# Projeto Cadastro Registro
URL Swagger: http://localhost:8082/swagger-ui.html

# URL Console OpenShift
https://10.0.75.2:8443/console/catalog
