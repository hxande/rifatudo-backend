# Documentação Técnica — cadastro-registro-api

Este diretório centraliza a documentação técnica do serviço `cadastro-registro-api`, parte do ecossistema **Soucoop** (Sescoop/OCB). A estrutura segue o template **arc42**, modelo **C4** (níveis 1–3) e registra decisões arquiteturais como **ADRs**.

## Visão Resumida

O `cadastro-registro-api` é o serviço **write** responsável por toda a operação transacional do registro de cooperativas no Sescoop — incluindo cadastro de pessoas físicas e jurídicas, governança, mandatos, certificação, anuário, censo, regularidade cooperativa e arrecadação. A leitura/consulta é atendida pelo serviço gêmeo `cadastro-registro-leitura-api`.

- **Stack:** Java 17, Spring Boot 3.2.12, Spring Cloud 2023.0.5, Hibernate 6.4.10 + Envers, QueryDSL 5.0.0, Liquibase, MapStruct 1.6.3, ModelMapper 3.1.0, Microsoft SQL Server, Keycloak (OAuth2 Resource Server), Spring AMQP / RabbitMQ, JasperReports 6.18.1, SpringDoc OpenAPI 2.6.0, Lombok 1.18.24.
- **Volume:** 125 RestControllers, 132 Services, 99 Repositories, 105 Entidades JPA, 120 módulos funcionais.
- **Domínio:** Cadastro e Registro Cooperativo — Soucoop.
- **Pilar Sescoop/OCB:** Registro, Monitoramento e Regularidade.

## Como navegar

| Tema | Localização |
|------|-------------|
| Visão geral arc42 | [`architecture/01-overview.md`](architecture/01-overview.md) |
| Restrições | [`architecture/02-constraints.md`](architecture/02-constraints.md) |
| Contexto (C4 nível 1) | [`architecture/03-context.md`](architecture/03-context.md) |
| Blocos de construção (C4 nível 2 e 3) | [`architecture/04-building-blocks.md`](architecture/04-building-blocks.md) |
| Cenários de execução | [`architecture/05-runtime.md`](architecture/05-runtime.md) |
| Deploy | [`architecture/06-deployment.md`](architecture/06-deployment.md) |
| Qualidade (NFRs) | [`architecture/07-quality.md`](architecture/07-quality.md) |
| Débito técnico | [`architecture/08-technical-debt.md`](architecture/08-technical-debt.md) |
| Decisões (ADR) | [`architecture/decisions/`](architecture/decisions/) |
| Diagramas C4 | [`architecture/diagrams/`](architecture/diagrams/) |
| Módulos de negócio | [`modules/`](modules/) |
| LGPD | [`compliance/lgpd.md`](compliance/lgpd.md) |
| Endpoints | [`api/endpoints.md`](api/endpoints.md) |
| Glossário | [`glossary.md`](glossary.md) |

## Stack detalhada

| Camada | Tecnologia |
|--------|-----------|
| Linguagem | Java 17 |
| Framework | Spring Boot 3.2.12 |
| Config distribuído | Spring Cloud Config (cliente) |
| Persistência | Spring Data JPA + Hibernate 6.4.10 |
| Auditoria | Hibernate Envers (`@Audited` em todas as entidades-chave) |
| Consultas dinâmicas | QueryDSL 5.0.0 |
| Migrations | Liquibase (master em `classpath:/Liquibase/changelog-master.xml`, 246 changesets, dialeto `mssql`, `endDelimiter="\nGO"`) |
| Mapeamento | MapStruct 1.6.3 + ModelMapper 3.1.0 |
| Banco | Microsoft SQL Server (instância `cobalt:1433`, database `api_cadastro_registro` em local) |
| Segurança | OAuth2 Resource Server (JWT emitido pelo Keycloak, realm OCB) |
| Mensageria | Spring AMQP — RabbitMQ (`10.7.0.47`, vhost `rabbitmq-dev`) |
| Relatórios | JasperReports 6.18.1 |
| Documentação | SpringDoc OpenAPI 2.6.0 (`/swagger-ui.html`) |
| Build | Maven, Surefire 3.2.5 (paralelo 15 threads), JaCoCo 0.8.7 |
| Empacotamento | Docker (imagem base `jdk_maven:17.3.8.4`) |

## Profiles

- `application.properties` — defaults
- `application-local.properties` — desenvolvimento local (porta 8082, contexto `/cadastro-registro-api`, Keycloak HMLG, SQL Server `cobalt`)
- `application-hmlg.properties` — homologação
- `application-prd.properties` — produção

Ativação: `-Dspring.profiles.active=local|hmlg|prd`.

## Pacote raiz

`br.coop.somoscooperativismo.registro.api.v1` — anotado com `@SpringBootApplication`.

## Atualização

> ⚠️ **Importante:** este conjunto de documentos foi gerado a partir de evidências do codebase em 2026-05-15 e **revisado em 2026-06-19** contra o estado atual do branch `develop` (após ~122 commits). Toda alteração estrutural relevante (novo módulo, nova integração, mudança de stack, decisão arquitetural) deve gerar **um novo ADR** em `architecture/decisions/`.

> 📌 **Principais mudanças desde 2026-05-15** (revisão de 2026-06-19):
> - Integração com o **GDH (desenvolvimento humano)** migrada de chamada HTTP síncrona (`DesenvolvimentoHumanoClient`) para **eventos assíncronos via RabbitMQ** (Governança → fila com DLQ). Ver novo [`decisions/0006-integracao-gdh-evento-rabbitmq-dlq.md`](architecture/decisions/0006-integracao-gdh-evento-rabbitmq-dlq.md).
> - **DLQ (Dead Letter Queue)** implementada neste serviço (`api.v1.dlq`) com persistência e reprocessamento — antes inexistente (ver ADR 0005).
> - `EmailClient` (HTTP) **removido**; envio de e-mail agora ocorre exclusivamente via `EmailPublisher`/`EmailService` (RabbitMQ) — refatorações `ARQ-183`/`ARQ-185`.
> - Novo módulo `vinculosolicitacao` / `cooperativavinculacao` (`SOU-1148`): solicitação de vínculo entre cooperativas.
> - Clientes HTTP OAuth2 reduzidos de 11 para **9** (removidos `EmailClient` e `DesenvolvimentoHumanoClient`).
