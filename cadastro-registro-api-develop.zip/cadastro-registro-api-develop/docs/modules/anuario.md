# Módulo — Anuário / Censo

## Propósito

Coleta os **dados anuais** das cooperativas para o **Anuário Cooperativista** e o **Censo**. Sustenta os indicadores estatísticos do cooperativismo brasileiro publicados pela OCB.

## Pacote

`br.coop.somoscooperativismo.registro.api.v1.anuario`, `anuarionovo`, `censoanuario`.

## Entidades-chave

- `Anuario` — coleta anual (auditada).
- `CensoAnuario` — formulário de censo.

## Componentes

| Camada | Componente |
|--------|-----------|
| Web | `AnuarioRestController`, `AnuarioNovoRestController`, `CensoAnuarioRestController` |
| Serviço | `AnuarioService`, `CensoAnuarioService` |
| Repositório | `AnuarioRepository`, `CensoAnuarioRepository` |
| Integração | `DesempenhoClient`, `RelatorioClient`, `EmailPublisher` |

## Cache

- `CACHE_PARAMETRO_QUADRO_SOCIAL`

## Fluxo — preenchimento anual

```mermaid
sequenceDiagram
    actor U as Responsável da cooperativa
    participant Ctrl as AnuarioRestController
    participant Svc as AnuarioService
    participant Repo as AnuarioRepository
    participant DB as SQL Server
    participant Sched as Scheduler diário
    participant MQ as RabbitMQ

    U->>Ctrl: POST /anuario (JWT)
    Ctrl->>Svc: salvar(anuarioTO)
    Svc->>Svc: validar período aberto
    Svc->>Repo: save
    Repo->>DB: INSERT TB_ANUARIO + AUD

    Note over Sched: cron 0 0 10 * * *
    Sched->>Svc: notificar pendências
    Svc->>MQ: EventoEmail (lembrete anuário)
```

## Pontos de atenção

> ⚠️ O fluxo "anuário novo" coexiste com o "anuário" — sinal de migração em curso. Documentar transição entre versões.

> ⚠️ Janelas de coleta (data início/fim) lidas de parametrização — invalidação do cache só ocorre por TTL (1h–4h).
