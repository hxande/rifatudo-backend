# Módulo — Cadastro/Registro

## Propósito

Orquestra o ciclo de vida da **solicitação de registro cooperativo**: criação, análise, pendências, aprovação ou indeferimento. É o módulo central que dá nome ao serviço.

## Pacote

`br.coop.somoscooperativismo.registro.api.v1.cadastroregistro` (e correlatos `solicitacao`, `aprovacao`).

## Entidades-chave

- `Solicitacao` — solicitação de registro (auditada).
- `CadastroRegistro` — vínculo formal entre cooperativa e Sescoop após aprovação.
- `Aprovacao` — registro do ato aprobatório.
- `EventoEmail` — notificação assíncrona.

## Componentes

| Camada | Componente |
|--------|-----------|
| Web | `CadastroRegistroRestController`, `SolicitacaoRestController`, `AprovacaoRestController` |
| Serviço | `CadastroRegistroService`, `SolicitacaoService`, `AprovacaoService` |
| Repositório | `CadastroRegistroRepository`, `SolicitacaoRepository` |
| Integração | `SerproClient`, `EmailPublisher`, `GovernancaPublisher` (eventos de governança → GDH via RabbitMQ) |

## Cache

- `CACHE_CADASTRO_REGISTRO`
- `CACHE_CADASTRO_REGISTRO_LEITURA`

## Fluxo — solicitação até aprovação

```mermaid
sequenceDiagram
    actor U as Usuário (cooperativa ou UF)
    participant SCtrl as SolicitacaoRestController
    participant SSvc as SolicitacaoService
    participant Serpro as SerproClient
    participant DB as SQL Server
    participant ASvc as AprovacaoService
    participant MQ as RabbitMQ

    U->>SCtrl: POST /solicitacao (JWT)
    SCtrl->>SSvc: criar(solicitacaoTO)
    SSvc->>Serpro: consultarCNPJ
    SSvc->>DB: INSERT TB_SOLICITACAO + AUD
    SSvc->>MQ: EventoEmail (recebido)
    SCtrl-->>U: 201 Created

    U->>ASvc: POST /aprovacao/{id}/aprovar
    ASvc->>DB: UPDATE situacao = APROVADA
    ASvc->>DB: INSERT TB_CADASTRO_REGISTRO
    ASvc->>MQ: EventoEmail (aprovado)
```

## Pontos de atenção

> ⚠️ Regras de UF e perfil tratadas no service. Trocas de estado da `Solicitacao` deveriam ser cobertas por testes de máquina de estado.

> ⚠️ Volume alto de regras concentradas neste módulo — candidato a refatoração para serviços menores se a complexidade continuar crescendo.
