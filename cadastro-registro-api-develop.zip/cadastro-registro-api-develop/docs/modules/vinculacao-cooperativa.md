# Módulo — Vínculo entre Cooperativas

> Adicionado em 2026-06 (`SOU-1148`).

## Propósito

Gerencia o ciclo de **solicitação de vínculo entre cooperativas** — quando uma cooperativa solicita filiação a uma cooperativa superior (`FILIACAO_SUPERIOR`) ou pede para gerenciar uma cooperativa filiada (`GERENCIAR_FILIADA`). A cooperativa indicada analisa a solicitação, aprovando ou reprovando.

## Pacote

`br.coop.somoscooperativismo.registro.api.v1.vinculosolicitacao` (correlato: `cooperativavinculacao`).

## Entidades-chave

- `CooperativaVinculacaoSolicitacao` — solicitação de vínculo (`COOPERATIVA_VINCULACAO_SOLICITACAO`), com `cooperativaSolicitante`, `cooperativaIndicada`, `tipoVinculo`, `status`, datas e usuários de solicitação/análise.
- `CooperativaVinculacao` — vínculo efetivado entre cooperativas.

## Enums

- `TipoVinculoSolicitacaoEnum` — `FILIACAO_SUPERIOR`, `GERENCIAR_FILIADA`.
- `StatusVinculoSolicitacaoEnum` — `AGUARDANDO_APROVACAO`, `APROVADO`, `REPROVADO`.

## Componentes

| Camada | Componente |
|--------|-----------|
| Web | `CooperativaVinculacaoSolicitacaoRestController`, `CooperativaVinculacaoRestController` |
| Serviço | `CooperativaVinculacaoSolicitacaoService`, `CooperativaVinculacaoService` |
| Repositório | `CooperativaVinculacaoSolicitacaoRepository`, `CooperativaVinculacaoRepository` |
| TO/Request | `CooperativaVinculacaoSolicitacaoTO`, `CriarVinculoSolicitacaoRequest`, `CooperativaSuperiorBuscaTO` |

## Endpoints (`/api/v1/vinculacaocooperativa-solicitacao`)

| Método | Rota | Propósito |
|--------|------|-----------|
| `POST` | `/` | Criar solicitação de vínculo |
| `GET` | `/solicitante/{idCooperativa}` | Solicitações emitidas por uma cooperativa |
| `GET` | `/pendentes/{idCooperativaIndicada}` | Solicitações pendentes de análise da cooperativa indicada |
| `PUT` | `/{idSolicitacao}/aprovar` | Aprovar solicitação |
| `PUT` | `/{idSolicitacao}/reprovar` | Reprovar solicitação |
| `DELETE` | `/{idSolicitacao}` | Cancelar/remover solicitação |

## Migration

- `changes/2026/20260520_create_table_cooperativa_vinculacao_solicitacao.sql` (changeset no `changelog-master.xml`).

## Pontos de atenção

> ⚠️ A transição de `status` (`AGUARDANDO_APROVACAO` → `APROVADO`/`REPROVADO`) deveria ser coberta por testes de máquina de estado, garantindo que apenas a cooperativa indicada possa analisar.
