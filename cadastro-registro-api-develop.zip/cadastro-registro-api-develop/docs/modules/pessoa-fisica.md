# Módulo — Pessoa Física

## Propósito

Gerencia o cadastro de **pessoas físicas** vinculadas ao ecossistema cooperativista: dirigentes, membros de governança, integrantes do quadro social, instrutores e usuários relacionados.

## Pacote

`br.coop.somoscooperativismo.registro.api.v1.pessoafisica`.

## Entidades-chave

- `PessoaFisica` (auditada por Envers) — atributos:
  - `cpf`, `nome`, `dataNascimento`
  - `telefone`, `celular`, `email`
  - `rg`, `profissao`, `genero`, `escolaridade`
- View read-only: `VwPessoaFisica` (`insertable=false, updatable=false`).
- Superclasse: `Pessoa`.

> ⚠️ **LGPD:** todos os atributos acima são **dados pessoais sensíveis** ou identificadores diretos. Não há mascaramento/criptografia em repouso. Ver [`../compliance/lgpd.md`](../compliance/lgpd.md).

## Componentes

| Camada | Componente | Função |
|--------|-----------|--------|
| Web | `PessoaFisicaRestController` | Endpoints REST |
| Serviço | `PessoaFisicaService` | Regras: CPF válido, e-mail único, idade mínima |
| Repositório | `PessoaFisicaRepository` | JPA + QueryDSL |
| Integração | `PessoaClient` | Sincronização com `pessoa-api` |

## Fluxo principal

```mermaid
sequenceDiagram
    actor U as Usuário
    participant Ctrl as PessoaFisicaRestController
    participant Svc as PessoaFisicaService
    participant Repo as PessoaFisicaRepository
    participant DB as SQL Server
    participant Cli as PessoaClient

    U->>Ctrl: POST /pessoaFisica (JWT)
    Ctrl->>Svc: criar(pessoaFisicaTO)
    Svc->>Svc: validar CPF, e-mail, idade
    Svc->>Cli: sincronizar(pessoa-api)
    Svc->>Repo: save(pessoaFisica)
    Repo->>DB: INSERT TB_PESSOA_FISICA + AUD
    Svc-->>Ctrl: pessoaFisicaTO
    Ctrl-->>U: 201 Created
```

## Pontos de atenção

> ⚠️ Conformidade LGPD parcial — auditoria coberta por Envers, porém sem minimização nem mascaramento.

> ⚠️ Falha do `PessoaClient` propaga 5xx para o front (sem retry).
