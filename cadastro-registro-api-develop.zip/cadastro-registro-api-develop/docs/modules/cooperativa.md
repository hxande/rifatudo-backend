# Módulo — Cooperativa

## Propósito

Centraliza o cadastro de **cooperativas brasileiras** registradas no Sescoop/OCB. Mantém dados cadastrais, ramo, segmento, natureza jurídica, situação e vínculo com pessoas jurídicas (`PessoaJuridica`).

## Pacote

`br.coop.somoscooperativismo.registro.api.v1.cooperativa` e correlatos (`cooperativaregistro`, `ramo`, `unidadeestadual`).

## Entidades-chave

- `Cooperativa` — Cooperativa registrada (auditada por Envers).
- `PessoaJuridica` — Dados base da PJ (CNPJ, razão social, natureza jurídica).
- `Ramo` — Ramo cooperativista (agropecuário, crédito, etc.).
- `UnidadeEstadual` — Sescoop estadual.
- `SituacaoCooperativa` — Enumeração de situações.

## Componentes

| Camada | Componente | Função |
|--------|-----------|--------|
| Web | `CooperativaRestController` | Endpoints REST |
| Serviço | `CooperativaService` | Regras de negócio |
| Repositório | `CooperativaRepository` | Acesso JPA + QueryDSL |
| Integração | `SerproClient` | Consulta CNPJ |
| Integração | `LocalizacaoClient` | UF, município |

## Cache

- `CACHE_RAMO`
- `CACHE_SITUACAO_COOPERATIVA`
- `CACHE_SEGMENTOS`

## Fluxo principal

```mermaid
sequenceDiagram
    actor U as Usuário UF
    participant Ctrl as CooperativaRestController
    participant Svc as CooperativaService
    participant Repo as CooperativaRepository
    participant DB as SQL Server
    participant Serpro as SerproClient

    U->>Ctrl: POST /cooperativa (JWT)
    Ctrl->>Svc: criar(cooperativaTO)
    Svc->>Serpro: consultar(CNPJ)
    Serpro-->>Svc: dadosPJ
    Svc->>Svc: validar ramo, UF, situação
    Svc->>Repo: save(cooperativa)
    Repo->>DB: INSERT TB_COOPERATIVA + AUD
    Svc-->>Ctrl: cooperativaTO
    Ctrl-->>U: 201 Created
```

## Pontos de atenção

> ⚠️ Regras de UF (uma cooperativa pertence a uma UF) aplicadas no service — sem `@PreAuthorize`.

> ⚠️ Falha do Serpro derruba criação (sem retry/circuit breaker).
