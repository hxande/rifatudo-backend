# Módulo — Certificado

## Propósito

Emite e gerencia os **certificados de regularidade** das cooperativas (Sescoop UF e Nacional). Atende cooperativas que precisam comprovar regularidade para licitações, financiamentos e operações com órgãos públicos.

## Pacote

`br.coop.somoscooperativismo.registro.api.v1.certificado` (e correlatos `regularidadecooperativa`).

## Entidades-chave

- `Certificado` — emissão genérica.
- `CertificadoUnidadeEstadual` — emissão por UF.
- `CertificadoRegularidade` — regularidade nacional.

Todas auditadas por Envers.

## Componentes

| Camada | Componente |
|--------|-----------|
| Web | `CertificadoRestController`, `RegularidadeRestController` |
| Serviço | `CertificadoService`, `RegularidadeCooperativaService` |
| Repositório | `CertificadoRepository` |
| Geração | `JasperReports` 6.18.1 |
| Integração | `RelatorioClient`, `FileUploadClient`, `EmailPublisher` |

## Fluxo — emissão

```mermaid
sequenceDiagram
    actor U as Cooperativa
    participant Ctrl as CertificadoRestController
    participant Svc as CertificadoService
    participant DB as SQL Server
    participant JR as JasperReports
    participant Rel as RelatorioClient
    participant MQ as RabbitMQ

    U->>Ctrl: GET /certificado/{cnpj}
    Ctrl->>Svc: emitir(cnpj)
    Svc->>DB: validar regularidade e pendências
    Svc->>JR: render(template, dados)
    JR-->>Svc: PDF
    Svc->>Rel: persistirRelatorio
    Svc->>MQ: EventoEmail (certificado emitido)
    Svc-->>Ctrl: PDF
    Ctrl-->>U: 200 OK + application/pdf
```

## Pontos de atenção

> ⚠️ Validade do certificado depende de cron diário (`tempo-rotina`) e semanal (`tempo-rotina-suspensao`). Sem ShedLock, há risco em múltiplas réplicas.

> ⚠️ Sem retry no `RelatorioClient` — falha na persistência do relatório bloqueia a emissão.
