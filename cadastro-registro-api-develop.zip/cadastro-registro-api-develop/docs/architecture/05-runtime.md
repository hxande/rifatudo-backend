# 5. Cenários de Execução (Runtime)

Esta seção descreve os principais fluxos dinâmicos do `cadastro-registro-api`.

## 5.1 Cenário — Cadastrar nova Pessoa Física

```mermaid
sequenceDiagram
    actor U as Usuário (Front)
    participant CR as cadastro-registro-front
    participant API as cadastro-registro-api
    participant DB as SQL Server
    participant ENV as Envers (Audit)

    U->>CR: Preenche formulário PF
    CR->>API: POST /api/v1/pessoaFisica (JWT)
    API->>API: Filtro OAuth2 valida JWT
    API->>API: Mapeia PessoaFisicaTO → PessoaFisica
    API->>API: Service aplica regras (CPF, idade, e-mail)
    API->>DB: INSERT TB_PESSOA_FISICA
    API->>ENV: Grava revisão (REV_INFO)
    API-->>CR: 201 Created + PessoaFisicaTO
    CR-->>U: Confirmação
```

> ⚠️ Dados sensíveis (CPF, RG, e-mail, telefone) persistem sem mascaramento explícito. Ver [`compliance/lgpd.md`](../compliance/lgpd.md).

## 5.2 Cenário — Solicitação de Registro de Cooperativa

```mermaid
sequenceDiagram
    actor U as Usuário UF
    participant API as cadastro-registro-api
    participant SER as SerproClient
    participant DB as SQL Server
    participant MQ as RabbitMQ
    participant MAIL as email-api

    U->>API: POST /api/v1/solicitacao (JWT)
    API->>SER: Consulta CNPJ (Serpro)
    SER-->>API: Dados PJ
    API->>API: Valida dados, ramo, UF
    API->>DB: INSERT TB_SOLICITACAO + TB_PESSOA_JURIDICA
    API->>MQ: Publica EventoEmail (boas-vindas)
    MQ->>MAIL: Consome evento
    MAIL-->>U: E-mail enviado
    API-->>U: 201 Created + SolicitacaoTO
```

## 5.3 Cenário — Aprovação de Registro

```mermaid
sequenceDiagram
    actor A as Analista Sescoop
    participant API as cadastro-registro-api
    participant DB as SQL Server
    participant CERT as Geração de Certificado
    participant MQ as RabbitMQ

    A->>API: POST /api/v1/aprovacao/{id}/aprovar (JWT)
    API->>API: Valida estado da solicitação
    API->>DB: UPDATE TB_SOLICITACAO (status=APROVADA)
    API->>CERT: Cria CertificadoRegularidade
    CERT->>DB: INSERT TB_CERTIFICADO
    API->>MQ: Publica EventoEmail (notificação)
    API-->>A: 200 OK
```

## 5.4 Cenário — Emissão de Certificado de Regularidade

```mermaid
sequenceDiagram
    actor U as Usuário
    participant API as cadastro-registro-api
    participant DB as SQL Server
    participant REL as relatorio-api
    participant JR as JasperReports

    U->>API: GET /api/v1/certificado/{cnpj}
    API->>DB: SELECT regularidade da cooperativa
    API->>API: Valida vigência e pendências
    API->>JR: Gera PDF (template Jasper)
    API->>REL: Persiste relatório gerado
    API-->>U: 200 OK + PDF
```

## 5.5 Cenário — Cron diário (`tempo-rotina`)

```mermaid
sequenceDiagram
    participant SCH as Spring Scheduler
    participant SVC as Service de Rotina
    participant DB as SQL Server
    participant MQ as RabbitMQ

    Note over SCH: cron 0 0 10 * * *
    SCH->>SVC: Dispara rotina diária
    SVC->>DB: Lê pendências, vencimentos
    SVC->>DB: Atualiza status de regularidade
    SVC->>MQ: Publica eventos de e-mail
```

## 5.6 Cenário — Cron semanal (`tempo-rotina-suspensao`)

```mermaid
sequenceDiagram
    participant SCH as Spring Scheduler
    participant SVC as SuspensaoService
    participant DB as SQL Server

    Note over SCH: cron 0 0 8 * * 1 (segunda 8h)
    SCH->>SVC: Avalia cooperativas inadimplentes
    SVC->>DB: Marca suspensões e atualiza certificados
```

## 5.7 Cenário — Erro em integração externa

Hoje, sem Resilience4j:

```mermaid
sequenceDiagram
    participant API as cadastro-registro-api
    participant EXT as Serviço externo

    API->>EXT: GET (keycloakRestTemplate)
    EXT--xAPI: Timeout / 5xx
    API->>API: Exceção propaga
    API-->>Caller: 500 Internal Server Error
```

> ⚠️ **Risco:** falha de qualquer parceiro derruba operação local. Recomenda-se Resilience4j com `retry`, `circuit breaker` e `time limiter` por client.
