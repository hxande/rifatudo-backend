# 8. Débito Técnico

Esta seção consolida os débitos identificados durante o levantamento do codebase em 2026-05-15, **revisada em 2026-06-19** contra o estado atual do `develop`. A intenção é **tornar visível**, não atribuir responsabilidade.

## 8.1 Sumário priorizado

| # | Débito | Severidade | Impacto |
|---|--------|------------|---------|
| 1 | LGPD: dados pessoais sem mascaramento/criptografia | Alta | Conformidade legal |
| 2 | Sem retry / circuit breaker (Resilience4j ausente) | Alta | Disponibilidade |
| 3 | Sem `@PreAuthorize` por método nos controllers | Alta | Segurança / autorização |
| 4 | Actuator com `*` exposto | Média | Superfície de exposição |
| 5 | Cron sem coordenação multi-réplica (ShedLock ausente) | Média | Duplicidade de execução |
| 6 | 120 módulos — alta granularidade de pacotes | Média | Manutenibilidade |
| 7 | API sem versionamento por negociação de conteúdo | Média | Evolução de contrato |
| 8 | Ausência de ADRs até esta documentação (mitigado — ADRs 0001–0006) | Baixa | Governança arquitetural |
| 9 | 10 arquivos com `TODO`/`FIXME` | Baixa | Higiene de código |
| 10 | CORS permissivo | Baixa-Média | Segurança |

## 8.2 Detalhamento

### 1. LGPD — dados sensíveis sem proteção em repouso

`PessoaFisica` armazena CPF, RG, nome, dataNascimento, telefone, celular, e-mail, profissão, gênero, escolaridade sem mascaramento/criptografia. Não há documentação de fluxo de eliminação de dados (LGPD Art. 18).

Ações sugeridas:
- Identificar quais campos exigem criptografia em repouso (`@Convert(converter = ...)`).
- Implementar máscara de exibição (CPF parcial) em respostas onde não houver necessidade do dado completo.
- Documentar fluxo de **direito ao esquecimento**.

Ver [`../compliance/lgpd.md`](../compliance/lgpd.md).

### 2. Ausência de Resilience4j

9 clients HTTP, sem retry, circuit breaker, time limiter ou bulkhead. Falha em Serpro ou em qualquer parceiro propaga como 5xx para o front.

> ℹ️ **Atualização 2026-06-19:** a integração de governança → GDH deixou de ser HTTP e passou a usar **eventos RabbitMQ com Dead Letter Queue** (ver ADR 0006), o que adiciona resiliência (reprocessamento) a esse fluxo específico. Os demais clients HTTP permanecem sem proteção.

Ações sugeridas:
- Adicionar dependência `spring-cloud-starter-circuitbreaker-reactor-resilience4j` ou equivalente síncrono.
- Definir políticas por client (Serpro = retry curto; serviços internos = circuit breaker rápido).

### 3. Autorização granular ausente nos controllers

Não foram encontrados `@PreAuthorize` nos 125 controllers. A autorização efetiva está na camada de serviço — risco de novos endpoints esquecerem regras de UF/perfil.

Ações sugeridas:
- Adicionar `@PreAuthorize("hasAuthority('...')")` nos endpoints mutadores.
- Centralizar regras de UF em `MethodSecurityExpressionHandler` customizado.

### 4. Actuator `*` exposto

`management.endpoints.web.exposure.include=*` em produção amplia a superfície (heapdump, env, etc.). Ajustar para o conjunto mínimo necessário (`health, info, prometheus`).

### 5. Cron sem coordenação multi-réplica

`tempo-rotina` e `tempo-rotina-suspensao` rodam sempre que o container sobe. Em mais de uma réplica, ambas executarão a mesma rotina. Ver ShedLock (já usado em `gerencia-usuario`).

### 6. 120 módulos / pacotes

A divisão fina pode dificultar localização e duplicar responsabilidades. Sugere-se inventário e fusão de pacotes muito pequenos durante refatorações futuras.

### 7. Versionamento de API

Path `/api/v1` está presente, porém não há negociação por header (`Accept: application/vnd.sescoop.v1+json`) ou estratégia de coexistência v1/v2 documentada.

### 8. ADRs

Antes desta documentação, decisões arquiteturais não tinham registro. Os primeiros 5 ADRs (`0001`–`0005`) foram criados retroativamente. Na revisão de 2026-06-19 foi adicionado o ADR `0006` (integração GDH por evento RabbitMQ + DLQ), demonstrando o uso vivo do processo de governança.

### 9. `TODO`/`FIXME`

10 arquivos contêm marcações pendentes. Recomenda-se varredura periódica e abertura de issues.

### 10. CORS

Configuração permissiva — adequada para desenvolvimento, **revisar** em produção.

## 8.3 Como abater

Cada item acima deve virar uma issue rastreada. Mudanças estruturais devem gerar novo ADR e atualizar este capítulo.
