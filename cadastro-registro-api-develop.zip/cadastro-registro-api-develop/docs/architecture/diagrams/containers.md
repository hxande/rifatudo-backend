# Diagrama C4 — Nível 2 (Containers)

```mermaid
flowchart TD
    Front[cadastro-registro-front<br/>SPA Angular]

    subgraph OS[OpenShift]
        subgraph NS[Namespace cadastro-registro]
            API[cadastro-registro-api<br/>Spring Boot 3.2.12]
            Leit[cadastro-registro-leitura-api]
        end

        subgraph Plat[Namespace plataforma]
            KC[Keycloak]
            Cfg[Config Server]
            MQ[(RabbitMQ)]
        end

        subgraph Data[Namespace data]
            DB[(SQL Server)]
        end
    end

    Front -->|HTTPS JWT| API
    Front -->|HTTPS JWT| Leit

    API -->|JDBC| DB
    API -->|AMQP| MQ
    API -. config .-> Cfg
    API -. JWT .-> KC
    API -->|OAuth2 REST| Leit
```

## Containers principais

| Container | Tecnologia | Responsabilidade |
|-----------|------------|------------------|
| `cadastro-registro-api` | Spring Boot 3.2.12 | Escrita transacional do domínio |
| `cadastro-registro-leitura-api` | Spring Boot 3.x | Consultas otimizadas |
| `cadastro-registro-front` | Angular 14 | Interface do usuário |

## Componentes internos do `cadastro-registro-api`

```mermaid
flowchart LR
    Web[125 RestControllers]
    Svc[132 Services]
    Repo[99 Repositories]
    Ent[(105 Entidades JPA Auditadas)]
    Cli[9 Clients OAuth2]
    Pub[Publishers/Listeners AMQP + DLQ]
    Cache[Spring Cache - 12 regiões]
    Sch[Schedulers Cron]
    Sec[SecurityConfig OAuth2]

    Web --> Svc
    Svc --> Repo
    Repo --> Ent
    Svc --> Cli
    Svc --> Pub
    Svc --> Cache
    Sch --> Svc
    Sec -. filtros .- Web
```
