# Diagrama C4 — Nível 1 (Contexto)

```mermaid
flowchart TD
    User[Usuário Sescoop / Cooperativa]
    Front[cadastro-registro-front<br/>SPA Angular 14]
    API[cadastro-registro-api<br/>Spring Boot 3.2.12]
    Leitura[cadastro-registro-leitura-api]
    KC[Keycloak<br/>Realm OCB]
    Serpro[Serpro - CNPJ]
    GU[gerencia-usuario-api]
    Pessoa[pessoa-api]
    Desemp[desempenho-api]
    Arrec[arrecadacao-api]
    Rel[relatorio-api]
    Mail[email-api]
    GDH[desenvolvimento-humano-controlador-api]
    Loc[localizacao-api]
    Doc[documento-api]
    File[file-upload-api]
    DB[(MS SQL Server)]
    MQ[(RabbitMQ)]
    Cfg[Spring Cloud Config Server]

    User --> Front
    User -. login OIDC .-> KC
    Front -->|HTTPS + JWT| API
    Front -. valida token .-> KC

    API -->|JDBC| DB
    API -->|AMQP| MQ
    API -. busca configs .-> Cfg
    API -. valida JWT .-> KC

    API -->|REST OAuth2| Leitura
    API -->|REST OAuth2| GU
    API -->|REST OAuth2| Pessoa
    API -->|REST OAuth2| Desemp
    API -->|REST OAuth2| Arrec
    API -->|REST OAuth2| Rel
    API -->|AMQP| Mail
    API -->|AMQP eventos governança + DLQ| GDH
    API -->|REST OAuth2| Loc
    API -->|REST OAuth2| Doc
    API -->|REST OAuth2| File
    API -->|REST| Serpro
```

## Atores

- **Usuário Sescoop / Cooperativa** — opera via SPA.
- **`cadastro-registro-front`** — SPA Angular 14.

## Sistemas externos

- **Serpro** — consulta CNPJ.
- **Keycloak** — IdP do realm OCB.

## Sistemas internos do ecossistema

- `cadastro-registro-leitura-api`, `gerencia-usuario-api`, `pessoa-api`, `desempenho-api`, `arrecadacao-api`, `relatorio-api`, `email-api`, `desenvolvimento-humano-controlador-api`, `localizacao-api`, `documento-api`, `file-upload-api`.

## Infraestrutura

- MS SQL Server, RabbitMQ, Spring Cloud Config Server, OpenShift.
