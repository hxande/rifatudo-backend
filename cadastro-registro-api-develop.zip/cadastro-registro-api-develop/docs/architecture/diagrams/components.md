# Diagrama C4 — Nível 3 (Componentes principais)

## Módulo Cooperativa

```mermaid
flowchart TD
    Ctrl[CooperativaRestController]
    Svc[CooperativaService]
    Repo[CooperativaRepository]
    Ent[(Cooperativa @Audited)]
    Vw[(VwPessoaJuridica)]
    Serpro[SerproClient]
    Cache[CACHE_RAMO / CACHE_SITUACAO_COOPERATIVA]
    Loc[LocalizacaoClient]

    Ctrl --> Svc
    Svc --> Repo
    Repo --> Ent
    Svc --> Vw
    Svc --> Serpro
    Svc --> Cache
    Svc --> Loc
```

## Módulo Pessoa Física

```mermaid
flowchart TD
    Ctrl[PessoaFisicaRestController]
    Svc[PessoaFisicaService]
    Repo[PessoaFisicaRepository]
    Ent[(PessoaFisica @Audited)]
    Vw[(VwPessoaFisica)]
    Pub[EmailPublisher]
    MQ[(RabbitMQ)]

    Ctrl --> Svc
    Svc --> Repo
    Repo --> Ent
    Svc --> Vw
    Svc --> Pub
    Pub --> MQ
```

## Módulo Cadastro/Registro

```mermaid
flowchart TD
    Ctrl[CadastroRegistroRestController]
    Svc[CadastroRegistroService]
    Repo[CadastroRegistroRepository]
    Ent[(Solicitacao / Aprovacao @Audited)]
    Cache[CACHE_CADASTRO_REGISTRO]
    Mail[EmailPublisher]
    GovPub[GovernancaPublisher]
    MQ[(RabbitMQ<br/>governanca.exchange + DLQ)]

    Ctrl --> Svc
    Svc --> Repo
    Repo --> Ent
    Svc --> Cache
    Svc --> Mail
    Svc --> GovPub
    GovPub --> MQ
```

> ℹ️ A integração com o GDH (desenvolvimento humano) deixou de ser HTTP (`DesenvolvimentoHumanoClient`) e passou a ocorrer por **publicação de eventos no RabbitMQ** com Dead Letter Queue (ver `decisions/0006`).

## Módulo Certificado

```mermaid
flowchart TD
    Ctrl[CertificadoRestController]
    Svc[CertificadoService]
    Repo[CertificadoRepository]
    Ent[(Certificado / CertificadoRegularidade @Audited)]
    Jasper[JasperReports]
    Rel[RelatorioClient]
    Mail[EmailPublisher]

    Ctrl --> Svc
    Svc --> Repo
    Repo --> Ent
    Svc --> Jasper
    Svc --> Rel
    Svc --> Mail
```

## Módulo Anuário / Censo

```mermaid
flowchart TD
    Ctrl[AnuarioRestController]
    Svc[AnuarioService]
    Repo[AnuarioRepository]
    Ent[(Anuario / CensoAnuario @Audited)]
    Cache[CACHE_PARAMETRO_QUADRO_SOCIAL]
    Sched[Schedulers Cron]

    Ctrl --> Svc
    Svc --> Repo
    Repo --> Ent
    Svc --> Cache
    Sched --> Svc
```
