# 6. Visão de Deploy

## 6.1 Plataforma

- **OpenShift** (corporativo Sescoop/OCB) — orquestrador de containers.
- **Imagem Docker base:** `jdk_maven:17.3.8.4` (imagem interna).
- Comunicação entre serviços por DNS interno OpenShift (`.hmlg.svc`, `.prd.svc`).
- Configuração centralizada via **Spring Cloud Config Server**.

## 6.2 Ambientes

| Profile | Ambiente | Banco | Keycloak | Notas |
|---------|----------|-------|----------|-------|
| `local` | Desenvolvedor | `jdbc:sqlserver://cobalt:1433;databaseName=api_cadastro_registro` | Realm OCB (HMLG) | Porta 8082, contexto `/cadastro-registro-api` |
| `hmlg` | Homologação | SQL Server HMLG (via Config Server) | Realm OCB (HMLG) | DNS `.hmlg.svc` |
| `prd` | Produção | SQL Server PRD (via Config Server) | Realm OCB (PRD) | DNS `.prd.svc` |

Ativação: `-Dspring.profiles.active=local|hmlg|prd`.

## 6.3 Diagrama de Deploy

```mermaid
flowchart TD
    subgraph OS[OpenShift Cluster]
        subgraph NS[Namespace cadastro-registro]
            POD1[Pod cadastro-registro-api<br/>Spring Boot 3.2.12]
            POD2[Pod cadastro-registro-leitura-api]
        end
        subgraph NSCFG[Namespace plataforma]
            CFG[Spring Cloud Config Server]
            KC[Keycloak Realm OCB]
            MQ[(RabbitMQ)]
        end
        subgraph NSDATA[Namespace data]
            DB[(MS SQL Server)]
        end
    end

    FRONT[cadastro-registro-front<br/>SPA Angular]

    FRONT -->|HTTPS| POD1
    FRONT -->|HTTPS| POD2

    POD1 -->|JDBC| DB
    POD1 -->|AMQP| MQ
    POD1 -.config.-> CFG
    POD1 -->|OAuth2| KC
    POD1 -->|REST OAuth2| POD2
```

## 6.4 Build e empacotamento

- **Maven** (`mvn clean install`, `mvn spring-boot:run`).
- Surefire 3.2.5 com paralelismo de 15 threads.
- JaCoCo 0.8.7 para cobertura.
- `Dockerfile` na raiz produz a imagem do serviço.
- `docker-compose.yml` para subir dependências locais.
- Script `run-with-config-server.cmd` para execução local conectada ao Config Server.

## 6.5 Observabilidade

- **Spring Boot Actuator** com `management.endpoints.web.exposure.include=*`.
- **Prometheus** scrape em `/actuator/prometheus`.
- **Logs** rotativos: `cadastro-registro-api.log` + `.log.<data>.<n>.gz`.

> ⚠️ Expor `*` no Actuator em produção amplia a superfície de exposição. Recomenda-se restringir explicitamente em `application-prd.properties` (ver débito técnico).

## 6.6 Endpoints públicos relevantes

| Endpoint | Função |
|----------|--------|
| `/swagger-ui.html` | UI OpenAPI (SpringDoc 2.6.0) |
| `/v3/api-docs` | Spec OpenAPI |
| `/actuator/health` | Healthcheck |
| `/actuator/info` | Build info |
| `/actuator/prometheus` | Métricas |

## 6.7 Estratégia de release

- Branches por feature (`feature/...`).
- Promoção: `local → hmlg → prd`.
- Changesets Liquibase aplicados na inicialização do container.

> ⚠️ Não foi identificado **zero-downtime** explícito para migrations destrutivas. Mudanças de schema em colunas ativas devem seguir Expand/Contract.
