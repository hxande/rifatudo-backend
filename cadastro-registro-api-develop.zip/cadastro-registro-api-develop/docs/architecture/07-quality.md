# 7. Qualidade (Requisitos Não-Funcionais)

## 7.1 Cenários de qualidade

| ID | Atributo | Cenário | Status |
|----|----------|---------|--------|
| Q-01 | Segurança | Acesso aos endpoints requer JWT válido emitido pelo Keycloak | Atendido (OAuth2 Resource Server) |
| Q-02 | Auditabilidade | Toda alteração em entidades-chave gera revisão Envers | Atendido |
| Q-03 | Rastreabilidade | Logs estruturados + Actuator + Prometheus | Parcialmente atendido (logs textuais) |
| Q-04 | Conformidade LGPD | Dados pessoais protegidos e auditáveis | ⚠️ Gap: sem mascaramento/criptografia |
| Q-05 | Disponibilidade | Falha em parceiro externo não derruba o serviço | ⚠️ Gap: sem Resilience4j |
| Q-06 | Performance | Dados pouco voláteis cacheados por 1h–8h | Atendido (12 regiões) |
| Q-07 | Escalabilidade | Pods stateless em OpenShift | Atendido (`SessionCreationPolicy.STATELESS`) |
| Q-08 | Testabilidade | Cobertura via JaCoCo | Atendido (sem meta definida documentada) |
| Q-09 | Manutenibilidade | Arquitetura em camadas e DTOs (`*TO`) | Atendido |
| Q-10 | Evolução do schema | Liquibase como fonte única | Atendido |

## 7.2 Atributos detalhados

### Segurança

- OAuth2 Resource Server + JWT.
- CORS configurado de forma permissiva — **avaliar restrição em produção**.
- Sessões STATELESS.
- Comunicação entre serviços via `keycloakRestTemplate` (propaga token).

> ⚠️ Ausência de `@PreAuthorize` por método nos controllers. Autorização granular fica no service. Risco: regras de UF/perfil podem ser esquecidas em novos endpoints.

### Auditabilidade

- Hibernate Envers em todas as entidades-chave (`@Audited`).
- Tabelas `*_AUD` mantidas pelo Envers.

### Performance

- Cache Spring com 12 regiões (TTL 1h/4h/8h).
- ThreadPool dedicado para tarefas assíncronas (core 2, max 5, queue 500).
- QueryDSL para consultas dinâmicas otimizadas.

### Resiliência

- Sem retry/circuit breaker. Falha de Serpro ou de qualquer cliente interno propaga como 5xx.
- RabbitMQ utilizado para desacoplar envio de e-mail — atenua falha do `email-api`.

### Compliance

- LGPD: dados pessoais armazenados sem mascaramento ou criptografia explícita.
- Auditoria suficiente para investigação retroativa.
- Direito de eliminação não está documentado como fluxo automatizado.

### Observabilidade

- Logs textuais em arquivo rotativo.
- Actuator `*` exposto.
- Prometheus scrape habilitado.

> ⚠️ Recomenda-se: logs estruturados (JSON), `Correlation-Id` por request, métricas customizadas por domínio.

### Testabilidade

- Surefire paralelo (15 threads).
- JaCoCo 0.8.7.
- Pasta `testesautomatizados` indica suíte separada.

## 7.3 Trade-offs explícitos

| Decisão | Vantagem | Custo |
|---------|----------|-------|
| Cache amplo (12 regiões) | Reduz carga no SQL Server | Risco de stale data; invalidação distribuída ausente |
| OAuth2 entre serviços | Padronização e segurança | Latência adicional por requisição token |
| Envers obrigatório | Auditabilidade integral | Crescimento das tabelas `*_AUD` |
| Cron interno | Simplicidade operacional | Pods múltiplos exigem coordenação (ShedLock está em `gerencia-usuario`, **não** aqui) |

> ⚠️ Se este serviço escalar para mais de uma réplica, os cron `tempo-rotina` e `tempo-rotina-suspensao` podem executar em paralelo gerando duplicidade. Avaliar ShedLock.
