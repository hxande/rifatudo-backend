# 1. Visão Geral e Objetivos

## 1.1 Objetivo de Negócio

O `cadastro-registro-api` é o **núcleo transacional do Soucoop** — sistema do Sescoop/OCB responsável por registrar e manter atualizado o cadastro de cooperativas brasileiras e seus integrantes. O serviço sustenta os processos finalísticos do **Registro Cooperativo** (Lei 5.764/71 e Lei 12.690/12), regularidade, governança e monitoramento estatístico (Anuário e Censo).

São responsabilidades principais:

- Cadastrar e manter **pessoas físicas** (PF) e **pessoas jurídicas** (PJ) que compõem o ecossistema cooperativista.
- Operar o **registro de cooperativas**, incluindo solicitações, aprovações e renovações.
- Gerenciar **governança cooperativa** (órgãos, mandatos, membros, cargos).
- Emitir e controlar **certificados de regularidade** por unidade estadual e nacional.
- Coletar dados do **Anuário Cooperativista** e **Censo**.
- Registrar **apontamentos**, **visitas técnicas** e **arrecadação**.
- Notificar eventos via e-mail assíncrono (RabbitMQ).
- Publicar eventos de **governança** (membro de diretoria atualizado, mandato encerrado) para o **GDH** via RabbitMQ.
- Integrar-se com Serpro (CNPJ), Keycloak (identidade) e demais APIs do ecossistema. A integração com o GDH passou a ser **assíncrona via mensageria** (antes era HTTP via `DesenvolvimentoHumanoClient`).

## 1.2 Stakeholders

| Stakeholder | Interesse |
|-------------|-----------|
| Sescoop Nacional | Registro nacional, regularidade, indicadores |
| Unidades Estaduais (Sescoop UF) | Cadastro local, certificados, visitas |
| Cooperativas registradas | Manter regularidade, dados do anuário |
| OCB (Organização das Cooperativas Brasileiras) | Governança, mandatos, ramos |
| Time de Desenvolvimento Sescoop | Manter, evoluir e operar o serviço |

## 1.3 Características essenciais

- **Domínio rico em regras regulatórias** (registro cooperativo, regularidade).
- **Forte exigência de auditabilidade** — toda alteração precisa ser rastreável (Hibernate Envers).
- **Forte exposição LGPD** — armazena CPF, RG, telefone, endereço, e-mail, gênero, escolaridade.
- **Integrações múltiplas e críticas** com serviços do ecossistema Sescoop/OCB.
- **Volume considerável de módulos** (120) — sinal de domínio amplo e necessidade de modularização cuidadosa.

## 1.4 Princípios arquiteturais adotados

1. **Separação CQRS leve:** este serviço concentra escrita; consultas estão em `cadastro-registro-leitura-api`.
2. **OAuth2 entre serviços:** todo chamado externo passa por `keycloakRestTemplate`.
3. **Configuração centralizada:** Spring Cloud Config Server fornece propriedades por profile.
4. **Migração estruturada de schema:** Liquibase é a única fonte da verdade do schema.
5. **Auditoria por padrão:** entidades-chave anotadas com `@Audited` (Envers).
6. **Cache para dados pouco voláteis:** 12 regiões de cache nomeadas com TTLs distintos.
7. **Assincronia para efeitos colaterais:** envio de e-mails sai por RabbitMQ.

## 1.5 Escopo

**Dentro do escopo:**

- Cadastro PF/PJ, cooperativas, governança, mandatos, certificados, anuário, censo, apontamentos, solicitações, visitas técnicas, arrecadação, regularidade.

**Fora do escopo:**

- Consultas otimizadas — `cadastro-registro-leitura-api`.
- Autenticação de usuário final — Keycloak (`gerencia-usuario`).
- Gestão de instrutores — `gestao-instrutor-api`.
- Trilha de desenvolvimento humano — `desenvolvimento-humano-controlador-api`.

## 1.6 Indicadores de tamanho

| Métrica | Valor |
|--------|-------|
| RestControllers | 125 |
| Services | 132 |
| Repositories | 99 |
| Entidades JPA | 105 |
| Módulos funcionais (pacotes) | 120 |
| ChangeSets Liquibase | 246 |
| Regiões de cache | 12 |
| Clientes HTTP externos | 9 |

> ⚠️ A quantidade de módulos (120) indica **complexidade significativa** — ver [`08-technical-debt.md`](08-technical-debt.md).
