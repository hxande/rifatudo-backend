# 3. Contexto e Escopo (C4 — Nível 1)

Este capítulo descreve o `cadastro-registro-api` em relação aos demais sistemas do ecossistema Sescoop/OCB.

## 3.1 Atores e sistemas externos

| Ator / Sistema | Tipo | Interação |
|---------------|------|-----------|
| Usuário Sescoop (UF/Nacional) | Humano | Acessa via `cadastro-registro-front` (SPA Angular) |
| Cooperativa registrada | Humano | Solicita registros, atualiza dados |
| Keycloak (`gerencia-usuario`) | Sistema | Provedor de identidade (OAuth2, JWT) |
| Serpro (CNPJ) | Sistema externo | Consulta de dados de PJ via `SerproClient` |
| `cadastro-registro-leitura-api` | Sistema interno | Serviço gêmeo de leitura (CQRS) |
| `gerencia-usuario-api` | Sistema interno | Cadastro de usuários do sistema |
| `pessoa-api` | Sistema interno | Cadastro de pessoas (camada compartilhada) |
| `desempenho-api` | Sistema interno | Indicadores de desempenho |
| `arrecadacao-api` | Sistema interno | Arrecadação cooperativa |
| `relatorio-api` | Sistema interno | Geração e armazenamento de relatórios |
| `email-api` | Sistema interno | Despacho efetivo de e-mails (consome eventos via RabbitMQ) |
| `desenvolvimento-humano-controlador-api` (GDH) | Sistema interno | Trilhas de desenvolvimento humano (recebe eventos de governança via RabbitMQ — ver ADR 0006) |
| `localizacao-api` | Sistema interno | Estados, municípios, CEP |
| `documento-api` | Sistema interno | Repositório de documentos |
| `file-upload-api` | Sistema interno | Upload de arquivos |
| Spring Cloud Config Server | Infraestrutura | Distribuição de propriedades |
| RabbitMQ | Infraestrutura | Filas de eventos de e-mail (`EventoEmail`) e de governança→GDH (com DLQ) |
| Microsoft SQL Server | Infraestrutura | Persistência primária |
| OpenShift | Infraestrutura | Orquestrador de containers |

## 3.2 Diagrama de Contexto

```mermaid
flowchart TD
    User[Usuário Sescoop / Cooperativa]
    Front[cadastro-registro-front<br/>Angular SPA]
    API[cadastro-registro-api<br/>Spring Boot 3.2.12]
    Leitura[cadastro-registro-leitura-api]
    KC[Keycloak<br/>Realm OCB]
    Serpro[Serpro<br/>Consulta CNPJ]
    GU[gerencia-usuario-api]
    Pessoa[pessoa-api]
    Desemp[desempenho-api]
    Arrec[arrecadacao-api]
    Rel[relatorio-api]
    Mail[email-api]
    GDH[desenvolvimento-humano-api]
    Loc[localizacao-api]
    Doc[documento-api]
    File[file-upload-api]
    DB[(MS SQL Server)]
    MQ[(RabbitMQ)]
    Cfg[Spring Cloud<br/>Config Server]

    User --> Front
    Front -->|HTTPS + JWT| API
    User -->|login OIDC| KC
    Front -. valida token .-> KC

    API -->|JDBC| DB
    API -->|AMQP| MQ
    API -.config.-> Cfg
    API -->|OAuth2 token| KC

    API -->|REST OAuth2| Leitura
    API -->|REST OAuth2| GU
    API -->|REST OAuth2| Pessoa
    API -->|REST OAuth2| Desemp
    API -->|REST OAuth2| Arrec
    API -->|REST OAuth2| Rel
    API -->|AMQP| Mail
    API -->|AMQP eventos governança + DLQ| GDH
    API -->|REST OAuth2| Loc
    API -->|REST OAuth2| Doc
    API -->|REST OAuth2| File
    API -->|REST| Serpro
```

Ver também versão dedicada em [`diagrams/context.md`](diagrams/context.md).

## 3.3 Fluxos de entrada principais

1. **Front (Angular)** chama endpoints REST autenticando com JWT do Keycloak.
2. **Cron internos** disparam rotinas (`tempo-rotina=0 0 10 * * *`, `tempo-rotina-suspensao=0 0 8 * * 1`) — não há entrada externa.
3. **Actuator** (`management.endpoints.web.exposure.include=*`) — Prometheus e info para observabilidade.

## 3.4 Fluxos de saída principais

- HTTP REST (OAuth2 propagado via `keycloakRestTemplate`) para 11 serviços internos + Serpro.
- Mensagens AMQP para fila de e-mail.
- JDBC para SQL Server (datasource padrão; ver leitura-api para multi-datasource).

## 3.5 Limites de responsabilidade

| Está dentro | Está fora |
|-------------|-----------|
| Cadastro e mutação de cooperativas, PF, PJ, governança, mandatos | Consultas otimizadas (`-leitura-api`) |
| Emissão e ciclo de vida de certificados | Geração visual de relatórios PDF (delegada ao `relatorio-api` quando aplicável) |
| Eventos de e-mail (publicação) | Despacho SMTP efetivo (`email-api`) |
| Solicitações de registro e aprovação | Login / cadastro de usuários (`gerencia-usuario`) |
| Coleta de Anuário e Censo | Visualização e BI de indicadores |

> ⚠️ A separação `-api` / `-leitura-api` exige disciplina: novas consultas complexas devem ir para o serviço gêmeo, evitando que o `-api` cresça em responsabilidades.
