# 2. Restrições

Esta seção lista as restrições **técnicas, organizacionais e regulatórias** que moldam a arquitetura do `cadastro-registro-api`. Elas não são negociáveis sem nova decisão arquitetural (ADR).

## 2.1 Restrições técnicas

| ID | Restrição | Origem |
|----|-----------|--------|
| RT-01 | Java 17 (LTS) | Padrão do ecossistema Sescoop/OCB |
| RT-02 | Spring Boot 3.2.12 (Spring 6) | Alinhamento com demais APIs do ecossistema |
| RT-03 | Spring Cloud 2023.0.5 | Compatibilidade com Spring Cloud Config Server |
| RT-04 | Microsoft SQL Server como SGBD | Padrão corporativo Sescoop |
| RT-05 | Liquibase com `dbms="mssql"` e `endDelimiter="\nGO"` | Compatibilidade com sintaxe SQL Server |
| RT-06 | Hibernate Envers obrigatório nas entidades-chave | Requisito legal de auditoria |
| RT-07 | Comunicação entre serviços via `keycloakRestTemplate` (OAuth2) | Padrão de segurança do ecossistema |
| RT-08 | Keycloak (realm OCB) como provedor de identidade | Único IdP corporativo |
| RT-09 | OpenShift como plataforma de runtime | Padrão de deploy Sescoop |
| RT-10 | Maven como ferramenta de build | Padrão do monorepo |
| RT-11 | Profiles obrigatórios: `local`, `hmlg`, `prd` | Padrão de promoção entre ambientes |
| RT-12 | Imagem Docker base `jdk_maven:17.3.8.4` | Imagem corporativa interna |

## 2.2 Restrições organizacionais

| ID | Restrição | Origem |
|----|-----------|--------|
| RO-01 | Idioma Java/TypeScript em **inglês** (variáveis técnicas); domínio em **português** | Padrão de codificação Sescoop |
| RO-02 | Mensagens e labels exclusivamente em **pt-BR** | Público interno e cooperativas brasileiras |
| RO-03 | Arquitetura em camadas: `RestController → Service → Repository → Entity` | Padrão do ecossistema |
| RO-04 | DTOs com sufixo `*TO`; nunca expor entidades | Padrão do ecossistema |
| RO-05 | Naming `*RestController`, `*Service`, `*Repository`, `*Enum`, `*Client` | Convenção do monorepo |
| RO-06 | Colunas SQL prefixadas: `SQ_` (PK/FK), `TX_` (texto), `IN_` (indicador/enum), `DT_` (data), `NR_` (número) | Padrão do banco corporativo |
| RO-07 | Liquibase em `src/main/resources/Liquibase/` (changesets `changes/sql_*.sql`) | Estrutura herdada |
| RO-08 | Cobertura de testes coletada por JaCoCo | Pipeline corporativo |
| RO-09 | Documentação técnica em `docs/` em pt-BR | Padrão de governança Sescoop |

## 2.3 Restrições regulatórias

| ID | Restrição | Origem |
|----|-----------|--------|
| RR-01 | **LGPD** (Lei 13.709/18) — tratamento adequado de dados pessoais (PF e contatos) | Lei nacional |
| RR-02 | Auditoria integral de alterações em entidades sensíveis (Envers) | LGPD + Lei 12.846/13 |
| RR-03 | Lei 5.764/71 — registro de cooperativas | Marco regulatório |
| RR-04 | Lei 12.690/12 — cooperativas de trabalho | Marco regulatório |
| RR-05 | Sigilo de dados de pessoa física (CPF, RG, telefone, endereço) | LGPD Art. 5º |
| RR-06 | Direito de eliminação e portabilidade de dados | LGPD Art. 18 |

> ⚠️ **Gap LGPD:** não foi identificado mascaramento ou criptografia em colunas de dados pessoais sensíveis em `PessoaFisica`. Ver [`compliance/lgpd.md`](../compliance/lgpd.md) e [`08-technical-debt.md`](08-technical-debt.md).

## 2.4 Restrições de convenção interna

- Configurações distribuídas via **Spring Cloud Config Server** — propriedades sensíveis (DB, RabbitMQ, hosts) não devem ser commitadas com valores produtivos.
- Imutabilidade de changesets Liquibase já promovidos a HMLG/PRD: **nunca editar** — apenas adicionar novos.
- Migrations destrutivas exigem `<preConditions>` e **changeset reverso** quando possível.

## 2.5 Restrições futuras (sinalizadas, não impostas)

- Adoção de Resilience4j para circuit breaker/retry — recomendada (ver débito técnico).
- Versionamento explícito de API (`/api/v1` está no path mas não há negociação por header).
