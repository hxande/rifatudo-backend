# 4. Blocos de Construção (C4 — Nível 2 e 3)

## 4.1 Visão de Container (Nível 2)

O `cadastro-registro-api` é um único container Spring Boot, organizado internamente em **módulos por domínio de negócio**.

```mermaid
flowchart TD
    subgraph CR[cadastro-registro-api]
        WEB[Camada Web<br/>125 RestControllers]
        SVC[Camada de Serviço<br/>132 Services]
        REPO[Camada de Persistência<br/>99 Repositories]
        ENT[(105 Entidades JPA<br/>Envers)]
        INT[Integrações HTTP<br/>9 Clients OAuth2]
        AMQP[Publishers/Listeners<br/>Spring AMQP + DLQ]
        CACHE[Spring Cache<br/>12 regiões]
        SCHED[Schedulers<br/>cron tempo-rotina]
    end

    WEB --> SVC
    SVC --> REPO
    REPO --> ENT
    SVC --> INT
    SVC --> AMQP
    SVC --> CACHE
    SCHED --> SVC
```

## 4.2 Camadas

| Camada | Responsabilidade | Volume |
|--------|------------------|--------|
| **Web** | Adaptadores HTTP, validação de payload, mapeamento `TO ↔ Entity` | 125 controllers |
| **Service** | Regras de negócio, transações, orquestração de clients HTTP, publicação AMQP, cache | 132 services |
| **Repository** | Acesso a dados, queries QueryDSL, especificações JPA | 99 repositories |
| **Entity** | Modelo de domínio JPA, anotações `@Audited` (Envers), views `Vw*` read-only | 105 entidades |
| **Integração** | Clients HTTP com `keycloakRestTemplate` + Publishers/Listeners AMQP | 9 clients |

## 4.3 Pacotes principais (módulos C4 — Nível 3)

Os 120 módulos sob `br.coop.somoscooperativismo.registro.api.v1.*` agrupam-se em famílias funcionais:

| Família | Pacotes representativos | Propósito |
|---------|------------------------|-----------|
| **Pessoa** | `pessoafisica`, `pessoajuridica`, `quadrosocial` | Entidades-base do ecossistema |
| **Cooperativa** | `cooperativa`, `cooperativaregistro`, `ramo`, `unidadeestadual`, `cooperativavinculacao`, `vinculosolicitacao` | Registro cooperativo e vínculos entre cooperativas |
| **Registro** | `cadastroregistro`, `solicitacao`, `aprovacao` | Ciclo de vida da solicitação |
| **Governança** | `governanca`, `mandato`, `mandatomembro` | Órgãos, cargos e mandatos |
| **Regularidade** | `regularidadecooperativa`, `certificado` | Emissão e validade de certificados |
| **Estatística** | `anuario`, `anuarionovo`, `censoanuario` | Coleta anual |
| **Operação** | `apontamentos`, `visitatecnica`, `arrecadacao` | Operação local das UFs |
| **Comunicação** | `email`, `eventoemail`, `events`, `dlq` | Notificações e eventos assíncronos (RabbitMQ) + Dead Letter Queue |
| **Integrações** | `client`, `serpro`, `governanca.event` | Consumo de APIs (HTTP) e publicação de eventos para o ecossistema |
| **Infraestrutura** | `config`, `security`, `cache`, `async` | Transversais |

## 4.4 Componentes transversais

### Segurança (`config.security`)

- `SecurityConfig` configura `SessionCreationPolicy.STATELESS` e `OAuth2 Resource Server` com JWT.
- Rotas públicas: `/swagger-ui/**`, `/actuator/**`, `/js/**`, `/public/**`, `index.html`.
- CORS configurado de forma permissiva.

> ⚠️ Não foram detectados `@PreAuthorize` explícitos nos controllers. A autorização efetiva é feita na camada de serviço (regras de UF, perfil) — risco de inconsistência. Ver [`08-technical-debt.md`](08-technical-debt.md).

### Cache (`config.cache`)

12 regiões nomeadas com TTLs distintos (1h, 4h, 8h):

`CACHE_TIPO_ENDERECO`, `CACHE_LOCALIZACAO`, `CACHE_MUNICIPIO`, `CACHE_RAMO`, `CACHE_TIPO_ORGAO_GOVERNANCA`, `CACHE_CARGOS_GOVERNANCA`, `CACHE_CADASTRO_UNIDADE_ESTADUAL`, `CACHE_PARAMETRO_QUADRO_SOCIAL`, `CACHE_SEGMENTOS`, `CACHE_SITUACAO_COOPERATIVA`, `CACHE_CADASTRO_REGISTRO`, `CACHE_CADASTRO_REGISTRO_LEITURA`.

Ver [`decisions/0004-cache-spring-12-regioes.md`](decisions/0004-cache-spring-12-regioes.md).

### Assincronia e mensageria (`config.async`, `config.RabbitMQConfig`, `events`, `dlq`)

- `ThreadPoolTaskExecutor` — `core=2`, `max=5`, `queue=500`.
- **Publishers** (`EmailPublisher`, `GovernancaPublisher`, `SolicitacaoMudancaEnderecoPublisher`, `CensoAnuarioPreenchimentoPublisher`) publicam eventos em RabbitMQ.
- **Listeners** (`EnvioEmailEventListener`, `SolicitacaoMudancaEndereco*Listener`, `CensoAnuarioPreenchimento*Listener`, `RevisaoAuditoriaListener`) consomem eventos de domínio.
- **Topologia RabbitMQ** (`RabbitMQConfig`): exchanges `email.exchange`, `cadastro-registro.governanca.exchange` e a DLX `cadastro-registro.governanca.desenvolvimento-humano.dlx`; fila `cadastro-registro.governanca.desenvolvimento-humano.queue` com **Dead Letter Queue** dedicada (`...desenvolvimento-humano.dlq`); routing keys `governanca.membro.atualizado` e `governanca.mandato.encerrado`.
- **DLQ (`api.v1.dlq`)**: `DlqConsumer` recebe mensagens mortas, `DlqMessage` (entidade) as persiste e `DlqProcessorService`/`DlqProcessingOrchestrator` permitem reprocessamento — capacidade **inexistente** na geração original (ver ADR 0005, agora complementado pelo [`0006`](decisions/0006-integracao-gdh-evento-rabbitmq-dlq.md)).

### Integrações HTTP

9 clients usando `keycloakRestTemplate`:

`ArrecadacaoClient`, `DesempenhoClient`, `UsuarioClient`, `LocalizacaoClient`, `PessoaClient`, `DocumentoClient`, `RelatorioClient`, `FileUploadClient`, `SerproClient`.

> ℹ️ `EmailClient` foi **removido** (refatorações `ARQ-183`/`ARQ-185`): o envio de e-mail agora é exclusivamente assíncrono via `EmailPublisher`/`EmailService`. `DesenvolvimentoHumanoClient` foi **removido**: a integração com o GDH passou a ser por **eventos RabbitMQ** (ver ADR 0006).

Hosts em propriedades: `cadastro_registro_leitura_service_host`, `pessoa_service_host`, `desempenho_service_host`, `gerencia_usuario_service_host`, `arrecadacao_service_host`, `relatorio_service_host`.

> ⚠️ Não há **Resilience4j** configurado. Não há retry, circuit breaker ou bulkhead nos clients HTTP. Para a integração de governança→GDH, a resiliência passou a ser provida pela **DLQ** do RabbitMQ. Ver débito técnico.

### Schedulers

- `tempo-rotina=0 0 10 * * *` — execução diária 10h.
- `tempo-rotina-suspensao=0 0 8 * * 1` — execução semanal segunda 8h.

### Persistência

- Datasource principal SQL Server.
- Liquibase com 246 changesets, master em `classpath:/Liquibase/changelog-master.xml`, `dbms="mssql"`, `endDelimiter="\nGO"`.
- Auditoria Envers em entidades-chave.
- Views `VwPessoaFisica`, `VwPessoaJuridica` (read-only).

## 4.5 Entidades-chave

| Entidade | Papel |
|----------|-------|
| `Pessoa` | Superclasse de PF/PJ |
| `PessoaFisica` | CPF, nome, dataNascimento, telefone, celular, email, rg, profissao, genero, escolaridade |
| `PessoaJuridica` | CNPJ, ramo, natureza jurídica |
| `Cooperativa` | Cooperativa registrada |
| `Governanca` | Órgãos de governança |
| `Mandato` / `MandatoMembro` | Mandatos e composição |
| `Endereco` / `Contato` | Dados de contato |
| `Certificado`, `CertificadoUnidadeEstadual`, `CertificadoRegularidade` | Emissões |
| `Anuario`, `CensoAnuario` | Coleta estatística |
| `Apontamento`, `Solicitacao`, `EventoEmail` | Operação e eventos |
| `CooperativaVinculacaoSolicitacao` | Solicitação de vínculo entre cooperativas (módulo `SOU-1148`) |
| `DlqMessage` | Persistência de mensagens da Dead Letter Queue para reprocessamento |

Todas auditadas com `@Audited` (Envers).

Ver detalhamento por módulo em [`../modules/`](../modules/) e diagramas em [`diagrams/containers.md`](diagrams/containers.md) e [`diagrams/components.md`](diagrams/components.md).
