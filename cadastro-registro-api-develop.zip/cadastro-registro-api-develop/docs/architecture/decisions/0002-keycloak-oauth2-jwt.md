# ADR 0002 — Keycloak como IdP e OAuth2 Resource Server com JWT

- **Status:** Aceito
- **Data:** 2026-05-15
- **Responsável:** Time `cadastro-registro` / Segurança Sescoop

## Finalidade

Centralizar a autenticação e a propagação de identidade no ecossistema Sescoop/OCB usando **Keycloak** como Identity Provider único (realm OCB) e **JWT** como mecanismo de transporte. O `cadastro-registro-api` atua como `OAuth2 Resource Server`, validando tokens emitidos pelo Keycloak, e propaga o token nas chamadas a outras APIs via `keycloakRestTemplate`.

## Dependências

- `spring-boot-starter-oauth2-resource-server`.
- Keycloak realm OCB (HMLG /TRT/ PRD).
- `keycloakRestTemplate` configurado para anexar `Authorization: Bearer <jwt>` automaticamente em chamadas para `cadastro-registro-leitura-api`, `gerencia-usuario-api`, `pessoa-api`, `desempenho-api`, `arrecadacao-api`, `relatorio-api`, `email-api`, `desenvolvimento-humano-controlador-api`, `localizacao-api`, `documento-api`, `file-upload-api`.
- `SecurityConfig` com `SessionCreationPolicy.STATELESS`.

## Detalhamento

- Rotas públicas explicitamente liberadas: `/swagger-ui/**`, `/actuator/**`, `/js/**`, `/public/**`, `index.html`.
- Demais rotas exigem JWT válido.
- CORS configurado de forma permissiva (revisar em produção).
- Sessão stateless — escala horizontal em OpenShift sem cookies de sessão.
- Comunicação entre serviços nunca usa `RestTemplate` simples — apenas `keycloakRestTemplate` para garantir propagação do token.

## Consequências

**Positivas:**
- IdP único reduz operação e auditoria de identidades.
- JWT permite operação stateless e cacheável.
- Mesma estratégia em todos os serviços do monorepo → previsibilidade.

**Negativas:**
- Indisponibilidade do Keycloak impacta todas as APIs.
- Aumenta latência por requisição (validação JWT) — mitigado com cache de chaves públicas.
- Falta de `@PreAuthorize` por método deixa autorização granular dispersa nos serviços — ver débito técnico [`../08-technical-debt.md`](../08-technical-debt.md) item 3.

## Impacto

| Eixo | Impacto |
|------|---------|
| Segurança | Positivo (padronização e centralização) |
| Disponibilidade | Negativo se Keycloak cair — necessidade de HA no Keycloak |
| Performance | Neutro (com cache de JWKS) |
| Compliance | Positivo (auditoria de acessos centralizada) |
| Operação | Mais simples (sem sessão server-side) |
| Risco | Médio — autorização não explícita em controllers |
