# ADR 0006 — Integração com o GDH por evento RabbitMQ com Dead Letter Queue

- **Status:** Aceito
- **Data:** 2026-06-19
- **Responsável:** Time `cadastro-registro` / Arquitetura Sescoop
- **Referências:** `SOU-1475` (checkbox "Diretoria GDH" e endpoint de integração), `ARQ-183`/`ARQ-185` (saída do envio de e-mail por HTTP)

## Finalidade

Substituir a integração **HTTP síncrona** com o GDH (desenvolvimento humano) — antes feita pelo `DesenvolvimentoHumanoClient` via `keycloakRestTemplate` — por uma integração **assíncrona baseada em eventos no RabbitMQ**, com **Dead Letter Queue (DLQ)** dedicada. O objetivo é desacoplar o registro de governança (atualização de membro de diretoria, encerramento de mandato) do consumo pelo GDH, garantindo que indisponibilidade do GDH não bloqueie nem falhe transações de governança do `cadastro-registro-api`.

Esta decisão complementa o [ADR 0005](0005-email-assincrono-rabbitmq.md), que apontava a ausência de retry/DLQ neste serviço como risco em aberto.

## Dependências

- `spring-boot-starter-amqp` (Spring AMQP) — já presente.
- RabbitMQ corporativo (`10.7.0.47`, vhost `rabbitmq-dev` em local).
- `RabbitMQConfig` — topologia de exchanges, filas, DLX/DLQ e bindings.
- `GovernancaPublisher` — publica os eventos de governança.
- Eventos: `GovernancaDiretoriaGdhEvent`, `GovernancaMandatoEncerradoDiretoriaGdhEvent`, TO `GovernancaBeneficiarioDiretoriaGdhTO`.
- Módulo `api.v1.dlq` — `DlqConsumer`, `DlqMessage` (entidade persistida), `DlqMessageRepository`, `DlqMessageMapper`, `DlqProcessorService`, `DlqProcessingOrchestrator`.

## Detalhamento

Topologia definida em `RabbitMQConfig`:

| Recurso | Nome |
|---------|------|
| Exchange de governança | `cadastro-registro.governanca.exchange` (DirectExchange) |
| Fila principal | `cadastro-registro.governanca.desenvolvimento-humano.queue` (durável) |
| DLX | `cadastro-registro.governanca.desenvolvimento-humano.dlx` |
| DLQ | `cadastro-registro.governanca.desenvolvimento-humano.dlq` (durável) |
| Routing key — membro atualizado | `governanca.membro.atualizado` |
| Routing key — mandato encerrado | `governanca.mandato.encerrado` |

Fluxo:

1. Ao atualizar um membro marcado como "Diretoria GDH" ou encerrar um mandato, o `GovernancaService`/`MandatoService` aciona o `GovernancaPublisher`.
2. O evento é publicado no exchange `cadastro-registro.governanca.exchange` com a routing key apropriada.
3. A fila `...desenvolvimento-humano.queue` recebe a mensagem; o GDH a consome.
4. Em falha de processamento, a mensagem é redirecionada para a DLX e cai na **DLQ**, onde é persistida (`DlqMessage`) e pode ser **reprocessada** (`DlqProcessorService`/`DlqProcessingOrchestrator`).

## Consequências

**Positivas:**
- Transações de governança não dependem da disponibilidade do GDH.
- Resiliência efetiva via DLQ: mensagens não são perdidas e podem ser reprocessadas.
- Reduz o acoplamento HTTP (um client a menos — `DesenvolvimentoHumanoClient` removido).
- Rastreabilidade das falhas (mensagens mortas persistidas em base).

**Negativas:**
- Eventual consistência: o GDH passa a refletir a governança com atraso (não é mais síncrono).
- Mais topologia RabbitMQ para operar e monitorar (fila + DLX + DLQ).
- Necessidade de rotina/observabilidade sobre o tamanho da DLQ e o reprocessamento.

## Impacto

| Eixo | Impacto |
|------|---------|
| Disponibilidade | Positivo (desacoplamento do GDH) |
| Performance percebida | Positivo (resposta imediata na governança) |
| Resiliência | Positivo (DLQ + reprocessamento — cobre lacuna do ADR 0005) |
| Operação | Aumenta — exige monitorar fila e DLQ |
| Custo | Marginal (infra RabbitMQ já existente) |
| Consistência | Eventual entre `cadastro-registro` e GDH |
| Compliance | Auditoria das alterações de governança mantida via Envers |
