# ADR 0004 — Cache Spring com 12 regiões nomeadas

- **Status:** Aceito
- **Data:** 2026-05-15
- **Responsável:** Time `cadastro-registro` / Arquitetura Sescoop

## Finalidade

Reduzir a carga em SQL Server para dados de **baixa volatilidade** (parametrização, tabelas de domínio, listagens estáticas) por meio de cache em memória local, controlando TTL por região.

## Dependências

- `spring-boot-starter-cache`.
- Provider em memória (Caffeine ou ConcurrentMapCacheManager — provider efetivo no `application.properties`).
- Anotações `@Cacheable`, `@CacheEvict` nos serviços que servem dados de domínio.

## Detalhamento

12 regiões nomeadas, com TTLs diferenciados:

| Região | Conteúdo | TTL típico |
|--------|----------|-----------|
| `CACHE_TIPO_ENDERECO` | Tipos de endereço | 4h–8h |
| `CACHE_LOCALIZACAO` | UFs e regiões | 8h |
| `CACHE_MUNICIPIO` | Municípios brasileiros | 8h |
| `CACHE_RAMO` | Ramos cooperativistas | 4h–8h |
| `CACHE_TIPO_ORGAO_GOVERNANCA` | Tipos de órgão de governança | 4h–8h |
| `CACHE_CARGOS_GOVERNANCA` | Cargos | 4h–8h |
| `CACHE_CADASTRO_UNIDADE_ESTADUAL` | Cadastro de UFs | 4h |
| `CACHE_PARAMETRO_QUADRO_SOCIAL` | Parâmetros do quadro social | 4h |
| `CACHE_SEGMENTOS` | Segmentos | 4h–8h |
| `CACHE_SITUACAO_COOPERATIVA` | Situações | 4h |
| `CACHE_CADASTRO_REGISTRO` | Cache transacional pontual | 1h |
| `CACHE_CADASTRO_REGISTRO_LEITURA` | Espelho de dados consultados | 1h |

TTLs concretos lidos das propriedades do Config Server.

## Consequências

**Positivas:**
- Redução significativa de queries em tabelas de domínio.
- Latência menor em endpoints de consulta a parâmetros.
- Isolamento por região permite ajuste fino de TTL.

**Negativas:**
- Cache **local** ao pod: réplicas múltiplas mantêm estados independentes.
- Invalidação distribuída inexistente — alteração em tabela de domínio só se propaga após TTL.
- Risco de **stale data** quando administradores ajustam parametrização.

## Impacto

| Eixo | Impacto |
|------|---------|
| Performance | Positivo (latência menor) |
| Consistência | Negativo (eventual consistency até TTL) |
| Memória do pod | Aumento controlado por TTL |
| Escalabilidade | Cache local não compartilhado entre réplicas |
| Operação | Necessário invalidar via reinício para mudanças urgentes |
| Risco | Médio — avaliar adoção de cache distribuído (Redis) se houver crescimento |
