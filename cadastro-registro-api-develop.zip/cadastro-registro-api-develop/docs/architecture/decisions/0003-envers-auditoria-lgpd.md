# ADR 0003 — Hibernate Envers para auditoria integral

- **Status:** Aceito
- **Data:** 2026-05-15
- **Responsável:** Time `cadastro-registro` / Compliance Sescoop

## Finalidade

Garantir **rastreabilidade integral** de mudanças em entidades sensíveis ao negócio e ao tratamento de dados pessoais (LGPD), por meio de auditoria automática via Hibernate Envers. Toda alteração deve ser recuperável, identificando autor, momento e estado anterior/posterior.

## Dependências

- `hibernate-envers` (alinhado a Hibernate 6.4.10).
- Coluna `REVINFO` controlando usuário e timestamp.
- Liquibase gerando tabelas `*_AUD` para entidades anotadas com `@Audited`.

## Detalhamento

- Entidades-chave anotadas com `@Audited`:
  - `Pessoa`, `PessoaFisica`, `PessoaJuridica`.
  - `Cooperativa`, `Governanca`, `Mandato`, `MandatoMembro`.
  - `Endereco`, `Contato`.
  - `Certificado`, `CertificadoUnidadeEstadual`, `CertificadoRegularidade`.
  - `Anuario`, `CensoAnuario`.
  - `Apontamento`, `Solicitacao`, `EventoEmail`.
- Views `VwPessoaFisica` e `VwPessoaJuridica` são read-only — não auditadas.
- Tabelas `*_AUD` armazenam o histórico; `REVINFO` armazena revisão e timestamp.
- Autor da revisão capturado a partir do `principal` do JWT.

## Consequências

**Positivas:**
- Atendimento direto ao requisito LGPD de rastreabilidade.
- Recuperação de estado anterior para investigações regulatórias.
- Suporte a relatórios de "quem alterou o quê" sem solução customizada.
- Resiliência a auditorias do Sescoop Nacional.

**Negativas:**
- Crescimento contínuo das tabelas `*_AUD`. Sem política de retenção, tendem a inflar o banco.
- Operações em massa duplicam custo de escrita.
- Não substitui criptografia em repouso de dados sensíveis (Envers grava também os valores antigos).

## Impacto

| Eixo | Impacto |
|------|---------|
| Compliance LGPD | Positivo (auditoria) — neutro para minimização |
| Storage | Negativo (crescimento `*_AUD`) — exigir plano de retenção |
| Performance | Levemente negativo em escritas em massa |
| Operação | Neutro (transparente para a aplicação) |
| Custo | Aumenta consumo de SQL Server |
| Risco | Baixo — risco maior é ausência de **política de expurgo** documentada |
