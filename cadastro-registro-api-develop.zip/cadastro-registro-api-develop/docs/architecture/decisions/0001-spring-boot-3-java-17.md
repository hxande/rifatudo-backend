# ADR 0001 — Adoção de Spring Boot 3.2.12 sobre Java 17

- **Status:** Aceito
- **Data:** 2026-05-15
- **Responsável:** Time `cadastro-registro` / Arquitetura Sescoop

## Finalidade

Padronizar o `cadastro-registro-api` no stack Java 17 + Spring Boot 3.2.12, alinhado ao ecossistema Sescoop/OCB (gestao-instrutor, gerencia-usuario, cadastro-registro-leitura-api, etc.) que adotaram Spring Boot 3.x. O objetivo é garantir compatibilidade entre serviços, suporte LTS de longo prazo e acesso aos recursos do Spring Framework 6.

## Dependências

- Java 17 LTS — disponível na imagem corporativa `jdk_maven:17.3.8.4`.
- Spring Cloud 2023.0.5 (compatível com Spring Boot 3.2.x).
- Migração Jakarta EE (pacotes `jakarta.*` em vez de `javax.*`) — concluída.
- Hibernate 6.4.10 (compatível com Spring Boot 3.2).
- Liquibase 4.x.

## Detalhamento

- `pom.xml` declara `spring-boot-starter-parent` 3.2.12.
- Pacote raiz: `br.coop.somoscooperativismo.registro.api.v1`.
- Bibliotecas reescritas para Jakarta: `jakarta.persistence`, `jakarta.validation`, `jakarta.servlet`.
- SpringDoc OpenAPI atualizado para 2.6.0 (compatível com Spring Boot 3).
- MapStruct 1.6.3 (suporte Java 17 / Jakarta).
- Surefire 3.2.5 com paralelismo de 15 threads para acelerar build.

## Consequências

**Positivas:**
- Alinhamento total com o monorepo Sescoop.
- Acesso a `Records`, `pattern matching`, `sealed classes`.
- Performance e segurança superiores ao Spring Boot 2.x.
- Suporte LTS de Spring Boot 3.2 até pelo menos fim de 2025 (comunidade) — atenção à atualização para 3.3+ no futuro.

**Negativas:**
- Imagem base maior que JRE 8.
- Esforço inicial de migração `javax → jakarta` (concluído).
- Necessidade de manter aderência com `gdh-controlador-api` que ainda usa Spring Boot 2.7.7.

## Impacto

| Eixo | Impacto |
|------|---------|
| Performance | Positivo (melhorias do Spring 6 / Hibernate 6) |
| Segurança | Positivo (atualizações ativas) |
| Operação | Sem mudança (mesmo OpenShift / imagem) |
| Custo | Neutro |
| Risco | Baixo — versão estável e amplamente adotada no monorepo |
| Compatibilidade | Atenção ao GDH (Spring Boot 2.7.7) — usar contratos REST estáveis |
