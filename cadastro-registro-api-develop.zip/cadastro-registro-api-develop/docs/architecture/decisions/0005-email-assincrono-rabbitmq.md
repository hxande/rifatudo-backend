# ADR 0005 — Envio de e-mail assíncrono via RabbitMQ

- **Status:** Aceito
- **Data:** 2026-05-15
- **Responsável:** Time `cadastro-registro` / Arquitetura Sescoop

## Finalidade

Desacoplar o `cadastro-registro-api` do `email-api` no envio de notificações por e-mail, garantindo que **falhas ou indisponibilidade** do componente de e-mail **não bloqueiem** transações de negócio do usuário (cadastro, aprovação, regularidade, etc.).

## Dependências

- `spring-boot-starter-amqp` (Spring AMQP).
- RabbitMQ corporativo (`10.7.0.47`, vhost `rabbitmq-dev` em local).
- Entidade `EventoEmail` (auditada por Envers).
- `EmailPublisher` — componente que publica o evento na fila apropriada.
- `email-api` como consumidor.

## Detalhamento

- Fluxo: serviço de negócio cria `EventoEmail` em transação, e ao final publica o evento na fila RabbitMQ.
- Spring AMQP empacota e envia a mensagem.
- `email-api` consome a fila, monta o template, despacha via SMTP.
- A persistência do `EventoEmail` antes do envio dá rastreabilidade — auditoria Envers cobre alterações de status.
- ThreadPool de tarefas assíncronas: `core=2`, `max=5`, `queue=500`.

## Consequências

**Positivas:**
- Resposta ao usuário não depende do tempo de envio do e-mail.
- Picos de notificação absorvidos pela fila.
- Indisponibilidade temporária do `email-api` não impacta a operação.
- Reprocessamento possível pelo consumidor.

**Negativas:**
- Mais um componente de infraestrutura (RabbitMQ) na dependência crítica.
- E-mails não são imediatos — pode levar segundos a minutos.
- Necessidade de monitorar tamanho de fila e DLQ (Dead Letter Queue).
- Sem retry/DLQ documentado neste serviço — depende do `email-api`.

## Impacto

| Eixo | Impacto |
|------|---------|
| Disponibilidade | Positivo (desacoplamento) |
| Performance percebida | Positivo (resposta imediata) |
| Operação | Aumenta — exige monitorar RabbitMQ |
| Custo | Marginal (infra já existente) |
| Risco | Médio — DLQ e retry **não documentados** neste serviço |
| Compliance | Auditoria do envio mantida via Envers em `EventoEmail` |
