# Glossário

Termos do domínio cooperativista, do ecossistema Sescoop/OCB e da arquitetura técnica usados ao longo desta documentação.

## Domínio cooperativista

| Termo | Definição |
|-------|-----------|
| **Cooperativa** | Sociedade de pessoas constituída para prestar serviços aos cooperados, regida pela Lei 5.764/71 |
| **Cooperado** | Pessoa associada a uma cooperativa |
| **Quadro Social** | Conjunto de cooperados associados a uma cooperativa |
| **Ramo** | Classificação da cooperativa por atividade (Agropecuário, Crédito, Saúde, Transporte, etc.) |
| **Segmento** | Subdivisão dentro de um ramo |
| **Governança** | Estrutura de órgãos (Assembleia, Conselho de Administração, Conselho Fiscal, Diretoria) |
| **Mandato** | Período em que membros da governança exercem cargo |
| **MandatoMembro** | Vínculo de uma pessoa física a um cargo em um mandato |
| **Registro Cooperativo** | Ato formal de inscrição da cooperativa no Sescoop |
| **Regularidade** | Status que indica cooperativa em conformidade (sem pendências) |
| **Suspensão** | Estado de uma cooperativa com pendências graves (cron `tempo-rotina-suspensao`) |
| **Anuário** | Coleta anual de dados estatísticos das cooperativas |
| **Censo** | Coleta amostral/total para o anuário |
| **Apontamento** | Registro de observação feito por UF sobre uma cooperativa |
| **Visita Técnica** | Acompanhamento presencial pelo Sescoop UF |
| **Arrecadação** | Contribuição da cooperativa ao Sescoop |
| **Solicitação** | Pedido formal de registro/alteração |
| **Aprovação** | Ato de aprovar uma solicitação |
| **Certificado de Regularidade** | Documento que atesta regularidade |

## Ecossistema Sescoop / OCB

| Termo | Definição |
|-------|-----------|
| **Sescoop** | Serviço Nacional de Aprendizagem do Cooperativismo |
| **OCB** | Organização das Cooperativas Brasileiras |
| **UF / Unidade Estadual** | Sescoop em cada estado |
| **Soucoop** | Plataforma onde reside `cadastro-registro-api` |
| **GDH** | Gestão de Desenvolvimento Humano (`desenvolvimento-humano-controlador-api`) |
| **Gestão Instrutor** | Domínio de instrutores e PJs prestadoras |
| **Gerência Usuário** | Domínio que controla usuários do sistema (Keycloak) |

## Técnico

| Termo | Definição |
|-------|-----------|
| **TO** | Transfer Object — DTO usado na fronteira do serviço |
| **Envers** | Componente Hibernate para auditoria automática (`@Audited`, tabelas `*_AUD`) |
| **Liquibase** | Ferramenta de migrations de schema (master em `Liquibase/changelog-master.xml`) |
| **QueryDSL** | DSL para consultas type-safe sobre JPA |
| **MapStruct** | Geração de mapeadores entre entidades e TOs |
| **ModelMapper** | Mapeamento dinâmico complementar |
| **`keycloakRestTemplate`** | `RestTemplate` que anexa o JWT corrente nas chamadas a outras APIs |
| **C4 Model** | Notação para diagramas em níveis (Contexto, Container, Componente, Código) |
| **ADR** | Architecture Decision Record |
| **arc42** | Template padrão de documentação arquitetural |
| **LGPD** | Lei Geral de Proteção de Dados (Lei 13.709/18) |
| **JWT** | JSON Web Token — formato do token OAuth2 emitido pelo Keycloak |
| **OAuth2 Resource Server** | API protegida que valida tokens emitidos por um IdP |
| **OpenShift** | Plataforma de containers usada pelo Sescoop |
| **Config Server** | Spring Cloud Config — distribui propriedades por profile |
| **ShedLock** | Biblioteca para evitar execução duplicada de cron em múltiplas réplicas |
| **Resilience4j** | Biblioteca para retry, circuit breaker, time limiter, bulkhead |

## Convenções SQL Sescoop

| Prefixo | Uso |
|---------|-----|
| `SQ_` | PK / FK (sequência) |
| `TX_` | Texto |
| `IN_` | Indicador / Enum |
| `DT_` | Data |
| `NR_` | Número |
| `TB_` | Tabela |
| `VW_` | View |
| `*_AUD` | Tabela de auditoria Envers |
