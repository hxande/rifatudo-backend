# Conformidade LGPD — cadastro-registro-api

## Contexto

O `cadastro-registro-api` armazena, processa e transmite **dados pessoais** e **dados pessoais sensíveis** definidos pela Lei 13.709/18 (LGPD). Esta página consolida o levantamento atual e os **gaps de conformidade** identificados em 2026-05-15 (revisado em 2026-06-19).

## Dados pessoais tratados

| Entidade | Atributo | Classificação LGPD |
|----------|----------|---------------------|
| `PessoaFisica` | `cpf` | Identificador direto |
| `PessoaFisica` | `nome` | Dado pessoal |
| `PessoaFisica` | `dataNascimento` | Dado pessoal |
| `PessoaFisica` | `rg` | Identificador direto |
| `PessoaFisica` | `telefone`, `celular` | Dado de contato |
| `PessoaFisica` | `email` | Dado de contato |
| `PessoaFisica` | `profissao` | Dado pessoal |
| `PessoaFisica` | `genero` | **Dado sensível** (Art. 5º, II) |
| `PessoaFisica` | `escolaridade` | Dado pessoal |
| `Endereco` | logradouro/CEP/nº | Dado pessoal |
| `Contato` | telefones, e-mails | Dado de contato |

## Bases legais (Art. 7º LGPD)

| Tratamento | Base provável |
|------------|---------------|
| Registro de cooperativas | **Cumprimento de obrigação legal** (Lei 5.764/71) |
| Registro de governança | **Cumprimento de obrigação legal** + execução de contrato |
| Comunicações operacionais | **Legítimo interesse** |
| Anuário/Censo | **Cumprimento de obrigação legal** (atribuição Sescoop/OCB) |

## Controles existentes

| Controle | Implementação |
|----------|---------------|
| Auditoria de alterações | Hibernate Envers (`@Audited`) em entidades-chave |
| Autenticação | OAuth2 / JWT via Keycloak |
| Comunicação entre serviços autenticada | `keycloakRestTemplate` |
| Sessão stateless | `SessionCreationPolicy.STATELESS` |
| Sigilo em trânsito | HTTPS (responsabilidade do OpenShift Route) |

## Gaps identificados

> ⚠️ **GAP 1 — Sem criptografia em repouso para CPF, RG, e dados sensíveis.**
> Recomenda-se `@Convert(converter = ...)` com `AttributeConverter` baseado em chave gerenciada (Vault ou OpenShift Secret).

> ⚠️ **GAP 2 — Sem mascaramento em respostas.**
> Endpoints podem expor CPF completo onde a UI exibe parcial. Avaliar `@JsonSerialize` com `MaskingSerializer`.

> ⚠️ **GAP 3 — Direito à eliminação (Art. 18) sem fluxo automatizado.**
> Não foi identificado endpoint de remoção/anonimização. Necessário definir processo (em geral anonimizar, preservando estatísticas do anuário/censo).

> ⚠️ **GAP 4 — Tabelas `*_AUD` retêm dados antigos indefinidamente.**
> Política de retenção de auditoria não documentada. Para LGPD, definir período mínimo (em geral 5 anos para auditoria fiscal/regulatória) e expurgo posterior.

> ⚠️ **GAP 5 — `genero` é dado sensível** (Art. 5º, II) e exige tratamento equiparado a saúde/origem racial. Avaliar minimização (campo realmente necessário?) e base legal específica.

> ⚠️ **GAP 6 — Logs textuais podem conter dados pessoais.**
> Padronizar logs estruturados sem PII e revisar serializers `toString()` das entidades.

## Ações recomendadas

1. Criar inventário formal de dados pessoais (RIPD — Relatório de Impacto à Proteção de Dados).
2. Implementar criptografia em repouso para CPF e RG.
3. Implementar mascaramento na serialização de TOs de saída.
4. Documentar e implementar fluxo de eliminação/anonimização.
5. Definir e automatizar política de retenção das tabelas `*_AUD`.
6. Reforçar política de logging sem PII.
7. Revisar coleta de `genero` (necessidade e base legal).

## Referências

- Lei 13.709/2018 (LGPD)
- Art. 5º (definições e dados sensíveis)
- Art. 7º (bases legais)
- Art. 18 (direitos do titular)
- ADR [`../architecture/decisions/0003-envers-auditoria-lgpd.md`](../architecture/decisions/0003-envers-auditoria-lgpd.md)
