# API REST — cadastro-registro-api

## Base

- **Contexto:** `/cadastro-registro-api`
- **Porta local:** `8082`
- **Documentação interativa:** `http://localhost:8082/cadastro-registro-api/swagger-ui.html`
- **Spec OpenAPI:** `http://localhost:8082/cadastro-registro-api/v3/api-docs`
- **Autenticação:** OAuth2 / JWT (Keycloak realm OCB) — header `Authorization: Bearer <token>`
- **Versionamento:** path `/api/v1/...`

## Famílias de endpoints

O serviço expõe 125 `RestController`s. As principais famílias são:

| Família | Prefixo típico | Função                                                           |
|---------|----------------|------------------------------------------------------------------|
| Pessoa Física | `/api/v1/pessoaFisica` | Pessoa Fisica                                                    |
| Pessoa Jurídica | `/api/v1/pessoaJuridica` | Pessoa Juridica                                                  |
| Cooperativa | `/api/v1/cooperativa` | CRUD e consultas                                                 |
| Vínculo entre cooperativas | `/api/v1/vinculacaocooperativa-solicitacao` | Solicitação/aprovação de vínculo entre cooperativas (`SOU-1148`) |
| Cadastro/Registro | `/api/v1/cadastroRegistro` | Vínculo cooperativa ↔ Sescoop                                    |
| Solicitação | `/api/v1/solicitacao` | Solicitação de registro                                          |
| Aprovação | `/api/v1/aprovacao` | Análise e aprovação                                              |
| Governança | `/api/v1/governanca` | Órgãos, cargos                                                   |
| Mandato | `/api/v1/mandato`, `/api/v1/mandatoMembro` | Composição de governança                                         |
| Certificado | `/api/v1/certificado`, `/api/v1/certificadoUnidadeEstadual` | Emissão e consulta                                               |
| Regularidade | `/api/v1/regularidadeCooperativa` | Status de regularidade                                           |
| Ramo | `/api/v1/ramo` | Ramos cooperativistas                                            |
| Quadro Social | `/api/v1/quadroSocial` | Quadro social das cooperativas                                   |
| Anuário | `/api/v1/anuario`, `/api/v1/anuarioNovo` | Coleta anual                                                     |
| Censo | `/api/v1/censoAnuario` | Coleta de censo                                                  |
| Apontamentos | `/api/v1/apontamentos` | Apontamentos da UF                                               |
| Visita Técnica | `/api/v1/visitaTecnica` | Visitas                                                          |
| Arrecadação | `/api/v1/arrecadacao` | Arrecadação cooperativa                                          |
| Unidade Estadual | `/api/v1/unidadeEstadual` | Sescoop UFs                                                      |
| E-mail | `/api/v1/eventoEmail` | Eventos publicados                                               |
| Endereço/Contato | `/api/v1/endereco`, `/api/v1/contato` | Subrecursos                                                      |

## Padrões aplicados

- Verbos HTTP convencionais (`GET`, `POST`, `PUT`, `DELETE`).
- Entrada/saída em `application/json`, exceto certificados (`application/pdf`).
- DTOs com sufixo `*TO`; entidades nunca expostas.
- Validação por `jakarta.validation` (`@Valid`, `@NotNull`, etc.).
- Tratamento de exceções centralizado (handler global retorna erro estruturado).

## Endpoints públicos (sem autenticação)

| Endpoint | Função |
|----------|--------|
| `/swagger-ui/**`, `/v3/api-docs` | Documentação |
| `/actuator/**` | Saúde, métricas, info |
| `/js/**`, `/public/**`, `index.html` | Estáticos auxiliares |

> ⚠️ `management.endpoints.web.exposure.include=*` expõe todos os endpoints do Actuator. Restringir em produção.

## Códigos de retorno

| Código | Uso |
|--------|-----|
| `200 OK` | Operação consulta/atualização |
| `201 Created` | Criação |
| `204 No Content` | Exclusão / atualização sem corpo |
| `400 Bad Request` | Validação |
| `401 Unauthorized` | JWT ausente/inválido |
| `403 Forbidden` | Regra de autorização (UF/perfil) |
| `404 Not Found` | Recurso inexistente |
| `409 Conflict` | Regra de duplicidade (CPF, CNPJ) |
| `500 Internal Server Error` | Falha inesperada / falha em integração |

## Observações sobre versionamento

> ⚠️ Não há negociação de versão via header `Accept`. Caso seja necessária uma `v2` coexistindo, deve ser planejada via novo path `/api/v2/...` ou adoção de header customizado.
