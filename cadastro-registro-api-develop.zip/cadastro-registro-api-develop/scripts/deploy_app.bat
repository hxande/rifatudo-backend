set NOME_APP=colaboradores

ECHO CRIA A BUILD DO CONTAINER
oc new-build --binary --name=%NOME_APP% -l app=%NOME_APP%

ECHO INICIA A BUILD COM O WORKDIR DA APP
oc start-build %NOME_APP% --from-dir=../ --follow

ECHO INICIA O CONTAINER
oc new-app %NOME_APP% -l app=%NOME_APP%

ECHO CRIA O SVC PARA ACESSO AOS PODS
oc create service clusterip %NOME_APP% --tcp=8080:8080

ECHO EXPOE O SVC PARA ACESSO EXTERNO
oc expose svc %NOME_APP%
