set NOME_APP=colaboradores

oc delete dc %NOME_APP%
oc delete bc %NOME_APP%
oc delete is %NOME_APP%
oc delete svc %NOME_APP%
oc delete route %NOME_APP%
