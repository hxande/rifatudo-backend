java -jar target\cadastro-registro-api-0.0.1-SNAPSHOT.jar ^
	--spring.application.name=cadastro-registro-api ^
	--spring.profiles.active=hmlg ^
	--spring.cloud.config.uri=http://ocb-config-server-hmlg.cloudapps.ocb.org.br:80/
	