package br.coop.somoscooperativismo.registro.api.v1.email.event;

import br.coop.somoscooperativismo.registro.api.v1.email.EnvioEmailService;
import br.coop.somoscooperativismo.registro.api.v1.email.util.EmailServiceEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EnvioEmailEventListener {

    private final EnvioEmailService envioEmailService;

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_VISITA_TECNICA.getId()")
    public void emailVisitaTecnica(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.emailVisitaTecnica(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_INICIO_PROCESSO_REGISTRO.getId()")
    public void emailIniciarProcessoRegistro(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.emailIniciarProcessoRegistro(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_FIM_VISITA_TECNICA.getId()")
    public void enviaEmailFimVisitaTecnica(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailFimVisitaTecnica(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_AJUSTES.getId()")
    public void enviaEmailAjustes(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailAjustes(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_FIM_CONFORMIDADE.getId()")
    public void enviaEmailFimConformidade(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailFimConformidade(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_REGISTRO_DEFERIDO.getId()")
    public void enviaEmailRegistroDeferido(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailRegistroDeferido(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_REGISTRO_INDEFERIDO.getId()")
    public void enviaEmailRegistroIndeferido(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailRegistroIndeferido(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_ARQUIVA_REGISTRO.getId()")
    public void enviaEmailRegistroArquivado(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailRegistroArquivado(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_DESARQUIVA_REGISTRO.getId()")
    public void enviaEmailRegistroDesarquivado(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailRegistroDesarquivado(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_FIM_AJUSTE.getId()")
    public void enviaEmailAjustesFinalizado(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailAjustesFinalizado(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_SUBMETER.getId()")
    public void enviaEmailSubmeter(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailSubmeter(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_MANUTENCAO_SUBMETER.getId()")
    public void enviaEmailManutencaoSubmeter(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailManutencaoSubmeter(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_FIM_AJUSTE_MANUTENCAO.getId()")
    public void enviaEmailManutencaoAprovar(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailManutencaoAprovar(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_SOLICITA_AJUSTE_MANUTENCAO.getId()")
    public void enviaEmailManutencaoAjustes(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailManutencaoAjustes(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_APONTA_IRREGULARIDADE_COOP.getId()")
    public void enviaEmailApontarIrregularidade(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailApontarIrregularidade(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_NOTIFICACAO_GESTOR_UE.getId()")
    public void enviaEmailNotificacoesGestorUE(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailNotificacoesGestorUE(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_APONTA_IRREGULARIDADE_UE.getId()")
    public void enviaEmailCooperativasIrregulares(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailCooperativasIrregulares(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_INATIVAR_COOP.getId()")
    public void enviaEmailInativarCoop(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailInativarCoop(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_AVISAR_UE_CONCLUIR_SOLICITACAO.getId()")
    public void enviaEmailAvisaUEConcluirSolicitacao(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailAvisaUEConcluirSolicitacao(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_ATUALIZAR_CADASTRO.getId()")
    public void enviaEmailAtualizarCadastro(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailAtualizarCadastro(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_SUBMISSAO_ANUARIO.getId()")
    public void enviarEmailUnidadeEstadualSubmissaoAnuario(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviarEmailUnidadeEstadualSubmissaoAnuario(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_DEFERIR_PEDIDO.getId()")
    public void enviaEmailDeferirPedido(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailDeferirPedido(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_ENVIAR_APONTAMENTOS.getId()")
    public void enviaEmailEnviarApontamentos(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailEnviarApontamentos(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_SOLICITAR_SUSPENSAO.getId()")
    public void enviaEmailSuspensaoCooperativa(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailSuspensaoCooperativa(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_MANTER_SITUACAO_COOPERATIVA.getId()")
    public void enviaEmailManterSuspensaoCooperativa(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailManterSuspensaoCooperativa(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_TORNAR_SITUACAO_REGULAR.getId()")
    public void enviaEmailTornarCooperativaRegular(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailTornarCooperativaRegular(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_TORNAR_SITUACAO_REGULAR_UN.getId()")
    public void enviaEmailTornarCooperativaRegularUn(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailTornarCooperativaRegularUn(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_SOLICITAR_CANCELAMENTO.getId()")
    public void enviaEmailSolicitaCancelamentoCooperativa(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailSolicitaCancelamentoCooperativa(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_MANTER_SITUACAO_CANCELAMENTO_COOPERATIVA.getId()")
    public void enviaEmailManterCancelamentoCooperativa(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailManterCancelamentoCooperativa(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_ACEITAR_SOLICITACAO_CANCELAMENTO.getId()")
    public void enviaEmailAceitarSolicitacaoCancelamento(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailAceitarSolicitacaoCancelamento(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_PRE_CADASTRO.getId()")
    public void enviaEmailIniciarProcessoRegistro(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailIniciarProcessoRegistro(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_COMUNICA_ORGAOS_SUSPENSAO.getId()")
    public void enviaEmailComunicarOrgaosSuspensao(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailComunicarOrgaosSuspensao(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_SOLICITACAO_FILIACAO_SUPERIOR.getId()")
    public void enviaEmailSolicitacaoFiliacaoSuperior(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailSolicitacaoFiliacaoSuperior(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_APROVACAO_FILIACAO_SUPERIOR.getId()")
    public void enviaEmailAprovacaoFiliacaoSuperior(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailAprovacaoFiliacaoSuperior(to);
    }

    @EventListener(condition = "#event.typeEvent eq T(br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum).EMAIL_REPROVACAO_FILIACAO_SUPERIOR.getId()")
    public void enviaEmailReprovacaoFiliacaoSuperior(EmailServiceEvent<Object> event){
        EmailEventTO to = (EmailEventTO) event.getModel();
        envioEmailService.enviaEmailReprovacaoFiliacaoSuperior(to);
    }

}
