package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RamoImportacaoTO {
    private Integer id;
    private String nome;
    private String detalhamento;
    private String imagem;
    private Boolean ativo;
    private Boolean excluido;
}
