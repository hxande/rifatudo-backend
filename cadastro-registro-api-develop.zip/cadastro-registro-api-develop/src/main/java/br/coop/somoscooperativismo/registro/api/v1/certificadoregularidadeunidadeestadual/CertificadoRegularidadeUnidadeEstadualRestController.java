package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual.entidade.CertificadoRegularidadeUnidadeEstadual;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/certificadoRegularidadeUnidadeEstadual")
@Tag(name = "CertificadoRegularidadeUnidadeEstadual")
public class CertificadoRegularidadeUnidadeEstadualRestController {

	
	public static final String LISTA_BACKGROUND_CERTIFICADO_NACIONAL_SALVO = "Certificados salvos com sucesso!";

	@Autowired
	private CertificadoRegularidadeUnidadeEstadualService certificadoRegularidadeUnidadeEstadualService;
	
	@Autowired
	MessagesService messages;
	
	private static final String CERTIFICADO_REGULARIDADE_GERADO_SUCESSO = "Certificado de regularidade gerado com sucesso.";

	
	@GetMapping()
	@Operation(summary="Lista certificados de regularidade das unidades estaduais", description="")
	public ResponseEntity<ServiceResponse<List<CertificadoRegularidadeUnidadeEstadual>>> listaCertificadoRegularidadeUnidadeEstadual() {
		return new ResponseEntity<>(new ServiceResponse<>(certificadoRegularidadeUnidadeEstadualService.findAll()),  HttpStatus.OK);
	}

	@GetMapping("/{uf}")
	@Operation(summary="Carregar o Certificado por UF", description="")
	public ResponseEntity<CertificadoRegularidadeUnidadeEstadual> buscarPorUf(@PathVariable String uf) {
		return new ResponseEntity<>(certificadoRegularidadeUnidadeEstadualService.buscaPorUf(uf), HttpStatus.OK);
	}


	@PutMapping
	@Operation(summary = "Salva as alterações no certificado de regularidade da unidade estadual")
	public ResponseEntity<ServiceResponse<List<CertificadoRegularidadeUnidadeEstadual>>> salvarBackGrounds(@RequestBody List<CertificadoRegularidadeUnidadeEstadual> listaCertificadoRegularidadeUnidadeEstadual) {
		certificadoRegularidadeUnidadeEstadualService.salvarTodas(listaCertificadoRegularidadeUnidadeEstadual);
		ServiceMessage message = new ServiceMessage(messages.get(LISTA_BACKGROUND_CERTIFICADO_NACIONAL_SALVO));		
		return ResponseEntity.ok(new ServiceResponse<>(listaCertificadoRegularidadeUnidadeEstadual, message));
	}
	

	@GetMapping("/pdf/{id}")
	@Operation(summary="Lista certificados de regularidade das unidades estaduais", description="")
	public ServiceResponse<byte[]> gerarCertificadoRegularidade(@PathVariable(name = "id") Integer idCooperativa) {
		return new ServiceResponse<>(
				certificadoRegularidadeUnidadeEstadualService.imprimirCertificado(idCooperativa),
				new ServiceMessage(messages.get(CERTIFICADO_REGULARIDADE_GERADO_SUCESSO)));
	}
	
	  @GetMapping("/pode-imprimir/{idCooperativa}")
	  @Operation(summary = "Pode imprimir certificado de regularidade")
	  public ResponseEntity<ServiceResponse<Boolean>> podeImprimirCertificadoRegularidade(@PathVariable Integer idCooperativa){
	       return new ResponseEntity<>(new ServiceResponse<Boolean>(certificadoRegularidadeUnidadeEstadualService.validaSePodeImprimir(idCooperativa)), HttpStatus.OK);
	  }
}
