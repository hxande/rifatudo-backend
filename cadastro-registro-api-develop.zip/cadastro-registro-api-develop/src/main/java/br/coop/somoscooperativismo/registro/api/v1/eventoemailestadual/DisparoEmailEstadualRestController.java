package br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to.DisparoEmailEstadualFiltroTO;
import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to.DisparoEmailEstadualTO;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/disparo-email-estadual")
@Tag(name = "Controle de envio de e-mail para cooperativas")
public class DisparoEmailEstadualRestController {

	@Autowired
	private DisparoEmailEstadualService disparoEmailEstadualService;
	
	@GetMapping("/listar")
	public ServiceResponse<Page<DisparoEmailEstadualTO>> obterListaDisparoEmailEstadual(DisparoEmailEstadualFiltroTO filtro, Pageable pageable){
		return new ServiceResponse<>(disparoEmailEstadualService.obterListaDisparoEmailEstadual(filtro,pageable));
	}
	
	@PutMapping("/alterar")
	public ServiceResponse<DisparoEmailEstadualTO> atualizarDisparoEmailEstadual(@RequestBody DisparoEmailEstadualTO disparoEmailEstadualTO){
		ServiceMessage message = new ServiceMessage("Disparo Email Estadual Alterado com Sucesso");
		return new ServiceResponse<>(disparoEmailEstadualService.atualizarDisparoEmailEstadual(disparoEmailEstadualTO), message);
	}
}
