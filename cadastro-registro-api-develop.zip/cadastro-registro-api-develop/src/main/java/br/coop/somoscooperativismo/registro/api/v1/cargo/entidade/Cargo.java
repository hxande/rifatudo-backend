package br.coop.somoscooperativismo.registro.api.v1.cargo.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;

@Entity
@Table(name = "GOVERNANCA_CARGO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Cargo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SQ_GOVERNANCA_CARGO")
	private Integer id;
	
	@Column(name="IN_REGISTRO_ATIVO", nullable=false)
	private Boolean ativo;

	@NotBlank
	@Size(max = 100)
	@Column(name="TX_GOVERNANCA_CARGO", nullable=false)
	private String nome;
	

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getId() {
		return id;
	}


	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}
	
	public Boolean getAtivo() {
		return ativo;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}


	
}
