package br.coop.somoscooperativismo.registro.api.v1.email;

import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DisparoEmailTO {

    private String numeroProcesso;
    private String corpoEmail;
    private String textoVariavelEmail;
    private String nomeArquivoHtml;
    private DisparoEmailEnum codigoDisparoEmail;
    private String valorVariavel;
    private String variavel;
    private String botaoContinuar;
    private String botaoData;
    private String botaoRecebeEmail;
    private String cooperativa;
    private String uf;

}
