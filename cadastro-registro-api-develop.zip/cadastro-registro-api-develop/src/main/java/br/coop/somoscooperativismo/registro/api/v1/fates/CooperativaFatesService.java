package br.coop.somoscooperativismo.registro.api.v1.fates;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacao;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
public class CooperativaFatesService {

    private final CooperativaFatesRepository cooperativaFatesRepository;
    private final CooperativaRepository cooperativaRepository;
    private final CooperativaFatesFinalidadeRepository cooperativaFatesFinalidadeRepository;

    /**
     * Busca o FATES por cooperativa e ano
     */
    @Transactional(readOnly = true)
    public CooperativaFatesTO buscarPorAnoCooperativa(Integer ano, Integer idCooperativa) {

        Optional<CooperativaFates> cooperativaFatesOpt = cooperativaFatesRepository
                .findByAnoAndCooperativaId(ano, idCooperativa);

        CooperativaFates cooperativaFates;
        if (cooperativaFatesOpt.isEmpty()) {
            cooperativaFates = new CooperativaFates();
            cooperativaFates.setFinalidades(new ArrayList<>());
        } else {
            cooperativaFates = cooperativaFatesOpt.get();
        }

        List<Integer> finalidadesIds = cooperativaFates.getFinalidades()
                .stream()
                .map(CooperativaFatesFinalidade::getId)
                .map(CooperativaFatesFinalidadeId::getFinalidadeId)
                .collect(Collectors.toList());

        return new CooperativaFatesTO(
                cooperativaFates.getValorFates(),
                finalidadesIds
        );
    }

    /**
     * Salva ou atualiza o FATES por cooperativa e ano
     */
    @Transactional
    public void salvarOuAtualizar(Integer ano, Integer idCooperativa, CooperativaFatesTO to) {

        Cooperativa cooperativa = cooperativaRepository.findById(idCooperativa)
                .orElseThrow(() -> new EntityNotFoundException("Cooperativa não encontrada"));

        CooperativaFates fates = cooperativaFatesRepository
                .findByAnoAndCooperativaId(ano, idCooperativa)
                .orElseGet(() -> {
                    CooperativaFates novo = new CooperativaFates();
                    novo.setCooperativa(cooperativa);
                    novo.setAno(ano);
                    return novo;
                });

        fates.setValorFates(to.getValorFates() != null ? to.getValorFates() : BigDecimal.ZERO);

        fates.getFinalidades().clear();

        if (to.getFinalidadesFates() != null) {
            to.getFinalidadesFates().forEach(idFinalidade -> {
                CooperativaFatesFinalidadeId id = new CooperativaFatesFinalidadeId();
                id.setCooperativaFatesId(fates.getId());
                id.setFinalidadeId(idFinalidade);
                CooperativaFatesFinalidade finalidade = new CooperativaFatesFinalidade();
                finalidade.setId(id);
                finalidade.setNome(FinalidadeFatesEnum.fromCodigo(idFinalidade).getDescricao());
                finalidade.setCooperativaFates(fates);
                fates.getFinalidades().add(finalidade);
            });
        }

        cooperativaFatesRepository.save(fates);
    }

    @Transactional(readOnly = true)
    public List<CooperativaFatesFinalidadeTO> listarFatesFinalidade() {
        return cooperativaFatesFinalidadeRepository.findAll()
                .stream()
                .map(this::toFatesFinalidadeTO)
                .toList();
    }

    private CooperativaFatesFinalidadeTO toFatesFinalidadeTO(CooperativaFatesFinalidade entidade) {
        return new CooperativaFatesFinalidadeTO(
                entidade.getId().getCooperativaFatesId(),
                entidade.getId().getFinalidadeId(),
                entidade.getNome()
        );
    }

    @Transactional(readOnly = true)
    public List<String> verificarPendencias(Integer cooperativaId, Integer ano) {
        return validarPendencias(cooperativaId, ano).getMensagens().stream()
                .map(ServiceMessage::getMessage)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public ValidacaoPrimeiroRegistroTO validarPendencias(Integer cooperativaId, Integer ano) {
        List<ServiceMessage> mensagens = new ArrayList<>();

        Optional<CooperativaFates> optFates = cooperativaFatesRepository.findByAnoAndCooperativaId(ano, cooperativaId);

        if (optFates.isEmpty()) {
            mensagens.add(new ServiceMessage(MessageType.WARN, "Destinação FATES"));
        } else {
            CooperativaFates fates = optFates.get();

            if (fates.getValorFates() == null) {
                mensagens.add(new ServiceMessage(MessageType.WARN,
                        "Qual foi o valor utilizado da conta de RATES/FATES em 2025? "));
            }

            if (fates.getFinalidades().isEmpty()) {
                mensagens.add(new ServiceMessage(MessageType.WARN,
                        "Indique as principais finalidades da destinação do valor utilizado da conta de RATES/FATES em 2025."));
            }
        }

        ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Detalhamento contábil");
        vpr.setMensagens(mensagens);
        vpr.setValidado(mensagens.stream().noneMatch(m ->
                MessageType.ERROR.equals(m.getType())));
        return vpr;
    }
}

