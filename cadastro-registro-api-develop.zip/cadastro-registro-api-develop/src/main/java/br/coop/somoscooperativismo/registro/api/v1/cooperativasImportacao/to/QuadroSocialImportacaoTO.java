package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QuadroSocialImportacaoTO {
    private Integer id;
    private Integer ano;
    private Integer cooperadosPF;
    private Integer cooperadosPJ;
    private Integer cooperadosTotal;
    private Integer empregadosHomens;
    private Integer empregadosMulheres;
    private Integer empregadosTotal;
    private Integer cooperadosHomens;
    private Integer cooperadosMulheres;
    private Integer cooperadosAtivos;
    private AprovacaoImportacaoTO aprovacao;
    private List<QuadroSocialParametroQuadroImportacaoTO> parametroQuadros;
}
