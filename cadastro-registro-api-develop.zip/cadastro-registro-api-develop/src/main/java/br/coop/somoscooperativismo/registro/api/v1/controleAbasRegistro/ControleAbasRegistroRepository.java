package br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro;

import br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro.entidade.ControleAbasRegistro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ControleAbasRegistroRepository extends JpaRepository<ControleAbasRegistro, Integer> {
}
