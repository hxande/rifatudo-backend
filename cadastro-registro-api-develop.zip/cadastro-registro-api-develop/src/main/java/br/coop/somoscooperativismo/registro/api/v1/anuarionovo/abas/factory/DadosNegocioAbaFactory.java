package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory;

import br.coop.somoscooperativismo.ocbcommonsapi.web.JsonUtil;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaCampoBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.SelectButtonOptionBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.SelectButtonValueBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.*;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.InputTypeEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.PaisTO;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacao;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoPais;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoPaisId;
import br.coop.somoscooperativismo.registro.api.v1.util.StringUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class DadosNegocioAbaFactory implements AbaFactory {

    private static final int INDICE_MODALIDADE_EXPORTACAO = 2;
    private static final int INDICE_PAISES_EXPORTACAO = 3;

    @Override
    public NomeAbaEnum getNomeAba() {
        return NomeAbaEnum.NEGOCIO;
    }

    @Override
    public List<AbaDataInterface> build(Object dados) {
        var dadosRecebidos = (DadosNegocioTO) dados;
        List<AbaDataInterface> lista = new ArrayList<>();
        lista.addAll(buildDadosNegocios(dadosRecebidos.getDadosEstrutura()));
        if (dadosRecebidos.getPaises() != null) {
            lista.add(buildDadosNegocioExportacao(dadosRecebidos.getDadosNegocioExportacao(), dadosRecebidos.getPaises(), dadosRecebidos.getDadosEstrutura(), dadosRecebidos.getAno()));
        }
        return lista;
    }

    public static AbaDataInterface buildDadosNegocioExportacao(NegocioExportacao negocioExportacao, Iterable<PaisTO> paises, List<EstruturaIntegracaoTO> integracoes, Integer ano) {
        AbaBuilder aba = new AbaBuilder("negocioExportacao", NomeQuadroEnum.NEGOCIO_EXPORTACAO.toString(), 1, null, "Negócio - Exportação")
                .subTitle(null)
                .info(null);

        List<AbaCampos> campos = new ArrayList<>();

        String realizaExportacao = null;
        String modalidade = null;
        if (negocioExportacao != null) {
            if (negocioExportacao.getExportacao() != null) {
                realizaExportacao = Boolean.TRUE.equals(negocioExportacao.getExportacao()) ? "1" : "0";
            }
            if (negocioExportacao.getModalidade() != null) {
                modalidade = negocioExportacao.getModalidade();
            }
        }

        campos.add(AbaCampoBuilder.selectButton("realizaExportacao", "realizaExportacao", 1, null, "A Cooperativa realiza exportação de produtos?")
                .value(new SelectButtonValueBuilder(
                        List.of(
                                new SelectButtonOptionBuilder("Sim", "1"),
                                new SelectButtonOptionBuilder("Não", "0")
                        ),
                        realizaExportacao
                ))
                .required(Boolean.TRUE)
                .build());

        campos.add(AbaCampoBuilder.selectButton("modalidadeExportacao", "modalidadeExportacao", INDICE_MODALIDADE_EXPORTACAO, null, "Qual(ais) modalidade(s) de exportação a Cooperativa realiza?")
                .value(new SelectButtonValueBuilder(
                        List.of(
                                new SelectButtonOptionBuilder("Direta", "DIRETA"),
                                new SelectButtonOptionBuilder("Indireta", "INDIRETA"),
                                new SelectButtonOptionBuilder("Ambas", "AMBAS")
                        ),
                        modalidade
                ))
                .required(Boolean.TRUE)
                .visible(negocioExportacao != null && negocioExportacao.getExportacao() != null && negocioExportacao.getExportacao())
                .build());

        List<SelectButtonOptionBuilder> listaPaises = new ArrayList<>();
        if (paises != null) {
            paises.forEach(p -> listaPaises.add(new SelectButtonOptionBuilder(p.getNome(), p.getId().toString())));
        }
        campos.add(
                AbaCampoBuilder.multCheckbox("paisesExportacao", "paisesExportacao", INDICE_PAISES_EXPORTACAO, null, "Para quais países a Cooperativa exportou em " + ano + "?", null)
                        .value(new SelectButtonValueBuilder(
                                listaPaises,
                                Optional.ofNullable(negocioExportacao)
                                        .map(NegocioExportacao::getPaises)
                                        .orElse(List.of())
                                        .stream()
                                        .map(NegocioExportacaoPais::getId)
                                        .filter(Objects::nonNull)
                                        .map(NegocioExportacaoPaisId::getPaisId)
                                        .filter(Objects::nonNull)
                                        .map(String::valueOf)
                                        .collect(Collectors.joining(", "))
                        ))
                        .required(false)
                        .visible(negocioExportacao != null && negocioExportacao.getExportacao() != null && negocioExportacao.getExportacao())
                        .build()
        );

        integracoes.stream()
                .filter(Objects::nonNull)
                .filter(integracao -> "Negócio - Exportação".equals(integracao.getNome()))
                .filter(integracao -> integracao.getGrupos() != null)
                .forEach(integracao -> {
                    integracao.getGrupos().forEach(grupo -> {
                        if (grupo.getParametros() != null) {
                            var camposEstrutura = buildCampos(grupo, "Negócio - Exportação");
                            camposEstrutura.forEach(c -> c.setVisible(negocioExportacao != null && negocioExportacao.getExportacao() != null && negocioExportacao.getExportacao()));
                            campos.addAll(camposEstrutura);
                        }
                    });
                });
        aba.addCampos(campos);
        return aba.build();
    }

    public static List<AbaDataInterface> buildDadosNegocios(List<EstruturaIntegracaoTO> integracoes) {
        List<AbaDataInterface> abas = new ArrayList<>();

        if (integracoes == null) {
            return abas;
        }

        for (EstruturaIntegracaoTO estrutura : integracoes) {
            if (estrutura == null || estrutura.getGrupos() == null || estrutura.getNome().equals("Negócio - Exportação")) {
                continue;
            }

            var idAba = (estrutura.getNome() != null) ? StringUtil.toCamelCase(estrutura.getNome()) + StringUtil.toCamelCase(estrutura.getNome()) : "Outros" + estrutura.getId();
            AbaBuilder aba = new AbaBuilder(idAba, estrutura.getNome() != null ? StringUtil.toCamelCase(estrutura.getNome()) : "Outros", estrutura.getId(), null, estrutura.getNome())
                    .subTitle(null)
                    .info(null);

            for (EstruturaGrupoTO grupo : estrutura.getGrupos()) {
                if (grupo.getParametros() != null) {
                    aba.addCampos(buildCampos(grupo, estrutura.getNome()));
                }
            }
            abas.add(aba.build());
        }

        return abas;
    }

    private static List<AbaCampos> buildCampos(EstruturaGrupoTO grupo, String integracaoNome) {
        List<AbaCampos> campos = new ArrayList<>();
        if (grupo.getNome() != null) {
            campos.add(
                    AbaCampoBuilder.divisor(StringUtil.toCamelCase(grupo.getNome()) + grupo.getId(),
                                    grupo.getNome(),
                                    grupo.getId(),
                                    null, "", grupo.getNome())
                            .value(null)
                            .parametroIntegracao(null)
                            .required(false)
                            .build()
            );
        }
        for (EstruturaIntegracaoParametroTO param : grupo.getParametros()) {
            var campo = buildCampo(param, integracaoNome);
            if (campo != null) {
                campos.add(campo);
            }
        }
        return campos;
    }

    private static AbaCampos buildCampo(EstruturaIntegracaoParametroTO param, String integracaoNome) {
        return switch (param.getTipoUnidade()) {
            case "NUMERO" -> buildCampoNumero(param, integracaoNome);
            case "TEXTO" -> buildCampoTexto(param, integracaoNome);
            case "BOOLEANO" -> buildCampoBooleano(param, integracaoNome);
            default -> null;
        };
    }

    private static AbaCampos buildCampoNumero(EstruturaIntegracaoParametroTO param, String integracaoNome) {
        return AbaCampoBuilder.input(StringUtil.toCamelCase(param.getNomeParametro()), integracaoNome, param.getIdParametro(), null, param.getNomeParametro())
                .inputType(param.isValoresNegativos() ? InputTypeEnum.TEXT.getType() : InputTypeEnum.NUMBER.getType())
                .value(formatarCampoNumerico(param))
                .required(param.isCampoObrigatorio())
                .isAceitaNegativo(param.isValoresNegativos())
                .mask((param.getQuantidadeCasasUnidade() != null && param.getQuantidadeCasasUnidade() > 0 ? (param.isValoresNegativos() ? "currencyNegative" : "currency") : null), param.getSiglaUnidade())
                .hasMask((param.getQuantidadeCasasUnidade() != null && param.getQuantidadeCasasUnidade() > 0))
                .subTitle(param.getDescricaoParametro())
                .parametroIntegracao(JsonUtil.toJson(param))
                .decimal(param.getQuantidadeCasasUnidade())
                .build();
    }

    private static String formatarCampoNumerico(EstruturaIntegracaoParametroTO param) {
        if (param.getValor() != null && (param.getQuantidadeCasasUnidade() == null || param.getQuantidadeCasasUnidade() == 0)) {
            return param.getValor().replace(".", "");
        } else {
            return param.getValor();
        }
    }

    private static AbaCampos buildCampoTexto(EstruturaIntegracaoParametroTO param, String integracaoNome) {
        return AbaCampoBuilder.input(StringUtil.toCamelCase(param.getNomeParametro()), integracaoNome, param.getIdParametro(), null, param.getNomeParametro())
                .inputType(InputTypeEnum.TEXT.getType())
                .value(param.getValor())
                .required(param.isCampoObrigatorio())
                .subTitle(param.getDescricaoParametro())
                .parametroIntegracao(JsonUtil.toJson(param))
                .build();
    }

    private static AbaCampos buildCampoBooleano(EstruturaIntegracaoParametroTO param, String integracaoNome) {
        String value = null;

        if (param.getValor() != null && (param.getValor().equals("1.00") || param.getValor().equals("1,00"))) {
            value = "1";
        }

        if (param.getValor() != null && (param.getValor().equals("0.00") || param.getValor().equals("0,00"))) {
            value = "0";
        }

        return AbaCampoBuilder.selectButton("parametroSelectOption" + param.getIdParametro(), integracaoNome, param.getIdParametro(), null, param.getNomeParametro())
                .value(new SelectButtonValueBuilder(
                        List.of(
                                new SelectButtonOptionBuilder("Sim", "1"),
                                new SelectButtonOptionBuilder("Não", "0")
                        ),
                        value
                ))
                .required(param.isCampoObrigatorio())
                .parametroIntegracao(JsonUtil.toJson(param))
                .subTitle(param.getDescricaoParametro())
                .build();
    }
}
