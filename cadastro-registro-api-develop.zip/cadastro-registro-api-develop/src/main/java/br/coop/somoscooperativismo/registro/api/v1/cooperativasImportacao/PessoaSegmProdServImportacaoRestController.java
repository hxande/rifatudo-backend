package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.entidade.PessoaSegmProdServ;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.PessoaSegmProdServService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/pessoas-segms-prods-servs")
public class PessoaSegmProdServImportacaoRestController {

    private final PessoaSegmProdServService pessoaSegmProdServService;

    @GetMapping("/pessoa-juridica/{idPessoaJuridica}")
    public ResponseEntity<List<PessoaSegmProdServ>> getByPessoaJuridica(@PathVariable Integer idPessoaJuridica) {
        return ResponseEntity.ok(pessoaSegmProdServService.listaPorPessoa(idPessoaJuridica));
    }
}
