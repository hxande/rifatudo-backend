package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas;

import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.entidade.PessoaSegmProdServ;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class RequestPortfolioTO implements Serializable {

    private Integer situacao;
    private List<PessoaSegmProdServ> fields;

}
