package br.coop.somoscooperativismo.registro.api.v1.anuario;

import br.coop.somoscooperativismo.registro.api.v1.anuario.entidade.Anuario;
import java.net.URI;
import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioFieldsTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosSociaisAbaAdapter;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.anuario.filtros.AnuarioFiltroTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;

@RestController
@RequestMapping("/api/v1/anuario")
@Tag(name = "Anuário")
public class AnuarioRestController {

	public static final String ANUARIO_CRIADO = "anuario.criado";

	public static final String MEDIA_TYPE_EXCEL = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String ATTACHMENT_EXCEL = "attachment; filename=Relatório.xlsx";
	public static final String CACHE_CTRL_PARAM = "no-cache, no-store, must-revalidate";
	public static final String NO_CACHE = "no-cache";

	private static final int ID_COOPERATIVA_PADRAO = 715;
	private static final int ANO_PADRAO = 2024;

	@Autowired
	AnuarioService anuarioService;

	@Autowired
	private CooperativaService cooperativaService;

	@Autowired
	MessagesService messages;

    @Autowired
    DadosSociaisAbaAdapter dadosSociaisAbaAdapter;

	@Operation(summary = "Detalha a última Anuario pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{idCooperativa}")
	public ResponseEntity<ServiceResponse<Anuario>> getByCooperativa(@PathVariable Integer idCooperativa) {
		return new ResponseEntity<>(new ServiceResponse<>(anuarioService.getByCooperativa(idCooperativa)),
				HttpStatus.OK);
	}

	@Operation(summary = "Retorna o Anuário da Cooperativa no ano indicado.", description = "ID da cCooperativa e ano devem ser informados")
	@GetMapping("/{idCooperativa}/{ano}")
	public ResponseEntity<ServiceResponse<Anuario>> getByCooperativaAno(@PathVariable Integer idCooperativa,
			@PathVariable Integer ano) {
		return new ResponseEntity<>(new ServiceResponse<>(anuarioService.getByCooperativaAno(idCooperativa, ano)),
				HttpStatus.OK);
	}

	@Operation(summary = "Retorna a lista de Anuários da Cooperativa indicada.", description = "ID da cCooperativa e ano devem ser informados")
	@GetMapping("/list/{idCooperativa}")
	public ResponseEntity<ServiceResponse<List<Anuario>>> getList(@PathVariable Integer idCooperativa) {
		return new ResponseEntity<ServiceResponse<List<Anuario>>>(
				new ServiceResponse<>(anuarioService.getListByCooperativa(idCooperativa)), HttpStatus.OK);
	}

	@Operation(summary = "Retorna a lista de Anuários de acordo com os filtros indicados.", description = "O ano deve ser informado")
	@GetMapping("/filtrarPaginado/{ano}")
	public ServiceResponse<Page<AnuarioTO>> filtrarPaginado(AnuarioFiltroTO anuarioFiltroTO, Pageable pageable) {
		Page<AnuarioTO> retorno = anuarioService.filtrarPaginado(anuarioFiltroTO, pageable);
		return new ServiceResponse<>(retorno);
	}

	@GetMapping("/filtrarListagemExcel")
	@Operation(summary = "Retorna Excel com base nos filtros de anuarios de cooperativas ")
	public ResponseEntity<Resource> filtrarListagemExcel(AnuarioFiltroTO anuarioFiltroTO) {
		cooperativaService.podeExportarDadosListagemCooperativaRegistradas();
		byte[] dados = anuarioService.filtrarAnuarioExcel(anuarioFiltroTO);

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_EXCEL);
		header.add(HttpHeaders.CACHE_CONTROL, CACHE_CTRL_PARAM);
		header.add(HttpHeaders.PRAGMA, NO_CACHE);
		header.add(HttpHeaders.EXPIRES, "0");

		return ResponseEntity.ok().headers(header).contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
				.contentType(MediaType.parseMediaType(MEDIA_TYPE_EXCEL))
				.body(!ArrayUtils.isEmpty(dados) ? new ByteArrayResource(dados) : null);
	}

	@PostMapping
	@Operation(summary = "Cria um anuario")
	public ResponseEntity<ServiceResponse<Anuario>> createC(@RequestBody @Valid Anuario anuario) {
		anuario = anuarioService.create(anuario);
		HttpHeaders headers = new HttpHeaders();
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{idCooperativa}")
				.buildAndExpand(anuario.getCooperativa().getId()).toUri();
		headers.setLocation(location);

		ServiceMessage message = new ServiceMessage(messages.get(ANUARIO_CRIADO));
		return ResponseEntity.ok(new ServiceResponse<>(anuario, message));
	}

    @PostMapping("/processar-dados-dinamicos")
    public ResponseEntity<ServiceResponse<Void>> processarDadosDinamicos(@RequestBody RequestAnuarioTO request, @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit) {

        dadosSociaisAbaAdapter.execute(ID_COOPERATIVA_PADRAO, ANO_PADRAO, request, isSubmit);

        return ResponseEntity.ok(new ServiceResponse<>(new ServiceMessage("Processado com sucesso")));
    }

}
