package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
public class NotificaEtapasScheduleService {
    
    @Autowired
    private CooperativaService cooperativaService;


    @Scheduled(cron = "${cron_envio_email_aviso: 0 */10 * * * *}")
    public void avisaSolicitacaoPodeSerConcluida(){

        log.info("Iniciando rotina de enviar e-mails depois de 15 dias");

        cooperativaService.avisaUEConcluirSolicitacao();

        log.info("Encerrando rotina de enviar e-mails depois de 15 dias");


    }

}
