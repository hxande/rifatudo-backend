package br.coop.somoscooperativismo.registro.api.v1.email.entidade;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "REGISTRO_EMAIL")
@Getter
@Setter
public class RegistroEmail implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;


    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_REGISTRO_EMAIL")
	private Integer id;

    @Column(name="TX_PARA", nullable = false)
    private String para;

    @Column(name = "DT_ENVIO", nullable = false)
    private Date dtEnvio;

    @Column(name = "TX_CORPO",  columnDefinition = "TEXT", nullable = false)
    private String corpo;
    
}
