package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.segmento.entidade.Segmento;
import br.coop.somoscooperativismo.registro.api.v1.segmento.SegmentoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/segmentos")
public class SegmentoImportacaoRestController {

    private final SegmentoService segmentoService;

    @GetMapping("/{id}")
    public ResponseEntity<Segmento> getSegmento(@PathVariable Integer id) {
        return ResponseEntity.ok(segmentoService.getSegmento(id));
    }

    @GetMapping("/ramo/{id}/ativo")
    public ResponseEntity<List<Segmento>> getSegmentosByRamoAtivos(@PathVariable Integer id) {
        return ResponseEntity.ok(segmentoService.getSegmentosPorRamoAtivos(id));
    }

    @GetMapping("/ramo/{id}")
    public ResponseEntity<List<Segmento>> getSegmentosByRamo(@PathVariable Integer id) {
        return ResponseEntity.ok(segmentoService.getSegmentosPorRamo(id));
    }

    @GetMapping("/ramos-ativos")
    public ResponseEntity<List<Segmento>> getAllByRamoAtivoAndExcluidoFalse() {
        return ResponseEntity.ok(segmentoService.getAllByRamoAtivoTrueAndRamoExcluidoFalse());
    }

    @GetMapping("/page")
    public ResponseEntity<Page<Segmento>> getAll(@RequestParam(required = false) Integer id,
                                                 @RequestParam(required = false) String nome,
                                                 @RequestParam(name = "ramo.id", required = false) Integer ramoId,
                                                 @RequestParam(name = "ramo.nome", required = false) String ramoNome,
                                                 @PageableDefault(sort = {"ramo.id", "id"}, direction = Sort.Direction.ASC) Pageable pageable) {
        return ResponseEntity.ok(segmentoService.getAll(id, nome, ramoId, ramoNome, pageable));
    }


}
