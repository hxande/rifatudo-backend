package br.coop.somoscooperativismo.registro;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import java.util.List;
import java.util.stream.Collectors;
import org.hibernate.exception.ConstraintViolationException;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class CadastroRegistroRestControllerAdvice {

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ServiceResponse<Void> handleConstraintViolation(ConstraintViolationException ex) {
        String sqlExceptionMessage = ex.getSQLException().getMessage().toLowerCase();

        ServiceMessage messages;
        if (sqlExceptionMessage.contains("violation of unique key constraint")) {
            messages = new ServiceMessage(MessageType.ERROR, "Já existe registro com esses dados!");
        } else {
            messages = new ServiceMessage(MessageType.ERROR, ex.getCause().getMessage());
        }
        return new ServiceResponse<>(null, messages);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ServiceResponse<Void> handlerMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        BindingResult bindingResult = exception.getBindingResult();
        List<ServiceMessage> messages = bindingResult.getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .map(errorMessage -> new ServiceMessage(MessageType.ERROR, errorMessage))
                .collect(Collectors.toList());
        return new ServiceResponse<>(null, messages);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex,
            WebRequest request) {

        String mensagem = "Erro ao ler o corpo da requisição: " + ex.getMostSpecificCause().getMessage();

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(new ServiceResponse<>(new ServiceMessage(mensagem)));
    }

    @ExceptionHandler(IllegalStateException.class)
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            IllegalStateException ex,
            WebRequest request) {

        String mensagem = "Erro ao ler o corpo da requisição: " + ex.getCause().getMessage();

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(new ServiceResponse<>(new ServiceMessage(mensagem)));
    }

}
