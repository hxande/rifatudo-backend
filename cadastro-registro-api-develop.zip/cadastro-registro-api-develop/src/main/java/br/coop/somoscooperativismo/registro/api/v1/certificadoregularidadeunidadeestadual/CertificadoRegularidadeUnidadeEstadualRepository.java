package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual;

import br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual.entidade.CertificadoRegularidadeUnidadeEstadual;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificadoRegularidadeUnidadeEstadualRepository extends JpaRepository<CertificadoRegularidadeUnidadeEstadual, Integer> {
	Optional<CertificadoRegularidadeUnidadeEstadual> findByUf(String uf);
}
