package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImportacaoAnuarioResultadoTO {
    private boolean submetido;
    private Integer situacaoDadosSociais;
    private Integer situacaoPortfolio;
    private Integer situacaoContabilTributario;
    private Integer situacaoNegocio;
    private Integer situacaoDadosComplementares;
    private String motivoNaoSubmissao;
}
