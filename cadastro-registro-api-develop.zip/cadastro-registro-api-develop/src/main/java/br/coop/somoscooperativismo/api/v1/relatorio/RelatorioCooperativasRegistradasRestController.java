package br.coop.somoscooperativismo.api.v1.relatorio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/relatorio")
@Tag(name = "RelatorioUtil Cooperativas Registradas")
public class RelatorioCooperativasRegistradasRestController {
	
	public static final String RELATORIO_GERADO_SUCESSO = "relatorio.gerado.sucesso";
	
	@Autowired
	private RelatorioCoopertativasRegistradasService relatorioCooperativasRegistradasService;
	
	@Autowired
    private MessagesService messages;
		
	@Operation(summary = "Gera relatório estadual de cooperativas registradas pela UF", description = "Uma UF válida deve ser informado")
	@GetMapping(value = "/pdf/ue/{uf}")
	public ServiceResponse<byte[]> imprimirRelatorioCooperativaRegistradaUE(@PathVariable String uf) {
		return new ServiceResponse<>(
				relatorioCooperativasRegistradasService.imprimirRelatorioCooperativasRegistradasUE(uf),
				new ServiceMessage(messages.get(RELATORIO_GERADO_SUCESSO)));

	}
	@Operation(summary = "Gera relatório nacional de cooperativas registradas")
	@GetMapping(value = "/pdf/un")
	public ServiceResponse<byte[]> imprimirRelatorioCooperativaRegistradaUN() {
		return new ServiceResponse<>(
				relatorioCooperativasRegistradasService.imprimirRelatorioCooperativasRegistradasUN(),
				new ServiceMessage(messages.get(RELATORIO_GERADO_SUCESSO)));

	}
}
