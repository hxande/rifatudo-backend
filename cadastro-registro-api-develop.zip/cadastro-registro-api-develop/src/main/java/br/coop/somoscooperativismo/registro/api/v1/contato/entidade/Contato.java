package br.coop.somoscooperativismo.registro.api.v1.contato.entidade;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade.AreaContato;
import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.pessoa.entidade.Pessoa;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "PESSOA_CONTATO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Contato {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_PESSOA_CONTATO")
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SQ_PESSOA")
	@Fetch(FetchMode.JOIN)
	@NotNull
	private Pessoa pessoa;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SQ_AREA_CONTATO")
	@Fetch(FetchMode.JOIN)
	private AreaContato areaContato;

	@Column(name = "TX_NOME_RESPONSAVEL", nullable = true)
	@Size(max = 255)
	private String nomeResponsavel;

	@Column(name = "TX_TELEFONE", nullable = true)
	@Size(max = 14)
	private String telefone;

	@Column(name = "TX_CELULAR", nullable = true)
	@Size(max = 14)
	private String celular;

	@Column(name = "TX_EMAIL", nullable = true)
	@Size(max = 255)
	private String email;

	@Column(name = "TX_SITE", nullable = true)
	@Size(max = 500)
	private String site;

	@Column(name = "TX_CARGO", length = 30)
	@Size(max = 30)
	private String cargo;

	@Column(name = "DATA_CRIACAO")
	private LocalDateTime dataAtualizacao;

	@Column(name = "USUARIO_ATUALIZACAO")
	private String usuarioAtualizacao;
}
