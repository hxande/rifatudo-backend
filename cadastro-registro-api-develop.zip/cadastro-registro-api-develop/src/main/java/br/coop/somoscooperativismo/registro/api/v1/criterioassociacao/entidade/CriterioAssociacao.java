package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;
import lombok.Getter;
import lombok.Setter;

import org.hibernate.envers.Audited;
import org.springframework.lang.Nullable;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@Table(name  = "CRITERIO_ASSOCIACAO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class CriterioAssociacao {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_CRITERIO_ASSOCIACAO")
    private Integer id;

    @OneToOne
    @JoinColumn(name = "SQ_RAMO")
    private Ramo ramo;

    @Column(name = "TX_CRITERIO_ASSOCIACAO")
    @Nullable
    private String descricao;

    @Column(name = "IN_ATIVO")
    private Boolean ativo;

    @Column(name = "IN_EXCLUIDO")
    private Boolean excluido;
}
