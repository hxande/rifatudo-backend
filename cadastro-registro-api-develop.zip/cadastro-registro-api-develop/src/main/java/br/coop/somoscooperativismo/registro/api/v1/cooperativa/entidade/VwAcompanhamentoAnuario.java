package br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "VW_ACOMPANHAMENTO_CENSO_ANUARIO")
public class VwAcompanhamentoAnuario {
    @Id
    @Column(name = "SQ_PESSOA")
    private Integer id;

    @Column(name = "TX_CNPJ")
    private String cnpj;

    @Column(name = "TX_RAZAO_SOCIAL")
    private String razaoSocial;

    @Column(name = "TX_NOME_FANTASIA")
    private String nomeFantasia;

    @Column(name = "TX_NUMERO_REGISTRO_OCB")
    private String numeroRegistroOCB;

    @Column(name = "TX_NIRE")
    private String nire;

    @Column(name = "ANO_REFERENCIA_DADOS")
    private Integer anoReferencia;

    @Column(name = "CICLO_ULTIMA_APROVACAO")
    private Integer cicloUltimaAprovacao;

    @Column(name = "DT_ULTIMA_APROVACAO")
    private Date dataUltimaAprovacao;

    @Column(name = "NR_COOPERADOS_TOTAL")
    private Integer cooperadosTotal;

    @Column(name = "NR_EMPREGADOS_TOTAL")
    private Integer empregadosTotal;

    @Column(name = "ESTATUTO_SOCIAL_VIGENTE_COOPERATIVA")
    private String estatutoSocialVigente;

    @Column(name = "DEMONSTRACOES_FINANCEIRAS_EXERCICIO_FINDO")
    private String demonstracoesFinanceirasExercicioFindo;

    @Column(name = "ATA_ASSEMBLEIA_GERAL_ORDINARIA_ANUAL")
    private String ataAssembleiaGeralOrdinariaAnual;

    @Column(name = "ATA_ASSEMBLEIA_GERAL_ATUAL_DIRETORIA")
    private String ataAssembleiaGeralAtualDiretoria;

    @Column(name = "CONSELHO_ADMINISTRACAO")
    private String conselhoAdministracao;

    @Column(name = "CONSELHO_FISCAL")
    private String conselhoFiscal;

    @Column(name = "DIRETORIA_CONTRATADA")
    private String diretoriaContratada;

    @Column(name = "POSSUI_USUARIO")
    private String possuiUsuario;

    @Column(name = "ANUARIO_ATUALIZADO")
    private String anuarioAtualizado;
}
