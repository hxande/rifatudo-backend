package br.coop.somoscooperativismo.registro.api.v1.apontamentos;

import br.coop.somoscooperativismo.registro.api.v1.apontamentos.entidade.Apontamento;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ApontamentoRepository extends JpaRepository<Apontamento, Integer> {

    Set<Apontamento> findByCooperativaId(Integer idParecer);

}
