package br.coop.somoscooperativismo.registro.api.v1.complementoanuario;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ComplementoAnuarioService {

    ComplementoAnuarioTO create(ComplementoAnuarioTO complementoAnuarioTO);

    Optional<ComplementoAnuarioTO> update(Integer id, ComplementoAnuarioTO complementoAnuarioTO);

    Optional<ComplementoAnuarioTO> findById(Integer id);

    Page<ComplementoAnuarioTO> findAll(String uf, String texto, String url, Pageable pageable);

    Optional<ComplementoAnuarioTO> deleteById(Integer id);

    Optional<ComplementoAnuarioTO> findByUf(String uf);

    boolean existsByUf(String uf);
}
