package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class AbaFactoryRegistry {

    private final Map<NomeAbaEnum, AbaFactory> factories;

    public AbaFactoryRegistry(List<AbaFactory> factories) {
        this.factories = factories
                .stream()
                .collect(Collectors.toMap(AbaFactory::getNomeAba, factory -> factory));
    }

    public AbaFactory getFactory(NomeAbaEnum nomeAba) {
        return factories.get(nomeAba);
    }

    public Collection<AbaFactory> getAllFactories() {
        return factories.values();
    }
}
