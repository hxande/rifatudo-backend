package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacaoCooperativa;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CriterioAssociacaoCooperativaRepository extends JpaRepository<CriterioAssociacaoCooperativa, Integer> {

    List<CriterioAssociacaoCooperativa> findByCooperativaId(Integer sqCooperativa);
    
    List<CriterioAssociacaoCooperativa> findByCriterioAssociacaoIdIn(List<Integer> listaCriterioAssocacaoId);

    List<CriterioAssociacaoCooperativa> findByCooperativaIdAndAtivoTrueAndCriterioAssociacao_AtivoTrue(Integer sqCooperativa);

    Optional<CriterioAssociacaoCooperativa> findByCooperativa_IdAndCriterioAssociacao_Id(Integer sqCooperativa, Integer sqCriterioAssociacao);

	void deleteAllByCriterioAssociacaoIdIn(List<Integer> listaCriterioAssociacaoId);

}
