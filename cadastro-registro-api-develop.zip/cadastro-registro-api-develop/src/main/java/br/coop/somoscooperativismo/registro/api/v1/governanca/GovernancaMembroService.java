package br.coop.somoscooperativismo.registro.api.v1.governanca;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoService;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.MandatoMembroService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.SituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import lombok.RequiredArgsConstructor;
import org.joda.time.Years;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Objects;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class GovernancaMembroService {
	private static final int MEMBRO_IDADE_MINIMA = 16;
	private static final int MEMBRO_IDADE_MAXIMA = 100;
	private final MandatoMembroService mandatoMembroService;
	private final MessagesService messages;
	private final MandatoService mandatoService;
	private final KeycloakService keycloakService;
	private final CooperativaPendenciaService cooperativaPendenciaService;

	public void validaMembroMandato(MandatoMembro membro) {
		if (!ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getCpf())) {
			throw new RegraNegocioException("O campo CPF é obrigatório");
		}
		if(!ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getNome())) {
			throw new RegraNegocioException(
					"Nome do CPF " + membro.getPessoaFisica().getCpf() + " é obrigatório");
		}
		if (!ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getGenero())) {
			throw new RegraNegocioException(
					"Gênero do CPF " + membro.getPessoaFisica().getCpf() + " é obrigatório");
		}
		if (!ValidacaoCampos.validaCampoPreenchido(membro.getCargo())) {
			throw new RegraNegocioException(
					"Cargo do CPF " + membro.getPessoaFisica().getCpf() + " é obrigatório");
		}
	}

	public void verificaMembroAprovado(MandatoMembro membro) {
		validaMembroInicioMandatoECargo(membro);
		if (membro.getId() != null) {

			Optional<MandatoMembro> op = mandatoMembroService.findById(membro.getId());
			if (op.isPresent()) {
				MandatoMembro membroCadastrado = op.get();

				if (membroCadastrado.getInicioMandato() == null) {
					membroCadastrado.setInicioMandato(membro.getInicioMandato());
				}

				LocalDate dataCadastrado = DataUtil.convertLocalDateEpochMilli(membroCadastrado.getInicioMandato());
				LocalDate dataInserida = DataUtil.convertLocalDateEpochMilli(membro.getInicioMandato());
				if ((membroCadastrado.getAprovacao() != null)
						&& (!membroCadastrado.getRepresentanteLegal().equals(membro.getRepresentanteLegal())
						|| (membroCadastrado.getCargo() != null
						&& !membroCadastrado.getCargo().getId().equals(membro.getCargo().getId()))
						|| dataCadastrado.compareTo(dataInserida) != 0 || !membroCadastrado.getPessoaFisica()
						.getCpf().equals(membro.getPessoaFisica().getCpf()))) {
					throw new RegraNegocioException(messages.get(GovernancaConstants.MEMBRO_APROVADO) + " "
							+ RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
				}
			}
		}

	}

	private void validaMembroInicioMandatoECargo(MandatoMembro membro) {
		if (!ValidacaoCampos.validaCampoPreenchido(membro.getInicioMandato())) {
			throw new RegraNegocioException("Data de início do mandato não informada para o CPF:" + " "
					+ RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
		}
		if (!ValidacaoCampos.validaCampoPreenchido(membro.getCargo())) {
			throw new RegraNegocioException("Cargo não informado para o CPF:" + " "
					+ RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
		}
	}


	public void validarDataDeNascimento(MandatoMembro membro) {
		if (membro.getPessoaFisica().getDataNascimento() != null) {
			int age = Years.yearsBetween(new org.joda.time.LocalDate(membro.getPessoaFisica().getDataNascimento()),
					new org.joda.time.LocalDate()).getYears();
			if (age < MEMBRO_IDADE_MINIMA) {
				throw new RegraNegocioException(messages.get(GovernancaConstants.PESSOA_FISICA_IDADE_INVALIDA)
						+ " menor que 16 anos, verifique o membro: "
						+ membro.getPessoaFisica().getCpf()
						+ " - "
						+ membro.getPessoaFisica().getNome());
			}
			if (age > MEMBRO_IDADE_MAXIMA) {
				throw new RegraNegocioException(messages.get(GovernancaConstants.PESSOA_FISICA_IDADE_INVALIDA)
						+ " maior que 100 anos, verifique o membro: "
						+ membro.getPessoaFisica().getCpf()
						+ " - "
						+ membro.getPessoaFisica().getNome());
			}
			membro.getPessoaFisica().setDataNascimento(membro.getPessoaFisica().getDataNascimento());
		} else {
			if (membro.getPessoaFisica().getDataNascimento() == null) {
				membro.getPessoaFisica().setDataNascimento(null);
			}
		}
	}

	public void encerrarUltimoMandato(Integer idCooperativa, Integer idOrgao) {
		if (keycloakService.isVerificaPossuiSubPerfil("CO_VIS") || keycloakService.isVerificaPossuiSubPerfil("UE_VIS")
				|| Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("UN_VIS"))) {
			throw new RegraNegocioException(messages.get(GovernancaConstants.PERMISSAO_ALTERACAO));
		}
		Optional<Mandato> encerrado = mandatoService.getMandatosPorCooperativa(idCooperativa).stream()
				.filter(m -> Objects.nonNull(m.getOrgao()) && Objects.equals(m.getOrgao().getId(), idOrgao))
				.findFirst();
		mandatoService.encerrarUltimoMandato(idOrgao, idCooperativa);
		encerrado.ifPresent(mandato -> cooperativaPendenciaService.reabrirAgrupamentoPorEncerramentoMandato(
				idCooperativa, emAtualizacaoCadastral(mandato), idOrgao));
	}

	private boolean emAtualizacaoCadastral(Mandato mandato) {
		Cooperativa cooperativa = mandato.getCooperativa();
		if (Objects.isNull(cooperativa) || Objects.isNull(cooperativa.getSituacaoCooperativa())) {
			return false;
		}
		return !SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo()
				.equals(cooperativa.getSituacaoCooperativa().getId());
	}
	public void tornarMandatoVigente(Integer idCooperativa, Integer idMandato) {
		mandatoService.tornarMandatoVigente(idMandato, idCooperativa);
	}


}
