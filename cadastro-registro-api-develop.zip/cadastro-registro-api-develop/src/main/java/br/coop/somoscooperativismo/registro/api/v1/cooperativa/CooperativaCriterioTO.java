package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CooperativaCriterioTO {
    private Set<Integer> cooperativas;
    private Set<Integer> categorias;
    private Set<Integer> ramos;
    private Set<Integer> municipios;
    private String textoLivre;
    private Boolean ativas;
    private Integer pageNumber;
    private Integer pageSize;
    private String sort;
}
