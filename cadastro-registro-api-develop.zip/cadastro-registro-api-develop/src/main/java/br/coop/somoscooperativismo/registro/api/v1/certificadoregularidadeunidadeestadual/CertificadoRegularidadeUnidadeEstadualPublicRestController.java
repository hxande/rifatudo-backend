package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual;

import br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual.entidade.CertificadoRegularidadeUnidadeEstadual;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/public/api/v1/certificadoRegularidadeUnidadeEstadual")
@Tag(name = "CertificadoRegularidadeUnidadeEstadual")
public class CertificadoRegularidadeUnidadeEstadualPublicRestController {


    public static final String LISTA_BACKGROUND_CERTIFICADO_NACIONAL_SALVO = "Certificados salvos com sucesso!";

    @Autowired
    private CertificadoRegularidadeUnidadeEstadualService certificadoRegularidadeUnidadeEstadualService;

    @Autowired
    MessagesService messages;

    private static final String CERTIFICADO_REGULARIDADE_GERADO_SUCESSO = "Certificado de regularidade gerado com sucesso.";


    @GetMapping("/pdf/{id}")
    @Operation(summary = "Lista certificados de regularidade das unidades estaduais", description = "")
    public ServiceResponse<byte[]> gerarCertificadoRegularidade(@PathVariable(name = "id") Integer idCooperativa) {
        return new ServiceResponse<>(
                certificadoRegularidadeUnidadeEstadualService.imprimirCertificadoPublico(idCooperativa),
                new ServiceMessage(messages.get(CERTIFICADO_REGULARIDADE_GERADO_SUCESSO)));
    }

    @GetMapping("/pode-imprimir/{idCooperativa}")
    @Operation(summary = "Pode imprimir certificado de regularidade")
    public ResponseEntity<ServiceResponse<Boolean>> podeImprimirCertificadoRegularidade(@PathVariable Integer idCooperativa) {
        return new ResponseEntity<>(new ServiceResponse<Boolean>(certificadoRegularidadeUnidadeEstadualService.validaSePodeImprimir(idCooperativa)), HttpStatus.OK);
    }
}
