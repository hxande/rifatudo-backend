package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import br.coop.somoscooperativismo.registro.api.v1.categoria.CategoriaService;
import lombok.RequiredArgsConstructor;
import lombok.Synchronized;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/categorias")
public class CategoriaImportacaoRestController {

    private final CategoriaService categoriaService;

    @GetMapping("/ativas")
    @Synchronized // Resolve SOU-771
    public ResponseEntity<List<Categoria>> getAllAtivas() {

        return ResponseEntity.ok(categoriaService.getAllAtivas());
    }
}
