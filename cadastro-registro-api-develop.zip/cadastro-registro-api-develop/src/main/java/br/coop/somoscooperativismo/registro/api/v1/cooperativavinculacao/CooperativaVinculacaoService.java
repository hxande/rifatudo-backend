package br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao;

import br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.entidade.CooperativaVinculacao;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.categoria.CategoriaRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CategoriaCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.CooperativaRegistroRepository;

@Service
@Transactional
public class CooperativaVinculacaoService {

    @Autowired
    CooperativaVinculacaoRepository cooperativaVinculacaoRepository;

    @Autowired
    @Lazy
    CooperativaService cooperativaService;

    @Autowired
    CooperativaRegistroRepository cooperativaRegistroRepository;

    @Autowired
    CategoriaRepository categoriaRepository;

    @Autowired
    private MessagesService messages;
    
    @Autowired
	private KeycloakService keycloakService;

    public static final String COOPERATIVA_VINCULACAO_MINIMO = "cooperativaVinculacao.minimo";
    public static final String COOPERATIVA_CATEGORIAVINCULADA_NAO_ENCONTRADA = "cooperativaVinculacao.categoriaVinculadaNaoencontrada";
    public static final String COOPERATIVA_CATEGORIA_NAO_ENCONTRADA = "cooperativaVinculacao.categoriaNaoencontrada";
    public static final String COOPERATIVA_GRAU_NAO_ENCONTRADO = "cooperativaVinculacao.grauNaoencontrado";
    public static final String COOPERATIVA_JA_ESTA_NA_LISTAGEM = "cooperativaVinculacao.cooperativaJaExistenteNaListagem";
    public static final String COOPERATIVA_MINIMO_CENTRAL_FEDERACAO = "cooperativaVinculacao.min3CentralOuFederacao";
    public static final String COOPERATIVA_MINIMO_SINGULAR = "cooperativaVinculacao.min3Singular";
    public static final String COOPERATIVA_NAO_POSSIVEL_SALVAR = "cooperativaVinculacao.naoFoiPossivelSalvar";
    public static final String USUARIO_PERMISSAO_COOPERATIVAS_COLIGADAS = "permissao.acesso.cooperativas.coligadas";
    
    public void vinculaCooperativasBasicas(Integer idCooperativaPai, @Valid List<CooperativaBasicaTO> listaCooperativaVinculacao) {
        List<Cooperativa> cooperativas = new ArrayList<>();
            listaCooperativaVinculacao.stream().filter(coop -> !Objects.isNull(coop)).forEach(coop -> cooperativas.add(cooperativaService.getCooperativaSemVerificacao(coop.getId())));
            vinculaCooperativas(idCooperativaPai, cooperativas);
    }

    public void vinculaCooperativas(Integer idCooperativaPai, @Valid List<Cooperativa> listaCooperativaVinculacao) {
        Cooperativa cooperativaPai = cooperativaService.getCooperativa(idCooperativaPai);

        if (listaCooperativaVinculacao != null && !listaCooperativaVinculacao.isEmpty()) {

            if (cooperativaPai.getCategoria() == null) {
                throw new RegraNegocioException(messages.get(COOPERATIVA_CATEGORIA_NAO_ENCONTRADA));
            }

            // Filtrando elementos nulos
            listaCooperativaVinculacao = listaCooperativaVinculacao.stream().filter(Objects::nonNull).collect(Collectors.toList());


            // ATUALIZANDO LISTA COM ELEMENTOS DO BANCO DE DADOS
            listaCooperativaVinculacao.forEach(coop -> coop = cooperativaService.getCooperativaSemVerificacao(coop.getId()));


            CategoriaCooperativaEnum categoria = CategoriaCooperativaEnum.getValue(cooperativaPai.getCategoria().getId());

            if (categoria == null) {
                throw new RegraNegocioException(messages.get(COOPERATIVA_CATEGORIA_NAO_ENCONTRADA));
            }

            Set<Integer> cooperativasAdicionadas = new HashSet<>();
            cooperativasAdicionadas.add(cooperativaPai.getId());

            validandoListaDeVinculacoes(listaCooperativaVinculacao, categoria, cooperativasAdicionadas);
        }

        // Exclui tudo
        cooperativaVinculacaoRepository.excluiTodosIdPai(idCooperativaPai);

        // Salva tudo
        if (listaCooperativaVinculacao != null) {
            listaCooperativaVinculacao.forEach(item -> {
                CooperativaVinculacao aux = new CooperativaVinculacao();
                aux.setCooperativaPai(cooperativaPai);
                aux.setCooperativaVinculada(item);

                cooperativaVinculacaoRepository.save(aux);
            });
        }
    }

    private void validandoListaDeVinculacoes(List<Cooperativa> listaCooperativaVinculacao, CategoriaCooperativaEnum categoria, Set<Integer> cooperativasAdicionadas) {
        if (listaCooperativaVinculacao != null) {
            listaCooperativaVinculacao.forEach(coopVinc -> {
                if (coopVinc.getCategoria() == null) {
                    throw new RegraNegocioException(messages.get(COOPERATIVA_CATEGORIAVINCULADA_NAO_ENCONTRADA));
                }

                CategoriaCooperativaEnum categoriaVinculadaAux = CategoriaCooperativaEnum.getValue(coopVinc.getCategoria().getId());
                if (categoriaVinculadaAux == null) {
                    throw new RegraNegocioException(messages.get(COOPERATIVA_CATEGORIA_NAO_ENCONTRADA));
                }

                if (!categoria.getPermissaoVinculacao().contains(categoriaVinculadaAux.getGrau())) {
                    throw new RegraNegocioException(messages.get(COOPERATIVA_GRAU_NAO_ENCONTRADO));
                }

                if (cooperativasAdicionadas.contains(coopVinc.getId())) {
                    throw new RegraNegocioException("%s - %s".formatted(messages.get(COOPERATIVA_JA_ESTA_NA_LISTAGEM), coopVinc.getNomeCooperativa()));
                }

                cooperativasAdicionadas.add(coopVinc.getId());
            });
        }
    }

    
    public Set<Cooperativa> buscaCooperativasVinculadasPeloCNPJ(String cnpj) {
		if(!keycloakService.isTipoEntidadeNacional() 
				&& !keycloakService.isTipoEntidadeEstadual()
				&& !keycloakService.isTipoEntidadeCooperativa()) {
			throw new RegraNegocioException(messages.get(USUARIO_PERMISSAO_COOPERATIVAS_COLIGADAS));
		}
		
		Set<Integer> setIdArvoreCooperativas = new HashSet<>();
		Set<Cooperativa> setCooperativas = new HashSet<>();
    	if(cnpj != null) {
        	Cooperativa c = cooperativaService.getCooperativaByCNPJ(cnpj);
        	if(c != null) {
        		setCooperativas = buscaCooperativaFilhasByIdPai(c.getId(),setIdArvoreCooperativas);
        	}
    	}

        setIdArvoreCooperativas = null;

    	return setCooperativas;
    }
   
    
    public Set<Cooperativa> buscaCooperativasVinculadasPeloIdCooperativa(Integer idCooperativaPai) {
    	
    	if(!keycloakService.isTipoEntidadeNacional() 
    			&& !keycloakService.isTipoEntidadeEstadual() 
    			&& !keycloakService.isTipoEntidadeCooperativa()) {
			throw new RegraNegocioException(messages.get(USUARIO_PERMISSAO_COOPERATIVAS_COLIGADAS));
		}
    	Set<Integer> setCooperativasAdicionadas = new HashSet<>();
    	Set<Cooperativa> setCooperativas = new HashSet<>();
    	if( idCooperativaPai != null ) {
    		setCooperativas = buscaCooperativaFilhasByIdPai(idCooperativaPai, setCooperativasAdicionadas);
    	}

        setCooperativasAdicionadas = null;

    	return setCooperativas;
    }
    
    
    private Set<Cooperativa> buscaCooperativaFilhasByIdPai(Integer idCooperativaPai,Set<Integer> listaCooperativasAdicionadas){
    	Set<Cooperativa> setCooperativas = new HashSet<>();
    	if(idCooperativaPai != null) {
    		listaCooperativasAdicionadas.add(idCooperativaPai);
        	Set<CooperativaVinculacao> setFilhosCooperativa = cooperativaVinculacaoRepository.findByCooperativaPaiId(idCooperativaPai);   	
        	Cooperativa cooperativa = cooperativaService.getCooperativaPeloId(idCooperativaPai);
        	if(cooperativa != null && !setFilhosCooperativa.isEmpty()) {
        		for (CooperativaVinculacao cv : setFilhosCooperativa) {
        			Cooperativa c = cooperativaService.getCooperativaPeloId(cv.getCooperativaVinculada().getId());
        			if(!listaCooperativasAdicionadas.contains(cv.getCooperativaVinculada().getId()) && c != null) {
    					Set<Cooperativa> setCoopFilhas = buscaCooperativaFilhasByIdPai(cv.getCooperativaVinculada().getId(),listaCooperativasAdicionadas);
    					c.setCooperativasColigadas(setCoopFilhas);
            			setCooperativas.add(c);
        			}
        		}
        	}

            setFilhosCooperativa = null;
    	}
    	return setCooperativas;
    }
    
}
