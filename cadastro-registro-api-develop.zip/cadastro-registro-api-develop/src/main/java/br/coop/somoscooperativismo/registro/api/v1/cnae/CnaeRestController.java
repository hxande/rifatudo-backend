package br.coop.somoscooperativismo.registro.api.v1.cnae;

import br.coop.somoscooperativismo.registro.api.v1.cnae.entidade.Cnae;
import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/cnae")
@Tag(name = "Cnae")
public class CnaeRestController {
	
	private static final String CNAE_CRIADA = "cnae.criada";
	private static final String CNAE_NAO_CORRESPONDE = "cnae.naoCorresponde";
	private static final String CNAE_ATUALIZADA = "cnae.atualizada";
	private static final String CNAE_DESATIVADA = "cnae.desativada";
	
	@Autowired
	private CnaeService cnaeService;
	
	@Autowired
	private MessagesService messages;
	
	@Operation(summary = "Detalha uma cnae pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<Cnae>> getCnae(@PathVariable String id){
		return ResponseEntity.ok(new ServiceResponse<>(cnaeService.getCnae(id)));
		
	}
	
	@PostMapping
	@Operation(summary="Cria uma cnae")
	public ResponseEntity<ServiceResponse<Cnae>> createCnae(@RequestBody @Valid Cnae cnae){
		cnae = cnaeService.createCnae(cnae);
		
		HttpHeaders headers = new HttpHeaders();
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(cnae.getId()).toUri();
		headers.setLocation(location);
		
		ServiceMessage message = new ServiceMessage(messages.get(CNAE_CRIADA));

		return new ResponseEntity<>(new ServiceResponse<>(cnae, message), headers, HttpStatus.CREATED);
	}
	
	
	@PutMapping("/{id}")
	@Operation(summary="Altera uma cnae")
	public ResponseEntity<ServiceResponse<Cnae>> updateCnae(@PathVariable String id, @RequestBody @Valid Cnae cnae){
		if(!cnae.getId().equals(id)) {
			return new ResponseEntity<> (new ServiceResponse<>(null,
					new ServiceMessage(MessageType.ERROR, "URL ID: '" + id
							+ messages.get(CNAE_NAO_CORRESPONDE) + cnae.getId()  + "'.")),
					HttpStatus.BAD_REQUEST);
		}
		
		ServiceMessage message = new ServiceMessage(messages.get(CNAE_ATUALIZADA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cnaeService.updateCnae(cnae), message), HttpStatus.OK);
		
	}
	
	@GetMapping
	@Operation(summary = "Lista todas as cnaes")
	public ServiceResponse<List<Cnae>> getCnaes() {
		return new ServiceResponse<>(cnaeService.getCnaes());
	}
	
	@DeleteMapping("desativa/{id}")
	@Operation(summary = "Desativa uma cnae", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> desativaCnae(@PathVariable String id) {
		cnaeService.desativaCnae(id);
		ServiceMessage message = new ServiceMessage(messages.get(CNAE_DESATIVADA));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	@Operation(summary = "Exclui uma cnae", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> excluiCnae(@PathVariable String id) {
		cnaeService.excluiCnae(id);
		ServiceMessage message = new ServiceMessage(messages.get(CNAE_DESATIVADA));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

}
