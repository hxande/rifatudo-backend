package br.coop.somoscooperativismo.registro.api.v1.controleanuario;

import br.coop.somoscooperativismo.registro.api.v1.controleanuario.entidade.ControleAnuario;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ControleAnuarioRepository extends JpaRepository<ControleAnuario, String>{

    Optional<ControleAnuario> findControleAnuarioByChaveAnuario(String chaveAnuario);

}