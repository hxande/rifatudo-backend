package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.io.Serial;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EstruturaIntegracaoParametroTO implements Serializable {

	@Serial
	private static final long serialVersionUID = 1L;

	private Integer idParametro;
	private String nomeParametro;
	private String descricaoParametro;

	private String nomeUnidade;
	private String siglaUnidade;
	private String tipoUnidade;
	private Integer quantidadeCasasUnidade;

	private Integer idEstruturaModeloRamo;
	private String valor;
	private Boolean podePreencher;
	
	private Boolean fechado;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
	private Date dtRegistroOcb;
	private String situacao;
	private String uf;
	private String ramo;
	private Integer sqPessoa;
	private String dtSubmissao;
	private Integer ano;
	private String grupo;
	private String nomeFantasia;
	private String cnpj;

	private boolean isCreditoAno;
	private boolean isValoresNegativos;
	private boolean isCampoObrigatorio;
	private String descricaoRamo;

}
