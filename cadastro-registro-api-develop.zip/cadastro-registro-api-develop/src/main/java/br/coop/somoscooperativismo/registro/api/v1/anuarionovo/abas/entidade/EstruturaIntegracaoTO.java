package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EstruturaIntegracaoTO {

	private Integer id;
	private String nome;
	private List<EstruturaGrupoTO> grupos;
	private Boolean preenchimentoObrigatorio;
}
