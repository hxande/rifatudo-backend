package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.CooperativaRegistroComentarioTO;
import lombok.Getter;
import lombok.Setter;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

@Getter
@Setter
public class HistoricoCooperativaRegistroListagemTO {
	private String uf;
	private String cnpj;
	private String razaoSocial;
	private String nomeFantasia;
	private String ramo;
	private CooperativaRegistro cooperativaRegistro;
	private String acao;
	private String novaSituacao;
	private String justificativaUE;
	private String justificativaUN;
	private List<CooperativaRegistroComentarioTO>  subHistorico;
	
	public List<String> objectToListString() {
		List<String> result =  Arrays.asList(
				this.uf,
				this.cnpj != null ? this.cnpj.replaceAll("\\b(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5") : "", 
				this.razaoSocial = this.razaoSocial != null ? this.razaoSocial : "",
				this.nomeFantasia = this.nomeFantasia != null ? this.nomeFantasia : "",
				this.ramo = this.ramo != null ? this.ramo : "", 
				this.acao = this.acao != null ? this.acao : "",
				this.dataAlteracaoFormatada(), 
				this.novaSituacao = this.novaSituacao != null ? this.novaSituacao : "",
				this.motivoSolicitacao(),
				this.complementoSolicitacao(),
				this.justificativaUE = this.justificativaUE != null ? this.justificativaUE: "",
				this.justificativaUN = this.justificativaUN != null ? this.justificativaUN : ""
				);
		
		return result;
	}
	
	private String motivoSolicitacao() {
		if(ValidacaoCampos.validaCampoPreenchido(this.cooperativaRegistro)
				&& ValidacaoCampos.validaCampoPreenchido(this.cooperativaRegistro.getCooperativaSolicitacao())) {
			return this.cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao().getMotivoSolicitacao();
		}else {
			return "";
		}
	}
	
	private String complementoSolicitacao() {
		if(ValidacaoCampos.validaCampoPreenchido(this.cooperativaRegistro)
				&& ValidacaoCampos.validaCampoPreenchido(this.cooperativaRegistro.getCooperativaSolicitacao())) {
			return this.cooperativaRegistro.getCooperativaSolicitacao().getOutroMotivoDesc();
		}else {
			return "";
		}
	}
	
	private String dataAlteracaoFormatada() {
		if(ValidacaoCampos.validaCampoPreenchido(this.cooperativaRegistro.getDtAlteracao())) {
			SimpleDateFormat formatar = new SimpleDateFormat("dd/MM/yyyy");
			return formatar.format(this.cooperativaRegistro.getDtAlteracao());
		}else {
			return "";
		}
		
	}
	

	
}
