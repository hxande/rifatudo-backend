package br.coop.somoscooperativismo.registro.api.v1.dadosgerais;

import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.entidade.DadosGerais;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/manutencao-dados-gerais")
@Tag(name = "ManutencaoDadosGerais")
public class ManutencaoDadosGeraisRestController {

	@Autowired
	private DadosGeraisService dadosGeraisService;
	
	@Autowired
	private MessagesService messages;
	
	public static final String REGISTRO_SALVO = "registroSalvo.sucesso";
	public static final String REGISTRO_PENDENCIA = "registroSalvo.pendencia";
	
	@PutMapping("/{idCooperativa}")
	@Operation(summary = "Salvar dados gerais em manutenção")
	public ResponseEntity<ServiceResponse<Boolean>> salvarDadosGerais(@PathVariable Integer idCooperativa, @RequestBody DadosGerais dadosGerais) throws Exception {
		boolean apenasDadosSociaisAnoCorrente = true;
		boolean successfully = dadosGeraisService.salvarDadosGeraisManutencao(dadosGerais, apenasDadosSociaisAnoCorrente, false);
		ServiceMessage message = new ServiceMessage(messages.get((successfully ? REGISTRO_SALVO : REGISTRO_PENDENCIA)));
		return new ResponseEntity<>(new ServiceResponse<>(message), (successfully ? HttpStatus.OK : HttpStatus.ACCEPTED));
	}
	
	@GetMapping("/validarDadosGerais/{idCooperativa}")
	@Operation(summary = "Validando Dados Gerais do Primeiro Registro")
	public ResponseEntity<ServiceResponse<ValidacaoPrimeiroRegistroTO>> validarDadosGerais(@PathVariable Integer idCooperativa){
		return new ResponseEntity<>(new ServiceResponse<ValidacaoPrimeiroRegistroTO>(dadosGeraisService.validarDadosGeraisManutencao(idCooperativa, false)), HttpStatus.OK);
	}

	@GetMapping("/verificarMudancaRamo/{idCooperativa}/{idRamo}")
	@Operation(summary = "Validando Dados Gerais do Primeiro Registro")
	public ResponseEntity<ServiceResponse<Ramo>> obterRamoComDadosGovernacaENegocio(@PathVariable Integer idCooperativa, @PathVariable String idRamo){
		return new ResponseEntity<>(new ServiceResponse<Ramo>(dadosGeraisService.obterRamoComDadosGovernacaENegocio(idCooperativa, idRamo)), HttpStatus.OK);

	}

	@PutMapping("/salvaQuadroSocialHistorico/{idCooperativa}")
	@Operation(summary = "Salva histórico")
	public ResponseEntity<ServiceResponse<List<QuadroSocial>>> salvaQuadroHistorico(@PathVariable Integer idCooperativa, @RequestBody List<QuadroSocial> quadroSociais){
		return new ResponseEntity<>(new ServiceResponse<List<QuadroSocial>>(dadosGeraisService.salvarQuadrosSociaisManutencaoHistorico(idCooperativa, quadroSociais), new ServiceMessage("Salvo com sucesso!")), HttpStatus.OK);
	}
	
	
}
