package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentario;

import java.util.List;


public class CooperativaRegistroComentarioUtil {


    public static CooperativaRegistroComentarioTO toDTO(CooperativaRegistroComentario comentarioEntity, List<Long> motivoIds) {
        CooperativaRegistroComentarioTO comentarioTO = new CooperativaRegistroComentarioTO();

        comentarioTO.setCooperativaRegistroId(comentarioEntity.getCooperativaRegistro().getId());
        comentarioTO.setMotivos(motivoIds);
        comentarioTO.setObservacao(comentarioEntity.getObservacao());
        comentarioTO.setAcao(comentarioEntity.getAcao());
        comentarioTO.setDataAlteracao(comentarioEntity.getDataAlteracao());
        comentarioTO.setUsuarioAlteracao(comentarioEntity.getUsuarioAlteracao());
        return comentarioTO;
    }
}
