package br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/cooperativa-anuario-abas")
@Tag(name = "CooperativaAnuarioAbas")
public class CooperativaAnuarioAbasRestController {

	@Autowired
	private CooperativaAnuarioAbasService cooperativaAnuarioAbasService;

	
	@GetMapping("/{idCooperativa}/{anoCiclo}")
	@Operation(summary = "Consultar abas do anuário por cooperativa e ano")
	public ServiceResponse<List<CooperativaAnuarioAbaTO>> obterListaCooperativaAnuarioAbaTO(@PathVariable Integer idCooperativa,
			@PathVariable Integer anoCiclo){
		return new ServiceResponse<>(cooperativaAnuarioAbasService.obterListaCooperativaAnuarioAbasPorAno(idCooperativa, anoCiclo));
	}
}
