package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum GrupoNegocioEnum {
    NEGOCIO("NEGOCIO", "Negócio"),
    NEGOCIO_SETORIAIS("NEGOCIO_SETORIAIS", "Negócio - Setoriais"),
    NEGOCIO_INTERCOOPERACAO("NEGOCIO_INTERCOOPERACAO", "Negócio - Intercooperação"),
    NEGOCIO_EXPORTACAO("NEGOCIO_EXPORTACAO", "Negócio - Exportação"),
    NEGOCIO_VENDAS_ONLINE("NEGOCIO_VENDAS_ONLINE", "Negócio - Vendas On-line");

    private final String chave;
    private final String descricao;

    GrupoNegocioEnum(String chave, String descricao) {
        this.chave = chave;
        this.descricao = descricao;
    }

    public static GrupoNegocioEnum fromDescricao(String nomeGrupo) {
        return Arrays.stream(values())
                .filter(g -> g.getDescricao().equalsIgnoreCase(nomeGrupo))
                .findFirst()
                .orElse(null);
    }
}
