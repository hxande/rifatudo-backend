package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import lombok.Data;

@Data
public class CriterioAssociacaoTO {
    private Integer id;
    private Integer sqRamo;
    private String descricao;
    private Boolean ativo;
    private Boolean excluido;
}

