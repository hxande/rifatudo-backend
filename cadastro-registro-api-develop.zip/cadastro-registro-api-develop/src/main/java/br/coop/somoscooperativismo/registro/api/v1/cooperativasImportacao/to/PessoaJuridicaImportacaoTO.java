package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PessoaJuridicaImportacaoTO {
    private Integer id;
    private String cnpj;
    private BigInteger seqCnpj;
    private String razaoSocial;
    private String nomeFantasia;
    private String ufSigla;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataConstituicao;
    private String nire;
    private String telefoneGeral;
    private String emailGeral;
    private String site;
    private Boolean preCadastro;
    private String situacaoReceita;
    private String tipoPessoa;
    private NaturezaJuridicaImportacaoTO naturezaJuridica;
    private RamoImportacaoTO ramo;
    private Boolean excluido;
    private Boolean matriz;
    private String tipoUnidade;
    private Boolean optanteSimples;
    private String inscricaoEstadual;
    private String inscricaoMunicipal;
    private String descricaoObjetoSocial;
    private String celular;
    private Integer codigoColigada;
    private List<PessoaSegmProdServImportacaoTO> segmProdServs;
}
