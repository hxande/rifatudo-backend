package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.orgao.VinculoEnum;
import br.coop.somoscooperativismo.registro.api.v1.orgaoramo.entidade.OrgaoRamo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Data da assembleia obrigatória para órgão de vínculo estatutário eletivo.
 * Paridade: {@code GovernancaService.validaAssembleia} (chamada dentro de
 * {@code verificaMandatos} para o mandato vigente que deve validar).
 */
@Component
@RequiredArgsConstructor
public class AssembleiaObrigatoriaRule implements GovernancaRule {

    private final OrgaoRamoResolver resolver;

    @Override
    public List<ViolacaoGovernanca> avaliar(GovernancaContext contexto) {
        List<ViolacaoGovernanca> violacoes = new ArrayList<>();
        for (Mandato mandato : contexto.getMandatos()) {
            if (mandato.getOrgao() == null || mandato.getOrgao().getId() == null
                    || !Boolean.TRUE.equals(mandato.getVigente())) {
                continue;
            }
            OrgaoRamo orgaoRamo = contexto.orgaoRamoDe(mandato.getOrgao().getId());
            if (orgaoRamo == null) {
                continue;
            }
            boolean deveValidar = resolver.obrigatorio(contexto.getSituacao(), orgaoRamo)
                    || Boolean.TRUE.equals(mandato.getCoopPossui());
            if (!deveValidar) {
                continue;
            }
            boolean estatutario = VinculoEnum.ESTATUTARIO_ELETIVO.toString().equals(mandato.getOrgao().getVinculo());
            if (estatutario && mandato.getDataAssembleia() == null) {
                violacoes.add(ViolacaoGovernanca.deOrgao(
                        TipoViolacaoGovernanca.DATA_ASSEMBLEIA_OBRIGATORIA, mandato.getOrgao().getNome()));
            }
        }
        return violacoes;
    }
}
