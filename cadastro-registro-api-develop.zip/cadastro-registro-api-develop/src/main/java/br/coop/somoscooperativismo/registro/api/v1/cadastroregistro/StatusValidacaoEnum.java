package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

public enum StatusValidacaoEnum {
    VALIDADO,
    FALHA_VALIDACAO,
    PENDENTE_EXECUCAO
}
