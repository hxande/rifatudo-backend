package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.registro.api.v1.contato.ContatoService;
import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.DadosGeraisService;
import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaService;
import br.coop.somoscooperativismo.registro.api.v1.negocio.NegocioService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class VerificarPendenciasParaRelatorioService {

	private static final Logger LOGGER = LoggerFactory.getLogger(VerificarPendenciasParaRelatorioService.class);
	private final GovernancaService governancaService;
	private final DadosGeraisService dadosGeraisService;
	private final NegocioService negocioService;
	private final PessoaJuridicaService pessoaJuridicaService;
	private final ContatoService contatoService;

	public List<RetornoRelatorioErroValidacaoEmLoteTO> cooperativasComErroValidacaoEmLote(Integer id) {
		List<RetornoRelatorioErroValidacaoEmLoteTO> listaPendencias = new ArrayList<>();

		String cnpj = pessoaJuridicaService.getPessoaJuridica(id).getCnpj();

		listaPendencias.addAll(obterPendencias(cnpj, governancaService.obterValidacaoGovernancaManutencao(id, true)));
		listaPendencias.addAll(obterPendencias(cnpj, dadosGeraisService.validarDadosGeraisManutencao(id, false)));
		listaPendencias.addAll(obterPendencias(cnpj, negocioService.validarNegocioManutencao(id, true)));
		listaPendencias.addAll(obterPendencias(cnpj, validaContato(id)));

		cnpj = null;

		return listaPendencias;
	}

	private List<RetornoRelatorioErroValidacaoEmLoteTO> obterPendencias(String cnpj, ValidacaoPrimeiroRegistroTO validacao) {
		List<RetornoRelatorioErroValidacaoEmLoteTO> pendencias = new ArrayList<>();

		if (validacao.getMensagens() != null && !validacao.getMensagens().isEmpty()) {
			validacao.getMensagens().forEach(mensagem -> pendencias.add(criarPendencia(cnpj, validacao.getTitulo(), mensagem.getMessage())));
		}

		return pendencias;
	}

	private RetornoRelatorioErroValidacaoEmLoteTO criarPendencia(String cnpj, String titulo, String mensagem) {
		RetornoRelatorioErroValidacaoEmLoteTO pendencia = new RetornoRelatorioErroValidacaoEmLoteTO();
		pendencia.setCnpj(cnpj);
		pendencia.setTitulo(titulo);
		pendencia.setMensagens(mensagem);
		return pendencia;
	}

	public ValidacaoPrimeiroRegistroTO validaContato(Integer id) {
		List<Contato> contatos = contatoService.getContatosPessoa(id);
		ValidacaoPrimeiroRegistroTO validacaoContato = new ValidacaoPrimeiroRegistroTO();
		validacaoContato.setTitulo("Contato");

		try {
			validacaoContato.setValidado(contatoService.verificarTodosCamposPreenchidos(contatos));
			if (Boolean.FALSE.equals(validacaoContato.getValidado())) {
				adicionarMensagemErro("Campos não preenchidos", validacaoContato);
			}
		} catch (Exception e) {
			LOGGER.info("ERROR {0}.", e);
			validacaoContato.setValidado(false);
			adicionarMensagemErro(e.getMessage(), validacaoContato);
		}

		contatos = null;

		return validacaoContato;
	}

	private void adicionarMensagemErro(String mensagemErro, ValidacaoPrimeiroRegistroTO validacao) {
		ServiceMessage mensagem = new ServiceMessage();
		mensagem.setType(MessageType.ERROR);
		mensagem.setMessage(mensagemErro);

		if (validacao.getMensagens() == null) {
			validacao.setMensagens(new ArrayList<>());
		}

		validacao.getMensagens().add(mensagem);
	}
}
