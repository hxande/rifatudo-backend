package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.entidade;

import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.entidade.RedeSocial;
import java.util.List;
import lombok.Data;

@Data
public class DadosGeraisResponse {

	private Integer idCooperativa;
	private Categoria categoria;
	private Boolean regidaPorLei;
	private Integer idSindicato;
	private List<Endereco> enderecos;
	private List<Contato> contatoCooperativa;
	private List<RedeSocial> redesSociais;
	private List<CooperativaBasicaTO> cooperativasVinculadas;
	private PessoaJuridica pessoaJuridica;
	private QuadroSocial quadroSocialAtual;
	private QuadroSocial quadroSocialManutencao;

}
