package br.coop.somoscooperativismo.registro.api.v1.cargo;

import br.coop.somoscooperativismo.registro.api.v1.cargo.entidade.Cargo;
import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/cargo")
@Tag(name = "Cargo")
public class CargoRestController {
	public static final String NAO_CORRESPONDE = "cargo.naoCorresponde";
	public static final String CARGO_CRIADO = "cargo.criado";
	public static final String CARGO_DESATIVADO = "cargo.desativado";
	public static final String CARGO_ATUALIZADO = "cargo.atualizado";

	@Autowired
	CargoService cargoService;

	@Autowired
	private MessagesService messages;

	@Operation(summary = "Detalha um cargo pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<Cargo>> getCargo(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cargoService.getCargo(id)));
	}

	@PostMapping
	@Operation(summary = "Cria um cargo")
	public ResponseEntity<ServiceResponse<Cargo>> createCargo(@RequestBody @Valid Cargo cargo) {
		cargo = cargoService.createCargo(cargo);
		HttpHeaders headers = new HttpHeaders();
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(cargo.getId())
				.toUri();
		headers.setLocation(location);

		ServiceMessage message = new ServiceMessage(messages.get(CARGO_CRIADO));
		return new ResponseEntity<>(new ServiceResponse<>(cargo, message), headers, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	@Operation(summary = "Altera um cargo")
	public ResponseEntity<ServiceResponse<Cargo>> updateCargo(@PathVariable Integer id,
			@RequestBody @Valid Cargo cargo) {
		if (!cargo.getId().equals(id)) {
			return new ResponseEntity<>(
					new ServiceResponse<>(null,
							new ServiceMessage(MessageType.ERROR,
									"URL ID: '" + id + " " + messages.get(NAO_CORRESPONDE) + cargo.getId() + "'.")),
					HttpStatus.BAD_REQUEST);
		}
		ServiceMessage message = new ServiceMessage(messages.get(CARGO_ATUALIZADO));
		return new ResponseEntity<>(new ServiceResponse<>(cargoService.updateCargo(cargo), message), HttpStatus.OK);

	}

	@GetMapping
	@Operation(summary = "Lista")
	public ServiceResponse<List<Cargo>> getCargos() {
		return new ServiceResponse<>(cargoService.getCargos());
	}

	@DeleteMapping("ativo/{id}/{valor}")
	@Operation(summary = "Ativa/Desativa uma cargo", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> desativaCargo(@PathVariable Integer id, @PathVariable Boolean valor) {
		cargoService.desativaCargo(id, valor);
		ServiceMessage message = new ServiceMessage(messages.get(CARGO_ATUALIZADO));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@GetMapping("/filtro")
	@Operation(summary = "Lista as com filtro")
	public ServiceResponse<Page<Cargo>> listaFiltradoPaginado(
			@RequestParam(required = false) String nome,
			@RequestParam(required = false) Boolean ativo, Pageable pageable) {
		return new ServiceResponse<>(cargoService.filtra(nome != null ? nome : "", ativo, pageable));
	}
}
