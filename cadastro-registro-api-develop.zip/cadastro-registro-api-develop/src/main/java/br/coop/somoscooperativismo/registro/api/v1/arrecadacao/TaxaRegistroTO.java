package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import lombok.*;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TaxaRegistroTO {

    private Integer id;
    private String status;
    private Integer idCooperativa;
    private BigDecimal valor;
    private BigDecimal desconto;
    private BigDecimal juros;
    private BigDecimal multa;
    private BigDecimal valorPago;
    private BigDecimal valorTotal;
    private List<TaxaRegistroParcelaTO> listaParcelas;
}
