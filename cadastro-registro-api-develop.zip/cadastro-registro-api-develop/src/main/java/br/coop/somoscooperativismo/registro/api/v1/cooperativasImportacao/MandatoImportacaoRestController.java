package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.MandatoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoService;

@RestController
@RequestMapping("/api/v1/cooperativas-importacao/mandatos")
public class MandatoImportacaoRestController extends MandatoImportacaoAbstractController {

    private final MandatoService mandatoService;

    public MandatoImportacaoRestController(ModelMapper modelMapper, MandatoService mandatoService) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, Mandato.class, MandatoImportacaoTO.class);
        this.mandatoService = mandatoService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Mandato> getMandatoById(@PathVariable Integer id) {
        return ResponseEntity.ok(mandatoService.getMandato(id));
    }

    @GetMapping("/vigentes/{idCooperativa}")
    public ResponseEntity<List<MandatoImportacaoTO>> getVigentesByCooperativaId(@PathVariable Integer idCooperativa) {
        return ResponseEntity.ok(mandatoService.getVigentesByCooperativaId(idCooperativa).stream()
                .map(mandato -> modelMapper.map(mandato, MandatoImportacaoTO.class)).collect(Collectors.toList()));
    }
}
