package br.coop.somoscooperativismo.registro.api.v1.events.events;

import org.springframework.context.ApplicationEvent;

import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;

public class SolicitacaoMudancaEnderecoEvent extends ApplicationEvent {


	private static final long serialVersionUID = 1L;
	private SolicitacaoMudancaEndereco solicitacaoMudancaEndereco;
	
	public SolicitacaoMudancaEnderecoEvent(Object source, SolicitacaoMudancaEndereco solicitacaoMudancaEndereco) {
		super(source);
		this.solicitacaoMudancaEndereco = solicitacaoMudancaEndereco;
	}

	public SolicitacaoMudancaEndereco getSolicitacaoMudancaEndereco() {
		return this.solicitacaoMudancaEndereco;
	}
}
