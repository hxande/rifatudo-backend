package br.coop.somoscooperativismo.registro.api.v1.email;

import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;

public interface EnvioEmailService {

	void emailVisitaTecnica(EmailEventTO to);
	void emailIniciarProcessoRegistro(EmailEventTO to);
	void enviaEmailFimVisitaTecnica(EmailEventTO to);
	void enviaEmailAjustes(EmailEventTO to);
	void enviaEmailFimConformidade(EmailEventTO to);
	void enviaEmailRegistroDeferido(EmailEventTO to);
	void enviaEmailRegistroIndeferido(EmailEventTO to);
	void enviaEmailRegistroArquivado(EmailEventTO to);
	void enviaEmailRegistroDesarquivado(EmailEventTO to);
	void enviaEmailAjustesFinalizado(EmailEventTO to);
	void enviaEmailSubmeter(EmailEventTO to);
	void enviaEmailManutencaoSubmeter(EmailEventTO to);
	void enviaEmailManutencaoAprovar(EmailEventTO to);
	void enviaEmailManutencaoAjustes(EmailEventTO to);
	void enviaEmailApontarIrregularidade(EmailEventTO to);
	void enviaEmailNotificacoesGestorUE(EmailEventTO to);
	void enviaEmailCooperativasIrregulares(EmailEventTO to);
	void enviaEmailInativarCoop(EmailEventTO to);
	void enviaEmailAvisaUEConcluirSolicitacao(EmailEventTO to);
	void enviaEmailAtualizarCadastro(EmailEventTO to);
	void enviarEmailUnidadeEstadualSubmissaoAnuario(EmailEventTO to);
	void enviaEmailDeferirPedido(EmailEventTO to);
	void enviaEmailEnviarApontamentos(EmailEventTO to);
	void enviaEmailSuspensaoCooperativa(EmailEventTO to);
	void enviaEmailManterSuspensaoCooperativa(EmailEventTO to);
	void enviaEmailTornarCooperativaRegular(EmailEventTO to);
	void enviaEmailTornarCooperativaRegularUn(EmailEventTO to);
	void enviaEmailSolicitaCancelamentoCooperativa(EmailEventTO to);
	void enviaEmailManterCancelamentoCooperativa(EmailEventTO to);
	void enviaEmailAceitarSolicitacaoCancelamento(EmailEventTO to);
	void enviaEmailIniciarProcessoRegistro(EmailEventTO to);
	void enviaEmailComunicarOrgaosSuspensao(EmailEventTO to);
	void enviaEmailSolicitacaoFiliacaoSuperior(EmailEventTO to);
	void enviaEmailAprovacaoFiliacaoSuperior(EmailEventTO to);
	void enviaEmailReprovacaoFiliacaoSuperior(EmailEventTO to);

}
