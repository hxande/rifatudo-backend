package br.coop.somoscooperativismo.registro.api.v1.endereco.entidade;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.MunicipioTO;
import br.coop.somoscooperativismo.registro.api.v1.pessoa.entidade.Pessoa;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.entidade.TipoEndereco;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.envers.Audited;

@Entity
@Table(name = "PESSOA_ENDERECO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
@NoArgsConstructor
@EqualsAndHashCode
public class Endereco implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_PESSOA_ENDERECO")
    private Integer id;

    @Column(name = "SQ_ESTADO", columnDefinition = "TINYINT")
    private Integer idEstado;

    @Column(name = "SQ_MUNICIPIO")
    private Integer idMunicipio;

    @ManyToOne
    @JoinColumn(name = "SQ_TIPO_ENDERECO")
    @Fetch(FetchMode.JOIN)
    private TipoEndereco tipoEndereco;

    @ManyToOne
    @JoinColumn(name = "SQ_PESSOA")
    @JsonBackReference
    private Pessoa pessoa;

    @Column(name = "TX_CEP")
    @Size(max = 8)
    private String cep;

    @Column(name = "TX_BAIRRO")
    @Size(max = 255)
    private String bairro;

    @Column(name = "TX_ENDERECO")
    @Size(max = 500)
    private String enderecoReferencia;

    @Column(name = "TX_ENDERECO_NUMERO")
    @Size(max = 10)
    private String numero;

    @Column(name = "TX_ENDERECO_COMPLEMENTO")
    @Size(max = 100)
    private String complemento;

    @Column(name = "TX_DESCRICAO_ENDERECO")
    @Size(max = 40)
    private String descricaoEndereco;

    @Column(name = "IN_ENDERECO_CORRESPONDENCIA_DIFERENTE_PRINCIPAL", columnDefinition = "BIT")
    private Boolean correspondenciaDiferente;

    @Transient
    private transient MunicipioTO municipio;

    public Endereco(
            Integer idEstado,
            Integer idMunicipio,
            String cep,
            String bairro,
            String endereco,
            String numero,
            String complemento) {
        this.idEstado = idEstado;
        this.idMunicipio = idMunicipio;
        this.cep = cep;
        this.bairro = bairro;
        this.descricaoEndereco = endereco;
        this.complemento = complemento;
        this.numero = numero;

    }

    public boolean isEnderecoPrincipal() {
        if (Objects.nonNull(this.getTipoEndereco())) {
            return this.getTipoEndereco().getEnderecoPrincipal();
        }
        return false;
    }

    public String getDescricaoEndereco() {
        return descricaoEndereco;
    }

    public void setDescricaoEndereco(String descricaoEndereco) {
        this.descricaoEndereco = descricaoEndereco;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public TipoEndereco getTipoEndereco() {
        return tipoEndereco;
    }

    public void setTipoEndereco(TipoEndereco tipoEndereco) {
        this.tipoEndereco = tipoEndereco;
    }

    public String getCep() {
        return cep;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public Integer getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(Integer idEstado) {
        this.idEstado = idEstado;
    }

    public Integer getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(Integer idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public Boolean getCorrespondenciaDiferente() {
        return correspondenciaDiferente == null ? Boolean.FALSE : correspondenciaDiferente;
    }

    public void setCorrespondenciaDiferente(Boolean correspondenciaDiferente) {
        this.correspondenciaDiferente = correspondenciaDiferente;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public String getEnderecoReferencia() {
        return enderecoReferencia;
    }

    public void setEnderecoReferencia(String enderecoReferencia) {
        this.enderecoReferencia = enderecoReferencia;
    }

    public MunicipioTO getMunicipio() {
        return municipio;
    }

    public void setMunicipio(MunicipioTO municipio) {
        this.municipio = municipio;
    }
}
