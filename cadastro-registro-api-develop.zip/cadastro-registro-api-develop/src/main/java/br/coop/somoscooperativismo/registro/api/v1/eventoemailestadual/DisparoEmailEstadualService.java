package br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual;

import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.entidade.DisparoEmailEstadual;
import java.util.Objects;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to.DisparoEmailEstadualFiltroTO;
import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to.DisparoEmailEstadualTO;

@Service
public class DisparoEmailEstadualService {

	private static final String DESTINATARIO_COOPERATIVA = "%Cooperativa%";
	
	private final DisparoEmailEstadualRepository disparoEmailEstadualRepository;
	private final KeycloakService keycloakService;
	
	public DisparoEmailEstadualService(DisparoEmailEstadualRepository disparoEmailEstadualRepository,
			KeycloakService keycloakService) {
		this.disparoEmailEstadualRepository = disparoEmailEstadualRepository;
		this.keycloakService = keycloakService;
	}



	public Page<DisparoEmailEstadualTO> obterListaDisparoEmailEstadual(DisparoEmailEstadualFiltroTO filtro, Pageable pageable) {
		return disparoEmailEstadualRepository.obterPaginadoDisparEmailEstadual(DESTINATARIO_COOPERATIVA,filtro.ufs(),filtro.tipoProcesso(),filtro.emailDescricao(),pageable);
	}



	public DisparoEmailEstadual findByDisparoEmailIdAndUf(Integer id, String uf) {
		return disparoEmailEstadualRepository.findByDisparoEmailIdAndUf(id,uf);
	}



	public DisparoEmailEstadualTO atualizarDisparoEmailEstadual(DisparoEmailEstadualTO disparoEmailEstadualTO) {
		if (keycloakService.isTipoEntidadeCooperativa() || (keycloakService.isTipoEntidadeEstadual()
				&& !Objects.equals(keycloakService.getUFUsuario(), disparoEmailEstadualTO.uf()))) {
			throw new RegraNegocioException("Usuário sem permissão para atualizar o registro.", HttpStatus.FORBIDDEN);
		}
		
		DisparoEmailEstadual disparoEmailEstadual = disparoEmailEstadualRepository.getReferenceById(disparoEmailEstadualTO.id());
		
		
		disparoEmailEstadual.setEnvia(disparoEmailEstadualTO.ativo());
		disparoEmailEstadualRepository.save(disparoEmailEstadual);

		disparoEmailEstadual = null;

		return disparoEmailEstadualTO;
	}
}
