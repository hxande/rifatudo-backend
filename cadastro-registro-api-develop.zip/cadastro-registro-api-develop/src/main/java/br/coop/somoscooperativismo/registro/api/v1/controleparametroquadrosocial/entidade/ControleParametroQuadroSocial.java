package br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocial.entidade;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "CONTROLE_PARAMETRO_QUADRO_SOCIAL")
public class ControleParametroQuadroSocial {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_CONTROLE_PARAMETRO_QUADRO_SOCIAL")
    private Integer id;
	
	@Column(name = "DN_INFORMAR_CAMPOS")
    private Boolean informarCampos;
	
	@Column(name = "DT_ALTERACAO")
	private LocalDate dataAlteracao;
	
	@Column(name = "TX_USUARIO")
	private String usuario;
}
