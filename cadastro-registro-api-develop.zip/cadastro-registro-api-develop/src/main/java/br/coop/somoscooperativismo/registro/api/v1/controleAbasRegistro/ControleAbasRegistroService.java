package br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro;

import br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro.entidade.ControleAbasRegistro;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import jakarta.validation.Valid;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

@Service
public class ControleAbasRegistroService {

    private final ControleAbasRegistroRepository controleAbasRegistroRepository;

    public ControleAbasRegistroService(@NonNull ControleAbasRegistroRepository controleAbasRegistroRepository) {
        this.controleAbasRegistroRepository = controleAbasRegistroRepository;
    }

    public ControleAbasRegistro save(@Valid ControleAbasRegistro controleAbasRegistro) {
        if (null != controleAbasRegistro) {
            controleAbasRegistro.setDataEnvio(Calendar.getInstance(
                    TimeZone.getTimeZone("UTC-3"), new Locale("pt", "BR")).getTime());
        }
        assert controleAbasRegistro != null;
        return controleAbasRegistroRepository.save(controleAbasRegistro);
    }

}
