package br.coop.somoscooperativismo.registro.api.v1.censoanuario.entidade;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "COOPERATIVA_CENSO_ANUARIO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class CensoAnuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_CENSO_ANUARIO")
    private Integer id;

    @Column(name = "NR_ANO", nullable = false, updatable = false)
    private Integer ano;

    @ManyToOne
    @JoinColumn(name = "SQ_COOPERATIVA", nullable = false, updatable = false)
    private Cooperativa cooperativa;

    @Column(name = "TX_USERNAME", nullable = false)
    private String username;

    @Column(name = "DT_SUBMISSAO")
    private LocalDateTime dataSubmissao;
}
