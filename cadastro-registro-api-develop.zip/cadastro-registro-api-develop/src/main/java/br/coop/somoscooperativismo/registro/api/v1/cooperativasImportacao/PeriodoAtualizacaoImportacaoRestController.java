package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.PeriodoAtualizacaoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/periodo-atualizacao")
public class PeriodoAtualizacaoImportacaoRestController {

    private final PeriodoAtualizacaoService periodoAtualizacaoService;

    @GetMapping("/periodo-atual/{idCooperativa}")
    public ResponseEntity<Integer> getPeriodoAtualByCooperativaId(@PathVariable Integer idCooperativa) {
        Integer ano = periodoAtualizacaoService.obterAnoCicloVigente(idCooperativa);
        return ResponseEntity.ok(ano);
    }

}
