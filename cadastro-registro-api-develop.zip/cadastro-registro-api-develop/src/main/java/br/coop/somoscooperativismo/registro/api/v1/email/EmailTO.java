package br.coop.somoscooperativismo.registro.api.v1.email;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmailTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String chaveModulo;
	private String de;
	private String para;
	private String assunto;
	private String corpo;
	private String mensagemRetorno;
	private List<AnexoTO> anexos;
	private boolean enviado;

}
