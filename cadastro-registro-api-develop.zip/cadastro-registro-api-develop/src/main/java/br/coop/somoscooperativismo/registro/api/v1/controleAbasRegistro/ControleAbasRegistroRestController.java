package br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro;

import br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro.entidade.ControleAbasRegistro;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@RestController
@RequestMapping("/api/v1/controle-abas-registro")
@Tag(name = "Controle Abas Registro")
public class ControleAbasRegistroRestController extends ControleAbasRegistroAbstractController {

    private final ControleAbasRegistroService controleAbasRegistroService;

    public static final String SALVAR_APONTAMENTO = "Salvo com sucesso!";

    final MessagesService messages;

    public ControleAbasRegistroRestController(@NonNull ModelMapper modelMapper,
                                              @NonNull ControleAbasRegistroService controleAbasRegistroService,
                                              MessagesService messages) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, ControleAbasRegistro.class, ControleAbasRegistroTO.class);
        this.controleAbasRegistroService = controleAbasRegistroService;
        this.messages = messages;
    }

    @Operation(summary = "Abas Registro Salvo")
    @PostMapping
    public ResponseEntity<ServiceResponse<ControleAbasRegistroTO>> salvarApontamento(
            @RequestBody ControleAbasRegistro controleAbasRegistro) {
        ControleAbasRegistroTO controleAbas = modelMapper
                .map(controleAbasRegistroService.save(controleAbasRegistro), ControleAbasRegistroTO.class);
        return new ResponseEntity<>(new ServiceResponse<>(controleAbas), HttpStatus.CREATED);

    }
}
