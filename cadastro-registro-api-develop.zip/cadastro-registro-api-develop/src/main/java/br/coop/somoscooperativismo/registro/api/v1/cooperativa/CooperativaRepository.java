package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaIntegracaoFormularioResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaWebLectorResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;

public interface CooperativaRepository extends JpaRepository<Cooperativa, Integer>, CooperativaRepositoryCustom,
        QuerydslPredicateExecutor<Cooperativa> {

    @Query("Select cooperativa from Cooperativa cooperativa where cooperativa.pessoaJuridica.id = :id")
    Optional<Cooperativa> buscaPorPessoaJuridica(@PathVariable Integer id);

    @Query("Select cooperativa from Cooperativa cooperativa "
    		+ " join SindicatoCooperativa sind ON cooperativa.id = sind.cooperativa.id"
    		+ " where sind.sindicato.id = :idSindicato")
    List<Cooperativa> buscaFiliadasAoSindicato(@Param("idSindicato") Integer idSindicato);

    @Query(value = "SELECT DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(PJ.SQ_PESSOA) " +
            "  FROM PESSOA_JURIDICA PJ WITH(NOLOCK) " +
            "       JOIN COOPERATIVA C  WITH(NOLOCK) " +
            "         ON PJ.SQ_PESSOA = C.SQ_COOPERATIVA WHERE C.SQ_COOPERATIVA = :id", nativeQuery = true)
    String getStatus(@PathVariable Integer id);

    @Query("Select cooperativa from Cooperativa cooperativa where cooperativa.pessoaJuridica.razaoSocial like %:razaoSocial% "
            + " and cooperativa.situacaoCooperativa.id IN (1)"
            + " order by cooperativa.pessoaJuridica.razaoSocial")
    List<Cooperativa> buscaAtivasPorRazaoSocial(@PathVariable String razaoSocial);

    @Query("Select cooperativa from Cooperativa cooperativa where cooperativa.pessoaJuridica.razaoSocial like %:razaoSocial% "
            + " and cooperativa.situacaoCooperativa.id IN (1)"
            + " and cooperativa.pessoaJuridica.ufSigla = :uf"
            + " order by cooperativa.pessoaJuridica.razaoSocial")
    List<Cooperativa> buscaAtivasPorRazaoSocialEUf(@PathVariable String razaoSocial, @PathVariable String uf);

    @Query("Select cooperativa from Cooperativa cooperativa where cooperativa.pessoaJuridica.cnpj like %:cnpj% "
            + " and cooperativa.situacaoCooperativa.id IN (1)"
            + " order by cooperativa.pessoaJuridica.cnpj")
    List<Cooperativa> buscaAtivasPorCnpj(@PathVariable String cnpj);

    @Query("Select cooperativa from Cooperativa cooperativa where cooperativa.pessoaJuridica.cnpj like %:cnpj% "
            + " and cooperativa.situacaoCooperativa.id IN (1)"
            + " and (:processo is null or cooperativa.numeroRegistroOCB = :processo)"
            + " order by cooperativa.pessoaJuridica.razaoSocial")
    Page<Cooperativa> buscaAtivasPorCnpjPaginado(@PathVariable String cnpj, Integer processo, Pageable pageable);


    @Query("SELECT coop " +
            "FROM Cooperativa coop " +
            "JOIN coop.pessoaJuridica pj " +
            "WHERE 1=1 " +
            "  AND coop.numeroRegistroOCB IS NOT NULL " +
            "  AND coop.situacaoCooperativa.id <> 3 " +
            "  AND (:cnpj IS NULL OR :cnpj = '' OR pj.cnpj = :cnpj) " +
            "  AND (:processo IS NULL OR :processo = '' OR coop.numeroRegistroOCB = :processo) " +
            "  AND (:uf IS NULL  OR :uf = '' OR pj.ufSigla = :uf) " +
            "  AND (:nomeFantasia IS NULL OR :nomeFantasia = '' OR LOWER(pj.nomeFantasia) LIKE LOWER(CONCAT('%', :nomeFantasia, '%')))")
    Page<Cooperativa> buscaRegistradasPaginado(@PathVariable String cnpj, @PathVariable String processo, @PathVariable String uf, @PathVariable String nomeFantasia, Pageable pageable);

    @Query("Select cooperativa from Cooperativa cooperativa where cooperativa.pessoaJuridica.cnpj like %:cnpj% "
            + " order by cooperativa.pessoaJuridica.cnpj")
    List<Cooperativa> buscaPorCnpj(@PathVariable String cnpj);

    @Query("Select cooperativa from Cooperativa cooperativa where (:razaoSocial is null or cooperativa.pessoaJuridica.razaoSocial like %:razaoSocial%)"
            + " and cooperativa.situacaoCooperativa.id IN (1,2,3)")
    Page<Cooperativa> buscaPorRazaoSocialPaginado(@PathVariable String razaoSocial, Pageable pageable);

    @Query("Select cooperativa from Cooperativa cooperativa where (:razaoSocial is null or cooperativa.pessoaJuridica.razaoSocial like %:razaoSocial%)"
            + " and  (:nomeFantasia is null or cooperativa.pessoaJuridica.nomeFantasia like %:nomeFantasia%)"
            + " and (:tipo is null or cooperativa.pessoaJuridica.tipoPessoa like %:tipo%)"
            + " and cooperativa.situacaoCooperativa.id IN (1,2,3)")
    Page<Cooperativa> buscaPorRazaoSocialUfPaginado(@PathVariable String razaoSocial, @PathVariable String nomeFantasia,
                                                    @PathVariable String tipo, Pageable pageable);


    // Integer id, String cnpj, String razaoSocial, String nomeFantasia, String ufSigla, Integer idRamo, String nomeRamo

    @Query("""
            select new br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO(
                c.id,
                pj.cnpj,
                pj.razaoSocial,
                pj.nomeFantasia,
                pj.ufSigla,
                r.id,
                r.nome
            )
            from Cooperativa c
            join c.categoria cat
            join c.pessoaJuridica pj
            join pj.ramo r
            where cat.id in (:idCategoria)
              and c.situacaoCooperativa.id in (:situacaoCooperativa)
              and pj.matriz = true
              and pj.excluido = false
              and pj.cnpj = :cnpj
            """)
    List<CooperativaBasicaTO> getCooperativasPorGrauECnpj(
            @Param("cnpj") String cnpj,
            @Param("idCategoria") Integer[] idCategoria,
            @Param("situacaoCooperativa") Integer[] situacaoCooperativa,
            Pageable pageable
    );

    @Query("""
            select new br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO(
                c.id,
                pj.cnpj,
                pj.razaoSocial,
                pj.nomeFantasia,
                pj.ufSigla,
                r.id,
                r.nome
            )
            from Cooperativa c
            join c.categoria cat
            join c.pessoaJuridica pj
            join pj.ramo r
            where cat.id in (:idCategoria)
              and c.situacaoCooperativa.id in (:situacaoCooperativa)
              and pj.matriz = true
              and pj.excluido = false
              and (
                    pj.nomeFantasia like concat(:buscaTexto, '%')
                    or pj.razaoSocial like concat(:buscaTexto, '%')
              )
            order by pj.nomeFantasia
            """)
    List<CooperativaBasicaTO> getCooperativasPorGrauENome(
            @Param("buscaTexto") String buscaTexto,
            @Param("idCategoria") Integer[] idCategoria,
            @Param("situacaoCooperativa") Integer[] situacaoCooperativa,
            Pageable pageable
    );

    @Query("Select cv.cooperativaVinculada from Cooperativa cooperativa join cooperativa.cooperativaVinculacao cv " + " where cv.cooperativaPai.id = :idCooperativaPai ")
    List<Cooperativa> getCooperativasVinculadas(@Param("idCooperativaPai") Integer idCooperativaPai);

    @Query("Select c from Cooperativa c where (:cnpj is null or c.pessoaJuridica.cnpj = :cnpj) and (:uf is null or c.pessoaJuridica.ufSigla = :uf) ")
    List<Cooperativa> findAll(@Param("cnpj") String cnpj, @Param("uf") String uf);

    @Query("Select c from Cooperativa c where c.id = :idCooperativa AND (:cnpj is null or c.pessoaJuridica.cnpj = :cnpj) and (:uf is null or c.pessoaJuridica.ufSigla = :uf) ")
    Cooperativa findById(@Param("idCooperativa") Integer idCooperativa, @Param("cnpj") String cnpj, @Param("uf") String uf);

    @Query("Select c from Cooperativa c where c.id = :idCooperativa AND (:cnpj is null or c.pessoaJuridica.cnpj = :cnpj) and (:uf is null or c.pessoaJuridica.ufSigla = :uf) ")
    Cooperativa xpto(@Param("idCooperativa") Integer idCooperativa, @Param("cnpj") String cnpj, @Param("uf") String uf);

    @Query("Select c from Cooperativa c where c.id = :idCooperativa")
    Cooperativa getCooperativaPeloId(@Param("idCooperativa") Integer idCooperativa);

    @Query("Select c from Cooperativa c where c.pessoaJuridica.cnpj = :cnpj")
    Cooperativa getCooperativaByCNPJ(@Param("cnpj") String cnpj);

    @Query("Select c from Cooperativa c where c.pessoaJuridica.ramo.id =:idRamo")
    List<Cooperativa> findByRamoId(@Param("idRamo") Integer idRamo);

    @Query("Select c from Cooperativa c where c.pessoaJuridica.ufSigla = :uf AND c.situacaoCooperativa.id in(1,2) and c.dataRegistro is not null")
    List<Cooperativa> getRelatorioCooperativasRegistradasPelaUF(@Param("uf") String uf);

    @Query("Select c from Cooperativa c where c.pessoaJuridica.ufSigla = :uf AND c.situacaoCooperativa.id in(1) and c.dataRegistro is not null and c.pessoaJuridica.ramo.id = :idRamo")
    List<Cooperativa> findCooperativasAtivasByUFAndRamo(@Param("uf") String uf, @Param("idRamo") Integer idRamo);

    @Query("Select c from Cooperativa c where c.pessoaJuridica.ufSigla = :uf AND c.situacaoCooperativa.id in(1) and c.dataRegistro is not null and c.pessoaJuridica.ramo.id = :idRamo")
    List<Cooperativa> findCooperativasAtivasRegularesByUFAndRamo(@Param("uf") String uf, @Param("idRamo") Integer idRamo);

    @Query("FROM CooperativaMatrizRegistradaTO coop")
    Page<CooperativaMatrizRegistradaTO> getListCooperativaMatrizRegistrada(Pageable pageable);

    @Query("select distinct cooperativa from Cooperativa cooperativa"
            + " where cooperativa.progressoMicro = :progressoMicro "
            + " OR cooperativa.progressoManutencaoMicro =:progressoMicroManutencao"
            + " AND cooperativa.dataAtualizacao >= :dataHoraAtualizacao "
            + " AND cooperativa.arquivado = false "
            + " AND cooperativa.situacaoCooperativa.id <> 3"
            + " ORDER BY cooperativa.dataAtualizacao DESC")
    List<Cooperativa> buscarPendenciasData(@Param("progressoMicro") ProgressoMicroEnum progressoMicro, @Param("progressoMicroManutencao") ProgressoMicroEnum progressoMicroManutencao, @Param("dataHoraAtualizacao") Date dataHoraAtualizacao);

    @Query("select distinct cooperativa from Cooperativa cooperativa"
            + " join fetch cooperativa.cooperativaRegistro"
            + " where cooperativa.situacaoCooperativa.id = 2"
            + " ORDER BY cooperativa.dataAtualizacao DESC"
    )
    List<Cooperativa> buscaCooperativasIrregulares();

    Cooperativa findByPessoaJuridicaCnpj(String cnpj);

    @Query(value = "SELECT DISTINCT PJMATRIZ.SQ_PESSOA AS id," +
            "	PJMATRIZ.TX_NOME_FANTASIA AS nomeFantasia," +
            "	PJMATRIZ.TX_RAZAO_SOCIAL AS razaoSocial," +
            "	PJMATRIZ.TX_CNPJ  AS cnpj," +
            "	S.TX_NOVA_SITUACAO_COOPERATIVA AS situacao," +
            "	ISNULL(PJFILIAL.TX_UF_SIGLA, PJMATRIZ.TX_UF_SIGLA) AS ufSiglaFinal," +
            "	E.TX_CEP AS cep," +
            "	E.TX_ENDERECO AS endereco," +
            "	E.TX_BAIRRO AS bairro, " +
            "	E.TX_ENDERECO_NUMERO AS enderecoNumero," +
            "	E.TX_ENDERECO_COMPLEMENTO AS enderecoComplemento," +
            "	E.SQ_MUNICIPIO AS municipioId," +
            "	CMATRIZ.DT_ATUALIZACAO AS dataAtualizacao," +
            "	PJMATRIZ.TX_UF_SIGLA AS ufSigla" +
            "  FROM api_cadastro_registro..PESSOA_JURIDICA PJMATRIZ WITH(NOLOCK)" +
            "       JOIN api_cadastro_registro..COOPERATIVA CMATRIZ WITH(NOLOCK)" +
            "         ON CMATRIZ.SQ_COOPERATIVA = PJMATRIZ.SQ_PESSOA" +
            "       LEFT JOIN api_cadastro_registro..PESSOA_JURIDICA_FILIACAO PJF WITH(NOLOCK)" +
            "         ON PJMATRIZ.SQ_PESSOA = PJF.SQ_PESSOA_JURIDICA_MATRIZ" +
            "       LEFT JOIN api_cadastro_registro..PESSOA_JURIDICA PJFILIAL WITH(NOLOCK)" +
            "         ON PJF.SQ_PESSOA_JURIDICA_FILIADA = PJFILIAL.SQ_PESSOA" +
            "		 LEFT JOIN api_cadastro_registro..SITUACAO_COOPERATIVA S with(nolock) ON S.SQ_SITUACAO_COOPERATIVA = CMATRIZ.SQ_SITUACAO_COOPERATIVA" +
            "		 LEFT JOIN api_cadastro_registro..PESSOA_ENDERECO E with(nolock) ON PJMATRIZ.SQ_PESSOA = E.SQ_PESSOA  " +
            "  WHERE CMATRIZ.TX_NUMERO_REGISTRO_OCB is not null AND (E.SQ_TIPO_ENDERECO = 1 OR E.SQ_TIPO_ENDERECO IS NULL) " +
            "  ORDER BY PJMATRIZ.TX_CNPJ", nativeQuery = true)
    List<CooperativaWebLectorResponseTO> fetchCooperativasParaWebLector();

    @Query(value = "SELECT C.SQ_COOPERATIVA AS id," +
            "          CA.TX_CATEGORIA_COOPERATIVA AS categoria," +
            "          C.DT_REGISTRO_OCB AS dataRegistroOcb," +
            "          C.DT_ATUALIZACAO AS dataAtualizacao," +
            "		   C.IN_REGIDA_POR_LEI AS regidaPorLei," +
            "	       S.TX_NOVA_SITUACAO_COOPERATIVA AS situacao," +
            "          PJ.TX_CNPJ AS cnpj," +
            "          PJ.TX_RAZAO_SOCIAL AS razaoSocial," +
            "          PJ.TX_NOME_FANTASIA AS nomeFantasia," +
            "          PJ.DT_CONSTITUICAO_FUNDACAO AS dataConstituicaoFundacao," +
            "          PJ.TX_NIRE AS nire," +
            "          PJ.TX_TELEFONE_GERAL AS telefoneGeral," +
            "          PJ.TX_EMAIL_GERAL AS emailGeral," +
            "          PJ.TX_SITE AS site," +
            "          R.TX_RAMO AS ramo," +
            "          ISNULL( (SELECT DISTINCT CAST('true' AS VARCHAR(6)) "
            + " FROM COOPERATIVA_APROVACAO AP with(nolock) "
            + " WHERE AP.SQ_COOPERATIVA=C.SQ_COOPERATIVA AND AP.NR_ANO = YEAR(GETDATE())), 'false') AS aprovada "
            + " FROM COOPERATIVA C WITH(NOLOCK) "
            + "INNER JOIN PESSOA_JURIDICA PJ with(nolock) ON PJ.SQ_PESSOA = C.SQ_COOPERATIVA "
            + "INNER JOIN CATEGORIA_COOPERATIVA CA with(nolock) ON CA.SQ_CATEGORIA_COOPERATIVA = C.SQ_CATEGORIA_COOPERATIVA "
            + "INNER JOIN SITUACAO_COOPERATIVA S with(nolock) ON S.SQ_SITUACAO_COOPERATIVA = C.SQ_SITUACAO_COOPERATIVA "
            + "INNER JOIN RAMO R with(nolock) ON R.SQ_RAMO = PJ.SQ_RAMO "
            + "WHERE C.SQ_SITUACAO_COOPERATIVA NOT IN (3,4) AND PJ.TX_UF_SIGLA LIKE :uf"
            + " ORDER BY C.SQ_COOPERATIVA ", nativeQuery = true)
    List<CooperativaIntegracaoFormularioResponseTO> fetchCooperativasParaIntegracaoFormulario(String uf);

    List<Cooperativa> findByVwPessoaJuridicaId(Integer id);

    @Query("select cooperativa from Cooperativa cooperativa"
            + " join fetch cooperativa.quadrosSociais"
            + " join fetch cooperativa.pessoaJuridica"
            + " where cooperativa.situacaoCooperativa.id = 4 and cooperativa.pessoaJuridica.matriz = true and cooperativa.arquivado = false"
    )
    List<Cooperativa> emProcessoDeRegistroSemPaginacaoComQuadroSocial();

    @Modifying
    @Transactional
    @Query(value = " UPDATE COOPERATIVA SET IN_PREENCHIMENTO = :status WHERE SQ_COOPERATIVA = :id ", nativeQuery = true)
    void alterarStatusEmPreenchimento(@Param("id") Integer id, @Param("status") boolean status);

    @Query("SELECT pj.nomeFantasia " +
            "FROM Cooperativa coop " +
            "JOIN coop.pessoaJuridica pj " +
            "WHERE 1=1 " +
            "  AND coop.numeroRegistroOCB IS NOT NULL " +
            "  AND coop.situacaoCooperativa.id <> 3 " +
            "  AND (:parcial IS NULL OR :parcial = '' OR LOWER(pj.nomeFantasia) LIKE LOWER(CONCAT(:parcial, '%')))" +
            "ORDER BY pj.nomeFantasia ASC")
    List<String> autocompleteCooperativa(String parcial);

    @Query(" SELECT pj.ufSigla " +
            " FROM Cooperativa coop " +
            " JOIN coop.pessoaJuridica pj " +
            " WHERE coop.id = :idCooperativa ")
    String getUfSiglaCooperativa(@Param("idCooperativa") Integer idCooperativa);

    @Query("SELECT cooperativaPai " +
            "FROM CooperativaVinculacao cv " +
            "JOIN cv.cooperativaPai cooperativaPai " +
            "WHERE cv.cooperativaVinculada.id = :idCooperativaFilha")
    List<Cooperativa> getCooperativaSuperior(
            @Param("idCooperativaFilha") Integer idCooperativaFilha);

    @Query("""
                SELECT cooperativa
                FROM Cooperativa cooperativa
                WHERE cooperativa.pessoaJuridica.cnpj = :cnpj
                  AND cooperativa.categoria.ativo = true
                  AND cooperativa.pessoaJuridica.matriz = true
                  AND cooperativa.pessoaJuridica.excluido = false
                  AND cooperativa.id <> :idCooperativaAtual
            """)
    Optional<Cooperativa> buscarSuperiorPorCnpj(
            @Param("idCooperativaAtual") Integer idCooperativaAtual,
            @Param("cnpj") String cnpj
    );

    // Para Singular buscando Central/Federação do mesmo ramo:
    @Query("""
                SELECT cooperativaPai
                FROM Cooperativa cooperativaFilha, Cooperativa cooperativaPai
                WHERE cooperativaFilha.id = :idCooperativaFilha
                  AND cooperativaPai.pessoaJuridica.cnpj = :cnpjPai
                  AND cooperativaPai.categoria.id = 2
                  AND cooperativaPai.categoria.ativo = true
                  AND cooperativaPai.pessoaJuridica.ramo.id = cooperativaFilha.pessoaJuridica.ramo.id
                  AND cooperativaPai.pessoaJuridica.matriz = true
                  AND cooperativaPai.pessoaJuridica.excluido = false
                  AND cooperativaPai.situacaoCooperativa.id = 1
                  AND cooperativaPai.id <> cooperativaFilha.id
            """)
    List<Cooperativa> buscarCentralFederacaoPorCnpjMesmoRamo(
            @Param("idCooperativaFilha") Integer idCooperativaFilha,
            @Param("cnpjPai") String cnpjPai
    );

    // Para Central/Federação buscando Confederação:
    @Query("SELECT cooperativaPai " +
            "FROM Cooperativa cooperativaFilha, Cooperativa cooperativaPai " +
            "WHERE cooperativaFilha.id = :idCooperativaFilha " +
            "AND cooperativaPai.pessoaJuridica.cnpj = :cnpjPai " +
            "AND cooperativaPai.categoria.id = 3 " +
            "AND cooperativaPai.id <> cooperativaFilha.id")
    List<Cooperativa> buscarConfederacaoPorCnpj(
            @Param("idCooperativaFilha") Integer idCooperativaFilha,
            @Param("cnpjPai") String cnpjPai);

    @Query("""
                SELECT cooperativaPai
                FROM Cooperativa cooperativaPai
                WHERE cooperativaPai.pessoaJuridica.cnpj = :cnpj
                  AND cooperativaPai.categoria.id = :idCategoriaEsperada
                  AND cooperativaPai.categoria.ativo = true
                  AND cooperativaPai.pessoaJuridica.matriz = true
                  AND cooperativaPai.pessoaJuridica.excluido = false
                  AND cooperativaPai.situacaoCooperativa.id = 1
                  AND cooperativaPai.id <> :idCooperativaAtual
            """)
    List<Cooperativa> buscarCooperativaSuperiorPorCnpjECategoria(
            @Param("idCooperativaAtual") Integer idCooperativaAtual,
            @Param("cnpj") String cnpj,
            @Param("idCategoriaEsperada") Integer idCategoriaEsperada
    );

}
