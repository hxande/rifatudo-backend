package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.pessoacnae.entidade.PessoaCnae;
import br.coop.somoscooperativismo.registro.api.v1.pessoacnae.PessoaCnaeService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/pessoas-cnaes")
public class PessoaCnaeImportacaoRestController {

    private final PessoaCnaeService pessoaCnaeService;

    @GetMapping("/primario/{ehPrimario}/pessoa/{idPessoa}")
    public ResponseEntity<List<PessoaCnae>> getByPessoaId(@PathVariable Boolean ehPrimario, @PathVariable Integer idPessoa) {
        return ResponseEntity.ok(pessoaCnaeService.getByPrimarioAndPessoa(ehPrimario, idPessoa));
    }

}
