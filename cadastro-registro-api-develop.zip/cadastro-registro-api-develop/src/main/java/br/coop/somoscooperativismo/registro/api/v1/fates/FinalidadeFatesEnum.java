package br.coop.somoscooperativismo.registro.api.v1.fates;

import java.util.Arrays;

public enum FinalidadeFatesEnum {

    ASSISTENCIA_EDUCACIONAL(1, "Assistência Educacional"),
    ASSISTENCIA_SOCIAL(2, "Assistência Social"),
    ASSISTENCIA_TECNICA(3, "Assistência Técnica");

    private final Integer codigo;
    private final String descricao;

    FinalidadeFatesEnum(Integer codigo, String descricao) {
        this.codigo = codigo;
        this.descricao = descricao;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public static FinalidadeFatesEnum fromCodigo(Integer codigo) {
        return Arrays.stream(values())
                .filter(f -> f.codigo.equals(codigo))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Código de Finalidade FATES inválido: " + codigo));
    }
}

