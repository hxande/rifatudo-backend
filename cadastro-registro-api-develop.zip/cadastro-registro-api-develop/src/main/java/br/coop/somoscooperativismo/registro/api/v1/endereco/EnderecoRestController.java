package br.coop.somoscooperativismo.registro.api.v1.endereco;

import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/endereco")
@Tag(name = "Endereco")
public class EnderecoRestController {

	@Autowired
	private EnderecoService enderecoService;

	@Autowired
	private MessagesService messages;

	@GetMapping
	@Operation(summary = "Lista dos Endereco existentes")
	public ServiceResponse<Page<Endereco>> getEnderecos(Pageable pageable) {
		return new ServiceResponse<>(enderecoService.getEnderecos(pageable));
	}
	
	@GetMapping("/{id}")
	@Operation(summary = "Detalha um Endereco pelo ID", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Endereco>> getEndereco(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(enderecoService.buscarPorId(id)));
	}

	@PostMapping
	@Operation(summary = "Cria um Endereco", description = "Os dados do Endereco devem ser informados")
	public ResponseEntity<ServiceResponse<Endereco>> createEndereco(@RequestBody @Valid Endereco endereco) {
		endereco = enderecoService.save(endereco);
		HttpHeaders headers = new HttpHeaders();
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(endereco.getId()).toUri();
		headers.setLocation(location);
		ServiceMessage message = new ServiceMessage((messages.get("endereco.criado")));
		return new ResponseEntity<>(new ServiceResponse<>(endereco, message), headers, HttpStatus.CREATED);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Apaga um Endereco pelo id", description = "Um id válido deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> deletarEndereco(@PathVariable Integer id) {
		enderecoService.deletarEndereco(id);
		ServiceMessage message = new ServiceMessage((messages.get("endereco.deletado")));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@PutMapping("/{id}")
	@Operation(summary = "Altera os dados do Endereco", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Endereco>> updateEndereco(@PathVariable Integer id, @Valid @RequestBody Endereco endereco) {
		if (!endereco.getId().equals(id)) {
			return new ResponseEntity<>(new ServiceResponse<>(null, new ServiceMessage(MessageType.ERROR, "URL ID: '" + id + messages.get("endereco.naoCorresponde") + endereco.getId() + "'.")), HttpStatus.BAD_REQUEST);
		}
		ServiceMessage message = new ServiceMessage(messages.get("endereco.atualizado"));
		return new ResponseEntity<>(new ServiceResponse<>(enderecoService.updateEndereco(endereco), message), HttpStatus.OK);
	}

	@GetMapping("/filtro")
	@Operation(summary = "Lista os Endereco com filtro")
	public ServiceResponse<Page<Endereco>> filtrarEnderecoPaginado(EnderecoFiltroTO enderecoFiltroTO, Pageable pageable) {
		return new ServiceResponse<>(enderecoService.filtrarEnderecos(enderecoFiltroTO, pageable));
	}
	
	@GetMapping("/filtro/todos")
	@Operation(summary = "Lista os Endereco com filtro sem paginação")
	public ServiceResponse<List<Endereco>> filtrarEnderecoSemPaginacao(EnderecoFiltroTO enderecoFiltroTO) {
		return new ServiceResponse<>(enderecoService.filtrarEnderecosSemPaginacao(enderecoFiltroTO));
	}

	@GetMapping("/filtro/enderecosPessoa/{idPessoa}")
	@Operation(summary = "Lista os Endereco com filtro sem paginação")
	public ServiceResponse<List<Endereco>> obterEnderecosPessoa(@PathVariable Integer idPessoa) {
		return new ServiceResponse<>(enderecoService.obterEnderecosPessoa(idPessoa));
	}
	
}
