package br.coop.somoscooperativismo.registro.api.v1.controleanuario.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Data
@Table(name = "CONTROLE_ANUARIO")
public class ControleAnuario {

    @Id
    @Column(name = "TX_CONTROLE_ANUARIO")
    private String chaveAnuario;

    @Column(name = "TX_PREENCHER_ANUARIO")
    private String preencherAnuario;

    @Column(name = "IN_MOSTRAR_POPUP", columnDefinition = "bit", nullable = false)
    private Boolean mostrarpopup;

    @Column(name = "IN_DESTACAR_ANUARIO", columnDefinition = "bit", nullable = false)
    private Boolean destacarAnuario;

    @Column(name = "TX_CONTEUDO_POPUP")
    private String textoPop;

    @Column(name = "TX_VISUALIZAR_ANUARIO")
    private String visualizarAnuario;

    @Column(name = "IN_HABILITAR_PREENCHIMENTO", columnDefinition = "bit")
    private Boolean habilitarPreenchimento;
    
    @Column(name = "IN_COOPERATIVA_PREENCHER_ANUARIO", columnDefinition = "bit")
    private Boolean cooperativaPreencherAnuario;

    @Column(name = "IN_COOPERATIVA_VISUALIZAR_ANUARIO", columnDefinition = "bit")
    private Boolean cooperativaVisualizarAnuario;

}
