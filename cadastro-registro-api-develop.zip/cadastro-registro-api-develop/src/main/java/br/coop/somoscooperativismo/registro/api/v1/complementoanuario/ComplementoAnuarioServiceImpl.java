package br.coop.somoscooperativismo.registro.api.v1.complementoanuario;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.entidade.ComplementoAnuario;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.entidade.ComplementoAnuarioRamoUrl;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.ComplementoAnuarioRamoUrlTO;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.ComplementoAnuarioRamoUrlMapper;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ComplementoAnuarioServiceImpl implements ComplementoAnuarioService {

    private final ComplementoAnuarioRepository complementoAnuarioRepository;
    private final ComplementoAnuarioMapper complementoAnuarioMapper;
    private final ComplementoAnuarioRamoUrlMapper complementoAnuarioRamoUrlMapper;

    @Override
    public ComplementoAnuarioTO create(ComplementoAnuarioTO complementoAnuarioTO) {
        ComplementoAnuario complementoAnuario = this.toModel(complementoAnuarioTO);
        if (CollectionUtils.isNotEmpty(complementoAnuario.getComplementoAnuarioRamoUrls())) {
            complementoAnuario.getComplementoAnuarioRamoUrls()
                    .forEach(complementoAnuarioRamoUrl -> complementoAnuarioRamoUrl.setComplementoAnuario(complementoAnuario));
        }
        Optional<ComplementoAnuario> optComplementoAnuario = complementoAnuarioRepository.findByUf(complementoAnuario.getUf());
        if(optComplementoAnuario.isPresent()) {
        	throw new RegraNegocioException("Já existe uma parametrização de complemento do anuário para esta UF.");
        }
        
        ComplementoAnuario complementoAnuarioCreated = this.complementoAnuarioRepository.save(complementoAnuario);
        return this.toDto(complementoAnuarioCreated);
    }

    @Override
    public Optional<ComplementoAnuarioTO> update(Integer id, ComplementoAnuarioTO complementoAnuarioTO) {
        return this.complementoAnuarioRepository.findById(id)
                .map(complemento -> {
                    complemento.setUf(complementoAnuarioTO.getUf());
                    complemento.setTexto(complementoAnuarioTO.getTexto());
                    complemento.setUrl(complementoAnuarioTO.getUrl());

                    checkComplementoAnuarioRamosUrls(complemento, complementoAnuarioTO.getComplementoAnuarioRamoUrls());

                    ComplementoAnuario complementoUpdated = this.complementoAnuarioRepository.save(complemento);
                    return this.toDto(complementoUpdated);
                });
    }

    private void checkComplementoAnuarioRamosUrls(ComplementoAnuario complementoAnuario, List<ComplementoAnuarioRamoUrlTO> complementoAnuarioRamoUrls) {
        List<ComplementoAnuarioRamoUrl> complementoAnuarioRamoUrlList = complementoAnuarioRamoUrls
                .stream().map(this.complementoAnuarioRamoUrlMapper::toModel).collect(Collectors.toList());

        complementoAnuario.getComplementoAnuarioRamoUrls().forEach(complementoAnuarioRamoUrl -> {
            int complementoAnuarioRamoUrlIndexOf = complementoAnuarioRamoUrlList.indexOf(complementoAnuarioRamoUrl);
            if (complementoAnuarioRamoUrlIndexOf >= 0) {
                ComplementoAnuarioRamoUrl complementoAnuarioRamoUrl1 = complementoAnuarioRamoUrlList.get(complementoAnuarioRamoUrlIndexOf);
                complementoAnuarioRamoUrl.setUrl(complementoAnuarioRamoUrl1.getUrl());
                complementoAnuarioRamoUrlList.remove(complementoAnuarioRamoUrl1);
            }
        });

        complementoAnuarioRamoUrlList.forEach(complementoAnuario::addComplementoAnuarioRamoUrl);
    }

    @Transactional(readOnly = true)
    @Override
    public Optional<ComplementoAnuarioTO> findById(Integer id) {
        return this.complementoAnuarioRepository.findById(id).map(this::toDto);
    }

    @Transactional(readOnly = true)
    @Override
    public Optional<ComplementoAnuarioTO> findByUf(String uf) {
        return this.complementoAnuarioRepository.findByUf(uf).map(this::toDto);
    }

    @Override
    public boolean existsByUf(String uf) {
        return this.complementoAnuarioRepository.existsByUf(uf);
    }

    @Transactional(readOnly = true)
    @Override
    public Page<ComplementoAnuarioTO> findAll(String uf, String texto, String url, Pageable pageable) {
    	return this.complementoAnuarioRepository.findByUfAndTextoAndUrl(uf, texto, url, pageable).map(this::toDtoNoChilds);
    			//        return this.complementoAnuarioRepository
//                .findByUfContainingAndTextoContainingAndUrlContaining(uf, texto, url, pageable).map(this::toDtoNoChilds);
    }

    @Override
    public Optional<ComplementoAnuarioTO> deleteById(Integer id) {
        return this.complementoAnuarioRepository.findById(id).map(complementoAnuario -> {
           this.complementoAnuarioRepository.delete(complementoAnuario);
           return this.toDto(complementoAnuario);
        });
    }

    private ComplementoAnuarioTO toDto(ComplementoAnuario complementoAnuario) {
        return this.complementoAnuarioMapper.toDto(complementoAnuario);
    }

    private ComplementoAnuario toModel(ComplementoAnuarioTO complementoAnuarioTO) {
        return this.complementoAnuarioMapper.toModel(complementoAnuarioTO);
    }

    private ComplementoAnuarioTO toDtoNoChilds(ComplementoAnuario complementoAnuario) {
        return this.complementoAnuarioMapper.toDtoNoChilds(complementoAnuario);
    }
}
