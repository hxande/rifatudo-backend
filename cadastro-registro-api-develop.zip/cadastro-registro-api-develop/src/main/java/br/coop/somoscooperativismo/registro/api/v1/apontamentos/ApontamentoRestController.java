package br.coop.somoscooperativismo.registro.api.v1.apontamentos;

import br.coop.somoscooperativismo.registro.api.v1.apontamentos.entidade.Apontamento;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@RestController
@RequestMapping("/api/v1/apontamento")
@Tag(name = "Apontamento")
public class ApontamentoRestController extends ApontamentoAbstractController {

    private final ApontamentoService apontamentoService;

    public static final String SALVAR_APONTAMENTO = "Apontamento salvos com sucesso!";


    final MessagesService messages;

    public ApontamentoRestController(@NonNull ModelMapper modelMapper, @NonNull ApontamentoService apontamentoService, MessagesService messages) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, Apontamento.class, ApontamentoTO.class);
        this.apontamentoService = apontamentoService;
        this.messages = messages;
    }

    @Operation(summary = "Apontamento salvo")
    @PostMapping
    public ResponseEntity<ServiceResponse<Apontamento>> salvarApontamento(@RequestBody Apontamento apontamento) {
        ServiceMessage message = new ServiceMessage(messages.get(SALVAR_APONTAMENTO));
        apontamento =apontamentoService.save(apontamento);
        return new ResponseEntity<>(new ServiceResponse<>(apontamento, message), HttpStatus.CREATED);

    }

}
