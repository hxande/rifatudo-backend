package br.coop.somoscooperativismo.registro.api.v1.desempenho;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.EstruturaIntegracaoTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class DesempenhoClient {

    @Value("${desempenho_service_host:}")
    private String desempenhoHost;

    @Autowired
    private RestTemplate keycloakRestTemplate;

    public List<EstruturaPendenciaTO> buscarPendencia(String grupo, Integer idCooperativa, Integer ano) {
        String url = desempenhoHost + "/api/v1/lancamentos-externos/pendencia/%s/%s/12/%s".formatted(grupo, idCooperativa, ano);
        return keycloakRestTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<EstruturaPendenciaTO>>() {})
                .getBody();
    }

    public Boolean verificarPendencia(String grupo, Integer idCooperativa, Integer ano) {
        String url = desempenhoHost + "/api/v1/lancamentos-externos/existe-pendencia/%s/%s/12/%s".formatted(grupo, idCooperativa, ano);
        return keycloakRestTemplate.getForObject(url, Boolean.class);
    }

    public List<EstruturaIntegracaoTO> obterLancamentos(String grupo, Integer idCooperativa, Integer ano) {
        String url = desempenhoHost + "/api/v1/lancamentos-externos/obter/%s/%s/12/%s".formatted(grupo, idCooperativa, ano);

        ResponseEntity<List<EstruturaIntegracaoTO>> response =
                keycloakRestTemplate.exchange(
                        url,
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<EstruturaIntegracaoTO>>() {
                        }
                );

        return response.getBody();
    }

    public List<EstruturaIntegracaoTO> obterLancamentosNegocios(Integer idCooperativa, Integer ano) {
        String url = desempenhoHost + "/api/v1/lancamentos-externos/obter-negocio/%s/12/%s".formatted(idCooperativa, ano);

        ResponseEntity<List<EstruturaIntegracaoTO>> response =
                keycloakRestTemplate.exchange(
                        url,
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<List<EstruturaIntegracaoTO>>() {
                        }
                );

        return response.getBody();
    }

    public void salvarGrupos(String grupo, Integer idCooperativa, Integer ano, String jsonDadosGrupo) {
        if (ValidacaoCampos.validaCampoPreenchido(jsonDadosGrupo)) {
            String url = desempenhoHost + "/api/v1/lancamentos-externos/salvar/%s/%s/12/%s".formatted(grupo, idCooperativa, ano);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> entity = new HttpEntity<String>(jsonDadosGrupo, headers);
            keycloakRestTemplate.postForLocation(url, entity);
        }
    }
}
