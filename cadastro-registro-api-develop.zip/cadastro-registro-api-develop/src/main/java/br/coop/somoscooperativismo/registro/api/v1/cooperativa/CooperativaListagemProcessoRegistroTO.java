package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import com.fasterxml.jackson.annotation.JsonFormat;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class CooperativaListagemProcessoRegistroTO {

    private Integer id;
    private String numeroProcesso;
    private String cnpj;
    private String nomeFantasia;
    private String razaoSocial;
    private String ramo;
    private String grau;
    private String responsavel;
    private String telefone;
    private String uf;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataPrimeiroRegistro;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date prazo;
    private String faseProcesso;
    private Date dataAtualizacao;
    private String emailGeral;
    private String telefoneGeral;
    private String regidoLei12690;
    private String categoria;
    private String nire;
    private String cep;
    private String regiaoPais;
    private String regiaoUnidadeEstadual;
    private String nomeMunicipio;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataAberturaRegistro;
    private Integer tempoDecorrido;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataUltimaAnaliseUE;
    private String envioDeDocs;
    private String validacaoDoc;
    private String analiseConformidade;
    private String visitaTecnica;
    private String deliberacaoUE;
    private String deliberecaoUN;
    private Date dataApontamento;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataConstituicao;

    public CooperativaListagemProcessoRegistroTO(Integer id, String numeroProcesso, String cnpj, String nomeFantasia, String ramo, String grau, String uf, Date dataPrimeiroRegistro,
                                                 String faseProcesso, Date dataAtualizacao, Date dataConstituicao, String razaoSocial) {
        super();
        this.id = id;
        this.numeroProcesso = id != null ? id.toString() : "";
        setCnpj(cnpj);
        this.nomeFantasia = nomeFantasia;
        this.ramo = ramo;
        this.grau = grau;
        this.uf = uf;
        this.dataPrimeiroRegistro = dataPrimeiroRegistro;
        setPrazo(dataPrimeiroRegistro);
        setFaseProcesso(faseProcesso);
        this.dataAtualizacao = dataAtualizacao;
        this.dataConstituicao = dataConstituicao;
        this.razaoSocial = razaoSocial;
    }

    public CooperativaListagemProcessoRegistroTO(Integer id, String numeroProcesso, String cnpj, String nomeFantasia, String ramo, String grau, String uf, Date dataPrimeiroRegistro,
                                                 String faseProcesso, Date dataAtualizacao, Date dataApontamento, Date dataConstituicao) {
        super();
        this.id = id;
        this.numeroProcesso = numeroProcesso;
        setCnpj(cnpj);
        this.nomeFantasia = nomeFantasia;
        this.ramo = ramo;
        this.grau = grau;
        this.uf = uf;
        this.dataPrimeiroRegistro = dataPrimeiroRegistro;
        setPrazo(dataPrimeiroRegistro);
        setFaseProcesso(faseProcesso);
        this.dataAtualizacao = dataAtualizacao;
        this.dataApontamento = dataApontamento;
        this.dataConstituicao = dataConstituicao;
    }

    public CooperativaListagemProcessoRegistroTO(Integer id, String numeroProcesso, String cnpj, String nomeFantasia, String ramo, String grau, String uf, Date dataPrimeiroRegistro,
                                                 String faseProcesso, Date dataAtualizacao, Date dataConstituicao) {
        super();
        this.id = id;
        this.numeroProcesso = numeroProcesso;
        setCnpj(cnpj);
        this.nomeFantasia = nomeFantasia;
        this.ramo = ramo;
        this.grau = grau;
        this.uf = uf;
        this.dataPrimeiroRegistro = dataPrimeiroRegistro;
        setPrazo(dataPrimeiroRegistro);
        setFaseProcesso(faseProcesso);
        this.dataAtualizacao = dataAtualizacao;
        this.dataConstituicao = dataConstituicao;
    }

    public CooperativaListagemProcessoRegistroTO(
            String cnpj,
            String razaoSocial,
            String nomeFantasia,
            Integer numeroProcesso,
            String emailGeral,
            String telefoneGeral,
            String regidoLei12690,
            String ramo,
            String categoria,
            String nire,
            String cep,
            String regiaoPais,
            String uf,
            String regiaoUnidadeEstadual,
            String nomeMunicipio,
            Date dataAtualizacao,
            Date dataAberturaRegistro,
            Integer tempoDecorrido,
            Date dataUltimaAnaliseUE,
            String envioDeDocs,
            String validacaoDoc,
            String analiseConformidade,
            String visitaTecnica,
            String deliberacaoUE,
            String deliberecaoUN
    ) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.nomeFantasia = nomeFantasia;
        this.uf = uf;
        this.numeroProcesso = numeroProcesso != null ? numeroProcesso.toString() : null;
        this.emailGeral = emailGeral;
        this.telefoneGeral = telefoneGeral;
        this.regidoLei12690 = regidoLei12690;
        this.ramo = ramo;
        this.categoria = categoria;
        this.nire = nire;
        this.cep = cep;
        this.regiaoPais = regiaoPais;
        this.regiaoUnidadeEstadual = regiaoUnidadeEstadual;
        this.nomeMunicipio = nomeMunicipio;
        this.dataAtualizacao = dataAtualizacao;
        this.dataAberturaRegistro = dataAberturaRegistro;
        this.tempoDecorrido = tempoDecorrido;
        this.dataUltimaAnaliseUE = dataUltimaAnaliseUE;
        this.envioDeDocs = envioDeDocs;
        this.validacaoDoc = validacaoDoc;
        this.analiseConformidade = analiseConformidade;
        this.visitaTecnica = visitaTecnica;
        this.deliberacaoUE = deliberacaoUE;
        this.deliberecaoUN = deliberecaoUN;
    }


    public CooperativaListagemProcessoRegistroTO(
            String cnpj,
            String razaoSocial,
            String nomeFantasia,
            Integer numeroProcesso,
            String emailGeral,
            String telefoneGeral,
            String regidoLei12690,
            String ramo,
            String categoria,
            String nire,
            String cep,
            String regiaoPais,
            String uf,
            String regiaoUnidadeEstadual,
            String nomeMunicipio,
            Date dataAtualizacao,
            Date dataAberturaRegistro,
            Integer tempoDecorrido,
            Date dataUltimaAnaliseUE,
            String envioDeDocs,
            String validacaoDoc,
            String analiseConformidade,
            String visitaTecnica,
            String deliberacaoUE,
            String deliberecaoUN,
            Date dataApontamento
    ) {
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.nomeFantasia = nomeFantasia;
        this.uf = uf;
        this.numeroProcesso = numeroProcesso != null ? numeroProcesso.toString() : null;
        this.emailGeral = emailGeral;
        this.telefoneGeral = telefoneGeral;
        this.regidoLei12690 = regidoLei12690;
        this.ramo = ramo;
        this.categoria = categoria;
        this.nire = nire;
        this.cep = cep;
        this.regiaoPais = regiaoPais;
        this.regiaoUnidadeEstadual = regiaoUnidadeEstadual;
        this.nomeMunicipio = nomeMunicipio;
        this.dataAtualizacao = dataAtualizacao;
        this.dataAberturaRegistro = dataAberturaRegistro;
        this.tempoDecorrido = tempoDecorrido;
        this.dataUltimaAnaliseUE = dataUltimaAnaliseUE;
        this.envioDeDocs = envioDeDocs;
        this.validacaoDoc = validacaoDoc;
        this.analiseConformidade = analiseConformidade;
        this.visitaTecnica = visitaTecnica;
        this.deliberacaoUE = deliberacaoUE;
        this.deliberecaoUN = deliberecaoUN;
        this.dataApontamento = dataApontamento;
    }



    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNumeroProcesso() {
        return numeroProcesso;
    }

    public void setNumeroProcesso(String numeroProcesso) {
        this.numeroProcesso = numeroProcesso;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        if (cnpj != null) {
            this.cnpj = cnpj.replaceAll("\\b(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5");
        }
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getRamo() {
        return ramo;
    }

    public void setRamo(String ramo) {
        this.ramo = ramo;
    }

    public String getGrau() {
        return grau;
    }

    public void setGrau(String grau) {
        this.grau = grau;
    }

    public Date getDataPrimeiroRegistro() {
        return dataPrimeiroRegistro;
    }

    public void setDataPrimeiroRegistro(Date dataPrimeiroRegistro) {
        this.dataPrimeiroRegistro = dataPrimeiroRegistro;
    }

    public Date getPrazo() {
        return prazo;
    }

    public void setPrazo(Date dataRegistro) {
        if (dataRegistro != null) {
            LocalDate prazos = new java.sql.Date(dataRegistro.getTime()).toLocalDate();
            prazos = prazos.plusDays(180);
            this.prazo = DataUtil.convertLocalDateToDate(prazos);
        }
    }

    public String getFaseProcesso() {
        return faseProcesso;
    }

    public void setFaseProcesso(String faseProcesso) {
        if (faseProcesso != null) {
            this.faseProcesso = ProgressoMacroEnum.valueOf(faseProcesso).getNome();
        }
    }

    public String getResponsavel() {
        return responsavel;
    }

    public void setResponsavel(String responsavel) {
        this.responsavel = responsavel;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public Date getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(Date dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }

    public List<String> objectToStringArrayUN() {
        return Arrays.asList(numeroProcesso, cnpj, nomeFantasia, ramo, grau, responsavel, telefone, uf,
                dataPrimeiroRegistro != null ? DataUtil.transformarDataParaString(dataPrimeiroRegistro) : null,
                prazo != null ? DataUtil.transformarDataParaString(prazo) : null, faseProcesso,
                dataAtualizacao != null ? DataUtil.transformarDataParaString(dataAtualizacao) : null,
                dataApontamento != null ? DataUtil.transformarDataParaString(dataApontamento) : null,
                dataConstituicao != null ? DataUtil.transformarDataParaString(dataConstituicao) : null
                );
    }

    public List<String> objectToStringArrayUNSemDataApontamento() {
        return Arrays.asList(numeroProcesso, cnpj, nomeFantasia, ramo, grau, responsavel, telefone, uf,
                dataPrimeiroRegistro != null ? DataUtil.transformarDataParaString(dataPrimeiroRegistro) : null,
                prazo != null ? DataUtil.transformarDataParaString(prazo) : null, faseProcesso,
                dataAtualizacao != null ? DataUtil.transformarDataParaString(dataAtualizacao) : null,
                dataConstituicao != null ? DataUtil.transformarDataParaString(dataConstituicao) : null
        );
    }

    public List<String> objectToStringArrayUE() {
        return Arrays.asList(numeroProcesso, cnpj, nomeFantasia, ramo, grau, responsavel, telefone,
                dataPrimeiroRegistro != null ? DataUtil.transformarDataParaString(dataPrimeiroRegistro) : null,
                prazo != null ? DataUtil.transformarDataParaString(prazo) : null, faseProcesso,
                dataConstituicao != null ? DataUtil.transformarDataParaString(dataConstituicao) : null);
    }

    public List<String> objectToStringArrayAcompanhamento() {
        return Arrays.asList(
                cnpj != null ? this.cnpj : "N/A",
                this.razaoSocial != null ? this.razaoSocial : "N/A",
                this.nomeFantasia != null ? this.nomeFantasia : "N/A",
                this.numeroProcesso != null ? this.numeroProcesso : "N/A",
                this.emailGeral != null ? this.emailGeral : "N/A",
                this.telefoneGeral != null ? this.telefoneGeral : "N/A",
                this.regidoLei12690 != null ? this.regidoLei12690 : "N/A",
                this.ramo != null ? this.ramo : "N/A",
                this.categoria != null ? this.categoria : "N/A",
                this.nire != null ? this.nire : "N/A",
                this.cep != null ? this.cep : "N/A",
                this.regiaoPais != null ? this.regiaoPais : "N/A",
                this.uf != null ? this.uf : "N/A",
                this.regiaoUnidadeEstadual != null ? this.ramo : "N/A",
                this.nomeMunicipio != null ? this.nomeMunicipio : "N/A",
                this.dataAtualizacao != null ? DataUtil.transformarDataParaString(this.dataAtualizacao) : "N/A",
                this.dataAberturaRegistro != null ? DataUtil.transformarDataParaString(this.dataAberturaRegistro) : "N/A",
                this.tempoDecorrido != null ? tempoDecorrido.toString() : "N/A",
                this.dataUltimaAnaliseUE != null ? DataUtil.transformarDataParaString(this.dataUltimaAnaliseUE) : "N/A",
                this.envioDeDocs!= null ? this.envioDeDocs : "N/A",
                this.validacaoDoc!= null ? this.validacaoDoc : "N/A",
                this.analiseConformidade!= null ? this.analiseConformidade : "N/A",
                this.visitaTecnica!= null ? this.visitaTecnica : "N/A",
                this.deliberacaoUE!= null ? this.deliberacaoUE : "N/A",
                this.deliberecaoUN!= null ? this.deliberecaoUN : "N/A"
                //this.dataApontamento  != null ? DataUtil.transformarDataParaString(this.dataApontamento) : "N/A"
        );
    }
}
