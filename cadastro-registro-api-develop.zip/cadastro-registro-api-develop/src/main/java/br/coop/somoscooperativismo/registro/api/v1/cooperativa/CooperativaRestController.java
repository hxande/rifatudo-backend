package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.AprovacaoService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.vinculosolicitacao.CooperativaSuperiorBuscaTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("/api/v1/cooperativa")
@Tag(name = "Cooperativa")
public class CooperativaRestController {

	public static final String CATEGORIA_CRIADA = "cooperativa.criada";
	public static final String NAO_CORRESPONDE = "cooperativa.naoCorresponde";
	public static final String CATEGORIA_ATUALIZADA = "cooperativa.atualizada";
	public static final String CATEGORIA_DESATIVADA = "cooperativa.desativada";
	public static final String PROCESSO_ARQUIVADO = "processo.arquivado";
	public static final String PROCESSO_DESARQUIVADO = "processo.desarquivado";
	public static final String REGISTRO_SALVO = "registroSalvo.sucesso";
	public static final String COOPERATIVA_SUSPENSA = "cooperativa.suspensa";
	public static final String COOPERATIVA_ATIVADA = "cooperativa.ativada";
	public static final String COOPERATIVA_STATUS_SITUACAO_ATUALIZADA = "cooperativa.status.situacao.atualizada";
	public static final String COOPERATIVA_IRREGULARIZADA_SUCESSO = "cooperativa.status.regularidade.irregularizada";
	public static final String COOPERATIVA_CANCELADA_SUCESSO = "cooperativa.status.situacao.cacelada";
	public static final String SOLICITACAO_RECUSADA = "cooperativa.solicitacao.recusada";
	public static final String SOLICITACAO_ACEITA = "cooperativa.solicitacao.aceita";
	public static final String SOLICITACAO_CADASTRADA = "cooperativa.solicitacao.cadastrada";
	public static final String SOLICITACAO_CANCELAMENTO_ACEITA = "cooperativa.solicitacao.cancelamento.aceita";
	public static final String SOLICITACAO_CANCELAMENTO_REALIZADA = "cooperativa.solicitacao.cancelamento.realizada";

	public static final String MEDIA_TYPE_EXCEL = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String ATTACHMENT_EXCEL = "attachment; filename=Relatório.xlsx";
	public static final String CACHE_CTRL_PARAM = "no-cache, no-store, must-revalidate";
	public static final String NO_CACHE = "no-cache";
	public static final String SOLICITACAO_CANCELADA = "cooperativa.solicitacao.cencelasolicitacao";
	public static final String ALTERACAO_CADASTRADA = "Alteração cadastrada com sucesso.";

	@Autowired
	private CooperativaService cooperativaService;

	@Autowired
	private PessoaJuridicaService pessoaJuridicaService;

	@Autowired
	private MessagesService messages;

	@Autowired
	private AprovacaoService aprovacaoService;


	@Operation(summary = "Detalha uma Cooperativa pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<Cooperativa>> getCooperativa(@PathVariable Integer id) {
		Cooperativa cooperativa = cooperativaService.getCooperativa(id);
		for (Endereco end : cooperativa.getPessoaJuridica().getEnderecos()) {
			end.getBairro();
		}
		return ResponseEntity.ok(new ServiceResponse<>(cooperativa));
	}

	@Operation(summary = "Detalha uma Cooperativa com as informações básicas para apresentação pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/apresentacao/{id}")
	public ResponseEntity<ServiceResponse<CooperativaApresentacaoTO>> getCooperativaApresentacao(@PathVariable Integer id) {
		Cooperativa cooperativa = cooperativaService.getCooperativa(id);
		for (Endereco end : cooperativa.getPessoaJuridica().getEnderecos()) {
			end.getBairro();
		}
		return ResponseEntity.ok(new ServiceResponse<>(new CooperativaApresentacaoTO(cooperativa)));
	}

	@Operation(summary = "Detalha uma Cooperativa pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("buscaPorCnpj/{cnpj}")
	public ResponseEntity<ServiceResponse<Cooperativa>> getCooperativaPorCnpj(@PathVariable String cnpj) {
		PessoaJuridica pessoaJuridica = pessoaJuridicaService.buscaPorCnpj(cnpj);
		if (pessoaJuridica == null) {
			throw new RegraNegocioException("Pessoa Jurídica não encontrada!", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaService.getCooperativa(pessoaJuridica.getId())));
	}

	@PostMapping
	@Operation(summary = "Cria uma Cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> createCooperativa(@RequestBody @Valid Cooperativa cooperativa) {
		cooperativa = cooperativaService.save(cooperativa);

		HttpHeaders headers = new HttpHeaders();
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(cooperativa.getId()).toUri();
		headers.setLocation(location);

		ServiceMessage message = new ServiceMessage(messages.get(CATEGORIA_CRIADA));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativa, message), headers, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	@Operation(summary = "Altera uma Cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> updateCooperativa(@PathVariable Integer id,
			@RequestBody @Valid Cooperativa cooperativa) {

		if (!cooperativa.getId().equals(id)) {
			return new ResponseEntity<>(
					new ServiceResponse<>(null, new ServiceMessage(MessageType.ERROR,
							"URL ID: '" + id + " " + messages.get(NAO_CORRESPONDE) + cooperativa.getId() + "'.")),
					HttpStatus.BAD_REQUEST);
		}

		ServiceMessage message = new ServiceMessage(messages.get(CATEGORIA_ATUALIZADA));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.updateCooperativa(cooperativa), message),
				HttpStatus.OK);
	}

	@GetMapping
	@Operation(summary = "Lista")
	public ServiceResponse<List<Cooperativa>> getCooperativas() {
		return new ServiceResponse<>(cooperativaService.findAll());
	}

	@PostMapping("/cadastra/sem-usuario")
	@Operation(summary = "Cria uma Cooperativa sem usuário")
	public ResponseEntity<ServiceResponse<Cooperativa>> criaCooperativaSemUsuario(
			@RequestBody CooperativaBasicaTO cooperativa) {
		Cooperativa cooperativaDB = cooperativaService.cadastraSemUsuario(cooperativa);
		HttpHeaders headers = new HttpHeaders();
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(cooperativaDB.getId()).toUri();
		headers.setLocation(location);
		ServiceMessage message = new ServiceMessage("Cadastro iniciado.");
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaDB, message), headers, HttpStatus.CREATED);
	}

	@GetMapping("/buscarCooperativasPorCategoria")
	@Operation(summary = "Lista")
	public ServiceResponse<List<CooperativaBasicaTO>> getCooperativas(
			@RequestParam(required = true) String busca,
			@RequestParam(required = true) Integer idCategoria) {
		return new ServiceResponse<>(cooperativaService.getCooperativasPorGrau(busca, idCategoria));
	}

	@GetMapping("/buscarCooperativasVinculadas/{idCooperativa}")
	@Operation(summary = "Lista")
	public ServiceResponse<List<CooperativaBasicaTO>> getCooperativaVinculadas(@PathVariable Integer idCooperativa) {
		return new ServiceResponse<>(
				CooperativaUtil.formatarSaidaBasica(cooperativaService.getCooperativasVinculadas(idCooperativa)));
	}

	@GetMapping("/status/{idCooperativa}")
	@Operation(summary = "Obtem o status da cooperativa")
	public ServiceResponse<String> statusCooperativa(@PathVariable String idCooperativa, Pageable pageable)
			throws IllegalAccessException {
		return new ServiceResponse<>(cooperativaService.getStatusCooperativa(Integer.valueOf(idCooperativa)));
	}

	@GetMapping("/filtrarCooperativaListagemPaginado")
	@Operation(summary = "Lista CooperativaListagemTO paginado")
	public ServiceResponse<Page<CooperativaListagemTO>> filtrarCooperativaListagemPaginado(
			CooperativaFiltroTO cooperativaFiltro, Pageable pageable) {
		return new ServiceResponse<>(
				cooperativaService.filtrarCooperativaListagemPaginado(cooperativaFiltro, pageable));
	}

	@GetMapping("/filtrarNaoPaginado")
	@Operation(summary = "Lista filtrado nao paginado")
	public ServiceResponse<List<Cooperativa>> filtrarNaoPaginado(CooperativaFiltroTO cooperativaFiltro)
			throws IllegalAccessException {
		return new ServiceResponse<>(cooperativaService.filtrarNaoPaginado(cooperativaFiltro));
	}

	@GetMapping("/consultaCooperativa")
	@Operation(summary = "Lista filtrado nao paginado")
	public ServiceResponse<Page<Cooperativa>> consultaCooperativa(CooperativaFiltroTO cooperativaFiltro,
			Pageable pageable) {
		return new ServiceResponse<>(cooperativaService.consultaCooperativa(cooperativaFiltro, pageable));
	}

	@GetMapping("/consultaCooperativaNaoPaginada")
	@Operation(summary = "Lista filtrado nao paginado")
	public ServiceResponse<List<Cooperativa>> consultaCooperativaNaoPaginada(CooperativaFiltroTO cooperativaFiltro) {
		return new ServiceResponse<>(cooperativaService.consultaCooperativaNaoPaginada(cooperativaFiltro));
	}

	@GetMapping("/arquivaProcesso/{id}")
	@Operation(summary = "Arquivar Processo da Cooperativa", description = "Id válido deve ser informado")
	public ResponseEntity<ServiceResponse<Cooperativa>> arquivarProcesso(@PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(PROCESSO_ARQUIVADO));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.arquivarProcesso(id), message),
				HttpStatus.OK);
	}

	@GetMapping("/desarquivaProcesso/{id}")
	@Operation(summary = "Desarquivar Processo da Cooperativa", description = "Id válido deve ser informado")
	public ResponseEntity<ServiceResponse<Cooperativa>> desarquivarProcesso(@PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(PROCESSO_DESARQUIVADO));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.desarquivarProcesso(id), message),
				HttpStatus.OK);
	}

	@PutMapping("/salvarDeliberacao/{deferido}")
	@Operation(summary = "Altera uma Cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> salvarDeliberacao(@PathVariable Boolean deferido,
			@RequestBody @Valid Cooperativa cooperativa) {
		ServiceMessage message = new ServiceMessage(messages.get(REGISTRO_SALVO));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.salvarDeliberacao(cooperativa, deferido), message),
				HttpStatus.OK);

	}

	@PutMapping("/salvarApontamentos")
	@Operation(summary = "Altera uma Cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> salvarApontamentos(
			@RequestBody @Valid Cooperativa cooperativa) {
		ServiceMessage message = new ServiceMessage(messages.get(REGISTRO_SALVO));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.salvarApontamentos(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/salvarRecursoDeliberacao")
	@Operation(summary = "Altera uma Cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> salvarRecursoDeliberacao(
			@RequestBody @Valid Cooperativa cooperativa) {
		ServiceMessage message = new ServiceMessage(messages.get(REGISTRO_SALVO));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.salvarRecursoDeliberacao(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/salvarResultadoRecursoDeliberacao")
	@Operation(summary = "Salva o resultado de recurso com base em obj Cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> salvarResultadoRecursoDeliberacao(
			@RequestBody @Valid Cooperativa cooperativa) {
		ServiceMessage message = new ServiceMessage(messages.get(REGISTRO_SALVO));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.salvarResultadoRecursoDeliberacao(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/emitirCertifiado")
	@Operation(summary = "Emite certificado a uma cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> emitirCertifiado(@RequestBody @Valid Cooperativa cooperativa) {
		ServiceMessage message = new ServiceMessage(messages.get(REGISTRO_SALVO));
		aprovacaoService.criarAprovacaoAtualCooperativa(cooperativa.getId());
		Cooperativa retorno = cooperativaService.emitirCertificado(cooperativa);
		if (retorno != null) {
			aprovacaoService.atualizarDataAprovacao(cooperativa.getId());
		}
		return new ResponseEntity<>(new ServiceResponse<>(retorno, message), HttpStatus.OK);
	}

	@PostMapping("/emitirCertificadoImportacao")
	@Operation(summary = "Emite o certificado a uma cooperativa adicionada por importação")
	public ResponseEntity<Cooperativa> emitirCertificadoImportacao(@RequestBody @Valid Cooperativa cooperativa) {
		return ResponseEntity.ok(cooperativaService.emitirCertificadoViaImportacao(cooperativa));
	}

	@Operation(summary = "busca cooperativa com base na razao social da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/busca/razaoSocialPaginado")
	public Page<CooperativaBasicaTO> buscaCooperativaPorRazaoSocialPaginado(String razaoSocial, Pageable pageable) {
		return cooperativaService.findByRazaoSocialPublicoPaginado(razaoSocial, pageable);
	}

	@Operation(summary = "busca cooperativa com base na razao social da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/busca/razaoSocial/{razaoSocial}")
	public ResponseEntity<List<CooperativaBasicaTO>> buscaCooperativaPorRazaoSocial(@PathVariable String razaoSocial) {

		return new ResponseEntity<>(cooperativaService.findByRazaoSocialPublico(razaoSocial), HttpStatus.OK);
	}

	@PutMapping("/inativarCooperativa/{id}")
	@Operation(summary = "Inativa uma cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> inativarCooperativa(
			@RequestBody @Valid CooperativaRegistro cooperativaRegistro, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(COOPERATIVA_SUSPENSA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.inativarCooperativa(cooperativaRegistro), message),
				HttpStatus.OK);
	}

	@PutMapping("/solicitaInativacaoCooperativa/{id}")
	@Operation(summary = "Inativa uma cooperativa")
	@Deprecated
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> solicitaInativacaoCooperativa(
			@RequestBody CooperativaRegistroTO cooperativaRegistroTo, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_CADASTRADA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.solicitaInativacaoCooperativa(cooperativaRegistroTo), message),
				HttpStatus.OK);
	}

	@Deprecated
	@PutMapping("/solicitaCancelamentoCooperativa/{id}")
	@Operation(summary = "Cancela uma cooperativa")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> solicitaCancelamentoCooperativa(
			@RequestBody @Valid CooperativaRegistro cooperativaRegistro, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_CANCELAMENTO_REALIZADA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.solicitaCancelamentoCooperativa(cooperativaRegistro), message),
				HttpStatus.OK);
	}
	
	@PostMapping("/solicita-cancelamento-cooperativa")
	@Operation(summary = "Cancela uma cooperativa")
	public ResponseEntity<ServiceResponse<Void>> solicitaCancelamentoCooperativa(
			@RequestBody @Valid CooperativaSolicitacaoCancelamentoTO cooperativaSolicitacaoCancelamentoTO) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_CANCELAMENTO_REALIZADA));
		cooperativaService.solicitaCancelamentoCooperativa(cooperativaSolicitacaoCancelamentoTO);
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@PutMapping("/cancelaSolicitacaoInativacaoEnviada/{id}")
	@Operation(summary = "Cancela um solicitação de inativação de cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> cancelaSolicitacaoInativacaoEnviada(
//			@RequestBody @Valid Cooperativa cooperativa,
			@PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_CANCELADA)); // #refatorar
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.cancelaSolicitacaoInativacaoEnviada(id), message),
				HttpStatus.OK);
	}

	@PutMapping("/cancelaRegistroCooperativa/{id}")
	@Operation(summary = "Inativa uma cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> cancelaRegistroCooperativa(
			@RequestBody @Valid CooperativaRegistro cooperativaRegistro, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(COOPERATIVA_CANCELADA_SUCESSO));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.cancelaRegistroCooperativa(cooperativaRegistro), message),
				HttpStatus.OK);
	}

	@PutMapping("/cancelaSolicitacaoInativacaoApontamentoIrregularidade/{id}")
	@Operation(summary = "Cancela um solicitação de inativação de cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> cancelaSolicitacaoInativacaoApontamentoIrregularidade(
			@RequestBody @Valid Cooperativa cooperativa, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(SOLICITACAO_CANCELADA); // #refatorar
		return new ResponseEntity<>(
				new ServiceResponse<>(
						cooperativaService.cancelaSolicitacaoInativacaoApontamentoIrregularidade(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/cancelaAnaliseDadosAtualizaca/{id}")
	@Operation(summary = "Volta a cooperativa quando no passo 2, para o passo 1 da manutenção")
	public ResponseEntity<ServiceResponse<Cooperativa>> cancelaAnaliseDadosAtualizaca(
			@RequestBody @Valid Cooperativa cooperativa, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get("Análise de dados cancelada com sucesso."));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.cancelaAnaliseDadosAtualizaca(cooperativa), message),
				HttpStatus.OK);
	}

	@GetMapping("/filtrarCooperativaListagemProcessoRegistroExcel")
	@Operation(summary = "Retorna Excel com base no filtro de busca da listagem de cooperativas em processo de registro")
	public ResponseEntity<Resource> filtrarCooperativaListagemProcessoRegistroExcel(
			CooperativaFiltroTO cooperativaFiltro) {
		cooperativaService.podeExportarDadosListagemCooperativaRegistradas();
		byte[] dados = cooperativaService.consultaCooperativaExcel(cooperativaFiltro);

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_EXCEL);
		header.add(HttpHeaders.CACHE_CONTROL, CACHE_CTRL_PARAM);
		header.add(HttpHeaders.PRAGMA, NO_CACHE);
		header.add(HttpHeaders.EXPIRES, "0");

		return ResponseEntity.ok().headers(header).contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
				.contentType(MediaType.parseMediaType(MEDIA_TYPE_EXCEL))
				.body(!ArrayUtils.isEmpty(dados) ? new ByteArrayResource(dados) : null);
	}

	@GetMapping("/filtrarCooperativasAnuarioListagemExcel")
	@Operation(summary = "Retorna Excel com base nos filtros de anuarios de cooperativas ")
	public ResponseEntity<Resource> filtrarCooperativasAnuarioListagemExcel(CooperativaFiltroTO cooperativaFiltro) {
		cooperativaService.podeExportarDadosListagemCooperativaRegistradas();
		byte[] dados = cooperativaService.filtrarCooperativasAnuarioListagemExcel(cooperativaFiltro);

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_EXCEL);
		header.add(HttpHeaders.CACHE_CONTROL, CACHE_CTRL_PARAM);
		header.add(HttpHeaders.PRAGMA, NO_CACHE);
		header.add(HttpHeaders.EXPIRES, "0");

		return ResponseEntity.ok().headers(header).contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
				.contentType(MediaType.parseMediaType(MEDIA_TYPE_EXCEL))
				.body(!ArrayUtils.isEmpty(dados) ? new ByteArrayResource(dados) : null);
	}

	@GetMapping("/quatidadeCooperativasNaoRegistradasAguardandoUnidadeEstadual/")
	@Operation(summary = "Retorna a quantidade de cooperativas não registradas que estão aguardando ação da UE", description = "")
	public ResponseEntity<ServiceResponse<Integer>> quatidadeCooperativasNaoRegistradasAguardandoUnidadeEstadual() {
		return new ResponseEntity<>(
				new ServiceResponse<>(
						cooperativaService.quatidadeCooperativasNaoRegistradasAguardandoUnidadeEstadual()),
				HttpStatus.OK);
	}

	@GetMapping("/quatidadeCooperativasRegistradasAguardandoUnidadeEstadual/")
	@Operation(summary = "Retorna a quantidade de cooperativas registradas que estão aguardando ação da UE", description = "")
	public ResponseEntity<ServiceResponse<Integer>> quatidadeCooperativasRegistradasAguardandoUnidadeEstadual() {
		return new ResponseEntity<>(
				new ServiceResponse<>(
						cooperativaService.quatidadeCooperativasRegistradasAguardandoPorProcessoMicroUnidadeEstadual()),
				HttpStatus.OK);
	}

	@PutMapping("/marcarComoVisualizada")
	@Operation(summary = "marca uma Cooperativa como visualizada")
	public ResponseEntity<ServiceResponse<Cooperativa>> marcarComoVisualizada(@RequestBody @Valid Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.marcarComoVisualizada(id)), HttpStatus.OK);
	}

	@GetMapping("/registroAtualizacaoNaoVisualizada")
	@Operation(summary = "busca número de atualização nao visualizada - registro")
	public ResponseEntity<Integer> registroAtualizacaoNaoVisualizada() {
		return new ResponseEntity<>(cooperativaService.buscaRegistroAtualizacaoNaoVisualizada(), HttpStatus.OK);
	}

	@GetMapping("/verificaAtualizacaoNaoVisualizadaRegistrada")
	@Operation(summary = "busca número de atualização nao visualizada - registro")
	public ResponseEntity<Integer> verificaAtualizacaoNaoVisualizadaRegistrada() {
		return new ResponseEntity<>(cooperativaService.buscaAtualizacaoNaoVisualizadaRegistrada(), HttpStatus.OK);
	}

	@PutMapping("/cancelaSolicitacaoInativacao/{id}")
	@Operation(summary = "cancelar solicitação de inativação")
	public ResponseEntity<ServiceResponse<Cooperativa>> cancelarSolicitacaoInativacao(
			@RequestBody @Valid Cooperativa cooperativa, @PathVariable Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.cancelaSolicitacaoInativacao(cooperativa)),
				HttpStatus.OK);
	}

	@PutMapping("/retonarCooperativaConfirmidade/{id}")
	@Operation(summary = "retorna uma cooperativa para a conformidade legal")
	public ResponseEntity<ServiceResponse<Cooperativa>> retonarCooperativaConfirmidade(@PathVariable Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaService.retonarCooperativaConfirmidadeById(id)),
				HttpStatus.OK);
	}

	@PutMapping("/recusarSolicitacaoInativacao/{id}")
	@Operation(summary = "Altera o status de uma Cooperativa para Irregular porém mantém a cooperativa ativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> recusarSolicitacaoInativacao(
			@RequestBody @Valid CooperativaApresentacaoTO cooperativa, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_RECUSADA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.recusaSolicitacaoInativacao(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/aceitaSolicitacaoInativacao/{id}")
	@Operation(summary = "Inativa uma cooperativa")
	@Deprecated
	public ResponseEntity<ServiceResponse<Cooperativa>> aceitaSolicitacaoInativacao(
			@RequestBody @Valid CooperativaRegistro cooperativaRegistro, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_ACEITA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.aceitaSolicitacaoInativacao(cooperativaRegistro), message),
				HttpStatus.OK);
	}

	@PutMapping("/recusaSolicitacaoCancelamento/{id}")
	@Operation(summary = "Mantém cooperativa inativa")
	@Deprecated
	public ResponseEntity<ServiceResponse<Cooperativa>> recusaSolicitacaoCancelamento(
			@RequestBody @Valid CooperativaApresentacaoTO cooperativa, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_RECUSADA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.recusaSolicitacaoCancelamento(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/statusEmPreenchimento")
	@Operation(summary = "Mantém cooperativa inativa")
	public ResponseEntity<Void> statusEmPreenchimento(@RequestBody @Valid Cooperativa cooperativa) {
		cooperativaService.statusEmPreenchimento(cooperativa);
		return ResponseEntity.ok().build();
	}

	@PutMapping("/aceitaSolicitacaoCancelamento/{id}")
	@Operation(summary = "Inativa uma cooperativa")
	@Deprecated
	public ResponseEntity<ServiceResponse<Cooperativa>> aceitaSolicitacaoCancelamento(
			@RequestBody @Valid CooperativaRegistro cooperativaRegistro, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_CANCELAMENTO_ACEITA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.aceitaSolicitacaoCancelamento(cooperativaRegistro), message),
				HttpStatus.OK);
	}

	@PutMapping("/suspenderCooperativa/{id}")
	@Operation(summary = "Suspende uma cooperativa")
	public ResponseEntity<ServiceResponse<Cooperativa>> suspenderCooperativa(
			@RequestBody @Valid CooperativaRegistro cooperativaRegistro, @PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(COOPERATIVA_SUSPENSA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.suspenderCooperativa(cooperativaRegistro), message),
				HttpStatus.OK);
	}

	@PutMapping("/tornarCooperativaInativa/{id}")
	@Operation(summary = "Unidade Nacional  tornar inativa uma cooperativa cancelada")
	public ResponseEntity<ServiceResponse<Cooperativa>> tornarCooperativaInativa(@RequestBody Cooperativa cooperativa,
			@PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(COOPERATIVA_SUSPENSA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.tornarCooperativaInativa(cooperativa), message),
				HttpStatus.OK);
	}

	@PutMapping("/cancelaSolicitacaoCancelamento/{id}")
	@Deprecated
	@Operation(summary = "Unidade Estadual cancela solicitação de cancelamento da cooperativa q ue foi enviada")
	public ResponseEntity<ServiceResponse<Cooperativa>> cancelaSolicitacaoCancelamento(
			@RequestBody @Valid CooperativaApresentacaoTO cooperativa,
			@PathVariable Integer id) {
		ServiceMessage message = new ServiceMessage(messages.get(SOLICITACAO_CANCELADA));
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaService.cancelaSolicitacaoCancelamentoEnviada(cooperativa), message),
				HttpStatus.OK);
	}

	@GetMapping("/filtrarCooperativaProcessoAcompanhamentoExcel")
	@Operation(summary = "Retorna Excel com dados de cooperativas registradas baseados nas cooperativas listadas")
	public ResponseEntity<Resource> filtrarCooperativaProcessoAcompanhamentoExcel(CooperativaFiltroTO cooperativaFiltro) {
		cooperativaService.podeExportarDadosListagemCooperativaRegistradas();
		byte[] dados = cooperativaService
				.filtrarCooperativaListagemProcessoRegistroAcompanhamentoExcel(cooperativaFiltro);

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_EXCEL);
		header.add(HttpHeaders.CACHE_CONTROL, CACHE_CTRL_PARAM);
		header.add(HttpHeaders.PRAGMA, NO_CACHE);
		header.add(HttpHeaders.EXPIRES, "0");

		return ResponseEntity.ok().headers(header).contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
				.contentType(MediaType.parseMediaType(MEDIA_TYPE_EXCEL))
				.body(!ArrayUtils.isEmpty(dados) ? new ByteArrayResource(dados) : null);
	}

	@PostMapping("/busca-paginada")
	public ResponseEntity<Page<CooperativaBasicaTO>> buscaPaginada(@RequestBody CooperativaCriterioTO filtro) {
		return ResponseEntity.ok(cooperativaService.buscaPaginada(filtro));
	}

	@GetMapping("/destinatarios/{id}")
	@Operation(summary="Retorna a lista de destinatarios que receberão os emails destinados a cooperativa")
	public ResponseEntity<String> buscarDestinatiarios(@PathVariable Integer id) {
		return ResponseEntity.ok(cooperativaService.buscaDestinatarios(id));

	}

	@GetMapping("/dias-solicitacao")
	@Operation(summary="Retorna o número de dias que devem ter passado para poder concluir a solicitacao")
	public ResponseEntity<Integer> buscarDiasSolicitacap() {
		return ResponseEntity.ok(cooperativaService.obterDiasParaConcluirSolicitacao());

	}

    @Operation(summary = "Buscar cooperativa superior por CNPJ")
    @GetMapping("/buscar-cooperativa-superior/{idCooperativa}/{cnpjCooperativaSuperior}")
    public ResponseEntity<CooperativaSuperiorBuscaTO> getCooperativasSuperioresPorCnpjPai(@PathVariable Integer idCooperativa, @PathVariable String cnpjCooperativaSuperior) {
        return ResponseEntity.ok(cooperativaService.getCooperativasSuperioresPorCnpjPai(idCooperativa, cnpjCooperativaSuperior));
    }

    @Operation(summary = "Buscar cooperativa superior por que esta vinculada ao id da cooperativa informada")
    @GetMapping("/buscar-cooperativa-superior-vinculada/{idCooperativa}")
    public ResponseEntity<List<CooperativaBasicaTO>> getCooperativaSuperiorVinculada(@PathVariable Integer idCooperativa) {
        return ResponseEntity.ok(cooperativaService.getCooperativaSuperiorVinculada(idCooperativa));
    }

    @DeleteMapping("/remover-cooperativa-superior-vinculada/{idCooperativaFilha}/{idCooperativaPai}")
    @Operation(summary = "Remove vínculo de filiação superior")
    public ResponseEntity<ServiceResponse<Void>> removerCooperativaSuperiorVinculada(@PathVariable Integer idCooperativaFilha, @PathVariable Integer idCooperativaPai) {
        cooperativaService.removerCooperativaSuperiorVinculada(idCooperativaFilha, idCooperativaPai);
        return ResponseEntity.ok(new ServiceResponse<>());
    }

	
}
