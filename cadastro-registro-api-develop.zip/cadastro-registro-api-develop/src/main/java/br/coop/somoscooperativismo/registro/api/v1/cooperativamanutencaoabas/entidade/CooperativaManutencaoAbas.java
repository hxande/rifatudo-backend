package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.entidade;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "COOPERATIVA_MANUTENCAO_ABAS")
@Data
@NoArgsConstructor
public class CooperativaManutencaoAbas {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_COOPERATIVA_MANUTENCAO_ABAS")
	private Integer id;
	
	@Column(name = "SQ_COOPERATIVA")
	private Integer idCooperativa;
	
	@Column(name = "NR_ANO_CICLO")
	private Integer anoCiclo;
	
	@Column(name = "IN_ABA_DOCUMENTOS")
	private String abaDocumentos;
	
	@Column(name = "IN_ABA_DADOS_GERAIS")
	private String abaDadosGerais;
	
	@Column(name = "IN_ABA_GOVERNANCA")
	private String abaGovernanca;
	
	@Column(name = "IN_ABA_SEGMENTACAO_FILIAL")
	private String abaSegmentacaoFilial;
	
	@Column(name = "IN_ABA_CONTATOS")
	private String abaContatos;
	
	@Column(name = "IN_ABA_SUBMETER")
	private String abaSubmeter;
	
	@Column(name = "DT_ALTERACAO")
	private Date dataAlteracao;
	
	@Column(name = "DT_CRIACAO")
	private Date dataCriacao;
	
	@Column(name = "TX_USUARIO")
	private String usuario;
	
	@PrePersist
	public void setDataCriacao() {
		this.dataCriacao = new Date();
	}
	
	@PreUpdate
	public void setDataAlteracao() {
		this.dataAlteracao = new Date();
	}
	
}
