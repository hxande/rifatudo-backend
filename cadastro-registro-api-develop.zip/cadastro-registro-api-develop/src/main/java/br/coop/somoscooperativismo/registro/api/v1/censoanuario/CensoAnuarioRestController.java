package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestPortfolioTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.to.ListDadosSociaisAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.to.QuadroSocialAnuarioTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/censo-anuario")
@Tag(name = "Censo do Anuário do Cooperativismo")
public class CensoAnuarioRestController {

    private static final String CENSO_ANUARIO_CRIADO = "censoAnuario.criado";
    private static final String CENSO_ANUARIO_NAO_ENCONTRADO = "censoAnuario.naoEncontrado";
    private static final String CENSO_ANUARIO_NAO_CORRESPONDE = "censoAnuario.naoCorresponde";
    private static final String REGISTRO_SALVO = "registroSalvo.sucesso";
    private static final String REGISTRO_PENDENCIA = "registroSalvo.pendencia";

    private final CensoAnuarioService censoAnuarioService;
    private final MessagesService messages;

    @PostMapping
    @Operation(summary = "Cria o Censo do Anuário do Cooperativismo")
    public ResponseEntity<ServiceResponse<CensoAnuarioTO>> create(@RequestBody @Valid CensoAnuarioTO censoAnuarioTO, @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit) {
        CensoAnuarioTO censoAnuarioTOCreated = this.censoAnuarioService.create(censoAnuarioTO, isSubmit);

        this.censoAnuarioService.comunicarUnidadeEstadualSubmissaoAnuario(censoAnuarioTOCreated.getCooperativaId());

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(censoAnuarioTOCreated.getId()).toUri();

        ServiceResponse<CensoAnuarioTO> serviceResponse =
                new ServiceResponse<>(censoAnuarioTOCreated, new ServiceMessage(this.messages.get(CENSO_ANUARIO_CRIADO)));

        return ResponseEntity.created(location).body(serviceResponse);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza os dados do Censo do Anuario do Cooperativismo")
    public ResponseEntity<ServiceResponse<CensoAnuarioTO>> update(@PathVariable Integer id,
                                                                  @RequestBody @Valid CensoAnuarioTO censoAnuarioTO,
                                                                  @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit) {
        if (!censoAnuarioTO.getId().equals(id)) {
            String message = String.format("URL ID: '%d' %s '%d'.", id,
                    messages.get(CENSO_ANUARIO_NAO_CORRESPONDE), censoAnuarioTO.getId());
            return ResponseEntity.badRequest().body(
                    new ServiceResponse<>(null, new ServiceMessage(MessageType.ERROR, message)));
        }

        CensoAnuarioTO censoAnuarioTOUpdated = this.censoAnuarioService.update(id, censoAnuarioTO, isSubmit)
                .orElseThrow(() -> new RegraNegocioException(this.messages.get(CENSO_ANUARIO_NAO_ENCONTRADO), HttpStatus.NOT_FOUND));

        this.censoAnuarioService.comunicarUnidadeEstadualSubmissaoAnuario(censoAnuarioTOUpdated.getCooperativaId());

        ServiceMessage message = new ServiceMessage(messages.get(CENSO_ANUARIO_CRIADO));

        return ResponseEntity.ok(new ServiceResponse<>(censoAnuarioTOUpdated, message));
    }

    @GetMapping("/{ano}/{cooperativaId}")
    @Operation(summary = "Retorna o Censo do Anuário por Ano e Cooperativa")
    public ResponseEntity<ServiceResponse<CensoAnuarioTO>> getByAnoAndCooperativaId(@PathVariable Integer ano,
                                                                                    @PathVariable Integer cooperativaId) {
        CensoAnuarioTO censoAnuarioTO = this.censoAnuarioService.getByAnoAndCooperativaId(ano, cooperativaId).orElse(null);
        return ResponseEntity.ok(new ServiceResponse<>(censoAnuarioTO));
    }
    
    @GetMapping("/obter/{ano}/{cooperativaId}")
    @Operation(summary = "Retorna o Censo do Anuário por Ano e Cooperativa")
    public ResponseEntity<ServiceResponse<CensoAnuarioRecord>> obterPorAnoAndCooperativaId(@PathVariable Integer ano,
                                                                                           @PathVariable Integer cooperativaId) {
        CensoAnuarioRecord censoAnuarioRecord = this.censoAnuarioService.obterPorAnoAndCooperativaId(ano, cooperativaId);
        return ResponseEntity.ok(new ServiceResponse<>(censoAnuarioRecord));
    }

    @PostMapping("/salvarIntegracao")
    @Operation(summary = "Salvar dados intergracao")
    public ResponseEntity<ServiceResponse<Void>> salvarIntergracao(@RequestBody DadosIntegracaoTO dadosIntegracao, @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit) {
        boolean sucesso =  this.censoAnuarioService.salvarIntegracao(dadosIntegracao, isSubmit);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @GetMapping("/exibeAnuario")
    @Operation(summary = "Retorna feature toggle que controla exibição do botão Anuário do Cooperativismo")
    public ResponseEntity<ServiceResponse<Boolean>> getFeatureToggleExibeAnuario() {
        return ResponseEntity.ok(new ServiceResponse<>(this.censoAnuarioService.podeVisualizarAnuario()));
    }

    @GetMapping("/status-atualizacao/{cooperativaId}")
    @Operation(summary = "Retorna se a cooperativa está com Anuário atualizado ou desatualizado")
    public ResponseEntity<ServiceResponse<Boolean>> getStatusAtualizacao(@PathVariable Integer cooperativaId) {
        boolean atualizado = this.censoAnuarioService.getCheckAnuarioAtualizado(cooperativaId);
        return ResponseEntity.ok(new ServiceResponse<>(atualizado));
    }
    
    @GetMapping("/status-atualizacao-anuario/{cooperativaId}")
    @Operation(summary = "Retorna o status atualização do anuário")
    public ResponseEntity<ServiceResponse<String>> getStatusAtualizacaoAnuario(@PathVariable Integer cooperativaId) {
        return ResponseEntity.ok(new ServiceResponse<>(this.censoAnuarioService.getStatusAtualizacaoAnuario(cooperativaId)));
    }
    

    @PostMapping("/salvar-aba-dados-sociais/{cooperativaId}/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarAbaDadosSociais(
            @PathVariable Integer cooperativaId,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO) {

        boolean sucesso = this.censoAnuarioService.salvarAbaDadosSociais(cooperativaId, ano, dadosSociaisFinanceirosTO, null, isSubmit);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
    
    @PostMapping("/salvar-aba-quadro-social/{cooperativaId}/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarAbaDadosSociaisAnuario(
            @PathVariable Integer cooperativaId,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody List<QuadroSocialAnuarioTO> listQuadroSocialAnuarioTO) {

        boolean sucesso = this.censoAnuarioService.salvarAbaDadosSociais(cooperativaId, ano, listQuadroSocialAnuarioTO, null, isSubmit);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
    
    @PostMapping("/salvar-aba-portfolio/{cooperativaId}/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarAbaPortfolioAnuario(
            @PathVariable Integer cooperativaId,
            @PathVariable Integer ano,
            @RequestBody RequestPortfolioTO requestPortfolioTO) {

        boolean sucesso = this.censoAnuarioService.salvarAbaPortfolio(cooperativaId, ano, requestPortfolioTO);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
    
    

    @PostMapping("/salvar-aba-dados-financeiros/{cooperativaId}/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarAbaDadosFinanceiros(
            @PathVariable Integer cooperativaId,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO) {

        boolean sucesso = this.censoAnuarioService.salvarAbaDadosFinanceiros(cooperativaId, ano, dadosSociaisFinanceirosTO, isSubmit);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @PostMapping("/importacao/{cooperativaId}/{ano}")
    @Operation(summary = "Processa importação de anuário — atualiza abas e auto-submete quando elegível")
    public ResponseEntity<ImportacaoAnuarioResultadoTO> processarImportacao(
            @PathVariable Integer cooperativaId,
            @PathVariable Integer ano) {
        return ResponseEntity.ok(censoAnuarioService.processarImportacao(cooperativaId, ano));
    }

    @PostMapping("/salvar-aba-intercooperacao")
    public ResponseEntity<ServiceResponse<Void>> salvarAbaIntercooperacao(
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody DadosIntegracaoTO dadosIntegracaoTO) {

        boolean sucesso = this.censoAnuarioService.salvarAbaIntercooperacao(dadosIntegracaoTO, isSubmit);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @PostMapping("/salvar-aba-dados-sociais/financeiro/{cooperativaId}/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarAbaDadosSociaisAnuario(
            @PathVariable Integer cooperativaId,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody ListDadosSociaisAnuarioTO listQuadroSocialAnuarioTO) {

        //SOUCOOP
        boolean sucesso = this.censoAnuarioService.salvarAbaDadosSociais(cooperativaId, ano, listQuadroSocialAnuarioTO.getQuadroSocialAnuarioTOList(), null, isSubmit);

        //DESEMPENHO
        boolean sucessoDadosFinanceiros = this.censoAnuarioService.salvarAbaDadosFinanceiros(cooperativaId, ano, listQuadroSocialAnuarioTO.getDadosSociaisFinanceirosTO(), isSubmit);

        String mensagem = messages.get(sucesso && sucessoDadosFinanceiros ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso && sucessoDadosFinanceiros ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
}
