package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro.dao;

import br.coop.somoscooperativismo.registro.api.v1.cadastroregistro.RetornoRelatorioErroValidacaoEmLoteTO;
import br.coop.somoscooperativismo.registro.api.v1.util.sql.AbstractDAO;
import java.util.List;
import jakarta.persistence.Query;
import org.springframework.stereotype.Repository;

@Repository
public class RelatorioErrosValidacaoEmLoteDAO extends AbstractDAO {

	public List<RetornoRelatorioErroValidacaoEmLoteTO> fetchCooperativasParaIntegracaoFormulario(String uf) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ");

		Query query = em.createNativeQuery(sql.toString());
		if (uf != null && !uf.isEmpty()) query.setParameter("uf", uf);

		return query.getResultList();
	}
}
