package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MandatoMembroImportacaoTO {
    private Integer id;
    private MandatoImportacaoTO mandato;
    private CargoImportacaoTO cargo;
    private PessoaFisicaImportacaoTO pessoaFisica;
    private Boolean representanteLegal;
    private Boolean membroAtivo;
    private Date inicioMandato;
    private Date fimMandato;
    private AprovacaoImportacaoTO aprovacao;
}
