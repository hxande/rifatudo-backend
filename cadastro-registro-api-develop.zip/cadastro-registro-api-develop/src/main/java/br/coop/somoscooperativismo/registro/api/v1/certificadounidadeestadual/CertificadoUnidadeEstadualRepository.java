package br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual;

import br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual.entidade.CertificadoUnidadeEstadual;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificadoUnidadeEstadualRepository extends JpaRepository<CertificadoUnidadeEstadual, Integer>{

    Optional<CertificadoUnidadeEstadual> findByUf(String uf);
	
}
