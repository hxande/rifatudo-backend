package br.coop.somoscooperativismo.registro.api.v1.dlq.service;

import br.coop.somoscooperativismo.registro.api.v1.dlq.entidade.DlqMessage;
import br.coop.somoscooperativismo.registro.api.v1.dlq.repository.DlqMessageRepository;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DlqProcessorService {
    private final DlqMessageRepository dlqMessageRepository;

    public DlqProcessorService(DlqMessageRepository dlqMessageRepository) {
        this.dlqMessageRepository = dlqMessageRepository;
    }

    public void save(DlqMessage dlqMessage) {
        dlqMessageRepository.save(dlqMessage);
        log.info("Mensagem da DLQ salva no banco de dados: " + dlqMessage.getId());
    }

}
