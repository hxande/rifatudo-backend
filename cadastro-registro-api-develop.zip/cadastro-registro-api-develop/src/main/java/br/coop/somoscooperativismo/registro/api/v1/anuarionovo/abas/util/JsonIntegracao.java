package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.EstruturaIntegracaoParametroTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class JsonIntegracao implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private transient List<EstruturaIntegracaoParametroTO> parametros = new ArrayList<>();

    public JsonIntegracao(List<EstruturaIntegracaoParametroTO> parametros) {
        this.parametros = parametros;
    }
}
