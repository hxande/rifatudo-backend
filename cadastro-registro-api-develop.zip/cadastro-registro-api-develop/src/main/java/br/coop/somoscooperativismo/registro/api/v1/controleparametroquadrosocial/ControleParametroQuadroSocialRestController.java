package br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocial;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/controle-parametro-quadro-social")
@Tag(name = "Controle Parametro Quadro Social")
public class ControleParametroQuadroSocialRestController {

	@Autowired
	private ControleParametroQuadroSocialService controleParametroQuadroSocialService;
	
	@GetMapping
	@Operation(summary = "Retorna status do controle de preenchimento dos dados adicionais do quadro social")
	public ResponseEntity<ServiceResponse<Boolean>> obterControleParametroQuadroSocial(){
		return new ResponseEntity<>(new ServiceResponse<>(controleParametroQuadroSocialService.obterControlePreenchimentoDadosAdicionais()), HttpStatus.OK);
	}
	
	@PostMapping("/atualizar-controle-preenchimento")
	@Operation(summary = "Altera o controle do preenchimento dos dados adicionais do quadro social")
	public ResponseEntity<ServiceResponse<Void>> desabilitaControlePreenchimentoDadosAdicionais(@RequestBody boolean ativa){
		controleParametroQuadroSocialService.habilitarDesabilitarCampos(ativa);
		ServiceMessage message = new ServiceMessage("Controle de preenchimento atualizado com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	
}
