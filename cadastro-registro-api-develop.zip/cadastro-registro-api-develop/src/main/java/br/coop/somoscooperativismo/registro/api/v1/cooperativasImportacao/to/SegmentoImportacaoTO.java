package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SegmentoImportacaoTO {
    private Integer id;
    private String nome;
    private Boolean status;
    private RamoImportacaoTO ramo;
    private String segHint;
}
