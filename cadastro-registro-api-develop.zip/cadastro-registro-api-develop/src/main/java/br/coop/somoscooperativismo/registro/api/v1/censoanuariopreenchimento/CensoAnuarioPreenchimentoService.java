package br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento;


import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.entidade.CensoAnuarioPreenchimento;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaRepository;

@Service
@Transactional
public class CensoAnuarioPreenchimentoService {

	@Autowired
	private CensoAnuarioPreenchimentoRepository censoAnuarioPreenchimentoRepository;
	
	@Autowired
    private CooperativaRepository cooperativaRepository;
	
	
	public void iniciaPreenchimento(CensoAnuarioPreenchimento censoAnuarioPreenchimento) {
		
		censoAnuarioPreenchimento.setDataInicio(LocalDateTime.now());
		censoAnuarioPreenchimentoRepository.save(censoAnuarioPreenchimento);
	}
	
	public void finalizaPreenchimento(CensoAnuarioPreenchimento censoAnuarioPreenchimento) {
		censoAnuarioPreenchimento = getByAnoAndIdCooperativa(censoAnuarioPreenchimento).orElse(null);
		if(censoAnuarioPreenchimento != null) {
			censoAnuarioPreenchimento.setDataFim(LocalDateTime.now());
			censoAnuarioPreenchimentoRepository.save(censoAnuarioPreenchimento);
			updateDataAtualizacao(censoAnuarioPreenchimento.getIdCooperativa());
		}
	}	
	
	public Optional<CensoAnuarioPreenchimento> getByAnoAndIdCooperativa(CensoAnuarioPreenchimento censoAnuarioPreenchimento) {
		Integer ano = censoAnuarioPreenchimento.getAno();
		Integer idCooperativa = censoAnuarioPreenchimento.getIdCooperativa();
		return censoAnuarioPreenchimentoRepository
				.findByAnoAndIdCooperativa(ano, idCooperativa);
	}
	
	public boolean existsByAnoAndCooperativaId(Integer ano, Integer cooperativaId) {
		return censoAnuarioPreenchimentoRepository
				.findByAnoAndIdCooperativa(ano, cooperativaId).isPresent();
	}
	
	public void updateDataAtualizacao(Integer idCooperativa) {
		Cooperativa cooperativa = cooperativaRepository.findById(idCooperativa).orElseThrow(() -> new RegraNegocioException("Cooperativa não encontrada"));
		cooperativa.setDataAtualizacao(new Date());
		cooperativaRepository.save(cooperativa);
	}

}
