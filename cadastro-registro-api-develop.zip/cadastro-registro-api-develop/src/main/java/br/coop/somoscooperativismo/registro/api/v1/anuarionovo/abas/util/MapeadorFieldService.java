package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosDinamicosTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.FieldTO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class MapeadorFieldService {

    public <T> T mapFieldsToDto(List<List<FieldTO>> fields, T dto) {
        try {
            BeanWrapper beanWrapper = new BeanWrapperImpl(dto);

            if (fields != null) {
                for (List<FieldTO> listaCampos : fields) {
                    for (FieldTO campo : listaCampos) {
                        mapearCampo(beanWrapper, campo);
                    }
                }
            }

            return dto;
        } catch (Exception e) {
            throw new RegraNegocioException("Erro ao mapear dados", e);
        }
    }

    public <T> List<T> mapFieldsToListDto(List<List<FieldTO>> fields, Class<T> dtoClass) {
        try {
            List<T> resultado = new java.util.ArrayList<>();

            if (fields != null) {
                for (List<FieldTO> listaCampos : fields) {
                    T dto = dtoClass.getDeclaredConstructor().newInstance();
                    BeanWrapper beanWrapper = new BeanWrapperImpl(dto);

                    for (FieldTO campo : listaCampos) {
                        mapearCampo(beanWrapper, campo);
                    }

                    resultado.add(dto);
                }
            }

            return resultado;
        } catch (Exception e) {
            throw new RegraNegocioException("Erro ao mapear dados", e);
        }
    }

    public List<Map<String, Object>> mapFieldsToListMap(List<List<FieldTO>> fields) {
        List<Map<String, Object>> resultado = new java.util.ArrayList<>();

        if (fields != null) {
            for (List<FieldTO> listaCampos : fields) {
                Map<String, Object> mapa = new java.util.LinkedHashMap<>();

                for (FieldTO campo : listaCampos) {
                    if (campo.getName() != null) {
                        mapa.put(campo.getName(), campo.getValue());
                        // Adiciona também o parametroIntegracao se existir
                        if (campo.getParametroIntegracao() != null) {
                            mapa.put(campo.getName() + "_parametroIntegracao", campo.getParametroIntegracao());
                        }
                        if (campo.getIdParametro() != null) {
                            mapa.put(campo.getName() + "_idParametro", campo.getIdParametro());
                        }
                    }
                }

                resultado.add(mapa);
            }
        }

        return resultado;
    }

    public Map<String, Object> mapFieldsToMap(List<List<FieldTO>> fields) {
        Map<String, Object> resultado = new java.util.LinkedHashMap<>();

        if (fields != null) {
            for (List<FieldTO> listaCampos : fields) {
                for (FieldTO campo : listaCampos) {
                    if (campo.getName() != null) {
                        resultado.put(campo.getName(), campo.getValue());
                        if (campo.getParametroIntegracao() != null) {
                            resultado.put(campo.getName() + "_parametroIntegracao", campo.getParametroIntegracao());
                        }
                        if (campo.getIdParametro() != null) {
                            resultado.put(campo.getName() + "_idParametro", campo.getIdParametro());
                        }
                    }
                }
            }
        }

        return resultado;
    }

    public <T> List<DadosDinamicosTO> mapFieldsToHybrid(List<List<FieldTO>> fields, Class<T> dtoClass) {
        List<DadosDinamicosTO> resultado = new java.util.ArrayList<>();

        if (fields != null) {
            for (List<FieldTO> listaCampos : fields) {
                DadosDinamicosTO dadosDinamicos = new DadosDinamicosTO();

                // Mapeia para entidade se classe foi informada
                if (dtoClass != null) {
                    try {
                        T dto = dtoClass.getDeclaredConstructor().newInstance();
                        BeanWrapper beanWrapper = new BeanWrapperImpl(dto);

                        for (FieldTO campo : listaCampos) {
                            mapearCampo(beanWrapper, campo);
                        }

                        dadosDinamicos.setEntidadeMapeada(dto);
                    } catch (Exception e) {
                        // Se falhar, continua sem a entidade mapeada
                    }
                }

                // Sempre adiciona os campos dinâmicos
                for (FieldTO campo : listaCampos) {
                    dadosDinamicos.addCampo(campo);
                }

                resultado.add(dadosDinamicos);
            }
        }

        return resultado;
    }

    private void mapearCampo(BeanWrapper beanWrapper, FieldTO campo) {
        String fieldId = campo.getId();
        String fieldName = campo.getName();
        Object value = campo.getValue();

        if (fieldName != null && beanWrapper.isWritableProperty(fieldName)) {
            Class<?> propertyType = beanWrapper.getPropertyType(fieldName);
            Object convertedValue = converterValor(value, propertyType);
            beanWrapper.setPropertyValue(fieldName, convertedValue);
            beanWrapper.setPropertyValue("idQuadro", campo.getIdQuadro());
            beanWrapper.setPropertyValue("idQuadroAuxiliar", campo.getIdQuadroAuxiliar());
            beanWrapper.setPropertyValue("idParametro", campo.getIdParametro());
            beanWrapper.setPropertyValue("idParametroAuxiliar", campo.getIdParametroAuxiliar());
            beanWrapper.setPropertyValue("parametroIntegracao", campo.getParametroIntegracao());
        }
    }

    private Object converterValor(Object value, Class<?> targetType) {
        if (value == null) return null;

        String stringValue = value.toString();
        if (stringValue.isEmpty()) return null;

        if (targetType == BigDecimal.class) {
            return new BigDecimal(stringValue);
        } else if (targetType == Double.class || targetType == double.class) {
            return Double.parseDouble(stringValue);
        } else if (targetType == Integer.class || targetType == int.class) {
            if (stringValue.contains(".")) {
                return (int) Double.parseDouble(stringValue);
            }
            return Integer.parseInt(stringValue);
        } else if (targetType == Long.class || targetType == long.class) {
            if (stringValue.contains(".")) {
                return (long) Double.parseDouble(stringValue);
            }
            return Long.parseLong(stringValue);
        }

        return stringValue;
    }
}
