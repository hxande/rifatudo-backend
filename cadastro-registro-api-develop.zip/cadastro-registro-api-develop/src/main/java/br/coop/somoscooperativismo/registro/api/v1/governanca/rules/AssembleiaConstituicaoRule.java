package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * INV-4 (FR-007) — a data da assembleia não pode ser anterior à data de
 * constituição da PJ para o <b>Conselho de Administração</b> (órgão id 1) e o
 * <b>Conselho Fiscal</b> (órgão id 3).
 *
 * <p>Paridade: {@code GovernancaService.validaDataAssembleiaConstituicao}. Não é
 * filtrada por vigência (percorre todos os mandatos), como no legado.</p>
 */
@Component
public class AssembleiaConstituicaoRule implements GovernancaRule {

    private static final int ID_CONSELHO_ADMINISTRACAO = 1;
    private static final int ID_CONSELHO_FISCAL = 3;

    @Override
    public List<ViolacaoGovernanca> avaliar(GovernancaContext contexto) {
        List<ViolacaoGovernanca> violacoes = new ArrayList<>();
        Date dataConstituicao = contexto.getDataConstituicao();
        if (dataConstituicao == null) {
            return violacoes;
        }
        boolean conselhoAdmInvalido = false;
        boolean conselhoFiscalInvalido = false;
        for (Mandato mandato : contexto.getMandatos()) {
            if (mandato.getDataAssembleia() == null || mandato.getOrgao() == null) {
                continue;
            }
            boolean anterior = DataUtil.ignoreTime(dataConstituicao)
                    .after(DataUtil.ignoreTime(mandato.getDataAssembleia()));
            if (!anterior) {
                continue;
            }
            Integer idOrgao = mandato.getOrgao().getId();
            if (idOrgao != null && idOrgao == ID_CONSELHO_ADMINISTRACAO) {
                conselhoAdmInvalido = true;
            } else if (idOrgao != null && idOrgao == ID_CONSELHO_FISCAL) {
                conselhoFiscalInvalido = true;
            }
        }
        if (conselhoAdmInvalido) {
            violacoes.add(ViolacaoGovernanca.de(TipoViolacaoGovernanca.ASSEMBLEIA_ANTERIOR_CONSTITUICAO_CONS_ADM));
        }
        if (conselhoFiscalInvalido) {
            violacoes.add(ViolacaoGovernanca.de(TipoViolacaoGovernanca.ASSEMBLEIA_ANTERIOR_CONSTITUICAO_CONS_FISCAL));
        }
        return violacoes;
    }
}
