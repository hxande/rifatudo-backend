package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/cadastro-registro")
@Tag(name = "CadastroRegistro")
public class CadastroRegistroRestController {

	@Autowired
	private CadastroRegistroService cadastroRegistroService;
	
	@GetMapping("/validarCadastroRegistro/{idCooperativa}")
	@Operation(summary = "Validando Cadastro Registro")
	public ResponseEntity<ServiceResponse<ValidacaoPrimeiroRegistroTO>> validarCadastroRegistro(@PathVariable Integer idCooperativa, @RequestParam(required = false, defaultValue = "true") boolean considerarCiclo){
		return new ResponseEntity<>(new ServiceResponse<ValidacaoPrimeiroRegistroTO>(cadastroRegistroService.validarCadastroRegistro(idCooperativa, considerarCiclo)), HttpStatus.OK);
	}
	
	@GetMapping("/podePreencherCadastroRegistro/{idCooperativa}")
	@Operation(summary = "Validando Cadastro Registro")
	public ResponseEntity<ServiceResponse<Boolean>> podePreencherCadastroRegistro(@PathVariable Integer idCooperativa){
		// Pegar o usuário e verificar se é cooperativa, UE ou Nacional
		return new ResponseEntity<>(new ServiceResponse<Boolean>(cadastroRegistroService.podePreencherCadastroRegistroCooperativa(idCooperativa)), HttpStatus.OK);
	}
	
	@GetMapping("/podePreencherCadastroRegistroBasico/{idCooperativa}")
	@Operation(summary = "Validando Cadastro Registro")
	public ResponseEntity<ServiceResponse<Boolean>> podePreencherCadastroRegistroBasico(@PathVariable Integer idCooperativa){
		// Pegar o usuário e verificar se é cooperativa, UE ou Nacional
		return new ResponseEntity<>(new ServiceResponse<Boolean>(cadastroRegistroService.podePreencherCadastroRegistroCooperativaBasico(idCooperativa)), HttpStatus.OK);
	}
		
	@GetMapping("/podePreencherCadastroValidacao/{idCooperativa}")
	@Operation(summary = "Validando Cadastro Registro")
	public ResponseEntity<ServiceResponse<Boolean>> podePreencherCadastroValidacao(@PathVariable Integer idCooperativa){
		// Pegar o usuário e verificar se é cooperativa, UE ou Nacional
		return new ResponseEntity<>(new ServiceResponse<Boolean>(cadastroRegistroService.podePreencherCadastroValidacao(idCooperativa)), HttpStatus.OK);
	}
	
	@PutMapping("/submeterCadastro/{idCooperativa}")
	@Operation(summary = "Salvar dados cadastro registro")
	public ResponseEntity<ServiceResponse<Boolean>> submeterCadastro(@PathVariable Integer idCooperativa){
		ServiceMessage message = new ServiceMessage("Cadastro enviado com sucesso!");
		return new ResponseEntity<>(new ServiceResponse<>(cadastroRegistroService.submeterCadastro(idCooperativa), message), HttpStatus.OK);
		
	}
	
	@PutMapping("/notificarOrganizacaoEstadual/{idCooperativa}")
	@Operation(summary = "Notificar Organização Estadual ao iniciar o processo de registro da cooperativa")
	public ResponseEntity<ServiceResponse<Void>> notificarOrganizacaoEstadual(@PathVariable Integer idCooperativa){
		ServiceMessage message = new ServiceMessage("Organização Estadual notificada com sucesso!");
		cadastroRegistroService.notificarOrganizacaoEstadual(idCooperativa);
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
	
}
