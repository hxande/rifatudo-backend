package br.coop.somoscooperativismo.registro.api.v1.controleportifolio;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.coop.somoscooperativismo.registro.api.v1.controleportifolio.entidade.ControlePortifolio;

public interface ControlePortifolioRepository extends JpaRepository<ControlePortifolio, Integer> {

	ControlePortifolio findByUfIsNull();

	Optional<ControlePortifolio> findByUf(String uf);

}
