package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CooperativaTO {
    private Integer id;
    private String tipoPessoa;
    private String cnpj;
    private String razaoSocial;
    private String nomeFantasia;
    private String ufSigla;
    private Integer idRamo;
    private String nomeRamo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataRegistro;
    private String numeroRegistro;
    private Situacao situacao;
    private String regularidade;
    private Integer idCategoria;
    private String categoria;
    private Integer idMunicipio;
    private String municipio;

    public String getNomeCooperativa() {
        String nome = nomeFantasia != null ? nomeFantasia : razaoSocial;
        return "%s - %s - %s".formatted(cnpj, ufSigla, nome);
    }
}
