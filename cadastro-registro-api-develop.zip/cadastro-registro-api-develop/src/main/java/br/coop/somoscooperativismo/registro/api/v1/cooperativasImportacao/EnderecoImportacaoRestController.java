package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.EnderecoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.endereco.EnderecoService;

@RestController
@RequestMapping("/api/v1/cooperativas-importacao/enderecos")
public class EnderecoImportacaoRestController extends EnderecoImportacaoAbstractController {

    private final EnderecoService enderecoService;

    public EnderecoImportacaoRestController(@NonNull EnderecoService enderecoService, @NonNull ModelMapper modelMapper) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, Endereco.class, EnderecoImportacaoTO.class);
        this.enderecoService = enderecoService;
    }

    @GetMapping("/{idPessoa}/{idTipoEndereco}")
    public ResponseEntity<Endereco> getEnderecoByIdPessoaAndIdTipoEndereco(@PathVariable Integer idPessoa,
                                                                           @PathVariable Integer idTipoEndereco) {
        return ResponseEntity.ok(enderecoService.obterEndereco(idPessoa, idTipoEndereco));
    }

    @GetMapping("/uf/{uf}")
    public ResponseEntity<List<EnderecoImportacaoTO>> getByUf(@PathVariable String uf) {
        return ResponseEntity.ok(enderecoService.getByUf(uf).stream()
                .map(endereco -> modelMapper.map(endereco, EnderecoImportacaoTO.class)).collect(Collectors.toList()));
    }
}
