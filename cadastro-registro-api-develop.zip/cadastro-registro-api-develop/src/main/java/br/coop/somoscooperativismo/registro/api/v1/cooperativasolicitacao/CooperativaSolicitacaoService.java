package br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.entidade.CooperativaSolicitacao;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class CooperativaSolicitacaoService {

	@Autowired
	CooperativaSolicitacaoRepository cooperativaSolicitacaoRepository;

	@Autowired
	KeycloakService keycloakService;
	
	public static final String MOTIVO_APONTAMENTO_IRREGULARIDADE = "É necessário preencher o motivo da irregularidade";
	public static final String COMPLEMENTO_MOTIVO_APONTAMENTO_IRREGULARIDADE = "É necessário preencher o complemento do motivo da irregularidade";
	
	public static final String USUARIO_SEM_PERMISSAO = "Usuário sem permissão para este procedimento!";
	public static final String DOCUMENTO_OBRIGATORIO = "É necessário enviar o arquivo!";
	
	public CooperativaSolicitacao buscaUltimaCooperativaSolicitacao(Integer id, Integer tipoSolicitacao) {
		Pageable pageable = PageRequest.of(0,1);
		List<CooperativaSolicitacao> listCooperativaSolicitacao = cooperativaSolicitacaoRepository.buscaUltimaCooperativaSolicitacao(id, TipoSolicitacaoEnum.INATIVACAO.getTipo(), pageable);
		if(!listCooperativaSolicitacao.isEmpty()) {
			return listCooperativaSolicitacao.get(0);
		}
		return null;
	}

	public CooperativaSolicitacao getCooperativaSolicitacao(Integer id){
		return cooperativaSolicitacaoRepository.findById(id).orElse(null);
	}

	public static void validaCooperativaSolicitacao(CooperativaSolicitacao cooperativaSolicitacao) {
		if(!ValidacaoCampos.validaCampoPreenchido(cooperativaSolicitacao.getSolicitacao().getId())) {
			throw new RegraNegocioException(MOTIVO_APONTAMENTO_IRREGULARIDADE);
		}
		
		if(ValidacaoCampos.validaCampoPreenchido(cooperativaSolicitacao.getSolicitacao().getId())
				&& (cooperativaSolicitacao.getSolicitacao().getNecessitaComplemento() != null 
						&& cooperativaSolicitacao.getSolicitacao().getNecessitaDocumento().equals(Boolean.TRUE))
				
				&& !ValidacaoCampos.validaCampoPreenchido(cooperativaSolicitacao.getOutroMotivoDesc())) {
			throw new RegraNegocioException(COMPLEMENTO_MOTIVO_APONTAMENTO_IRREGULARIDADE);
		}
				
	}

	public CooperativaSolicitacao salvar(CooperativaSolicitacao cooperativaSolicitacao) {
		if(!keycloakService.isTipoEntidadeNacional() && !keycloakService.isTipoEntidadeEstadual()) {
			throw new RegraNegocioException(USUARIO_SEM_PERMISSAO);
		}
		return cooperativaSolicitacaoRepository.save(cooperativaSolicitacao);
	}

}
