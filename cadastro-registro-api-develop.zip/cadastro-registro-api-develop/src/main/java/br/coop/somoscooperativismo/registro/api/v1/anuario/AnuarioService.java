package br.coop.somoscooperativismo.registro.api.v1.anuario;

import br.coop.somoscooperativismo.api.v1.relatorio.RelatorioClient;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioExpressTO;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.anuario.entidade.Anuario;
import br.coop.somoscooperativismo.registro.api.v1.anuario.filtros.AnuarioFiltroTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import jakarta.validation.Valid;
import org.jboss.logging.Logger;
import org.joda.time.LocalDate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@Service
@Transactional
public class AnuarioService {

	public static final String FASE_DO_PROCESSO = "Fase do Processo";
	public static final String ERRO_PLANILHA = "cooperativa.erroPlanilha";
	public static final String NAO_HA_REGISTROS_EXPORT = "Não há registros para exportar.";
	public static final String NOME_FANTASIA = "Nome fantasia";

	private static final int ANO_2015 = 2015;
	private static final int NUMERO20 = 20;
	private static final int NUMERO45 = 45;
	private static final int NUMERO18 = 18;
	private static final int NUMERO5 = 5;
	private static final int NUMERO30 = 30;
	private static final int NUMERO16 = 16;
	private static final int NUMERO14 = 14;
	private static final int NUMERO24 = 24;
	private static final int NUMERO28 = 28;
	private static final int NUMERO2 = 2;
	
	private static final Logger LOGGER = Logger.getLogger(AnuarioService.class);
	
	private AnuarioRepository anuarioRepository;
	
	private AnuarioTORepositoryImpl anuarioTORepository;

	private CooperativaService cooperativaService;

	private RelatorioClient relatorioClient;

	private KeycloakService keycloakService;

	private MessagesService messages;
	
	public AnuarioService(AnuarioRepository anuarioRepository, AnuarioTORepositoryImpl anuarioTORepository,
			CooperativaService cooperativaService, RelatorioClient relatorioClient, KeycloakService keycloakService, MessagesService messages
			) {
		this.anuarioRepository = anuarioRepository;
		this.anuarioTORepository = anuarioTORepository;
		this.cooperativaService = cooperativaService;
		this.relatorioClient = relatorioClient;
		this.keycloakService = keycloakService;
		this.messages = messages;
	}

	/**
	 * @deprecated
	 * @param idCooperativa
	 * @return
	 */
	@Deprecated(since="X", forRemoval=true)
	public Anuario getByCooperativa(Integer idCooperativa) {
		Anuario anuario = anuarioRepository.getByCooperativa(idCooperativa);
		if (anuario == null) {
			anuario = new Anuario();
			anuario.setCooperativa(cooperativaService.getCooperativa(idCooperativa));
		}
		return anuario;
	}

	/**
	 * Retorna o anuário da Cooperativa no ano indicado, retornando null caso a
	 * cooperativa não possua anuário no ano indicado.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @param ano           Ano.
	 * @return Anuário da Cooperativa.
	 */
	public Anuario getByCooperativaAno(Integer idCooperativa, Integer ano) {
		return anuarioRepository.getByCooperativaAno(idCooperativa, ano);
	}

	public @Valid Anuario create(@Valid Anuario anuario) {
		
		validaAnuario(anuario);
		return anuarioRepository.save(anuario);
	}

	private void validaAnuario(@Valid Anuario anuario) {
		BigDecimal total = (anuario.getAtivoImobilizado() != null ? anuario.getAtivoImobilizado() : BigDecimal.ZERO);
		total = total.add(anuario.getAtivoTotal() != null ? anuario.getAtivoTotal() : BigDecimal.ZERO);
		total = total.add(anuario.getCapitalSocial() != null ? anuario.getCapitalSocial() : BigDecimal.ZERO);
		total = total.add(anuario.getDespesasPessoal() != null ? anuario.getDespesasPessoal() : BigDecimal.ZERO);
		total = total.add(anuario.getIngressosReceitasBrutas() != null ? anuario.getIngressosReceitasBrutas() : BigDecimal.ZERO);
		total = total.add(anuario.getPatrimonioLiquido() != null ? anuario.getPatrimonioLiquido() : BigDecimal.ZERO);
		total = total.add(anuario.getSobrasPerdasExercicio() != null ? anuario.getSobrasPerdasExercicio() : BigDecimal.ZERO);
		total = total.add(anuario.getTributos() != null ? anuario.getTributos() : BigDecimal.ZERO);
		if (anuario.getAno() == null || anuario.getAno() == 0) {
			throw new RegraNegocioException("O ano do anuário não foi informado.");
		}
		if (anuario.getAno() < ANO_2015 || anuario.getAno() > LocalDate.now().getYear()) {
			throw new RegraNegocioException("O ano do anuário não é válido.");
		}
		if (total.floatValue() <= 0) {
			throw new RegraNegocioException("Um dos valores deve ser maior que 0,00.");
		}

		total = null;
	}

	/**
	 * Retora a lista de anuários da cooperativa indicada.
	 * 
	 * @param idCooperativa ID da Cooperativa.
	 * @return Lista de Anuários.
	 */
	public List<Anuario> getListByCooperativa(Integer idCooperativa) {
		return anuarioRepository.getListByCooperativa(idCooperativa);
	}

	/**
	 * Retorna uma listagem de anuários paginados.
	 * 
	 * @param anuarioFiltroTO FiltroTO de anuário
	 * @param pageable
	 * @return
	 */
	public Page<AnuarioTO> filtrarPaginado(AnuarioFiltroTO anuarioFiltroTO, Pageable pageable) {
		anuarioFiltroTO.setCnpj(RemoveMascaraUtil.remove(anuarioFiltroTO.getCnpj()));
		if (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual()) {
			if (keycloakService.isTipoEntidadeEstadual()) {
				anuarioFiltroTO.setUf(keycloakService.getUFUsuario());
			}
		} else {
			throw new RegraNegocioException("Usuário não possui permissão.");
		}

		return anuarioTORepository.filtrarAnuarioPaginado(anuarioFiltroTO, pageable);
		
	}

	/**
	 * Filtra o anuário de acordo com o filtro e exporta como excel.
	 * 
	 * @param anuarioFiltroTO FiltroTO do anuário.
	 * @return Array de bytes.
	 */
	public byte[] filtrarAnuarioExcel(AnuarioFiltroTO anuarioFiltroTO) {
		anuarioFiltroTO.setCnpj(RemoveMascaraUtil.remove(anuarioFiltroTO.getCnpj()));

		if (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual()) {
			if (keycloakService.isTipoEntidadeEstadual()) {
				anuarioFiltroTO.setUf(keycloakService.getUFUsuario());
			}
		} else {
			throw new RegraNegocioException("Usuário não possui permissão.");
		}

		List<AnuarioTO> result = anuarioTORepository.filtrarAnuario(anuarioFiltroTO);

		if (result.isEmpty()) {
			throw new RegraNegocioException(NAO_HA_REGISTROS_EXPORT, HttpStatus.NOT_FOUND);
		}

		List<String> cabecalho = null;
		List<List<String>> linhas = new ArrayList<>();
		List<Integer> larguras = null;

		cabecalho = Arrays.asList("CNPJ", NOME_FANTASIA, "Ramo", "UF", FASE_DO_PROCESSO, "Status da Cooperativa",
				"Anuário", "Ativo Total", "Ativo Imobilizado", "Patrimônio Líquido", "Capital Social",
				"Sobras ou Perda do Exercício", "Ingressos e Receitas Brutas", "Tributos Sobre Vendas e Serviço",
				"Total de Despesas");
		larguras = Arrays.asList(NUMERO20, NUMERO45, NUMERO18, NUMERO5, NUMERO30, NUMERO16, NUMERO20, NUMERO14, NUMERO24, NUMERO20, NUMERO20, NUMERO28, NUMERO28, NUMERO30, NUMERO24);
		result.forEach(anuario -> linhas.add(Arrays.asList(anuario.getCnpj(), anuario.getNomeFantasia(),
				anuario.getNomeRamo(), anuario.getUfSigla(), anuario.getSituacaoCooperativa(),
				ano(anuario),
				ativoTotal(anuario),
				ativoImobilizado(anuario),
				patrimonioLiquido(anuario),
				capitalSocial(anuario),
				sobrasPerdasExercicio(anuario),
				ingressosReceitasBrutas(anuario),
				tributos(anuario),
				despesasPessoal(anuario)
				)));

		byte[] file = null;
		file = montaRelatorio(cabecalho, linhas, larguras);

		result = null;
		cabecalho = null;
		larguras = null;

		return file;

	}
	
	private String ano(AnuarioTO anuario) {
		return anuario.getAno() != null ? String.valueOf(anuario.getAno()).concat("") : "";
	}
	
	private String ativoTotal(AnuarioTO anuario) {
		return anuario.getAtivoTotal() != null ? anuario.getAtivoTotal().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String ativoImobilizado(AnuarioTO anuario) {
		return anuario.getAtivoImobilizado() != null
				? anuario.getAtivoImobilizado().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String patrimonioLiquido(AnuarioTO anuario) {
		return anuario.getPatrimonioLiquido() != null
				? anuario.getPatrimonioLiquido().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String capitalSocial(AnuarioTO anuario) {
		return anuario.getCapitalSocial() != null
				? anuario.getCapitalSocial().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String sobrasPerdasExercicio(AnuarioTO anuario) {
		return anuario.getSobrasPerdasExercicio() != null
				? anuario.getSobrasPerdasExercicio().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String ingressosReceitasBrutas(AnuarioTO anuario) {
		return anuario.getIngressosReceitasBrutas() != null
				? anuario.getIngressosReceitasBrutas().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String tributos(AnuarioTO anuario) {
		return anuario.getTributos() != null ? anuario.getTributos().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}
	
	private String despesasPessoal(AnuarioTO anuario) {
		return anuario.getDespesasPessoal() != null
				? anuario.getDespesasPessoal().setScale(NUMERO2, RoundingMode.FLOOR).toString()
				: "";
	}

	private byte[] montaRelatorio(List<String> cabecalho, List<List<String>> linhas,
			List<Integer> larguras) {
		byte[] file = null;
		if (!linhas.isEmpty()) {
			try {
				RelatorioExpressTO relatorio = new RelatorioExpressTO();
				relatorio.setCabecalho(cabecalho);
				relatorio.setDados(linhas);
				relatorio.setLarguras(larguras);
				file = relatorioClient.gerarRelatorio(relatorio);
			} catch (Exception e) {
				LOGGER.error(e.getMessage());
				throw new ErroSistemaException(messages.get(ERRO_PLANILHA), e);
			}
		}
		return file;
	}
}
