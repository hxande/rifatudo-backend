package br.coop.somoscooperativismo.registro.api.v1.areacontato;

import br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade.AreaContato;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface AreaContatoRepository extends JpaRepository<AreaContato, Integer> {

	@Query("select tb from AreaContato tb where tb.nome like %:nome% "
			+ " and (:ativo is null or tb.ativo = :ativo) "
			+ " and (:utilizaCargo is null or tb.utilizaCargo = :utilizaCargo) "
			+ " and (:obrigatorio is null or tb.obrigatorio = :obrigatorio) "
			+ " and (:posicaoTela is null or tb.posicaoTela = :posicaoTela) "
			+ " and tb.excluido is not true"
			+ " and tb.uf is null ")
	Page<AreaContato> filtra(String nome, Boolean ativo, Boolean utilizaCargo,
							 Boolean obrigatorio, Integer posicaoTela, Pageable pageable);

	@Query("select tb from AreaContato tb where tb.nome like %:nome% "
			+ " and (:ativo is null or tb.ativo = :ativo) "
			+ " and (:utilizaCargo is null or tb.utilizaCargo = :utilizaCargo) "
			+ " and tb.excluido is not true "
			+ " and tb.uf = :uf ")
	Page<AreaContato> filtraEstadual(String nome, Boolean ativo, Boolean utilizaCargo, String uf, Pageable pageable);

	@Query("select tb from AreaContato tb where tb.nome like %:nome% "
			+ " and (:ativo is null or tb.ativo = :ativo) "
			+ " and (:utilizaCargo is null or tb.utilizaCargo = :utilizaCargo) "
			+ " and tb.excluido is not true "
			+ " and tb.uf is not null "
			+ " and (:obrigatorio is null or tb.obrigatorio = :obrigatorio) "
			+ " and (:posicaoTela is null or tb.posicaoTela = :posicaoTela) ")
	Page<AreaContato> filtraEstadualNacional(String nome, Boolean ativo, Boolean utilizaCargo,
											 Boolean obrigatorio, Integer posicaoTela, Pageable pageable);

	@Query("SELECT tb FROM AreaContato tb WHERE tb.ativo is true AND tb.excluido is not true AND (tb.uf = :uf OR tb.uf IS NULL) ORDER BY tb.uf ASC , tb.posicaoTela ASC")
	List<AreaContato> findByAtivoTrueAndExcluidoFalseOrderByPosicaoTela(@Param("uf") String uf);

	@Query("select tb from AreaContato tb where tb.ativo is true and tb.excluido is not true AND tb.uf IS NULL order by tb.uf ASC, tb.posicaoTela asc ")
	List<AreaContato> findAreaContatoOrderByPosicaoTela();

	List<AreaContato> findByAtivoTrueAndExcluidoFalseOrderByPosicaoTela();

	List<AreaContato> findByUfAndAtivoAndPosicaoTelaGreaterThanEqualOrderByPosicaoTela(String uf, boolean ativo, Integer posicaoTela);
	
}
