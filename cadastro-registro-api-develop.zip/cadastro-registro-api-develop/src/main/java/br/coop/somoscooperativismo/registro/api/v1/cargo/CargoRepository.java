package br.coop.somoscooperativismo.registro.api.v1.cargo;


import br.coop.somoscooperativismo.registro.api.v1.cargo.entidade.Cargo;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface CargoRepository extends JpaRepository<Cargo, Integer> {

	@Query("select tb from Cargo tb where tb.nome like %:nome% "
			+ " and (:ativo is null or tb.ativo = :ativo) ")
	Page<Cargo> filtra(String nome, Boolean ativo, Pageable pageable);

	
}
