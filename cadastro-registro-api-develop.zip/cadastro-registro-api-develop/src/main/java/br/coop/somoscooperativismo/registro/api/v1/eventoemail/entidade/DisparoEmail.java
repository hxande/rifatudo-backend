package br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "EVENTO_EMAIL")
public class DisparoEmail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_EVENTO_EMAIL")
    private Integer id;

    @Column(name = "TX_CHAVE_EMAIL", nullable = false)
    private String chaveEmail;

    @Column(name = "TX_TEXTO_EMAIL")
    private String textoEmail;

    @Column(name = "TX_TEXTO_VARIAVEL_EMAIL")
    private String textoVariavelEmail;

    @Column(name = "IN_ENVIAR_EMAIL", columnDefinition = "bit", nullable = false)
    private boolean ativo;

    @Column(name = "TX_DESCRICAO_EMAIL")
    private String textoDescricaoEmail;

    @Column(name = "TX_DESTINATARIO_EMAIL")
    private String destinatarioEmail;

	@Column(name = "SQ_TIPO_PROCESSO_EMAIL")
    private Integer idTipoProcessoEmail;
    
}
