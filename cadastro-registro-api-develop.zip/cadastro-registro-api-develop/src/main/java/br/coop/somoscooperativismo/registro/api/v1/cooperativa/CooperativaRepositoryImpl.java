package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.FiltroTO;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import liquibase.util.StringUtil;

public class CooperativaRepositoryImpl implements CooperativaRepositoryCustom {

	@PersistenceContext
	private EntityManager entityManager;

	private String select = "";

	private static final String CONSULTA_SQL = " FROM COOPERATIVA CP WITH(NOLOCK) "
			+ " JOIN PESSOA_JURIDICA PJ WITH(NOLOCK) ON CP.SQ_COOPERATIVA = PJ.SQ_PESSOA "
			+ " LEFT JOIN RAMO RM WITH(NOLOCK) ON PJ.SQ_RAMO = RM.SQ_RAMO "
			+ " LEFT JOIN PESSOA_SEGMENTO_PRODUTO_SERVICO SEG_PROD  WITH(NOLOCK) ON PJ.SQ_PESSOA = SEG_PROD.SQ_PESSOA "
			+ " LEFT JOIN SEGMENTO SEG WITH(NOLOCK) ON SEG.SQ_RAMO = RM.SQ_RAMO ";

	private static final String SQL_FROM_REGISTRO = CONSULTA_SQL
			+ " JOIN SITUACAO_COOPERATIVA SC WITH(NOLOCK) ON CP.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA AND (CP.SQ_SITUACAO_COOPERATIVA = 4 OR CP.SQ_SITUACAO_COOPERATIVA IS NULL) ";
	private static final String SQL_JOIN_COOPERATIVA_REGISTRADA = " JOIN SITUACAO_COOPERATIVA SC WITH(NOLOCK) ON CP.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA AND (CP.SQ_SITUACAO_COOPERATIVA not in (4)) ";
	private static final String SQL_FROM_COOPERATIVA = CONSULTA_SQL + SQL_JOIN_COOPERATIVA_REGISTRADA;
	private static final String SQL_JOIN_COOPERATIVA_COM_GRAU = " JOIN CATEGORIA_COOPERATIVA CC WITH(NOLOCK) ON CC.SQ_CATEGORIA_COOPERATIVA = CP.SQ_CATEGORIA_COOPERATIVA "
			+ SQL_JOIN_COOPERATIVA_REGISTRADA;
	private static final String SQL_JOIN_PESSOA_JURIDICA = "JOIN PESSOA_JURIDICA PJ WITH(NOLOCK) ON CP.SQ_COOPERATIVA = PJ.SQ_PESSOA ";
	private static final String SQL_JOIN_ANUARIO = "LEFT JOIN COOPERATIVA_ANUARIO AN WITH(NOLOCK) ON CP.SQ_COOPERATIVA=AN.SQ_COOPERATIVA";
	private static final String SQL_FROM_COOPERATIVA_COM_GRAU = CONSULTA_SQL + SQL_JOIN_ANUARIO
			+ SQL_JOIN_COOPERATIVA_COM_GRAU;
	private static final String SQL_JOIN_SOLICITACAO_UF = " JOIN PESSOA_ENDERECO_SOLICITACAO_TRANSFERENCIA ST WITH (NOLOCK) ON ST.SQ_PESSOA = CP.SQ_COOPERATIVA ";
	private static final String AND_CP_TX_PROCESSO_LIKE = " AND (CP.TX_PROCESSO like '";
	private static final String AND_PJ_TX_UF_SIGLA = " AND (PJ.TX_UF_SIGLA = '";
	private static final String AND_PJ_TX_CNPJ_LIKE = " AND (PJ.TX_CNPJ = '";
	private static final String AND_PJ_TX_NOME_FANTASIA_LIKE = " AND (PJ.TX_NOME_FANTASIA LIKE '%";
	private static final String WHERE_PJ_IN_MATRIZ = " WHERE PJ.IN_MATRIZ = 1 ";
	private static final String AND_ATUALIZACAO_NAO_VISUALIZADA = "AND CP.IN_ATUALIZACAO_NAO_VISUALIZADA = 1";
	private static final String TX_CNPJ = "TX_CNPJ";
	private static final String TX_RAZAO_SOCIAL = "TX_RAZAO_SOCIAL";
	private static final String TX_NOME_FANTASIA = "TX_NOME_FANTASIA";
	private static final String TX_UF_SIGLA = "TX_UF_SIGLA";
	private static final String TX_RAMO = "TX_RAMO";
	private static final String TX_CATEGORIA_COOPERATIVA = "TX_CATEGORIA_COOPERATIVA";
	private static final String DT_ATUALIZACAO = "DT_ATUALIZACAO";

	/**
	 * Listagem de cooperativas registradas/em processo de transferência de UF
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Page<CooperativaListagemTO> filtrarCooperativaListagemPaginado(CooperativaFiltroTO cooperativaFiltro,
			FiltroTO filtro, Pageable pageable) {
		select = "SELECT DISTINCT CP.SQ_COOPERATIVA, CP.TX_NUMERO_REGISTRO_OCB,  PJ.TX_CNPJ, PJ.TX_RAZAO_SOCIAL, PJ.TX_NOME_FANTASIA, "
				+ " PJ.TX_UF_SIGLA, RM.TX_RAMO, CC.TX_CATEGORIA_COOPERATIVA, SC.TX_NOVA_SITUACAO_COOPERATIVA, null, "
				+ "CP.DT_ATUALIZACAO, " + "	DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(PJ.SQ_PESSOA) "
				+ " 	AS STATUS, CP.IN_ATUALIZACAO_NAO_VISUALIZADA, " + " CP.IN_SOLICITACAO_INATIVACAO ";
		StringBuilder sqlNativo = null;
		if (cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia()) {
			// select cooperativas em processo de transferência de UF
			select = select.concat(", ST.SQ_ESTADO_DESTINO_SEDE ");
			sqlNativo = new StringBuilder(select + SQL_FROM_COOPERATIVA_COM_GRAU + SQL_JOIN_SOLICITACAO_UF);
		} else {
			// select cooperativas registradas
			sqlNativo = new StringBuilder(select + SQL_FROM_COOPERATIVA_COM_GRAU);
		}

		montaQueryFiltroNativo(sqlNativo, filtro, cooperativaFiltro, false);
		sqlNativo.append(ordenar(pageable));
		Query query = entityManager.createNativeQuery(sqlNativo.toString());
		restricoesDePaginacao(query, pageable);
		List<Object[]> resultList = query.getResultList();
		List<CooperativaListagemTO> cooperativaDto = new ArrayList<>();
		resultList.forEach(obj -> {
			if (cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia()) {
				cooperativaDto.add(new CooperativaListagemTO((Integer) obj[0], (String) obj[1], (String) obj[2],
						(String) obj[3], (String) obj[4], (String) obj[5], (String) obj[6], (String) obj[7],
						(String) obj[8], (Character) obj[9], (Date) obj[10], (String) obj[11], (Boolean) obj[12],
						(String) obj[14], (Boolean) obj[13]));
			} else {
				cooperativaDto.add(new CooperativaListagemTO((Integer) obj[0], (String) obj[1], (String) obj[2],
						(String) obj[3], (String) obj[4], (String) obj[5], (String) obj[6], (String) obj[7],
						(String) obj[8], (Character) obj[9], (Date) obj[10], (String) obj[11], (Boolean) obj[12],
						(Boolean) obj[13]));
			}

		});

		query = null;
		resultList = null;

		return new PageImpl<>(cooperativaDto, pageable, totalRegistros(sqlNativo, cooperativaFiltro, filtro));
	}

	@SuppressWarnings("unchecked")
	@Override
	public Page<Cooperativa> consultaCooperativa(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro,
												 Pageable pageable) {
		StringBuilder sqlNativo = null;
		if (cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia()) {
			select = "SELECT DISTINCT CP.*, PJ.TX_NOME_FANTASIA, PJ.TX_CNPJ, RM.TX_RAMO, SC.TX_SITUACAO_COOPERATIVA, PJ.TX_UF_SIGLA, SC.SQ_SITUACAO_COOPERATIVA, ST.SQ_ESTADO_DESTINO_SEDE ";
			sqlNativo = new StringBuilder(select + SQL_FROM_COOPERATIVA + SQL_JOIN_SOLICITACAO_UF);
		} else {
			select = "SELECT DISTINCT CP.*, PJ.TX_NOME_FANTASIA, PJ.TX_CNPJ, RM.TX_RAMO, SC.TX_SITUACAO_COOPERATIVA, PJ.TX_UF_SIGLA, SC.SQ_SITUACAO_COOPERATIVA ";
			sqlNativo = new StringBuilder(select + SQL_FROM_COOPERATIVA);
		}
		montaQueryFiltroNativo(sqlNativo, filtro, cooperativaFiltro, false);
		sqlNativo.append(ordenar(pageable));
		Query query = entityManager.createNativeQuery(sqlNativo.toString(), Cooperativa.class);
		restricoesDePaginacao(query, pageable);
		return new PageImpl<>((query.getResultList()), pageable, totalRegistrosCoop(cooperativaFiltro, filtro));
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Cooperativa> filtrarNaoPaginado(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro) {
		StringBuilder sqlNativo = new StringBuilder(
				"SELECT DISTINCT CP.*, PJ.TX_NOME_FANTASIA, PJ.TX_CNPJ, RM.TX_RAMO " + SQL_FROM_REGISTRO);

		montaQueryFiltro(sqlNativo, filtro, cooperativaFiltro);
		Query query = entityManager.createNativeQuery(sqlNativo.toString(), Cooperativa.class);

		sqlNativo = null;

		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Cooperativa> consultaCooperativaNaoPaginado(CooperativaFiltroTO cooperativaFiltro,
			FiltroTO filtro) {
		StringBuilder sqlNativo = new StringBuilder(
				"SELECT DISTINCT CP.*,PJ.TX_RAZAO_SOCIAL, PJ.TX_NOME_FANTASIA, PJ.TX_CNPJ, PJ.TX_UF_SIGLA, RM.TX_RAMO, CC.TX_CATEGORIA_COOPERATIVA, SC.TX_SITUACAO_COOPERATIVA "
						+ SQL_FROM_COOPERATIVA_COM_GRAU);

		montaQueryFiltro(sqlNativo, filtro, cooperativaFiltro);
		Query query = entityManager.createNativeQuery(sqlNativo.toString(), Cooperativa.class);

		sqlNativo = null;

		return query.getResultList();
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<CooperativaBasicaTO> buscaPorRazaoSocial(String razaoSocial) {
		StringBuilder sqlNativo = new StringBuilder();
		sqlNativo.append(" SELECT coop.SQ_COOPERATIVA, pj.TX_CNPJ, pj.TX_RAZAO_SOCIAL, pj.TX_NOME_FANTASIA");
		sqlNativo.append(" ,pj.TX_UF_SIGLA, rm.SQ_RAMO, rm.TX_RAMO");
		sqlNativo.append(" FROM COOPERATIVA coop WITH (NOLOCK) ");
		sqlNativo.append(" JOIN PESSOA_JURIDICA pj WITH (NOLOCK) ON coop.SQ_COOPERATIVA = pj.SQ_PESSOA");
		sqlNativo.append(" JOIN RAMO rm WITH (NOLOCK) ON pj.SQ_RAMO = rm.SQ_RAMO");
		sqlNativo.append(" WHERE coop.SQ_SITUACAO_COOPERATIVA IN (1,2,3)");
		sqlNativo.append(" AND PJ.IN_MATRIZ = 1 ");
		sqlNativo.append(" AND pj.TX_RAZAO_SOCIAL like '%" + razaoSocial + "%'");

		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		List<Object[]> resultList = query.getResultList();
		List<CooperativaBasicaTO> cooperativaDto = new ArrayList<>();

		resultList.forEach(obj -> cooperativaDto.add(new CooperativaBasicaTO((Integer) obj[0], (String) obj[1],
				(String) obj[2], (String) obj[3], (String) obj[4], ((Byte) obj[5]).intValue(), (String) obj[6])));

		query = null;
		resultList = null;

		return cooperativaDto;

	}

	/**
	 * Exportar arquivo excel das listagens de cooperativas em processo de registro
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<CooperativaListagemProcessoRegistroTO> filtrarCooperativaListagemProcessoRegistroExcel(
			CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro) {
		StringBuilder sqlNativo = new StringBuilder(
				" SELECT DISTINCT " +
						"    CP.SQ_COOPERATIVA, " +
						"    CP.TX_PROCESSO, " +
						"    PJ.TX_CNPJ, " +
						"    PJ.TX_NOME_FANTASIA, " +
						"    RM.TX_RAMO, " +
						"    CC.TX_CATEGORIA_COOPERATIVA, " +
						"    PJ.TX_UF_SIGLA, " +
						"    CP.DT_ABERTURA_PROCESSO_REGISTRO, " +
						"    CP.IN_PROGRESSO_MACRO, " +
						"    CP.DT_ATUALIZACAO, " +
						"    PJ.DT_CONSTITUICAO_FUNDACAO ");


		if (cooperativaFiltro.getApontamento() != null && cooperativaFiltro.getApontamento()) {
			sqlNativo.append(", MAX(AP.DT_APONTAMENTO) AS DT_APONTAMENTO ");
		}

		if (cooperativaFiltro.getApontamento() != null && cooperativaFiltro.getApontamento()) {
			sqlNativo.append(
					"FROM COOPERATIVA CP WITH (NOLOCK) " +
							" INNER JOIN PESSOA_JURIDICA PJ WITH (NOLOCK) ON CP.SQ_COOPERATIVA = PJ.SQ_PESSOA " +
							"INNER JOIN RAMO RM WITH (NOLOCK) ON PJ.SQ_RAMO = RM.SQ_RAMO " +
							"INNER JOIN PESSOA_SEGMENTO_PRODUTO_SERVICO SEG_PROD WITH (NOLOCK) ON PJ.SQ_PESSOA = SEG_PROD.SQ_PESSOA " +
							"INNER JOIN SEGMENTO SEG WITH (NOLOCK) ON SEG.SQ_RAMO = RM.SQ_RAMO " +
							"INNER JOIN SITUACAO_COOPERATIVA SC WITH (NOLOCK) ON CP.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA AND (CP.SQ_SITUACAO_COOPERATIVA = 4 OR CP.SQ_SITUACAO_COOPERATIVA IS NULL) " +
							"INNER JOIN CATEGORIA_COOPERATIVA CC WITH (NOLOCK) ON CP.SQ_CATEGORIA_COOPERATIVA = CC.SQ_CATEGORIA_COOPERATIVA ");
			sqlNativo.append("INNER JOIN COOPERATIVA_REGISTRO_APONTAMENTO AP ON CP.SQ_COOPERATIVA = AP.SQ_COOPERATIVA ");
		}else {
			sqlNativo.append(
					"FROM COOPERATIVA CP WITH (NOLOCK) " +
							" INNER JOIN PESSOA_JURIDICA PJ WITH (NOLOCK) ON CP.SQ_COOPERATIVA = PJ.SQ_PESSOA " +
							" LEFT JOIN RAMO RM WITH (NOLOCK) ON PJ.SQ_RAMO = RM.SQ_RAMO " +
							" LEFT JOIN PESSOA_SEGMENTO_PRODUTO_SERVICO SEG_PROD WITH (NOLOCK) ON PJ.SQ_PESSOA = SEG_PROD.SQ_PESSOA " +
							" LEFT JOIN SEGMENTO SEG WITH (NOLOCK) ON SEG.SQ_RAMO = RM.SQ_RAMO " +
							" INNER JOIN SITUACAO_COOPERATIVA SC WITH (NOLOCK) ON CP.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA AND (CP.SQ_SITUACAO_COOPERATIVA = 4 OR CP.SQ_SITUACAO_COOPERATIVA IS NULL) " +
							" LEFT JOIN CATEGORIA_COOPERATIVA CC WITH (NOLOCK) ON CP.SQ_CATEGORIA_COOPERATIVA = CC.SQ_CATEGORIA_COOPERATIVA ");
		}

		montaQueryFiltroNativo(sqlNativo, filtro, cooperativaFiltro, false);
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		List<Object[]> resultList = query.getResultList();
		List<CooperativaListagemProcessoRegistroTO> result = new ArrayList<>();

		if(cooperativaFiltro.getApontamento() != null && cooperativaFiltro.getApontamento()) {
			resultList.forEach(obj -> result.add(new CooperativaListagemProcessoRegistroTO((Integer) obj[0],
					(String) obj[1], (String) obj[2], (String) obj[3], (String) obj[4], (String) obj[5], (String) obj[6],
					(Date) obj[7], (String) obj[8], (Date) obj[9], (Date) obj[10], (String) obj[11])));
		}else{
			resultList.forEach(obj -> result.add(new CooperativaListagemProcessoRegistroTO((Integer) obj[0],
					(String) obj[1], (String) obj[2], (String) obj[3], (String) obj[4], (String) obj[5], (String) obj[6],
					(Date) obj[7], (String) obj[8], (Date) obj[9], (Date) obj[10])));
		}

		sqlNativo = null;
		resultList = null;
		query = null;

		return result;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<CooperativaListagemProcessoRegistroTO> filtrarCooperativaListagemProcessoRegistroAcompanhamentoExcel(
			CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro) {
		StringBuilder sqlNativo = new StringBuilder("SELECT DISTINCT PJ.TX_CNPJ, " + "PJ.TX_RAZAO_SOCIAL, "
				+ "ACOMP.TX_NOME_FANTASIA, " + "ACOMP.NR_PROCESSO, " + "ACOMP.TX_EMAIL_GERAL, "
				+ "ACOMP.TX_TELEFONE_GERAL, " + "ACOMP.REGIDA_LEI_12690, " + "ACOMP.TX_RAMO, "
				+ "ACOMP.TX_CATEGORIA_COOPERATIVA, " + "ACOMP.TX_NIRE, " + "ACOMP.TX_CEP, " + "ACOMP.TX_REGIAO_PAIS, "
				+ "PJ.TX_UF_SIGLA, " + "ACOMP.TX_NOME_REGIAO_UNIDADE_ESTADUAL, " + "ACOMP.TX_NOME_MUNICIPIO, "
				+ "ACOMP.DT_ATUALIZACAO, " + "ACOMP.DT_ABERTURA_PROCESSO_REGISTRO, " + "ACOMP.TEMPO_DECORRIDO_DIAS, "
				+ "ACOMP.DT_ULTIMA_ANALISE_UE, " + "ACOMP.CADASTRO_E_ENVIO_DOCUMENTOS, "
				+ "ACOMP.VALIDACAO_DADOS_DOCUMENTOS, " + "ACOMP.ANALISE_CONFORMIDADE_LEGAL, " + "ACOMP.VISITA_TECNICA, "
				+ "ACOMP.DELIBERACAO_UNIDADE_ESTADUAL, " + "ACOMP.DELIBERACAO_UNIDADE_NACIONAL " + CONSULTA_SQL
				+ "INNER JOIN VW_ACOMPANHAMENTO_COOPERATIVAS_NAO_REGISTRADAS ACOMP WITH (NOLOCK) "
				+ "ON CP.SQ_COOPERATIVA = ACOMP.SQ_PESSOA ");

		if (cooperativaFiltro.getApontamento() != null && cooperativaFiltro.getApontamento()) {
			sqlNativo.append("INNER JOIN COOPERATIVA_REGISTRO_APONTAMENTO AP ON CP.SQ_COOPERATIVA = AP.SQ_COOPERATIVA ");
		}

		montaQueryFiltroNativo(sqlNativo, filtro, cooperativaFiltro, true);
		Query query = entityManager.createNativeQuery(sqlNativo.toString(), Tuple.class);

		List<Tuple> resultList = query.getResultList();
		List<CooperativaListagemProcessoRegistroTO> result = new ArrayList<>();

		resultList.forEach(tuple -> result.add(new CooperativaListagemProcessoRegistroTO(
				tuple.get(TX_CNPJ, String.class), tuple.get(TX_RAZAO_SOCIAL, String.class),
				tuple.get(TX_NOME_FANTASIA, String.class), tuple.get("NR_PROCESSO", Integer.class),
				tuple.get("TX_EMAIL_GERAL", String.class), tuple.get("TX_TELEFONE_GERAL", String.class),
				tuple.get("REGIDA_LEI_12690", String.class), tuple.get(TX_RAMO, String.class),
				tuple.get(TX_CATEGORIA_COOPERATIVA, String.class), tuple.get("TX_NIRE", String.class),
				tuple.get("TX_CEP", String.class), tuple.get("TX_REGIAO_PAIS", String.class),
				tuple.get(TX_UF_SIGLA, String.class), tuple.get("TX_NOME_REGIAO_UNIDADE_ESTADUAL", String.class),
				tuple.get("TX_NOME_MUNICIPIO", String.class), tuple.get(DT_ATUALIZACAO, Date.class),
				tuple.get("DT_ABERTURA_PROCESSO_REGISTRO", Date.class),
				tuple.get("TEMPO_DECORRIDO_DIAS", Integer.class), tuple.get("DT_ULTIMA_ANALISE_UE", Date.class),
				tuple.get("CADASTRO_E_ENVIO_DOCUMENTOS", String.class),
				tuple.get("VALIDACAO_DADOS_DOCUMENTOS", String.class),
				tuple.get("ANALISE_CONFORMIDADE_LEGAL", String.class), tuple.get("VISITA_TECNICA", String.class),
				tuple.get("DELIBERACAO_UNIDADE_ESTADUAL", String.class),
				tuple.get("DELIBERACAO_UNIDADE_NACIONAL", String.class))));


		sqlNativo = null;
		resultList = null;
		query = null;

		return result;
	}

	@Override
	public List<CooperativaCnpjTO> buscaCooperativaTOporRamo(Integer idRamo, Integer anoAtual) {
		StringBuilder sqlNativo = new StringBuilder(

				"SELECT DISTINCT CP.SQ_COOPERATIVA,  PJ.TX_CNPJ, PJ.TX_EMAIL_GERAL FROM COOPERATIVA CP WITH (NOLOCK) "
						+ "						 JOIN PESSOA_JURIDICA PJ WITH (NOLOCK) ON CP.SQ_COOPERATIVA = PJ.SQ_PESSOA "
						+ "					WHERE PJ.SQ_RAMO = " + idRamo + "					AND NOT EXISTS("
						+ "						SELECT DISTINCT CP2.SQ_COOPERATIVA,  PJ2.TX_CNPJ FROM COOPERATIVA CP2 "
						+ "						 JOIN PESSOA_JURIDICA PJ2 WITH (NOLOCK) ON CP2.SQ_COOPERATIVA = PJ2.SQ_PESSOA "
						+ "						 JOIN COOPERATIVA_APROVACAO A WITH (NOLOCK) ON CP.SQ_COOPERATIVA = A.SQ_COOPERATIVA"
						+ "						WHERE PJ2.SQ_RAMO = " + idRamo
						+ "							AND CP2.SQ_SITUACAO_COOPERATIVA != 4" // diferente de 'Não
																							// Registradas'
						+ "							AND A.NR_ANO = " + anoAtual
						+ "							AND A.DT_ATUALIZACAO IS NOT NULL" + "					)");

		Query query = entityManager.createNativeQuery(sqlNativo.toString());
		@SuppressWarnings("unchecked")
		List<Object[]> resultList = query.getResultList();
		List<CooperativaCnpjTO> cooperativaDto = new ArrayList<>();

		// TODO PROVISÓRIO AJUSTAR NO SERVIÇO DE EMAIL
		resultList.forEach(
				obj -> cooperativaDto.add(new CooperativaCnpjTO((Integer) obj[0], (String) obj[1], (String) obj[2])));

		sqlNativo = null;
		query = null;
		resultList = null;

		return cooperativaDto;
	}

	// #MÉTODOS ÚTEIS#: Métodos de filtragem, ordenação e contagem

	void montaQueryFiltro(StringBuilder sqlNativo, FiltroTO filtro,
			CooperativaFiltroTO cooperativaFiltro) {

		sqlNativo.append(WHERE_PJ_IN_MATRIZ);

		// #FILTRO FIXO#: Responsável por validar usuários COOPERATIVA, ESTADUAL e
		// NACIONAL
		if (ValidacaoCampos.validaCampoPreenchido(filtro.getCnpj())) {
			sqlNativo.append(AND_PJ_TX_CNPJ_LIKE + filtro.getCnpj() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(filtro.getUf())) {
			sqlNativo.append(AND_PJ_TX_UF_SIGLA + filtro.getUf() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getUf())) {
			sqlNativo.append(AND_PJ_TX_UF_SIGLA + cooperativaFiltro.getUf() + "') ");
		}

		if ((cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia())
				&& ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getUfDestino())) {
			sqlNativo.append(" AND (ST.SQ_ESTADO_DESTINO_SEDE LIKE '%" + cooperativaFiltro.getUfDestino() + "%')");
		}

		// ##############################################################################

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getUf())) {
			sqlNativo.append(AND_PJ_TX_UF_SIGLA + cooperativaFiltro.getUf() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getIdCooperativa())) {
			sqlNativo.append(" AND ( CP.SQ_COOPERATIVA = " + cooperativaFiltro.getIdCooperativa() + " ) ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getPesquisaLivre())) {
			sqlNativo.append(AND_CP_TX_PROCESSO_LIKE + cooperativaFiltro.getPesquisaLivre() + "%' "
					+ " OR PJ.TX_NOME_FANTASIA LIKE '%" + cooperativaFiltro.getPesquisaLivre() + "%' "
					+ " OR PJ.TX_CNPJ LIKE '%" + cooperativaFiltro.getPesquisaLivre() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProcesso())) {
			sqlNativo.append(AND_CP_TX_PROCESSO_LIKE + cooperativaFiltro.getProcesso() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getNomeFantasia())) {
			sqlNativo.append(AND_PJ_TX_NOME_FANTASIA_LIKE + cooperativaFiltro.getNomeFantasia() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getCnpj())) {
			sqlNativo.append(" AND (PJ.TX_CNPJ like '%" + cooperativaFiltro.getCnpj() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getRamo())) {
			sqlNativo.append(" AND (RM.TX_RAMO like '%" + cooperativaFiltro.getRamo() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getDataAberturaProcesso())) {
			sqlNativo.append(
					" AND (CP.DT_ABERTURA_PROCESSO_REGISTRO = '" + cooperativaFiltro.getDataAberturaProcesso() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getDataUltimaSubmissao())) {
			sqlNativo.append(" AND (CP.DT_ULTIMA_SUBMISSAO_PROCESSO_REGISTRO = '"
					+ cooperativaFiltro.getDataUltimaSubmissao() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getNumeroRegistroOCB())) {
			sqlNativo.append(" AND (CP.TX_NUMERO_REGISTRO_OCB = '" + cooperativaFiltro.getNumeroRegistroOCB() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProgressoMacro())) {
			sqlNativo.append(" AND (CP.IN_PROGRESSO_MACRO LIKE '" + cooperativaFiltro.getProgressoMacro() + "') ");
		}

		// Filtros de Cooperativa
		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getSituacaoCooperativa())) {
			sqlNativo.append(
					" AND (SC.TX_SITUACAO_COOPERATIVA LIKE '" + cooperativaFiltro.getSituacaoCooperativa() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getNaoVisualizada())) {
			sqlNativo.append(" AND (CP.IN_ATUALIZACAO_NAO_VISUALIZADA = 1" + ") ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getArquivado())) {
			sqlNativo.append(" AND (CP.IN_ARQUIVADO = '" + cooperativaFiltro.getArquivado() + "') ");
		} else if (cooperativaFiltro.getArquivado() == null || !cooperativaFiltro.getArquivado()) {
			sqlNativo.append("  AND (CP.IN_ARQUIVADO IS NULL OR CP.IN_ARQUIVADO = '0')  ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProcessoTransferencia())) {
			sqlNativo.append(
					" AND (CP.IN_PROCESSO_TRANSFERENCIA = '" + cooperativaFiltro.getProcessoTransferencia() + "') ");
		} else if (cooperativaFiltro.getProcessoTransferencia() == null
				|| !cooperativaFiltro.getProcessoTransferencia()) {
			sqlNativo.append("  AND (CP.IN_PROCESSO_TRANSFERENCIA IS NULL OR CP.IN_PROCESSO_TRANSFERENCIA = '0')  ");
		}

		if (cooperativaFiltro.getCnpjResponsavel() != null && cooperativaFiltro.getCnpjResponsavel().length != 0) {
			sqlNativo.append(" AND (PJ.TX_CNPJ in (");

			for (int i = 0; i < cooperativaFiltro.getCnpjResponsavel().length; i++) {
				sqlNativo.append("'" + cooperativaFiltro.getCnpjResponsavel()[i] + "'  ");

				int countCnpj = i + 1;
				if (countCnpj < cooperativaFiltro.getCnpjResponsavel().length)
					sqlNativo.append(",");

			}

			sqlNativo.append(")) ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getPrazoRegistro())) {
			sqlNativo.append(" AND DATEADD(DAY, 60, CP.DT_ULTIMA_ANALISE_UE) = '").append(cooperativaFiltro.getPrazoRegistro()).append("'");
		}
	}

	private void montaQueryFiltroNativo(StringBuilder sql, FiltroTO filtroTO,
			CooperativaFiltroTO cooperativaFiltro, boolean processoAcompanhamento) {

		sql.append(WHERE_PJ_IN_MATRIZ);

		// #FILTRO FIXO#: Responsável por validar usuários COOPERATIVA, ESTADUAL e
		// NACIONAL
		if (ValidacaoCampos.validaCampoPreenchido(filtroTO.getCnpj())) {
			sql.append(AND_PJ_TX_CNPJ_LIKE + filtroTO.getCnpj() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(filtroTO.getUf())) {
			sql.append(AND_PJ_TX_UF_SIGLA + filtroTO.getUf() + "'");
			// Validação em caso de processo de transferência. Se true, adiciona UF de
			// destino como parâmetro de busca
			if (cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia()) {
				sql.append(" OR ST.SQ_ESTADO_DESTINO_SEDE = '" + filtroTO.getUf() + "'");
			}
			sql.append(") ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getUf())) {
			sql.append(AND_PJ_TX_UF_SIGLA + cooperativaFiltro.getUf() + "') ");
		}

		if ((cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia())
				&& ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getUfDestino())) {
			sql.append(" AND (ST.SQ_ESTADO_DESTINO_SEDE LIKE '%" + cooperativaFiltro.getUfDestino() + "%')");
		}

		// ##############################################################################

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getPesquisaLivre())) {
			sql.append(AND_CP_TX_PROCESSO_LIKE + cooperativaFiltro.getPesquisaLivre() + "%' "
					+ " OR PJ.TX_NOME_FANTASIA LIKE '%" + cooperativaFiltro.getPesquisaLivre() + "%' "
					+ " OR PJ.TX_CNPJ LIKE '%" + cooperativaFiltro.getPesquisaLivre() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProcesso())) {
			sql.append(AND_CP_TX_PROCESSO_LIKE + cooperativaFiltro.getProcesso() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getNomeFantasia())) {
			sql.append(AND_PJ_TX_NOME_FANTASIA_LIKE + cooperativaFiltro.getNomeFantasia() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getCnpj())) {
			sql.append(" AND (PJ.TX_CNPJ LIKE '%" + cooperativaFiltro.getCnpj() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getRamo())) {
			sql.append(" AND (RM.SQ_RAMO LIKE '%" + cooperativaFiltro.getRamo() + "%') ");
		}
		
		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getRamos())) {
			sql.append(" AND (RM.SQ_RAMO IN ("+ StringUtil.join(cooperativaFiltro.getRamos(), ",") +")) ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getIdSegmento())) {
			sql.append(" AND (SEG_PROD.SQ_SEGMENTO = " + cooperativaFiltro.getIdSegmento() + ") ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getDataAberturaProcesso())) {
			sql.append(
					" AND (CP.DT_ABERTURA_PROCESSO_REGISTRO = '" + cooperativaFiltro.getDataAberturaProcesso() + "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getDataUltimaSubmissao())) {
			sql.append(" AND (CP.DT_ULTIMA_SUBMISSAO_PROCESSO_REGISTRO = '" + cooperativaFiltro.getDataUltimaSubmissao()
					+ "') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getNumeroRegistroOCB())) {
			sql.append(" AND (CP.TX_NUMERO_REGISTRO_OCB LIKE '%" + cooperativaFiltro.getNumeroRegistroOCB() + "%') ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProgressoMacro())) {
			sql.append(" AND (CP.IN_PROGRESSO_MACRO LIKE '" + ProgressoMacroEnum.getValue(cooperativaFiltro.getProgressoMacro()).name() + "') ");
		}
		
		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProgressosMacros())
				|| ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProgressoMicro())) {
			String sqlFases = "";
			if(ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProgressosMacros())) {
				List<String> listProgressoMacro = Arrays.asList(cooperativaFiltro.getProgressosMacros()).stream().map(progresso -> "'" + ProgressoMacroEnum.getValue(progresso).name() + "'").toList();
				sqlFases = " (CP.IN_PROGRESSO_MACRO IN("+ StringUtil.join(listProgressoMacro, ",") +")) ";
			}
			
			if(ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProgressoMicro())) {
				sqlFases = sqlFases.isEmpty() ? sqlFases : sqlFases + " OR ";
				sqlFases += " (CP.IN_PROGRESSO_MICRO = '" + cooperativaFiltro.getProgressoMicro() + "') "; 
			}
			
			if(!sqlFases.isEmpty()) {
				sql.append(" AND ("+ sqlFases+ ") ");
			}
		}

		// Filtros de Cooperativa
		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getSituacaoCooperativa())) {
			if (cooperativaFiltro.getSituacaoCooperativa().equalsIgnoreCase("REGULAR,IRREGULAR")) {
				String situacoes[] = cooperativaFiltro.getSituacaoCooperativa().split(",");
				sql.append(" AND (SC.TX_NOVA_SITUACAO_COOPERATIVA LIKE '")
						.append(situacoes[0])
						.append("'")
						.append(" OR SC.TX_NOVA_SITUACAO_COOPERATIVA LIKE '")
						.append(situacoes[1])
						.append("') ");
			} else {
				sql.append(" AND (SC.TX_NOVA_SITUACAO_COOPERATIVA LIKE '" + cooperativaFiltro.getSituacaoCooperativa() + "') ");
			}
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getProcessoTransferencia())) {
			sql.append(" AND (CP.IN_PROCESSO_TRANSFERENCIA = '" + cooperativaFiltro.getProcessoTransferencia() + "') ");
			sql.append(" AND (ST.IN_APROVADO IS NULL)");
		} else if (cooperativaFiltro.getProcessoTransferencia() == null
				|| !cooperativaFiltro.getProcessoTransferencia()) {
			sql.append(" AND (CP.IN_PROCESSO_TRANSFERENCIA IS NULL OR CP.IN_PROCESSO_TRANSFERENCIA = '0')  ");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getNaoVisualizada())) {
			sql.append(" AND (CP.IN_ATUALIZACAO_NAO_VISUALIZADA = 1)  ");
		}


		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getArquivado())) {
			sql.append(" AND (CP.IN_ARQUIVADO = '" + cooperativaFiltro.getArquivado() + "') ");
		} else if (cooperativaFiltro.getArquivado() == null || !cooperativaFiltro.getArquivado()) {
			sql.append(" AND (CP.IN_ARQUIVADO IS NULL OR CP.IN_ARQUIVADO = '0')  ");
		}

		// se o campo: "Solicitação da unidade estadual" for marcado
		String filtro = "";
		if (cooperativaFiltro.getSolicitacaoAtivacao() != null || cooperativaFiltro.getSolicitacaoInativacao() != null
				|| cooperativaFiltro.getSolicitacaoCancelamento() != null) {

			if (cooperativaFiltro.getSolicitacaoAtivacao() != null && cooperativaFiltro.getSolicitacaoAtivacao()) {
				filtro = " CP.IN_SOLICITACAO_ATIVACAO = 1 ";
			}

			if (cooperativaFiltro.getSolicitacaoInativacao() != null && cooperativaFiltro.getSolicitacaoInativacao()) {
				if (!filtro.equals("")) {
					filtro += " OR ";
				}
				filtro += " CP.IN_SOLICITACAO_INATIVACAO = 1 ";
			}

			if (cooperativaFiltro.getSolicitacaoCancelamento() != null
					&& cooperativaFiltro.getSolicitacaoCancelamento()) {
				if (!filtro.equals("")) {
					filtro += " OR ";
				}
				filtro += " CP.IN_SOLICITACAO_CANCELADA = 1 ";
			}

			if (!filtro.equals("")) {
				sql.append(" AND (" + filtro + ") ");
			}

		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getCooperativaStatusManutencao())
				&& cooperativaFiltro.getCooperativaStatusManutencao()
						.equals(CooperativaStatusManutencaoEnum.DADOS_ATUALIZADOS)) {
			sql.append(" AND (DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(PJ.SQ_PESSOA) = 'Aprovada')");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getCooperativaStatusManutencao())
				&& cooperativaFiltro.getCooperativaStatusManutencao()
						.equals(CooperativaStatusManutencaoEnum.DADOS_DESATUALIZADOS)) {
			sql.append(
					" AND (DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(PJ.SQ_PESSOA) = 'Desatualizada')");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getCooperativaStatusManutencao())
				&& cooperativaFiltro.getCooperativaStatusManutencao()
						.equals(CooperativaStatusManutencaoEnum.AGUARDANDO_AJUSTE)) {
			sql.append(
					" AND (DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(PJ.SQ_PESSOA) = 'Aguardando ajustes')");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getCooperativaStatusManutencao())
				&& cooperativaFiltro.getCooperativaStatusManutencao()
						.equals(CooperativaStatusManutencaoEnum.AGUARDANDO_ANALISE)) {
			sql.append(
					" AND (DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(PJ.SQ_PESSOA) = 'Aguardando análise')");
		}

		if (ValidacaoCampos.validaCampoPreenchido(cooperativaFiltro.getApontamento())){
			sql.append(" AND AP.TX_APONTAMENTO IS NOT NULL ");
		}


		if (AnuarioEnum.PREENCHIDO.equals(cooperativaFiltro.getAnuario())) {
			sql.append(" AND AN.VL_ATIVO_TOTAL IS NOT NULL ");
		} else if (AnuarioEnum.NAO_PREENCHIDO.equals(cooperativaFiltro.getAnuario())) {
			sql.append(" AND AN.VL_ATIVO_TOTAL IS NULL ");
		}

		if(!processoAcompanhamento) {

			sql.append("GROUP BY " +
					"    CP.SQ_COOPERATIVA, " +
					"    TX_PROCESSO, " +
					"    PJ.TX_CNPJ, " +
					"    PJ.TX_NOME_FANTASIA, " +
					"    RM.TX_RAMO, " +
					"    CC.TX_CATEGORIA_COOPERATIVA, " +
					"    PJ.TX_UF_SIGLA, " +
					"    CP.DT_ABERTURA_PROCESSO_REGISTRO, " +
					"    CP.IN_PROGRESSO_MACRO, " +
					"    CP.DT_ATUALIZACAO, " +
					"    PJ.DT_CONSTITUICAO_FUNDACAO;");
		}

	}

	String ordenar(Pageable pageable) {
		Iterator<Sort.Order> iterator = pageable.getSort().iterator();
		StringBuilder orderSql = new StringBuilder("");
		int i = 0;
		while (iterator.hasNext()) {
			Sort.Order order = iterator.next();
			if (order != null) {
				String propriedade = order.getProperty();
				String direcao = order.getDirection().toString();
				orderSql.append(
						i == 0 ? " ORDER BY " + propriedade + " " + direcao : ", " + propriedade + " " + direcao);
			}
			i++;
		}
		return orderSql.toString();
	}

	private void restricoesDePaginacao(Query query, Pageable pageable) {
		int paginaAtual = pageable.getPageNumber();
		int totalRegistroPagina = pageable.getPageSize();
		int primeiroRegistroPagina = paginaAtual * totalRegistroPagina;
		query.setFirstResult(primeiroRegistroPagina);
		query.setMaxResults(totalRegistroPagina);
	}

	public Integer totalRegistros(StringBuilder sqlNativo, CooperativaFiltroTO cooperativaFiltro,
			FiltroTO filtro) {
		// substitui select com parâmetros por select count
		sqlNativo.replace(0, select.length(), "SELECT COUNT(DISTINCT PJ.SQ_PESSOA) ");

		// remove order by, caso exista
		if (sqlNativo.indexOf("ORDER BY") > -1) {
			sqlNativo.replace(sqlNativo.indexOf("ORDER BY"), sqlNativo.length(), "");
		}
		
		Query query = entityManager.createNativeQuery(sqlNativo.toString());
		return ((Integer) query.getSingleResult()).intValue();
	}

	private Integer totalRegistrosCoop(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro) {
		StringBuilder sqlNativo = new StringBuilder("SELECT COUNT(DISTINCT PJ.SQ_PESSOA) " + SQL_FROM_COOPERATIVA);
		montaQueryFiltro(sqlNativo, filtro, cooperativaFiltro);
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		sqlNativo = null;

		return ((Integer) query.getSingleResult()).intValue();
	}

	@Override
	public Object getNextValSequenciaNumeroRegistroOcb() {
		String sql = "SELECT NEXT VALUE FOR SEQUENCIA_NUMERO_REGISTRO_OCB as sq_numero_registro_ocb;";
		Query query = entityManager.createNativeQuery(sql);
		Object sqNumeroRegistroOcb = query.getSingleResult();
		return sqNumeroRegistroOcb;
	}

	@Override
	public Integer quatidadeCooperativasNaoRegistradasAguardandoPorProcessoMicroUnidadeEstadual(String uf) {
		String sql = "select COUNT(SQ_COOPERATIVA) from dbo.COOPERATIVA c INNER JOIN dbo.PESSOA_JURIDICA as pj WITH (NOLOCK) on pj.SQ_PESSOA = c.SQ_COOPERATIVA"
				+ " where IN_PROGRESSO_MICRO IN ('AGUARDANDO_ANALISE_2_1','AGUARDANDO_ANALISE_CONFORMIDADE_3_1','AGUARDANDO_PROPOSTA_DATA_4_1','AGUARDANDO_DELIBERACAO_5_1','AGUARDANDO_LIBERACAO_5_3')"
				+ " AND pj.TX_UF_SIGLA = ?1";
		Query query = entityManager.createNativeQuery(sql).setParameter(1, uf);
		Integer sqQt = (Integer) query.getSingleResult();

		query = null;

		return sqQt;
	}

	@Override
	public Integer quatidadeCooperativasRegistradasAguardandoPorProcessoMicroUnidadeEstadual(String uf) {
		String sql = "select COUNT(SQ_COOPERATIVA) from dbo.COOPERATIVA c INNER JOIN dbo.PESSOA_JURIDICA as pj WITH (NOLOCK) on pj.SQ_PESSOA = c.SQ_COOPERATIVA "
				+ " where IN_PROGRESSO_MICRO IN ('AGUARDANDO_ANALISE_2_1') AND pj.TX_UF_SIGLA = ?1";
		Query query = entityManager.createNativeQuery(sql).setParameter(1, uf);
		Integer sqQt = (Integer) query.getSingleResult();

		query = null;

		return sqQt;
	}

	@Override
	public Integer buscaRegistroAtualizacaoNaoVisualizada(String uf) {
		StringBuilder sqlNativo = new StringBuilder("SELECT COUNT (DISTINCT CP.SQ_COOPERATIVA) " + SQL_FROM_REGISTRO);
		sqlNativo.append(WHERE_PJ_IN_MATRIZ);
		sqlNativo.append(AND_ATUALIZACAO_NAO_VISUALIZADA);
		sqlNativo.append(" AND CP.IN_PROGRESSO_MICRO NOT IN ('" + ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1.name() + "'"
				+ "," + "'" + ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3.name() + "')");
		if (uf != null) {
			sqlNativo.append(" AND PJ.TX_UF_SIGLA = '" + uf + "' ");
		}
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		sqlNativo = null;

		return ((Integer) query.getSingleResult()).intValue();
	}

	@Override
	public Integer buscaAtualizacaoNaoVisualizadaRegistrada(String uf) {
		StringBuilder sqlNativo = new StringBuilder("SELECT COUNT (DISTINCT CP.SQ_COOPERATIVA) FROM COOPERATIVA CP WITH (NOLOCK) "
				+ SQL_JOIN_PESSOA_JURIDICA + SQL_JOIN_COOPERATIVA_REGISTRADA);
		sqlNativo.append(AND_ATUALIZACAO_NAO_VISUALIZADA);
		sqlNativo.append(" AND CP.IN_PROGRESSO_MICRO NOT IN ('" + ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1.name() + "'"
				+ "," + "'" + ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3.name() + "')");
		if (uf != null) {
			sqlNativo.append(" AND PJ.TX_UF_SIGLA = '" + uf + "' ");
		}
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		sqlNativo = null;

		return ((Integer) query.getSingleResult()).intValue();
	}

	@Override
	public Integer buscaRegistroAtualizacaoNacionalNaoVisualizada() {
		StringBuilder sqlNativo = new StringBuilder("SELECT COUNT (DISTINCT CP.SQ_COOPERATIVA) " + SQL_FROM_REGISTRO);
		sqlNativo.append(WHERE_PJ_IN_MATRIZ);
		sqlNativo.append(AND_ATUALIZACAO_NAO_VISUALIZADA);
		sqlNativo.append(" AND (CP.IN_PROGRESSO_MICRO = '" + ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1.name() + "' "
				+ "OR CP.IN_PROGRESSO_MICRO = '" + ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3.name() + "')");
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		sqlNativo = null;

		return ((Integer) query.getSingleResult()).intValue();
	}

	@Override
	public Integer buscaAtualizacaoNacionalNaoVisualizadaRegistrada() {
		StringBuilder sqlNativo = new StringBuilder("SELECT COUNT (DISTINCT CP.SQ_COOPERATIVA) FROM COOPERATIVA CP WITH (NOLOCK) "
				+ SQL_JOIN_PESSOA_JURIDICA + SQL_JOIN_COOPERATIVA_REGISTRADA);
		sqlNativo.append(WHERE_PJ_IN_MATRIZ);
		sqlNativo.append(AND_ATUALIZACAO_NAO_VISUALIZADA);
		sqlNativo.append(" AND (CP.IN_PROGRESSO_MICRO = '" + ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1.name() + "' "
				+ "OR CP.IN_PROGRESSO_MICRO = '" + ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3.name() + "') "
				+ " OR (CP.IN_SOLICITACAO_INATIVACAO = 1) ");
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		sqlNativo = null;

		return ((Integer) query.getSingleResult()).intValue();
	}

	@Override
	public List<CooperativaAnuarioTO> filtrarCooperativasAnuarioListagemExcel(CooperativaFiltroTO cooperativaFiltro,
			FiltroTO filtro) {
		select = "SELECT DISTINCT CP.SQ_COOPERATIVA, PJ.TX_CNPJ, PJ.TX_RAZAO_SOCIAL, PJ.TX_NOME_FANTASIA, PJ.TX_UF_SIGLA, RM.TX_RAMO, SC.TX_SITUACAO_COOPERATIVA, "
				+ " null, AN.VL_ATIVO_TOTAL, AN.VL_ATIVO_IMOBILIZADO, AN.VL_PATRIMONIO_LIQUIDO, AN.VL_CAPITAL_SOCIAL, AN.VL_SOBRAS_PERDAS_EXERCICIO,  "
				+ " AN.VL_INGRESSOS_RECEITAS_BRUTAS, AN.VL_TRIBUTOS, AN.VL_DESPESAS_PESSOAL, "
				+ " (SELECT CASE WHEN ANUARIO.VL_ATIVO_TOTAL IS NOT NULL THEN 'Preenchido'  END "
				+ " FROM COOPERATIVA COOP2 WITH (NOLOCK) "
				+ " LEFT JOIN COOPERATIVA_ANUARIO ANUARIO WITH (NOLOCK) ON COOP2.SQ_COOPERATIVA=ANUARIO.SQ_COOPERATIVA "
				+ " WHERE COOP2.SQ_COOPERATIVA=AN.SQ_COOPERATIVA) AS ANUARIO ";

		StringBuilder sqlNativo = null;
		sqlNativo = new StringBuilder(select + SQL_FROM_COOPERATIVA_COM_GRAU);

		montaQueryFiltroNativo(sqlNativo, filtro, cooperativaFiltro, false);
		Query query = entityManager.createNativeQuery(sqlNativo.toString());

		List<Object[]> resultList = query.getResultList();
		List<CooperativaAnuarioTO> cooperativaDto = new ArrayList<>();
		resultList.forEach(obj -> {
			cooperativaDto
					.add(new CooperativaAnuarioTO((Integer) obj[0], (String) obj[1], (String) obj[2], (String) obj[3],
							(String) obj[4], (String) obj[5], (String) obj[6], (Character) obj[7], (BigDecimal) obj[8],
							(BigDecimal) obj[9], (BigDecimal) obj[10], (BigDecimal) obj[11], (BigDecimal) obj[12],
							(BigDecimal) obj[13], (BigDecimal) obj[14], (BigDecimal) obj[15], (String) obj[16]));

		});

		query = null;
		resultList = null;
		sqlNativo = null;

		return cooperativaDto;
	}

	public String recuperaUsuarioAuditoria(Integer idCooperativa) {
		String select = "SELECT TOP(1) ra.NO_USUARIO " + "  FROM COOPERATIVA c WITH (NOLOCK) "
				+ "  JOIN COOPERATIVA_AUD ca WITH (NOLOCK) ON ca.SQ_COOPERATIVA = c.SQ_COOPERATIVA "
				+ "  JOIN REVISAO_AUDITORIA ra WITH (NOLOCK) ON ra.SQ_REVISAO = ca.SQ_REVISAO " + "  WHERE c.SQ_COOPERATIVA = ?1"
				+ "  ORDER BY ra.SQ_REVISAO DESC ";
		StringBuilder sqlNativo = null;
		sqlNativo = new StringBuilder(select);
		Query query = entityManager.createNativeQuery(sqlNativo.toString()).setParameter(1, idCooperativa);
		List<String> resultados = query.getResultList();

		select = null;
		sqlNativo = null;
		query = null;

		return !resultados.isEmpty() ? resultados.get(0) : null;
	}

}
