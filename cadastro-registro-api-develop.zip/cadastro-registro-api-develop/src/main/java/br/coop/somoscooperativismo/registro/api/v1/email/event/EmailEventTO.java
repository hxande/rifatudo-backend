package br.coop.somoscooperativismo.registro.api.v1.email.event;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import lombok.Data;

@Data
public class EmailEventTO {

	private Cooperativa cooperativa;
	private String nomeFantasia;
	private String destinatarios;
	private String email;
	private String arquivoBase64;
	private String nomeArquivo;
	private String login;
	private int ramo;
	private int ano;

}
