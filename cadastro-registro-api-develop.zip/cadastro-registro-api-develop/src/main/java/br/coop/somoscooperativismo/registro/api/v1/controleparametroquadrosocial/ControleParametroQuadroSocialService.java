package br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocial;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocial.entidade.ControleParametroQuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.parametroQuadroSocial.ParametroQuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.parametroQuadroSocial.entidade.ParametroQuadroSocial;

@Service
@Transactional
public class ControleParametroQuadroSocialService {

	private final ControleParametroQuadroSocialRepository controleParametroQuadroSocialRepository;
	private final KeycloakService keycloakService;
	private final ParametroQuadroSocialService parametroQuadroSocialService;

	public ControleParametroQuadroSocialService(
			ControleParametroQuadroSocialRepository controleParametroQuadroSocialRepository,
			KeycloakService keycloakService,
			ParametroQuadroSocialService parametroQuadroSocialService) {
		this.controleParametroQuadroSocialRepository = controleParametroQuadroSocialRepository;
		this.keycloakService = keycloakService;
		this.parametroQuadroSocialService = parametroQuadroSocialService;
	}
	
	public void habilitarDesabilitarCampos(boolean habilitar) {
		
		if(!keycloakService.isTipoEntidadeNacional()) {
			throw new RegraNegocioException("Usuário não possui permissão para realizar esta operação.");
		}
		
		ControleParametroQuadroSocial controleParametroQuadroSocial = null;
		List<ControleParametroQuadroSocial> listControleParametroQuadroSocial = controleParametroQuadroSocialRepository.findAll();
		
		controleParametroQuadroSocial = ValidacaoCampos.validaCampoPreenchido(listControleParametroQuadroSocial)
				? listControleParametroQuadroSocial.get(0)
				: new ControleParametroQuadroSocial();
		
		controleParametroQuadroSocial.setInformarCampos(habilitar);
		controleParametroQuadroSocial.setUsuario(keycloakService.getUsername());
		controleParametroQuadroSocial.setDataAlteracao(LocalDate.now());
		controleParametroQuadroSocialRepository.save(controleParametroQuadroSocial);
		
		List<ParametroQuadroSocial> listParametroQuadroSocial = parametroQuadroSocialService.findAll();
		if(ValidacaoCampos.validaCampoPreenchido(listParametroQuadroSocial)) {
			listParametroQuadroSocial.forEach(parametroQuadroSocial -> {
				parametroQuadroSocial.setObrigatorio(habilitar);
				parametroQuadroSocialService.saveParametroQuadroSocial(parametroQuadroSocial);
			});
		}

		listControleParametroQuadroSocial = null;
		listParametroQuadroSocial = null;
	}
	
	
	public Boolean obterControlePreenchimentoDadosAdicionais() {
		List<ControleParametroQuadroSocial> listaControleParametroQuadroSocial = controleParametroQuadroSocialRepository.findAll();
		
		return ValidacaoCampos.validaCampoPreenchido(listaControleParametroQuadroSocial) ? listaControleParametroQuadroSocial.get(0).getInformarCampos() : Boolean.FALSE;
	}
}
