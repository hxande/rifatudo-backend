package br.coop.somoscooperativismo.registro.api.v1.governanca;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cadastroregistro.CadastroRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.cargo.entidade.Cargo;
import br.coop.somoscooperativismo.registro.api.v1.client.PessoaClient;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.AbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.CooperativaManutencaoAbasService;
import br.coop.somoscooperativismo.registro.api.v1.escolaridade.EscolaridadeService;
import br.coop.somoscooperativismo.registro.api.v1.escolaridade.EscolaridadeTO;
import br.coop.somoscooperativismo.registro.api.v1.governanca.event.GovernancaDiretoriaGdhEvent;
import br.coop.somoscooperativismo.registro.api.v1.governanca.event.GovernancaPublisher;
import br.coop.somoscooperativismo.registro.api.v1.governanca.event.util.GovernancaEventEnum;
import br.coop.somoscooperativismo.registro.api.v1.governanca.rules.*;
import br.coop.somoscooperativismo.registro.api.v1.governanca.service.GovernancaContextFactory;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.*;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoRepository;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoService;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatoacao.AcaoGovernancaDescricaoBuilder;
import br.coop.somoscooperativismo.registro.api.v1.mandatoacao.TipoAcaoGovernancaEnum;
import br.coop.somoscooperativismo.registro.api.v1.mandatoacao.UltimaAcaoGovernancaService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.MandatoMembroRepository;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.MandatoMembroService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.orgao.VinculoEnum;
import br.coop.somoscooperativismo.registro.api.v1.orgao.entidade.Orgao;
import br.coop.somoscooperativismo.registro.api.v1.orgaocargo.OrgaoCargoRepository;
import br.coop.somoscooperativismo.registro.api.v1.orgaocargo.entidade.OrgaoCargo;
import br.coop.somoscooperativismo.registro.api.v1.orgaoramo.OrgaoRamoService;
import br.coop.somoscooperativismo.registro.api.v1.orgaoramo.entidade.OrgaoRamo;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.SituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaBlocoEnum;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.ValidacaoPendenciaTO;
import br.coop.somoscooperativismo.registro.api.v1.pessoafisica.entidade.PessoaFisica;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import br.coop.somoscooperativismo.registro.config.RabbitMQConfig;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.Years;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
@Slf4j
public class GovernancaService {

    private final MandatoService mandatoService;

    private final MandatoMembroService mandatoMembroService;

    private final CooperativaPendenciaService cooperativaPendenciaService;

    private final CooperativaService cooperativaService;

    private final CadastroRegistroService cadastroRegistroService;

    private final OrgaoRamoService orgaoRamoService;

    private final CooperativaManutencaoAbasService cooperativaManutencaoAbasService;

    private final OrgaoCargoRepository orgaoCargoRepository;

    private final PessoaClient pessoaClient;

    private final MessagesService messages;

    private final KeycloakService keycloakService;

    private final QuadroSocialService quadroSocialService;

    private final MandatoRepository mandatoRepository;

    private final MandatoMembroRepository mandatoMembroRepository;

    private final EscolaridadeService escolaridadeService;

    private final GovernancaPublisher governancaPublisher;

    private final GovernancaContextFactory governancaContextFactory;

    private final GovernancaRuleEngine governancaRuleEngine;

    private final GovernancaViolacaoRenderer governancaViolacaoRenderer;

    private final UltimaAcaoGovernancaService ultimaAcaoGovernancaService;

    private final OrgaoRamoResolver orgaoRamoResolver;

    public GovernancaService(
            MandatoService mandatoService,
            MandatoMembroService mandatoMembroService,
            CooperativaPendenciaService cooperativaPendenciaService,
            @Lazy CooperativaService cooperativaService,
            @Lazy CadastroRegistroService cadastroRegistroService,
            OrgaoRamoService orgaoRamoService,
            CooperativaManutencaoAbasService cooperativaManutencaoAbasService,
            OrgaoCargoRepository orgaoCargoRepository,
            PessoaClient pessoaClient,
            MessagesService messages,
            KeycloakService keycloakService,
            QuadroSocialService quadroSocialService,
            MandatoRepository mandatoRepository,
            MandatoMembroRepository mandatoMembroRepository,
            EscolaridadeService escolaridadeService,
            GovernancaPublisher governancaPublisher,
            GovernancaContextFactory governancaContextFactory,
            GovernancaRuleEngine governancaRuleEngine,
            GovernancaViolacaoRenderer governancaViolacaoRenderer,
            UltimaAcaoGovernancaService ultimaAcaoGovernancaService,
            OrgaoRamoResolver orgaoRamoResolver
    ) {
        this.mandatoService = Objects.requireNonNull(mandatoService, "mandatoService");
        this.mandatoMembroService = Objects.requireNonNull(mandatoMembroService, "mandatoMembroService");
        this.cooperativaPendenciaService = Objects.requireNonNull(cooperativaPendenciaService, "cooperativaPendenciaService");
        this.cooperativaService = Objects.requireNonNull(cooperativaService, "cooperativaService");
        this.cadastroRegistroService = Objects.requireNonNull(cadastroRegistroService, "cadastroRegistroService");
        this.orgaoRamoService = Objects.requireNonNull(orgaoRamoService, "orgaoRamoService");
        this.cooperativaManutencaoAbasService = Objects.requireNonNull(cooperativaManutencaoAbasService, "cooperativaManutencaoAbasService");
        this.orgaoCargoRepository = Objects.requireNonNull(orgaoCargoRepository, "orgaoCargoRepository");
        this.pessoaClient = Objects.requireNonNull(pessoaClient, "pessoaClient");
        this.messages = Objects.requireNonNull(messages, "messages");
        this.keycloakService = Objects.requireNonNull(keycloakService, "keycloakService");
        this.quadroSocialService = Objects.requireNonNull(quadroSocialService, "quadroSocialService");
        this.mandatoRepository = Objects.requireNonNull(mandatoRepository, "mandatoRepository");
        this.mandatoMembroRepository = Objects.requireNonNull(mandatoMembroRepository, "mandatoMembroRepository");
        this.escolaridadeService = Objects.requireNonNull(escolaridadeService, "escolaridadeService");
        this.governancaPublisher = Objects.requireNonNull(governancaPublisher, "governancaPublisher");
        this.governancaContextFactory = Objects.requireNonNull(governancaContextFactory, "governancaContextFactory");
        this.governancaRuleEngine = Objects.requireNonNull(governancaRuleEngine, "governancaRuleEngine");
        this.governancaViolacaoRenderer = Objects.requireNonNull(governancaViolacaoRenderer, "governancaViolacaoRenderer");
        this.ultimaAcaoGovernancaService = Objects.requireNonNull(ultimaAcaoGovernancaService, "ultimaAcaoGovernancaService");
        this.orgaoRamoResolver = Objects.requireNonNull(orgaoRamoResolver, "orgaoRamoResolver");
    }

    /**
     * Validação throw-first de gravação — ÚNICA para Registro e Manutenção.
     * Substitui o antigo {@code validarGovernanca(lista, coop, isManutencao)}:
     * elimina o ramo {@code isManutencao} divergente e delega as invariantes de
     * negócio ao MESMO {@link GovernancaRuleEngine} consumido pelo caminho de
     * leitura/pendências — o motor é o ponto único de verdade.
     *
     * <p>Apenas as violações
     * {@link br.coop.somoscooperativismo.registro.api.v1.governanca.rules.TipoViolacaoGovernanca#bloqueiaSalvamento() bloqueantes}
     * impedem o save (erros de integridade de entrada). As demais são pendências
     * que NÃO bloqueiam o salvar-por-conselho incremental e surgem
     * no fluxo de pendências / botão "Avançar". Os guard-rails de ordenação
     * de datas que o motor ainda não modela ficam em {@link #validarGuardRailsSalvar},
     * aplicados de forma idêntica nos dois fluxos.</p>
     */
    private void validarGovernancaParaSalvar(Cooperativa cooperativa, List<GovernancaTO> listaGovernancaTO) {
        // Representante legal: default null -> false (preserva o comportamento legado).
        for (GovernancaTO governancaTO : listaGovernancaTO) {
            for (MandatoMembro membro : membrosDe(governancaTO.getMandato())) {
                if (Objects.isNull(membro.getRepresentanteLegal())) {
                    membro.setRepresentanteLegal(false);
                }
            }
        }

        validarGuardRailsSalvar(cooperativa, listaGovernancaTO);

        List<Mandato> mandatosParaAvaliar = new ArrayList<>();
        for (GovernancaTO governancaTO : listaGovernancaTO) {
            Mandato mandato = governancaTO.getMandato().toEntity();
            // O save força vigente=true ao persistir; avalia sob a mesma premissa
            // para que as regras condicionadas a vigência avaliem o conselho salvo.
            mandato.setVigente(Boolean.TRUE);
            mandatosParaAvaliar.add(mandato);
        }
        GovernancaContext contexto = governancaContextFactory.criar(cooperativa, mandatosParaAvaliar);
        ResultadoValidacaoGovernanca resultado = governancaRuleEngine.avaliar(contexto);
        resultado.getViolacoes().stream()
                .filter(violacao -> violacao.tipo().bloqueiaSalvamento())
                .findFirst()
                .ifPresent(violacao -> {
                    throw new RegraNegocioException(governancaViolacaoRenderer.render(violacao));
                });

        validarCpfDuplicadoEntreConselhos(cooperativa, mandatosParaAvaliar);
    }

    /**
     * O salvar-por-conselho monta o contexto só com o conselho salvo, então a
     * {@link CpfDuplicadoRule} nunca enxerga um CPF ativo em OUTRO conselho —
     * regressão do throw do legado. Reavalia APENAS a regra de CPF sobre o
     * conjunto agregado (demais mandatos vigentes persistidos + conselhos sob
     * gravação), sem expor os outros conselhos às demais regras (o save
     * incremental de um conselho não pode ser bloqueado por pendência alheia).
     *
     * <p>A colisão de CPF entre payload (mascarado) e banco (sem
     * máscara) é responsabilidade da {@link CpfDuplicadoRule}, que normaliza o
     * CPF. Aqui só bloqueiam as violações que apontam para um conselho SOB
     * GRAVAÇÃO — duplicidade restrita aos demais conselhos persistidos é
     * problema alheio e não trava este save.</p>
     */
    private void validarCpfDuplicadoEntreConselhos(Cooperativa cooperativa, List<Mandato> mandatosParaAvaliar) {
        Set<Integer> orgaosSobGravacao = mandatosParaAvaliar.stream()
                .map(Mandato::getOrgao)
                .filter(Objects::nonNull)
                .map(Orgao::getId)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        Set<String> nomesOrgaosSobGravacao = mandatosParaAvaliar.stream()
                .map(Mandato::getOrgao)
                .filter(Objects::nonNull)
                .map(Orgao::getNome)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        // Persistidos primeiro: a violação (2ª ocorrência) aponta para o conselho sendo salvo.
        List<Mandato> conjuntoAgregado = new ArrayList<>();
        mandatoService.getMandatosPorCooperativa(cooperativa.getId()).stream()
                .filter(m -> Boolean.TRUE.equals(m.getVigente()))
                .filter(m -> Objects.nonNull(m.getOrgao()) && !orgaosSobGravacao.contains(m.getOrgao().getId()))
                .forEach(conjuntoAgregado::add);
        if (conjuntoAgregado.isEmpty()) {
            return;
        }
        conjuntoAgregado.addAll(mandatosParaAvaliar);

        GovernancaContext contextoAgregado = GovernancaContext.builder()
                .cooperativa(cooperativa)
                .mandatos(conjuntoAgregado)
                .build();
        new CpfDuplicadoRule().avaliar(contextoAgregado).stream()
                .filter(violacao -> Objects.nonNull(violacao.orgaoNome())
                        && nomesOrgaosSobGravacao.contains(violacao.orgaoNome()))
                .findFirst()
                .ifPresent(violacao -> {
                    throw new RegraNegocioException(governancaViolacaoRenderer.render(violacao));
                });
    }

    /**
     * Guard-rails de ordenação de datas que o {@link GovernancaRuleEngine} ainda não
     * modela (início ≥ constituição; fim ≥ início), aplicados de forma idêntica nos
     * dois fluxos — sem ramo {@code isManutencao}. As demais checagens de data
     * (início × assembleia, início futuro, fim obrigatório de inativo) já são do
     * motor (DatasMandatoRule/MembroInativoComFimRule). Candidatos a virar regra do
     * motor quando a rede de ITs de paridade estiver consolidada.
     */
    private void validarGuardRailsSalvar(Cooperativa cooperativa, List<GovernancaTO> listaGovernancaTO) {
        PessoaJuridica pessoaJuridica = cooperativa.getPessoaJuridica();
        Date constituicao = Objects.nonNull(pessoaJuridica) ? pessoaJuridica.getDataConstituicao() : null;
        for (GovernancaTO governancaTO : listaGovernancaTO) {
            MandatoTO mandato = governancaTO.getMandato();
            boolean contratacao = Objects.nonNull(mandato.getOrgao())
                    && VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo());
            for (MandatoMembro membro : membrosDe(mandato)) {
                // Paridade legada: sem a data
                // de constituição não há como checar datas×constituição — o legado
                // bloqueava o save do membro; o skip silencioso deixava mandatos
                // persistirem sem nenhuma checagem.
                if (Objects.isNull(constituicao)) {
                    throw new RegraNegocioException(
                            "A Data de constituição da cooperativa não foi definida nos dados gerais.");
                }
                String nome = Objects.nonNull(membro.getPessoaFisica()) ? membro.getPessoaFisica().getNome() : null;
                String cpf = Objects.nonNull(membro.getPessoaFisica()) ? membro.getPessoaFisica().getCpf() : null;
                Date inicio = membro.getInicioMandato();
                Date fim = membro.getFimMandato();
                // "contrato" só cabe no vínculo CONTRATAÇÃO; órgão eletivo tem mandato.
                String termoVinculo = contratacao ? "contrato" : "mandato";
                if (Objects.nonNull(inicio) && DataUtil.ignoreTime(inicio).before(DataUtil.ignoreTime(constituicao))) {
                    throw new RegraNegocioException(String.format(
                            "Data de início de %s do %s não pode ser menor que a data de constituição da cooperativa",
                            termoVinculo, nome));
                }
                if (Objects.nonNull(fim) && Objects.nonNull(inicio)
                        && DataUtil.ignoreTime(fim).before(DataUtil.ignoreTime(inicio))) {
                    if (contratacao) {
                        throw new RegraNegocioException(mandato.getOrgao().getNome() + ": "
                                + messages.get(GovernancaConstants.DATA_FIM_SUPERIOR_CONTRATACAO)
                                + RemoveMascaraUtil.mascaraCPF(cpf));
                    }
                    throw new RegraNegocioException(String.format(
                            "Data de fim de mandato do %s não pode ser menor que a data de início do mandato", nome));
                }
                if (Objects.nonNull(fim) && Objects.nonNull(mandato.getDataAssembleia())
                        && DataUtil.ignoreTime(fim).before(DataUtil.ignoreTime(mandato.getDataAssembleia()))) {
                    throw new RegraNegocioException(mandato.getOrgao().getNome() + ": "
                            + messages.get(GovernancaConstants.DESLIGAMENTO_ANTERIOR_ASSEMBLEIA) + " "
                            + RemoveMascaraUtil.mascaraCPF(cpf));
                }
            }
        }
    }

    /**
     * Lista defensiva de membros de um {@link MandatoTO}.
     */
    private List<MandatoMembro> membrosDe(MandatoTO mandato) {
        return Objects.isNull(mandato) || Objects.isNull(mandato.getListaMandatoMembro())
                ? Collections.emptyList()
                : mandato.getListaMandatoMembro();
    }

    /**
     * Salvar-por-conselho: grava SOMENTE o órgão informado
     * (mandato + membros), com isolamento por conselho — não toca os
     * demais conselhos da cooperativa (sem {@code excluiMandatosContratados}
     * cooperativa-wide). Valida pelas mesmas regras do Registro (sem ramo
     * {@code isManutencao}) e grava a {@code dataAtualizacao} em 100% dos
     * saves. Preserva a integração GDH (RabbitMQ) dos membros do conselho.
     *
     * <p>SUBSTITUIU o salvar-da-aba: {@code salvar()} e os endpoints
     * {@code POST /{idCooperativa}} / {@code POST /cria-governanca/{idCooperativa}}
     * foram removidos. Este é o único caminho de gravação da aba,
     * para os dois fluxos.</p>
     */
    @Transactional
    public MandatoTO salvarPorConselho(Integer idCooperativa, Integer idOrgao, @Valid MandatoTO mandatoFront, boolean manutencao) {
        // A permissão de edição depende da fase do cadastro (registro inicial × manutenção).
        Boolean podeEditar = manutencao
                ? cadastroRegistroService.podePreencherCadastroRegistroManutencao(idCooperativa)
                : cadastroRegistroService.podePreencherCadastroRegistroCooperativaBasico(idCooperativa);
        if (Boolean.FALSE.equals(podeEditar)) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.AGUARDE_ANDAMENTO));
        }
        if (Objects.isNull(mandatoFront.getOrgao()) || !Objects.equals(idOrgao, mandatoFront.getOrgao().getId())) {
            throw new RegraNegocioException("O órgão do mandato não corresponde ao conselho informado.");
        }

        Cooperativa cooperativa = cooperativaService.findById(idCooperativa);
        mandatoFront.setCooperativa(cooperativa);

        // Mesmas regras do Registro, restritas a este conselho (lista de um).
        GovernancaTO governancaTO = new GovernancaTO();
        governancaTO.setMandato(mandatoFront);
        List<GovernancaTO> umConselho = List.of(governancaTO);
        // inicioMandato := dataAssembleia é regra EXCLUSIVA do Registro legado; na
        // Manutenção sobrescreveria as datas históricas de entrada de cada membro.
        if (!manutencao) {
            atualizarDataInicioMandato(umConselho);
        }
        verificaMandatoAprovado(mandatoFront.toEntity());
        validarGovernancaParaSalvar(cooperativa, umConselho);
        verificaGovernancaFoiPreenchidaRefatorada(mandatoFront);

        // Define a quantidade de membros quando o vínculo do órgão for CONTRATAÇÃO.
        Predicate<Mandato> filtroContratacao = m -> VinculoEnum.CONTRATACAO.toString().equals(m.getOrgao().getVinculo());
        boolean contratacao = filtroContratacao.test(mandatoFront.toEntity());
        if (contratacao) {
            mandatoFront.setMembrosMandato(mandatoFront.getListaMandatoMembro().size());
            mandatoFront.setAnosDuracao(null);
        }

        // Isolamento por conselho: considera apenas os mandatos persistidos DESTE órgão.
        // Defesa em profundidade: se o front reenviar id=null após um
        // save (2º Salvar do mesmo conselho), casa pelo mandato VIGENTE do órgão em vez
        // de criar um SEGUNDO vigente — paridade com buscarMandatoVigenteOrgao do legado.
        Mandato mandatoBanco = mandatoService.getMandatosPorCooperativa(idCooperativa).stream()
                .filter(m -> Objects.nonNull(m.getOrgao()) && Objects.equals(m.getOrgao().getId(), idOrgao))
                .filter(m -> Objects.equals(m.getId(), mandatoFront.getId())
                        || (Objects.isNull(mandatoFront.getId()) && Boolean.TRUE.equals(m.getVigente())))
                .findFirst().orElse(null);

        // Snapshot para o diff (antes → depois) da descrição da trilha — capturado
        // ANTES da reconciliação: mandatoBanco é mutado adiante e é o próprio objeto salvo.
        AcaoGovernancaDescricaoBuilder.MandatoAntes mandatoAntes = AcaoGovernancaDescricaoBuilder.snapshot(mandatoBanco);

        Map<Integer, String> cpfsAntesDoSave = cpfsPersistidos(mandatoBanco);

        // Snapshot dos membros ativos ANTES da reconciliação (as listas do
        // mandatoBanco são mutadas adiante) para classificar a ação da trilha:
        // ativo no banco → inativo no payload = inativação registrada.
        List<String> membrosInativadosNoSave = new ArrayList<>();
        List<Integer> membrosReativadosNoSave = new ArrayList<>();
        List<MandatoMembro> desligadosSemDataNoSave = new ArrayList<>();
        int ativosAntesDoSave = 0;
        if (Objects.nonNull(mandatoBanco) && Objects.nonNull(mandatoBanco.getListaMandatoMembro())) {
            for (MandatoMembro mb : mandatoBanco.getListaMandatoMembro()) {
                if (!Boolean.TRUE.equals(mb.getMembroAtivo())) {
                    mandatoFront.getListaMandatoMembro().stream()
                            .filter(mf -> (Objects.nonNull(mf.getId()) && mf.getId().equals(mb.getId()))
                                    || (Objects.isNull(mf.getId()) && Objects.nonNull(mf.getPessoaFisica())
                                    && Objects.nonNull(mb.getPessoaFisica()) && Objects.nonNull(mb.getPessoaFisica().getCpf())
                                    && mb.getPessoaFisica().getCpf().equals(mf.getPessoaFisica().getCpf())))
                            .findFirst()
                            .filter(mf -> Boolean.TRUE.equals(mf.getMembroAtivo()))
                            .ifPresent(mf -> membrosReativadosNoSave.add(mb.getId()));
                    continue;
                }
                ativosAntesDoSave++;
                mandatoFront.getListaMandatoMembro().stream()
                        .filter(mf -> (Objects.nonNull(mf.getId()) && mf.getId().equals(mb.getId()))
                                || (Objects.isNull(mf.getId()) && Objects.nonNull(mf.getPessoaFisica())
                                && Objects.nonNull(mb.getPessoaFisica()) && Objects.nonNull(mb.getPessoaFisica().getCpf())
                                && mb.getPessoaFisica().getCpf().equals(mf.getPessoaFisica().getCpf())))
                        .findFirst()
                        .filter(mf -> Boolean.FALSE.equals(mf.getMembroAtivo()))
                        .ifPresent(mf -> {
                            membrosInativadosNoSave.add(identificaMembro(mf));
                            if (Objects.isNull(mf.getFimMandato())) {
                                desligadosSemDataNoSave.add(mf);
                            }
                        });
            }
        }

        validarDesligamentoComData(mandatoFront, desligadosSemDataNoSave);

        // Desmarcar órgão ESTATUTÁRIO com mandato APROVADO que ainda tem membro
        // ATIVO é rejeitado — o mandato deve ser encerrado primeiro. Mandato sem
        // aprovação é rascunho e pode ser desmarcado direto. Enforcement no
        // backend: protege UI, API direta e importação.
        if (!contratacao && Boolean.FALSE.equals(mandatoFront.getCoopPossui()) && Objects.nonNull(mandatoBanco)) {
            if (Objects.nonNull(mandatoBanco.getAprovacao()) && GovernancaContext.membrosAtivos(mandatoBanco) > 0) {
                throw new RegraNegocioException(messages.get(GovernancaConstants.ORGAO_COM_MANDATO_ATIVO) + " "
                        + mandatoFront.getOrgao().getNome());
            }
            return encerrarOrgaoOpcionalDesmarcado(cooperativa, idCooperativa, mandatoBanco, manutencao, idOrgao);
        }

        validarDatasAssembleiaOrgao(mandatoFront, mandatoBanco, idOrgao, idCooperativa);

        // Desmarcar a DC (coopPossui=false) DESATIVA em vez de excluir: membros
        // ativos recebem fimMandato=dataFimContrato (validada ≥ início de cada
        // contrato e ≤ hoje) e o mandato é encerrado — histórico preservado.
        // Vale para mandato aprovado e não aprovado, para qualquer perfil
        // habilitado (a DC permanece exceção às travas de aprovação).
        if (contratacao && Boolean.FALSE.equals(mandatoFront.getCoopPossui())) {
            if (Objects.isNull(mandatoBanco)) {
                aplicarEfeitosProcessoSalvar(cooperativa, idCooperativa, manutencao, idOrgao);
                mandatoFront.setId(null);
                mandatoFront.setVigente(false);
                mandatoFront.setDataAtualizacao(new Date());
                return mandatoFront;
            }
            List<MandatoMembro> membrosAtivos = mandatoMembroService.getMandatosMembroPorMandato(mandatoBanco.getId())
                    .stream().filter(mb -> Boolean.TRUE.equals(mb.getMembroAtivo()))
                    .collect(Collectors.toList());
            Date dataFimContrato = mandatoFront.getDataFimContrato();
            if (!membrosAtivos.isEmpty()) {
                validarDataFimContratoDesmarque(dataFimContrato, membrosAtivos);
                for (MandatoMembro membro : membrosAtivos) {
                    membro.setFimMandato(dataFimContrato);
                    membro.setMembroAtivo(false);
                    mandatoMembroService.salvar(membro);
                }
            }
            mandatoBanco.setCoopPossui(false);
            mandatoBanco.setVigente(false);
            if (Objects.nonNull(dataFimContrato)) {
                mandatoBanco.setFimMandato(dataFimContrato);
            }
            mandatoService.updateMandato(mandatoBanco);
            // Trilha: INATIVACAO_EM_MASSA reusado com descrição específica de DC.
            ultimaAcaoGovernancaService.registrar(TipoAcaoGovernancaEnum.INATIVACAO_EM_MASSA, mandatoBanco,
                    AcaoGovernancaDescricaoBuilder.desmarcacaoDiretoriaContratada(dataFimContrato, membrosAtivos));
            // GDH: desativações propagadas como membros atualizados.
            publicarEventosGdhConselho(idCooperativa, Collections.emptyList(), membrosAtivos);
            aplicarEfeitosProcessoSalvar(cooperativa, idCooperativa, manutencao, idOrgao);
            MandatoTO retorno = mandatoBanco.toDto();
            ultimaAcaoGovernancaService.preencherUltimaAcao(retorno);
            return retorno;
        }

        List<MandatoMembro> membrosAdicionados = new ArrayList<>();
        List<MandatoMembro> membrosAtualizados = new ArrayList<>();

        // Remove membro(s) excluído(s) (mesma diferença ativa/inativa do salvar).
        if (Objects.nonNull(mandatoBanco) && Objects.nonNull(mandatoBanco.getId())) {
            Iterator<MandatoMembro> iterator = mandatoBanco.getListaMandatoMembro().iterator();
            while (iterator.hasNext()) {
                MandatoMembro mb = iterator.next();
                boolean membroRemovido = mandatoFront.getListaMandatoMembro().stream()
                        .noneMatch(mf -> Objects.equals(mb.getId(), mf.getId())
                                || Objects.equals(
                                mb.getPessoaFisica().getCpf(),
                                mf.getPessoaFisica().getCpf()));
                if (membroRemovido) {
                    if (preservadoNaAusenciaDoPayload(mandatoBanco, mb)) {
                        continue;
                    }
                    mandatoMembroService.excluir(mb);
                    iterator.remove();
                }
            }
        }

        Mandato mandatoASalvar = Objects.nonNull(mandatoBanco) ? mandatoBanco : new Mandato();
        atualizaDadosMandato(mandatoASalvar, mandatoFront.toEntity());

        for (MandatoMembro mf : mandatoFront.getListaMandatoMembro()) {
            if (Objects.isNull(mandatoFront.getDataAssembleia())
                    && "ESTATUTÁRIO ELETIVO".equals(mandatoFront.getOrgao().getVinculo())) {
                throw new RegraNegocioException("Não é possível salvar. A data da assembleia é obrigatória.");
            }

            validarCpfImutavel(mandatoBanco, cpfsAntesDoSave, mf);

            // Casa por id; membro reenviado com id=null (2º Salvar sem reload) casa por
            // CPF — paridade com obterMembroPorCpf do legado: sem isso
            // o membro duplicaria no mandato e estouraria o índice único filtrado.
            MandatoMembro membroASalvar = Objects.isNull(mandatoASalvar.getListaMandatoMembro())
                    ? mf
                    : mandatoASalvar.getListaMandatoMembro().stream()
                    .filter(mb -> (Objects.nonNull(mb.getId()) && Objects.equals(mb.getId(), mf.getId()))
                            || (Objects.isNull(mf.getId())
                            && Objects.nonNull(mb.getPessoaFisica())
                            && Objects.nonNull(mf.getPessoaFisica())
                            && Objects.equals(
                            mb.getPessoaFisica().getCpf(),
                            mf.getPessoaFisica().getCpf())))
                    .findFirst()
                    .orElse(mf);

            if (Objects.isNull(membroASalvar.getAprovacao())) {
                membroASalvar.setAprovacao(mf.getAprovacao());
            }
            membroASalvar.setCargo(mf.getCargo());
            membroASalvar.setCooperativa(idCooperativa);
            membroASalvar.setFimMandato(mf.getFimMandato());
            membroASalvar.setInicioMandato(mf.getInicioMandato());
            membroASalvar.setMandato(mandatoASalvar);
            membroASalvar.setMembroAtivo(mf.getMembroAtivo());
            membroASalvar.setRepresentanteLegal(mf.getRepresentanteLegal());
            membroASalvar.setPessoaFisica(mf.getPessoaFisica());
            membroASalvar.setPessoaFisica(salvaPessoaFisica(membroASalvar));
            verificaMembroAprovado(membroASalvar);
            if (Objects.isNull(membroASalvar.getId())) {
                mandatoASalvar.getListaMandatoMembro().add(membroASalvar);
                membrosAdicionados.add(membroASalvar);
            } else {
                mandatoMembroService.updateMandatoMembro(membroASalvar);
                membrosAtualizados.add(membroASalvar);
            }
        }

        validarLimiteEleitosNaReativacao(mandatoASalvar, membrosReativadosNoSave, contratacao);
        validarQuantidadeDeclarada(mandatoASalvar, ativosAntesDoSave, contratacao);

        // Vigência única por órgão: encerra o último não-vigente do MESMO órgão.
        // O encerramento exige dataAssembleia: Joda new DateTime(null) = agora, e o
        // mandato antigo receberia fimMandato=ontem (CONTRATAÇÃO sem
        // assembleia não encerra o anterior).
        if (Boolean.TRUE.equals(mandatoASalvar.getVigente())
                && Objects.nonNull(mandatoASalvar.getDataAssembleia())) {
            List<Mandato> mandatosAnteriores = mandatoService.getMandatosNaoVigentes(idOrgao, idCooperativa);
            if (!mandatosAnteriores.isEmpty()) {
                Mandato ultimoMandatoNaoVigente = mandatosAnteriores.get(0);
                if (Objects.nonNull(ultimoMandatoNaoVigente.getAprovacao())) {
                    ultimoMandatoNaoVigente
                            .setFimMandato(new DateTime(mandatoASalvar.getDataAssembleia()).plusDays(-1).toDate());
                    mandatoService.updateMandato(ultimoMandatoNaoVigente);
                }
            }
        }
        mandatoASalvar.setVigente(true);
        mandatoASalvar.setCoopPossui(Objects.isNull(mandatoASalvar.getCoopPossui()) ? Boolean.FALSE : mandatoASalvar.getCoopPossui());

        sincronizarMembrosMandato(mandatoASalvar);

        // dataAtualizacao gravada em 100% dos saves por conselho.
        mandatoASalvar.setDataAtualizacao(new Date());

        Mandato salvo = mandatoService.salvar(mandatoASalvar);

        // Bookkeeping de processo do save legado: pendências do
        // analista, status/badge da aba e ciclo de manutenção.
        aplicarEfeitosProcessoSalvar(cooperativa, idCooperativa, manutencao, idOrgao);

        // Registra a ação na trilha append-only (ponto único de registro).
        // Inativação detectada no snapshot classifica o tipo; "em massa" = todos os
        // ativos do banco inativados neste save (fluxo de órgão desmarcado).
        TipoAcaoGovernancaEnum tipoAcao = TipoAcaoGovernancaEnum.SALVAR_CONSELHO;
        if (!membrosInativadosNoSave.isEmpty() && membrosReativadosNoSave.isEmpty()) {
            boolean todosAtivosInativados = membrosInativadosNoSave.size() == ativosAntesDoSave
                    && membrosInativadosNoSave.size() > 1;
            tipoAcao = todosAtivosInativados
                    ? TipoAcaoGovernancaEnum.INATIVACAO_EM_MASSA
                    : TipoAcaoGovernancaEnum.INATIVACAO_MEMBRO;
        } else if (membrosInativadosNoSave.isEmpty() && !membrosReativadosNoSave.isEmpty()) {
            tipoAcao = TipoAcaoGovernancaEnum.REATIVACAO_MEMBRO;
        }
        // Descrição rica (linha 1 = resumo, demais = antes → depois) derivada do
        // snapshot pré-reconciliação × mandato salvo.
        String descricaoAcao = AcaoGovernancaDescricaoBuilder.salvarConselho(mandatoAntes, salvo, membrosAdicionados);
        ultimaAcaoGovernancaService.registrar(tipoAcao, salvo, descricaoAcao);

        // Preserva a integração GDH via RabbitMQ — apenas os membros deste conselho.
        publicarEventosGdhConselho(idCooperativa, membrosAdicionados, membrosAtualizados);

        MandatoTO retorno = salvo.toDto();
        ultimaAcaoGovernancaService.preencherUltimaAcao(retorno);
        return retorno;
    }

    /**
     * O desligamento efetuado NO PRÓPRIO save exige a data de fim. A
     * {@link br.coop.somoscooperativismo.registro.api.v1.governanca.rules.MembroInativoComFimRule}
     * deixou de bloquear a gravação (inativo legado sem data travava o conselho inteiro,
     * sem campo na tela do Registro para corrigir); esta guarda mantém a exigência onde
     * ela é acionável — o membro que está sendo inativado agora.
     */
    private void validarDesligamentoComData(MandatoTO mandatoFront, List<MandatoMembro> desligadosSemData) {
        if (desligadosSemData.isEmpty()) {
            return;
        }
        MandatoMembro membro = desligadosSemData.get(0);
        String cpf = Objects.nonNull(membro.getPessoaFisica()) ? membro.getPessoaFisica().getCpf() : null;
        String nomeOrgao = Objects.nonNull(mandatoFront.getOrgao()) ? mandatoFront.getOrgao().getNome() : null;
        throw new RegraNegocioException(governancaViolacaoRenderer.render(
                ViolacaoGovernanca.deMembro(TipoViolacaoGovernanca.FIM_OBRIGATORIO_INATIVO, nomeOrgao, cpf)));
    }

    private MandatoTO encerrarOrgaoOpcionalDesmarcado(Cooperativa cooperativa, Integer idCooperativa,
                                                      Mandato mandatoBanco, boolean manutencao, Integer idOrgao) {
        boolean semHistorico = GovernancaContext.membros(mandatoBanco).isEmpty();
        List<MandatoMembro> desativados = desligarMembrosDoOrgaoDesmarcado(mandatoBanco);
        mandatoBanco.setCoopPossui(false);
        mandatoBanco.setVigente(false);
        mandatoBanco.setDataAtualizacao(new Date());
        if (semHistorico) {
            mandatoBanco.setDataAssembleia(null);
            mandatoBanco.setAnosDuracao(null);
            mandatoBanco.setMembrosMandato(0);
        }
        mandatoService.updateMandato(mandatoBanco);
        publicarEncerramentoGdh(idCooperativa, mandatoBanco, desativados);
        ultimaAcaoGovernancaService.registrar(TipoAcaoGovernancaEnum.ENCERRAMENTO_MANDATO, mandatoBanco,
                AcaoGovernancaDescricaoBuilder.desmarcacaoOrgaoOpcional(mandatoBanco, semHistorico));
        aplicarEfeitosProcessoSalvar(cooperativa, idCooperativa, manutencao, idOrgao);
        MandatoTO retorno = mandatoBanco.toDto();
        ultimaAcaoGovernancaService.preencherUltimaAcao(retorno);
        return retorno;
    }

    /**
     * Desmarcar órgão opcional encerra o mandato e DESLIGA todos os membros ativos —
     * ninguém permanece ativo em mandato encerrado. A data de fim é a do encerramento;
     * membro com início futuro recebe o próprio início, para não gerar fim anterior ao
     * início. Nada é excluído: o histórico de participação é preservado.
     */
    private List<MandatoMembro> desligarMembrosDoOrgaoDesmarcado(Mandato mandatoBanco) {
        Date dataEncerramento = new Date();
        List<MandatoMembro> desligados = new ArrayList<>();
        for (MandatoMembro membro : GovernancaContext.membros(mandatoBanco)) {
            if (!Boolean.TRUE.equals(membro.getMembroAtivo())) {
                continue;
            }
            Date fim = dataEncerramento;
            if (Objects.nonNull(membro.getInicioMandato())
                    && DataUtil.ignoreTime(fim).before(DataUtil.ignoreTime(membro.getInicioMandato()))) {
                fim = membro.getInicioMandato();
            }
            membro.setFimMandato(fim);
            membro.setMembroAtivo(false);
            mandatoMembroService.salvar(membro);
            desligados.add(membro);
        }
        if (!desligados.isEmpty()) {
            mandatoBanco.setFimMandato(dataEncerramento);
        }
        return desligados;
    }

    /**
     * Encerramento propagado ao GDH pelo MESMO contrato já usado por
     * {@code MandatoService.encerrarUltimoMandato}: MEMBRO_REMOVIDO na routing key
     * {@code governanca.mandato.encerrado}, um evento por membro desligado.
     */
    private void publicarEncerramentoGdh(Integer idCooperativa, Mandato mandato, List<MandatoMembro> desligados) {
        if (desligados.isEmpty()) {
            return;
        }
        GovernancaDiretoriaGdhEvent evento = new GovernancaDiretoriaGdhEvent(GovernancaEventEnum.MEMBRO_REMOVIDO,
                idCooperativa);
        for (MandatoMembro membro : desligados) {
            if (Objects.isNull(membro.getPessoaFisica())) {
                continue;
            }
            String cpf = membro.getPessoaFisica().getCpf();
            evento.getBeneficiario().setSQ_COOPERATIVA(idCooperativa);
            evento.getBeneficiario().setSQ_MANDATO(mandato.getId());
            evento.getBeneficiario().setSQ_MEMBRO_MANDATO(membro.getId());
            evento.getBeneficiario().setCpf(cpf);
            evento.getBeneficiario().setEstaAtivoNoMandato(false);
            evento.getBeneficiario().setEstaNoCargo(
                    mandatoMembroRepository.membroPossuiCargoDiretoriaGdh(cpf, true, membro.getCooperativa()));
            governancaPublisher.publicar(RabbitMQConfig.ROUTING_KEY_GOVERNANCA_MANDATO_ENCERRADO, evento);
        }
    }

    /**
     * Data de fim do contrato do desmarque da DC: obrigatória
     * quando há membros ativos, não pode ser futura e não pode ser anterior ao
     * início do contrato de nenhum membro ativo.
     */
    private void validarDatasAssembleiaOrgao(MandatoTO mandatoFront, Mandato mandatoBanco, Integer idOrgao,
                                             Integer idCooperativa) {
        Date novaAssembleia = mandatoFront.getDataAssembleia();
        if (Objects.isNull(novaAssembleia)) {
            return;
        }
        Integer idAtual = Objects.nonNull(mandatoBanco) ? mandatoBanco.getId() : mandatoFront.getId();
        List<Mandato> encerrados = mandatoService.getMandatosNaoVigentes(idOrgao, idCooperativa).stream()
                .filter(m -> Objects.nonNull(m.getDataAssembleia()))
                .filter(m -> Objects.nonNull(m.getId()) && !Objects.equals(m.getId(), idAtual))
                .collect(Collectors.toList());
        if (encerrados.isEmpty()) {
            return;
        }
        Date nova = DataUtil.ignoreTime(novaAssembleia);
        boolean mesmaDataDeEncerrado = encerrados.stream()
                .anyMatch(m -> DataUtil.ignoreTime(m.getDataAssembleia()).compareTo(nova) == 0);
        if (mesmaDataDeEncerrado) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.ASSEMBLEIA_JA_UTILIZADA) + " "
                    + mandatoFront.getOrgao().getNome());
        }
        Date ultima = encerrados.stream().map(Mandato::getDataAssembleia).max(Date::compareTo).orElse(null);
        if (Objects.nonNull(ultima) && nova.compareTo(DataUtil.ignoreTime(ultima)) < 0) {
            throw new RegraNegocioException(mandatoFront.getOrgao().getNome() + ": "
                    + messages.get(GovernancaConstants.ASSEMBLEIA_ANTERIOR_ULTIMA) + " "
                    + new java.text.SimpleDateFormat("dd/MM/yyyy").format(ultima));
        }
    }

    private void validarDataFimContratoDesmarque(Date dataFimContrato, List<MandatoMembro> membrosAtivos) {
        if (Objects.isNull(dataFimContrato)) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.DATA_FIM_CONTRATO_OBRIGATORIA));
        }
        if (DataUtil.ignoreTime(dataFimContrato).after(DataUtil.ignoreTime(new Date()))) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.FIM_CONTRATO_FUTURO));
        }
        for (MandatoMembro membro : membrosAtivos) {
            if (Objects.nonNull(membro.getInicioMandato())
                    && DataUtil.ignoreTime(dataFimContrato).before(DataUtil.ignoreTime(membro.getInicioMandato()))) {
                throw new RegraNegocioException(messages.get(GovernancaConstants.FIM_CONTRATO_ANTERIOR_INICIO) + " "
                        + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
            }
        }
    }

    /**
     * Identifica o membro na descrição da ação da trilha — nome da pessoa física, com CPF como fallback.
     */
    private String identificaMembro(MandatoMembro membro) {
        if (Objects.isNull(membro) || Objects.isNull(membro.getPessoaFisica())) {
            return null;
        }
        return ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getNome())
                ? membro.getPessoaFisica().getNome()
                : membro.getPessoaFisica().getCpf();
    }

    /**
     * Efeitos de processo do salvamento da aba, herdados do salvar-da-aba legado. Sem eles,
     * a cooperativa em AGUARDANDO_AJUSTE corrige e salva mas a pendência do analista
     * nunca é validada, o badge da aba (IN_ABA_GOVERNANCA) fica desatualizado e o
     * ciclo de manutenção não registra a atualização.
     *
     * <p>Registro (paridade com o fim do {@code salvar()} removido):
     * {@code marcarAjustesComoValidados(GOVERNANCA)}, {@code cooperativaService.save}
     * e {@code salvarStatusAbas} com a validação agregada pós-save. Manutenção
     * (paridade com {@code salvarGovernancaManutencao}):
     * {@code marcarAjustesComoValidados(MANUTENCAO_GOVERNANCA)}, {@code naoSubmeteu}
     * para usuário cooperativa e {@code dataAtualizacao} da cooperativa.</p>
     */
    private void aplicarEfeitosProcessoSalvar(Cooperativa cooperativa, Integer idCooperativa, boolean manutencao,
            Integer idOrgao) {
        if (manutencao) {
            ProgressoMicroEnum microPesquisar = obterProgressoParaValidacaoManutencao(cooperativa);
            if (Objects.nonNull(microPesquisar)) {
                cooperativaPendenciaService.marcarAjustesComoValidados(cooperativa.getId(),
                        CooperativaPendenciaBlocoEnum.MANUTENCAO_GOVERNANCA.name(), microPesquisar, idOrgao);
            }
            if (Objects.equals("C", keycloakService.getTipoUsuario()) && (Objects.isNull(cooperativa.getProgressoManutencaoMicro())
                    || Objects.equals(ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2, cooperativa.getProgressoManutencaoMicro()))) {
                cooperativa.setNaoSubmeteu(Boolean.TRUE);
            }
            cooperativa.setDataAtualizacao(Date.from(Instant.now()));
            cooperativaService.save(cooperativa);
            sincronizarAbaGovernancaManutencao(cooperativa, true);
            return;
        }

        ProgressoMicroEnum microPesquisar = obterProgressoParaValidacao(cooperativa);
        if (Objects.nonNull(microPesquisar)) {
            cooperativaPendenciaService.marcarAjustesComoValidados(cooperativa.getId(),
                    CooperativaPendenciaBlocoEnum.GOVERNANCA.name(), microPesquisar, idOrgao);
        }
        cooperativaService.save(cooperativa);

        List<ServiceMessage> mensagensMotor = mensagensValidacaoGovernanca(cooperativa);
        ValidacaoPrimeiroRegistroTO vpr = validarGovernancaQuandoSalvar(cooperativa, mensagensMotor);
        cooperativaManutencaoAbasService.salvarStatusAbas(cooperativa, mensagensMotor.isEmpty(),
                AbaEnum.ABA_GOVERNANCA, vpr.getValidado());
    }

    /**
     * Restaurado do salvar-da-aba legado (removido) — ver {@link #aplicarEfeitosProcessoSalvar}.
     */
    private ProgressoMicroEnum obterProgressoParaValidacao(Cooperativa c) {
        if (Objects.equals(ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2, c.getProgressoMicro())) {
            return ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1;
        } else if (Objects.equals(ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2, c.getProgressoMicro())) {
            return ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1;
        } else {
            return null;
        }
    }

    /**
     * Restaurado do salvar-da-aba legado (removido) — validação agregada pós-save.
     */
    public ValidacaoPrimeiroRegistroTO validarGovernancaQuandoSalvar(Cooperativa cooperativa) {
        return validarGovernancaQuandoSalvar(cooperativa, mensagensValidacaoGovernanca(cooperativa));
    }

    private ValidacaoPrimeiroRegistroTO validarGovernancaQuandoSalvar(Cooperativa cooperativa,
            List<ServiceMessage> mensagensMotor) {
        ValidacaoPrimeiroRegistroTO vpr = montarValidacaoGovernanca(cooperativa, mensagensMotor, false);
        if (Objects.isNull(vpr.getMensagens()) || (vpr.getMensagens().isEmpty() && vpr.getValidado())) {
            vpr.setValidado(cooperativaPendenciaService.verificarAbaValidadaQuandoSalvar(cooperativa,
                    CooperativaPendenciaBlocoEnum.GOVERNANCA));
        }
        return vpr;
    }

    /**
     * Publica os eventos GDH (MEMBRO_ADICIONADO/MEMBRO_ATUALIZADO) dos membros de um
     * único conselho — mesma mecânica do {@code salvar()} legado.
     */
    private void publicarEventosGdhConselho(Integer idCooperativa, List<MandatoMembro> adicionados, List<MandatoMembro> atualizados) {
        GovernancaDiretoriaGdhEvent evento = new GovernancaDiretoriaGdhEvent(GovernancaEventEnum.MEMBRO_ADICIONADO, idCooperativa);
        adicionados.forEach(membro -> {
            evento.getBeneficiario().setSQ_MANDATO(membro.getMandato().getId());
            evento.getBeneficiario().setSQ_MEMBRO_MANDATO(membro.getId());
            evento.getBeneficiario().setCpf(membro.getPessoaFisica().getCpf());
            evento.getBeneficiario().setEstaAtivoNoMandato(membro.getMembroAtivo());
            evento.getBeneficiario().setEstaNoCargo(mandatoMembroRepository.membroPossuiCargoDiretoriaGdh(membro.getPessoaFisica().getCpf(), true, membro.getCooperativa()));
            governancaPublisher.publicar(RabbitMQConfig.ROUTING_KEY_GOVERNANCA_MEMBRO_ATUALIZADO, evento);
        });
        evento.setEventType(GovernancaEventEnum.MEMBRO_ATUALIZADO);
        atualizados.forEach(membro -> {
            evento.getBeneficiario().setSQ_MEMBRO_MANDATO(membro.getId());
            evento.getBeneficiario().setCpf(membro.getPessoaFisica().getCpf());
            evento.getBeneficiario().setEstaAtivoNoMandato(membro.getMembroAtivo());
            evento.getBeneficiario().setEstaNoCargo(mandatoMembroRepository.membroPossuiCargoDiretoriaGdh(membro.getPessoaFisica().getCpf(), true, membro.getCooperativa()));
            governancaPublisher.publicar(RabbitMQConfig.ROUTING_KEY_GOVERNANCA_MEMBRO_ATUALIZADO, evento);
        });
    }

    /**
     * Inclusão <b>inline</b> de um único membro em um conselho já existente
     * ("Incluir e salvar"). Adiciona apenas o membro informado ao mandato vigente do
     * órgão, preservando os demais membros (isolamento por conselho) — diferente do
     * {@link #salvarPorConselho} que reconcilia a lista inteira do conselho.
     *
     * <p>As validações de membro são as <b>do motor único</b> ({@link GovernancaRuleEngine}
     * via {@link #validarGovernancaParaSalvar}), avaliando o conselho COM o novo membro —
     * sem ramo {@code isManutencao}. A integração GDH e a
     * gravação de {@code dataAtualizacao} seguem a mesma mecânica do salvar-por-conselho.</p>
     *
     * <p>O corpo é a própria entidade {@code MandatoMembro} (pessoa física aninhada com
     * gênero/nascimento e cargo) — mesmo formato que o front já envia em
     * {@code salvarPorConselho.listaMandatoMembro} e que {@link #salvaPessoaFisica} exige.</p>
     */
    @Transactional
    public MandatoTO incluirMembroPorConselho(Integer idCooperativa, Integer idOrgao, @Valid MandatoMembro novoMembro, boolean manutencao) {
        // Permissão de edição por fase (mesma regra do salvar-por-conselho).
        Boolean podeEditar = manutencao
                ? cadastroRegistroService.podePreencherCadastroRegistroManutencao(idCooperativa)
                : cadastroRegistroService.podePreencherCadastroRegistroCooperativaBasico(idCooperativa);
        if (Boolean.FALSE.equals(podeEditar)) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.AGUARDE_ANDAMENTO));
        }

        Cooperativa cooperativa = cooperativaService.findById(idCooperativa);

        // Localiza o conselho (mandato vigente do órgão). A inclusão inline pressupõe o
        // conselho já criado no acordeão — salve o conselho antes de incluir membros avulsos.
        Mandato mandato = mandatoService.getMandatosPorCooperativa(idCooperativa).stream()
                .filter(m -> Objects.nonNull(m.getOrgao()) && Objects.equals(m.getOrgao().getId(), idOrgao))
                .filter(m -> Boolean.TRUE.equals(m.getVigente()))
                .findFirst()
                .orElseThrow(() -> new RegraNegocioException(
                        "Conselho não encontrado para inclusão de membro. Salve o conselho antes de incluir um membro avulso."));

        novoMembro.setId(null);
        novoMembro.setCooperativa(idCooperativa);
        if (Objects.isNull(novoMembro.getRepresentanteLegal())) {
            novoMembro.setRepresentanteLegal(false);
        }

        // CPF sem máscara + validação — paridade com verificaGovernancaFoiPreenchidaRefatorada
        // (sem isto o CPF mascarado furaria a CpfDuplicadoRule e duplicaria PessoaFisica).
        if (Objects.isNull(novoMembro.getPessoaFisica()) || Objects.isNull(novoMembro.getPessoaFisica().getCpf())) {
            throw new RegraNegocioException(GovernancaConstants.O_CAMPO_CPF_E_OBRIGATORIO);
        }
        novoMembro.getPessoaFisica().setCpf(RemoveMascaraUtil.remove(novoMembro.getPessoaFisica().getCpf()));
        if (!ValidacaoCampos.validarCpf(novoMembro.getPessoaFisica().getCpf())) {
            throw new RegraNegocioException(String.format(GovernancaConstants.CPF_INVALIDO_NO_ORGAO_STRING,
                    novoMembro.getPessoaFisica().getCpf(), mandato.getOrgao().getNome()));
        }

        MandatoMembro membroInativoMesmoCpf = membroInativoComCpf(mandato, novoMembro.getPessoaFisica().getCpf());

        // Valida o conselho COM o novo membro pelo motor único, sem ramo isManutencao.
        // Usa uma cópia da lista para não mutar a coleção gerenciada do mandato durante a validação.
        MandatoTO conselhoComNovo = mandato.toDto();
        List<MandatoMembro> membrosParaAvaliar = new ArrayList<>(membrosDe(conselhoComNovo));
        membrosParaAvaliar.add(novoMembro);
        conselhoComNovo.setListaMandatoMembro(membrosParaAvaliar);
        GovernancaTO governancaTO = new GovernancaTO();
        governancaTO.setMandato(conselhoComNovo);
        validarGovernancaParaSalvar(cooperativa, List.of(governancaTO));

        // Guards de membro + persistência da pessoa física (CPF/nome/gênero/cargo/idade).
        novoMembro.setMandato(mandato);
        verificaMembroAprovado(novoMembro);
        novoMembro.setPessoaFisica(salvaPessoaFisica(novoMembro));

        boolean reativacao = Objects.nonNull(membroInativoMesmoCpf);
        MandatoMembro membroPersistido = novoMembro;
        Date fimMandatoAnterior = null;
        if (reativacao) {
            fimMandatoAnterior = membroInativoMesmoCpf.getFimMandato();
            membroInativoMesmoCpf.setCargo(novoMembro.getCargo());
            membroInativoMesmoCpf.setInicioMandato(novoMembro.getInicioMandato());
            membroInativoMesmoCpf.setRepresentanteLegal(novoMembro.getRepresentanteLegal());
            membroInativoMesmoCpf.setPessoaFisica(novoMembro.getPessoaFisica());
            membroInativoMesmoCpf.setMembroAtivo(true);
            membroInativoMesmoCpf.setFimMandato(null);
            membroPersistido = membroInativoMesmoCpf;
            validarLimiteEleitosNaReativacao(mandato, List.of(membroInativoMesmoCpf.getId()),
                    VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo()));
        } else {
            mandato.getListaMandatoMembro().add(novoMembro);
        }
        mandato.setDataAtualizacao(new Date());
        sincronizarMembrosMandato(mandato);
        Mandato salvo = mandatoService.salvar(mandato);

        aplicarEfeitosProcessoSalvar(cooperativa, idCooperativa, manutencao, idOrgao);

        if (reativacao) {
            ultimaAcaoGovernancaService.registrar(TipoAcaoGovernancaEnum.REATIVACAO_MEMBRO, salvo,
                    AcaoGovernancaDescricaoBuilder.reativacaoMembro(membroPersistido, fimMandatoAnterior));
            publicarEventosGdhConselho(idCooperativa, Collections.emptyList(), List.of(membroPersistido));
        } else {
            ultimaAcaoGovernancaService.registrar(TipoAcaoGovernancaEnum.INCLUSAO_MEMBRO, salvo,
                    AcaoGovernancaDescricaoBuilder.inclusaoMembro(novoMembro));
            publicarEventosGdhConselho(idCooperativa, List.of(novoMembro), Collections.emptyList());
        }

        MandatoTO retorno = salvo.toDto();
        ultimaAcaoGovernancaService.preencherUltimaAcao(retorno);
        return retorno;
    }

    private MandatoMembro membroInativoComCpf(Mandato mandato, String cpfSemMascara) {
        if (Objects.isNull(mandato.getListaMandatoMembro())) {
            return null;
        }
        return mandato.getListaMandatoMembro().stream()
                .filter(membro -> !Boolean.TRUE.equals(membro.getMembroAtivo()))
                .filter(membro -> Objects.nonNull(membro.getId()))
                .filter(membro -> Objects.nonNull(membro.getPessoaFisica())
                        && Objects.nonNull(membro.getPessoaFisica().getCpf()))
                .filter(membro -> Objects.equals(
                        RemoveMascaraUtil.remove(membro.getPessoaFisica().getCpf()), cpfSemMascara))
                .findFirst()
                .orElse(null);
    }

    private void atualizaDadosMandato(Mandato mandatoBd, Mandato mandatoFront) {
    	mandatoBd.setAnosDuracao(mandatoFront.getAnosDuracao());
    	mandatoBd.setAprovacao(mandatoFront.getAprovacao());
    	mandatoBd.setDataAssembleia(mandatoFront.getDataAssembleia());
    	mandatoBd.setFimMandato(mandatoFront.getFimMandato());
        // membrosMandato ("Nº de membros eleitos"): o payload vale em todo save.
        // Alteração em mandato APROVADO por Coop/UE é rejeitada ANTES, com erro de
        // negócio explícito (verificaMandatoAprovado) — sem preservação silenciosa.
        // No vínculo CONTRATAÇÃO o valor chega derivado da lista de membros.
        mandatoBd.setMembrosMandato(mandatoFront.getMembrosMandato());
    	mandatoBd.setOrgao(mandatoFront.getOrgao());
    	mandatoBd.setCoopPossui(mandatoFront.getCoopPossui());
    	mandatoBd.setCooperativa(mandatoFront.getCooperativa());
	}

	private void atualizarDataInicioMandato(List<GovernancaTO> listaGovernancaTO) {
        listaGovernancaTO.forEach(governanca -> governanca.getMandato().getListaMandatoMembro().forEach(mandatoMembro -> {
            if (Objects.nonNull(governanca.getMandato().getDataAssembleia())) {
                mandatoMembro.setInicioMandato(governanca.getMandato().getDataAssembleia());
            }
        }));
    }

    @Transactional
    public Boolean salvarGovernancaImportacao(List<GovernancaTO> listaGovernancaTO, Integer idCooperativa) {
        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroManutencao(idCooperativa))) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.AGUARDE_ANDAMENTO));
        }
        List<String> erros = new ArrayList<>();
        for (GovernancaTO governancaTO : listaGovernancaTO) {
            MandatoTO mandato = Objects.isNull(governancaTO) ? null : governancaTO.getMandato();
            String orgaoNome = Objects.nonNull(mandato) && Objects.nonNull(mandato.getOrgao()) && Objects.nonNull(mandato.getOrgao().getNome())
                    ? mandato.getOrgao().getNome()
                    : "Conselho não identificado";
            try {
                if (Objects.isNull(mandato) || Objects.isNull(mandato.getOrgao()) || Objects.isNull(mandato.getOrgao().getId())) {
                    throw new RegraNegocioException("Órgão do conselho ausente no payload de importação.");
                }
                if (VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo())) {
                    mandato.setCoopPossui(validarMembrosAtivos(mandato.getListaMandatoMembro()));
                }
                salvarPorConselho(idCooperativa, mandato.getOrgao().getId(), mandato, true);
            } catch (RegraNegocioException e) {
                erros.add(orgaoNome + ": " + e.getMessage());
            }
        }
        if (!erros.isEmpty()) {
            throw new RegraNegocioException(String.join("\n", erros));
        }
        return Boolean.TRUE;
    }

    private boolean validarMembrosAtivos(List<MandatoMembro> listaMandatoMembro) {
        if (Objects.isNull(listaMandatoMembro) || listaMandatoMembro.isEmpty()) {
            return false;
        }
        return listaMandatoMembro.stream().anyMatch(membro -> Objects.equals(Boolean.TRUE, membro.getMembroAtivo()));
    }

    private void verificaMembroAprovado(MandatoMembro membro) {
        if (Objects.nonNull(membro.getId())) {
            Optional<MandatoMembro> op = mandatoMembroService.findById(membro.getId());
            if (op.isPresent()) {
                MandatoMembro membroCadastrado = op.get();

                if (Objects.isNull(membro.getInicioMandato())) {
                    throw new RegraNegocioException("Data de início do mandato não informada para o CPF:" + " "
                            + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
                }
                if (Objects.isNull(membro.getCargo())) {
                    throw new RegraNegocioException("Cargo não informado para o CPF:" + " "
                            + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
                }


                if (Objects.isNull(membroCadastrado.getInicioMandato())) {
                    membroCadastrado.setInicioMandato(membro.getInicioMandato());
                }

                LocalDate dataCadastrado = DataUtil.convertLocalDateEpochMilli(membroCadastrado.getInicioMandato());
                LocalDate dataInserida = DataUtil.convertLocalDateEpochMilli(membro.getInicioMandato());

                if (Objects.nonNull(membroCadastrado.getAprovacao())
                        && (!Objects.equals(
                        membroCadastrado.getRepresentanteLegal(),
                        membro.getRepresentanteLegal())
                        || (Objects.nonNull(membroCadastrado.getCargo())
                        && !Objects.equals(membroCadastrado.getCargo().getId(), membro.getCargo().getId()))
                        || dataCadastrado.compareTo(dataInserida) != 0
                        || !Objects.equals(
                        membroCadastrado.getPessoaFisica().getCpf(),
                        membro.getPessoaFisica().getCpf()))) {
                    throw new RegraNegocioException(messages.get(GovernancaConstants.MEMBRO_APROVADO) + " "
                            + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
                }
            }
        } else if (Objects.isNull(membro.getCargo()) || Objects.isNull(membro.getCargo().getId())) {
            throw new RegraNegocioException("Cargo não informado para o CPF:" + " "
                    + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
        }
        if (Objects.isNull(membro.getInicioMandato())) {
            throw new RegraNegocioException("Data de início do mandato não informada para o CPF:" + " "
                    + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
        }

    }

    /**
     * Com a estrutura travada — aprovação de ciclo ou parecer aprovado no órgão —
     * o save não pode elevar o número de membros ativos acima do declarado. O teto
     * considera também quantos ativos já existiam: mandato legado com excesso
     * continua salvável, apenas não pode crescer. Repor vaga (desligar um e
     * incluir outro no mesmo save) mantém o total e passa.
     */
    protected void validarQuantidadeDeclarada(Mandato mandato, int ativosAntes, boolean contratacao) {
        if (contratacao || keycloakService.isTipoEntidadeNacional()
                || Objects.isNull(mandato.getMembrosMandato())) {
            return;
        }
        if (Objects.isNull(mandato.getAprovacao()) && !parecerDoOrgaoAprovado(mandato)) {
            return;
        }
        long ativosDepois = GovernancaContext.membrosAtivos(mandato);
        long teto = Math.max(mandato.getMembrosMandato(), ativosAntes);
        if (ativosDepois > teto) {
            throw new RegraNegocioException(
                    messages.get(GovernancaConstants.MANDATO_APROVADO_MEMBROS_EXCEDIDOS) + " "
                            + (Objects.nonNull(mandato.getOrgao()) ? mandato.getOrgao().getNome() : ""));
        }
    }

    private void validarLimiteEleitosNaReativacao(Mandato mandato, List<Integer> membrosReativados,
                                                 boolean contratacao) {
        if (membrosReativados.isEmpty() || contratacao || Objects.isNull(mandato.getMembrosMandato())) {
            return;
        }
        long ativos = GovernancaContext.membrosAtivos(mandato);
        if (ativos > mandato.getMembrosMandato()) {
            throw new RegraNegocioException(messages.get(MandatoMembroService.REATIVAR_LIMITE_EXCEDIDO));
        }
    }

    protected void sincronizarMembrosMandato(Mandato mandato) {
        boolean contratacao = Objects.nonNull(mandato.getOrgao())
                && VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo());
        if (!contratacao && (Objects.nonNull(mandato.getAprovacao()) || parecerDoOrgaoAprovado(mandato))) {
            return;
        }
        long ativos = GovernancaContext.membrosAtivos(mandato);
        if (contratacao) {
            mandato.setMembrosMandato((int) ativos);
            return;
        }
        if (ativos > 0 && (Objects.isNull(mandato.getMembrosMandato()) || mandato.getMembrosMandato() < ativos)) {
            mandato.setMembrosMandato((int) ativos);
        }
    }

    /**
     * Membro que não veio no payload: só é removido fisicamente pela entidade
     * Nacional ou enquanto o mandato está em rascunho — sem aprovação de ciclo e
     * sem parecer aprovado no órgão. Fora disso é preservado, porque o caminho
     * correto é o desligamento, que mantém o histórico de participação. Na
     * Diretoria Contratada e para membro já inativo a preservação é incondicional.
     */
    protected boolean preservadoNaAusenciaDoPayload(Mandato mandatoBanco, MandatoMembro membro) {
        if (keycloakService.isTipoEntidadeNacional()) {
            return false;
        }
        boolean contratacao = Objects.nonNull(mandatoBanco.getOrgao())
                && VinculoEnum.CONTRATACAO.toString().equals(mandatoBanco.getOrgao().getVinculo());
        if (contratacao || !Boolean.TRUE.equals(membro.getMembroAtivo())) {
            return true;
        }
        return Objects.nonNull(mandatoBanco.getAprovacao()) || parecerDoOrgaoAprovado(mandatoBanco);
    }

    protected Map<Integer, String> cpfsPersistidos(Mandato mandatoBanco) {
        Map<Integer, String> cpfs = new HashMap<>();
        if (Objects.isNull(mandatoBanco) || Objects.isNull(mandatoBanco.getListaMandatoMembro())) {
            return cpfs;
        }
        for (MandatoMembro mb : mandatoBanco.getListaMandatoMembro()) {
            if (Objects.nonNull(mb.getId()) && Objects.nonNull(mb.getPessoaFisica())) {
                cpfs.put(mb.getId(), RemoveMascaraUtil.remove(mb.getPessoaFisica().getCpf()));
            }
        }
        return cpfs;
    }

    protected void validarCpfImutavel(Mandato mandatoBanco, Map<Integer, String> cpfsAntes,
            MandatoMembro membroFront) {
        if (Objects.isNull(mandatoBanco) || Objects.isNull(membroFront.getId())) {
            return;
        }
        String cpfAntes = cpfsAntes.get(membroFront.getId());
        if (Objects.isNull(cpfAntes)) {
            return;
        }
        String cpfInformado = Objects.nonNull(membroFront.getPessoaFisica())
                ? RemoveMascaraUtil.remove(membroFront.getPessoaFisica().getCpf())
                : null;
        if (!Objects.equals(cpfAntes, cpfInformado)) {
            throw new RegraNegocioException(messages.get(GovernancaConstants.MEMBRO_CPF_IMUTAVEL) + " "
                    + RemoveMascaraUtil.mascaraCPF(cpfAntes));
        }
    }

    /**
     * RN-EDIT-04: dataAssembleia, anosDuracao e membrosMandato são imutáveis para
     * Cooperativa/UE a partir da aprovação do ciclo. Mandato sem aprovação é
     * rascunho e permanece editável, mesmo que o analista já tenha marcado o
     * agrupamento do órgão como adequado. Alterá-los exige encerrar o mandato
     * vigente e cadastrar um novo por nova assembleia. A entidade Nacional edita
     * os três livremente e a Diretoria Contratada (vínculo CONTRATAÇÃO) permanece
     * exceção às travas de aprovação.
     */
    protected boolean parecerDoOrgaoAprovado(Mandato mandato) {
        if (Objects.isNull(mandato) || Objects.isNull(mandato.getCooperativa())
                || Objects.isNull(mandato.getOrgao())) {
            return false;
        }
        boolean manutencao = Objects.nonNull(mandato.getCooperativa().getSituacaoCooperativa())
                && !SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo()
                        .equals(mandato.getCooperativa().getSituacaoCooperativa().getId());
        return cooperativaPendenciaService.parecerDoOrgaoAprovado(mandato.getCooperativa().getId(), manutencao,
                mandato.getOrgao().getId());
    }

    protected void verificaMandatoAprovado(Mandato mandato) {
        if (Objects.isNull(mandato.getId())) {
            return;
        }
        Optional<Mandato> op = mandatoService.findById(mandato.getId());
        if (op.isEmpty()) {
            return;
        }
        if (keycloakService.isTipoEntidadeNacional()) {
            return;
        }
        if (Objects.nonNull(mandato.getOrgao())
                && VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo())) {
            return;
        }

        Mandato mandatoCadastrado = op.get();
        if (Objects.isNull(mandatoCadastrado.getAprovacao()) && !parecerDoOrgaoAprovado(mandatoCadastrado)) {
            return;
        }
        String orgaoNome = Objects.nonNull(mandato.getOrgao()) ? mandato.getOrgao().getNome() : "";
        if (Objects.nonNull(mandatoCadastrado.getDataAssembleia()) && Objects.nonNull(mandato.getDataAssembleia())
                && stringToCalendar(mandatoCadastrado.getDataAssembleia())
                        .compareTo(stringToCalendar(mandato.getDataAssembleia())) != 0) {
            throw new RegraNegocioException(
                    messages.get(GovernancaConstants.MANDATO_APROVADO_ASSEMBLEIA_IMUTAVEL) + " " + orgaoNome);
        }
        // Valor nulo no banco = save parcial aprovado; completar não é alteração.
        if (Objects.nonNull(mandatoCadastrado.getAnosDuracao())
                && !Objects.equals(mandatoCadastrado.getAnosDuracao(), mandato.getAnosDuracao())) {
            throw new RegraNegocioException(
                    messages.get(GovernancaConstants.MANDATO_APROVADO_DURACAO_IMUTAVEL) + " " + orgaoNome);
        }
        if (Objects.nonNull(mandatoCadastrado.getMembrosMandato())
                && !Objects.equals(mandatoCadastrado.getMembrosMandato(), mandato.getMembrosMandato())) {
            throw new RegraNegocioException(
                    messages.get(GovernancaConstants.MANDATO_APROVADO_MEMBROS_IMUTAVEL) + " " + orgaoNome);
        }
    }

    private ProgressoMicroEnum obterProgressoParaValidacaoManutencao(Cooperativa c) {
        return Objects.equals(ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2, c.getProgressoManutencaoMicro())
                ? ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1
                : ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2;
    }

    protected void verificaGovernancaFoiPreenchidaRefatorada(MandatoTO mandato) {
        if (Objects.nonNull(mandato.getListaMandatoMembro()) && !mandato.getListaMandatoMembro().isEmpty() &&
                Objects.nonNull(mandato.getListaMandatoMembro().get(0).getId())
                && VinculoEnum.ESTATUTARIO_ELETIVO.toString().equals(mandato.getOrgao().getVinculo())) {
            if ((Objects.isNull(mandato.getDataAssembleia()))) {
                throw new RegraNegocioException(
                        messages.get(GovernancaConstants.GOVERNANCA_DATA_ASSEMBLEIA_OBRIGATORIA) + " " + mandato.getOrgao().getNome());
            }
        }

        List<MandatoMembro> listaMembros = new ArrayList<>();

        for (MandatoMembro membro : mandato.getListaMandatoMembro()) {
            // Verifica se algum campo foi preenchido
            if (Objects.nonNull(membro.getPessoaFisica().getCpf())) {
                membro.getPessoaFisica().setCpf(RemoveMascaraUtil.remove(membro.getPessoaFisica().getCpf()));
                if (!ValidacaoCampos.validarCpf(membro.getPessoaFisica().getCpf())) {
                    throw new RegraNegocioException(String.format(GovernancaConstants.CPF_INVALIDO_NO_ORGAO_STRING,
                            membro.getPessoaFisica().getCpf(), mandato.getOrgao().getNome()));
                }
            } else if ((ValidacaoCampos.validaCampoPreenchido(membro.getCargo())
                    && ValidacaoCampos.validaCampoPreenchido(membro.getCargo().getId()))
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getNome())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getInicioMandato())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getFimMandato())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getGenero())) {

                throw new RegraNegocioException(GovernancaConstants.CAMPO_CPF_E_OBRIGATORIO_NO_ORGAO + mandato.getOrgao().getNome());
            }

            if (VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo())
                    && !(ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getCpf()))) {
                throw new RegraNegocioException(
                        mandato.getOrgao().getNome() + GovernancaConstants.FOI_SELECIONADA + GovernancaConstants.O_CAMPO_CPF_E_OBRIGATORIO);

            }

            // No vínculo CONTRATAÇÃO, membro desligado exige "Fim do
            // contrato" — exceto no desmarque (coopPossui=false), em que a data
            // chega no nível do conselho (dataFimContrato) e o backend desativa.
            if (VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo())
                    && !Boolean.FALSE.equals(mandato.getCoopPossui())
                    && Boolean.FALSE.equals(membro.getMembroAtivo())
                    && Objects.isNull(membro.getFimMandato())) {
                throw new RegraNegocioException(messages.get(GovernancaConstants.FIM_CONTRATO_OBRIGATORIO) + " "
                        + RemoveMascaraUtil.mascaraCPF(membro.getPessoaFisica().getCpf()));
            }

            if (VinculoEnum.ESTATUTARIO_ELETIVO.toString().equals(mandato.getOrgao().getVinculo())
                    && ((ValidacaoCampos.validaCampoPreenchido(membro.getCargo())
                    && ValidacaoCampos.validaCampoPreenchido(membro.getCargo().getId()))
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getNome())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getGenero()))) {
                // verificar linha preenchida
                listaMembros.add(membro);
            }

            if (VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo())
                    && ((ValidacaoCampos.validaCampoPreenchido(membro.getCargo())
                    && ValidacaoCampos.validaCampoPreenchido(membro.getCargo().getId()))
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getCpf())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getNome())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getInicioMandato())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getFimMandato())
                    || ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getGenero()))) {
                // verificar linha preenchida
                listaMembros.add(membro);
            }

        }

        // Validando membros
        listaMembros.stream().filter(membro -> Boolean.TRUE.equals(membro.getMembroAtivo())).forEach(membro -> {
            int qtd = 0;
            for (MandatoMembro membro2 : listaMembros) {
                if (Objects.nonNull(membro.getPessoaFisica().getCpf())
                        && Boolean.TRUE.equals(membro2.getMembroAtivo())
                        && membro.getPessoaFisica().getCpf().equals(membro2.getPessoaFisica().getCpf())) {
                    qtd++;
                    // Membro repetido na lista
                    if (qtd > 1) {
                        String error = messages.get(GovernancaConstants.MEMBRO_REPETIDO_SEM_MANDADO) + GovernancaConstants.CPF + membro.getPessoaFisica().getCpf();

                        if (ValidacaoCampos.validaCampoPreenchido(membro.getMandato()) &&
                                ValidacaoCampos.validaCampoPreenchido(membro.getMandato().getOrgao())) {
                            error = messages.get(GovernancaConstants.MEMBRO_REPETIDO) + " " + membro.getMandato().getOrgao().getNome()
                                    + GovernancaConstants.CPF + membro.getPessoaFisica().getCpf();
                        }

                        throw new RegraNegocioException(error);
                    }
                }
            }
        });

        mandato.setListaMandatoMembro(listaMembros);
    }

    @Transactional(readOnly = true)
    public ValidacaoPrimeiroRegistroTO validarGovernanca(Integer idCooperativa, boolean forcarValidacao) {
        return montarValidacaoGovernanca(idCooperativa, forcarValidacao);
    }

    private ValidacaoPrimeiroRegistroTO montarValidacaoGovernanca(Integer idCooperativa, boolean forcarValidacao) {
        Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);
        return montarValidacaoGovernanca(cooperativa, mensagensValidacaoGovernanca(cooperativa), forcarValidacao);
    }

    private ValidacaoPrimeiroRegistroTO montarValidacaoGovernanca(Cooperativa cooperativa,
            List<ServiceMessage> mensagensMotor, boolean forcarValidacao) {

        List<ServiceMessage> mensagens = new ArrayList<>(mensagensMotor);

        obterPendencias(cooperativa.getId(), mensagens, forcarValidacao);

        return getValidacaoPrimeiroRegistro(mensagens, cooperativa);
    }

    private List<ServiceMessage> mensagensValidacaoGovernanca(Cooperativa c) {

        List<ServiceMessage> mensagens = new ArrayList<>();

        List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(c.getId());

        if (mandatos.isEmpty()) {
            mensagens.add(new ServiceMessage(MessageType.ERROR, GovernancaConstants.NENHUM_MANDATO_CADASTRADO));
        }

        if (validaPjRamo(c)) {
            // Ponto único de verdade: o motor de regras substitui verificaMandatos +
            // verificaResponsavelLegal + validaDataAssembleiaConstituicao, sem ramo
            // isManutencao. Paridade provada por
            // GovernancaValidacaoCaracterizacaoIT em coops reais.
            GovernancaContext contexto = governancaContextFactory.criar(c, mandatos);
            mensagens.addAll(governancaViolacaoRenderer.render(governancaRuleEngine.avaliar(contexto)));
        } else {
            mensagens.add(new ServiceMessage(messages.get(GovernancaConstants.DADOS_GERAIS_VALIDACAO_RAMO)));
        }

        return mensagens;
    }

    /**
     * Projeção das pendências de governança por conselho/órgão + flag agregada
     * "pode avançar". Reusa o
     * {@link GovernancaRuleEngine} — ponto único de verdade — pelo MESMO caminho
     * de leitura do GET de busca/validação: monta o {@link GovernancaContext} a
     * partir dos mandatos persistidos e da matriz {@code OrgaoRamo} do ramo da
     * cooperativa, sem reimplementar regra.
     *
     * <p>Os conselhos exibidos são os órgãos aplicáveis do ramo (mesma fonte que
     * {@link #buscaPorCooperativa(Integer)}: {@code orgaoRamoService.listaPorRamo}).
     * As violações do motor são agrupadas por {@code Mandato.orgao} (casando pelo
     * nome do órgão, único na matriz do ramo) e renderizadas em pt-BR pelo
     * {@link GovernancaViolacaoRenderer} (constituição IV).</p>
     *
     * <p>"Pendência" aqui é a projeção das invariantes de governança reportadas na
     * leitura — todas as violações, não apenas as {@code bloqueiaSalvamento()}: o
     * "Avançar" é mais restritivo que o salvar-por-conselho incremental. Um órgão
     * opcional desmarcado ({@code coopPossui = false}) não gera pendência de
     * mínimo — o próprio motor já o ignora. {@code podeAvancar} é
     * {@code true} apenas quando nenhum conselho aplicável possui pendência.</p>
     */
    @Transactional(readOnly = true)
    public PendenciasGovernancaTO obterPendenciasGovernanca(Integer idCooperativa) {
        Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);
        List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(idCooperativa);

        PendenciasGovernancaTO retorno = new PendenciasGovernancaTO();
        retorno.setIdCooperativa(Objects.isNull(idCooperativa) ? null : idCooperativa.longValue());

        // Sem PJ/ramo não há matriz de órgãos aplicáveis: não há conselhos a
        // exibir e a aba não pode avançar (espelha o ramo de validaPjRamo).
        if (!validaPjRamo(cooperativa)) {
            retorno.setPodeAvancar(false);
            return retorno;
        }

        GovernancaContext contexto = governancaContextFactory.criar(cooperativa, mandatos);
        ResultadoValidacaoGovernanca resultado = governancaRuleEngine.avaliar(contexto);

        // Mapeia órgão -> coopPossui a partir do mandato (vigente) persistido.
        Map<Integer, Boolean> coopPossuiPorOrgao = new HashMap<>();
        Map<Integer, Mandato> mandatoPorOrgao = new HashMap<>();
        for (Mandato mandato : mandatos) {
            if (Objects.isNull(mandato.getOrgao()) || Objects.isNull(mandato.getOrgao().getId())) {
                continue;
            }
            boolean possui = Boolean.TRUE.equals(mandato.getCoopPossui());
            // Vigente prevalece; na ausência de vigente, mantém o que houver.
            if (Boolean.TRUE.equals(mandato.getVigente()) || !coopPossuiPorOrgao.containsKey(mandato.getOrgao().getId())) {
                coopPossuiPorOrgao.put(mandato.getOrgao().getId(), possui);
                mandatoPorOrgao.put(mandato.getOrgao().getId(), mandato);
            }
        }

        // Agrupa as mensagens pt-BR das violações por nome de órgão (único na
        // matriz do ramo). Violações sem órgão (ex.: AssembleiaConstituicaoRule)
        // vão para a chave nula e entram em "pendências gerais" — TAMBÉM derrubam
        // podeAvancar: uma violação não associada a conselho não pode liberar a submissão.
        Map<String, List<String>> pendenciasPorOrgao = new HashMap<>();
        for (ViolacaoGovernanca violacao : resultado.getViolacoes()) {
            String chave = violacao.orgaoNome();
            pendenciasPorOrgao.computeIfAbsent(chave, k -> new ArrayList<>())
                    .add(governancaViolacaoRenderer.render(violacao));
        }

        boolean podeAvancar = true;
        EstadoPreenchimentoEnum estadoAba = EstadoPreenchimentoEnum.COMPLETO;
        List<PendenciasConselhoTO> conselhos = new ArrayList<>();
        // Órgãos aplicáveis na ordem de exibição (mesma fonte do GET de busca).
        List<OrgaoRamo> orgaosRamo = new ArrayList<>(contexto.getOrgaosRamo().values());
        Collections.sort(orgaosRamo);
        for (OrgaoRamo orgaoRamo : orgaosRamo) {
            Orgao orgao = orgaoRamo.getOrgao();
            PendenciasConselhoTO conselho = new PendenciasConselhoTO();
            conselho.setIdOrgao(Objects.isNull(orgao.getId()) ? null : orgao.getId().longValue());
            conselho.setNomeOrgao(orgao.getNome());
            conselho.setCoopPossui(Boolean.TRUE.equals(coopPossuiPorOrgao.get(orgao.getId())));

            List<String> pendencias = pendenciasPorOrgao.getOrDefault(orgao.getNome(), new ArrayList<>());
            conselho.setPendencias(pendencias);
            conselho.setBloqueiaAvancar(!pendencias.isEmpty());

            if (conselho.isBloqueiaAvancar()) {
                podeAvancar = false;
            }

            boolean obrigatorio = orgaoRamoResolver.obrigatorio(contexto.getSituacao(), orgaoRamo);
            if (obrigatorio || conselho.isCoopPossui()) {
                EstadoPreenchimentoEnum estadoConselho;
                if (!pendencias.isEmpty()) {
                    estadoConselho = EstadoPreenchimentoEnum.OBRIGATORIO_PENDENTE;
                } else if (facultativosPreenchidos(mandatoPorOrgao.get(orgao.getId()))) {
                    estadoConselho = EstadoPreenchimentoEnum.COMPLETO;
                } else {
                    estadoConselho = EstadoPreenchimentoEnum.SO_OBRIGATORIOS;
                }
                conselho.setEstadoPreenchimento(estadoConselho);
                estadoAba = piorEstado(estadoAba, estadoConselho);
            }
            conselhos.add(conselho);
        }

        // Violações órfãs (sem órgão OU de órgão fora da matriz exibida) não podem
        // "furar" o gate agregado do Avançar.
        Set<String> orgaosExibidos = conselhos.stream()
                .map(PendenciasConselhoTO::getNomeOrgao)
                .collect(Collectors.toSet());
        List<String> pendenciasGerais = new ArrayList<>();
        for (Map.Entry<String, List<String>> entry : pendenciasPorOrgao.entrySet()) {
            if (Objects.isNull(entry.getKey()) || !orgaosExibidos.contains(entry.getKey())) {
                pendenciasGerais.addAll(entry.getValue());
            }
        }
        if (!pendenciasGerais.isEmpty()) {
            podeAvancar = false;
            estadoAba = EstadoPreenchimentoEnum.OBRIGATORIO_PENDENTE;
        }

        retorno.setPendenciasGerais(pendenciasGerais);
        retorno.setConselhos(conselhos);
        retorno.setPodeAvancar(podeAvancar);
        retorno.setEstadoPreenchimento(estadoAba);
        return retorno;
    }

    private boolean facultativosPreenchidos(Mandato mandato) {
        if (Objects.isNull(mandato) || Objects.isNull(mandato.getListaMandatoMembro())) {
            return true;
        }
        return mandato.getListaMandatoMembro().stream()
                .filter(membro -> Boolean.TRUE.equals(membro.getMembroAtivo()))
                .allMatch(membro -> Objects.nonNull(membro.getPessoaFisica())
                        && Objects.nonNull(membro.getPessoaFisica().getDataNascimento())
                        && Objects.nonNull(membro.getPessoaFisica().getIdEscolaridade()));
    }

    private EstadoPreenchimentoEnum piorEstado(EstadoPreenchimentoEnum atual, EstadoPreenchimentoEnum candidato) {
        if (atual == EstadoPreenchimentoEnum.OBRIGATORIO_PENDENTE
                || candidato == EstadoPreenchimentoEnum.OBRIGATORIO_PENDENTE) {
            return EstadoPreenchimentoEnum.OBRIGATORIO_PENDENTE;
        }
        if (atual == EstadoPreenchimentoEnum.SO_OBRIGATORIOS
                || candidato == EstadoPreenchimentoEnum.SO_OBRIGATORIOS) {
            return EstadoPreenchimentoEnum.SO_OBRIGATORIOS;
        }
        return EstadoPreenchimentoEnum.COMPLETO;
    }

    private ValidacaoPrimeiroRegistroTO getValidacaoPrimeiroRegistro(List<ServiceMessage> mensagens, Cooperativa c) {
        ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Governança");
        vpr.setMensagens(mensagens);

        // Se não tiver críticas, então está validado
        if (mensagens.isEmpty()) {
            vpr.setValidado(
                    cooperativaPendenciaService.verificarAbaValidada(c, CooperativaPendenciaBlocoEnum.GOVERNANCA));
        } else {
            vpr.setValidado(false);
        }
        return vpr;
    }

    @Transactional(readOnly = true)
    public ValidacaoPrimeiroRegistroTO obterValidacaoGovernancaManutencao(Integer idCooperativa, boolean forcarValidacao) {
        return montarValidacaoGovernancaManutencao(idCooperativa, forcarValidacao);
    }

    private ValidacaoPrimeiroRegistroTO montarValidacaoGovernancaManutencao(Integer idCooperativa, boolean forcarValidacao) {
        Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);
        return montarValidacaoGovernancaManutencao(cooperativa,
                mensagensValidacaoGovernancaManutencao(cooperativa), forcarValidacao);
    }

    private ValidacaoPrimeiroRegistroTO montarValidacaoGovernancaManutencao(Cooperativa cooperativa,
            List<ServiceMessage> mensagensMotor, boolean forcarValidacao) {

        List<ServiceMessage> mensagens = new ArrayList<>(mensagensMotor);

        obterPendenciasManutencao(cooperativa.getId(), mensagens, forcarValidacao);

        return getValidacaoManutencao(mensagens, cooperativa);
    }

    private List<ServiceMessage> mensagensValidacaoGovernancaManutencao(Cooperativa c) {

        List<ServiceMessage> mensagens = new ArrayList<>();

        List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(c.getId());

        if (mandatos.isEmpty()) {
            mensagens.add(new ServiceMessage(MessageType.ERROR, "Nenhum mandato cadastrado."));
        }

        if (validaPjRamo(c)) {
            // Mesmo motor do fluxo de Registro — elimina a divergência isManutencao.
            // A unificação dispensa o filtro por órgão (as regras já filtram
            // por mandato.orgao). Difere do Registro apenas no obterPendenciasManutencao.
            GovernancaContext contexto = governancaContextFactory.criar(c, mandatos);
            mensagens.addAll(governancaViolacaoRenderer.render(governancaRuleEngine.avaliar(contexto)));
        } else {
            mensagens.add(new ServiceMessage(messages.get(GovernancaConstants.DADOS_GERAIS_VALIDACAO_RAMO)));
        }

        return mensagens;
    }

    @Transactional
    public ValidacaoPrimeiroRegistroTO validarGovernancaManutencao(Integer idCooperativa, boolean forcarValidacao) {
        return sincronizarAbaGovernancaManutencao(cooperativaService.getCooperativa(idCooperativa), forcarValidacao);
    }

    private ValidacaoPrimeiroRegistroTO sincronizarAbaGovernancaManutencao(Cooperativa cooperativa,
            boolean forcarValidacao) {
        List<ServiceMessage> mensagensMotor = mensagensValidacaoGovernancaManutencao(cooperativa);

        ValidacaoPrimeiroRegistroTO validacao =
                montarValidacaoGovernancaManutencao(cooperativa, mensagensMotor, forcarValidacao);

        cooperativaManutencaoAbasService.salvarStatusAbasManutencao(cooperativa.getId(), mensagensMotor.isEmpty(),
                AbaEnum.ABA_GOVERNANCA);

        return validacao;
    }

    private ValidacaoPrimeiroRegistroTO getValidacaoManutencao(List<ServiceMessage> mensagens, Cooperativa c) {
        ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Governança");
        vpr.setMensagens(mensagens);

        // Se não tiver críticas, então está validado
        if (mensagens.isEmpty()) {
            vpr.setValidado(cooperativaPendenciaService.verificarAbaValidadaManutencao(c,
                    CooperativaPendenciaBlocoEnum.MANUTENCAO_GOVERNANCA));
        } else {
            vpr.setValidado(false);
        }
        return vpr;
    }

    private void obterPendencias(Integer idCooperativa, List<ServiceMessage> mensagens,
                                 boolean forcarValidacao) {
        ValidacaoPendenciaTO pendenciasAbas = cooperativaPendenciaService.obterPendenciasAbas(idCooperativa);
        if (Objects.nonNull(pendenciasAbas) && Objects.nonNull(pendenciasAbas.getGovernanca())
                && Boolean.FALSE.equals(pendenciasAbas.getGovernanca().getAbaPreenchida())) {
            if (!forcarValidacao) {
                mensagens.clear();
            }
        }

    }

    private void obterPendenciasManutencao(Integer idCooperativa, List<ServiceMessage> mensagens,
                                           boolean forcarValidacao) {
        ValidacaoPendenciaTO pendenciasAbas = cooperativaPendenciaService.obterPendenciasAbasManutencao(idCooperativa);
        if (Objects.nonNull(pendenciasAbas) && Objects.nonNull(pendenciasAbas.getGovernanca())
                && Objects.nonNull(pendenciasAbas.getGovernanca().getAbaPreenchida()) && !forcarValidacao) {
            mensagens.clear();

		}

    }

    private boolean validaPjRamo(Cooperativa c) {
        return Objects.nonNull(c.getPessoaJuridica()) && Objects.nonNull(c.getPessoaJuridica().getRamo());
    }

    private Integer getTotalCooperados(Integer idCooperativa) {
        QuadroSocial quadroSocial = quadroSocialService.getQuadroSocialAtual(idCooperativa);
        if (Objects.nonNull(quadroSocial) && Objects.nonNull(quadroSocial.getCooperadosTotal())) {
            return quadroSocial.getCooperadosTotal();
        }
        return 0;
    }

    private void validaPessoaFisica(MandatoMembro membro) {
        if (Objects.isNull(membro.getPessoaFisica().getCpf()) || Objects.equals(membro.getPessoaFisica().getCpf(), "")) {
            throw new RegraNegocioException(GovernancaConstants.O_CAMPO_CPF_E_OBRIGATORIO);
        }
        if (Objects.isNull(membro.getPessoaFisica().getNome()) || Objects.equals(membro.getPessoaFisica().getNome(), "")) {
            throw new RegraNegocioException(
                    "Nome do CPF " + membro.getPessoaFisica().getCpf() + " é obrigatório");
        }
        if (Objects.isNull(membro.getPessoaFisica().getGenero())) {
            throw new RegraNegocioException(
                    "Gênero do CPF " + membro.getPessoaFisica().getCpf() + " é obrigatório");
        }
        if (Objects.isNull(membro.getCargo())) {
            throw new RegraNegocioException(
                    "Cargo do CPF " + membro.getPessoaFisica().getCpf() + " é obrigatório");
        }
    }

    private PessoaFisica salvaPessoaFisica(MandatoMembro membro) {

        if (Objects.nonNull(membro.getPessoaFisica().getCpf()) && !membro.getPessoaFisica().getCpf().isEmpty()) {
            PessoaFisica pessoaCPF = pessoaClient.buscaPorCpf(membro.getPessoaFisica().getCpf());
            validaPessoaFisica(membro);
            if (Objects.nonNull(pessoaCPF) && Objects.nonNull(pessoaCPF.getId())) {
                pessoaCPF.setNome(membro.getPessoaFisica().getNome());
                pessoaCPF.setGenero(membro.getPessoaFisica().getGenero());
                if (Objects.nonNull(membro.getPessoaFisica().getIdEscolaridade())) {
                    pessoaCPF.setIdEscolaridade(membro.getPessoaFisica().getIdEscolaridade());
                }
                validarDataDeNascimento(membro);
                pessoaCPF.setDataNascimento(membro.getPessoaFisica().getDataNascimento());
                membro.setPessoaFisica(pessoaCPF);
                validarDataDeNascimento(membro);
            }
        }

        validarDataDeNascimento(membro);

        if (Objects.nonNull(membro.getPessoaFisica().getId()) && membro.getPessoaFisica().getId() != 0) {
            return pessoaClient.updatePessoaFisica(membro.getPessoaFisica());
        } else {
            return pessoaClient.createPessoaFisica(membro.getPessoaFisica());
        }
    }

    private void validarDataDeNascimento(MandatoMembro membro) {
        if (Objects.nonNull(membro.getPessoaFisica().getDataNascimento())) {
            int age = Years.yearsBetween(new org.joda.time.LocalDate(membro.getPessoaFisica().getDataNascimento()),
                    new org.joda.time.LocalDate()).getYears();
            if (age < 16) {
                throw new RegraNegocioException(messages.get(GovernancaConstants.PESSOA_FISICA_IDADE_INVALIDA)
                        + "menor que 16 anos, verifique o membro: "
                        + membro.getPessoaFisica().getCpf()
                        + " - "
                        + membro.getPessoaFisica().getNome());
            }
            if (age > 100) {
                throw new RegraNegocioException(messages.get(GovernancaConstants.PESSOA_FISICA_IDADE_INVALIDA)
                        + "maior que 100 anos, verifique o membro: "
                        + membro.getPessoaFisica().getCpf()
                        + " - "
                        + membro.getPessoaFisica().getNome());
            }
            membro.getPessoaFisica().setDataNascimento(membro.getPessoaFisica().getDataNascimento());
        } else if (Objects.isNull(membro.getPessoaFisica().getDataNascimento())) {
            membro.getPessoaFisica().setDataNascimento(null);
        }

    }

    @Transactional(readOnly = true)
    public List<GovernancaTO> buscaPorCooperativa(Integer idCooperativa) {

        List<GovernancaTO> listaGovernancaTO = new ArrayList<>();
        MinMembroMaxAnosTO minMembrosMaxAnos;

        Cooperativa coop = cooperativaService.findById(idCooperativa);
        List<Mandato> listaMandatos = mandatoService.getMandatosPorCooperativa(idCooperativa);
        List<OrgaoRamo> listaOrgaoRamo = orgaoRamoService.listaPorRamo(coop.getPessoaJuridica().getRamo().getId());
        Collections.sort(listaOrgaoRamo);

        HashMap<Integer, List<OrgaoCargo>> todosCargosObrigatorios = getMapOrgaoCargo();

        for (OrgaoRamo orgaoRamo : listaOrgaoRamo) {
            boolean existe = false;
            Orgao orgao = orgaoRamo.getOrgao();
            GovernancaTO governancaTO = new GovernancaTO();

            minMembrosMaxAnos = verificarLei12690(coop, orgaoRamo);
            for (Mandato mandato : listaMandatos) {

                if (mandato.getOrgao().getId().equals(orgao.getId())) {
                    governancaTO.setMandato(mandato.toDto());
                    existe = true;
                }
            }
            if (!existe) {
                governancaTO = criaGovernanca(orgao, minMembrosMaxAnos.getMinimoMembros(), minMembrosMaxAnos.getMaxAnos(), todosCargosObrigatorios);
            }
            listaGovernancaTO.add(governancaTO);
        }

        // Última ação por conselho — preenchida SOMENTE para a unidade Nacional.
        ultimaAcaoGovernancaService.preencherUltimaAcao(listaGovernancaTO);
        preencherParecerAprovado(listaGovernancaTO, idCooperativa, CooperativaPendenciaBlocoEnum.GOVERNANCA.name());

        return listaGovernancaTO;
    }

    /**
     * Marca em cada conselho se o parecer do agrupamento daquele órgão está
     * aprovado, para o front bloquear a edição sem precisar de consulta própria
     * nem depender do mapa de pendências-chave.
     */
    private void preencherParecerAprovado(List<GovernancaTO> conselhos, Integer idCooperativa, String bloco) {
        for (GovernancaTO governancaTO : conselhos) {
            MandatoTO mandato = Objects.isNull(governancaTO) ? null : governancaTO.getMandato();
            if (Objects.isNull(mandato) || Objects.isNull(mandato.getOrgao())
                    || Objects.isNull(mandato.getOrgao().getId())) {
                continue;
            }
            mandato.setParecerAprovado(cooperativaPendenciaService.parecerDoOrgaoAprovado(
                    idCooperativa, bloco, mandato.getOrgao().getId()));
        }
    }

    private GovernancaTO criaGovernanca(Orgao orgao, Integer minimoMembros, Integer maxAnos, HashMap<Integer, List<OrgaoCargo>> todosCargosObrigatorios) {
        Mandato mandato = new Mandato(orgao, minimoMembros, maxAnos);
        List<MandatoMembro> listaMembros = criaListaMembros(todosCargosObrigatorios, minimoMembros, mandato, 0);
        mandato.setListaMandatoMembro(listaMembros);
        GovernancaTO governancaTO = new GovernancaTO();
        governancaTO.setMandato(mandato.toDto());

        return governancaTO;
    }

    private MinMembroMaxAnosTO verificarLei12690(Cooperativa c, OrgaoRamo orgaoRamo) {
        MinMembroMaxAnosTO retorno = new MinMembroMaxAnosTO();
        if (Objects.nonNull(c.getRegidaPorLei())) {
            if (getTotalCooperados(c.getId()) <= GovernancaConstants.QTD_COOPERADOS_LEI12690) {
                retorno.setMinimoMembros(orgaoRamo.getMinimoMembrosLei12690());
                retorno.setMaxAnos(orgaoRamo.getMaximoAnosLei12690());
            } else {
                retorno.setMinimoMembros(orgaoRamo.getMinimoMembrosLei12690Maior19());
                retorno.setMaxAnos(orgaoRamo.getMaximoAnosLei12690Maior19());
            }
        } else {
            retorno.setMinimoMembros(orgaoRamo.getMinimoMembro());
            retorno.setMaxAnos(orgaoRamo.getMaximoAnos());
        }
        return retorno;
    }

    private List<MandatoMembro> adicionaMembros(HashMap<Integer, List<OrgaoCargo>> todosCargosObrigatorios,
                                                List<MandatoMembro> listaMembros, Integer qtdMembro, Integer minimoMembro, Mandato mandato) {
        int nMembros = qtdMembro > minimoMembro ? qtdMembro : minimoMembro;

        List<OrgaoCargo> cargosObrigatorios = todosCargosObrigatorios.get(mandato.getOrgao().getId());
        HashMap<Integer, Cargo> cargosObrigatoriosNaoUtilizados = new HashMap<>();
        if (Objects.nonNull(cargosObrigatorios)) {
            cargosObrigatorios.forEach(co -> cargosObrigatoriosNaoUtilizados.put(co.getCargo().getId(), co.getCargo()));
            for (MandatoMembro mm : listaMembros) {
                if (Objects.nonNull(mm) && Objects.nonNull(mm.getCargo())) {
                    cargosObrigatoriosNaoUtilizados.remove(mm.getCargo().getId());
                }
            }
        }

        List<Cargo> cargosNaoEncontrados = new ArrayList<>(cargosObrigatoriosNaoUtilizados.values());
        Cargo aux;
        for (int i = listaMembros.size(), y = 0; i < nMembros; i++, y++) {
            aux = null;

            if (cargosNaoEncontrados.size() > y && Objects.nonNull(cargosNaoEncontrados.get(y))) {
                aux = cargosNaoEncontrados.get(y);
            }

            MandatoMembro membro = new MandatoMembro();
            membro.setPessoaFisica(new PessoaFisica());
            membro.setCargo(aux);
            membro.setMandato(mandato);
            membro.setRepresentanteLegal(false);
            membro.setMembroAtivo(true);

            listaMembros.add(membro);
        }

        return listaMembros;
    }

    private List<MandatoMembro> criaListaMembros(HashMap<Integer, List<OrgaoCargo>> todosCargosObrigatorios,
                                                 Integer minimoMembro, Mandato mandato, Integer qtdMembro) {
        return adicionaMembros(todosCargosObrigatorios, new ArrayList<>(), qtdMembro, minimoMembro, mandato);
    }

    @Transactional(readOnly = true)
    public List<GovernancaTO> buscaPorCooperativaManutencao(Integer idCooperativa) {
        List<GovernancaTO> listaGovernancaManutencaoTO = new ArrayList<>();

        Cooperativa c = cooperativaService.findById(idCooperativa);
        List<Mandato> listaMandatosManutencao = mandatoService.getMandatosPorCooperativa(idCooperativa);
        List<OrgaoRamo> listaOrgaoRamoManutencao = orgaoRamoService
                .listaPorRamo(c.getPessoaJuridica().getRamo().getId());
        Collections.sort(listaOrgaoRamoManutencao);

        HashMap<Integer, List<OrgaoCargo>> todosCargosObrigatorios = getMapOrgaoCargo();

        for (OrgaoRamo orgaoRamo : listaOrgaoRamoManutencao) {
            boolean existe = false;
            Orgao orgao = orgaoRamo.getOrgao();
            GovernancaTO governancaTO = new GovernancaTO();
            Integer minimoMembros = 1;
            Integer maximoAnos;
            boolean obrigatorio = false;

            // Verifica Liquidação
            if (Boolean.TRUE.equals(c.getLiquidacao())) {
                minimoMembros = orgaoRamo.getMinimoMembrosLiquidacao();
                maximoAnos = orgaoRamo.getMaximoAnos();
                obrigatorio = orgaoRamo.getObrigatorioLiquidacao();
            } else if (Boolean.TRUE.equals(c.getRegidaPorLei())) { // Verifica Lei 12690
                if (getTotalCooperados(c.getId()) <= GovernancaConstants.QTD_COOPERADOS_LEI12690) {
                    minimoMembros = orgaoRamo.getMinimoMembrosLei12690();
                    maximoAnos = orgaoRamo.getMaximoAnosLei12690();
                    obrigatorio = orgaoRamo.getObrigatorioLei12690();
                } else {
                    minimoMembros = orgaoRamo.getMinimoMembrosLei12690Maior19();
                    maximoAnos = orgaoRamo.getMaximoAnosLei12690Maior19();
                    obrigatorio = orgaoRamo.getObrigatorioLei12690Maior19();

                }
            } else {
                minimoMembros = orgaoRamo.getMinimoMembro();
                maximoAnos = orgaoRamo.getMaximoAnos();
                obrigatorio = orgaoRamo.getObrigatorio();

            }

            // Mandato existente devolve SOMENTE os membros persistidos: completar a
            // lista com linhas em branco a partir de membrosMandato criava membros
            // fantasma "Revisar" na tela e contava no mínimo do conselho. A tela
            // cria linha sob demanda ("Adicionar membro").
            for (Mandato mandato : listaMandatosManutencao) {
                if (mandato.getOrgao().getId().equals(orgao.getId())) {
                    mandato.getOrgao().setObrigatorio(obrigatorio);
                    governancaTO.setMandato(mandato.toDto());
                    existe = true;
                }
            }

            if (!existe) {
                governancaTO.setMandato(new MandatoTO());
                governancaTO.getMandato().setOrgao(orgao);
                governancaTO.getMandato().getOrgao().setObrigatorio(obrigatorio);
                governancaTO.getMandato().setVigente(false);
                governancaTO.getMandato().setMembrosMandato(minimoMembros);
                governancaTO.getMandato().setAnosDuracao(duracaoDoOrgao(orgao, maximoAnos));
                governancaTO.getMandato().setListaMandatoMembro(
                        criaListaMembros(todosCargosObrigatorios, minimoMembros, governancaTO.getMandato().toEntity(), 0));
            }
            listaGovernancaManutencaoTO.add(governancaTO);
        }

        // Última ação por conselho — preenchida SOMENTE para a unidade Nacional.
        ultimaAcaoGovernancaService.preencherUltimaAcao(listaGovernancaManutencaoTO);
        preencherParecerAprovado(listaGovernancaManutencaoTO, idCooperativa,
                CooperativaPendenciaBlocoEnum.MANUTENCAO_GOVERNANCA.name());

        return listaGovernancaManutencaoTO;
    }

    private HashMap<Integer, List<OrgaoCargo>> getMapOrgaoCargo() {
        List<OrgaoCargo> cargosObrigatorios = orgaoCargoRepository.buscaPorOrgaoObrigatorio();
        HashMap<Integer, List<OrgaoCargo>> todosCargosObrigatorios = new HashMap<>();
        cargosObrigatorios.forEach(co -> {
            if (!todosCargosObrigatorios.containsKey(co.getOrgao().getId())) {
                todosCargosObrigatorios.put(co.getOrgao().getId(), new ArrayList<>());
            }
            todosCargosObrigatorios.get(co.getOrgao().getId()).add(co);
        });

        return todosCargosObrigatorios;
    }

    public List<GovernancaTO> buscaNaoVigentesPorCooperativaOrgao(Integer idCooperativa, Integer idOrgao) {
        List<GovernancaTO> listaGovernancaTO = new ArrayList<>();
        cooperativaService.findById(idCooperativa);
        List<Mandato> listaMandatos = mandatoService.getMandatosNaoVigentesPorCooperativaOrgao(idCooperativa, idOrgao);
        for (Mandato mandato : listaMandatos) {
            GovernancaTO governancaTO = new GovernancaTO();
            governancaTO.setMandato(mandato.toDto());
            listaGovernancaTO.add(governancaTO);
        }

        // Última ação também no histórico (um mandato encerrado carrega o
        // encerramento e o usuário executor) — somente unidade Nacional.
        ultimaAcaoGovernancaService.preencherUltimaAcao(listaGovernancaTO);

        return listaGovernancaTO;
    }

    public void atualizarRamoRegistro(Integer id) {
        List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(id);
        Cooperativa c = cooperativaService.findById(id);
        List<OrgaoRamo> listaOrgaoRamo = orgaoRamoService.listaPorRamo(c.getPessoaJuridica().getRamo().getId());

        for (Mandato mandato : mandatos) {
            boolean existe = false;
            for (OrgaoRamo orgaoRamo : listaOrgaoRamo) {
                if (mandato.getOrgao().getId().equals(orgaoRamo.getOrgao().getId())) {
                    existe = true;
                    break;
                }
            }
            if (!existe) {
                for (MandatoMembro membro : mandatoMembroService.getMandatosMembroPorMandato(mandato.getId())) {
                    mandatoMembroService.excluiMandatoMembro(membro.getId());
                }
                mandatoService.excluiMandato(mandato.getId());
            }
        }

    }

    public void tornarMandatoVigente(Integer idCooperativa, Integer idMandato) {

        mandatoService.tornarMandatoVigente(idMandato, idCooperativa);
    }

    @Deprecated
    public static String stringToCalendar(Date dataAssembleia) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dataAssembleia);
        LocalDateTime dateTime = calendar.toInstant().atZone(ZoneId.of("UTC")).toLocalDateTime();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        return dateTime.toLocalDate().format(formatter);
    }

    @Transactional(readOnly = true)
    public GovernancaTO buscaPorCooperativaManutencaoRamo(Integer idCooperativa, Integer idOrgao) {

        Cooperativa c = cooperativaService.findById(idCooperativa);
        OrgaoRamo orgaoRamo = orgaoRamoService
                .listaPorRamoCooperativaOrgao(idCooperativa, c.getPessoaJuridica().getRamo().getId(), idOrgao);

        GovernancaTO governancaTO = new GovernancaTO();
        governancaTO.setMandato(new MandatoTO());
        governancaTO.getMandato().setOrgao(new Orgao());
        Integer minimoMembros = 1;
        Integer maximoAnos;
        boolean obrigatorio = false;

        // Verifica Liquidação
        if (Boolean.TRUE.equals(c.getLiquidacao())) {
            minimoMembros = orgaoRamo.getMinimoMembrosLiquidacao();
            maximoAnos = orgaoRamo.getMaximoAnos();
            obrigatorio = orgaoRamo.getObrigatorioLiquidacao();
        } else if (Boolean.TRUE.equals(c.getRegidaPorLei())) { // Verifica Lei 12690
            if (getTotalCooperados(c.getId()) <= GovernancaConstants.QTD_COOPERADOS_LEI12690) {
                minimoMembros = orgaoRamo.getMinimoMembrosLei12690();
                maximoAnos = orgaoRamo.getMaximoAnosLei12690();
                obrigatorio = orgaoRamo.getObrigatorioLei12690();
            } else {
                minimoMembros = orgaoRamo.getMinimoMembrosLei12690Maior19();
                maximoAnos = orgaoRamo.getMaximoAnosLei12690Maior19();
                obrigatorio = orgaoRamo.getObrigatorioLei12690Maior19();
            }
        } else {
            minimoMembros = orgaoRamo.getMinimoMembro();
            maximoAnos = orgaoRamo.getMaximoAnos();
            obrigatorio = orgaoRamo.getObrigatorio();

        }

        governancaTO.getMandato().getOrgao().setObrigatorio(obrigatorio);
        governancaTO.getMandato().setMembrosMandato(minimoMembros);
        governancaTO.getMandato().setAnosDuracao(duracaoDoOrgao(governancaTO.getMandato().getOrgao(), maximoAnos));

        return governancaTO;
    }

    private Integer duracaoDoOrgao(Orgao orgao, Integer maximoAnos) {
        boolean contratacao = Objects.nonNull(orgao)
                && VinculoEnum.CONTRATACAO.toString().equals(orgao.getVinculo());
        return contratacao ? null : maximoAnos;
    }

    public List<IntegracaoGdhRetornoTO> buscaDadosBeneficiariosIntegracaoGdh(IntegracaoGdhTO integracaoGdhTO) {
        List<IntegracaoGdhRetornoTO> beneficiarios = mandatoMembroRepository.obterDadosBeneficiarioGdh(integracaoGdhTO.getCpfs(),
                integracaoGdhTO.isSomenteMandatoVigente());

        beneficiarios.forEach(this::processaBeneficiario);
        return beneficiarios;
    }

    private void processaBeneficiario(IntegracaoGdhRetornoTO beneficiario) {
        List<EscolaridadeTO> escolaridades = escolaridadeService.getEscolaridades();

        Map<Integer, EscolaridadeTO> escolaridadePorId = escolaridades.stream()
                .collect(Collectors.toMap(
                        EscolaridadeTO::getId,
                        Function.identity()
                ));

        if (Objects.nonNull(beneficiario.getDataNascimento())) {
            beneficiario.setDataNascimento(
                    beneficiario.getDataNascimento().substring(0, 10)
            );
        }
        if (Objects.nonNull(beneficiario.getEscolaridade())) {
            EscolaridadeTO escolaridade = escolaridadePorId.get(
                    Integer.parseInt(beneficiario.getEscolaridade())
            );
            if (Objects.nonNull(escolaridade)) {
                beneficiario.setEscolaridade(escolaridade.getDescricaoEscolaridade());
            } else {
                beneficiario.setEscolaridade(null);
            }
        }
    }
}
