package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import lombok.Data;

import java.util.List;

@Data
public class AbaCampos {
    private String id;
    private String name;
    private String type;
    private boolean isAccordion;
    private String placeHolder;
    private String subTitle;
    private String label;
    private Object value;
    private boolean isRequired;
    private String inputType;
    private boolean hasMask;
    private String mask;
    private Integer quantidadeDeCasas;
    private boolean hasIcon;
    private String icon;
    private boolean hasInfo;
    private String infoText;
    private boolean readonly;
    private boolean disable;
    private boolean visible;
    private boolean isAceitaNegativo;
    private String siglaUnidade;
    private Integer idParametro;
    private Integer idParametroAuxiliar;
    private String parametroIntegracao;
}
