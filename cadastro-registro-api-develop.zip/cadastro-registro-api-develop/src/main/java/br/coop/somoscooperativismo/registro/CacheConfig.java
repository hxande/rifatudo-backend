package br.coop.somoscooperativismo.registro;

import static javax.management.timer.Timer.ONE_HOUR;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableCaching
@Slf4j
public class CacheConfig {

    public static final String CACHE_TIPO_ENDERECO = "tipoEnderecoCache";
    public static final String CACHE_LOCALIZACAO = "localizacaoCache";
    public static final String CACHE_MUNICIPIO = "municipioCache";
    public static final String CACHE_RAMO = "ramoCache";
    public static final String CACHE_TIPO_ORGAO_GOVERNANCA = "tipoOrgaoGovernancaCache";
    public static final String CACHE_CARGOS_GOVERNANCA = "cargosGovernancaCache";
    public static final String CACHE_CADASTRO_UNIDADE_ESTADUAL = "cadastroUnidadeEstadualCache";
    public static final String CACHE_PARAMETRO_QUADRO_SOCIAL = "parametroQuadroSocialCache";
    public static final String CACHE_SEGMENTOS = "segmentosCache";
    public static final String CACHE_SITUACAO_COOPERATIVA = "situacaoCooperativaCache";
    public static final String CACHE_CADASTRO_REGISTRO = "cadastroRegistroCache";
    public static final String CACHE_CADASTRO_REGISTRO_LEITURA = "cadastroRegistroLeituraCache";
    public static final String CACHE_MESSAGES = "messagesCache";
    public static final String CACHE_USUARIO_NOME = "usuarioNomeCache";


    private static final long CACHE_TIMER_QUATRO_HORAS = ONE_HOUR * 4;
    private static final long CACHE_TIMER_OITO_HORAS = ONE_HOUR * 8;
    private static final long CACHE_TIMER_UMA_HORAS = ONE_HOUR;

    @Scheduled(fixedRate = CACHE_TIMER_QUATRO_HORAS)
    @CacheEvict(value = {
            CACHE_TIPO_ENDERECO,
            CACHE_LOCALIZACAO,
            CACHE_MUNICIPIO,
            CACHE_RAMO,
            CACHE_CARGOS_GOVERNANCA,
            CACHE_CADASTRO_UNIDADE_ESTADUAL,
            CACHE_PARAMETRO_QUADRO_SOCIAL,
            CACHE_SEGMENTOS,
            CACHE_SITUACAO_COOPERATIVA,
            CACHE_CADASTRO_REGISTRO,
            CACHE_CADASTRO_REGISTRO_LEITURA,
            CACHE_USUARIO_NOME
    }, allEntries = true)
    public void clearCacheQuatroHoras() {
        log.info("Limpando cache a cada {} hora", CACHE_TIMER_QUATRO_HORAS);
    }

    @Scheduled(fixedRate = CACHE_TIMER_UMA_HORAS)
    @CacheEvict(value = {CACHE_TIPO_ORGAO_GOVERNANCA}, allEntries = true)
    public void clearCacheUmaHora() {
        log.info("Limpando cache a cada {} hora", CACHE_TIMER_UMA_HORAS);
    }

    @Scheduled(fixedRate = CACHE_TIMER_OITO_HORAS)
    @CacheEvict(value = {CACHE_MESSAGES}, allEntries = true)
    public void clearCacheOitoHoras() {
        log.info("Limpando cache a cada {} hora", CACHE_TIMER_OITO_HORAS);
    }

}
