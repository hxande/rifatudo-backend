package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao;

import java.util.List;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

public class DadosGeraisValidacaoContato {
	public static final String VALIDACAO_EMAIL_OBRIGATORIO = "dadosGerais.validacao.emailObrigatorio";
	public static final String VALIDACAO_EMAIL_INVALIDO = "dadosGerais.validacao.emailInvalido";
	public static final String VALIDACAO_TELEFONE_OBRIGATORIO = "dadosGerais.validacao.telefoneInvalido";

	public List<ServiceMessage> validaContato(List<ServiceMessage> mensagens, Cooperativa c,  MessagesService messages){
		if(!ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getEmailGeral())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_EMAIL_OBRIGATORIO)));
		} else if(!ValidacaoCampos.validarEmail(c.getPessoaJuridica().getEmailGeral())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_EMAIL_INVALIDO)));
		}

		if(!ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getTelefoneGeral())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_TELEFONE_OBRIGATORIO)));
		}

		return mensagens;

	}

    public boolean validaNaoObrigatorios(Cooperativa c) {
        return ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getSite())
                && ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getLojaVirtual())
                && ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getRedesSociais());
    }

}
