package br.coop.somoscooperativismo.registro.api.v1.email.util;

import br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class EmailServiceEvent<T> {
    private final int typeEvent;
    private final EnvioEmailEventEnum executeType;
    private final T model;
}
