package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas;

import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.entidade.CooperativaManutencaoAbas;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CooperativaManutencaoAbasRepository extends JpaRepository<CooperativaManutencaoAbas, Integer> {

	Optional<CooperativaManutencaoAbas> findByIdCooperativaAndAnoCiclo(Integer idCooperativa, Integer anoCiclo);

}
