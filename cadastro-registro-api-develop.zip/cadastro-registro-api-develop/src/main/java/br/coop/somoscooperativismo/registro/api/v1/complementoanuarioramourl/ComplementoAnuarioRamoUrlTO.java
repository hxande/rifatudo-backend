package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplementoAnuarioRamoUrlTO {

    private Integer complementoAnuarioId;
    private Integer id;

    @NotNull(message = "Campo Ramo é obrigatório")
    private Integer ramoId;

    @NotEmpty(message = "Campo Link é obrigatório!")
    @Size(max = 2000)
    private String url;
}
