package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * INV-2/INV-6 (FR-009/FR-019) — um mesmo CPF não pode ocupar duas posições
 * <b>ativas</b> na submissão de governança (decisão Q2=A, clarification
 * 2026-06-24). Regra unificada entre Registro e Manutenção: ambos os fluxos
 * passam a considerar apenas posições ativas, eliminando o ramo divergente
 * {@code isManutencao} de {@code validaCpfDuplicado}.
 *
 * <p>A comparação usa o CPF <b>sem máscara</b> (QA R4-10/A19): o payload do
 * front chega mascarado ({@code 999.999.999-99}) e o banco guarda apenas
 * dígitos — sem normalizar, a duplicidade entre um conselho sob gravação e um
 * conselho persistido nunca colidia e o FR-033 não bloqueava a gravação.
 * Quando as duas ocorrências ativas estão em órgãos DIFERENTES, a violação é
 * {@link TipoViolacaoGovernanca#CPF_DUPLICADO_ENTRE_CONSELHOS}, que carrega os
 * dois órgãos para a mensagem (FR-033).</p>
 */
@Component
public class CpfDuplicadoRule implements GovernancaRule {

    @Override
    public List<ViolacaoGovernanca> avaliar(GovernancaContext contexto) {
        List<ViolacaoGovernanca> violacoes = new ArrayList<>();
        // CPF normalizado (sem máscara) -> órgão da PRIMEIRA ocorrência ativa.
        Map<String, String> orgaoPorCpfAtivo = new LinkedHashMap<>();
        for (Mandato mandato : contexto.getMandatos()) {
            String nomeOrgao = mandato.getOrgao() != null ? mandato.getOrgao().getNome() : null;
            for (MandatoMembro membro : GovernancaContext.membros(mandato)) {
                if (!Boolean.TRUE.equals(membro.getMembroAtivo())) {
                    continue;
                }
                if (membro.getPessoaFisica() == null || membro.getPessoaFisica().getCpf() == null) {
                    continue;
                }
                String cpf = RemoveMascaraUtil.remove(membro.getPessoaFisica().getCpf());
                if (!orgaoPorCpfAtivo.containsKey(cpf)) {
                    orgaoPorCpfAtivo.put(cpf, nomeOrgao);
                    continue;
                }
                String orgaoPrimeiraOcorrencia = orgaoPorCpfAtivo.get(cpf);
                if (Objects.equals(orgaoPrimeiraOcorrencia, nomeOrgao)) {
                    violacoes.add(ViolacaoGovernanca.deMembro(
                            TipoViolacaoGovernanca.CPF_DUPLICADO, nomeOrgao,
                            membro.getPessoaFisica().getCpf()));
                } else {
                    violacoes.add(ViolacaoGovernanca.deCpfEntreOrgaos(
                            nomeOrgao, cpf, orgaoPrimeiraOcorrencia));
                }
            }
        }
        return violacoes;
    }
}
