package br.coop.somoscooperativismo.registro.api.v1.governanca.event.util;

import lombok.Getter;

@Getter
public enum GovernancaEventEnum {
    MEMBRO_ADICIONADO,
    MEMBRO_ATUALIZADO,
    MEMBRO_REMOVIDO,
    ATUALIZAR_DIRETORIA_GDH;
}
