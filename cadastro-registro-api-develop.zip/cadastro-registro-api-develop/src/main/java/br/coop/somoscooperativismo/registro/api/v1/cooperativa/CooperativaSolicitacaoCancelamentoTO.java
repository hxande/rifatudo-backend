package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CooperativaSolicitacaoCancelamentoTO {
	
	@NotNull
	private Integer idCooperativa;
	
	@NotNull
	private Integer idSolicitacao;
	
	@NotNull
	private String justificativaSolicitacaoCancelamento;
	
	@NotNull
	private String anexo;
}
