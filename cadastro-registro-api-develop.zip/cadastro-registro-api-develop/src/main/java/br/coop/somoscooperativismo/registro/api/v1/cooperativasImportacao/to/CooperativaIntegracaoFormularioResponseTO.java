package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.sql.Date;
import java.time.LocalDate;
import lombok.Data;

@Data
public class CooperativaIntegracaoFormularioResponseTO {
    private Integer id;
    private String categoria;
    private LocalDate dataRegistroOcb;
    private LocalDate dataAtualizacao;
    private Boolean regidaPorLei;
    private String situacao;
    private String cnpj;
    private String razaoSocial;
    private  String nomeFantasia;
    private LocalDate dataConstituicaoFundacao;
    private String nire;
    private String telefoneGeral;
    private String emailGeral;
    private String site;
    private String ramo;
    private Boolean aprovada;

    public static CooperativaIntegracaoFormularioResponseTO converter(Object[] obj) {
        CooperativaIntegracaoFormularioResponseTO to = new CooperativaIntegracaoFormularioResponseTO();
        to.setId(obj.length > 0 && obj[0] != null ? (Integer) obj[0] : null);
        to.setCategoria(obj.length > 1 ? (String) obj[1] : null);
        to.setDataRegistroOcb(obj.length > 2 && obj[2] != null ? ((Date) obj[2]).toLocalDate() : null);
        to.setDataAtualizacao(obj.length > 3 && obj[3] != null ? ((Date) obj[3]).toLocalDate() : null);
        to.setRegidaPorLei(obj.length > 4 && obj[4] != null ? (Boolean) obj[4] : null);
        to.setSituacao(obj.length > 5 ? (String) obj[5] : null);
        to.setCnpj(obj.length > 6 ? (String) obj[6] : null);
        to.setRazaoSocial(obj.length > 7 ? (String) obj[7] : null);
        to.setNomeFantasia(obj.length > 8 ? (String) obj[8] : null);
        to.setDataConstituicaoFundacao(obj.length > 9 && obj[9] != null ? ((Date) obj[9]).toLocalDate() : null);
        to.setNire(obj.length > 10 ? (String) obj[10] : null);
        to.setTelefoneGeral(obj.length > 11 ? (String) obj[11] : null);
        to.setEmailGeral(obj.length > 12 ? (String) obj[12] : null);
        to.setSite(obj.length > 13 ? (String) obj[13] : null);
        to.setRamo(obj.length > 14 ? (String) obj[14] : null);
        to.setAprovada(obj.length > 15 && obj[15] != null ? Boolean.parseBoolean((String) obj[15]) : null);
        return to;
    }
}
