package br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento;

import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade.Faturamento;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

public interface FaturamentoRepository extends JpaRepository<Faturamento, Integer> {

    @Query("select f from Faturamento f where f.cooperativa = :cooperativa")
    List<Faturamento> obterFaturamentos(@Param("cooperativa") Cooperativa cooperativa);
    
    @Query("select f from Faturamento f where f.cooperativa.id = :idCooperativa and f.aprovacao.id = :idAprovacao")
    List<Faturamento> obterFaturamentosPorCooperativaEAprovacao(@Param("idCooperativa") Integer idCooperativa, @Param("idAprovacao") Integer idAprovacao);

    @Query("select f from Faturamento f where f.cooperativa = :cooperativa and f.ano < :ano")
    List<Faturamento> obterFaturamentosHistorico(@Param("cooperativa") Cooperativa cooperativa, @Param("ano") Integer ano);

    @Query("select f from Faturamento f where f.ano = :ano and f.cooperativa = :cooperativa")
    Faturamento obterFaturamento(@Param("cooperativa") Cooperativa cooperativa, @Param("ano") Integer ano);
    
    @Query(value = "Select top 1 f.* from COOPERATIVA_FATURAMENTO f with(nolock) where f.NR_ANO = :ano and f.SQ_COOPERATIVA = :idCooperativa", nativeQuery = true)
	Optional<Faturamento> buscaPorAno(@Param("idCooperativa") Integer idCooperativa, @Param("ano") Integer ano);

    @Query("select f from Faturamento f where f.cooperativa.id = :idCooperativa")
    List<Faturamento> obterFaturamentosPorCooperativaId(Integer idCooperativa);
}
