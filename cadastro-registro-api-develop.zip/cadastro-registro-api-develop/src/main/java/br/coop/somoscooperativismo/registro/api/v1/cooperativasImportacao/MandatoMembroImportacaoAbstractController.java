package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.spi.MappingContext;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.AprovacaoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CargoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.MandatoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.MandatoMembroImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.OrgaoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.PessoaFisicaImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class MandatoMembroImportacaoAbstractController {

    @NonNull
    protected ModelMapper modelMapper;

    protected Converter<MandatoMembro, MandatoMembroImportacaoTO> converterEntidadeParaTO = context ->
            MandatoMembroImportacaoTO.builder()
                    .id(context.getSource().getId())
                    .mandato(MandatoImportacaoTO.builder()
                            .id(context.getSource().getMandato().getId())
                            .cooperativa(CooperativaImportacaoTO.builder()
                                    .id(context.getSource().getMandato().getCooperativa().getId())
                                    .build())
                            .dataAssembleia(context.getSource().getMandato().getDataAssembleia())
                            .orgao(OrgaoImportacaoTO.builder()
                                    .id(context.getSource().getMandato().getOrgao().getId())
                                    .nome(context.getSource().getMandato().getOrgao().getNome())
                                    .obrigatorio(context.getSource().getMandato().getOrgao().getObrigatorio())
                                    .ativo(context.getSource().getMandato().getOrgao().getAtivo())
                                    .nomeiaResponsavel(context.getSource().getMandato().getOrgao().getNomeiaResponsavel())
                                    .vinculo(context.getSource().getMandato().getOrgao().getVinculo())
                                    .build())
                            .fimMandato(context.getSource().getMandato().getFimMandato())
                            .anosDuracao(context.getSource().getMandato().getAnosDuracao())
                            .membrosMandato(context.getSource().getMandato().getMembrosMandato())
                            .vigente(context.getSource().getMandato().getVigente())
                            .listaMandatoMembro(null)
                            .build())
                    .cargo(CargoImportacaoTO.builder()
                            .id(context.getSource().getCargo().getId())
                            .ativo(context.getSource().getCargo().getAtivo())
                            .nome(context.getSource().getCargo().getNome())
                            .build())
                    .pessoaFisica(PessoaFisicaImportacaoTO.builder()
                            .seqCpf(context.getSource().getPessoaFisica().getSeqCpf())
                            .cpf(context.getSource().getPessoaFisica().getCpf())
                            .nome(context.getSource().getPessoaFisica().getNome())
                            .dataNascimento(context.getSource().getPessoaFisica().getDataNascimento())
                            .telefone(context.getSource().getPessoaFisica().getTelefone())
                            .celular(context.getSource().getPessoaFisica().getCelular())
                            .email(context.getSource().getPessoaFisica().getEmail())
                            .genero(context.getSource().getPessoaFisica().getGenero())
                            .idEscolaridade(context.getSource().getPessoaFisica().getIdEscolaridade())
                            .build())
                    .representanteLegal(context.getSource().getRepresentanteLegal())
                    .membroAtivo(context.getSource().getMembroAtivo())
                    .inicioMandato(context.getSource().getInicioMandato())
                    .fimMandato(context.getSource().getFimMandato())
                    .aprovacao(getAprovacao(context))
                    .build();

    private AprovacaoImportacaoTO getAprovacao(MappingContext<MandatoMembro, MandatoMembroImportacaoTO> context) {
        if (null == context.getSource().getAprovacao()) {
            return null;
        }

        return AprovacaoImportacaoTO.builder()
                .id(context.getSource().getAprovacao().getId())
                .ano(context.getSource().getAprovacao().getAno())
                .dataAtualizacao(context.getSource().getAprovacao().getDataAtualizacao())
                .build();
    }
}