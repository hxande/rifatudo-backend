package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.PathVariable;


public interface CooperativaRegistroRepository extends JpaRepository<CooperativaRegistro, Integer> {

	@Query("Select cooperativa from CooperativaRegistro cooperativa where cooperativa.id = :id")
	Optional<CooperativaRegistro> buscaPorPessoaJuridica(@PathVariable Integer id);
	
	@Query("SELECT cr FROM CooperativaRegistro cr where cr.cooperativa.id = :id")
	List<CooperativaRegistro> getUltimoRegistroAtivo(@PathVariable Integer id);
	
	@Query("SELECT cr FROM CooperativaRegistro cr where cr.cooperativa.id = :id")
	CooperativaRegistro findByCooperativaIdAndUltimoRegistroTrue(Integer id);
	
	CooperativaRegistro findTop1ByCooperativaId(Integer cooperativaId);

	CooperativaRegistro findTop1ByCooperativaIdAndSituacaoIdOrderByIdDesc(Integer idCooperativa, Integer idSitucao);

 	CooperativaRegistro findTop1ByCooperativaIdAndSituacaoIdAndSolicitacaoInativacaoTrueOrderByIdDesc(Integer idCooperativa, Integer idSitucao);
	
 	@Query("SELECT cr FROM CooperativaRegistro cr where cr.cooperativa.id = :id and cr.situacao.id = :situacaoId order by cr.id desc")
 	List<CooperativaRegistro> getUltimoHistoricoApontamentoIrregularidadeSolicitacaoInativacao (
			@PathVariable Integer id,
			@PathVariable Integer situacaoId, 
			Pageable page);
 	
 	@Query("SELECT cr FROM CooperativaRegistro cr where cr.cooperativa.id = :id and cr.situacao.id = :situacaoId order by cr.id desc")
 	List<CooperativaRegistro> getUltimoHistoricoInativacao (
			@PathVariable Integer id,
			@PathVariable Integer situacaoId, 
			Pageable page);
 	
 	@Query("SELECT cr FROM CooperativaRegistro cr where cr.cooperativa.id = :id and cr.situacao.id = :situacaoId and solicitacaoAtivacao = :solicitacaoAtivacao order by cr.id desc")
 	List<CooperativaRegistro> getUltimoHistoricoSolicitacaoAtivacao(
 			@PathVariable Integer id,
			@PathVariable Integer situacaoId,
			@PathVariable Boolean solicitacaoAtivacao,
			Pageable page);
 	
 	@Query("SELECT cr FROM CooperativaRegistro cr where cr.cooperativa.id = :id and cr.situacao.id = :situacaoId order by cr.id desc")
	List<CooperativaRegistro> getUltimoHistoricoCancelamento(
			@PathVariable Integer id,
			@PathVariable Integer situacaoId,
			Pageable page);
 	
 	@Query("SELECT cr FROM CooperativaRegistro cr where "
 			+ "cr.cooperativa.id = :id and "
 			+ "cr.situacao.id = :situacaoId and "
 			+ "cr.solicitacaoInativacao is not null "
 			+ "order by cr.id desc")
 	List<CooperativaRegistro> buscaUltimoHistoricoSolicitacaoInativacao(
 			@PathVariable Integer id,
 			@PathVariable Integer situacaoId,
 			Pageable page);
 	
 	@Query("SELECT cr FROM CooperativaRegistro cr where "
 			+ "cr.cooperativa.id = :id and "
 			+ "cr.situacao.id = :situacaoId and "
 			+ "cr.solicitacaoCancelamento = :solicitacaoCancelamento  and "
 			+ "cr.justificativaSolicitacaoCancelamento is not null "
 			+ "order by cr.id desc")
 	List<CooperativaRegistro> buscaUltimoHistoricoSolicitacaoCancelamento(
 			@PathVariable Integer id,
 			@PathVariable Integer situacaoId,
 			@PathVariable Boolean solicitacaoCancelamento,
 			Pageable page);
 	
	@Query("SELECT cr FROM CooperativaRegistro cr where "
 			+ "cr.cooperativa.id = :id and "
 			+ "(cr.justificativaAtivacao is not null OR cr.justificativaCancelada is not null "
 			+ "or cr.justificativaInativada is not null) and "
 			+ "( cr.solicitacaoAtivacao is null and cr.solicitacaoCancelamento is null "
 			+ " and cr.solicitacaoInativacao is null) "
 			+ "order by cr.id desc")
 	List<CooperativaRegistro> buscaHistoricoSituacaoCooperativa(
 			@PathVariable Integer id);
	
	@Query("SELECT cr FROM CooperativaRegistro cr where "
 			+ "cr.cooperativa.id = :id "
 			+ " order by cr.id desc ")
 	List<CooperativaRegistro> buscaHistoricoCooperativa(@PathVariable Integer id);


	@Query(value = "select * from dbo.COOPERATIVA_REGISTRO cr "
				+ " WHERE IN_TIPO_ACAO  = 'UE_NOTIFICA_SUSPENSAO' "
				+ " AND DT_ALTERACAO_SITUACAO_STATUS = :data "
				+ " AND NOT EXISTS (SELECT * FROM dbo.COOPERATIVA_REGISTRO cr2 "
				+ " WHERE cr2.DT_ALTERACAO_SITUACAO_STATUS > cr.DT_ALTERACAO_SITUACAO_STATUS and cr2.SQ_COOPERATIVA = cr.SQ_COOPERATIVA)", nativeQuery = true)
	List<CooperativaRegistro> buscaRegistrosNotificacaoAEnviar(@Param("data") String data);
	
}
