package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import br.coop.somoscooperativismo.registro.api.v1.censoanuario.entidade.CensoAnuario;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CensoAnuarioMapper {

    @Mapping(source = "cooperativaId", target = "cooperativa.id")
    CensoAnuario toModel(CensoAnuarioTO censoAnuarioTO);

    @Mapping(source = "cooperativa.id", target = "cooperativaId")
    CensoAnuarioTO toDto(CensoAnuario censoAnuario);

}
