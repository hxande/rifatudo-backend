package br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.entidade;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import lombok.Data;


@Data
@Entity
@Table(name = "COOPERATIVA_CENSO_ANUARIO_PREENCHIMENTO")
public class CensoAnuarioPreenchimento {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_CENSO_ANUARIO_PREENCHIMENTO")
    private Integer id;

    @Column(name = "NR_ANO", nullable = false, updatable = false)
    private Integer ano;

    @Column(name = "SQ_COOPERATIVA", nullable = false, updatable = false)
    private Integer idCooperativa;
    

    @Column(name = "DT_INICIO", updatable = false, nullable = false)
    private LocalDateTime dataInicio;
    
    @Column(name = "DT_FIM")
    private LocalDateTime dataFim;


    @Transient
    private Boolean finaliza;
}
