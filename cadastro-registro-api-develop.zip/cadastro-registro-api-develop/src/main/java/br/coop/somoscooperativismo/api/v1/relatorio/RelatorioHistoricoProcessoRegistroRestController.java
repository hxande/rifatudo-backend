package br.coop.somoscooperativismo.api.v1.relatorio;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/v1/relatorio/historico-processo-registro")
@Tag(name = "Relatório Histórico do Processo de Registro")
@RequiredArgsConstructor
public class RelatorioHistoricoProcessoRegistroRestController {

    private final RelatorioHistoricoProcessoRegistroService relatorioService;

    @GetMapping("/{uf}")
    @Operation(summary = "Gera relatório Excel do histórico dos processos de registro por UF")
    public ResponseEntity<byte[]> gerarRelatorio(
            @PathVariable String uf,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dataInicio,
            @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date dataFim,
            @RequestParam(required = false) List<String> status) {

        RelatorioHistoricoProcessoRegistroFiltroTO filtro = new RelatorioHistoricoProcessoRegistroFiltroTO();
        filtro.setUf(uf.toUpperCase());
        filtro.setDataInicio(dataInicio);
        filtro.setDataFim(dataFim);
        filtro.setStatus(status);

        byte[] dados = relatorioService.gerarRelatorio(filtro);

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Historico_Processo_Registro_" + uf.toUpperCase() + ".xlsx");
        header.add(HttpHeaders.CACHE_CONTROL, "no-cache, no-store, must-revalidate");
        header.add(HttpHeaders.PRAGMA, "no-cache");
        header.add(HttpHeaders.EXPIRES, "0");

        return ResponseEntity.ok()
                .headers(header)
                .contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(dados);
    }
}
