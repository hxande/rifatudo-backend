package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaRepository;
import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacao;
import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacaoCooperativa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CriterioAssociacaoCooperativaService {

    @Autowired
    private CriterioAssociacaoCooperativaRepository criterioAssociacaoCooperativaRepository;

    @Autowired
    private CooperativaRepository cooperativaRepository;

    @Autowired
    private CriterioAssociacaoRespository criterioAssociacaoRepository;


    @Autowired
    CriterioAssociacaoCooperativaConverter associacaoCooperativaConverter;


    @Transactional
    public List<CriterioAssociacaoCooperativaTO> sincronizarRegistros(List<CriterioAssociacaoCooperativaTO> dtos) {
        Integer sqCooperativa = dtos.get(0).getSqCooperativa();
        cooperativaRepository.findById(sqCooperativa)
                .orElseThrow(() -> new RegraNegocioException("Cooperativa não encontrada com o ID: " + sqCooperativa));

        List<CriterioAssociacaoCooperativa> existentes = criterioAssociacaoCooperativaRepository.findByCooperativaId(sqCooperativa);

        Set<CriterioAssociacaoCooperativaChaveCompostaTO> chavesExistentes = existentes.stream()
                .map(e -> new CriterioAssociacaoCooperativaChaveCompostaTO(e.getCooperativa().getId(), e.getCriterioAssociacao().getId()))
                .collect(Collectors.toSet());

        Set<CriterioAssociacaoCooperativaChaveCompostaTO> chavesFornecidas = dtos.stream()
                .map(dto -> new CriterioAssociacaoCooperativaChaveCompostaTO(dto.getSqCooperativa(), dto.getSqCriterioAssociacao()))
                .collect(Collectors.toSet());

        Set<CriterioAssociacaoCooperativaChaveCompostaTO> paraInserir = new HashSet<>(chavesFornecidas);
        paraInserir.removeAll(chavesExistentes);

        Set<CriterioAssociacaoCooperativaChaveCompostaTO> paraExcluir = new HashSet<>(chavesExistentes);
        paraExcluir.removeAll(chavesFornecidas);

        List<CriterioAssociacaoCooperativa> sincronizados = new ArrayList<>();

        for (CriterioAssociacaoCooperativaChaveCompostaTO chave : paraInserir) {
            CriterioAssociacaoCooperativa novoRegistro = new CriterioAssociacaoCooperativa();
            novoRegistro.setCooperativa(cooperativaRepository.findById(chave.getCooperativaId()).orElse(null));
            novoRegistro.setCriterioAssociacao(criterioAssociacaoRepository.findById(chave.getCriterioAssociacaoId()).orElse(null));
            novoRegistro.setAtivo(true);
            CriterioAssociacaoCooperativa registroSalvo = criterioAssociacaoCooperativaRepository.save(novoRegistro);
            sincronizados.add(registroSalvo);
        }

        for (CriterioAssociacaoCooperativaChaveCompostaTO chave : paraExcluir) {
            Optional<CriterioAssociacaoCooperativa> registroOpt = criterioAssociacaoCooperativaRepository.findByCooperativa_IdAndCriterioAssociacao_Id(chave.getCooperativaId(), chave.getCriterioAssociacaoId());
            registroOpt.ifPresent(criterioAssociacaoCooperativaRepository::delete);
        }

        existentes.addAll(sincronizados);

        chavesExistentes = null;
        paraExcluir = null;
        sincronizados = null;

        return associacaoCooperativaConverter.toDTOList(existentes);
    }


    public CriterioAssociacaoCooperativa salvarCriterioAssociacaoCooperativa(CriterioAssociacaoCooperativa criterioAssociacaoCooperativa) {

        // Verificar se a Cooperativa e o CriterioAssociacao existem
        Integer sqCooperativa = criterioAssociacaoCooperativa.getCooperativa().getId();
        Integer sqCriterioAssociacao = criterioAssociacaoCooperativa.getCriterioAssociacao().getId();

        Cooperativa cooperativa = cooperativaRepository.findById(sqCooperativa)
                .orElseThrow(() -> new RegraNegocioException("Cooperativa não encontrada com o ID: " + sqCooperativa));

        CriterioAssociacao criterioAssociacao = criterioAssociacaoRepository.findById(sqCriterioAssociacao)
                .orElseThrow(() -> new RegraNegocioException("CriterioAssociacao não encontrada com o ID: " + sqCriterioAssociacao));

        if (!isCriterioAssociacaoAtivo(criterioAssociacao.getId())) {
            throw new RegraNegocioException("O Critério de associação está inativo e por este motivo não é possível salvar.");
        }

        criterioAssociacaoCooperativa.setCooperativa(cooperativa);
        criterioAssociacaoCooperativa.setCriterioAssociacao(criterioAssociacao);

        cooperativa = null;
        criterioAssociacao = null;

        return criterioAssociacaoCooperativaRepository.save(criterioAssociacaoCooperativa);
    }

    public List<CriterioAssociacaoCooperativaResponseTO> listarCriterioAssociacaoAtivoCooperativaPorCooperativa(Integer sqCooperativa) {
        List<CriterioAssociacaoCooperativa> associacoes = criterioAssociacaoCooperativaRepository.findByCooperativaIdAndAtivoTrueAndCriterioAssociacao_AtivoTrue(sqCooperativa);
        return associacaoCooperativaConverter.toResponseDTOList(associacoes);
    }


    public List<CriterioAssociacaoCooperativaReadOnlyTO> listarCriterioAssociacaoCooperativaPorCooperativaDescricao(Integer sqCooperativa) {
        List<CriterioAssociacaoCooperativa> associacoes = criterioAssociacaoCooperativaRepository.findByCooperativaId(sqCooperativa);
        return converterParaDTO(associacoes);
    }

    private List<CriterioAssociacaoCooperativaReadOnlyTO> converterParaDTO(List<CriterioAssociacaoCooperativa> associacoes) {
        List<CriterioAssociacaoCooperativaReadOnlyTO> dtoList = new ArrayList<>();
        for (CriterioAssociacaoCooperativa associacao : associacoes) {
            CriterioAssociacaoCooperativaReadOnlyTO dto = new CriterioAssociacaoCooperativaReadOnlyTO();
            dto.setId(associacao.getId());
            dto.setIdCriterioAssociacao(associacao.getCriterioAssociacao().getId());
            dto.setIdCooperativa(associacao.getCooperativa().getId());
            dto.setNomeCriterioAssociacao(associacao.getCriterioAssociacao().getDescricao());
            dto.setNomeCooperativa(associacao.getCooperativa().getNomeCooperativa());
            dtoList.add(dto);
        }
        return dtoList;
    }

    public boolean editarCriterioAssociacaoCooperativa(Integer id, CriterioAssociacaoCooperativaTO dto) {

        Optional<CriterioAssociacaoCooperativa> associacaoOptional = criterioAssociacaoCooperativaRepository.findById(id);

        if (associacaoOptional.isPresent()) {
            CriterioAssociacaoCooperativa associacao = associacaoOptional.get();
            dto.setId(id);
            if (!isCriterioAssociacaoAtivo(dto.getSqCriterioAssociacao())) {
                throw new RegraNegocioException("O Critério de associação está inativo e por este motivo não pe possível editar.");
            }
            criterioAssociacaoCooperativaRepository.save(associacao);

            associacaoOptional = null;

            return true;
        } else {
            return false;
        }
    }

    public boolean isCriterioAssociacaoAtivo(Integer sqCriterioAssociacao) {
        Optional<CriterioAssociacao> criterioAssociacaoOptional = criterioAssociacaoRepository.findById(sqCriterioAssociacao);
        return criterioAssociacaoOptional.map(CriterioAssociacao::getAtivo).orElse(false);
    }
    
}

