package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosComplementaresAbaAdapter;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosContabilTributarioAbaAdapter;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosNegociosAbaAdapter;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosSociaisAbaAdapter;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaDataInterface;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.CooperativaAbaInterface;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.CensoAnuarioService;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.entidade.PessoaSegmProdServ;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v2/cooperativa-anuario-abas")
public class CooperativaAnuarioAbasInterfaceRestController {

    private static final String REGISTRO_SALVO = "registroSalvo.sucesso";
    private static final String REGISTRO_PENDENCIA = "registroSalvo.pendencia";

    private final CooperativaAnuarioAbasInterfaceService cooperativaAnuarioAbasInterfaceService;
    private final CensoAnuarioService censoAnuarioService;
    private final DadosSociaisAbaAdapter dadosSociaisAbaAdapter;
    private final DadosContabilTributarioAbaAdapter dadosContabilTributarioAbaAdapter;
    private final DadosNegociosAbaAdapter dadosNegociosAbaAdapter;
    private final DadosComplementaresAbaAdapter dadosComplementaresAbaAdapter;
    private final MessagesService messages;

    public CooperativaAnuarioAbasInterfaceRestController(
            CooperativaAnuarioAbasInterfaceService cooperativaAnuarioAbasInterfaceService,
            DadosSociaisAbaAdapter dadosSociaisAbaAdapter,
            DadosContabilTributarioAbaAdapter dadosContabilTributarioAbaAdapter,
            DadosComplementaresAbaAdapter dadosComplementaresAbaAdapter,
            DadosNegociosAbaAdapter dadosNegociosAbaAdapter,
            CensoAnuarioService censoAnuarioService,
            MessagesService messages
    ) {
        this.cooperativaAnuarioAbasInterfaceService = cooperativaAnuarioAbasInterfaceService;
        this.censoAnuarioService = censoAnuarioService;
        this.dadosSociaisAbaAdapter = dadosSociaisAbaAdapter;
        this.dadosNegociosAbaAdapter = dadosNegociosAbaAdapter;
        this.dadosContabilTributarioAbaAdapter = dadosContabilTributarioAbaAdapter;
        this.dadosComplementaresAbaAdapter = dadosComplementaresAbaAdapter;
        this.messages = messages;
    }

    @GetMapping("/{idCooperativa}/{anoCiclo}")
    public ServiceResponse<List<CooperativaAbaInterface>> obterListaAbasAnuario(@PathVariable Integer idCooperativa, @PathVariable Integer anoCiclo) {
        return new ServiceResponse<>(cooperativaAnuarioAbasInterfaceService.obterListaAbaAnuario(idCooperativa, anoCiclo));
    }

    @GetMapping("/quadro-social/{idCooperativa}/ano/{ano}")
    public List<AbaDataInterface> obterQuadroSocialAnuario(@PathVariable Integer idCooperativa, @PathVariable Integer ano) {
        return cooperativaAnuarioAbasInterfaceService.obterListaAbaAnuarioDadosSociais(idCooperativa, ano);
    }

    @GetMapping("contabil-tributario/{idCooperativa}/ano/{ano}")
    public ServiceResponse<List<AbaDataInterface>> obterLancamentosExternos(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano
    ) {
        return new ServiceResponse<>(cooperativaAnuarioAbasInterfaceService.obterListaAbaAnuarioDadosContabilTributario(ano, idCooperativa));
    }

    @GetMapping("negocios/{idCooperativa}/ano/{ano}")
    public ServiceResponse<List<AbaDataInterface>> obterNegocios(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano
    ) {
        return new ServiceResponse<>(cooperativaAnuarioAbasInterfaceService.obterListaAbaNegocios(ano, idCooperativa));
    }

    @GetMapping("/dados-complementares/{idCooperativa}/ano/{ano}")
    public ServiceResponse<List<AbaDataInterface>> obterDadosComplementaresAnuario(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano
    ) {
        return new ServiceResponse<>(cooperativaAnuarioAbasInterfaceService.obterListaAbaAnuarioDadosComplementares(idCooperativa, ano));
    }

    @PostMapping("/quadro-social/{idCooperativa}/ano/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarDadosSociaisAnuario(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody RequestAnuarioTO request
    ) {
        boolean sucesso = this.dadosSociaisAbaAdapter.execute(idCooperativa, ano, request, isSubmit);
        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @PostMapping("/portifolio/{idCooperativa}/ano/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarPortifolioAnuario(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano,
            @RequestBody RequestPortfolioTO requestPortfolioTO
    ) {
        boolean sucesso = this.censoAnuarioService.salvarAbaPortfolio(idCooperativa, ano, requestPortfolioTO);

        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @PostMapping("/contabil-tributario/{idCooperativa}/ano/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarContabilTributarioAnuario(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody RequestAnuarioTO request
    ) {
        boolean sucesso = this.dadosContabilTributarioAbaAdapter.execute(idCooperativa, ano, request, isSubmit);
        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @PostMapping("/negocio/{idCooperativa}/ano/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarNegocioAnuario(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano,
            @RequestParam(name = "isSubmit", defaultValue = "false", required = false) boolean isSubmit,
            @RequestBody RequestAnuarioTO request
    ) {
        boolean sucesso = this.dadosNegociosAbaAdapter.execute(idCooperativa, ano, request, isSubmit);
        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }

    @PostMapping("/dados-complementares/{idCooperativa}/ano/{ano}")
    public ResponseEntity<ServiceResponse<Void>> salvarDadosComplementaresAnuario(
            @PathVariable Integer idCooperativa,
            @PathVariable Integer ano,
            @RequestBody RequestAnuarioTO request
    ) {
        boolean sucesso = this.dadosComplementaresAbaAdapter.execute(idCooperativa, ano, request);
        String mensagem = messages.get(sucesso ? REGISTRO_SALVO : REGISTRO_PENDENCIA);
        MessageType tipoMensagem = sucesso ? MessageType.SUCCESS : MessageType.WARN;

        ServiceMessage message = new ServiceMessage(tipoMensagem, mensagem);
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
}
