package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import lombok.Data;

@Data
public class CooperativaAbaInterface {

    private String id;
    private String title;
    private Object handler;
    private boolean tabPreenchida;
    private CooperativaAbaDataInterface content;
    private Integer indice;
    private boolean temPendencia;
    private Integer situacao;

}
