package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.orgao.VinculoEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * INV-4 (FR-007) — consistência de datas do membro ativo de vínculo
 * estatutário eletivo: início do mandato não pode ser anterior à data da
 * assembleia, nem posterior à data atual.
 *
 * <p>Paridade: {@code GovernancaService.verificaMembro} (ramos estatutário).
 * A referência de "hoje" é injetável para tornar a regra determinística em
 * testes.</p>
 */
@Component
public class DatasMandatoRule implements GovernancaRule {

    private final java.util.function.Supplier<Date> hoje;

    public DatasMandatoRule() {
        this(Date::new);
    }

    DatasMandatoRule(java.util.function.Supplier<Date> hoje) {
        this.hoje = hoje;
    }

    @Override
    public List<ViolacaoGovernanca> avaliar(GovernancaContext contexto) {
        List<ViolacaoGovernanca> violacoes = new ArrayList<>();
        for (Mandato mandato : contexto.getMandatos()) {
            if (mandato.getOrgao() == null) {
                continue;
            }
            boolean estatutario = VinculoEnum.ESTATUTARIO_ELETIVO.toString().equals(mandato.getOrgao().getVinculo());
            if (!estatutario) {
                continue;
            }
            String nomeOrgao = mandato.getOrgao().getNome();
            Date assembleia = mandato.getDataAssembleia();
            for (MandatoMembro membro : GovernancaContext.membros(mandato)) {
                if (!Boolean.TRUE.equals(membro.getMembroAtivo()) || membro.getInicioMandato() == null) {
                    continue;
                }
                String cpf = membro.getPessoaFisica() != null ? membro.getPessoaFisica().getCpf() : null;
                if (assembleia != null
                        && DataUtil.ignoreTime(membro.getInicioMandato()).before(DataUtil.ignoreTime(assembleia))) {
                    violacoes.add(ViolacaoGovernanca.deMembro(
                            TipoViolacaoGovernanca.INICIO_INVALIDO, nomeOrgao, cpf));
                }
                if (DataUtil.ignoreTime(membro.getInicioMandato()).after(DataUtil.ignoreTime(hoje.get()))) {
                    violacoes.add(ViolacaoGovernanca.deMembro(
                            TipoViolacaoGovernanca.DATA_INICIO_SUPERIOR, nomeOrgao, cpf));
                }
            }
        }
        return violacoes;
    }
}
