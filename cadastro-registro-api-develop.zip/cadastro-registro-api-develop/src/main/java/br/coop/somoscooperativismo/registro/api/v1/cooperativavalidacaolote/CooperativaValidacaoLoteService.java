package br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote;

import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.entidade.CooperativaValidacaoLote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CooperativaValidacaoLoteService {

    @Autowired
    private CooperativaValidacaoLoteRepository repository;

    public CooperativaValidacaoLote saveOrUpdate(CooperativaValidacaoLote cooperativaValidacaoLote) {
        return repository.save(cooperativaValidacaoLote);
    }

    public Optional<CooperativaValidacaoLote> findByCooperativaIdAndAnoReferencia(Integer cooperativaId, Integer anoReferencia) {
        return repository.findByCooperativaIdAndAnoReferencia(cooperativaId, anoReferencia);
    }
}
