package br.coop.somoscooperativismo.registro.api.v1.controleportifolio;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.registro.api.v1.controleportifolio.entidade.ControlePortifolio;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api/v1/controle-portifolio")
@Tag(name = "ControlePortifolio")
public class ControlePortifolioRestController {

	private final ControlePortifolioService controlePortifolioService;

	public ControlePortifolioRestController(ControlePortifolioService controlePortifolioService) {
		this.controlePortifolioService = controlePortifolioService;
	}
	
	@Operation(summary = "Obtem controle do portifólio por UF")
	@GetMapping("/{uf}")
	public ResponseEntity<ServiceResponse<ControlePortifolio>> obterPorUf(@PathVariable String uf){
		return ResponseEntity.ok(new ServiceResponse<>(controlePortifolioService.obterPorUf(uf)));
	}
	
	@Operation(summary = "Obter controle do portifólio Nacional")
	@GetMapping("/obter-controle-nacional")
	public ResponseEntity<ServiceResponse<ControlePortifolio>> obterControleAtualizacaoCadastralNacional() {
		return ResponseEntity.ok(new ServiceResponse<>(controlePortifolioService.obterControleNacional()));
	}
	
	@PostMapping
	@Operation(summary = "Altera o controle do portifolio")
	public ResponseEntity<ServiceResponse<Void>> salvarControlePortifolio(@RequestBody ControlePortifolio controlePortifolio){
		controlePortifolioService.salvar(controlePortifolio);
		ServiceMessage message = new ServiceMessage("Controles dos portifolios atualizados com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
	
	@PutMapping("/habilita-controle-nacional")
	@Operation(summary = "Habilita ou desabilita o controle do portifolio Nacional")
	public ResponseEntity<ServiceResponse<Void>> desabilitaControleControlePortifolio(@RequestBody boolean habilita){
		controlePortifolioService.habilitaControleNacional(habilita);
		ServiceMessage message = new ServiceMessage("Controles dos portifolios atualizados com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
	
}
