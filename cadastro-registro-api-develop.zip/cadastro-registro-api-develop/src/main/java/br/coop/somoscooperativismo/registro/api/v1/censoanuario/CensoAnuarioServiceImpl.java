package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.CooperativaAnuarioAbasInterfaceService;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestPortfolioTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaDataInterface;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.entidade.CensoAnuario;
import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.CensoAnuarioPreenchimentoService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.entidade.CensoAnuarioPreenchimento;
import br.coop.somoscooperativismo.registro.api.v1.controleanuario.ControleAnuarioService;
import br.coop.somoscooperativismo.registro.api.v1.controleanuariouf.ControleAnuarioUfService;
import br.coop.somoscooperativismo.registro.api.v1.controleanuariouf.entidade.ControleAnuarioUf;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.CooperativaAnuarioAbasService;
import br.coop.somoscooperativismo.registro.api.v1.desempenho.DesempenhoClient;
import br.coop.somoscooperativismo.registro.api.v1.enviaemail.EnviaEmailService;
import br.coop.somoscooperativismo.registro.api.v1.events.events.CensoAnuarioPreenchimentoEvent;
import br.coop.somoscooperativismo.registro.api.v1.events.publisher.CensoAnuarioPreenchimentoPublisher;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesService;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoService;
import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.PeriodoAtualizacaoService;
import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.entidade.PeriodoAtualizacao;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaCnpjNomeFantasiaUfSiglaTO;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.PessoaSegmProdServService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.to.QuadroSocialAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.usuario.UsuarioClient;
import br.coop.somoscooperativismo.registro.api.v1.usuario.UsuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

@RequiredArgsConstructor
@Service
public class CensoAnuarioServiceImpl implements CensoAnuarioService {

    private final CensoAnuarioRepository censoAnuarioRepository;
    private final CensoAnuarioMapper censoAnuarioMapper;
    private final DesempenhoClient desempenhoClient;
    private final UsuarioClient usuarioClient;
    private final KeycloakService keycloakService;
    private final QuadroSocialService quadroSocialService;
    private final EnviaEmailService enviaEmailService;
    private final PessoaJuridicaService pessoaJuridicaService;
    private final ControleAnuarioService controleAnuarioService;
    private final CensoAnuarioPreenchimentoService censoAnuarioPreenchimentoService;
    private final CensoAnuarioPreenchimentoPublisher censoAnuarioPreenchimentoPublisher;
    private final CooperativaService cooperativaService;
    private final PeriodoAtualizacaoService periodoAtualizacaoService;
    private final ControleAnuarioUfService controleAnuarioUfService;
    private final CooperativaAnuarioAbasService cooperativaAnuarioAbasService;
    private final CooperativaAnuarioAbasInterfaceService cooperativaAnuarioAbasInterfaceService;
    private final PessoaSegmProdServService pessoaSegmProdServService;
    private final NegocioExportacaoService negocioExportacaoService;
    private final CooperativaFatesService cooperativaFatesService;
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public CensoAnuarioTO create(CensoAnuarioTO censoAnuarioTO, boolean isSubmit) {
//        podeSalvarCensoAnuario();
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(censoAnuarioTO.getCooperativaId(), censoAnuarioTO.getAno(), isSubmit);
        verificarSeExistemPendencias(censoAnuarioTO);

        CensoAnuario censoAnuario = this.censoAnuarioMapper.toModel(censoAnuarioTO);
        censoAnuario.setUsername(keycloakService.getUsername());
        censoAnuario.setDataSubmissao(LocalDateTime.now());
        CensoAnuario created = this.censoAnuarioRepository.save(censoAnuario);
        informarPreenchimento(censoAnuarioTO.getAno(), censoAnuarioTO.getCooperativaId(), true);
        return this.censoAnuarioMapper.toDto(created);
    }


    private void verificaUsuarioPreenchimento() {
        if (Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("CO_VIS")) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("UE_VIS")) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("UN_VIS"))) {
            throw new RegraNegocioException("Usuário sem permissão para preencher o anuário.");
        }

    }


    @Override
    public Optional<CensoAnuarioTO> update(Integer id, CensoAnuarioTO censoAnuarioTO, boolean isSubmit) {
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(censoAnuarioTO.getCooperativaId(), censoAnuarioTO.getAno(), isSubmit);
//        podeSalvarCensoAnuario();
        verificarSeExistemPendencias(censoAnuarioTO);


        return this.censoAnuarioRepository.findById(id).map(censoAnuario -> {
            censoAnuario.setUsername(keycloakService.getUsername());
            censoAnuario.setDataSubmissao(LocalDateTime.now());
            CensoAnuario censoAnuarioSaved = this.censoAnuarioRepository.save(censoAnuario);
            return this.censoAnuarioMapper.toDto(censoAnuarioSaved);
        });
    }

    protected void verificarSeExistemPendencias(CensoAnuarioTO censoAnuarioTO) throws RegraNegocioException {
        if (existemPendenciasNaAbaDadosSociaisFinanceiros(censoAnuarioTO.getCooperativaId(), censoAnuarioTO.getAno())) {
            throw new RegraNegocioException("Existem campos obrigatórios não preenchidos na aba Dados sociais e financeiros!");
        }
    }

    private boolean existemPendenciasNaAbaDadosSociaisFinanceiros(Integer cooperativaId, Integer ano) {
        return existemPendenciasNaAbaDadosSociaisAnuario(cooperativaId) || existemPendenciasNaAbaDadosFinanceiros(cooperativaId, ano);
    }

    private Integer calcularSituacaoAba(ValidacaoPrimeiroRegistroTO vpr) {
        if (vpr.getMensagens() == null) return null;
        if (vpr.getMensagens().isEmpty()) return 1;
        boolean temErro = vpr.getMensagens().stream()
                .anyMatch(m -> MessageType.ERROR.equals(m.getType()));
        return temErro ? -1 : 0;
    }

    private Integer calcularSituacaoAba(List<String> erros) {
        if (erros == null) return null;
        return erros.isEmpty() ? 1 : -1;
    }

    protected boolean existemPendenciasNaAbaDadosSociais(Integer cooperativaId, Integer ano) {
        ValidacaoPrimeiroRegistroTO validacaoPrimeiroRegistroTO = this.quadroSocialService.validarQuadroSocial(cooperativaId, false);
        return validacaoPrimeiroRegistroTO.getMensagens() != null && validacaoPrimeiroRegistroTO.getMensagens().size() > 0;

    }

    protected boolean existemPendenciasNaAbaDadosSociaisAnuario(Integer cooperativaId) {
        ValidacaoPrimeiroRegistroTO validacaoPrimeiroRegistroTO = this.quadroSocialService.validarQuadroSocial(cooperativaId, true);
        return validacaoPrimeiroRegistroTO.getMensagens() != null &&
                validacaoPrimeiroRegistroTO.getMensagens().stream()
                        .anyMatch(m -> MessageType.ERROR.equals(m.getType()));
    }

    private boolean existemPendenciasNabaPortfolioAnuario(Integer cooperativaId) {
        ValidacaoPrimeiroRegistroTO validacaoPrimeiroRegistroTO = this.pessoaSegmProdServService.validarSegmentoProdutoServico(cooperativaId);
        return validacaoPrimeiroRegistroTO.getMensagens() != null && validacaoPrimeiroRegistroTO.getMensagens().size() > 0;
    }

    private boolean existemPendenciasNaAbaDadosFinanceiros(Integer cooperativaId, Integer ano) {
        return this.desempenhoClient.verificarPendencia("SOCIAL_FINANCEIRO", cooperativaId, ano);
    }

    private boolean existemPendendicasNaAbaIntercooperacao(Integer cooperativaId, Integer ano) {
        return this.desempenhoClient.verificarPendencia("INTERCOOPERACAO", cooperativaId, ano);
    }

    @Override
    public Optional<CensoAnuarioTO> getByAnoAndCooperativaId(Integer ano, Integer cooperativaId) {
        return this.censoAnuarioRepository.findByAnoAndCooperativaId(ano, cooperativaId)
                .map(this.censoAnuarioMapper::toDto);
    }

    @Override
    public boolean salvarIntegracao(DadosIntegracaoTO dadosIntegracao, boolean isSubmit) {
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), isSubmit);

        if (!ValidacaoCampos.validaCampoPreenchido(dadosIntegracao)) {
            throw new RegraNegocioException("Objeto vazio...");
        }

        if (ValidacaoCampos.validaCampoPreenchido(dadosIntegracao.getSocialFinanceiro())) {
            this.desempenhoClient.salvarGrupos("SOCIAL_FINANCEIRO", dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), dadosIntegracao.getSocialFinanceiro());
            informarPreenchimento(dadosIntegracao.getAno(), dadosIntegracao.getIdCooperativa(), false);
//            this.cooperativaAnuarioAbasService.salvarAba(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), "SOCIAL_FINANCEIRO", dadosIntegracao.getSituacao());
            return !this.existemPendenciasNaAbaDadosFinanceiros(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno());
        }

        if (ValidacaoCampos.validaCampoPreenchido(dadosIntegracao.getContabilTributarioFiscal())) {
            this.desempenhoClient.salvarGrupos("CONTABIL_TRIBUTARIO", dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), dadosIntegracao.getContabilTributarioFiscal());
            informarPreenchimento(dadosIntegracao.getAno(), dadosIntegracao.getIdCooperativa(), false);
            this.cooperativaAnuarioAbasService.salvarAba(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), "CONTABIL_TRIBUTARIO", dadosIntegracao.getSituacao());
            return !this.desempenhoClient.verificarPendencia("CONTABIL_TRIBUTARIO", dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno());
        }

        if (ValidacaoCampos.validaCampoPreenchido(dadosIntegracao.getNegociosIntercooperacao())) {
            this.desempenhoClient.salvarGrupos(GrupoNegocioEnum.NEGOCIO_INTERCOOPERACAO.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), dadosIntegracao.getNegociosIntercooperacao());
            informarPreenchimento(dadosIntegracao.getAno(), dadosIntegracao.getIdCooperativa(), false);
            this.cooperativaAnuarioAbasService.salvarAba(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), GrupoNegocioEnum.NEGOCIO.getChave(), dadosIntegracao.getSituacao());
            return !this.desempenhoClient.verificarPendencia(GrupoNegocioEnum.NEGOCIO_INTERCOOPERACAO.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno());
        }

        if (ValidacaoCampos.validaCampoPreenchido(dadosIntegracao.getNegociosSetorias())) {
            this.desempenhoClient.salvarGrupos(GrupoNegocioEnum.NEGOCIO_SETORIAIS.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), dadosIntegracao.getNegociosSetorias());
            informarPreenchimento(dadosIntegracao.getAno(), dadosIntegracao.getIdCooperativa(), false);
            this.cooperativaAnuarioAbasService.salvarAba(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), GrupoNegocioEnum.NEGOCIO.getChave(), dadosIntegracao.getSituacao());
            return !this.desempenhoClient.verificarPendencia(GrupoNegocioEnum.NEGOCIO_SETORIAIS.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno());
        }

        if (ValidacaoCampos.validaCampoPreenchido(dadosIntegracao.getNegociosExportacao())) {
            this.desempenhoClient.salvarGrupos(GrupoNegocioEnum.NEGOCIO_EXPORTACAO.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), dadosIntegracao.getNegociosExportacao());
            informarPreenchimento(dadosIntegracao.getAno(), dadosIntegracao.getIdCooperativa(), false);
            this.cooperativaAnuarioAbasService.salvarAba(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), GrupoNegocioEnum.NEGOCIO.getChave(), dadosIntegracao.getSituacao());
            return !this.desempenhoClient.verificarPendencia(GrupoNegocioEnum.NEGOCIO_EXPORTACAO.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno());
        }

        if (ValidacaoCampos.validaCampoPreenchido(dadosIntegracao.getNegociosVendasOnline())) {
            this.desempenhoClient.salvarGrupos(GrupoNegocioEnum.NEGOCIO_VENDAS_ONLINE.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), dadosIntegracao.getNegociosVendasOnline());
            informarPreenchimento(dadosIntegracao.getAno(), dadosIntegracao.getIdCooperativa(), false);
            this.cooperativaAnuarioAbasService.salvarAba(dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno(), GrupoNegocioEnum.NEGOCIO.getChave(), dadosIntegracao.getSituacao());
            return !this.desempenhoClient.verificarPendencia(GrupoNegocioEnum.NEGOCIO_VENDAS_ONLINE.getChave(), dadosIntegracao.getIdCooperativa(), dadosIntegracao.getAno());
        }

        return false;
    }

    @Override
    public void comunicarUnidadeEstadualSubmissaoAnuario(Integer cooperativaId) {
        PessoaJuridicaCnpjNomeFantasiaUfSiglaTO pessoaJuridicaView = pessoaJuridicaService.getViewCnpjAndNomeFantasiaAndUfSiglaById(cooperativaId);
        this.enviaEmailService.enviarEmailUnidadeEstadualSubmissaoAnuario(cooperativaId, pessoaJuridicaView);
    }

    @Override
    public boolean getCheckAnuarioAtualizado(Integer cooperativaId) {
        return censoAnuarioRepository.existsByAnoAndCooperativaId(LocalDate.now().getYear() - 1, cooperativaId);
    }

    @Override
    public boolean salvarAbaDadosFinanceiros(Integer cooperativaId, Integer ano, DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO, boolean isSubmit) {
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(cooperativaId, ano, isSubmit);
        return this.salvarIntegracao(dadosSociaisFinanceirosTO.getFinanceiro(), isSubmit);
    }

    @Override
    public boolean salvarAbaDadosSociais(Integer cooperativaId, Integer ano, DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO, Integer situacao, boolean isSubmit) {
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(cooperativaId, ano, isSubmit);

        QuadroSocialTO quadroSocialTO = new QuadroSocialTO();
        quadroSocialTO.setCooperativa(new Cooperativa(cooperativaId));
        quadroSocialTO.setQuadroSocialManutencao(dadosSociaisFinanceirosTO.getQuadrosSociais());

        this.quadroSocialService.salvarQuadrosSociais(quadroSocialTO);

        informarPreenchimento(ano, cooperativaId, false);

        quadroSocialTO = null;

        return !this.existemPendenciasNaAbaDadosSociaisAnuario(cooperativaId);
    }

    @Override
    public boolean salvarAbaDadosSociais(Integer cooperativaId, Integer ano, List<QuadroSocialAnuarioTO> listQuadroSocialAnuarioTO, Integer situacao, boolean isSubmit) {
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(cooperativaId, ano, isSubmit);

        this.cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "DADOS_SOCIAIS", situacao);

        this.quadroSocialService.salvarQuadroSocialAnuario(listQuadroSocialAnuarioTO);

        informarPreenchimento(ano, cooperativaId, false);

        return !this.existemPendenciasNaAbaDadosSociaisAnuario(cooperativaId);
    }

    @Override
    public boolean salvarAbaPortfolio(Integer cooperativaId, Integer ano, RequestPortfolioTO requestPortfolioTO) {
        verificaUsuarioPreenchimento();
        this.cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "PORTFOLIO", requestPortfolioTO.getSituacao());
        this.pessoaSegmProdServService.vinculaSegmProdServ(cooperativaId, requestPortfolioTO.getFields());

        informarPreenchimento(ano, cooperativaId, false);

        return !this.existemPendenciasNabaPortfolioAnuario(cooperativaId);
    }


    @Override
    public boolean salvarAbaIntercooperacao(DadosIntegracaoTO dadosIntegracaoTO, boolean isSubmit) {
        verificaUsuarioPreenchimento();
        verificaPrazoEstadualENacional(dadosIntegracaoTO.getIdCooperativa(), dadosIntegracaoTO.getAno(), isSubmit);
        return this.salvarIntegracao(dadosIntegracaoTO, isSubmit);

    }

    @Override
    public boolean podeVisualizarAnuario() {
        return controleAnuarioService.podeVisualizarAnuario(keycloakService.getTipoUsuario());
    }

    public void podeSalvarCensoAnuario() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate today = LocalDate.now();
        LocalDate prazoInicial = LocalDate.parse("13/06/2022", formatter);
        LocalDate prazoFinal = LocalDate.parse("08/07/2022", formatter);

        if (!keycloakService.isTipoEntidadeNacional()) {
            if (!controleAnuarioService.podeSalvarAnuario(keycloakService.getTipoUsuario())) {
                throw new RegraNegocioException("A submissão do anuário está desabilitada pelo gestor nacional");
            }
        }

        if (keycloakService.isTipoEntidadeCooperativa() &&
                (prazoInicial.isBefore(today) && prazoFinal.isAfter(today))) {
            throw new RegraNegocioException("O prazo para submissão das informações do anuário do cooperativismo se encerrou no dia: " + prazoInicial.format(formatter));
        }

        today = null;
        prazoFinal = null;
        prazoInicial = null;
    }

    private void informarPreenchimento(Integer ano, Integer idCooperativa, Boolean finaliza) {
        CensoAnuarioPreenchimento censoAnuarioPreenchimento = new CensoAnuarioPreenchimento();
        censoAnuarioPreenchimento.setAno(ano);
        censoAnuarioPreenchimento.setIdCooperativa(idCooperativa);
        censoAnuarioPreenchimento.setFinaliza(finaliza);
        censoAnuarioPreenchimentoPublisher.publish(new CensoAnuarioPreenchimentoEvent(this, censoAnuarioPreenchimento));

        censoAnuarioPreenchimento = null;
    }

    @Override
    public String getStatusAtualizacaoAnuario(Integer idCooperativa) {
        Integer ano = LocalDate.now().getYear() - 1;
        boolean submeteuAnuario = censoAnuarioRepository.existsByAnoAndCooperativaId(ano, idCooperativa);
        boolean preenchendoAnuario = censoAnuarioPreenchimentoService.existsByAnoAndCooperativaId(ano, idCooperativa);

        ano = null;

        return submeteuAnuario ? "Atualizado" : (preenchendoAnuario ? "Em preenchimento" : "Desatualizado");
    }


    @Override
    public CensoAnuarioRecord obterPorAnoAndCooperativaId(Integer ano, Integer cooperativaId) {
        Optional<CensoAnuario> optionalCensoAnuario = censoAnuarioRepository.findByAnoAndCooperativaId(ano, cooperativaId);
        if (optionalCensoAnuario.isEmpty()) {
            return null;
        }
        CensoAnuario censoAnuario = optionalCensoAnuario.get();
        String username = censoAnuario.getUsername();
        if (!ValidacaoCampos.validaCampoPreenchido(username)) {
            return null;
        }
        String nomeExibicao = username;
        try {
            UsuarioTO usuario = usuarioClient.obterUsuarioLogin(username);
            if (ValidacaoCampos.validaCampoPreenchido(usuario) && ValidacaoCampos.validaCampoPreenchido(usuario.getNome())) {
                nomeExibicao = usuario.getNome();
            }
        } catch (Exception ignored) {
            // mantém o username como fallback
        }
        return new CensoAnuarioRecord(ano, cooperativaId, censoAnuario.getDataSubmissao(), nomeExibicao);
    }

    @Override
    public ImportacaoAnuarioResultadoTO processarImportacao(Integer cooperativaId, Integer ano) {
        java.util.Set<String> abasEsperadas = cooperativaAnuarioAbasInterfaceService.obterChavesAbasEsperadas(cooperativaId, ano);

        ValidacaoPrimeiroRegistroTO vprDados = quadroSocialService.validarQuadroSocial(cooperativaId, true);
        Integer situacaoDados = calcularSituacaoAba(vprDados);
        if (situacaoDados != null) {
            cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "DADOS_SOCIAIS", situacaoDados);
        }

        ValidacaoPrimeiroRegistroTO vprPortfolio = pessoaSegmProdServService.validarSegmentoProdutoServico(cooperativaId);
        Integer situacaoPortfolio = calcularSituacaoAba(vprPortfolio);
        if (situacaoPortfolio != null) {
            cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "PORTFOLIO", situacaoPortfolio);
        }

        ValidacaoPrimeiroRegistroTO vprContabil = cooperativaFatesService.validarPendencias(cooperativaId, ano);
        if (Boolean.TRUE.equals(desempenhoClient.verificarPendencia("CONTABIL_TRIBUTARIO", cooperativaId, ano))) {
            adicionarErroPendencia(vprContabil, "Há campos obrigatórios não preenchidos no Detalhamento contábil.");
        }
        try {
            marcarOpcionaisVaziosComoWarn(
                    cooperativaAnuarioAbasInterfaceService.obterListaAbaAnuarioDadosContabilTributario(ano, cooperativaId),
                    vprContabil, "Detalhamento contábil");
        } catch (Exception e) {
        }
        Integer situacaoContabil = calcularSituacaoAba(vprContabil);
        if (situacaoContabil != null) {
            cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "CONTABIL_TRIBUTARIO", situacaoContabil);
        }

        Integer situacaoNegocio = null;
        if (abasEsperadas.contains("NEGOCIO")) {
            ValidacaoPrimeiroRegistroTO vprNegocio = negocioExportacaoService.validarPendencias(cooperativaId, ano);
            for (String subgrupo : new String[]{"NEGOCIO_SETORIAIS", "NEGOCIO_INTERCOOPERACAO", "NEGOCIO_EXPORTACAO", "NEGOCIO_VENDAS_ONLINE"}) {
                if (Boolean.TRUE.equals(desempenhoClient.verificarPendencia(subgrupo, cooperativaId, ano))) {
                    adicionarErroPendencia(vprNegocio, "Há campos obrigatórios não preenchidos em Negócio (" + subgrupo + ").");
                }
            }
            try {
                marcarOpcionaisVaziosComoWarn(
                        cooperativaAnuarioAbasInterfaceService.obterListaAbaNegocios(ano, cooperativaId),
                        vprNegocio, "Negócio");
            } catch (Exception e) {
            }
            situacaoNegocio = calcularSituacaoAba(vprNegocio);
            if (situacaoNegocio != null) {
                cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "NEGOCIO", situacaoNegocio);
            }
        }

        Integer situacaoDadosComplementares = null;
        if (abasEsperadas.contains("DADOS_COMPLEMENTARES")) {
            cooperativaAnuarioAbasService.salvarAba(cooperativaId, ano, "DADOS_COMPLEMENTARES", 1);
            situacaoDadosComplementares = 1;
        }

        informarPreenchimento(ano, cooperativaId, false);

        boolean submetido = false;
        boolean todasOk = cooperativaAnuarioAbasService.todasAbasAprovadas(cooperativaId, ano, abasEsperadas);
        if (todasOk) {
            Optional<CensoAnuario> existente = censoAnuarioRepository.findByAnoAndCooperativaId(ano, cooperativaId);
            CensoAnuario censoAnuario = existente.orElseGet(CensoAnuario::new);
            censoAnuario.setAno(ano);
            censoAnuario.setCooperativa(new Cooperativa(cooperativaId));
            censoAnuario.setUsername(keycloakService.getUsername());
            censoAnuario.setDataSubmissao(LocalDateTime.now());
            censoAnuarioRepository.save(censoAnuario);
            if (existente.isEmpty()) {
                comunicarUnidadeEstadualSubmissaoAnuario(cooperativaId);
            }
            informarPreenchimento(ano, cooperativaId, true);
            submetido = true;
        }

        ImportacaoAnuarioResultadoTO resultado = new ImportacaoAnuarioResultadoTO();
        resultado.setSubmetido(submetido);
        resultado.setSituacaoDadosSociais(situacaoDados);
        resultado.setSituacaoPortfolio(situacaoPortfolio);
        resultado.setSituacaoContabilTributario(situacaoContabil);
        resultado.setSituacaoNegocio(situacaoNegocio);
        resultado.setSituacaoDadosComplementares(situacaoDadosComplementares);
        if (!submetido) {
            resultado.setMotivoNaoSubmissao(montarMotivoNaoSubmissao(abasEsperadas, resultado));
        }
        return resultado;
    }

    private String montarMotivoNaoSubmissao(java.util.Set<String> abasEsperadas, ImportacaoAnuarioResultadoTO resultado) {
        java.util.List<String> inconsistentes = new java.util.ArrayList<>();
        java.util.List<String> ausentes = new java.util.ArrayList<>();

        avaliarAba(abasEsperadas, "DADOS_SOCIAIS", "Dados Sociais", resultado.getSituacaoDadosSociais(), inconsistentes, ausentes);
        avaliarAba(abasEsperadas, "PORTFOLIO", "Portfólio", resultado.getSituacaoPortfolio(), inconsistentes, ausentes);
        avaliarAba(abasEsperadas, "CONTABIL_TRIBUTARIO", "Detalhamento contábil", resultado.getSituacaoContabilTributario(), inconsistentes, ausentes);
        avaliarAba(abasEsperadas, "NEGOCIO", "Negócio", resultado.getSituacaoNegocio(), inconsistentes, ausentes);
        avaliarAba(abasEsperadas, "DADOS_COMPLEMENTARES", "Dados Complementares", resultado.getSituacaoDadosComplementares(), inconsistentes, ausentes);

        if (inconsistentes.isEmpty() && ausentes.isEmpty()) {
            return "O anuário não foi submetido automaticamente.";
        }

        StringBuilder sb = new StringBuilder("O anuário não foi submetido automaticamente.");
        if (!inconsistentes.isEmpty()) {
            sb.append(" Abas com inconsistências: ").append(String.join(", ", inconsistentes)).append(".");
        }
        if (!ausentes.isEmpty()) {
            sb.append(" Abas obrigatórias não preenchidas: ").append(String.join(", ", ausentes)).append(".");
        }
        return sb.toString();
    }

    private void adicionarErroPendencia(ValidacaoPrimeiroRegistroTO vpr, String mensagem) {
        List<ServiceMessage> mensagens = vpr.getMensagens();
        if (mensagens == null) {
            mensagens = new ArrayList<>();
            vpr.setMensagens(mensagens);
        }
        mensagens.add(new ServiceMessage(MessageType.ERROR, mensagem));
    }

    private void marcarOpcionaisVaziosComoWarn(
            List<AbaDataInterface> paineis,
            ValidacaoPrimeiroRegistroTO vpr, String contexto) {
        if (paineis == null || paineis.isEmpty()) return;

        List<ServiceMessage> mensagens = vpr.getMensagens();
        if (mensagens == null) {
            mensagens = new ArrayList<>();
            vpr.setMensagens(mensagens);
        }

        for (var painel : paineis) {
            if (painel.getFields() == null) continue;
            for (var linha : painel.getFields()) {
                if (linha == null) continue;
                for (var campo : linha) {
                    if (campo == null || campo.isRequired()) continue;
                    String tipo = campo.getType();
                    if (tipo != null && (tipo.equals("divider") || tipo.equals("accordion") || tipo.equals("section"))) continue;
                    if (isValueVazio(campo.getValue())) {
                        String label = campo.getLabel() != null ? campo.getLabel() : campo.getId();
                        mensagens.add(new ServiceMessage(MessageType.WARN,
                                "<b>" + contexto + "</b>: campo opcional \"" + label + "\" não preenchido."));
                    }
                }
            }
        }
    }

    private boolean isValueVazio(Object value) {
        if (value == null) return true;
        if (value instanceof String s) return s.trim().isEmpty();
        if (value instanceof java.util.Map<?, ?> m) {
            Object selected = m.get("selected");
            return selected == null || (selected instanceof String ss && ss.trim().isEmpty());
        }
        return false;
    }

    private void avaliarAba(java.util.Set<String> abasEsperadas, String chave, String nomeUsuario, Integer situacao,
                            java.util.List<String> inconsistentes, java.util.List<String> ausentes) {
        if (!abasEsperadas.contains(chave)) {
            return;
        }
        if (situacao == null) {
            ausentes.add(nomeUsuario);
        } else if (situacao < 0) {
            inconsistentes.add(nomeUsuario);
        }
    }

    private void verificaPrazoEstadualENacional(Integer idCooperativa, Integer ano, boolean isSubmit) {

        // O ano do Anuário sempre é anterior ao ano atual/parametro
        Integer anoParametro = ano + 1;

        // Buscar a UF da cooperativa
        Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);


        ControleAnuarioUf controleAnuarioUf = controleAnuarioUfService.buscarControleExistente(cooperativa.getPessoaJuridica().getUfSigla());
        // Verificar controle da submissão
        if (!keycloakService.isTipoEntidadeNacional() && Objects.equals(controleAnuarioUf.getHabilitarPreenchimentoAnuario(), Boolean.FALSE)) {
            throw new RegraNegocioException("A submissão do anuário está desabilitada pelo gestor nacional");
        }

        // Buscar a parametrização dessa UF
        // se não existir a parametrização buscar a parametrização nacional
        List<PeriodoAtualizacao> listaPeriodoAtualizacao = periodoAtualizacaoService
                .buscaPeriodoAtualizacaoPorRamoUfOuUnAno(cooperativa.getPessoaJuridica().getUfSigla(),
                        cooperativa.getPessoaJuridica().getRamo().getId(), anoParametro);

        if (!ValidacaoCampos.validaCampoPreenchido(listaPeriodoAtualizacao)) {
            throw new RegraNegocioException("Não há parâmetro cadastrado para envio do Anuário.");
        }

        // De acordo com a parametrização de ele pode atualizar ou não o senso anuario;
        Predicate<PeriodoAtualizacao> filtroUf = periodoAtualizacao -> Objects.equals(periodoAtualizacao.getUf(),
                cooperativa.getPessoaJuridica().getUfSigla());

        PeriodoAtualizacao periodoAtualizacao = listaPeriodoAtualizacao.stream().filter(filtroUf).findFirst().orElse(listaPeriodoAtualizacao.get(0));

        if (Objects.isNull(periodoAtualizacao.getInicioAttAnuario()) || Objects.isNull(periodoAtualizacao.getFimAttAnuario())) {

            periodoAtualizacao = periodoAtualizacaoService
                    .buscaPeriodoAtualizacaoPorRamoUfOuUnAno(
                            null,
                            cooperativa.getPessoaJuridica().getRamo().getId(),
                            anoParametro
                    )
                    .stream()
                    .findFirst()
                    .orElseThrow(() -> new RegraNegocioException(
                            "Não há parâmetro nacional cadastrado para envio do Anuário."
                    ));
        }

        if (Objects.isNull(periodoAtualizacao.getInicioAttAnuario()) || Objects.isNull(periodoAtualizacao.getFimAttAnuario())) {
            throw new RegraNegocioException("O período de envio do Anuário não está configurado corretamente.");
        }

        LocalDate dataHoje = LocalDate.now();
        LocalDate dataInicio = DataUtil.converteDateToLocalDate(periodoAtualizacao.getInicioAttAnuario());
        LocalDate dataFim = DataUtil.converteDateToLocalDate(periodoAtualizacao.getFimAttAnuario());

        boolean foraDoPeriodo = dataHoje.isBefore(dataInicio) || dataHoje.isAfter(dataFim);

        if (foraDoPeriodo) {
            String operacao = isSubmit ? "submetido" : "alterado";
            throw new RegraNegocioException("O Anuário não pode ser " + operacao + " nesta data.");
        }

    }


}
