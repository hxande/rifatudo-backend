package br.coop.somoscooperativismo.registro.api.v1.fates;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Embeddable
public class CooperativaFatesFinalidadeId implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "SQ_COOPERATIVA_FATES")
    private Integer cooperativaFatesId;

    @Column(name = "SQ_COOPERATIVA_FATES_FINALIDADE")
    private Integer finalidadeId;
}