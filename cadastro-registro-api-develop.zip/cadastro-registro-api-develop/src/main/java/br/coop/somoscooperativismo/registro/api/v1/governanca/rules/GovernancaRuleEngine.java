package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Motor de regras de governança (Composite). Compõe todas as
 * {@link GovernancaRule} disponíveis e devolve o resultado acumulado para um
 * dado {@link GovernancaContext}. É o <b>ponto único de verdade</b> consumido
 * tanto pelo fluxo de Registro quanto pelo de Manutenção — eliminando os ramos
 * {@code isManutencao} divergentes (FR-002/FR-020, research D2).
 *
 * <p>Spring injeta a lista de regras (todas as beans {@link GovernancaRule}),
 * de modo que adicionar uma nova regra é apenas criar um novo {@code @Component}.</p>
 */
@Component
public class GovernancaRuleEngine {

    private final List<GovernancaRule> regras;

    public GovernancaRuleEngine(List<GovernancaRule> regras) {
        this.regras = regras;
    }

    /**
     * Avalia o contexto contra todas as regras, acumulando as violações.
     * Mesmo contexto ⇒ mesmo resultado, independentemente do fluxo de origem
     * (SC-001/SC-002).
     */
    public ResultadoValidacaoGovernanca avaliar(GovernancaContext contexto) {
        ResultadoValidacaoGovernanca resultado = new ResultadoValidacaoGovernanca();
        boolean liquidacao = contexto.getSituacao() != null && contexto.getSituacao().isLiquidacao();
        for (GovernancaRule regra : regras) {
            if (liquidacao && !(regra instanceof MinimoMembrosRule)) {
                continue;
            }
            resultado.adicionarTodas(regra.avaliar(contexto));
        }
        return resultado;
    }

    /** Quantidade de regras compostas (diagnóstico/auditoria — SC-002). */
    public int quantidadeRegras() {
        return regras.size();
    }
}
