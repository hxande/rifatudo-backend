package br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to;

public record DisparoEmailEstadualTO(Integer id, Integer idDisparoEmail, String processoDescricao, String emailDescricao, String emailTexto, Boolean ativo, String uf) {
	
}
