package br.coop.somoscooperativismo.registro.api.v1.anuario;

import java.util.Iterator;
import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import br.coop.somoscooperativismo.registro.api.v1.anuario.filtros.AnuarioFiltroTO;

/**
 * 
 * @author brunno.stefanini
 *
 */
public class AnuarioTORepositoryImpl {

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Realiza a filtragem do anuário sem páginação.
	 * 
	 * @param anuarioFiltroTO FiltroTO de pesquisa.
	 * @return Lista de anuários.
	 */
	@SuppressWarnings("unchecked")
	public List<AnuarioTO> filtrarAnuario(AnuarioFiltroTO anuarioFiltroTO) {
		String select = "SELECT ANUARIO.SQ_COOPERATIVA_ANUARIO AS SQ_COOPERATIVA_ANUARIO, "
				+ "		   CP.SQ_PESSOA AS SQ_COOPERATIVA, ANUARIO.NR_ANO AS NR_ANO, "
				+ "			  CP.TX_CNPJ AS TX_CNPJ, CP.TX_RAZAO_SOCIAL AS TX_RAZAO_SOCIAL, "
				+ "			  CP.TX_NOME_FANTASIA as TX_NOME_FANTASIA, CP.TX_SIGLA_ESTADO as TX_UF_SIGLA, CP.SQ_RAMO as SQ_RAMO, CP.TX_RAMO as TX_RAMO, "
				+ "			  CP.SQ_SITUACAO_COOPERATIVA as SQ_SITUACAO_COOPERATIVA, "
				+ "			  CP.TX_SITUACAO_COOPERATIVA as TX_SITUACAO_COOPERATIVA, ANUARIO.VL_ATIVO_TOTAL as VL_ATIVO_TOTAL, "
				+ "			  ANUARIO.VL_ATIVO_IMOBILIZADO as VL_ATIVO_IMOBILIZADO, ANUARIO.VL_PATRIMONIO_LIQUIDO as VL_PATRIMONIO_LIQUIDO, "
				+ "			  ANUARIO.VL_CAPITAL_SOCIAL as VL_CAPITAL_SOCIAL, ANUARIO.VL_SOBRAS_PERDAS_EXERCICIO as VL_SOBRAS_PERDAS_EXERCICIO, "
				+ "			  ANUARIO.VL_INGRESSOS_RECEITAS_BRUTAS as VL_INGRESSOS_RECEITAS_BRUTAS, "
				+ "			  ANUARIO.VL_TRIBUTOS as VL_TRIBUTOS, ANUARIO.VL_DESPESAS_PESSOAL as VL_DESPESAS_PESSOAL "
				+ "FROM VW_COOPERATIVAS_MATRIZES_REGISTRADAS CP WITH (NOLOCK) LEFT JOIN COOPERATIVA_ANUARIO ANUARIO WITH(NOLOCK) ON CP.SQ_PESSOA = ANUARIO.SQ_COOPERATIVA "
				+ "		   AND (ANUARIO.NR_ANO = :ano)" + "WHERE  CP.SQ_SITUACAO_COOPERATIVA IS NOT NULL :condicoes";

		// Monta as condições de acordo com os filtros.
		String condicoes = "";
		if (anuarioFiltroTO.getCnpj() != null && anuarioFiltroTO.getCnpj().length() > 0)
			condicoes += " AND CP.TX_CNPJ = '" + anuarioFiltroTO.getCnpj() + "'";
		if (anuarioFiltroTO.getNomeFantasia() != null && anuarioFiltroTO.getNomeFantasia().length() > 0)
			condicoes += " AND CP.TX_NOME_FANTASIA LIKE '" + anuarioFiltroTO.getNomeFantasia().replaceAll(" ", "%")
					+ "%'";
		if (anuarioFiltroTO.getSituacaoCooperativa() != null && anuarioFiltroTO.getSituacaoCooperativa().length() > 0)
			condicoes += " AND TX_SITUACAO_COOPERATIVA = '" + anuarioFiltroTO.getSituacaoCooperativa() + "'";
		if (anuarioFiltroTO.getUf() != null && anuarioFiltroTO.getUf().length() > 0)
			condicoes += " AND CP.TX_SIGLA_ESTADO = '" + anuarioFiltroTO.getUf() + "'";
		if (anuarioFiltroTO.getAnuario() != null && anuarioFiltroTO.getAnuario().length() > 0)
			condicoes += " AND ANUARIO.NR_ANO IS "
					+ (anuarioFiltroTO.getAnuario().equals("PREENCHIDO") ? "NOT NULL" : "NULL");

		if (condicoes.isEmpty())
			condicoes += " AND 1=1";

		// Adiciona as condições e a ordenação à Query.
		StringBuilder sqlNativo = new StringBuilder(
				select.replaceAll(":ano", anuarioFiltroTO.getAno() + "").replaceAll(":condicoes", condicoes));
		sqlNativo = sqlNativo.append(" ORDER BY CP.TX_NOME_FANTASIA");

		Query query = entityManager.createNativeQuery(sqlNativo.toString(), AnuarioTO.class);

		select = null;
		condicoes = null;
		sqlNativo = null;

		return query.getResultList();
	}

	/**
	 * Realiza a filtragem do anuário páginado, de acordo com o filtro indicado.
	 * 
	 * @param anuarioFiltroTO FiltroTO de pesquisa.
	 * @param pageable      Paginador.
	 * @return Página de anuários.
	 */
	public Page<AnuarioTO> filtrarAnuarioPaginado(AnuarioFiltroTO anuarioFiltroTO, Pageable pageable) {
		String select = "SELECT ANUARIO.SQ_COOPERATIVA_ANUARIO AS SQ_COOPERATIVA_ANUARIO, "
				+ "		   CP.SQ_PESSOA AS SQ_COOPERATIVA, ANUARIO.NR_ANO AS NR_ANO, "
				+ "			  CP.TX_CNPJ AS TX_CNPJ, CP.TX_RAZAO_SOCIAL AS TX_RAZAO_SOCIAL, "
				+ "			  CP.TX_NOME_FANTASIA as TX_NOME_FANTASIA, CP.TX_SIGLA_ESTADO as TX_UF_SIGLA, CP.SQ_RAMO as SQ_RAMO, CP.TX_RAMO as TX_RAMO, "
				+ "			  CP.SQ_SITUACAO_COOPERATIVA as SQ_SITUACAO_COOPERATIVA, "
				+ "			  CP.TX_SITUACAO_COOPERATIVA as TX_SITUACAO_COOPERATIVA, ANUARIO.VL_ATIVO_TOTAL as VL_ATIVO_TOTAL, "
				+ "			  ANUARIO.VL_ATIVO_IMOBILIZADO as VL_ATIVO_IMOBILIZADO, ANUARIO.VL_PATRIMONIO_LIQUIDO as VL_PATRIMONIO_LIQUIDO, "
				+ "			  ANUARIO.VL_CAPITAL_SOCIAL as VL_CAPITAL_SOCIAL, ANUARIO.VL_SOBRAS_PERDAS_EXERCICIO as VL_SOBRAS_PERDAS_EXERCICIO, "
				+ "			  ANUARIO.VL_INGRESSOS_RECEITAS_BRUTAS as VL_INGRESSOS_RECEITAS_BRUTAS, "
				+ "			  ANUARIO.VL_TRIBUTOS as VL_TRIBUTOS, ANUARIO.VL_DESPESAS_PESSOAL as VL_DESPESAS_PESSOAL "
				+ "FROM VW_COOPERATIVAS_MATRIZES_REGISTRADAS CP WITH (NOLOCK) LEFT JOIN COOPERATIVA_ANUARIO ANUARIO ON CP.SQ_PESSOA = ANUARIO.SQ_COOPERATIVA "
				+ "		   AND (ANUARIO.NR_ANO = :ano)" + "WHERE  CP.SQ_SITUACAO_COOPERATIVA IS NOT NULL :condicoes";
		String selectCount = "SELECT COUNT(*) "
				+ "FROM VW_COOPERATIVAS_MATRIZES_REGISTRADAS CP WITH (NOLOCK) LEFT JOIN COOPERATIVA_ANUARIO ANUARIO ON CP.SQ_PESSOA = ANUARIO.SQ_COOPERATIVA "
				+ "		   AND (ANUARIO.NR_ANO = :ano)" + "WHERE  CP.SQ_SITUACAO_COOPERATIVA IS NOT NULL :condicoes";

		// Definição das condições de acordo com o filtro.
		String condicoes = "";
		if (anuarioFiltroTO.getCnpj() != null && anuarioFiltroTO.getCnpj().length() > 0)
			condicoes += " AND CP.TX_CNPJ = '" + anuarioFiltroTO.getCnpj() + "'";
		if (anuarioFiltroTO.getNomeFantasia() != null && anuarioFiltroTO.getNomeFantasia().length() > 0)
			condicoes += " AND CP.TX_NOME_FANTASIA LIKE '" + anuarioFiltroTO.getNomeFantasia().replaceAll(" ", "%") + "%'";
		if (anuarioFiltroTO.getSituacaoCooperativa() != null && anuarioFiltroTO.getSituacaoCooperativa().length() > 0)
			condicoes += " AND TX_SITUACAO_COOPERATIVA = '" + anuarioFiltroTO.getSituacaoCooperativa() + "'";
		if (anuarioFiltroTO.getUf() != null && anuarioFiltroTO.getUf().length() > 0)
			condicoes += " AND CP.TX_SIGLA_ESTADO = '" + anuarioFiltroTO.getUf() + "'";
		if (anuarioFiltroTO.getAnuario() != null && anuarioFiltroTO.getAnuario().length() > 0)
			condicoes += " AND ANUARIO.NR_ANO IS "
					+ (anuarioFiltroTO.getAnuario().equals("PREENCHIDO") ? "NOT NULL" : "NULL");

		if (condicoes.isEmpty())
			condicoes += " AND 1=1";

		// Adiciona as condições e paginação à query.
		StringBuilder sqlNativo = new StringBuilder(
				select.replaceAll(":ano", anuarioFiltroTO.getAno() + "").replaceAll(":condicoes", condicoes));
		StringBuilder sqlNativoCount = new StringBuilder(
				selectCount.replaceAll(":ano", anuarioFiltroTO.getAno() + "").replaceAll(":condicoes", condicoes));
		sqlNativo.append(ordenar(pageable));

		// Executa a consulta e monta os objetos.
		Query query = entityManager.createNativeQuery(sqlNativo.toString(), AnuarioTO.class);
		restricoesDePaginacao(query, pageable);
		List<AnuarioTO> anuarios = query.getResultList();

		// Executa a consulta de contagem dos registros.
		Query queryCount = entityManager.createNativeQuery(sqlNativoCount.toString());
		List<Integer> resultado = queryCount.getResultList();
		int resultados = (resultado == null || resultado.size() == 0 ? 0 : resultado.get(0));

		select = null;
		selectCount = null;
		condicoes = null;
		sqlNativo = null;
		sqlNativoCount = null;

		return new PageImpl<>(anuarios, pageable, resultados);
	}

	/**
	 * Retorna uma String que representa as condições de ordenação, baseada no
	 * paginador informado.
	 * 
	 * @param pageable Página.
	 * @return String com as condições de ordenação.
	 */
	private String ordenar(Pageable pageable) {
		Iterator<Sort.Order> iterator = pageable.getSort().iterator();
		StringBuilder orderSql = new StringBuilder("");
		int i = 0;
		while (iterator.hasNext()) {
			Sort.Order order = iterator.next();
			if (order != null) {
				String propriedade = order.getProperty();
				String direcao = order.getDirection().toString();
				orderSql.append(
						i == 0 ? " ORDER BY " + propriedade + " " + direcao : ", " + propriedade + " " + direcao);
			}
			i++;
		}

		iterator = null;

		return orderSql.toString();
	}

	/**
	 * Adiciona as restrições de paginação à query.
	 * 
	 * @param query    Query.
	 * @param pageable Paginador.
	 */
	private void restricoesDePaginacao(Query query, Pageable pageable) {
		int paginaAtual = pageable.getPageNumber();
		int totalRegistroPagina = pageable.getPageSize();
		int primeiroRegistroPagina = paginaAtual * totalRegistroPagina;
		query.setFirstResult(primeiroRegistroPagina);
		query.setMaxResults(totalRegistroPagina);
	}

}
