package br.coop.somoscooperativismo.registro.api.v1.cnae;

import br.coop.somoscooperativismo.registro.api.v1.cnae.entidade.Cnae;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CnaeRepository extends JpaRepository<Cnae, String>{

    List<Cnae> findAllByAtivoTrueOrderByIdAsc();

    Page<Cnae> findByIdContainingAndDescricaoContaining(String id,
                                                                                  String descricao,
                                                                                  Pageable pageable);
}
