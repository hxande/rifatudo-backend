package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name  = "CRITERIO_ASSOCIACAO_COOPERATIVA")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class CriterioAssociacaoCooperativa {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_CRITERIO_ASSOCIACAO_COOPERATIVA")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "SQ_COOPERATIVA")
    private Cooperativa cooperativa;

    @ManyToOne
    @JoinColumn(name = "SQ_CRITERIO_ASSOCIACAO")
    private CriterioAssociacao criterioAssociacao;
    
    @Column(name = "IN_ATIVO")
    private Boolean ativo;

}
