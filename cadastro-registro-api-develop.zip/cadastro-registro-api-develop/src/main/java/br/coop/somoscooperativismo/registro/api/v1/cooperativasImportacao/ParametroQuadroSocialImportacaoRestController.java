package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.parametroQuadroSocial.entidade.ParametroQuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.parametroQuadroSocial.ParametroQuadroSocialService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/parametros-quadro-social")
public class ParametroQuadroSocialImportacaoRestController {

    private final ParametroQuadroSocialService parametroQuadroSocialService;

    @GetMapping("/ativos")
    public ResponseEntity<List<ParametroQuadroSocial>> getAllAtivos() {
        return ResponseEntity.ok(parametroQuadroSocialService.getAllAtivos());
    }
}
