package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.FiltroTO;

public interface CooperativaRepositoryCustom {

	List<Cooperativa> filtrarNaoPaginado(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro) throws IllegalAccessException;
	Page<Cooperativa> consultaCooperativa(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro, Pageable pageable);
	List<Cooperativa> consultaCooperativaNaoPaginado(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro);
	List<CooperativaBasicaTO> buscaPorRazaoSocial(String razaoSocial);
	List<CooperativaCnpjTO> buscaCooperativaTOporRamo(Integer idRamo, Integer anoAtual);
	Page<CooperativaListagemTO> filtrarCooperativaListagemPaginado(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro,
			Pageable pageable);
	List<CooperativaListagemProcessoRegistroTO> filtrarCooperativaListagemProcessoRegistroExcel(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro);
	List<CooperativaListagemProcessoRegistroTO> filtrarCooperativaListagemProcessoRegistroAcompanhamentoExcel(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro);

	Object getNextValSequenciaNumeroRegistroOcb();
	Integer quatidadeCooperativasNaoRegistradasAguardandoPorProcessoMicroUnidadeEstadual(String uf);
	Integer quatidadeCooperativasRegistradasAguardandoPorProcessoMicroUnidadeEstadual(String uf);
	Integer buscaRegistroAtualizacaoNaoVisualizada(String uf);
	Integer buscaAtualizacaoNaoVisualizadaRegistrada(String uf);
	Integer buscaRegistroAtualizacaoNacionalNaoVisualizada();
	Integer buscaAtualizacaoNacionalNaoVisualizadaRegistrada();
	List<CooperativaAnuarioTO> filtrarCooperativasAnuarioListagemExcel(CooperativaFiltroTO cooperativaFiltro, FiltroTO filtro);
	String recuperaUsuarioAuditoria(Integer idCooperativa);

}
