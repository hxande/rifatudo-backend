package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums;

public enum NomeQuadroEnum {
    QUANTIDADE_COOPERADOS,
    COOPERADOS_ADICIONAIS,
    EMPREGADOS_ADICIONAIS,
    DADOS_COMPLEMENTARES,
    QUANTIDADE_EMPREGADOS,
    DESTINACAO_FATES,
    NEGOCIO_EXPORTACAO
}
