package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import lombok.Data;

@Data
public class CriterioAssociacaoCooperativaChaveCompostaTO {
    private Integer cooperativaId;
    private Integer criterioAssociacaoId;

    public CriterioAssociacaoCooperativaChaveCompostaTO(Integer cooperativaId, Integer criterioAssociacaoId) {
        this.cooperativaId = cooperativaId;
        this.criterioAssociacaoId = criterioAssociacaoId;
    }

}
