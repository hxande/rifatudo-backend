package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

public enum AnuarioEnum {
	
	PREENCHIDO,
	NAO_PREENCHIDO;

}
