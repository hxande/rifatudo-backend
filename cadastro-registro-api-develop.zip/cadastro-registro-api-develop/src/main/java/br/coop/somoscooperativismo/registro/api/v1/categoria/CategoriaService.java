package br.coop.somoscooperativismo.registro.api.v1.categoria;

import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Service
public class CategoriaService {
	
	public static final String NAO_ENCONTRADO = "categoria.naoEncontrado";
	
	private final CategoriaRepository categoriaRepository;
	
	private final MessagesService messages;
	
	
	public CategoriaService(CategoriaRepository categoriaRepository, MessagesService messages) {
		this.categoriaRepository = categoriaRepository;
		this.messages = messages;
	}

	public List<Categoria> getCategorias() {
		return categoriaRepository.findAll();
	}

	public Categoria getCategoria(Integer id) {
		Optional<Categoria> categoria = categoriaRepository.findById(id);
		if(categoria.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + id, HttpStatus.NOT_FOUND);
		}
		return categoria.get();
	}
	
	public List<Categoria> listAtivos(Boolean ativo){
		return categoriaRepository.listAtivos(ativo);
	}

	public Page<Categoria> filtra(String descricao, Integer minimoCooperativa, Boolean ativo, Pageable pageable) {
		return categoriaRepository.filtra(descricao, minimoCooperativa, ativo, pageable);
	}

	@Transactional(readOnly = true)
	public List<Categoria> getAllAtivas() {
		return listAtivos(true);
	}
}
