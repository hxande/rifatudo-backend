package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaRepository;
import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacao;
import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacaoCooperativa;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Component
public class CriterioAssociacaoCooperativaConverter {

    private final CooperativaRepository cooperativaRepository;

    private final CriterioAssociacaoRespository criterioAssociacaoRespository;

    public CriterioAssociacaoCooperativaConverter(CooperativaRepository cooperativaRepository, CriterioAssociacaoRespository criterioAssociacaoRespository) {
        this.cooperativaRepository = cooperativaRepository;
        this.criterioAssociacaoRespository = criterioAssociacaoRespository;
    }

    public List<CriterioAssociacaoCooperativa> toEntityList(List<CriterioAssociacaoCooperativaTO> dtoList) {
        List<CriterioAssociacaoCooperativa> entityList = new ArrayList<>();
        for (CriterioAssociacaoCooperativaTO dto : dtoList) {
            CriterioAssociacaoCooperativa entity = toEntity(dto);
            entityList.add(entity);
        }
        return entityList;
    }

    public CriterioAssociacaoCooperativaTO toDTO(CriterioAssociacaoCooperativa entity) {
        CriterioAssociacaoCooperativaTO dto = new CriterioAssociacaoCooperativaTO();
        dto.setId(entity.getId());
        dto.setSqCooperativa(entity.getCooperativa().getId());
        dto.setSqCriterioAssociacao(entity.getCriterioAssociacao().getId());
        return dto;
    }


    public List<CriterioAssociacaoCooperativaTO> toDTOList(List<CriterioAssociacaoCooperativa> entityList) {
        List<CriterioAssociacaoCooperativaTO> dtoList = new ArrayList<>();
        for (CriterioAssociacaoCooperativa entity : entityList) {
            CriterioAssociacaoCooperativaTO dto = toDTO(entity);
            dtoList.add(dto);
        }
        return dtoList;
    }


    public List<CriterioAssociacaoCooperativaResponseTO> toResponseDTOList(List<CriterioAssociacaoCooperativa> entityList) {
        List<CriterioAssociacaoCooperativaResponseTO> responseDTOList = new ArrayList<>();

        for (CriterioAssociacaoCooperativa entity : entityList) {
            CriterioAssociacaoCooperativaResponseTO responseDTO = toResponseDTO(entity);
            responseDTOList.add(responseDTO);
        }

        return responseDTOList;
    }

    public CriterioAssociacaoCooperativaResponseTO toResponseDTO(CriterioAssociacaoCooperativa entity) {
        CriterioAssociacaoCooperativaResponseTO responseDTO = new CriterioAssociacaoCooperativaResponseTO();

        responseDTO.setId(entity.getId());
        responseDTO.setCriterioAssociacaoCooperativaAtivo(entity.getAtivo());

        if (entity.getCooperativa() != null) {
            responseDTO.setSqCooperativa(entity.getCooperativa().getId());
        }

        if (entity.getCriterioAssociacao() != null) {
            responseDTO.setRamoId(entity.getCriterioAssociacao().getRamo().getId());
            responseDTO.setNomeCriterioAssociacao(entity.getCriterioAssociacao().getDescricao());
            responseDTO.setSqCriterioAssociacao(entity.getCriterioAssociacao().getId());
            responseDTO.setCriterioAssociacaoAtivo(entity.getCriterioAssociacao().getAtivo());
            responseDTO.setCriterioAssociacaoExcluido(entity.getCriterioAssociacao().getExcluido());
        }

        return responseDTO;
    }


    public CriterioAssociacaoCooperativa toEntity(CriterioAssociacaoCooperativaTO dto) {
        CriterioAssociacaoCooperativa entity = new CriterioAssociacaoCooperativa();
        entity.setId(dto.getId());
        Optional<Cooperativa> cooperativaOptional = cooperativaRepository.findById(dto.getSqCooperativa());
        Cooperativa cooperativa = cooperativaOptional.orElseThrow(() -> new IllegalArgumentException("Cooperativa não encontrada"));
        Optional<CriterioAssociacao> criterioAssociacaoOptional = criterioAssociacaoRespository.findById(dto.getSqCriterioAssociacao());
        CriterioAssociacao criterioAssociacao = criterioAssociacaoOptional.orElseThrow(() -> new IllegalArgumentException("CriterioAssociacao não encontrado"));
        entity.setCooperativa(cooperativa);
        entity.setCriterioAssociacao(criterioAssociacao);
        return entity;
    }
}
