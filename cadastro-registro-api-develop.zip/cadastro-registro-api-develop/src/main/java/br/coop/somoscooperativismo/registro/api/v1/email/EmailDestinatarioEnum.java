package br.coop.somoscooperativismo.registro.api.v1.email;

/**
 * Enumeração que indica o destinatario de e-mails.
 * @author brunno.stefanini
 */
public enum EmailDestinatarioEnum {
	
	COOPERATIVA, UNIDADE_ESTADUAL, UNIDADE_NACIONAL, COOPERATIVA_E_ORGANIZACAO_ESTADUAL

}
