package br.coop.somoscooperativismo.registro.api.v1.documentocliente;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentoClient {
	public static final String MENSAGENS = "mensagens";
	public static final String PROBLEMAS_DOCUMENTO = "documento.problemas";
	
	@Value("${documento_service_url}")
	private String documentoServiceUrl;

	@Autowired
	private RestTemplate keycloakRestTemplate;

	@Autowired
	private MessagesService messages;

	@SuppressWarnings({ "rawtypes" })
	public ValidacaoPrimeiroRegistroTO validarDocumentos(Integer idPessoaJuridica, boolean considerarCiclo) {
		String urlValidarDocumento = "%s/api/v1/pessoadocumento/validarDocumentos/%s?considerarCiclo=%s".formatted(documentoServiceUrl, idPessoaJuridica, considerarCiclo);
		LinkedHashMap retorno = keycloakRestTemplate.getForObject(urlValidarDocumento, LinkedHashMap.class);
		
		ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Documentos");
		if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof LinkedHashMap){
			
			LinkedHashMap dados = (LinkedHashMap) retorno.get("data");
			if(dados != null){
				validaDados(dados, vpr);
				
			}
			
		}

		retorno = null;

		return vpr;
	}

	public ValidacaoPrimeiroRegistroTO validarDocumentosManutencao(Integer idPessoaJuridica) {
		String urlValidarDocumento = "%s/api/v1/pessoadocumento/validarDocumentos/manutencao/%s".formatted(documentoServiceUrl, idPessoaJuridica);
		LinkedHashMap retorno = keycloakRestTemplate.getForObject(urlValidarDocumento, LinkedHashMap.class);

		ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Documentos");
		if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof LinkedHashMap){

			LinkedHashMap dados = (LinkedHashMap) retorno.get("data");
			if(dados != null){
				validaDados(dados, vpr);

			}

		}

		retorno = null;

		return vpr;
	}

    public boolean atualizaDocCicloAtual(Integer idPessoa, Integer anoCiclo) {
        String documento = "%s/api/v1/pessoadocumento/atualiza-ano/%s/%s".formatted(documentoServiceUrl, anoCiclo, idPessoa);

        try {
            LinkedHashMap retorno = keycloakRestTemplate.getForObject(documento, LinkedHashMap.class);
            if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof LinkedHashMap){
                LinkedHashMap dados = (LinkedHashMap) retorno.get("data");
                if(dados != null){
                    return true;
                }
            }
        }catch (Exception e) {
            throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
        }
        return false;
    }

	@SuppressWarnings("rawtypes")
	public boolean aprovaDocumentacao(Integer idPessoa, Aprovacao aprovacao) {
		String documento = "%s/api/v1/aprovacao/aprovar-documentacao/%s".formatted(documentoServiceUrl, idPessoa);

		try {
			LinkedHashMap retorno = keycloakRestTemplate.postForObject(documento, aprovacao, LinkedHashMap.class);
			if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof LinkedHashMap){
				LinkedHashMap dados = (LinkedHashMap) retorno.get("data");
				if(dados != null){
					return true;
				}
			}
		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return false;
	}

	public boolean existeEsseDocumento(Integer idDocumento) {
		String documento = "%s/api/v1/documento/%s".formatted(documentoServiceUrl, idDocumento);

		try {
			LinkedHashMap retorno = keycloakRestTemplate.getForObject(documento, LinkedHashMap.class);
			if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof LinkedHashMap){
				LinkedHashMap dados = (LinkedHashMap) retorno.get("data");
				if(dados != null){
					return true;
				}
			}
		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return false;
	}

	@SuppressWarnings("rawtypes")
	public List<Integer> obterDocumentosPJ() {
		String documento = "%s/api/v1/documento/buscaAtivos/true/PJ".formatted(documentoServiceUrl);
		List<Integer> documentos = new ArrayList<>();

		try {
			LinkedHashMap retorno = keycloakRestTemplate.getForObject(documento, LinkedHashMap.class);
			if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof ArrayList){
				ArrayList dados = (ArrayList) retorno.get("data");
				if(dados != null){
					LinkedHashMap reg;
					for (int i = 0; i < dados.size(); i++) {
						reg = (LinkedHashMap) dados.get(i);
						if(reg.get("obrigatorioPreCadastro") != null && (Boolean) reg.get("obrigatorioPreCadastro")) {
							documentos.add((Integer)reg.get("id"));
						}
					}
				}
			}
		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return documentos;
	}

	public List<Integer> obterDocumentosPJManutencaoAtivos(String idCoop) {
		String documentoUrl = "%s/api/v1/manutencao-documento/buscaAtivos/PJ/%s".formatted(documentoServiceUrl, idCoop);
		List<Integer> documentos = new ArrayList<>();

		try {
			ParameterizedTypeReference<List<DocumentoTO>> listaDocsParam = new  ParameterizedTypeReference<List<DocumentoTO>>() {};
			ResponseEntity<List<DocumentoTO>> responseEntity  = keycloakRestTemplate.exchange(documentoUrl, HttpMethod.GET, null, listaDocsParam);
			List<DocumentoTO> docs = responseEntity.getBody();
			if (docs != null) {
				documentos = docs.stream().map(DocumentoTO::getId).collect(Collectors.toList());
			}

		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return documentos;
	}

	public List<Integer> obterDocumentosPJAtivos(String idCoop) {
		String documentoUrl = "%s/api/v1/documento/buscaAtivos/PJ/%s".formatted(documentoServiceUrl, idCoop);
		List<Integer> documentos = new ArrayList<>();

		try {
			ParameterizedTypeReference<List<DocumentoTO>> listaDocsParam = new  ParameterizedTypeReference<List<DocumentoTO>>() {};
			ResponseEntity<List<DocumentoTO>> responseEntity  = keycloakRestTemplate.exchange(documentoUrl, HttpMethod.GET, null, listaDocsParam);
			List<DocumentoTO> docs = responseEntity.getBody();
			if (docs != null) {
				documentos = docs.stream().map(DocumentoTO::getId).collect(Collectors.toList());
			}

		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return documentos;
	}

	public List<Integer> obterDocumentosPJManutencao() {
		String documento = "%s/api/v1/documento/buscaAtivos/true/PJ".formatted(documentoServiceUrl);
		List<Integer> documentos = new ArrayList<>();

		try {
			LinkedHashMap retorno = keycloakRestTemplate.getForObject(documento, LinkedHashMap.class);
			if(retorno != null && retorno.containsKey("data") && retorno.get("data") instanceof ArrayList){
				ArrayList dados = (ArrayList) retorno.get("data");
				if(dados != null){
					LinkedHashMap reg;
					for (int i = 0; i < dados.size(); i++) {
						reg = (LinkedHashMap) dados.get(i);
						if(reg.get("obrigatorioPosCadastro") != null && (Boolean) reg.get("obrigatorioPosCadastro")) {
							documentos.add((Integer)reg.get("id"));
						}
					}
				}
			}
		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}

		documento = null;

		return documentos;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void validaDados(LinkedHashMap dados, ValidacaoPrimeiroRegistroTO vpr) {
		if(dados.containsKey("validado")){
			vpr.setValidado((Boolean) dados.get("validado"));
		}
		if(dados.containsKey(MENSAGENS) && dados.get(MENSAGENS) instanceof ArrayList){
			List<LinkedHashMap> mensagens = (List<LinkedHashMap>) dados.get(MENSAGENS);

			if(mensagens != null && !mensagens.isEmpty()){
				vpr.setMensagens(new ArrayList<ServiceMessage>());

				mensagens.forEach(mens -> {
					if(mens.containsKey("type") && mens.containsKey("message")){
						vpr.getMensagens().add(new ServiceMessage(MessageType.valueOf((String)mens.get("type")), (String) mens.get("message")));
					}
				});
			}
		}

	}

	public void atualizarExcluindoAprovacao(Integer idAprovacao) {
        String url = "%s/api/v1/pessoadocumento/atualizaExcluindoAprovacao?idAprovacao=%s".formatted(documentoServiceUrl, idAprovacao);
        try {
        	keycloakRestTemplate.put(url, null);
		} catch(HttpClientErrorException e) {
			throw new RegraNegocioException("Não foi possível excluir a aprovação!",e);
		}
    }

	public void salvarDocumentacao(String documentacaoJson) {
		String url = "%s/api/v1/documento/salvarDocumentacao".formatted(documentoServiceUrl);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> entity = new HttpEntity<>(documentacaoJson, headers);

		keycloakRestTemplate.postForLocation(url, entity);
	}

	public List<Integer> obterDocumentosAtivosPJ(String idCoop) {
		String documentoUrl = String.format("%s/api/v1/documento/buscaAtivosObrigatorios/PJ/%s",documentoServiceUrl, idCoop);
		List<Integer> documentos = new ArrayList<>();

		try {
			ParameterizedTypeReference<List<DocumentoTO>> listaDocsParam = new  ParameterizedTypeReference<List<DocumentoTO>>() {};
			ResponseEntity<List<DocumentoTO>> responseEntity  = keycloakRestTemplate.exchange(documentoUrl, HttpMethod.GET, null, listaDocsParam);
			List<DocumentoTO> docs = responseEntity.getBody();
			if (docs != null) {
				documentos = docs.stream().map(DocumentoTO::getId).collect(Collectors.toList());
			}

		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return documentos;
	}

	public List<Integer> obterDocumentosPJAtivosObrigatorios(String idCoop) {
		String documentoUrl = String.format("%s/api/v1/documento/buscaAtivosObrigatorios/%s",documentoServiceUrl, idCoop);
		List<Integer> documentos = new ArrayList<>();

		try {
			ParameterizedTypeReference<List<DocumentoTO>> listaDocsParam = new  ParameterizedTypeReference<List<DocumentoTO>>() {};
			ResponseEntity<List<DocumentoTO>> responseEntity  = keycloakRestTemplate.exchange(documentoUrl, HttpMethod.GET, null, listaDocsParam);
			List<DocumentoTO> docs = responseEntity.getBody();
			if (docs != null) {
				documentos = docs.stream().map(DocumentoTO::getId).collect(Collectors.toList());
			}

		}catch (Exception e) {
			throw new RegraNegocioException(messages.get(PROBLEMAS_DOCUMENTO) + e.getMessage(),e);
		}
		return documentos;
	}
}
