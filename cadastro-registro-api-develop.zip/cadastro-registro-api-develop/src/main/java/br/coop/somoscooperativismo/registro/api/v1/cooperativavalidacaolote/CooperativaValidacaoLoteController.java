package br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote;

import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.entidade.CooperativaValidacaoLote;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1/cooperativa-validacao-lote")
public class CooperativaValidacaoLoteController {

    @Autowired
    private CooperativaValidacaoLoteService service;

    @PostMapping("/save-or-update")
    public ResponseEntity<CooperativaValidacaoLote> saveOrUpdate(@RequestBody CooperativaValidacaoLote cooperativaValidacaoLote) {
        CooperativaValidacaoLote savedCooperativa = service.saveOrUpdate(cooperativaValidacaoLote);
        return ResponseEntity.ok(savedCooperativa);
    }

    @GetMapping("/get-by-cooperativa-ano")
    public ResponseEntity<CooperativaValidacaoLote> getByCooperativaIdAndAnoReferencia(
            @RequestParam Integer cooperativaId,
            @RequestParam Integer anoReferencia) {

        Optional<CooperativaValidacaoLote> cooperativaValidacaoLote = service.findByCooperativaIdAndAnoReferencia(cooperativaId, anoReferencia);

        if (cooperativaValidacaoLote.isPresent()) {
            return ResponseEntity.ok(cooperativaValidacaoLote.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
