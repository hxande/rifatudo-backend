package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Component
public class ValidacaoCooperativaService {

	private static final String PERMISSAO_ALTERACAO = "permissao.alteracao.situacao";
	
	@Autowired
	private KeycloakService keycloakService;
	@Autowired
	private MessagesService messages;

	/**
	 * Verifica se o usuário logado possui perfil com permissão para alterar a
	 * situação da cooperativa
	 * 
	 */
	public void podeInativarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeCancelarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeAtivarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeIrregularizarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeRegularizarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isTipoEntidadeEstadual()
				|| keycloakService.isTipoEntidadeNacional())) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeTonarInativaCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeEmitirCertificadoRegistroCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_ANA")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeEmitirCertificadoRegularidadeCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_ANA")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeVisualizarDocumentosCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_ANA")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeVisualizarCadastroCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeSolicitarInativacaoCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeAceitarSolicitacaoInativacaoCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeRecusarSolicitacaoInativacaoCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeSolicitacaoCancelamentoCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeAceitarSolicitacaoCancelamentoCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeSolicitacaoAtivarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeRecusarSolicitacaoCancelamentoCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeAceitarSolicitacaoAtivarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeCancelarSolicitacaoInativacaoEnviada() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeCancelarSolicitacaoCancelamentoEnviada() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeRecusarSolicitacaoAtivarCooperativa() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeCancelarSolicitacaoAtivacao() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("CO_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeDeferirPedido() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeSalvarRecursoDeLiberacao() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeSalvarResultadoRecursoDeliberacao() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeArquivarProcesso() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeDesarquivarProcesso() {
		if (!(keycloakService.isVerificaPossuiSubPerfil("UE_GES")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_RESP_SITUACAO")
				|| keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}

	public void podeExportarDadosTabelaCooperativa() {
		/*
		keycloakService.isVerificaPossuiSubPerfil(UE_VIS)
		 if (keycloakService.isVerificaPossuiSubPerfil(UN_VIS)) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
		*/
	}
}
