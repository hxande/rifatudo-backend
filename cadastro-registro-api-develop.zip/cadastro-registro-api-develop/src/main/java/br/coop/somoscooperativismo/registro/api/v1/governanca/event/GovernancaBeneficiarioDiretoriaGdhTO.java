package br.coop.somoscooperativismo.registro.api.v1.governanca.event;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GovernancaBeneficiarioDiretoriaGdhTO {
    private Integer SQ_MEMBRO_MANDATO;
    private Integer SQ_COOPERATIVA;
    private Integer SQ_MANDATO;
    private String cpf;
    private boolean estaNoCargo;
    private boolean estaAtivoNoMandato;
}
