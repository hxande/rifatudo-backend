package br.coop.somoscooperativismo.registro.api.v1.apontamentos;

import java.util.Date;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ApontamentoTO {
    private Integer id;
    private CooperativaTO cooperativa;
    private String loginUsuario;
    private Date dataApontamento;
    private String apontamento;
}
