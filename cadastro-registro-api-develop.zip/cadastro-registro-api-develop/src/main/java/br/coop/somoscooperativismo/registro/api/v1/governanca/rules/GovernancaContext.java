package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.orgaocargo.entidade.OrgaoCargo;
import br.coop.somoscooperativismo.registro.api.v1.orgaoramo.entidade.OrgaoRamo;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import lombok.Builder;
import lombok.Getter;
import lombok.Singular;

/**
 * Contexto imutável de avaliação consumido pelas {@link GovernancaRule}.
 * Reúne tudo que as regras precisam (cooperativa, situação, mandatos sob
 * avaliação e a matriz {@code OrgaoRamo}/cargos resolvida), sem que as regras
 * acessem repositórios — o que as torna unitariamente testáveis sem Spring/DB.
 *
 * <p>Pode representar a avaliação de UM conselho (salvar-por-conselho, FR-023)
 * ou de TODOS os conselhos (validação agregada/pendências, FR-026).</p>
 */
@Getter
@Builder
public class GovernancaContext {

    private final Cooperativa cooperativa;
    private final GovernancaSituacao situacao;

    /** Data de constituição da PJ (referência das regras de data, INV-4). */
    private final Date dataConstituicao;

    /** Mandatos sob avaliação. */
    @Singular
    private final List<Mandato> mandatos;

    /** Matriz de regras por órgão (id do órgão → OrgaoRamo). */
    @Singular("orgaoRamo")
    private final Map<Integer, OrgaoRamo> orgaosRamo;

    /** Cargos obrigatórios por órgão (id do órgão → cargos). */
    @Singular("cargosObrigatorios")
    private final Map<Integer, List<OrgaoCargo>> cargosObrigatoriosPorOrgao;

    /** Todos os cargos do órgão (id do órgão → cargos), para "cargo retirado". */
    @Singular("cargosDoOrgao")
    private final Map<Integer, List<OrgaoCargo>> cargosPorOrgao;

    public OrgaoRamo orgaoRamoDe(Integer idOrgao) {
        return orgaosRamo == null ? null : orgaosRamo.get(idOrgao);
    }

    public List<OrgaoCargo> cargosObrigatoriosDe(Integer idOrgao) {
        if (cargosObrigatoriosPorOrgao == null) {
            return Collections.emptyList();
        }
        return cargosObrigatoriosPorOrgao.getOrDefault(idOrgao, Collections.emptyList());
    }

    public List<OrgaoCargo> cargosDe(Integer idOrgao) {
        if (cargosPorOrgao == null) {
            return Collections.emptyList();
        }
        return cargosPorOrgao.getOrDefault(idOrgao, Collections.emptyList());
    }

    /** Membros ativos de um mandato (lista nula é tratada como vazia). */
    public static long membrosAtivos(Mandato mandato) {
        if (mandato == null || mandato.getListaMandatoMembro() == null) {
            return 0L;
        }
        return mandato.getListaMandatoMembro().stream()
                .filter(m -> Boolean.TRUE.equals(m.getMembroAtivo()))
                .count();
    }

    /** Lista defensiva de membros de um mandato. */
    public static List<MandatoMembro> membros(Mandato mandato) {
        if (mandato == null || mandato.getListaMandatoMembro() == null) {
            return Collections.emptyList();
        }
        return mandato.getListaMandatoMembro();
    }
}
