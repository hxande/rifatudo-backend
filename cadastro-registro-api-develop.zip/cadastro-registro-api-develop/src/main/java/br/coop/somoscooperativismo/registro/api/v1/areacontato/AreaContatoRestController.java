package br.coop.somoscooperativismo.registro.api.v1.areacontato;

import br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade.AreaContato;
import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/area-contato")
@Tag(name = "AreaContato")
public class AreaContatoRestController {

	private static final String AREA_CONTATO_CRIADA = "areaContato.criada";
	private static final String AREA_CONTATO_NAO_CORRESPONDE = "areaContato.naoCorresponde";
	private static final String AREA_CONTATO_ATUALIZADA = "areaContato.atualizada";
	private static final String AREA_CONTATO_DESATIVADA = "areaContato.desativada";

	@Autowired
	private AreaContatoService areaContatoService;

	@Autowired
	private MessagesService messages;

	@Operation(summary = "Detalha uma area de contato pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<AreaContato>> getAreaContato(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(areaContatoService.getAreaContato(id)));

	}

	@PostMapping
	@Operation(summary = "Cria uma area de contato")
	public ResponseEntity<ServiceResponse<AreaContato>> createAreaContato(@RequestBody @Valid AreaContato areaContato) {
		areaContato = areaContatoService.createAreaContato(areaContato);

		HttpHeaders headers = new HttpHeaders();

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
				.buildAndExpand(areaContato.getId()).toUri();
		headers.setLocation(location);

		ServiceMessage message = new ServiceMessage(messages.get(AREA_CONTATO_CRIADA));

		return new ResponseEntity<>(new ServiceResponse<>(areaContato, message), headers, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	@Operation(summary = "Altera uma area de contato")
	public ResponseEntity<ServiceResponse<AreaContato>> updateAreaContato(@PathVariable Integer id,
			@RequestBody @Valid AreaContato areaContato) {
		if (!areaContato.getId().equals(id)) {
			return new ResponseEntity<>(
					new ServiceResponse<>(null,
							new ServiceMessage(MessageType.ERROR, "URL ID: '" + id
									+ messages.get(AREA_CONTATO_NAO_CORRESPONDE) + areaContato.getId() + "'.")),
					HttpStatus.BAD_REQUEST);
		}

		ServiceMessage message = new ServiceMessage(messages.get(AREA_CONTATO_ATUALIZADA));
		return new ResponseEntity<>(new ServiceResponse<>(areaContatoService.updateAreaContato(areaContato), message),
				HttpStatus.OK);

	}

	@GetMapping
	@Operation(summary = "Lista todas as areas de contato")
	public ServiceResponse<List<AreaContato>> getAreasContatos() {
		return new ServiceResponse<>(areaContatoService.buscaListaAreaContatoAtivaOrderByPosicaoTela());
	}
	
	@GetMapping("/uf/{uf}")
	@Operation(summary = "Lista todas as areas de contato")
	public ServiceResponse<List<AreaContato>> getAreasContatosPorUf(@PathVariable String uf) {
		return new ServiceResponse<>(areaContatoService.buscaListaAreaContatoAtivaByUf(uf));
	}

	@GetMapping("/estadual")
	@Operation(summary = "Lista todas as areas de contato por uf")
	public ServiceResponse<List<AreaContato>> getAreasContatosEstaduais(@RequestParam(required = false) String uf) {
		return new ServiceResponse<>(areaContatoService.buscaListaAreaContatoAtivaByUf(uf));
	}

	@GetMapping("/nacional")
	@Operation(summary = "Lista todas as areas de contato nacionais")
	public ServiceResponse<List<AreaContato>> getAreasContatosNacionais() {
		return new ServiceResponse<>(areaContatoService.findAreaContatoOrderByPosicaoTela());
	}

	@GetMapping("/filtro")
	@Operation(summary = "Lista as areas com filtro")
	public ServiceResponse<Page<AreaContato>> listaAreaContatoFiltradoPaginado(
			@RequestParam(required = false) String nome,
			@RequestParam(required = false) Boolean ativo,
			@RequestParam(required = false) Boolean utilizaCargo,
			@RequestParam(required = false) Boolean obrigatorio,
			@RequestParam(required = false) Integer posicaoTela,
			Pageable pageable) {
		return new ServiceResponse<>(areaContatoService.filtra(nome != null ? nome : "", ativo,
				utilizaCargo, obrigatorio, posicaoTela, pageable));
	}

	@GetMapping("/filtro/estadual")
	@Operation(summary = "Lista as areas com filtro")
	public ServiceResponse<Page<AreaContato>> listaAreaContatoEstadualFiltradoPaginado(
			@RequestParam(required = false) String nome,
			@RequestParam(required = false) Boolean ativo,
			@RequestParam(required = false) Boolean utilizaCargo,
			@RequestParam(required = false) String uf,
			Pageable pageable) {
		return new ServiceResponse<>(areaContatoService.filtraEstadual(nome != null ? nome : "", ativo, utilizaCargo, uf, pageable));
	}

	@GetMapping("/filtro/estadual/nacional")
	@Operation(summary = "Lista as areas com filtro")
	public ServiceResponse<Page<AreaContato>> listaAreaContatoEstadualFiltradoPaginado(
			@RequestParam(required = false) String nome,
			@RequestParam(required = false) Boolean ativo,
			@RequestParam(required = false) Boolean utilizaCargo,
			@RequestParam(required = false) Boolean obrigatorio,
			@RequestParam(required = false) Integer posicaoTela,
			Pageable pageable) {
		return new ServiceResponse<>(areaContatoService.filtraEstadualNacional(nome != null ? nome : "", ativo,
				utilizaCargo, obrigatorio, posicaoTela, pageable));
	}

	@DeleteMapping("ativo/{id}/{valor}")
	@Operation(summary = "Desativa uma area de contato", description = "Um ID válido e um valor deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> desativaAreaContato(@PathVariable Integer id, @PathVariable Boolean valor) {
		areaContatoService.ativaAreaContato(id, valor);
		ServiceMessage message = new ServiceMessage(messages.get(AREA_CONTATO_ATUALIZADA));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	@Operation(summary = "Exclui uma area de contato", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> excluiAreaContato(@PathVariable Integer id) {
		areaContatoService.excluiAreaContato(id);
		ServiceMessage message = new ServiceMessage(messages.get(AREA_CONTATO_DESATIVADA));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

}
