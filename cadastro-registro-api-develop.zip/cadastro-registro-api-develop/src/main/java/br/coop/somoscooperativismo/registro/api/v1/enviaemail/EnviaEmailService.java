package br.coop.somoscooperativismo.registro.api.v1.enviaemail;

import br.coop.somoscooperativismo.api.v1.relatorio.RelatorioClient;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioExpressTO;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum;
import br.coop.somoscooperativismo.registro.api.v1.email.util.EmailServiceEvent;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.entidade.CooperativaPendencia;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaCnpjNomeFantasiaUfSiglaTO;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.usuario.VwUsuarioInscritoEmailRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class EnviaEmailService {
    public static final int NUMBER_107 = 107;
    public static final int NUMBER_101 = 101;
    public static final int NUMBER_40 = 40;
    public static final int NUMBER_30 = 30;
    public static final int NUMBER_2 = 2;
    public static final int NUMBER_20 = 20;
    public static final int NUMBER_22 = 22;

    @Autowired
    private RelatorioClient relatorioClient;

    @Autowired
    EnviaEmailRepository enviaEmailRepository;

    @Autowired
    VwUsuarioInscritoEmailRepository vwUsuarioInscritoEmailRepository;

    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;

    @Autowired
    private CooperativaService cooperativaService;

    public List<CooperativaPendencia> retiraRepetido(List<CooperativaPendencia> cooperativaPendencia) {
        List<CooperativaPendencia> cooperativaSemRepeticao = new ArrayList<>();
        Set<String> blocos = new HashSet<>();
        cooperativaPendencia.forEach(p -> {
            String bloco = p.getBloco();
            if (!blocos.contains(bloco)) {
                blocos.add(bloco);
                cooperativaSemRepeticao.add(p);
            }
        });
        return cooperativaSemRepeticao;
    }

    public void filtraCooperativaSuspensa() {
        String fileBase64;

        Calendar dataInicio = Calendar.getInstance();
        dataInicio.set(Calendar.HOUR_OF_DAY, 0);
        dataInicio.add(Calendar.DATE, - NUMBER_107);

        Calendar dataFim = Calendar.getInstance();
        dataFim.set(Calendar.HOUR_OF_DAY, 0);
        dataFim.add(Calendar.DATE, - NUMBER_101);

        List<Cooperativa> cooperativasIrregulares = cooperativaService.buscaCooperativasIrregulares();


        cooperativasIrregulares = cooperativasIrregulares.stream().peek(
                c -> c.setCooperativaRegistro(c.getCooperativaRegistro().stream().filter(
                    cr -> cr.getDtAlteracao().after(dataInicio.getTime()) && cr.getDtAlteracao().before(dataFim.getTime())
                ).toList())).filter(c -> !c.getCooperativaRegistro().isEmpty()).toList();

        Map<String, List<Cooperativa>> irregularidadesPorUf = new HashMap<>();

        cooperativasIrregulares.forEach(p -> {
            String uf = p.getPessoaJuridica().getUfSigla();
            if (!irregularidadesPorUf.containsKey(uf)) {
                irregularidadesPorUf.put(uf, new ArrayList<>());
            }
            irregularidadesPorUf.get(uf).add(p);
        });

        List<EmailGestorTO> emailsGestor;

        emailsGestor = enviaEmailRepository.getEmailsGestorFiltro();

        if (!ValidacaoCampos.validaCampoPreenchido(emailsGestor)) {
            return;
        }

        List<String> cabecalho = Arrays.asList("Cooperativa", "Data última atualização");
        List<Integer> larguras = Arrays.asList(NUMBER_40, NUMBER_30);
        for (String uf : irregularidadesPorUf.keySet()) {
            String listaEmailsGestor = emailsGestor.stream().filter(eg -> eg.getUf().equals(uf)).map(EmailGestorTO::getEmail).collect(Collectors.joining(","));
            if (!ValidacaoCampos.validaCampoPreenchido(listaEmailsGestor)) {
                continue;
            }

            // inclusão de campos novos
            List<List<String>> linhas = new ArrayList<>();
            irregularidadesPorUf.get(uf).forEach(r -> {
                linhas.add(Arrays.asList(r.getPessoaJuridica().getNomeFantasia(),
                        r.getDataAtualizacao().toString()));
            });


            fileBase64 = Base64.getEncoder().encodeToString(montaRelatorio(cabecalho, linhas, larguras));
            disparodeEmails(listaEmailsGestor, fileBase64, EnvioEmailEventEnum.EMAIL_APONTA_IRREGULARIDADE_UE);
        }
    }


    public void filtrarAlteracaoCooperativaListagemExcel() {
        String fileBase64 = null;
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.add(Calendar.DATE, -NUMBER_2);

        ProgressoMicroEnum status = ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1;
        ProgressoMicroEnum statusManutencao = ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1;

        List<Cooperativa> resultado = cooperativaService.buscarPendenciasData(status, statusManutencao, cal.getTime());

        Map<String, List<Cooperativa>> pendenciasPorUf = new HashMap<>();
        resultado.forEach(p -> {
            if(p.getPessoaJuridica() != null) {
                String uf = p.getPessoaJuridica().getUfSigla();
                if (!pendenciasPorUf.containsKey(uf)) {
                    pendenciasPorUf.put(uf, new ArrayList<>());
                }
                pendenciasPorUf.get(uf).add(p);
            }
        });

        List<EmailGestorTO> emailsGestor = null;


        emailsGestor = vwUsuarioInscritoEmailRepository.getEmailsGestorFiltro();

        if (!ValidacaoCampos.validaCampoPreenchido(emailsGestor)) {
            return;
        }

        List<String> cabecalho = Arrays.asList("Cooperativa", "CNPJ", "Pendência", "Ramo", "E-mail Cooperativa");
        List<Integer> larguras = Arrays.asList(NUMBER_40, NUMBER_20, NUMBER_22, NUMBER_22, NUMBER_40);
        for (String uf : pendenciasPorUf.keySet()) {
            String listaEmailsGestor = emailsGestor.stream().filter(eg -> eg.getUf().equals(uf)).map(EmailGestorTO::getEmail).collect(Collectors.joining(","));
            if (!ValidacaoCampos.validaCampoPreenchido(listaEmailsGestor)) {
                continue;
            }

            List<List<String>> linhas = new ArrayList<>();
            pendenciasPorUf.get(uf).forEach(r -> {
                linhas.add(Arrays.asList(r.getPessoaJuridica().getNomeFantasia(),
                        r.getPessoaJuridica().getCnpj(),
                        r.getProgressoMicro() != null ? "Aguardando Análise" : "Aguardando Análise Manutencao",
                        r.getPessoaJuridica().getRamo().getNome(),
                        r.getPessoaJuridica().getEmailGeral()));
            });

            fileBase64 = Base64.getEncoder().encodeToString(montaRelatorio(cabecalho, linhas, larguras));
            disparodeEmails(listaEmailsGestor, fileBase64, EnvioEmailEventEnum.EMAIL_APONTA_IRREGULARIDADE_UE);
        }
    }

    private byte[] montaRelatorio(List<String> cabecalho, List<List<String>> linhas,
                                  List<Integer> larguras) {
        RelatorioExpressTO relatorio = new RelatorioExpressTO();
        relatorio.setCabecalho(cabecalho);
        relatorio.setDados(linhas);
        relatorio.setLarguras(larguras);
        return relatorioClient.gerarRelatorio(relatorio);
    }

    public void enviarEmailUnidadeEstadualSubmissaoAnuario(Integer cooperativaId, PessoaJuridicaCnpjNomeFantasiaUfSiglaTO pessoaJuridicaView) {
        String emails = getEmailsGestoresUe(pessoaJuridicaView.getUfSigla());
        if (StringUtils.isNotEmpty(emails)) {
            Cooperativa cooperativa = cooperativaService.getCooperativa(cooperativaId);
            disparodeCoopEmails(emails, cooperativa, EnvioEmailEventEnum.EMAIL_SUBMISSAO_ANUARIO);
        }

        emails = null;
    }

    private String getEmailsGestoresUe(String uf) {
        List<EmailGestorTO> gestoresEmail = vwUsuarioInscritoEmailRepository.getEmailsGestorFiltro();
        return gestoresEmail.stream()
                .filter(gestorEmail -> gestorEmail.getUf()
                        .equalsIgnoreCase(uf))
                .map(EmailGestorTO::getEmail)
                .collect(Collectors.joining(","));
    }
    private void disparodeEmails(String listaEmailsGestor, String fileBase64, EnvioEmailEventEnum type) {
        EmailEventTO to = new EmailEventTO();
        to.setArquivoBase64(fileBase64);
        to.setDestinatarios(listaEmailsGestor);
        EmailServiceEvent<EmailEventTO> event = new EmailServiceEvent<>(type.getId(), type, to);
        applicationEventPublisher.publishEvent(event);

        to = null;

    }
    private void disparodeCoopEmails(String emails, Cooperativa cooperativa, EnvioEmailEventEnum type) {
        EmailEventTO to = new EmailEventTO();
        to.setEmail(emails);
        to.setCooperativa(cooperativa);
        EmailServiceEvent<EmailEventTO> event = new EmailServiceEvent<>(type.getId(), type, to);
        applicationEventPublisher.publishEvent(event);

        to = null;
    }

}
