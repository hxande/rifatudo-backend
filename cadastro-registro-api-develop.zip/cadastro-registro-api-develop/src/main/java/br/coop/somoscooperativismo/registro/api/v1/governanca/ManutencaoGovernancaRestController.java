package br.coop.somoscooperativismo.registro.api.v1.governanca;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.GovernancaTO;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.MandatoMembroService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/manutencao-governanca")
@Tag(name = "GovernancaManutencao")
public class ManutencaoGovernancaRestController {

	private final MessagesService messages;
	private  final GovernancaService governancaService;
	private  final MandatoService mandatoService;

	private  final GovernancaMembroService governacaMembroService;

	private final MandatoMembroService mandatoMembroService;
	
	public static final String REGISTRO_SALVO = "registroSalvo.sucesso";
	public static final String REGISTRO_PENDENCIA = "registroSalvo.pendencia";
	public static final String HISTORICO_SALVO = "historico.salvo";



	// O endpoint POST /{idCooperativa} (salvar a aba inteira em
	// Manutenção) foi REMOVIDO — a gravação é exclusivamente por conselho, via
	// POST /api/v1/governanca/{idCooperativa}/conselho/{idOrgao}?manutencao=true.

	@GetMapping("/validarGovernanca/{id}")
	@Operation(summary = "Validando Governança em Manutenção")
	public ResponseEntity<ServiceResponse<ValidacaoPrimeiroRegistroTO>> validarGovernancaManutencao(@PathVariable Integer id){
		return obterValidacaoGovernancaManutencao(id);
				
	}
	
	@GetMapping("/obter-validacao-governanca/{id}")
	@Operation(summary = "Validando Governança em Manutenção")
	public ResponseEntity<ServiceResponse<ValidacaoPrimeiroRegistroTO>> obterValidacaoGovernancaManutencao(@PathVariable Integer id){
		return new ResponseEntity<>(new ServiceResponse<>(governancaService.obterValidacaoGovernancaManutencao(id, true)), HttpStatus.OK);
				
	}

	@GetMapping("/buscaVigentesPorCooperativa/{idCooperativa}")
	@Operation(summary = "Busca lista de governanças vigentes por id da cooperativa")
	public ResponseEntity<ServiceResponse<List<GovernancaTO>>> buscaPorCooperativManutencaoa(@PathVariable Integer idCooperativa){
		return new ResponseEntity<>(new ServiceResponse<>(governancaService.buscaPorCooperativaManutencao(idCooperativa)), HttpStatus.OK);
	}
	
	@GetMapping("/buscaNaoVigentesPorCooperativaOrgao/{idCooperativa}/{idOrgao}")
	@Operation(summary = "Busca lista de governanças nao vigentes por id da cooperativa e órgao")
	public ResponseEntity<ServiceResponse<List<GovernancaTO>>> buscaNaoVigentesPorCooperativaOrgao(@PathVariable Integer idCooperativa, @PathVariable Integer idOrgao){
		return new ResponseEntity<>(new ServiceResponse<>(governancaService.buscaNaoVigentesPorCooperativaOrgao(idCooperativa, idOrgao)), HttpStatus.OK);
	}

	@DeleteMapping("/tornarUltimoNaoVigente/{idCooperativa}/{idOrgao}")
	@Operation(summary = "Torna o ultimo mandato do orgao e cooperativa como não vigente")
	public ResponseEntity<ServiceResponse<Void>> tornarUltimoNaoVigente(@PathVariable Integer idCooperativa, @PathVariable Integer idOrgao){
		governacaMembroService.encerrarUltimoMandato(idCooperativa, idOrgao);
		ServiceMessage message = new ServiceMessage(messages.get(HISTORICO_SALVO));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@DeleteMapping("/excluir-mandato/{idCooperativa}/{idMandato}")
	@Operation(summary = "Torna o ultimo mandato do orgao e cooperativa como não vigente")
	public ResponseEntity<ServiceResponse<Void>> excluirMandato(@PathVariable Integer idCooperativa, @PathVariable Integer idMandato){
		mandatoService.excluirMandato(idCooperativa, idMandato);
		ServiceMessage message = new ServiceMessage("Mandato excluido com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@DeleteMapping("/exluir-membro/{idMandatoMembro}")
	@Operation(summary = "Remover o membro do mandato vigente permanentemente")
	public ResponseEntity<ServiceResponse<Void>> excluirMandatoMembro(@PathVariable Integer idMandatoMembro){
		mandatoService.excluirMandatoMembro(idMandatoMembro);
		ServiceMessage message = new ServiceMessage("Membro do Mandato excluido com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@PutMapping("/reativar-membro/{idMandatoMembro}")
	@Operation(summary = "Reativa individualmente um membro desligado de mandato vigente (trilha REATIVACAO_MEMBRO)")
	public ResponseEntity<ServiceResponse<MandatoMembro>> reativarMembro(@PathVariable Integer idMandatoMembro){
		return new ResponseEntity<>(new ServiceResponse<>(mandatoMembroService.reativarMembro(idMandatoMembro)), HttpStatus.OK);
	}

	@PutMapping("/tornar-vigente/{idCooperativa}/{idMandato}")
	@Operation(summary = "Torna o ultimo mandato do orgao e cooperativa como não vigente")
	public ResponseEntity<ServiceResponse<Void>> tornarMandatoVigente(@PathVariable Integer idCooperativa, @PathVariable Integer idMandato){
		governacaMembroService.tornarMandatoVigente(idCooperativa, idMandato);
		ServiceMessage message = new ServiceMessage("Mandato vigente adicionado com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

}
