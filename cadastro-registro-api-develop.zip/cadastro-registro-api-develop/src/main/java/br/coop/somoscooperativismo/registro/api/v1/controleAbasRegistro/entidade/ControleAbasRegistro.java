package br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro.entidade;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "CONTROLE_ABAS_REGISTRO")
public class ControleAbasRegistro implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_CONTROLE_ABA_REGISTRO")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_COOPERATIVA", referencedColumnName = "SQ_COOPERATIVA", nullable = false)
    private Cooperativa cooperativa;

    @Column(name = "DT_ENVIO")
    @Temporal(TemporalType.TIMESTAMP)
    @NotNull
    private Date dataEnvio;

    @Column(name = "TX_ABA")
    @NotNull
    @Size(max = 21)
    private String aba;

    @Column(name = "IN_ENVIADA")
    @NotNull
    private Boolean enviada;

}
