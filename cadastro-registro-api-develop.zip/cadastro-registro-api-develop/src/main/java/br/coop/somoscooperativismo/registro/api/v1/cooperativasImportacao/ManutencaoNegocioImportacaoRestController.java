package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import br.coop.somoscooperativismo.registro.api.v1.negocio.NegocioTO;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.negocio.NegocioService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/manutencao-negocio")
public class ManutencaoNegocioImportacaoRestController {

    private final NegocioService negocioService;

    @PatchMapping
    public ResponseEntity<Boolean> atualizar(@RequestBody @Valid NegocioTO negocioTO) {
        boolean successfully = negocioService.salvarManutencao(negocioTO);
        return ResponseEntity.ok(successfully);
    }

    @GetMapping("/validacoes/{id}")
    public ResponseEntity<ValidacaoPrimeiroRegistroTO> validarNegocioImportacao(@PathVariable Integer id) {
        return ResponseEntity.ok(negocioService.validarNegocioManutencao(id, true));
    }
}
