package br.coop.somoscooperativismo.registro.api.v1.escolaridade;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EscolaridadeTO implements Serializable{

    private static final long serialVersionUID = 1L;

    private Integer id;

    private Boolean ativo;

    private String descricaoEscolaridade;

}
