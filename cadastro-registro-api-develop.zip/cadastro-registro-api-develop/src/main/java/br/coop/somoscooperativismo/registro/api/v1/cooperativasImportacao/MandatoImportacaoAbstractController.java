package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.stream.Collectors;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.AprovacaoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CargoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.MandatoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.MandatoMembroImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.OrgaoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.PessoaFisicaImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class MandatoImportacaoAbstractController {

    @NonNull
    protected ModelMapper modelMapper;

    protected Converter<Mandato, MandatoImportacaoTO> converterEntidadeParaTO = context ->
            MandatoImportacaoTO.builder()
                    .id(context.getSource().getId())
                    .cooperativa(CooperativaImportacaoTO.builder()
                            .id(context.getSource().getCooperativa().getId())
                            .build())
                    .dataAssembleia(context.getSource().getDataAssembleia())
                    .orgao(OrgaoImportacaoTO.builder()
                            .id(context.getSource().getOrgao().getId())
                            .nome(context.getSource().getOrgao().getNome())
                            .obrigatorio(context.getSource().getOrgao().getObrigatorio())
                            .ativo(context.getSource().getOrgao().getAtivo())
                            .nomeiaResponsavel(context.getSource().getOrgao().getNomeiaResponsavel())
                            .vinculo(context.getSource().getOrgao().getVinculo())
                            .build())
                    .fimMandato(context.getSource().getFimMandato())
                    .anosDuracao(context.getSource().getAnosDuracao())
                    .membrosMandato(context.getSource().getMembrosMandato())
                    .vigente(context.getSource().getVigente())
                    .listaMandatoMembro(context.getSource().getListaMandatoMembro().stream()
                            .map(mandatoMembro -> MandatoMembroImportacaoTO.builder()
                                    .id(mandatoMembro.getId())
                                    .cargo(CargoImportacaoTO.builder()
                                            .id(mandatoMembro.getCargo().getId())
                                            .ativo(mandatoMembro.getCargo().getAtivo())
                                            .nome(mandatoMembro.getCargo().getNome())
                                            .build())
                                    .pessoaFisica(PessoaFisicaImportacaoTO.builder()
                                            .seqCpf(mandatoMembro.getPessoaFisica().getSeqCpf())
                                            .cpf(mandatoMembro.getPessoaFisica().getCpf())
                                            .nome(mandatoMembro.getPessoaFisica().getNome())
                                            .dataNascimento(mandatoMembro.getPessoaFisica().getDataNascimento())
                                            .telefone(mandatoMembro.getPessoaFisica().getTelefone())
                                            .celular(mandatoMembro.getPessoaFisica().getCelular())
                                            .email(mandatoMembro.getPessoaFisica().getEmail())
                                            .build())
                                    .representanteLegal(mandatoMembro.getRepresentanteLegal())
                                    .membroAtivo(mandatoMembro.getMembroAtivo())
                                    .inicioMandato(mandatoMembro.getInicioMandato())
                                    .fimMandato(mandatoMembro.getFimMandato())
                                    .aprovacao(getAprovacao(mandatoMembro))
                                    .build()).collect(Collectors.toList()))
                    .build();

    private AprovacaoImportacaoTO getAprovacao(MandatoMembro mandatoMembro) {
        if (null == mandatoMembro.getAprovacao()) {
            return null;
        }

        return AprovacaoImportacaoTO.builder()
                .id(mandatoMembro.getAprovacao().getId())
                .ano(mandatoMembro.getAprovacao().getAno())
                .dataAtualizacao(mandatoMembro.getAprovacao().getDataAtualizacao())
                .build();
    }
}
