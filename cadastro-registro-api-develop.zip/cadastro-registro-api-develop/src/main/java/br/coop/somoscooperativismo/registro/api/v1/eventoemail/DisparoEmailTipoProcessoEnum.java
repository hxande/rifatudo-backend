package br.coop.somoscooperativismo.registro.api.v1.eventoemail;

import lombok.Getter;

@Getter
public enum DisparoEmailTipoProcessoEnum {
	PROCESSO_REGISTRO(1,"Processo de Registro"),ATUALIZACAO_CADASTRAL(2,"Atualização Cadastral");

	DisparoEmailTipoProcessoEnum(Integer id, String descricao) {
		this.id = id;
		this.descricao = descricao;
	}
	
	private Integer id;
	private String descricao;
}
