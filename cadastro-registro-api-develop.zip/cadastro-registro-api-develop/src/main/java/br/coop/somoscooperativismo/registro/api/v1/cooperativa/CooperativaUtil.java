package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import java.util.ArrayList;
import java.util.List;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;

public class CooperativaUtil {
	
	private CooperativaUtil() {
		
	}

	public static List<CooperativaBasicaTO> formatarSaidaBasica(List<Cooperativa> r) {
		List<CooperativaBasicaTO> saida = new ArrayList<>();
		
		if(r != null && !r.isEmpty()) {
			saida = new ArrayList<>();
			for (Cooperativa c : r) {
				saida.add(formatarSaidaBasica(c));
			}
		}
		
		return saida;
	}
	public static CooperativaBasicaTO formatarSaidaBasica(Cooperativa c) {
		CooperativaBasicaTO saida = null;
		
		if(c != null) {
			saida = new CooperativaBasicaTO();
			saida.setId(c.getId());
			saida.setCnpj(ValidacaoCampos.formatarComMascara(c.getPessoaJuridica().getCnpj(), "##.###.###/####-##"));
			saida.setNomeFantasia(c.getPessoaJuridica().getNomeFantasia());
			saida.setRazaoSocial(c.getPessoaJuridica().getRazaoSocial());
			saida.setUfSigla(c.getPessoaJuridica().getUfSigla());
			saida.setNumeroRegistro(c.getNumeroRegistroOCB());
			saida.setDataRegistro(c.getDataRegistro());
			saida.setSituacao(c.getSituacaoCooperativa());
			if(c.getPessoaJuridica().getRamo() != null) {
				saida.setIdRamo(c.getPessoaJuridica().getRamo().getId());
				saida.setNomeRamo(c.getPessoaJuridica().getRamo().getNome());	
			}
		}
		return saida;
	}
	
	/**
	 * @description Adiciona mascara 00000000 para o número sq do registro
	 * @param sqNumeroRegistroOCB
	 * @return String
	 */
	public static String formataNumeroRegistroOCB(Integer sqNumeroRegistroOCB) {
		return org.apache.commons.lang3.StringUtils.leftPad(sqNumeroRegistroOCB.toString(), 8, "0");
	}
	
}
