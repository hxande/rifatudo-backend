package br.coop.somoscooperativismo.registro.api.v1.controleanuariouf.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Data
@Table(name = "CONTROLE_ANUARIO_UF")
public class ControleAnuarioUf {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_CONTROLE_ANUARIO_UF")
    private Integer id;
    
    @Column(name = "TX_CONTROLE_ANUARIO_UF")
    private String chaveAnuario;

    @Column(name = "IN_MOSTRAR_POPUP", columnDefinition = "bit", nullable = false)
    private Boolean mostrarpopup;

    @Column(name = "IN_DESTACAR_ANUARIO", columnDefinition = "bit", nullable = false)
    private Boolean destacarAnuario;

    @Column(name = "TX_CONTEUDO_POPUP")
    private String textoPop;
    
    @Column(name = "IN_COOPERATIVA_PODE_PREENCHER", columnDefinition = "bit", nullable = false)
    private Boolean cooperativaPodePreencher;

    @Column(name = "IN_COOPERATIVA_PODE_VISUALIZAR_BTN_ANUARIO", columnDefinition = "bit", nullable = false)
    private Boolean cooperativaPodeVisualizar;
    
    @Column(name = "IN_HABILITAR_PREENCHIMENTO_ANUARIO", columnDefinition = "bit", nullable = false)
    private Boolean habilitarPreenchimentoAnuario;
    
    @Column(name = "IN_VISUALIZAR_PERIODO_ATUALIZACAO", columnDefinition = "bit")
    private Boolean visualizarPeriodoAtualizacao;
    
    @Column(name = "TX_UF", columnDefinition = "varchar(2)")
    private String uf;

}
