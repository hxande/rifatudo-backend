package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.PaisTO;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacao;
import lombok.Data;

import java.util.List;

@Data
public class DadosNegocioTO {
    private List<EstruturaIntegracaoTO> dadosEstrutura;
    private NegocioExportacao dadosNegocioExportacao;
    private List<PaisTO> paises;
    private Integer ano;
}
