package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.util.TokenSecurity;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/public/api/v1/cooperativa")
@Tag(name = "Cooperativa")
public class CooperativaPublicRestController {

	public static final String NAO_CORRESPONDE 		= "cooperativa.naoCorresponde";

	@Autowired
	private CooperativaService cooperativaService;
	
	@Autowired
	private PessoaJuridicaService pessoaJuridicaService;

	@Operation(summary = "Cria pessoa Juridica", description = "Um ID válido deve ser informado")
	@GetMapping("/cria/{idPessoaJuridica}")
	public ResponseEntity<ServiceResponse<CooperativaBasicaTO>> criaCooperativa(@PathVariable Integer idPessoaJuridica) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaService.salvaPreCadastro(idPessoaJuridica)));
	}

	@Operation(summary = "busca cooperativa com base no id da pessoajuridica", description = "Um ID válido deve ser informado")
	@GetMapping("/busca/{id}")
	public ResponseEntity<ServiceResponse<CooperativaBasicaTO>> buscaCooperativa(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaService.findByIdPublico(id)));
	}

	@Operation(summary = "Deleta cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("/remove/{id}/{token}")
	public ResponseEntity<Void> deleteCooperativa(@PathVariable Integer id, @PathVariable String token) {
		// Validando Segurança
		if(!TokenSecurity.tokenValido(token)) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			
		}
		cooperativaService.deleteById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@Operation(summary = "busca cooperativa ativa com base na razao social da pessoajuridica por uf", description = "Um nome válido deve ser informado")
	@GetMapping("/buscaAtiva/razaoSocial/{razaoSocial}/{uf}")
	public ResponseEntity<List<CooperativaBasicaTO>> buscaCooperativaAtivaPorRazaoSocialEUF(@PathVariable String razaoSocial, @PathVariable String uf) {
		
		return new ResponseEntity<>(cooperativaService.findCooperativaAtivaByRazaoSocialUFPublico(razaoSocial, uf), HttpStatus.OK);
	}

	
	@Operation(summary = "busca cooperativa ativa com base na razao social da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/buscaAtiva/razaoSocial/{razaoSocial}")
	public ResponseEntity<List<CooperativaBasicaTO>> buscaCooperativaAtivaPorRazaoSocial(@PathVariable String razaoSocial) {
		
		return new ResponseEntity<>(cooperativaService.findCooperativaAtivaByRazaoSocialPublico(razaoSocial), HttpStatus.OK);
	}
	
	@Operation(summary = "busca cooperativa ativa com base na razao social da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/buscaAtiva/cnpj/{cnpj}")
	public ResponseEntity<List<CooperativaBasicaTO>> buscaCooperativaAtivaPorCnpj(@PathVariable String cnpj) {
		
		return new ResponseEntity<>(cooperativaService.findCooperativaAtivaByCnpj(cnpj), HttpStatus.OK);
	}

	@Operation(summary = "busca cooperativa com base no cnpj da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/busca/cnpj/{cnpj}")
	public ResponseEntity<List<CooperativaBasicaTO>> buscaCooperativaPorCnpj(@PathVariable String cnpj) {
		
		return new ResponseEntity<>(cooperativaService.findCooperativaByCnpj(cnpj), HttpStatus.OK);
	}
	
	
	@Operation(summary = "busca cooperativa com base na razao social da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/busca/AtivasPorNomeUf")
	public Page<CooperativaBasicaTO> buscaCooperaAtivasPorNomeUfPaginado(String razaoSocial, String nomeFantasia, String tipo, Pageable pageable) {
		return cooperativaService.findByNomeUfPublico(razaoSocial, nomeFantasia, tipo, pageable);
	}
	
	@Operation(summary = "Detalha uma Cooperativa pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("buscaSituacaoPorCnpj/{cnpj}")
	public ResponseEntity<ServiceResponse<Situacao>> getCooperativaPorCnpj(@PathVariable String cnpj) {
		PessoaJuridica pessoaJuridica = pessoaJuridicaService.buscaPorCnpj(cnpj);
		if (pessoaJuridica == null) {
			throw new RegraNegocioException("Pessoa Jurídica não encontrada!", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaService.getSituacaoCooperativa(pessoaJuridica.getId())));
	}
	
	@GetMapping("/valida-status-coop/{cnpj}")
	@Operation(summary = "Valida se cooperativa não está registrada e se está nos passos iniciais (0 e 1)", description = "Um CNPJ válido deve ser informado")
	public ResponseEntity<Boolean> validaStatusCoop(@PathVariable String cnpj) {
		return new ResponseEntity<>(cooperativaService.isCooperativaNaoRegistradaAndInPreCadastro(cnpj), HttpStatus.OK);
	}
	
	
	@GetMapping("/coop-is-nao-registrada/{cnpj}")
	@Operation(summary = "Valida se cooperativa não está regiqstrada", description = "Um CNPJ válido deve ser informado")
	public ResponseEntity<Boolean> coopIsNaoRegistrada(@PathVariable String cnpj) {
		return new ResponseEntity<>(cooperativaService.isNaoRegistrada(cnpj), HttpStatus.OK);
	}

	@GetMapping("/busca-ativas")
	@Operation(summary = "Valida se cooperativa não está regiqstrada", description = "Um CNPJ válido deve ser informado")
	public ResponseEntity<Page<CooperativaBasicaTO>> buscaAtivas(@RequestParam(required = false) String cnpj,
																 @RequestParam(value = "pr", required = false) String processo, Pageable pageable) {
		return new ResponseEntity<>(cooperativaService.findCooperativaAtivaByCnpj(cnpj, processo, pageable), HttpStatus.OK);
	}

	@GetMapping("/busca-registradas")
	@Operation(summary = "Valida se cooperativa não está regiqstrada", description = "Um CNPJ válido deve ser informado")
	public ResponseEntity<Page<CooperativaBasicaTO>> buscaRegistradas(@RequestParam(required = false) String cnpj,
																	  @RequestParam(required = false) String uf,
																	  @RequestParam(required = false) String processo,
																	  @RequestParam(required = false) String nomeFantasia,
																      Pageable pageable) {
		try{
			return new ResponseEntity<>(cooperativaService.findCooperativaRegistradas(cnpj, processo, uf, nomeFantasia, pageable), HttpStatus.OK);
		} catch (NullPointerException e) {
			return new ResponseEntity<>(HttpStatus.OK);
		}
	}

	@GetMapping("/auto-complete")
	@Operation(summary = "Autocomplete para o campo nome fantasia")
	public ResponseEntity<List<String>> autocomplete(@RequestParam(required = false) String parcial) {
		return new ResponseEntity<>(cooperativaService.autocompleteCooperativa(parcial), HttpStatus.OK);
	}
}
