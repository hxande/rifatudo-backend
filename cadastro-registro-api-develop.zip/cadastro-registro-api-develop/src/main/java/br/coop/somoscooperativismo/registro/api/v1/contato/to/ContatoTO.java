package br.coop.somoscooperativismo.registro.api.v1.contato.to;

import lombok.Data;

@Data
public class ContatoTO {

	private Integer id;
	private Integer idPessoa;
	private Integer idAreaContato;
	private String nomeResponsavel;
	private String telefone;
	private String celular;
	private String email;
	private String site;
	private String cargo;
}
