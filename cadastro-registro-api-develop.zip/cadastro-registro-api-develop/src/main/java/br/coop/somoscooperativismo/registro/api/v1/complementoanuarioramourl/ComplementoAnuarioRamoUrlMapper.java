package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.entidade.ComplementoAnuarioRamoUrl;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface ComplementoAnuarioRamoUrlMapper {

    @Mapping(source = "complementoAnuarioId", target = "complementoAnuario.id")
    @Mapping(source = "ramoId", target = "ramo.id")
    ComplementoAnuarioRamoUrl toModel(ComplementoAnuarioRamoUrlTO complementoAnuarioRamoUrlTO);

    @Mapping(source = "complementoAnuario.id", target = "complementoAnuarioId")
    @Mapping(source = "ramo.id", target = "ramoId")
    ComplementoAnuarioRamoUrlTO toDto(ComplementoAnuarioRamoUrl complementoAnuarioRamoUrl);
}
