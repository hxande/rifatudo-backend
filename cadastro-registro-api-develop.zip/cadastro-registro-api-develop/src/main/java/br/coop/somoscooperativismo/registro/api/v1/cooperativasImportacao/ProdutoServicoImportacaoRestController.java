package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.PessoaSegmProdServService;
import br.coop.somoscooperativismo.registro.api.v1.produtoservico.ProdutoServicoService;
import br.coop.somoscooperativismo.registro.api.v1.produtoservico.entidade.ProdutoServico;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/produtoServico")
public class ProdutoServicoImportacaoRestController {

    private final ProdutoServicoService produtoServicoService;
    private final PessoaSegmProdServService segmProdServService;

    @GetMapping("/page")
    public ResponseEntity<Page<ProdutoServico>> getAll(@RequestParam(required = false) Integer id,
                                                       @RequestParam(required = false) Integer segmento,
                                                       @RequestParam(name = "descricao", required = false) String descricao,
                                                       @RequestParam(name = "detalhamento", required = false) String detalhamento,
                                                       @PageableDefault(sort = {"id"}, direction = Sort.Direction.ASC) Pageable pageable) {
        return ResponseEntity.ok(produtoServicoService.getAll(id, segmento, descricao, detalhamento, pageable));
    }

    @GetMapping("/buscaPorRamoSegmento/{idSegmento}/{idRamo}")
    @Operation(summary = "Lista por id de Ramo e id de Segmento")
    public ServiceResponse<List<ProdutoServico>> buscaPorRamoSegmento(@PathVariable Integer idSegmento, @PathVariable Integer idRamo) {
        return new ServiceResponse<>(produtoServicoService.buscaPorRamoSegmento(idSegmento, idRamo));
    }

    @GetMapping("/validar-controle-portfolio/{idCooperativa}")
    @Operation(summary = "Validando o controle do portfólio")
    public ResponseEntity<ServiceResponse<Boolean>> validarControlePortifolio(@PathVariable Integer idCooperativa){
        return new ResponseEntity<>(new ServiceResponse<>(segmProdServService.validarControlePortifolio(idCooperativa)), HttpStatus.OK);
    }


}
