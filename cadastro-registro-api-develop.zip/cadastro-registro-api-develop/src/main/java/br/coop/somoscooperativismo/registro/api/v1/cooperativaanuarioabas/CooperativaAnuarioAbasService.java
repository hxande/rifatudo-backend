package br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.entidade.CooperativaAnuarioAbas;

@Service
@Transactional
public class CooperativaAnuarioAbasService {

	private final CooperativaAnuarioAbasRepository cooperativaAnuarioAbasRepository;
	private final KeycloakService keycloakService;

	public CooperativaAnuarioAbasService(CooperativaAnuarioAbasRepository cooperativaAnuarioAbasRepository,
			KeycloakService keycloakService) {
		this.cooperativaAnuarioAbasRepository = cooperativaAnuarioAbasRepository;
		this.keycloakService = keycloakService;
	}
	
		
	public List<CooperativaAnuarioAbaTO> obterListaCooperativaAnuarioAbasPorAno(Integer idCooperativa,Integer ano){
		return cooperativaAnuarioAbasRepository.findAllByIdCooperativaAndAnoCiclo(idCooperativa,ano).stream().map(CooperativaAnuarioAbaTO::new).toList();
	}


	public void salvarAba(Integer cooperativaId, Integer anoCiclo, String abaNome, Integer situacao) {
        Optional<CooperativaAnuarioAbas> opCoopAnuarioAba = cooperativaAnuarioAbasRepository.findByIdCooperativaAndAnoCicloAndAbaNome(cooperativaId, anoCiclo, abaNome);

        CooperativaAnuarioAbas cooperativaAnuarioAbas;

        if (opCoopAnuarioAba.isPresent()) {
            cooperativaAnuarioAbas = opCoopAnuarioAba.get();
        } else {
            cooperativaAnuarioAbas = new CooperativaAnuarioAbas();
            cooperativaAnuarioAbas.setAbaNome(abaNome);
            cooperativaAnuarioAbas.setIdCooperativa(cooperativaId);
            cooperativaAnuarioAbas.setAnoCiclo(anoCiclo);
            cooperativaAnuarioAbas.setUsuario(keycloakService.getUsername());
            cooperativaAnuarioAbas.setAbaPreenchida(Boolean.TRUE);

        }

        cooperativaAnuarioAbas.setSituacao(situacao);
        cooperativaAnuarioAbasRepository.save(cooperativaAnuarioAbas);
    }

    public boolean todasAbasAprovadas(Integer cooperativaId, Integer ano, Set<String> abasEsperadas) {
        List<CooperativaAnuarioAbas> abas =
            cooperativaAnuarioAbasRepository.findAllByIdCooperativaAndAnoCiclo(cooperativaId, ano);

        Set<String> presentes = abas.stream()
            .map(CooperativaAnuarioAbas::getAbaNome)
            .collect(Collectors.toSet());

        if (!presentes.containsAll(abasEsperadas)) {
            return false;
        }

        return abas.stream()
            .filter(a -> abasEsperadas.contains(a.getAbaNome()))
            .allMatch(a -> a.getSituacao() != null && a.getSituacao() >= 0);
    }

}
