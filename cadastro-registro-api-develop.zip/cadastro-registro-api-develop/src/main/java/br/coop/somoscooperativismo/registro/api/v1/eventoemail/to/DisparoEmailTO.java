package br.coop.somoscooperativismo.registro.api.v1.eventoemail.to;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DisparoEmailTO {
	
	private Integer id;
	private String chaveEmail;
	private String textoEmail;
	private String textoVariavelEmail;
	private Boolean ativo;
	private String textoDescricaoEmail;
	private String destinatarioEmail;
	private Integer idTipoProcessoEmail;
	private String descricaoTipoProcessoEmail;
	
	public DisparoEmailTO(Integer id, String chaveEmail, String textoEmail,
			String textoVariavelEmail, String textoDescricaoEmail, 
			String destinatarioEmail,Boolean ativo, 
			Integer idTipoProcessoEmail,String descricaoTipoProcessoEmail) {
		this.id = id;
		this.chaveEmail = chaveEmail;
		this.textoEmail = textoEmail;
		this.textoVariavelEmail = textoVariavelEmail;
		this.ativo = ativo;
		this.textoDescricaoEmail = textoDescricaoEmail;
		this.destinatarioEmail = destinatarioEmail;
		this.idTipoProcessoEmail = idTipoProcessoEmail;
		this.descricaoTipoProcessoEmail = descricaoTipoProcessoEmail;
	}
}
