package br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.entidade.CooperativaSolicitacao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/cooperativasolicitacao")
@Tag(name = "CooperativaSolicitacao")
public class CooperativaSolicitacaoRestController {
	
	
	
	
	@Autowired
	CooperativaSolicitacaoService cooperativaSolicitacaoService;

	@Operation(summary = "busca a última cooperativa solicitacao de inativação ou solicitacao de inativação", description = "Um nome válido deve ser informado")
	@GetMapping("/buscaUltimaCooperativaSolicitacaoInativacao/{id}")
	public ServiceResponse<CooperativaSolicitacao> buscaUltimaCooperativaSolicitacaoInativacao(@PathVariable Integer id) {
		return new ServiceResponse<>(cooperativaSolicitacaoService.buscaUltimaCooperativaSolicitacao(id, TipoSolicitacaoEnum.INATIVACAO.getTipo()));
	}
	
	@Operation(summary = "busca cooperativa com base na razao social da pessoajuridica", description = "Um nome válido deve ser informado")
	@GetMapping("/buscaUltimaCooperativaInativacao/{id}")
	public ServiceResponse<CooperativaSolicitacao> buscaUltimaCooperativaInativacao(@PathVariable Integer id) {
		return new ServiceResponse<>(cooperativaSolicitacaoService.buscaUltimaCooperativaSolicitacao(id, TipoSolicitacaoEnum.INATIVACAO.getTipo()));
	}
	
}
