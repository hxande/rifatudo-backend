package br.coop.somoscooperativismo.registro.api.v1.eventoemail;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmailHistorico;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.to.DisparoEmailTO;
import br.coop.somoscooperativismo.registro.api.v1.tipoprocessoemail.TipoProcessoEmailRepository;
import br.coop.somoscooperativismo.registro.api.v1.tipoprocessoemail.entidade.TipoProcessoEmail;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DisparoEmailService {

    private static final String NAO_ENCONTRADO = "eventoEmail.naoEncontrado";
    final DisparoEmailRepository disparoEmailRepository;
    final DisparoEmailHistoricoRepository disparoEmailHistoricoRepository;
    final TipoProcessoEmailRepository tipoProcessoEmailRepository;

    private final MessagesService messages;

    public DisparoEmailService(DisparoEmailRepository disparoEmailRepository,
    		                   DisparoEmailHistoricoRepository disparoEmailHistoricoRepository,
    		                   TipoProcessoEmailRepository tipoProcessoEmailRepository,
    						   MessagesService messages) {
        this.disparoEmailRepository = disparoEmailRepository;
        this.disparoEmailHistoricoRepository = disparoEmailHistoricoRepository;
        this.tipoProcessoEmailRepository = tipoProcessoEmailRepository;
        this.messages = messages;
    }

    public Page<DisparoEmailTO> filtra(String tipoProcesso ,String chaveEmail, String textoDescricaoEmail, String tipoPessoaEmail, Boolean enviarEmail, Pageable pageable) {
    	return disparoEmailRepository.filtra(tipoProcesso,chaveEmail,textoDescricaoEmail,tipoPessoaEmail, enviarEmail, pageable);
    }

    public @Valid DisparoEmail updateDisparoEmail(@Valid DisparoEmail disparoEmail) {
        Optional<DisparoEmail> op = disparoEmailRepository.findById(disparoEmail.getId());
        if (op.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + disparoEmail.getId(), HttpStatus.NOT_FOUND);
        }
        return disparoEmailRepository.save(disparoEmail);
    }
    
    public @Valid DisparoEmailHistorico insertDisparoEmailHistorico(@Valid DisparoEmailHistorico disparoEmailHistorico) {
    	return disparoEmailHistoricoRepository.save(disparoEmailHistorico);
    }
    
    public DisparoEmailHistorico getDisparoEmailHistorico(DisparoEmail disparoEmail, Integer idCooperativa) {
    	Optional<DisparoEmailHistorico> disparoEmailHistorico = disparoEmailHistoricoRepository.findByDisparoEmailAndIdCooperativa(disparoEmail,idCooperativa);
    	return disparoEmailHistorico.orElse(null);
    }

    public DisparoEmail getDisparoEmail(Integer id) {
        Optional<DisparoEmail> disparoEmail = disparoEmailRepository.findById(id);
        if (disparoEmail.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + id, HttpStatus.NOT_FOUND);
        }
        return disparoEmail.get();
    }

    public DisparoEmail findDisparoEmailByChaveEmail(String chaveEmail) {
        Optional<DisparoEmail> disparoEmail = disparoEmailRepository.findDisparoEmailByChaveEmail(chaveEmail);
        if (disparoEmail.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + chaveEmail, HttpStatus.NOT_FOUND);
        }
        return disparoEmail.get();
    }

	public List<TipoProcessoEmail> getListTipoProcessoEmail() {
		return tipoProcessoEmailRepository.findAll();
	}
}
