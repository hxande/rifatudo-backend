package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade.AreaContato;
import br.coop.somoscooperativismo.registro.api.v1.areacontato.AreaContatoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/areas-contatos")
public class AreaContatoImportacaoRestController {

    private final AreaContatoService areaContatoService;

    @GetMapping("/ativos")
    public ResponseEntity<List<AreaContato>> getAllAtivos() {
        return ResponseEntity.ok(areaContatoService.getAllAtivosNaoExcluidos());
    }
}
