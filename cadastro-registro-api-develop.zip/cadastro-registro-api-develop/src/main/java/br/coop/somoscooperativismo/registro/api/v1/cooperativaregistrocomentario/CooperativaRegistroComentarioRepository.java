package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CooperativaRegistroComentarioRepository extends JpaRepository<CooperativaRegistroComentario, Integer> {
    List<CooperativaRegistroComentario> findByCooperativaRegistroId(Integer cooperativaRegistroId);

}
