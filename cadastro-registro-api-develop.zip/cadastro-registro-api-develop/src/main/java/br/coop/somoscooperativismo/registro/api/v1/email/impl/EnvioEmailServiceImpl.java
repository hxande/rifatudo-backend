package br.coop.somoscooperativismo.registro.api.v1.email.impl;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaCnpjTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.CooperativaRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.email.DisparoEmailTO;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailDestinatarioEnum;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailServiceConstant;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailTO;
import br.coop.somoscooperativismo.registro.api.v1.email.EnvioEmailService;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;
import br.coop.somoscooperativismo.registro.api.v1.email.util.EmailServiceUtil;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmailHistorico;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class EnvioEmailServiceImpl implements EnvioEmailService {
	public static final int NUMBER_2 = 2;
	private final EmailServiceUtil emailServiceUtil;
	private final EmailService emailService;
	private final DisparoEmailService disparoEmailService;
	private final CooperativaService cooperativaService;
	private final CooperativaRegistroService cooperativaRegistroService;

	@Value("${url-processo-registro-coop}")
	private String urlProcessoRegistroCoop;

	@Value("${url-recebe-email}")
	private String urlRecebeEmail;

	@Value("${dias_concluir_solicitacao}")
	private int diasConcluirSolicitacao;

	@Value("${email.fixo}")
	private String destinatarioFixo;

	@Override
	public void emailVisitaTecnica(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.VISITA_TECNICA);
		disparoEmailTO.setBotaoData(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void emailIniciarProcessoRegistro(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.PRE_CADASTRO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		DisparoEmailHistorico emailHistorico = disparoEmailService.getDisparoEmailHistorico(disparoEmail, to.getCooperativa().getId());
		if (disparoEmail != null && disparoEmail.getId() != null && (Objects.isNull(emailHistorico) || !emailHistorico.getEnviado())) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, to.getDestinatarios(), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
			emailServiceUtil.salvarHistoricoEnvioEmail(disparoEmail, to.getCooperativa().getId(), to.getDestinatarios());
		}
	}

	@Override
	public void enviaEmailFimVisitaTecnica(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.FIM_VISITA_TECNICA);
		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailAjustes(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.SOLICITA_AJUSTE);
		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.REALIZAR_ADEQUACAO_CADASTRAL, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailFimConformidade(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.FIM_CONFORMIDADE);
		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailRegistroDeferido(EmailEventTO to) {
//		if(to != null && to.getEmail() == null){
//			throw new RegraNegocioException("Email do destinatário não informado.");
//		}
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.REGISTRO_DEFERIDO);
		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailRegistroIndeferido(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.REGISTRO_INDEFERIDO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailRegistroArquivado(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.ARQUIVA_REGISTRO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailRegistroDesarquivado(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.DESARQUIVA_REGISTRO);
		DisparoEmail disparoEmail =  emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailAjustesFinalizado(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.FIM_AJUSTE);
		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailSubmeter(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.SUBMETER);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.REQUERIMENTO_DO_REGISTRO_REALIZADO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailManutencaoSubmeter(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.MANUTENCAO_SUBMETER);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_ATUALIZACAO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailManutencaoAprovar(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.FIM_AJUSTE_MANUTENCAO);

		if (disparoEmailTO == null) {
			return;
		}

		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_ATUALIZACAO, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailManutencaoAjustes(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.SOLICITA_AJUSTE_MANUTENCAO);
		disparoEmailTO.setBotaoContinuar(urlProcessoRegistroCoop);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.REALIZAR_ADEQUACAO_DE_ATUALIZACAO_CADASTRAL, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailApontarIrregularidade(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.APONTA_IRREGULARIDADE);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.COOPERATIVA_IRREGULAR, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailNotificacoesGestorUE(EmailEventTO to) {
		to.setNomeArquivo("pendencias.xlsx");
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.NOTIFICACAO_GESTOR_UE);
		disparoEmailTO.setBotaoRecebeEmail(urlRecebeEmail);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.NOTIFICACAO_SOU_COOP, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailComunicarOrgaosSuspensao(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.COMUNICA_ORGAOS_SUSPENSAO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.NOTIFICACAO_SOU_COOP, emailServiceUtil.obtemDestinatariosOE(to.getCooperativa().getPessoaJuridica().getUfSigla()), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailCooperativasIrregulares(EmailEventTO to) {
		to.setNomeArquivo("cooperativasIrregulares.xlsx");
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.APONTA_IRREGULARIDADE);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.NOTIFICACAO_SOU_COOP, to.getDestinatarios(), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailInativarCoop(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.INATIVAR_COOP);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.COOPERATIVA_INATIVA, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailAvisaUEConcluirSolicitacao(EmailEventTO to) {
		LocalDate quinzeDiasAtras = LocalDate.now().minusDays(diasConcluirSolicitacao);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String dataBuscar = sdf.format(Date.from(quinzeDiasAtras.atStartOfDay(ZoneId.systemDefault()).toInstant()));
		List<CooperativaRegistro> registros = cooperativaRegistroService.buscaNotificacoesAEnviarEmail(dataBuscar);
		registros.stream().limit(NUMBER_2).forEach(r -> envioEmailAvisaUEConcluirSolicitacao(to, r));

	}

	@Override
	public void enviaEmailAtualizarCadastro(EmailEventTO to) {
		List<CooperativaCnpjTO> cooperativasTO = cooperativaService.buscaCooperativaTOporRamo(to.getRamo(), to.getAno());
		List<EmailTO> listaEmailTO = new ArrayList<>();
		if(!cooperativasTO.isEmpty()) {
			emailServiceUtil.gerarEmailsParaSeremEnviados(cooperativasTO, listaEmailTO);
			emailService.enviaEmailsEmLote(listaEmailTO);
		}
	}

	@Override
	public void enviarEmailUnidadeEstadualSubmissaoAnuario(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.SUBMISSAO_ANUARIO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.ANUARIO_ANO_SOUCOOP_SISTEMA_OCB, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailDeferirPedido(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.DEFERIR_PEDIDO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, destinatarioFixo, disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailEnviarApontamentos(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.ENVIAR_APONTAMENTOS);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.COOPERATIVA_IRREGULAR, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailSuspensaoCooperativa(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.SOLICITAR_SUSPENSAO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.SUSPENSAO_COOPERATIVA, destinatarioFixo, disparoEmail, EmailDestinatarioEnum.UNIDADE_NACIONAL, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailManterSuspensaoCooperativa(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.MANTER_SITUACAO_COOPERATIVA);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.SUSPENSAO_COOPERATIVA, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailTornarCooperativaRegular(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.TORNAR_SITUACAO_REGULAR);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.REGULARIZA_COOPERATIVA, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
		}

	}

	@Override
	public void enviaEmailTornarCooperativaRegularUn(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.TORNAR_SITUACAO_REGULAR_UN);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.REGULARIZA_COOPERATIVA, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_NACIONAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailSolicitaCancelamentoCooperativa(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.SOLICITAR_CANCELAMENTO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.SOLICITA_CANCELAMENTO_COOPERATIVA, destinatarioFixo, disparoEmail, EmailDestinatarioEnum.UNIDADE_NACIONAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailManterCancelamentoCooperativa(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.MANTER_SITUACAO_CANCELAMENTO_COOPERATIVA);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.SOLICITA_CANCELAMENTO_COOPERATIVA, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailAceitarSolicitacaoCancelamento(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.ACEITAR_SOLICITACAO_CANCELAMENTO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.SOLICITA_CANCELAMENTO_COOPERATIVA, emailServiceUtil.getEmailService(to), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailIniciarProcessoRegistro(EmailEventTO to) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.PRE_CADASTRO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		DisparoEmailHistorico emailHistorico = disparoEmailService.getDisparoEmailHistorico(disparoEmail, to.getCooperativa().getId());
		if (disparoEmail != null && disparoEmail.getId() != null && (Objects.isNull(emailHistorico) || !emailHistorico.getEnviado())) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.PROCESSO_DE_REGISTRO, to.getDestinatarios(), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
			salvarHistoricoEnvioEmail(disparoEmail,to.getCooperativa().getId(), to.getDestinatarios());
		}

	}

	private void envioEmailAvisaUEConcluirSolicitacao(EmailEventTO to, CooperativaRegistro r) {
		to.setCooperativa(r.getCooperativa());
		to.setLogin(r.getLoginAlteracaoSituacao());
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, DisparoEmailEnum.AVISAR_UE_CONCLUIR_SOLICITACAO);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(EmailServiceConstant.NOTIFICACAO_SOU_COOP, emailServiceUtil.obtemDestinatarioPorLogin(to.getLogin()), disparoEmail, EmailDestinatarioEnum.UNIDADE_ESTADUAL, to);
			emailService.enviarEmail(emailTO);
		}
	}

	@Override
	public void enviaEmailSolicitacaoFiliacaoSuperior(EmailEventTO to) {
		enviaEmailFiliacaoSuperior(to, DisparoEmailEnum.SOLICITACAO_FILIACAO_SUPERIOR, EmailServiceConstant.SOLICITACAO_VINCULO_COOPERATIVA);
	}

	@Override
	public void enviaEmailAprovacaoFiliacaoSuperior(EmailEventTO to) {
		enviaEmailFiliacaoSuperior(to, DisparoEmailEnum.APROVACAO_FILIACAO_SUPERIOR, EmailServiceConstant.FILIACAO_SUPERIOR_APROVADA);
	}

	@Override
	public void enviaEmailReprovacaoFiliacaoSuperior(EmailEventTO to) {
		enviaEmailFiliacaoSuperior(to, DisparoEmailEnum.REPROVACAO_FILIACAO_SUPERIOR, EmailServiceConstant.FILIACAO_SUPERIOR_REPROVADA);
	}

	private void enviaEmailFiliacaoSuperior(EmailEventTO to, DisparoEmailEnum chave, String assunto) {
		DisparoEmailTO disparoEmailTO = emailServiceUtil.getDisparoEmailTO(to, chave);
		DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
		if (disparoEmail != null && disparoEmail.getId() != null && ValidacaoCampos.validaCampoPreenchido(to.getDestinatarios())) {
			EmailTO emailTO = emailServiceUtil.getEmailTO(assunto, to.getDestinatarios(), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
			emailService.enviarEmail(emailTO);
			emailServiceUtil.salvarHistoricoEnvioEmail(disparoEmail, to.getCooperativa().getId(), to.getDestinatarios());
		}
	}

	private void salvarHistoricoEnvioEmail(DisparoEmail disparoEmail, Integer idCooperativa, String destinatario) {
		DisparoEmailHistorico disparoEmailHistorico = new DisparoEmailHistorico();
		disparoEmailHistorico.setDisparoEmail(disparoEmail);
		disparoEmailHistorico.setDestinatario(destinatario);
		disparoEmailHistorico.setIdCooperativa(idCooperativa);
		disparoEmailHistorico.setEnviado(Boolean.TRUE);
		disparoEmailHistorico.setDataEnvio(Date.from(Instant.now()));
		disparoEmailService.insertDisparoEmailHistorico(disparoEmailHistorico);
	}
}
