package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao;

import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.UFTO;
import java.util.List;

import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.entidade.TipoEndereco;

@Component
public class DadosGeraisValidacaoEndereco {
	
	public static final String VALIDACAO_ENDERECO_OBRIGATORIO_NAO_INFORMADO = "dadosGerais.validacao.enderecoObrigatorioNaoInformado";
	
	public List<ServiceMessage> validaEndereco(Cooperativa c, UFTO UFEndereco, List<ServiceMessage> mensagens, Endereco enderecoAux, TipoEndereco tipoEndereco){

		if(enderecoAux == null) {
			if(Boolean.TRUE.equals(tipoEndereco.getEnderecoPrincipal())) {
				mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Endereço %s</b> é obrigatório".formatted(tipoEndereco.getNome())));				
			}

		} else {
			
			if(Boolean.TRUE.equals(enderecoAux.getTipoEndereco().getEnderecoPrincipal())) {
					if(!ValidacaoCampos.validaCampoPreenchido(UFEndereco)) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>UF do Endereço</b> é obrigatória (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getCep())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>CEP</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					} else if(Boolean.FALSE.equals(ValidacaoCampos.validarCep(enderecoAux.getCep()))) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>CEP</b> inválido (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getEnderecoReferencia())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Endereço</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getIdMunicipio())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Município</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getNumero())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Número</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}
	
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getBairro())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Bairro</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}				
			} 
			
			if((!enderecoAux.getTipoEndereco().getEnderecoPrincipal() 
					&& enderecoAux.getCorrespondenciaDiferente())) {
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getCep())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>CEP</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					} else if(Boolean.FALSE.equals(ValidacaoCampos.validarCep(enderecoAux.getCep()))) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>CEP</b> inválido (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getEnderecoReferencia())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Endereço</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(UFEndereco)) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>UF do Endereço</b> é obrigatória (%s)".formatted(tipoEndereco.getNome())));
					}

										
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getIdMunicipio())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Município</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}
					
					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getNumero())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Número</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}

					if(!ValidacaoCampos.validaCampoPreenchido(enderecoAux.getBairro())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Bairro</b> obrigatório (%s)".formatted(tipoEndereco.getNome())));
					}	

			}
			
		}
		
		return mensagens;
	}

}
