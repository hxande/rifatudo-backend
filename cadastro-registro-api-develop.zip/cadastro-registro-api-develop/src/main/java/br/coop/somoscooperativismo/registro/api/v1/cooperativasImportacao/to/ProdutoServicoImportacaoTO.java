package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProdutoServicoImportacaoTO {
    private Integer id;
    private RamoImportacaoTO ramo;
    private SegmentoImportacaoTO segmento;
    private String descricao;
    private String detalhamento;
    private Boolean ativo;
    private Boolean excluido;
    private Boolean descricaoComplementar;
}
