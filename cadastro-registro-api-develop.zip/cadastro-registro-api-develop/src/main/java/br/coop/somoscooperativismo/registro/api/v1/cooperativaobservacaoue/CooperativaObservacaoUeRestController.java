package br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue.entidade.CooperativaObservacaoUe;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * CooperativaObservacaoUeRestController</b><br>
 * Controlador web resposável pelo tratamento das chamadas web da entidade
 * CooperativaObservacaoUe.
 * 
 * @since 20 de novembro de 2020.
 * @author brunno.stefanini
 */
@RestController
@RequestMapping("/api/v1/cooperativa-observacao-ue")
@Tag(name = "CooperativaObservacaoUe")
public class CooperativaObservacaoUeRestController {

	public static final String REGISTRO_SALVO = "registroSalvo.sucesso";
	public static final String OBSERVACAO_CERTIFICADO_REGISTRO_SALVO = "cooperativa.observacao.certificado.registro.salvo";

	@Autowired
	private CooperativaObservacaoUeService cooperativaObservacaoService;
	@Autowired
	private MessagesService messages;

	/**
	 * Retorna a observação ativa para a cooperativa com o ID indicado.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Observação da UE.
	 */
	@GetMapping("/getObservacaoAtiva/{idCooperativa}")
	@Operation(summary = "retorna a observação ativa")
	public ResponseEntity<ServiceResponse<CooperativaObservacaoUe>> getObservacaoAtiva(
			@PathVariable Integer idCooperativa) {
		return new ResponseEntity<>(new ServiceResponse<CooperativaObservacaoUe>(
				cooperativaObservacaoService.getObservacaoAtiva(idCooperativa)), HttpStatus.OK);
	}

	/**
	 * Retorna o histórico de observações para a cooperativa com o ID indicado.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Histórico de observações.
	 */
	@GetMapping("/getHistorico/{idCooperativa}")
	@Operation(summary = "retorna o histórico de observações")
	public ResponseEntity<ServiceResponse<List<CooperativaObservacaoUe>>> getHistorico(
			@PathVariable Integer idCooperativa) {
		return new ResponseEntity<>(new ServiceResponse<List<CooperativaObservacaoUe>>(
				cooperativaObservacaoService.getHistorico(idCooperativa)), HttpStatus.OK);
	}

	/**
	 * Remove a observação da cooperativa indicada.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Observação excluída.
	 */
	@GetMapping("/excluir/{idCooperativa}/{idObservacao}")
	@Operation(summary = "Realiza a excusão de uma observação na cooperativa")
	public ResponseEntity<ServiceResponse<Void>> excluir(@PathVariable Integer idCooperativa,
			@PathVariable Integer idObservacao) {
		cooperativaObservacaoService.excluir(idCooperativa, idObservacao);
		ServiceMessage message = new ServiceMessage("Observação removida com sucesso.");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	/**
	 * Realiza a gravação de uma observação na cooperativa.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @param observacao    Observação.
	 * @return Observação após gravação.
	 */
	@PostMapping("/salvar")
	@Operation(summary = "Realiza a gravação de uma observação na cooperativa")
	public ResponseEntity<ServiceResponse<CooperativaObservacaoUe>> salvar(
			@RequestBody CooperativaObservacaoTO observacao) {
		ServiceMessage message = new ServiceMessage(messages.get(OBSERVACAO_CERTIFICADO_REGISTRO_SALVO));
		return new ResponseEntity<>(new ServiceResponse<>(
				cooperativaObservacaoService.salvar(observacao.getIdCooperativa(), observacao.getObservacao()),
				message), HttpStatus.OK);
	}

	/**
	 * Retorna se o usuário corrente tem permissão de gravação na cooperativa
	 * indicada.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return true/false.
	 */
	@GetMapping("/temPermissaoDeGravacao/{idCooperativa}")
	@Operation(summary = "Verifica se o usuário corrente tem permissão de gravação.")
	public ResponseEntity<ServiceResponse<Boolean>> temPermissaoDeGravacao(
			@PathVariable Integer idCooperativa) {
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaObservacaoService.temPermissaoDeGravacao(idCooperativa)),
				HttpStatus.OK);
	}

	/**
	 * Retorna se o usuário corrente tem permissão de gravação na cooperativa
	 * indicada.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return true/false.
	 */
	@GetMapping("/temPermissaoDeLeitura/{idCooperativa}")
	@Operation(summary = "Verifica se o usuário corrente tem permissão de leitura.")
	public ResponseEntity<ServiceResponse<Boolean>> temPermissaoDeLeitura(
			@PathVariable Integer idCooperativa) {
		return new ResponseEntity<>(
				new ServiceResponse<>(cooperativaObservacaoService.temPermissaoDeLeitura(idCooperativa)),
				HttpStatus.OK);
	}
}