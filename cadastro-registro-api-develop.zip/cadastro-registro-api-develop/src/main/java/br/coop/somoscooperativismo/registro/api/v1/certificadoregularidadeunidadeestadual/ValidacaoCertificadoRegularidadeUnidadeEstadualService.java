package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Component
public class ValidacaoCertificadoRegularidadeUnidadeEstadualService {
	

	private static final String PERMISSAO_ALTERACAO = "permissao.alteracao.situacao";
	@Autowired private KeycloakService keycloakService;
	@Autowired private MessagesService messages;
		
	public void podeEmitirCertificadoRegularidadeUnidadeEstadual() {
		if (keycloakService.isVerificaPossuiSubPerfil("CO_VIS") ||
					keycloakService.isVerificaPossuiSubPerfil("UE_VIS") ||
					Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("UN_VIS"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
	}
}
