package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class QuadroSocialParametroQuadroImportacaoTO {
    private QuadroSocialParametroQuadroIdentityImportacaoTO idQuadroSocialParametroQuadro;
    private Integer quantidade;
}
