package br.coop.somoscooperativismo.registro.api.v1.documentocliente;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DocumentoTO {
	private Integer id;
}
