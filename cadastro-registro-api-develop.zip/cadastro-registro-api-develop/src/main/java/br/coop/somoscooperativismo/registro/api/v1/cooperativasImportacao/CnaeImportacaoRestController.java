package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import br.coop.somoscooperativismo.registro.api.v1.cnae.CnaeService;
import br.coop.somoscooperativismo.registro.api.v1.cnae.entidade.Cnae;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/cnaes")
public class CnaeImportacaoRestController {

    private final CnaeService cnaeService;

    @GetMapping("/{id}")
    public ResponseEntity<Cnae> getCnae(@PathVariable String id) {
        return ResponseEntity.ok(cnaeService.getCnae(id));
    }

    @GetMapping("/ativos")
    public ResponseEntity<List<Cnae>> getAllAtivos() {
        return ResponseEntity.ok(cnaeService.getAllAtivos());
    }

    @GetMapping("/page")
    public ResponseEntity<Page<Cnae>> getPageByIdAndDescricaoAndClassificacao(@RequestParam(required = false) String id,
                                                @RequestParam(required = false) String descricao,
                                                Pageable pageable) {
        return ResponseEntity.ok(cnaeService.getPageCnaeByIdAndDescricaoAndClassificacao(id, descricao, pageable));
    }
}
