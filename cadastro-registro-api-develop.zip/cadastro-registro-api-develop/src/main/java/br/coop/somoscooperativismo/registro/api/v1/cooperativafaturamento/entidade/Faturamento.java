package br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

/**
 * @author jorge.stefanini
 */
@Entity
@Table(name = "COOPERATIVA_FATURAMENTO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Faturamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_FATURAMENTO")
    private Integer id;

    @Column(name = "NR_ANO")
    private Integer ano;

    @Column(name = "VL_FATURAMENTO", columnDefinition = "money(19,2)")
    private BigDecimal faturamento;

    @Column(name = "VL_FATURAMENTO_EXPORTACAO", columnDefinition = "money(19,2)")
    private BigDecimal faturamentoExportacao;

    @ManyToOne
    @JoinColumn(name = "SQ_COOPERATIVA_APROVACAO")
    @NotAudited
    private Aprovacao aprovacao;

    @ManyToOne
    @JoinColumn(name = "SQ_COOPERATIVA")
    private Cooperativa cooperativa;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public BigDecimal getFaturamento() {
        if(faturamento != null)
            return  BigDecimal.valueOf(faturamento.doubleValue()).setScale(2, RoundingMode.HALF_UP);
        return null;
    }

    public String getFaturamentoStr() {
        return faturamento != null ? getFaturamento().toString() : "";
    }

    public String getFaturamentoExportacaoStr() {
        return faturamentoExportacao != null ? getFaturamentoExportacao().toString(): "";
    }

    public void setFaturamento(BigDecimal faturamento) {
        this.faturamento = faturamento;
    }

    public BigDecimal getFaturamentoExportacao() {
        if(faturamentoExportacao != null)
            return  BigDecimal.valueOf(faturamentoExportacao.doubleValue()).setScale(2, RoundingMode.HALF_UP);
        return null;
    }

    public void setFaturamentoExportacao(BigDecimal faturamentoExportacao) {
        this.faturamentoExportacao = faturamentoExportacao;
    }

    public Aprovacao getAprovacao() {
        return aprovacao;
    }

    public void setAprovacao(Aprovacao aprovacao) {
        this.aprovacao = aprovacao;
    }

    public Cooperativa getCooperativa() {
        return cooperativa;
    }

    public void setCooperativa(Cooperativa cooperativa) {
        this.cooperativa = cooperativa;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Faturamento that = (Faturamento) o;
        return Objects.equals(id, that.id) && Objects.equals(ano, that.ano);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public String getExportacoesDiretas() {
        return this.faturamentoExportacao != null ? "true" : "false";
    }
}
