package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

import br.coop.somoscooperativismo.api.v1.relatorio.RelatorioClient;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioExpressTO;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@EnableAsync
@Service
@RequiredArgsConstructor
public class GerarRelatorioErroValidacaoEmLoteService {

	private static final String ERRO_PLANILHA = "cooperativa.erroPlanilha";
	private static final List<String> CABECALHO = List.of("CNPJ", "BLOCO", "MOTIVO DA FALHA");
	private static final List<Integer> LARGURAS = List.of(20, 50, 150);

	private final RelatorioClient relatorioClient;
	private final MessagesService messages;
	private final VerificarPendenciasParaRelatorioService verificarPendenciasService;

	public byte[] exportarErrosValidacaoEmLote(List<Integer> idsCooperativas) {
		List<CompletableFuture<List<List<String>>>> futures = idsCooperativas.stream()
				.map(this::processarPendenciasCooperativaAsync)
				.toList();

		List<List<String>> linhas = futures.stream()
				.map(CompletableFuture::join)
				.flatMap(List::stream)
				.toList();

		futures = null;

		return gerarArquivoRelatorio(linhas);
	}

	@Async
	public CompletableFuture<List<List<String>>> processarPendenciasCooperativaAsync(Integer idCoop) {
		List<List<String>> linhas = new ArrayList<>();
		List<RetornoRelatorioErroValidacaoEmLoteTO> pendencias = verificarPendenciasService.cooperativasComErroValidacaoEmLote(idCoop);

		pendencias.forEach(pendencia -> linhas.add(criarLinhaRelatorio(pendencia)));
		return CompletableFuture.completedFuture(linhas);
	}

	private List<String> criarLinhaRelatorio(RetornoRelatorioErroValidacaoEmLoteTO pendencia) {
		return List.of(
				pendencia.getCnpj(),
				pendencia.getTitulo(),
				limparTagsHtml(pendencia.getMensagens())
		);
	}

	private String limparTagsHtml(String mensagem) {
		return (mensagem == null || mensagem.isEmpty()) ? "" : mensagem.replaceAll("<b>", "").replaceAll("</b>", "");
	}

	private byte[] gerarArquivoRelatorio(List<List<String>> linhas) {
		if (linhas.isEmpty()) {
			throw new RegraNegocioException("Nenhum dado gerado", HttpStatus.NO_CONTENT);
		}
		try {
			RelatorioExpressTO relatorio = criarRelatorioTO(linhas);
			return relatorioClient.gerarRelatorio(relatorio);
		} catch (Exception e) {
			throw new ErroSistemaException(messages.get(ERRO_PLANILHA), e);
		}
	}

	private RelatorioExpressTO criarRelatorioTO(List<List<String>> linhas) {
		RelatorioExpressTO relatorio = new RelatorioExpressTO();
		relatorio.setCabecalho(CABECALHO);
		relatorio.setDados(linhas);
		relatorio.setLarguras(LARGURAS);
		return relatorio;
	}
}