package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "COOPERATIVA_REGISTRO_COMENTARIO_MOTIVO")
@Getter
@Setter
public class CooperativaRegistroComentarioMotivo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "ID_COMENTARIO", nullable = false)
    private CooperativaRegistroComentario cooperativaRegistroComentario;

    @Column(name = "MOTIVO", length = 500)
    private Long motivo;

}

