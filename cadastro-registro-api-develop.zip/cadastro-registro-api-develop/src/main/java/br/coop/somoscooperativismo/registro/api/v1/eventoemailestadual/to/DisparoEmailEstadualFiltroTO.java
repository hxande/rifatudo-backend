package br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to;

import java.util.List;

public record DisparoEmailEstadualFiltroTO(List<String> ufs, String tipoProcesso, String emailDescricao) {

}
