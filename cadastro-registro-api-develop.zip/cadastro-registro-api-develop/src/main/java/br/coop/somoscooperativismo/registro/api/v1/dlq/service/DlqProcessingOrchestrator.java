package br.coop.somoscooperativismo.registro.api.v1.dlq.service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.registro.api.v1.dlq.entidade.DlqMessage;
import br.coop.somoscooperativismo.registro.api.v1.dlq.mapper.DlqMessageMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DlqProcessingOrchestrator {
    private final DlqMessageMapper dlqMessageMapper;
    private final DlqProcessorService dlqProcessorService;

    public DlqProcessingOrchestrator(DlqMessageMapper dlqMessageMapper, DlqProcessorService dlqProcessorService) {
        this.dlqMessageMapper = dlqMessageMapper;
        this.dlqProcessorService = dlqProcessorService;
    }

    public void processoDlqMessagem(Message message) {
        String messageId = message.getMessageProperties().getMessageId();
        log.info("Iniciando processamento da mensagem ID: {}", messageId);

        try {
            DlqMessage dlqMessage = dlqMessageMapper.mapToDlqMessage(message, null);
            dlqProcessorService.save(dlqMessage);
            log.info("Mensagem processada e persistida com sucesso: {}", messageId);
        } catch (Exception e) {
            log.error("ERRO ao persistir mensagem. Message ID: {}. Detalhes: {}", messageId, e.getMessage(), e);
            throw new ErroSistemaException("Erro ao persistir mensagem ", e);
        }
    }

}
