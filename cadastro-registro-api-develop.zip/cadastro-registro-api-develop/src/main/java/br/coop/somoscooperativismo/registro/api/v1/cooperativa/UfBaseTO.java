package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.util.Set;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UfBaseTO {
	private String uf;
	private Set<Integer> cidades;
}
