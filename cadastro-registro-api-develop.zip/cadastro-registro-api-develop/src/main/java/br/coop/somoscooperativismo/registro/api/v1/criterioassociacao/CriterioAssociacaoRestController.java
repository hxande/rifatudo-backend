package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api/v1/criterio-associacao")
@Tag(name = "CriterioAssociacao")
public class CriterioAssociacaoRestController {

    @Autowired
    CriterioAssociacaoService service;

    @Autowired
    CriterioAssociacaoCooperativaService associacaoCooperativaService;

    @PostMapping("/salvar")
    @Operation(summary = "Salvar critérios de associação")
    public ServiceResponse<List<CriterioAssociacaoTO>> salvarCriterioAssociacao(@RequestBody List<CriterioAssociacaoTO> listaCriterioAssociacaoDTO) {
        ServiceMessage message = new ServiceMessage("Registro(s) salvo(s) com sucesso.");
        return new ServiceResponse<>(service.salvarCriterioAssociacao(listaCriterioAssociacaoDTO),message);
    }


    @PostMapping("/salvar-associacao-cooperativa")
    @Operation(summary = "Salvar uma lista de CriterioAssociacaoCooperativaDTO")
    public List<CriterioAssociacaoCooperativaTO> salvarCriterioAssociacaoCooperativa(@RequestBody List<CriterioAssociacaoCooperativaTO> dtoList) {
        return associacaoCooperativaService.sincronizarRegistros(dtoList);
    }


    @PutMapping("/editar-associacao-cooperativa/{id}")
    @Operation(summary = "Editar um CriterioAssociacaoCooperativa por ID")
    public ResponseEntity<String> editarCriterioAssociacaoCooperativa(@PathVariable Integer id, @RequestBody CriterioAssociacaoCooperativaTO dto) {

        boolean editado = associacaoCooperativaService.editarCriterioAssociacaoCooperativa(id, dto);
        if (editado) {
            return ResponseEntity.ok("CriterioAssociacaoCooperativa editado com sucesso");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/listar-associacao-cooperativa/sqCooperativa/{sqCooperativa}")
    @Operation(summary = "Listar todos os CriterioAssociacaoCooperativa por sqCooperativa")
    public ServiceResponse<List<CriterioAssociacaoCooperativaResponseTO>> listarCriterioAssociacaoCooperativaPorCooperativa(@PathVariable Integer sqCooperativa) {
        return new ServiceResponse<>(associacaoCooperativaService.listarCriterioAssociacaoAtivoCooperativaPorCooperativa(sqCooperativa));
    }

    @GetMapping("/listar-descricao-associacao-cooperativa/sqCooperativa/{sqCooperativa}")
    @Operation(summary = "Listar todos os CriterioAssociacaoCooperativa por sqCooperativa")
    public List<CriterioAssociacaoCooperativaReadOnlyTO> listarCriterioAssociacaoCooperativaPorCooperativaDescricao(@PathVariable Integer sqCooperativa) {
        return associacaoCooperativaService.listarCriterioAssociacaoCooperativaPorCooperativaDescricao(sqCooperativa);
    }

    @GetMapping("/listar-ativos/ramo/{sqRamo}")
    @Operation(summary = "Obter lista de CriterioAssociacao ativos por sqRamo")
    public ServiceResponse<List<CriterioAssociacaoTO>> listarCriterioAssociacaoAtivosPorRamo(@PathVariable Integer sqRamo) {
        return new ServiceResponse<>(service.listarCriterioAssociacaoAtivosPorRamo(sqRamo));
    }
    
    @GetMapping("/listar/ramo/{sqRamo}")
    @Operation(summary = "Obter lista de CriterioAssociacao por sqRamo")
    public ServiceResponse<List<CriterioAssociacaoTO>> listarCriterioAssociacaoPorRamo(@PathVariable Integer sqRamo) {
        return new ServiceResponse<>(service.listarCriterioAssociacaoPorRamo(sqRamo));
    }

    @GetMapping("/listar-filtro/ramo/{sqRamo}")
    @Operation(summary = "Obter lista de CriterioAssociacao por sqRamo")
    public ServiceResponse<List<CriterioAssociacaoTO>> listarCriterioAssociacaoPorRamoFiltro(@PathVariable Integer sqRamo) {
        return new ServiceResponse<>(service.listarCriterioAssociacaoPorRamoFiltro(sqRamo));
    }
    
    @PutMapping("/ativar-desativar")
    @Operation(summary = "Ativar/Desativar CriterioAssociacao por sqRamo")
    public ServiceResponse<Void> desativarCriterioAssociacaoRamo(@RequestBody CriterioAssociacaoRamoTO criterioRamoTO){
        String ativacao = Boolean.TRUE.equals(criterioRamoTO.getAtivo()) ? "ativado(s)" : "desativado(s)";
    	ServiceMessage message = new ServiceMessage("Registro(s) " + ativacao + " com sucesso.");
    	service.ativarDesativarCriterioAssociacaoRamo(criterioRamoTO);
    	return new ServiceResponse<>(message);
    }
    
    @GetMapping("/listar-ramos")
    @Operation(summary = "Obter lista de Ramos para CriterioAssociacao")
    public ServiceResponse<Page<CriterioAssociacaoRamoTO>> listarRamosCriterioAssociacao(Pageable pageable){
    	return new ServiceResponse<>(service.listarRamosCriterioAssociacao(pageable));
    }
    

}
