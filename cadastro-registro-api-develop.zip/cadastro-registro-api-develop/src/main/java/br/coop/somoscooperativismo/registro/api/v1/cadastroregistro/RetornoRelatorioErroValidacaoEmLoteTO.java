package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RetornoRelatorioErroValidacaoEmLoteTO {

	private String cnpj;
	private String titulo;
	private String mensagens;

}
