package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import lombok.Data;

@Data
public class CriterioAssociacaoCooperativaResponseTO {
    private Integer id;
    private Integer sqCooperativa;
    private Integer ramoId;
    private String  nomeCriterioAssociacao;
    private Integer sqCriterioAssociacao;

    private Boolean criterioAssociacaoCooperativaAtivo; // Campo ativo da CriterioAssociacaoCooperativa
    private Boolean criterioAssociacaoAtivo; // Campo ativo da CriterioAssociacao
    private Boolean criterioAssociacaoExcluido; // Campo excluido da CriterioAssociacao

}
