package br.coop.somoscooperativismo.registro.api.v1.email;

public class UsuarioEmailTO {
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
