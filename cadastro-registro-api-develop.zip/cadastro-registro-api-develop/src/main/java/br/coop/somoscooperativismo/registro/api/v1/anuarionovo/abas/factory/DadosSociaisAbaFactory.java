package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.ocbcommonsapi.web.JsonUtil;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaCampoBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.SelectButtonOptionBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.SelectButtonValueBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaCampos;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaDataInterface;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.EstruturaIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.InputTypeEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.to.QuadroSocialAnuarioTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DadosSociaisAbaFactory implements AbaFactory {

    private final PessoaJuridicaService pessoaJuridicaService;

    public DadosSociaisAbaFactory(PessoaJuridicaService pessoaJuridicaService) {
        this.pessoaJuridicaService = pessoaJuridicaService;
    }

    @Override
    public NomeAbaEnum getNomeAba() {
        return NomeAbaEnum.DADOS_SOCIAIS;
    }

    @Override
    public List<AbaDataInterface> build(Object quadro) {

        QuadroSocialAnuarioTO quadroSocial = (QuadroSocialAnuarioTO) quadro;

        if (!quadroSocial.getDadosComplementares().isEmpty()) {
            return List.of(
                    buildQuantidadeCooperados((QuadroSocialAnuarioTO) quadro),
                    buildCooperadosAdicionais((QuadroSocialAnuarioTO) quadro),
                    buildQuantidadeEmpregados((QuadroSocialAnuarioTO) quadro),
                    buildEmpregadosAdicionais((QuadroSocialAnuarioTO) quadro),
                    buildDadosComplementares(((QuadroSocialAnuarioTO) quadro).getDadosComplementares())
            );
        } else {
            return List.of(
                    buildQuantidadeCooperados((QuadroSocialAnuarioTO) quadro),
                    buildCooperadosAdicionais((QuadroSocialAnuarioTO) quadro),
                    buildQuantidadeEmpregados((QuadroSocialAnuarioTO) quadro),
                    buildEmpregadosAdicionais((QuadroSocialAnuarioTO) quadro)
            );
        }

    }

    public AbaDataInterface buildQuantidadeCooperados(QuadroSocialAnuarioTO quadro) {

        AbaBuilder aba = new AbaBuilder("quantidadeCooperados", NomeQuadroEnum.QUANTIDADE_COOPERADOS.toString(), quadro.getId(), null, "Quantidade de Cooperados")
                .subTitle("")
                .info("Esse é um informativo que pode ser mostrado.");

        if (ValidacaoCampos.validaCampoPreenchido(quadro.getListaQuadroSocialUFTO()) && quadro.getListaQuadroSocialUFTO().size() > 1) {
            buildQuadroSocialCooperadosPorUF(quadro, aba);
        } else {
            buildQuadroSocialCooperados(quadro, aba);
        }

        return aba.build();
    }

    protected void buildQuadroSocialCooperados(QuadroSocialAnuarioTO quadro, AbaBuilder aba) {
        List<AbaCampos> campos = new ArrayList<>();

        String uf = pessoaJuridicaService.buscarUfByIdPj(quadro.getIdPessoaJuridica());

        campos.add(
                AbaCampoBuilder.divisor("cooperadosUF", "cooperadosUF", quadro.getId(), null, "", uf.toUpperCase())
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("cooperadosHomensUF", "cooperadosHomensUF", quadro.getId(), null, "Homens")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getCooperadosHomens())
                        .required(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("cooperadosMulheresUF", "cooperadosMulheresUF", quadro.getId(), null, "Mulheres")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getCooperadosMulheres())
                        .required(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("cooperadosPFUF", "cooperadosPFUF", quadro.getId(), null, "Cooperados Pessoa Física")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getCooperadosPF())
                        .required(false)
                        .disabled(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("cooperadosPJUF", "cooperadosPJUF", quadro.getId(), null, "Cooperados Pessoa Jurídica")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getCooperadosPJ())
                        .required(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("cooperadosTotalUF", "cooperadosTotalUF", quadro.getId(), null, "Total")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getCooperadosTotal())
                        .disabled(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("cooperadosAtivosUF", "cooperadosAtivosUF", quadro.getId(), null, "Ativos")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getCooperadosAtivos())
                        .build()
        );

        aba.addCampos(campos);
    }

    protected static void buildQuadroSocialCooperadosPorUF(QuadroSocialAnuarioTO quadro, AbaBuilder aba) {
        quadro.getListaQuadroSocialUFTO().forEach(qsUF -> {
            List<AbaCampos> campos = new ArrayList<>();

            campos.add(AbaCampoBuilder.divisor("dividerCooperadosUF", "dividerCooperadosUF", qsUF.getId(), null, "", qsUF.getUf())
                    .build());

            campos.add(
                    AbaCampoBuilder.input("cooperadosHomensUF", "cooperadosHomensUF", qsUF.getId(), null, "Homens")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getCooperadosHomensUF())
                            .required(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("cooperadosMulheresUF", "cooperadosMulheresUF", qsUF.getId(), null, "Mulheres")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getCooperadosMulheresUF())
                            .required(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("cooperadosPFUF", "cooperadosPFUF", qsUF.getId(), null, "Cooperados Pessoa Física")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getCooperadosPFUF())
                            .required(true)
                            .disabled(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("cooperadosPJUF", "cooperadosPJUF", qsUF.getId(), null, "Cooperados Pessoa Jurídica")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getCooperadosPJUF())
                            .required(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("cooperadosTotalUF", "cooperadosTotalUF", qsUF.getId(), null, "Total")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getCooperadosTotalUF())
                            .disabled(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("cooperadosAtivosUF", "cooperadosAtivosUF", qsUF.getId(), null, "Ativos")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getCooperadosAtivosUF())
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("uf", "uf", qsUF.getId(), null, "UF")
                            .inputType(InputTypeEnum.TEXT.getType())
                            .value(qsUF.getUf())
                            .required(true)
                            .visible(false)
                            .build()
            );

            aba.addCampos(campos);
        });
    }

    public AbaDataInterface buildQuantidadeEmpregados(QuadroSocialAnuarioTO quadro) {

        AbaBuilder aba = new AbaBuilder("quantidadeEmpregados", NomeQuadroEnum.QUANTIDADE_EMPREGADOS.toString(), quadro.getId(), null, "Quantidade de Empregados")
                .subTitle("")
                .info("Esse é um informativo que pode ser mostrado.");

        if (ValidacaoCampos.validaCampoPreenchido(quadro.getListaQuadroSocialUFTO()) && quadro.getListaQuadroSocialUFTO().size() > 1) {

                buildQuadroSocialEmpregadosPorUF(quadro, aba);
        } else {
            buildQuadroSocialEmpregados(quadro, aba);
        }

        return aba.build();

    }

    protected void buildQuadroSocialEmpregados(QuadroSocialAnuarioTO quadro, AbaBuilder aba) {
        List<AbaCampos> campos = new ArrayList<>();
        String uf = pessoaJuridicaService.buscarUfByIdPj(quadro.getIdPessoaJuridica());


        campos.add(
                AbaCampoBuilder.divisor("empregadosUF", "empregadosUF", quadro.getId(), null, "", uf.toUpperCase())
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("empregadosHomensUF", "empregadosHomensUF", quadro.getId(), null, "Homens")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getEmpregadosHomens())
                        .required(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("empregadosMulheresUF", "empregadosMulheresUF", quadro.getId(), null, "Mulheres")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getEmpregadosMulheres())
                        .required(true)
                        .build()
        );

        campos.add(
                AbaCampoBuilder.input("empregadosTotalUF", "empregadosTotalUF", quadro.getId(), null, "Total")
                        .inputType(InputTypeEnum.NUMBER.getType())
                        .value(quadro.getEmpregadosTotal())
                        .disabled(true)
                        .build()
        );

        aba.addCampos(campos);
    }

    protected static void buildQuadroSocialEmpregadosPorUF(QuadroSocialAnuarioTO quadro, AbaBuilder aba) {
        quadro.getListaQuadroSocialUFTO().forEach(qsUF -> {
            List<AbaCampos> campos = new ArrayList<>();

            campos.add(AbaCampoBuilder.divisor("dividerEmpregadosUF", "dividerEmpregadosUF", qsUF.getId(), null, "", qsUF.getUf())
                    .build());

            campos.add(
                    AbaCampoBuilder.input("empregadosHomensUF", "empregadosHomensUF", qsUF.getId(), null, "Homens")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getEmpregadosHomensUF())
                            .required(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("empregadosMulheresUF", "empregadosMulheresUF", qsUF.getId(), null, "Mulheres")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getEmpregadosMulheresUF())
                            .required(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("empregadosTotalUF", "empregadosTotalUF", qsUF.getId(), null, "Total")
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .value(qsUF.getEmpregadosTotalUF())
                            .disabled(true)
                            .build()
            );

            campos.add(
                    AbaCampoBuilder.input("uf", "uf", qsUF.getId(), null, "UF")
                            .inputType(InputTypeEnum.TEXT.getType())
                            .value(qsUF.getUf())
                            .required(true)
                            .visible(false)
                            .build()
            );

            aba.addCampos(campos);
        });
    }

    public AbaDataInterface buildCooperadosAdicionais(QuadroSocialAnuarioTO quadro) {

        AbaBuilder aba = new AbaBuilder("cooperadosAdicionais", NomeQuadroEnum.COOPERADOS_ADICIONAIS.toString(), quadro.getId(), null, "Cooperados - Escolaridade");

        List<AbaCampos> campos = new ArrayList<>();
        quadro.getListaCooperadosDadosAdicionais().forEach(item -> {
            campos.add(
                    AbaCampoBuilder.input("cooperadoExtra_" + item.getIdParametroQuadroSocialCooperado(),
                                    "quantidade",
                                    quadro.getId(),
                                    item.getIdParametroQuadroSocialCooperado(),
                                    item.getNomeParametroQuadroSocialCooperado())
                            .value(item.getQuantidade())
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .required(Boolean.TRUE.equals(item.getObrigatorio()))
                            .build()
            );
        });

        aba.addCampos(campos);

        return aba.build();
    }

    public AbaDataInterface buildEmpregadosAdicionais(QuadroSocialAnuarioTO quadro) {

        AbaBuilder aba = new AbaBuilder("empregadosAdicionais", NomeQuadroEnum.EMPREGADOS_ADICIONAIS.toString(), quadro.getId(), null, "Empregados - Escolaridade");

        List<AbaCampos> campos = new ArrayList<>();
        quadro.getListaEmpregadosDadosAdicionais().forEach(item -> {
            campos.add(
                    AbaCampoBuilder.input("empregadoExtra_" + item.getIdParametroQuadroSocial(),
                                    "quantidade",
                                    quadro.getId(),
                                    item.getIdParametroQuadroSocial(),
                                    item.getNomeParametroQuadroSocial())
                            .value(obterValor(item.getQuantidade()))
                            .inputType(InputTypeEnum.NUMBER.getType())
                            .required(Boolean.TRUE.equals(item.getObrigatorio()))
                            .build()
            );
        });

        aba.addCampos(campos);

        return aba.build();
    }

    //Desempenho
    public AbaDataInterface buildDadosComplementares(List<EstruturaIntegracaoTO> dadosComplementares) {
        AbaBuilder aba = new AbaBuilder("dadosComplementares", NomeQuadroEnum.DADOS_COMPLEMENTARES.toString(), null, null, "Dados Complementares");

        dadosComplementares.forEach(item -> {
            List<AbaCampos> campos = new ArrayList<>();

            item.getGrupos().forEach(grupo -> {
                if (grupo.getNome() != null) {
                    campos.add(
                            AbaCampoBuilder.divisor("dadosComplementares" + grupo.getId(),
                                            grupo.getNome(),
                                            grupo.getId(),
                                            null, "", grupo.getNome())
                                    .value(grupo.getNome())
                                    .parametroIntegracao(null)
                                    .required(false)
                                    .build()
                    );
                }
                grupo.getParametros().forEach(parametro -> {
                    if (parametro.getTipoUnidade().equals("NUMERO")) {
                        campos.add(
                                AbaCampoBuilder.input("parametro" + parametro.getIdParametro(),
                                                "parametro",
                                                parametro.getIdParametro(),
                                                null,
                                                parametro.getNomeParametro())
                                        .value(obterValor(parametro.getValor()))
                                        .mask((parametro.getQuantidadeCasasUnidade() != null && parametro.getQuantidadeCasasUnidade() > 0 ? "currency" : null), parametro.getSiglaUnidade())
                                        .hasMask((parametro.getQuantidadeCasasUnidade() != null && parametro.getQuantidadeCasasUnidade() > 0))
                                        .parametroIntegracao(JsonUtil.toJson(parametro))
                                        .inputType(InputTypeEnum.NUMBER.getType())
                                        .required(parametro.isCampoObrigatorio())
                                        .build()
                        );
                    }

                    if (parametro.getTipoUnidade().equals("BOOLEANO")) {

                        campos.add(
                                AbaCampoBuilder.selectButton("parametro" + parametro.getIdParametro(), "parametro", parametro.getIdParametro(), null, parametro.getNomeParametro())
                                        .value(new SelectButtonValueBuilder(
                                                List.of(
                                                        new SelectButtonOptionBuilder("Sim", "1"),
                                                        new SelectButtonOptionBuilder("Não", "0")
                                                ),
                                                obterValor(parametro.getValor())
                                        ))
                                        .parametroIntegracao(JsonUtil.toJson(parametro))
                                        .required(parametro.isCampoObrigatorio())
                                        .build()
                        );
                    }
                });
            });

            aba.addCampos(campos);
        });

        return aba.build();
    }

}
