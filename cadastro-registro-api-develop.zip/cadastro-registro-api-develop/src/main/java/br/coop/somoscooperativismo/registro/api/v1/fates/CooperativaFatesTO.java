package br.coop.somoscooperativismo.registro.api.v1.fates;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.BaseAdapterTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CooperativaFatesTO extends BaseAdapterTO {
    private BigDecimal valorFates;
    private List<Integer> finalidadesFates;
}
