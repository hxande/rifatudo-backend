package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.entidade.DadosGerais;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.DadosGeraisService;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/manutencao-dados-gerais")
public class ManutencaoDadosGeraisImportacaoRestController {

    private final DadosGeraisService dadosGeraisService;

    @PatchMapping
    public ResponseEntity<Boolean> atualizar(@RequestBody DadosGerais dadosGerais) {
        boolean successfully = dadosGeraisService.salvarDadosGeraisManutencao(dadosGerais, false, true);
        return ResponseEntity.ok(successfully);
    }

    @GetMapping("/validacoes/{idCooperativa}")
    public ResponseEntity<ValidacaoPrimeiroRegistroTO> getValidacoes(@PathVariable Integer idCooperativa){
        ValidacaoPrimeiroRegistroTO validacao = dadosGeraisService.validarDadosGeraisManutencao(idCooperativa, true);
        return ResponseEntity.ok(validacao);
    }

}
