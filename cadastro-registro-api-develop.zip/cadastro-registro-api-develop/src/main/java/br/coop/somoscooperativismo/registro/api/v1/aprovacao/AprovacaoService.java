package br.coop.somoscooperativismo.registro.api.v1.aprovacao;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import br.coop.somoscooperativismo.registro.api.v1.cadastroregistro.StatusValidacaoEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.FaturamentoService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade.Faturamento;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.CooperativaValidacaoLoteService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.entidade.CooperativaValidacaoLote;
import br.coop.somoscooperativismo.registro.api.v1.documentocliente.DocumentoClient;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoService;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.MandatoMembroService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.PeriodoAtualizacaoService;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import org.jboss.logging.Logger;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.SituacaoCooperativaEnum;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class AprovacaoService {
	
	private static final Logger LOGGER = Logger.getLogger(AprovacaoService.class);
	
	private static final String PERMISSAO_ALTERACAO = "permissao.alteracao.situacao";
	private static final String APROVACAO_NAO_ENCONTRADA = "Aprovação não encontrada, crie antecipadamente!";
	private static final String PERMISSAO_NEGADA = "Permissão negada para este tipo de ação";

	
	private final AprovacaoRepository aprovacaoRepository;

	private final PeriodoAtualizacaoService periodoService;
	private final CooperativaService cooperativaService;
	
	private final QuadroSocialService quadroSocialService;
	
	private final FaturamentoService faturamentoService;

	private final KeycloakService keycloakService;

	
	private final DocumentoClient documentoCliente;
	
	private final MandatoService mandatoService;
	
	
	private final MandatoMembroService membroService;

	
	private final CooperativaValidacaoLoteService cooperativaValidacaoLoteService;
	
	private final MessagesService messages;

	private final CooperativaPendenciaService cooperativaPendenciaService;
	
	public AprovacaoService(AprovacaoRepository aprovacaoRepository,
			PeriodoAtualizacaoService periodoService,
			@Lazy CooperativaService cooperativaService,
			QuadroSocialService quadroSocialService,
			FaturamentoService faturamentoService,
			KeycloakService keycloakService,
			DocumentoClient documentoCliente,
			MandatoService mandatoService,
			MandatoMembroService membroService,
			CooperativaValidacaoLoteService cooperativaValidacaoLoteService,
			MessagesService messages,
			@Lazy CooperativaPendenciaService cooperativaPendenciaService
			) {
		this.aprovacaoRepository = aprovacaoRepository;
		this.periodoService = periodoService;
		this.cooperativaService = cooperativaService;
		this.quadroSocialService = quadroSocialService;
		this.faturamentoService = faturamentoService;
		this.keycloakService = keycloakService;
		this.documentoCliente = documentoCliente;
		this.mandatoService = mandatoService;
		this.membroService = membroService;
		this.cooperativaValidacaoLoteService = cooperativaValidacaoLoteService;
		this.messages = messages;
		this.cooperativaPendenciaService = cooperativaPendenciaService;
	}
	
	public Aprovacao getUltimaAtualizacaoCooperativa(Integer idCooperativa) {
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
		List<Aprovacao> ap = aprovacaoRepository.getUltimaAtualizacaoCooperativa(c.getId(), PageRequest.of(0, 1));

		c = null;

		return ValidacaoCampos.validaCampoPreenchido(ap) ? ap.get(0) : null;
	}

	public Aprovacao getAprovacaoAtualCooperativa(Integer idCooperativa) {
		Integer anoCorrente = periodoService.obterAno(idCooperativa);
		
		Aprovacao ap = aprovacaoRepository.obterAprovacaoCooperativa(anoCorrente, idCooperativa);
		
		if(ap == null) {
			throw new RegraNegocioException(APROVACAO_NAO_ENCONTRADA);
		}

		anoCorrente = null;

		return ap;
	}

	public Aprovacao getAprovacao(Integer idCooperativa) {
		Integer anoCorrente = periodoService.obterAno(idCooperativa);

		return aprovacaoRepository.obterAprovacaoCooperativa(anoCorrente, idCooperativa);
	}
	
	public Aprovacao getAprovacaoSemException(Integer idCooperativa) {
		Integer anoCorrente = periodoService.obterAnoSemException(idCooperativa);

		return aprovacaoRepository.obterAprovacaoCooperativa(anoCorrente, idCooperativa);

	}
	
	public boolean criarAprovacaoAtualCooperativa(Integer idCooperativa) {
		if (!(verificaPossuiSubPerfilCO() ||
				verificaPossuiSubPerfilUE() ||
				verificaPossuiSubPerfilUN())) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}
		
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
		Integer anoCorrente = periodoService.obterAno(c.getId());
		boolean primeiraVezSubmetido = false;
			

		Aprovacao ap = aprovacaoRepository.obterAprovacaoCooperativaSemDataAtualizacao(anoCorrente, c.getId());
		
		if(ap == null) {
			ap = new Aprovacao();
			ap.setCooperativa(c);
			ap.setAno(anoCorrente);
			defineUsuarioAprovacao(ap);
			if(verificaTipoEntidadeNacionalOuEstadual()) {
				ap.setDataAtualizacao(new Date());
			}
			aprovacaoRepository.save(ap);
			primeiraVezSubmetido = true;
		}

		return primeiraVezSubmetido;
	}

	private boolean verificaPossuiSubPerfilCO () {
		return keycloakService.isVerificaPossuiSubPerfil("CO_GES") || keycloakService.isVerificaPossuiSubPerfil("CO_ANA");
	}

	private boolean verificaPossuiSubPerfilUE () {
		return keycloakService.isVerificaPossuiSubPerfil("UE_GES") || keycloakService.isVerificaPossuiSubPerfil("UE_ANA_DADOS") ||
				keycloakService.isVerificaPossuiSubPerfil("UE_ANA_LEGALIDADE");
	}

	private boolean verificaPossuiSubPerfilUN () {
		return keycloakService.isVerificaPossuiSubPerfil("UN_GES") || keycloakService.isVerificaPossuiSubPerfil("UN_ANA");
	}

	private void salvarStatusValidacaoLoteCooperativa(Integer cooperativaId, StatusValidacaoEnum status, String descricaoErro) {
		Integer anoReferencia = LocalDate.now().getYear();
		Cooperativa c = cooperativaService.getCooperativa(cooperativaId);
		CooperativaValidacaoLote cooperativaValidacaoLote =
				cooperativaValidacaoLoteService.findByCooperativaIdAndAnoReferencia(cooperativaId, anoReferencia)
						.orElseGet(CooperativaValidacaoLote::new);

		cooperativaValidacaoLote.setCooperativa(c);
		cooperativaValidacaoLote.setDataValidacao(new Date());
		cooperativaValidacaoLote.setAnoReferencia(anoReferencia);
		cooperativaValidacaoLote.setUsuarioValidacao(keycloakService.getUsername());
		cooperativaValidacaoLote.setStatusValidacao(status.name());
		cooperativaValidacaoLote.setDescricaoValidacao(descricaoErro);

		cooperativaValidacaoLoteService.saveOrUpdate(cooperativaValidacaoLote);

		anoReferencia = null;
		c = null;
	}


	public boolean criarAprovacaoAtualCooperativaEmLote(Integer idCooperativa, boolean validado) {
		if (!(verificaPossuiSubPerfilCO() ||
				verificaPossuiSubPerfilUE() ||
				verificaPossuiSubPerfilUN())) {

			salvarStatusValidacaoLoteCooperativa( idCooperativa, StatusValidacaoEnum.FALHA_VALIDACAO,  "Falha na permissão (SubPerfil) para alteração");

			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}

		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
		Integer anoCorrente = periodoService.obterAno(c.getId());
		boolean primeiraVezSubmetido = false;


		Aprovacao ap = aprovacaoRepository.obterAprovacaoCooperativaSemDataAtualizacao(anoCorrente, c.getId());

		try {
			if (ap == null) {
				ap = new Aprovacao();
				ap.setCooperativa(c);
				ap.setAno(anoCorrente);
				if (verificaTipoEntidadeNacionalOuEstadual()) {
					ap.setDataAtualizacao(new Date());
				}
				defineUsuarioAprovacao(ap);
				aprovacaoRepository.save(ap);
				primeiraVezSubmetido = true;
			} else {
				if (keycloakService.isTipoEntidadeNacional() || (keycloakService.isTipoEntidadeEstadual() && ap.getDataAtualizacao() == null && validado)) {
					ap.setDataAtualizacao(new Date());
				}
				defineUsuarioAprovacao(ap);
				aprovacaoRepository.save(ap);

			}
			aprovarDadosCoopLote( idCooperativa,  c);
		}catch(IllegalArgumentException | OptimisticLockingFailureException  | RegraNegocioException e){
			String descricaoErro = "Falha ao salvar aprovação - dados inconsistentes ";
			LOGGER.error(descricaoErro,e);
			salvarStatusValidacaoLoteCooperativa( idCooperativa, StatusValidacaoEnum.FALHA_VALIDACAO, (descricaoErro + e.getCause()));

		}

		c = null;
		anoCorrente = null;

		return primeiraVezSubmetido;
	}

	public Aprovacao atualizarDataAprovacao(Integer idCooperativa) {
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
		Integer anoCorrente = periodoService.obterAno(c.getId());
		
		Aprovacao ap = aprovacaoRepository.obterAprovacaoCooperativa(anoCorrente, c.getId());
		if(ap == null) {
			throw new RegraNegocioException(APROVACAO_NAO_ENCONTRADA);
		}
		
		// TODO Implementar as verificações para atualização da data de APROVAÇÃO
		// => Do passo 2 para o 3 e na manutenção

		ap.setDataAtualizacao(new Date());
		defineUsuarioAprovacao(ap);
		ap = aprovacaoRepository.save(ap);

		c = null;
		anoCorrente = null;

		return ap;
	}

	public Aprovacao atualizaSeAindaNaoAtualizou(Integer idCooperativa) {
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
		Integer anoCorrente = periodoService.obterAno(c.getId());

		Aprovacao ap = aprovacaoRepository.obterAprovacaoCooperativaSemDataAtualizacao(anoCorrente, c.getId());
		if(ap == null) {
			salvarStatusValidacaoLoteCooperativa( idCooperativa, StatusValidacaoEnum.FALHA_VALIDACAO,   APROVACAO_NAO_ENCONTRADA);

			throw new RegraNegocioException(APROVACAO_NAO_ENCONTRADA);
		}

		// TODO Implementar as verificações para atualização da data de APROVAÇÃO
		// => Do passo 2 para o 3 e na manutenção
		if(ap.getDataAtualizacao() == null) {
			ap.setDataAtualizacao(new Date());
			defineUsuarioAprovacao(ap);
			ap = aprovacaoRepository.save(ap);
		}

		c = null;
		anoCorrente = null;

		return ap;
	}
	
	
	public void aprovarTodosDadosCooperativa(Integer idCooperativa) {
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
		// Somente nessas ocasiões o progresso é permitido
		if((verificaTipoEntidadeNacionalOuEstadual()) &&
		   (ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1 == (c.getProgressoMicro())
				   || ProgressoMicroEnum.EMISSAO_COM_APONTAMENTOS_6_2 == (c.getProgressoMicro())
				   || ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1 == (c.getProgressoManutencaoMicro()))) {
			aprovarDadosCoop(idCooperativa, c);
		}

		c = null;
	}

	// Fluxo apenas para primeiro subissão UN/UE
	public void aprovarTodosDadosCooperativaFluxoUEUN(Integer idCooperativa) {
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);

		if(keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional()) {
			aprovarDadosCoop(idCooperativa, c);
		}

		c = null;
	}

	private boolean verificaTipoEntidadeNacionalOuEstadual() {
		return keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional();
	}

	private void aprovarDadosCoop(Integer idCooperativa, Cooperativa c) {
		Aprovacao ap = getAprovacao(c.getId());
		Integer anoCiclo = periodoService.obterAno(c.getPessoaJuridica().getRamo());

		if (ap != null) {
			// ################## Quadros Sociais ######################
			List<QuadroSocial> quadrosSociais = quadroSocialService.getQuadroSociaisManutencao(idCooperativa);
			this.aprovaQuadroSocial(anoCiclo, quadrosSociais, ap);
			// #################### Faturamentos #######################
			List<Faturamento> faturamentos = faturamentoService.getFaturamentosPorCooperativaNoCiclo(idCooperativa);
			this.aprovaFaturamento(anoCiclo, faturamentos, ap);
			// #################### GovernancaTO #########################
			List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(idCooperativa);
			this.aprovaMandatos(mandatos, ap);
			// #################### Documentos #########################
			this.documentoCliente.aprovaDocumentacao(idCooperativa, ap);
		}

		ap = null;
		anoCiclo = null;
	}


	public void aprovarDadosCoopLote(Integer idCooperativa, Cooperativa c) {
		Aprovacao ap = getAprovacao(c.getId());
		Integer anoCiclo = periodoService.obterAno(c.getPessoaJuridica().getRamo());

		if (ap != null) {
			// ################## Quadros Sociais ######################
			List<QuadroSocial> quadrosSociais = quadroSocialService.getQuadroSociaisManutencao(idCooperativa);
			this.aprovaQuadroSocialCicloAtual(quadrosSociais, ap);
			// #################### Faturamentos #######################
			List<Faturamento> faturamentos = faturamentoService.getFaturamentosPorCooperativaNoCiclo(idCooperativa);
			this.aprovaFaturamento(anoCiclo, faturamentos, ap);
			// #################### GovernancaTO #########################
			List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(idCooperativa);
			this.aprovaMandatos(mandatos, ap);
			// #################### Documentos #########################
			// this.documentoCliente.aprovaDocumentacao(idCooperativa, ap);
		}

		ap = null;
		anoCiclo = null;
	}

	private void aprovaMandatos(List<Mandato> mandatos, Aprovacao ap) {
		if(mandatos != null) {
			mandatos.forEach(mandato -> {
				this.aprovaMembros(mandato, ap);
				mandato.setAprovacao(ap);
				mandato.setDataAtualizacao(new Date());
				mandatoService.updateMandatoAprovacao(mandato);

			});
		
		}
	}

	private void aprovaMembros(Mandato mandato, Aprovacao ap) {
		List<MandatoMembro> membros = membroService.getMandatosMembroPorMandato(mandato.getId());
		membros.forEach(membro -> {
			if(membro.getAprovacao() == null) {
				membro.setAprovacao(ap);
				membroService.updateMandatoMembro(membro);
			}
		});
		
	}

	/**
	 * Aprovando todos quadros que não estão aprovados e não sejam o quadro social do ciclo (atual)
	 */
	private void aprovaQuadroSocial(Integer anoCicloCorrente, List<QuadroSocial> quadrosSociais, Aprovacao ap) {
		if(quadrosSociais != null) {
			quadrosSociais.forEach(qs->{
				if(qs.getId() != null && qs.getAprovacao() == null && !anoCicloCorrente.equals(qs.getAno())) {
					qs.setAprovacao(ap);
					quadroSocialService.createQuadroSocialManutencao(qs);
				}
			});
		}
	}

	/**
	 * Aprovando todos quadros que não estão aprovados e que sejam o quadro social do ciclo (atual)
	 */
	private void aprovaQuadroSocialCicloAtual(List<QuadroSocial> quadrosSociais, Aprovacao ap) {
		if(quadrosSociais != null) {
			quadrosSociais.forEach(qs->{
				if(qs.getId() != null && qs.getAprovacao() == null ) {
					qs.setAprovacao(ap);
					quadroSocialService.createQuadroSocialManutencao(qs);
				}
			});
		}

	}
	
	private void aprovaFaturamento(Integer anoCicloCorrente, List<Faturamento> faturamentos, Aprovacao ap) {
		if(faturamentos != null) {
			faturamentos.forEach(f-> {
				if(f.getId() != null && f.getAprovacao() == null && !anoCicloCorrente.equals(f.getAno())) {
					f.setAprovacao(ap);
					faturamentoService.update(f);
				}
			});
		}
	}
	
	public Aprovacao getUltimaAtualizacao(Integer idCooperativa) {
		if(idCooperativa != null) {
			List<Aprovacao> listAprovacoes = aprovacaoRepository.getUltimasAprovacoes(idCooperativa);
			return (!listAprovacoes.isEmpty()) ? listAprovacoes.get(0) : null;
		}	
		return null;
	}
	
	public Aprovacao getAtualizacaoCooperativaAnoVigente(Integer idCooperativa) {
		if(idCooperativa != null) {
			LocalDate data = LocalDate.now();
			Integer ano = data.getYear();
			return aprovacaoRepository.obterAprovacaoCooperativa(ano, idCooperativa);
		}	
		
		return null;
	}

	
	public Aprovacao getAprovacaoCooperativaAnoAnterior(Integer idCooperativa) {
		LocalDate date = LocalDate.now();
		Integer ano = (date.getYear() - 1); // ano anterior

		date = null;

		return aprovacaoRepository.obterAprovacaoCooperativa(ano, idCooperativa);	
	}
	
	public void excluirAprovacaoCooperativa(Integer idCooperativa) {
		if(!keycloakService.isTipoEntidadeNacional()) {
			throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
		}
		
		Aprovacao aprovacaoCoop = getAprovacaoSemException(idCooperativa);
		
		if(aprovacaoCoop != null && aprovacaoCoop.getId() != null) {
			List<QuadroSocial> listaQuadroSociais = quadroSocialService.obterQuadroSociaisPorAprovacao(idCooperativa, aprovacaoCoop.getId());
			if(!listaQuadroSociais.isEmpty()) {
				for(QuadroSocial quadroSocial: listaQuadroSociais) {
					quadroSocial.setAprovacao(null);
				}
				quadroSocialService.updateListaQuadroSociais(listaQuadroSociais);
			}
			
			// Atualizar os membros
			List<MandatoMembro> listaMandatoMembros = membroService.obterMandatoMembrosPorAprovacao(idCooperativa, aprovacaoCoop.getId());
			if(!listaMandatoMembros.isEmpty()) {
				for(MandatoMembro membro: listaMandatoMembros) {
					membro.setAprovacao(null);
				}
				membroService.updateListaMandatoMembros(listaMandatoMembros);
			}
			
			List<Mandato> listaMandatos = mandatoService.obterMandatosPorAprovacao(idCooperativa, aprovacaoCoop.getId());
			if(!listaMandatos.isEmpty()) {
				for(Mandato mandato: listaMandatos) {
					mandato.setAprovacao(null);
					mandato.setDataAtualizacao(new Date());
				}
				mandatoService.updateListaMandatos(listaMandatos);
			}
			
			List<Faturamento> listaFaturamentos = faturamentoService.obterFaturamentosPorAprovacao(idCooperativa, aprovacaoCoop.getId());
			if(!listaFaturamentos.isEmpty()) {
				for(Faturamento faturamento: listaFaturamentos) {
					faturamento.setAprovacao(null);
				}
				faturamentoService.updateListaFaturamentos(listaFaturamentos);
			}
			
			//Tratar Documento e Documento Anexo
			documentoCliente.atualizarExcluindoAprovacao(aprovacaoCoop.getId());
			
			aprovacaoRepository.delete(aprovacaoCoop);
		}
	}
	
	private void defineUsuarioAprovacao(Aprovacao aprovacao) {
		if(verificaTipoEntidadeNacionalOuEstadual()) {
			aprovacao.setUsuarioAprovacao(keycloakService.getUsername());
		}
	}
	

	public void aprovarGovernancaSemAprovacao(Integer idCooperativa) {
		if(keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional()) {
			Integer anoCorrente = periodoService.obterAno(idCooperativa);
			Aprovacao ap = aprovacaoRepository.obterAprovacaoCooperativaSemDataAtualizacao(anoCorrente, idCooperativa);
			List<Mandato> mandatos = mandatoService.getMandatosPorCooperativa(idCooperativa);
			
			if(ValidacaoCampos.validaCampoPreenchido(ap)) {
				if(ValidacaoCampos.validaCampoPreenchido(mandatos)) {
					mandatos.stream()
					        .filter(this::parecerDoOrgaoAprovado)
					        .forEach(m -> atualizaAprovacaoMandatoEMembros(m,ap));
				}

				ap.setDataAtualizacao(new Date());
				aprovacaoRepository.save(ap);
			}
			
		}
	}
	
	/**
	 * Submeter o cadastro não aprova governança que ninguém analisou: só o mandato
	 * cujo agrupamento do órgão tem parecer "Aprovar dados" vigente recebe a
	 * aprovação do ciclo. Os demais seguem em rascunho e passam por análise.
	 */
	private boolean parecerDoOrgaoAprovado(Mandato mandato) {
		if (mandato.getCooperativa() == null || mandato.getOrgao() == null) {
			return false;
		}
		boolean manutencao = mandato.getCooperativa().getSituacaoCooperativa() != null
				&& !SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo()
						.equals(mandato.getCooperativa().getSituacaoCooperativa().getId());
		return cooperativaPendenciaService.parecerDoOrgaoAprovado(mandato.getCooperativa().getId(), manutencao,
				mandato.getOrgao().getId());
	}

	private void atualizaAprovacaoMandatoEMembros(Mandato mandato, Aprovacao aprovacao) {
		if(mandato.getAprovacao() == null) {
			mandato.setAprovacao(aprovacao);
		}
		
		if(ValidacaoCampos.validaCampoPreenchido(mandato.getListaMandatoMembro())) {
			mandato.getListaMandatoMembro()
			       .stream()
			       .forEach(membro -> {
			    	   if(membro.getAprovacao() == null) {
			    		   membro.setAprovacao(aprovacao);
			    	   }
			       });
		}
	}

		
}
