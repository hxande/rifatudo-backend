package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.entidade.ComplementoAnuarioRamoUrl;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComplementoAnuarioRamoUrlRepository extends JpaRepository<ComplementoAnuarioRamoUrl, Integer> {
}
