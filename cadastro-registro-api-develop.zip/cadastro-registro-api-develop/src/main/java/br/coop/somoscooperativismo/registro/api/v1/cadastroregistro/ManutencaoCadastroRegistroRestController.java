package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.AprovacaoService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.AcaoProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroTO;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.FaseProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/manutencao-cadastro-registro")
@Tag(name = "CadastroRegistro")
public class ManutencaoCadastroRegistroRestController {

    public static final String MEDIA_TYPE_EXCEL = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static final String ATTACHMENT_EXCEL = "attachment; filename=Relatório.xlsx";
    public static final String CACHE_CTRL_PARAM = "no-cache, no-store, must-revalidate";
    public static final String NO_CACHE = "no-cache";

    @Autowired
    private CadastroRegistroService cadastroRegistroService;

    @Autowired
    private AprovacaoService aprovacaoService;

    @Autowired
    private KeycloakService keycloakService;

    @Autowired
    private CooperativaService cooperativaService;

    @Autowired
    private GerarRelatorioErroValidacaoEmLoteService gerarRelatorioErroValidacaoEmLoteService;

    @Autowired
    private CooperativaHistoricoProcessoRegistroService cooperativaHistoricoProcessoRegistroService;

    @GetMapping("/validarCadastroRegistro/{idCooperativa}")
    @Operation(summary = "Validando Cadastro Registro")
    public ResponseEntity<ServiceResponse<ValidacaoPrimeiroRegistroTO>> validarCadastroRegistro(@PathVariable Integer idCooperativa) {
        return new ResponseEntity<>(new ServiceResponse<>(cadastroRegistroService.validarCadastroRegistroManutencao(idCooperativa)), HttpStatus.OK);
    }

    @GetMapping("/podePreencherCadastroRegistro/{idCooperativa}")
    @Operation(summary = "Validando Cadastro Registro")
    public ResponseEntity<ServiceResponse<Boolean>> podePreencherCadastroRegistro(@PathVariable Integer idCooperativa) {
        // Pegar o usuário e verificar se é cooperativa, UE ou Nacional
        return new ResponseEntity<>(new ServiceResponse<>(cadastroRegistroService.podePreencherCadastroRegistroCooperativaManutencao(idCooperativa)), HttpStatus.OK);
    }

    @GetMapping("/podePreencherCadastroValidacao/{idCooperativa}")
    @Operation(summary = "Validando Cadastro Registro")
    public ResponseEntity<ServiceResponse<Boolean>> podePreencherCadastroValidacao(@PathVariable Integer idCooperativa) {
        // Pegar o usuário e verificar se é cooperativa, UE ou Nacional
        return new ResponseEntity<>(new ServiceResponse<>(cadastroRegistroService.podePreencherCadastroValidacaoManutencao(idCooperativa)), HttpStatus.OK);
    }

    @PutMapping("/submeterCadastro/{idCooperativa}")
    @Operation(summary = "Salvar dados cadastro registro")
    public ResponseEntity<ServiceResponse<Boolean>> submeterCadastro(@PathVariable Integer idCooperativa) {
        ServiceMessage message = new ServiceMessage("Cadastro enviado com sucesso!");

        boolean retorno = cadastroRegistroService.submeterCadastroManutencao(idCooperativa, false);
        boolean primeiraVezSubmetido = aprovacaoService.criarAprovacaoAtualCooperativa(idCooperativa);

        // Para UN E UE se for a primeira subetido, aprova tudo e finaliza o processo
        if (retorno && verificaTipoEntidadeNacionalOuEstadual()) {
        	if(primeiraVezSubmetido) {
        		aprovacaoService.atualizaSeAindaNaoAtualizou(idCooperativa);
                cooperativaService.finalizarProcessoManutencao(idCooperativa);
                aprovacaoService.aprovarTodosDadosCooperativaFluxoUEUN(idCooperativa);
        	} else {
        		aprovacaoService.aprovarGovernancaSemAprovacao(idCooperativa);
        	}
        }

        CooperativaHistoricoProcessoRegistroTO chpr = new CooperativaHistoricoProcessoRegistroTO();
        chpr.setCooperativaId(idCooperativa);
        chpr.setDataAtualizacao(new Date());
        chpr.setAcao(AcaoProcessoRegistroEnum.SUBMETER_CADASTRO);
        chpr.setFase(FaseProcessoRegistroEnum.VALIDACAO);
        chpr.setUsuario(keycloakService.getNome());
        cooperativaHistoricoProcessoRegistroService.salvar(chpr);

        return new ResponseEntity<>(new ServiceResponse<>(retorno, message), HttpStatus.OK);

    }

    @PostMapping("/relatorioValidacaoErros")
    @Operation(summary = "Relatório de erros de validação")
    public ResponseEntity<Resource> relatorioValidacaoErros(@RequestBody List<Integer> idsCooperativas) {
        byte[] dados = gerarRelatorioErroValidacaoEmLoteService.exportarErrosValidacaoEmLote(idsCooperativas);

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=relatorio_erros_validacao.xlsx");
        header.add(HttpHeaders.CACHE_CONTROL, "no-cache, no-store, must-revalidate");
        header.add(HttpHeaders.PRAGMA, "no-cache");
        header.add(HttpHeaders.EXPIRES, "0");

        return ResponseEntity.ok()
                .headers(header)
                .contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(!ArrayUtils.isEmpty(dados) ? new ByteArrayResource(dados) : null);
    }


    @PutMapping("/submeterCadastro-em-lote")
    @Operation(summary = "Salvar dados cadastro registro - Validação em lote")
    public ResponseEntity<ServiceResponse<Boolean>> submeterCadastroValidacaoEmLote(@RequestBody Collection<String> idsCooperativaString) {
        List<Integer> idsCooperativa = idsCooperativaString.stream()
                .map(Integer::parseInt).toList();
        return cadastroRegistroService.submeterCadastroValidacaoEmLote(idsCooperativa);
    }

    private boolean verificaTipoEntidadeNacionalOuEstadual() {
		return keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional();
	}
}
