package br.coop.somoscooperativismo.api.v1.relatorio;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class RelatorioCooperativasRegistradasRepository {
	@PersistenceContext
	private EntityManager entityManager;
	
	public List<RelatorioCooperativasRegistradasRamoTO> listaCooperativasRelatorioNacional(){
		String sql = ""
				+ "SELECT   " + 
				"PJ.TX_UF_SIGLA as uf,  " + 
				"SC.TX_NOVA_SITUACAO_COOPERATIVA as situacao,    " +
				"CASE WHEN C.IN_REGULARIDADE_COOPERATIVA LIKE 'R' THEN 'R'" + 
				"     WHEN C.IN_REGULARIDADE_COOPERATIVA LIKE 'I' THEN 'I'" + 
				"ELSE 'NA' END as status,   " + 
				"ISNULL(qs.NR_ANO,0) as ano,  " + 
				"ISNULL(qs.NR_COOPERADOS_TOTAL,0) as qt_cooperados,   " + 
				"ISNULL(qs.NR_EMPREGADOS_TOTAL,0) as qt_empregados,  " + 
				"PJ.SQ_RAMO as ramo_id,  " + 
				"rm.TX_RAMO  as ramo  " + 
				"FROM PESSOA_JURIDICA PJ WITH (NOLOCK) " + 
				"JOIN COOPERATIVA as c WITH (NOLOCK) on c.SQ_COOPERATIVA = PJ.SQ_PESSOA   " + 
				"JOIN SITUACAO_COOPERATIVA SC WITH (NOLOCK) ON C.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA   " + 
				"JOIN RAMO as rm WITH (NOLOCK) on rm.SQ_RAMO = PJ.SQ_RAMO   " + 
				"LEFT JOIN QUADRO_SOCIAL QS WITH (NOLOCK) " + 
				"ON C.SQ_COOPERATIVA = QS.SQ_COOPERATIVA   " + 
				"AND QS.NR_ANO = (SELECT MAX(QI.NR_ANO) FROM QUADRO_SOCIAL QI WITH (NOLOCK) WHERE C.SQ_COOPERATIVA = QI.SQ_COOPERATIVA)   " + 
				"WHERE C.SQ_SITUACAO_COOPERATIVA in (1,2)   " + 
				"AND C.DT_REGISTRO_OCB is not null   AND PJ.IN_MATRIZ = 1 " + 
				"";
		return (List<RelatorioCooperativasRegistradasRamoTO>) entityManager.createNativeQuery(sql, "RelatorioCooperativasRegistradasRamoTO").getResultList();
	}
	
	public List<RelatorioCooperativasRegistradasRamoTO> listaCooperativasRelatorioEstadual(String uf){
		String sql = ""
				+ "SELECT   " + 
				"PJ.TX_UF_SIGLA as uf,  " + 
				"SC.TX_NOVA_SITUACAO_COOPERATIVA as situacao,    " +
				"CASE WHEN C.IN_REGULARIDADE_COOPERATIVA LIKE 'R' THEN 'R'" + 
				"     WHEN C.IN_REGULARIDADE_COOPERATIVA LIKE 'I' THEN 'I'" + 
				"ELSE 'NA' END as status,   " + 
				"ISNULL(qs.NR_ANO,0) as ano,  " + 
				"ISNULL(qs.NR_COOPERADOS_TOTAL,0) as qt_cooperados,   " + 
				"ISNULL(qs.NR_EMPREGADOS_TOTAL,0) as qt_empregados,  " + 
				"PJ.SQ_RAMO as ramo_id,  " + 
				"rm.TX_RAMO  as ramo  " + 
				"FROM PESSOA_JURIDICA PJ WITH (NOLOCK)  " + 
				"JOIN COOPERATIVA as c WITH (NOLOCK) on c.SQ_COOPERATIVA = PJ.SQ_PESSOA   " + 
				"JOIN SITUACAO_COOPERATIVA SC WITH (NOLOCK) ON C.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA   " + 
				"JOIN RAMO as rm WITH (NOLOCK) on rm.SQ_RAMO = PJ.SQ_RAMO   " + 
				"LEFT JOIN QUADRO_SOCIAL QS WITH (NOLOCK)  " + 
				"ON C.SQ_COOPERATIVA = QS.SQ_COOPERATIVA   " + 
				"AND QS.NR_ANO = (SELECT MAX(QI.NR_ANO) FROM QUADRO_SOCIAL QI WITH (NOLOCK) WHERE C.SQ_COOPERATIVA = QI.SQ_COOPERATIVA)   " + 
				"WHERE C.SQ_SITUACAO_COOPERATIVA in (1,2)   " + 
				"AND C.DT_REGISTRO_OCB is not null  AND PJ.TX_UF_SIGLA = :uf  AND PJ.IN_MATRIZ = 1 " + 
				"";
		
		return (List<RelatorioCooperativasRegistradasRamoTO>) entityManager.createNativeQuery(sql,"RelatorioCooperativasRegistradasRamoTO")
				.setParameter("uf", uf)
				.getResultList();
	}
	
}
