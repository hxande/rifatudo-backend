package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.parametroquadrosocialcooperado.entidade.ParametroQuadroSocialCooperado;
import br.coop.somoscooperativismo.registro.api.v1.parametroquadrosocialcooperado.ParametroQuadroSocialCooperadoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/parametros-quadro-social-cooperado")
public class ParametroQuadroSocialCooperadoImportacaoRestController {

    private final ParametroQuadroSocialCooperadoService parametroQuadroSocialCooperadoService;

    @GetMapping("/ativos")
    public ResponseEntity<List<ParametroQuadroSocialCooperado>> getAllAtivos() {
        return ResponseEntity.ok(parametroQuadroSocialCooperadoService.getAllAtivos());
    }
}
