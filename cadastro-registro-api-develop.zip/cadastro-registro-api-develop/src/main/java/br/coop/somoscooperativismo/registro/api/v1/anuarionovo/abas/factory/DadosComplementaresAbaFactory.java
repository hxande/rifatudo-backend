package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaCampoBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaDataInterface;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.ComplementoAnuarioTO;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DadosComplementaresAbaFactory implements AbaFactory {

    @Override
    public NomeAbaEnum getNomeAba() {
        return NomeAbaEnum.DADOS_COMPLEMENTARES;
    }

    @Override
    public List<AbaDataInterface> build(Object handler) {
        return List.of(
                buildDadosComplementares((ComplementoAnuarioTO) handler)
        );
    }

    public static AbaDataInterface buildDadosComplementares(ComplementoAnuarioTO handler) {
        AbaBuilder aba = new AbaBuilder("dadosComplementares", NomeQuadroEnum.DADOS_COMPLEMENTARES.toString(), handler.getId(), null,"Dados Complementares")
                .subTitle("Informações complementares");

        if (ValidacaoCampos.validaCampoPreenchido(handler)) {
            aba.addCampo(
                    AbaCampoBuilder.complementoAnuario("dadosComplementares", null , handler.getId(), null, handler.getTexto())
                            .value(handler.getUrl())
                            .readonly(false)
                            .build()
            );
        }

        return aba.build();
    }

}
