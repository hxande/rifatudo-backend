package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.redesocial.entidade.RedeSocial;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class RedeSocialImportacaoAbstractController {

    @NonNull
    protected ModelMapper modelMapper;

    protected Converter<RedeSocial, RedeSocialImportacaoTO> converterEntidadeParaTO = context ->
            RedeSocialImportacaoTO.builder()
                    .id(context.getSource().getId())
                    .pessoa(PessoaImportacaoTO.builder()
                            .id(context.getSource().getPessoa().getId())
                            .build())
                    .tipoRedeSocial(context.getSource().getTipoRedeSocial())
                    .link(context.getSource().getLink())
                    .build();
}