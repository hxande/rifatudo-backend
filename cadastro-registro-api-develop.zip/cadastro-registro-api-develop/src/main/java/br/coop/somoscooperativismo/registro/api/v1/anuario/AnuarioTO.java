package br.coop.somoscooperativismo.registro.api.v1.anuario;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.ColumnResult;
import jakarta.persistence.ConstructorResult;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.SqlResultSetMapping;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@SqlResultSetMapping(name = "AnuarioTOResult", classes = {
		@ConstructorResult(targetClass = br.coop.somoscooperativismo.registro.api.v1.anuario.AnuarioTO.class, columns = {
				@ColumnResult(name = "SQ_COOPERATIVA_ANUARIO", type = Integer.class),
				@ColumnResult(name = "SQ_COOPERATIVA", type = Integer.class),
				@ColumnResult(name = "VL_ATIVO_TOTAL", type = BigDecimal.class),
				@ColumnResult(name = "VL_ATIVO_IMOBILIZADO", type = BigDecimal.class),
				@ColumnResult(name = "VL_PATRIMONIO_LIQUIDO", type = BigDecimal.class),
				@ColumnResult(name = "VL_CAPITAL_SOCIAL", type = BigDecimal.class),
				@ColumnResult(name = "VL_SOBRAS_PERDAS_EXERCICIO", type = BigDecimal.class),
				@ColumnResult(name = "VL_INGRESSOS_RECEITAS_BRUTAS", type = BigDecimal.class),
				@ColumnResult(name = "VL_TRIBUTOS", type = BigDecimal.class),
				@ColumnResult(name = "VL_DESPESAS_PESSOAL", type = BigDecimal.class),
				@ColumnResult(name = "NR_ANO", type = Integer.class),
				@ColumnResult(name = "TX_RAZAO_SOCIAL", type = String.class),
				@ColumnResult(name = "TX_NOME_FANTASIA", type = String.class),
				@ColumnResult(name = "TX_UF_SIGLA", type = String.class),
				@ColumnResult(name = "TX_CNPJ", type = String.class),
				@ColumnResult(name = "SQ_RAMO", type = Integer.class),
				@ColumnResult(name = "TX_RAMO", type = String.class),
				@ColumnResult(name = "IN_REGULARIDADE_COOPERATIVA", type = Character.class),
				@ColumnResult(name = "SQ_SITUACAO_COOPERATIVA", type = Integer.class),
				@ColumnResult(name = "TX_SITUACAO_COOPERATIVA", type = String.class) }) })
/*
@NamedNativeQuery(name = "AnuarioTO.getList", query = "SELECT ANUARIO.SQ_COOPERATIVA_ANUARIO AS SQ_COOPERATIVA_ANUARIO, "
		+ "   CP.SQ_COOPERATIVA AS SQ_COOPERATIVA, ANUARIO.NR_ANO AS NR_ANO, "
		+ "	  PJ.TX_CNPJ AS TX_CNPJ, PJ.TX_RAZAO_SOCIAL AS TX_RAZAO_SOCIAL, "
		+ "	  PJ.TX_NOME_FANTASIA as TX_NOME_FANTASIA, PJ.TX_UF_SIGLA as TX_UF_SIGLA, RM.SQ_RAMO as SQ_RAMO, RM.TX_RAMO as TX_RAMO, "
		+ "	  CP.IN_REGULARIDADE_COOPERATIVA as IN_REGULARIDADE_COOPERATIVA, SC.SQ_SITUACAO_COOPERATIVA as SQ_SITUACAO_COOPERATIVA, "
		+ "	  SC.TX_SITUACAO_COOPERATIVA as TX_SITUACAO_COOPERATIVA, ANUARIO.VL_ATIVO_TOTAL as VL_ATIVO_TOTAL, "
		+ "	  ANUARIO.VL_ATIVO_IMOBILIZADO as VL_ATIVO_IMOBILIZADO, ANUARIO.VL_PATRIMONIO_LIQUIDO as VL_PATRIMONIO_LIQUIDO, "
		+ "	  ANUARIO.VL_CAPITAL_SOCIAL as VL_CAPITAL_SOCIAL, ANUARIO.VL_SOBRAS_PERDAS_EXERCICIO as VL_SOBRAS_PERDAS_EXERCICIO, "
		+ "	  ANUARIO.VL_INGRESSOS_RECEITAS_BRUTAS as VL_INGRESSOS_RECEITAS_BRUTAS, "
		+ "	  ANUARIO.VL_TRIBUTOS as VL_TRIBUTOS, ANUARIO.VL_DESPESAS_PESSOAL as VL_DESPESAS_PESSOAL "
		+ "	FROM COOPERATIVA CP LEFT JOIN COOPERATIVA_ANUARIO ANUARIO ON CP.SQ_COOPERATIVA = ANUARIO.SQ_COOPERATIVA "
		+ "   AND (ANUARIO.NR_ANO = :ano), SITUACAO_COOPERATIVA SC, CATEGORIA_COOPERATIVA CC, "
		+ "   PESSOA_JURIDICA PJ LEFT JOIN RAMO RM ON PJ.SQ_RAMO = RM.SQ_RAMO "
		+ "	WHERE  CP.SQ_COOPERATIVA = PJ.SQ_PESSOA AND CP.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA "
		+ "   AND CP.IN_REGULARIDADE_COOPERATIVA IS NOT NULL "
		+ "	  AND CC.SQ_CATEGORIA_COOPERATIVA = CP.SQ_CATEGORIA_COOPERATIVA AND PJ.IN_MATRIZ = 1 "
		+ "   AND (CP.IN_PROCESSO_TRANSFERENCIA IS NULL OR CP.IN_PROCESSO_TRANSFERENCIA = '0') "
		+ "   AND (CP.IN_ARQUIVADO IS NULL OR CP.IN_ARQUIVADO = '0')"
		+ " \n -- #pageable\n", resultSetMapping = "AnuarioTOResult", resultClass = AnuarioTO.class)
@NamedNativeQuery(name = "AnuarioTO.getListCount", query = "SELECT COUNT(*) "
		+ "	FROM COOPERATIVA CP LEFT JOIN COOPERATIVA_ANUARIO ANUARIO ON CP.SQ_COOPERATIVA = ANUARIO.SQ_COOPERATIVA "
		+ "   AND (ANUARIO.NR_ANO = :ano), SITUACAO_COOPERATIVA SC, CATEGORIA_COOPERATIVA CC, "
		+ "   PESSOA_JURIDICA PJ LEFT JOIN RAMO RM ON PJ.SQ_RAMO = RM.SQ_RAMO "
		+ "	WHERE  CP.SQ_COOPERATIVA = PJ.SQ_PESSOA AND CP.SQ_SITUACAO_COOPERATIVA = SC.SQ_SITUACAO_COOPERATIVA "
		+ "   AND CP.IN_REGULARIDADE_COOPERATIVA IS NOT NULL "
		+ "	  AND CC.SQ_CATEGORIA_COOPERATIVA = CP.SQ_CATEGORIA_COOPERATIVA AND PJ.IN_MATRIZ = 1 "
		+ "   AND (CP.IN_PROCESSO_TRANSFERENCIA IS NULL OR CP.IN_PROCESSO_TRANSFERENCIA = '0') "
		+ "   AND (CP.IN_ARQUIVADO IS NULL OR CP.IN_ARQUIVADO = '0')")
		*/
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "VW_COOPERATIVA_ANUARIO")
public class AnuarioTO {

	@Column(name = "SQ_COOPERATIVA_ANUARIO")
	private Integer id;

	@Id
	@Column(name = "SQ_COOPERATIVA")
	private Integer idCooperativa;

	@Column(name = "VL_ATIVO_TOTAL", columnDefinition = "money(19,2)")
	private BigDecimal ativoTotal;

	@Column(name = "VL_ATIVO_IMOBILIZADO", columnDefinition = "money(19,2)")
	private BigDecimal ativoImobilizado;

	@Column(name = "VL_PATRIMONIO_LIQUIDO", columnDefinition = "money(19,2)")
	private BigDecimal patrimonioLiquido;

	@Column(name = "VL_CAPITAL_SOCIAL", columnDefinition = "money(19,2)")
	private BigDecimal capitalSocial;

	@Column(name = "VL_SOBRAS_PERDAS_EXERCICIO", columnDefinition = "money(19,2)")
	private BigDecimal sobrasPerdasExercicio;

	@Column(name = "VL_INGRESSOS_RECEITAS_BRUTAS", columnDefinition = "money(19,2)")
	private BigDecimal ingressosReceitasBrutas;

	@Column(name = "VL_TRIBUTOS", columnDefinition = "money(19,2)")
	private BigDecimal tributos;

	@Column(name = "VL_DESPESAS_PESSOAL", columnDefinition = "money(19,2)")
	private BigDecimal despesasPessoal;

	@Column(name = "NR_ANO")
	private Integer ano;

	@Column(name = "TX_RAZAO_SOCIAL", nullable = false)
	@Size(max = 255)
	private String razaoSocial;

	@Column(name = "TX_NOME_FANTASIA")
	private String nomeFantasia;

	@Column(name = "TX_UF_SIGLA", columnDefinition = "char(2)")
	@Size(max = 2)
	private String ufSigla;

	@Column(name = "TX_CNPJ")
	@Size(max = 14)
	private String cnpj;

	@Column(name = "SQ_RAMO", columnDefinition = "tinyint(4)")
	private Integer idRamo;

	@Column(name = "TX_RAMO")
	private String nomeRamo;

	@Column(name = "SQ_SITUACAO_COOPERATIVA", columnDefinition = "tinyint(4)")
	private Integer idSituacaoCooperativa;

	@Column(name = "TX_SITUACAO_COOPERATIVA")
	private String situacaoCooperativa;
}
