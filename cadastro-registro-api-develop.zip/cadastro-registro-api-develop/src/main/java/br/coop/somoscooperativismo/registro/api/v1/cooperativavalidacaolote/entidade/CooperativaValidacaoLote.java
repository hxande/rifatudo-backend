package br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.entidade;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.envers.Audited;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "COOPERATIVA_VALIDACAO_LOTE", uniqueConstraints = {
        @UniqueConstraint(columnNames = {"SQ_PESSOA", "ANO_REFERENCIA"})
})
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class CooperativaValidacaoLote implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "USUARIO_VALIDACAO")
    private String usuarioValidacao;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DATA_VALIDACAO")
    private Date dataValidacao;

    @Column(name = "STATUS_VALIDACAO")
    private String statusValidacao;

    @Column(name = "DESCRICAO_VALIDACAO")
    private String descricaoValidacao;

    @Column(name = "ANO_REFERENCIA")
    private Integer anoReferencia;

    @OneToOne
    @JoinColumn(name = "SQ_PESSOA", referencedColumnName = "SQ_COOPERATIVA")
    private Cooperativa cooperativa;


}
