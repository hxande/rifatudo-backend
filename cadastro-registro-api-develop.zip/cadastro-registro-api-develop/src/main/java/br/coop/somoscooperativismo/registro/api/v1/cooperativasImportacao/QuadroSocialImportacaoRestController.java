package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/quadros-sociais")
public class QuadroSocialImportacaoRestController {

    private final QuadroSocialService quadroSocialService;

    
    @PostMapping
    public ResponseEntity<ServiceResponse<Void>> salvarQuadrosSociais(@RequestBody QuadroSocialTO quadroSocialCoop) {
        quadroSocialService.salvarQuadrosSociais(quadroSocialCoop);
        return ResponseEntity.ok(new ServiceResponse<>());
    }

    @GetMapping("/manutencao/{idCooperativa}")
    public ResponseEntity<List<QuadroSocial>> getQuadroSociaisManutencao(@PathVariable Integer idCooperativa) {
        return ResponseEntity.ok(quadroSocialService.getQuadroSociaisManutencao(idCooperativa));
    }
}
