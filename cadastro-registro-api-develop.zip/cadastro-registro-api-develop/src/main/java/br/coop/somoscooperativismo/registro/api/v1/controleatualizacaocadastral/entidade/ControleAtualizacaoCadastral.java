package br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import lombok.Data;

@Data
@Entity
@Table(name = "CONTROLE_ATUALIZACAO_CADASTRAL")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class ControleAtualizacaoCadastral {
	
	 	@Id
	 	@GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "SQ_CONTROLE_ATUALIZACAO_CADASTRAL")
	    private Integer id;
	    
	    @Column(name = "IN_MOSTRAR_POPUP", columnDefinition = "bit", nullable = false)
	    private Boolean mostrarPopup;

	    @Column(name = "IN_DESTACAR_ATUALIZACAO_CADASTRAL", columnDefinition = "bit", nullable = false)
	    private Boolean destacarAtualizacaoCadastral;

	    @Column(name = "TX_CONTEUDO_POPUP")
	    private String textoPopup;
	    
	    @Column(name = "IN_PERMITE_COOPERATIVA_PREENCHER", columnDefinition = "bit", nullable = false)
	    private Boolean permiteCooperativaPreencher;

	    @Column(name = "IN_PERMITE_COOPERATIVA_VISUALIZAR", columnDefinition = "bit", nullable = false)
	    private Boolean permiteCooperativaVisualizar;
	    
	    @Column(name = "IN_PERMITE_ESTADUAL_PREENCHER", columnDefinition = "bit", nullable = false)
	    private Boolean permiteEstadualPreencher;
	    
	    @Column(name = "IN_VISUALIZAR_PERIODO_ATUALIZACAO", columnDefinition = "bit")
	    private Boolean visualizarPeriodoAtualizacao;
	    
	    @Column(name = "TX_UF", columnDefinition = "varchar(2)")
	    private String uf;

}
