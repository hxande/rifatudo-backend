package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaBasicaTO;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaUtil;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import lombok.*;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CooperativaApresentacaoTO {
    private Integer id;
    private String status;
    private String numeroRegistroOCB;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataRegistro;
    private Date dataAtualizacao;
    private String justificativaAtivacao;
    private String justificativaSolicitacaoCancelamento;
    private String justificativaSolicitacaoInativacao;
    private String justificativaSolicitacaoAtivacao;
    private String justificativaIrregular;
    private String justificativaInativada;
    private String justificativaCancelada;
    private Boolean processoTransferencia;
    private Boolean liquidacao;
    private Boolean regidaPorLei;
    private Boolean naoSubmeteu;
    private Boolean solicitacaoAtivacao;
    private Boolean solicitacaoInativacao;
    private Boolean solicitacaoCancelamento;
    private Character regularidadeCooperativa;
    private ProgressoMicroEnum progressoManutencaoMicro;
    private PessoaJuridicaBasicaTO pessoaJuridica;
    private Categoria categoria;
    private Situacao situacaoCooperativa;
    private String usuarioSubmissao;
    private List<CooperativaRegistro> cooperativaRegistro;

    public CooperativaApresentacaoTO(Cooperativa cooperativa) {
        this.id = cooperativa.getId();
        this.status = cooperativa.getStatus();
        this.numeroRegistroOCB = cooperativa.getNumeroRegistroOCB();
        this.dataRegistro = cooperativa.getDataRegistro();
        this.dataAtualizacao = cooperativa.getDataAtualizacao();
        this.justificativaAtivacao = cooperativa.getJustificativaAtivacao();
        this.justificativaSolicitacaoCancelamento = cooperativa.getJustificativaSolicitacaoCancelamento();
        this.justificativaSolicitacaoInativacao = cooperativa.getJustificativaSolicitacaoInativacao();
        this.justificativaSolicitacaoAtivacao = cooperativa.getJustificativaSolicitacaoAtivacao();
        this.justificativaIrregular = cooperativa.getJustificativaIrregular();
        this.justificativaInativada = cooperativa.getJustificativaInativada();
        this.justificativaCancelada = cooperativa.getJustificativaCancelada();
        this.processoTransferencia = cooperativa.getProcessoTransferencia();
        this.liquidacao = cooperativa.getLiquidacao();
        this.regidaPorLei = cooperativa.getRegidaPorLei();
        this.naoSubmeteu = cooperativa.getNaoSubmeteu();
        this.solicitacaoAtivacao = cooperativa.getSolicitacaoAtivacao();
        this.solicitacaoInativacao = cooperativa.getSolicitacaoInativacao();
        this.solicitacaoCancelamento = cooperativa.getSolicitacaoCancelamento();
        this.progressoManutencaoMicro = cooperativa.getProgressoManutencaoMicro();
        this.pessoaJuridica = PessoaJuridicaUtil.formatarSaidaBasica(cooperativa.getPessoaJuridica());
        this.categoria = cooperativa.getCategoria();
        this.situacaoCooperativa = cooperativa.getSituacaoCooperativa();
        this.usuarioSubmissao = cooperativa.getUsuarioSubmissao();
        this.cooperativaRegistro = cooperativa.getCooperativaRegistro();
    }
}
