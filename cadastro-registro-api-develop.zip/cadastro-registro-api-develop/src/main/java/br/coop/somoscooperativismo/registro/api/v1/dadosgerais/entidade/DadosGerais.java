package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.entidade;

import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.entidade.RedeSocial;

public class DadosGerais {

	private Cooperativa cooperativa;
	private List<Endereco> enderecos;
	private List<Contato> contatoCooperativa;
	private List<RedeSocial> redesSociais;
	private List<CooperativaBasicaTO> cooperativasVinculadas;
	private QuadroSocial quadroSocialAtual;
	private QuadroSocial quadroSocialManutencao;

	public List<Endereco> getEnderecos() {
		return enderecos;
	}

	public List<Contato> getContatoCooperativa() {
		return contatoCooperativa;
	}

	public void setEnderecos(List<Endereco> enderecos) {
		this.enderecos = enderecos;
	}

	public void setContatoCooperativa(List<Contato> contatoCooperativa) {
		this.contatoCooperativa = contatoCooperativa;
	}

	public List<RedeSocial> getRedesSociais() {
		return redesSociais;
	}

	public void setRedesSociais(List<RedeSocial> redesSociais) {
		this.redesSociais = redesSociais;
	}

	public Cooperativa getCooperativa() {
		return cooperativa;
	}

	public void setCooperativa(Cooperativa cooperativa) {
		this.cooperativa = cooperativa;
	}

	public List<CooperativaBasicaTO> getCooperativasVinculadas() {
		return cooperativasVinculadas;
	}

	public void setCooperativasVinculadas(List<CooperativaBasicaTO> cooperativasVinculadas) {
		this.cooperativasVinculadas = cooperativasVinculadas;
	}

	public QuadroSocial getQuadroSocialAtual() {
		return quadroSocialAtual;
	}

	public void setQuadroSocialAtual(QuadroSocial quadroSocialAtual) {
		this.quadroSocialAtual = quadroSocialAtual;
	}

	public QuadroSocial getQuadroSocialManutencao() {
		return quadroSocialManutencao;
	}

	public void setQuadroSocialManutencao(QuadroSocial quadroSocialManutencao) {
		this.quadroSocialManutencao = quadroSocialManutencao;
	}

}
