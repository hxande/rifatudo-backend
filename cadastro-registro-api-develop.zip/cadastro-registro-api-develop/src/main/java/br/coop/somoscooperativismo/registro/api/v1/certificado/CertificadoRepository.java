package br.coop.somoscooperativismo.registro.api.v1.certificado;

import br.coop.somoscooperativismo.registro.api.v1.certificado.entidade.Certificado;
import org.springframework.data.jpa.repository.JpaRepository;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

public interface CertificadoRepository extends JpaRepository<Certificado, Integer> {

    Certificado findByCooperativa(Cooperativa cooperativa);

}
