package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.orgao.VinculoEnum;
import br.coop.somoscooperativismo.registro.api.v1.orgaoramo.entidade.OrgaoRamo;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Campos obrigatórios do membro (nome, gênero, cargo) e datas obrigatórias
 * condicionais (início; fim para inativo) — para membros de mandato vigente que
 * deve validar. Paridade: {@code GovernancaService.verificaMembro} (os ramos de
 * campo obrigatório). As datas de início inválida/futura e o fim de inativo
 * (literal) ficam em {@link DatasMandatoRule}/{@link MembroInativoComFimRule}.
 */
@Component
@RequiredArgsConstructor
public class MembroCamposObrigatoriosRule implements GovernancaRule {

    private final OrgaoRamoResolver resolver;

    @Override
    public List<ViolacaoGovernanca> avaliar(GovernancaContext contexto) {
        List<ViolacaoGovernanca> violacoes = new ArrayList<>();
        boolean manutencao10 = contexto.getCooperativa() != null
                && Objects.equals(ProgressoMacroEnum.MANUTENCAO_10, contexto.getCooperativa().getProgressoManutencaoMacro());

        for (Mandato mandato : contexto.getMandatos()) {
            if (mandato.getOrgao() == null || mandato.getOrgao().getId() == null
                    || !Boolean.TRUE.equals(mandato.getVigente())) {
                continue;
            }
            OrgaoRamo orgaoRamo = contexto.orgaoRamoDe(mandato.getOrgao().getId());
            if (orgaoRamo == null) {
                continue;
            }
            boolean deveValidar = resolver.obrigatorio(contexto.getSituacao(), orgaoRamo)
                    || Boolean.TRUE.equals(mandato.getCoopPossui());
            if (!deveValidar) {
                continue;
            }
            String nomeOrgao = mandato.getOrgao().getNome();
            boolean contratacao = VinculoEnum.CONTRATACAO.toString().equals(mandato.getOrgao().getVinculo());

            for (MandatoMembro membro : GovernancaContext.membros(mandato)) {
                if (membro.getPessoaFisica() == null) {
                    continue;
                }
                String cpf = membro.getPessoaFisica().getCpf();

                if (!ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getNome())) {
                    violacoes.add(ViolacaoGovernanca.deMembro(
                            TipoViolacaoGovernanca.PESSOA_FISICA_NOME_OBRIGATORIO, nomeOrgao, cpf));
                }
                if (!ValidacaoCampos.validaCampoPreenchido(membro.getPessoaFisica().getGenero())) {
                    violacoes.add(ViolacaoGovernanca.deMembro(
                            TipoViolacaoGovernanca.PESSOA_FISICA_GENERO_OBRIGATORIO, nomeOrgao, cpf));
                }
                if (membro.getCargo() == null) {
                    violacoes.add(ViolacaoGovernanca.deMembro(
                            TipoViolacaoGovernanca.MEMBRO_CARGO_OBRIGATORIO, nomeOrgao, cpf));
                }

                if (contratacao || manutencao10) {
                    if (membro.getInicioMandato() == null) {
                        violacoes.add(ViolacaoGovernanca.deMembro(
                                TipoViolacaoGovernanca.INICIO_OBRIGATORIO, nomeOrgao, cpf));
                    }
                    if (membro.getFimMandato() == null
                            && Boolean.FALSE.equals(membro.getMembroAtivo())
                            && !contratacao) {
                        violacoes.add(ViolacaoGovernanca.deMembro(
                                TipoViolacaoGovernanca.MEMBRO_FIM_OBRIGATORIO, nomeOrgao, cpf));
                    }
                }
            }
        }
        return violacoes;
    }
}
