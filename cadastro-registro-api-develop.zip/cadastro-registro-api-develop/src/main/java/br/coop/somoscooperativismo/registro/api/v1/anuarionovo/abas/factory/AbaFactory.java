package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaDataInterface;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;

import java.util.List;
import java.util.Objects;

public interface AbaFactory {
    NomeAbaEnum getNomeAba();
    List<AbaDataInterface> build(Object handler);

    default String obterValor(Object obj) {
        return Objects.nonNull(obj) ? obj.toString() : "";
    }
}
