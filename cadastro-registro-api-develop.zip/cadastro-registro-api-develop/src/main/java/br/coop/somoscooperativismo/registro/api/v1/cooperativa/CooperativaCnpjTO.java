package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

public class CooperativaCnpjTO {
	
	private Integer id;
	private String cnpj;
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public CooperativaCnpjTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CooperativaCnpjTO(Integer id, String cnpj, String email) {
		super();
		this.id = id;
		this.cnpj = cnpj;
		this.email = email;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
}
