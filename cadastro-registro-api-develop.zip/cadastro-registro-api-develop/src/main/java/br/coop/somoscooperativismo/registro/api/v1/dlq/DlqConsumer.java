package br.coop.somoscooperativismo.registro.api.v1.dlq;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.registro.api.v1.dlq.service.DlqProcessingOrchestrator;
import br.coop.somoscooperativismo.registro.config.RabbitMQConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class DlqConsumer {
    private static final Logger LOGGER = LoggerFactory.getLogger(DlqConsumer.class);
    private final DlqProcessingOrchestrator dlqProcessingOrchestrator;

    public DlqConsumer(DlqProcessingOrchestrator dlqProcessingOrchestrator) {
        this.dlqProcessingOrchestrator = dlqProcessingOrchestrator;
    }

    @RabbitListener(queues = RabbitMQConfig.GOVERNANCA_DESENVOLVIMENTO_HUMANO_DLQ)
    public void listenDlq(Message message) {
        try {
            dlqProcessingOrchestrator.processoDlqMessagem(message);
        } catch (Exception e) {
            LOGGER.error("Falha ao processar e persistir mensagem da DLQ final no banco de dados: {}",
                    e.getMessage(), e);
            throw new ErroSistemaException("Erro durante o processamento da mensagem DLQ para persistência.", e);
        }
    }
}
