package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;
import br.coop.somoscooperativismo.registro.api.v1.ramo.RamoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/ramos")
public class RamoImportacaoRestController {

    private final RamoService ramoService;

    @GetMapping("/ativos")
    public ResponseEntity<List<Ramo>> getAtivos() {
        return ResponseEntity.ok(ramoService.getListaRamosAtivos());
    }
}
