package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaConstants;

/**
 * Value object that captures the cooperative situation that drives the
 * {@code OrgaoRamo} matrix resolution (liquidacao / Lei 12.690 / porte).
 *
 * <p>Centraliza a leitura de {@code liquidacao}, {@code regidaPorLei} e
 * total de cooperados que hoje está espalhada em ~5 blocos {@code if/else}
 * de {@link br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaService}
 * (research D2 / Specification).</p>
 */
public final class GovernancaSituacao {

    private final boolean liquidacao;
    private final boolean regidaPorLei;
    private final int totalCooperados;

    public GovernancaSituacao(boolean liquidacao, boolean regidaPorLei, int totalCooperados) {
        this.liquidacao = liquidacao;
        this.regidaPorLei = regidaPorLei;
        this.totalCooperados = totalCooperados;
    }

    /** Reproduz a leitura atual: {@code Boolean} nulo é tratado como {@code false}. */
    public static GovernancaSituacao de(Cooperativa cooperativa, int totalCooperados) {
        boolean liquidacao = Boolean.TRUE.equals(cooperativa.getLiquidacao());
        boolean regidaPorLei = Boolean.TRUE.equals(cooperativa.getRegidaPorLei());
        return new GovernancaSituacao(liquidacao, regidaPorLei, totalCooperados);
    }

    public boolean isLiquidacao() {
        return liquidacao;
    }

    public boolean isRegidaPorLei() {
        return regidaPorLei;
    }

    public int getTotalCooperados() {
        return totalCooperados;
    }

    /** Lei 12.690 com porte de até 19 cooperados. */
    public boolean isLei12690AteDezenove() {
        return regidaPorLei && totalCooperados <= GovernancaConstants.QTD_COOPERADOS_LEI12690;
    }

    /** Lei 12.690 com porte de 20 ou mais cooperados. */
    public boolean isLei12690MaiorDezenove() {
        return regidaPorLei && totalCooperados > GovernancaConstants.QTD_COOPERADOS_LEI12690;
    }
}
