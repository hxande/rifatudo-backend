package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.record;

import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.AbaEnum;

public record CooperativaManutencaoRequestRecord(Integer idCooperativa, boolean validacao, String tipo) {

	public AbaEnum getTipo() {
		return AbaEnum.getValue(tipo);
	}
}
