package br.coop.somoscooperativismo.registro.api.v1.desempenho;

import lombok.*;

import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EstruturaPendenciaTO {

    private Integer idEstrutura;
	private String nomeEstrutura;
	private List<ParametroPendenciaTO> parametros;

}
