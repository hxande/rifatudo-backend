package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesService;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesTO;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacao;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoService;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.service.DadoSocialPortifolioService;
import br.coop.somoscooperativismo.registro.api.v1.to.DadoSocialPortifolioTO;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Objects;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/dado-social-portifolio")
public class DadoSocialPortifolioRestController {

    private final DadoSocialPortifolioService dadoSocialPortifolioService;
    private final NegocioExportacaoService negocioExportacaoService;
    private final CooperativaFatesService cooperativaFatesService;


    @PostMapping
    public ResponseEntity<Boolean> salvar(@RequestBody DadoSocialPortifolioTO dadoSocialPortifolioTO) {
        boolean successfully = dadoSocialPortifolioService.salvarDadosSocialPortifolio(dadoSocialPortifolioTO);
        return ResponseEntity.ok(successfully);
    }

    @PostMapping("/ano/{ano}/cooperativa/{idCooperativa}")
    public ResponseEntity<Boolean> salvarCooperativaFates(@PathVariable Integer ano, @PathVariable Integer idCooperativa, @RequestBody CooperativaFatesTO cooperativaFatesTO) {
        try {
            cooperativaFatesService.salvarOuAtualizar(ano, idCooperativa, cooperativaFatesTO);
            return ResponseEntity.ok(true);
        } catch (Exception e) {
            return ResponseEntity.ok(false);
        }
    }

    @PostMapping("/negocio-exportacao")
    public ResponseEntity<Boolean> salvarNegocioExportacao(@RequestBody NegocioExportacaoTO negocioExportacaoTO) {
        try {
            NegocioExportacao ne = negocioExportacaoService.salvarNegocioExportacao(negocioExportacaoTO);
            return ResponseEntity.ok(Objects.nonNull(ne));
        } catch (Exception e) {
            return ResponseEntity.ok(false);
        }
    }

    @GetMapping("/validacoes/{idCooperativa}")
    public ResponseEntity<ValidacaoPrimeiroRegistroTO> getValidacoes(@PathVariable Integer idCooperativa){
        ValidacaoPrimeiroRegistroTO validacao = dadoSocialPortifolioService.validarDadoSocialPortifolio(idCooperativa);
        return ResponseEntity.ok(validacao);
    }
}
