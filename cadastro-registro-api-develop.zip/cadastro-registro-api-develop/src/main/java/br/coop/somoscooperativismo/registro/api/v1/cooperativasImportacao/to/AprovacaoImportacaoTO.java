package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AprovacaoImportacaoTO {
    private Integer id;
    private Integer ano;
    private Date dataAtualizacao;
}
