package br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.to.ControleAtualizacaoCadastralTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/controle-atualizacao-cadastral")
@Tag(name = "Controle da atualização cadastral")
public class ControleAtualizacaoCadastralRestController {

	private final ControleAtualizacaoCadastralService controleAtualizacaoCadastralService;

	public ControleAtualizacaoCadastralRestController(
			ControleAtualizacaoCadastralService controleAtualizacaoCadastralService) {
		this.controleAtualizacaoCadastralService = controleAtualizacaoCadastralService;
	}

	@Operation(summary = "Obter controle da atualização cadastral por UF")
	@GetMapping("/{uf}")
	public ResponseEntity<ServiceResponse<ControleAtualizacaoCadastralTO>> getControleAtualizacaoCadastralPorUf(
			@PathVariable String uf) {
		return ResponseEntity.ok(new ServiceResponse<>(controleAtualizacaoCadastralService.obterPorUf(uf)));
	}
	
	@Operation(summary = "Obter controle da atualização cadastral por UF")
	@GetMapping("/obter-por-uf/{uf}")
	public ResponseEntity<ServiceResponse<ControleAtualizacaoCadastralTO>> obterControleAtualizacaoCadastralPorUf(
			@PathVariable String uf) {
		return ResponseEntity.ok(new ServiceResponse<>(controleAtualizacaoCadastralService.buscarControleExistente(uf)));
	}
	
	@Operation(summary = "Obter controle da atualização cadastral Nacional")
	@GetMapping("/obter-controle-nacional")
	public ResponseEntity<ServiceResponse<ControleAtualizacaoCadastralTO>> obterControleAtualizacaoCadastralNacional() {
		return ResponseEntity.ok(new ServiceResponse<>(controleAtualizacaoCadastralService.obterControleNacional()));
	}

	@PostMapping
	@Operation(summary = "Altera o controle da atualização cadastral")
	public ResponseEntity<ServiceResponse<ControleAtualizacaoCadastralTO>> updateControleAtualizacaoCadastral(
			@RequestBody @Valid ControleAtualizacaoCadastralTO controleAtualizacaoCadastralTO) {
		ServiceMessage message = new ServiceMessage("Registro atualizado com sucesso");
		return new ResponseEntity<>(
				new ServiceResponse<>(controleAtualizacaoCadastralService.salvar(controleAtualizacaoCadastralTO), message),
				HttpStatus.OK);
	}
	
	
	@PostMapping("/atualizar-controle-atualizacao-cadastral")
	@Operation(summary = "Altera o controle da atualização cadastral")
	public ResponseEntity<ServiceResponse<Void>> desabilitaControleAtualizacaoCadastral(@RequestBody boolean ativa){
		controleAtualizacaoCadastralService.desabilitarControleAtualizacaoCadastral(ativa);
		ServiceMessage message = new ServiceMessage("Controles de atualização cadastral atualizados com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
}
