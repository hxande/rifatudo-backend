package br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.entidade;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import org.springframework.lang.Nullable;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.solicitacao.entidade.Solicitacao;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name  = "COOPERATIVA_SOLICITACAO")
public class CooperativaSolicitacao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_SOLICITACAO")
	private Integer id;
	
	@OneToOne
	@JoinColumn(name = "SQ_SOLICITACAO")
	private Solicitacao solicitacao;

	@OneToOne
	@JoinColumn(name = "SQ_COOPERATIVA")
	@JsonBackReference
	private Cooperativa cooperativa;
	
	@Column(name = "TX_OUTRO_MOTIVO")
	@Nullable
	private String outroMotivoDesc;
	
	@Transient
	private String anexo;

	@Transient
	private String anexoNotificacao;

}
