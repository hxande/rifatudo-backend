package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.orgao.entidade.Orgao;
import br.coop.somoscooperativismo.registro.api.v1.orgao.OrgaoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/orgaos")
public class OrgaoImportacaoRestController {

    private final OrgaoService orgaoService;

    @GetMapping("/ativos")
    public ResponseEntity<List<Orgao>> getAtivos() {
        return ResponseEntity.ok(orgaoService.getOrgaos());
    }
}
