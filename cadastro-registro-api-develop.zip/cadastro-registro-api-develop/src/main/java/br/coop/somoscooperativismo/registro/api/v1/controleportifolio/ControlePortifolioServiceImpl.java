package br.coop.somoscooperativismo.registro.api.v1.controleportifolio;

import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.controleportifolio.entidade.ControlePortifolio;

@Service
@Transactional
public class ControlePortifolioServiceImpl implements ControlePortifolioService {
	
	private final KeycloakService keycloakService;
	private final ControlePortifolioRepository controlePortifolioRespoitory;
	
	public ControlePortifolioServiceImpl(KeycloakService keycloakService,
			ControlePortifolioRepository controlePortifolioRespoitory) {
		this.keycloakService = keycloakService;
		this.controlePortifolioRespoitory = controlePortifolioRespoitory;
	}

	@Override
	public ControlePortifolio salvar(ControlePortifolio controlePortifolio) {
		if(!(this.keycloakService.isTipoEntidadeNacional())) {
			throw new RegraNegocioException("Usuário permissão para esta operação");
		}
		
		
		if(!ValidacaoCampos.validaCampoPreenchido(controlePortifolio.getUf())) {
			throw new RegraNegocioException("UF não informada");
		}
		
		Optional<ControlePortifolio> opControlePortifolio = controlePortifolioRespoitory.findByUf(controlePortifolio.getUf());

		if(opControlePortifolio.isPresent()) {
			opControlePortifolio.get().setInformarCampos(controlePortifolio.getInformarCampos());
			return controlePortifolioRespoitory.save(opControlePortifolio.get());
		} else {
			return controlePortifolioRespoitory.save(controlePortifolio);
		}
		
	}

	@Override
	public ControlePortifolio obterPorUf(String uf) {
		Optional<ControlePortifolio> opControlePortifolio = controlePortifolioRespoitory.findByUf(uf);
		if(opControlePortifolio.isEmpty()) {
			ControlePortifolio controlePortifolio = new ControlePortifolio();
			controlePortifolio.setUf(uf);
			controlePortifolio.setInformarCampos(false);
			return controlePortifolio;
		}
		return opControlePortifolio.get();
	}

	@Override
	public ControlePortifolio obterControleNacional() {
		return controlePortifolioRespoitory.findByUfIsNull();
		
	}

	@Override
	public ControlePortifolio habilitaControleNacional(boolean ativa) {
		ControlePortifolio controleNacional = obterControleNacional();
		controleNacional.setInformarCampos(Boolean.valueOf(ativa));
		return controlePortifolioRespoitory.save(controleNacional);
	}


}
