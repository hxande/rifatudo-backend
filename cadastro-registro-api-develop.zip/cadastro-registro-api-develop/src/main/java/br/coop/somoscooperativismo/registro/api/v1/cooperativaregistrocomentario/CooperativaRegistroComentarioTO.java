package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
public class CooperativaRegistroComentarioTO {
    private Integer cooperativaRegistroId;
    private List<Long> motivos;
    private String observacao;
    private String acao;
    private Date dataAlteracao;
    private String usuarioAlteracao;

}
