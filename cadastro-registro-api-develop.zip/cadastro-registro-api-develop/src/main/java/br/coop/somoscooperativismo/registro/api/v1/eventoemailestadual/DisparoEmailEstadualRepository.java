package br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual;

import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.entidade.DisparoEmailEstadual;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to.DisparoEmailEstadualTO;

public interface DisparoEmailEstadualRepository extends JpaRepository<DisparoEmailEstadual, Integer>{

	@Query(value = """
			SELECT new br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.to.DisparoEmailEstadualTO(dee.id, dee.disparoEmail.id, tpe.descricao, dee.disparoEmail.textoDescricaoEmail, dee.disparoEmail.textoVariavelEmail, dee.envia, dee.uf) 
			FROM DisparoEmailEstadual dee
			left join TipoProcessoEmail tpe
			on tpe.id = dee.disparoEmail.idTipoProcessoEmail
			where (dee.disparoEmail.ativo = true) 
			and (coalesce(:ufs,'') = '' or dee.uf in :ufs)
			and (upper(dee.disparoEmail.destinatarioEmail) like upper(:destinatario))
			and (:tipoProcesso is null or upper(tpe.descricao) like '%' || upper(:tipoProcesso) || '%')
			and (:emailDescricao is null or upper(dee.disparoEmail.textoDescricaoEmail) like '%' || upper(:emailDescricao) || '%')
			""")
	Page<DisparoEmailEstadualTO> obterPaginadoDisparEmailEstadual( String destinatario,List<String> ufs, String tipoProcesso, String emailDescricao, Pageable pageable);

	DisparoEmailEstadual findByDisparoEmailIdAndUf(Integer disparoEmailId, String uf);
}
