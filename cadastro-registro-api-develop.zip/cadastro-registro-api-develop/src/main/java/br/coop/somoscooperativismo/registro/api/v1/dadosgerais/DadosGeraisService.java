package br.coop.somoscooperativismo.registro.api.v1.dadosgerais;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cadastroregistro.CadastroRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.AbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.CooperativaManutencaoAbasService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.CooperativaVinculacaoService;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.entidade.DadosGerais;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.entidade.DadosGeraisResponse;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao.DadosGeraisValidacaoContato;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao.DadosGeraisValidacaoDadosBasicos;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao.DadosGeraisValidacaoEndereco;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao.DadosGeraisValidacaoGrau;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao.DadosGeraisValidacaoQuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.documentocliente.DocumentoClient;
import br.coop.somoscooperativismo.registro.api.v1.endereco.EnderecoService;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaService;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.LocalizacaoClient;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.UFTO;
import br.coop.somoscooperativismo.registro.api.v1.mandato.MandatoService;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaBlocoEnum;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.ValidacaoPendenciaTO;
import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.PeriodoAtualizacaoService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.PessoaSegmProdServService;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.entidade.PessoaSegmProdServ;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.quadroSocialParametroQuadro.QuadroSocialParametroQuadroService;
import br.coop.somoscooperativismo.registro.api.v1.quadroSocialParametroQuadroCooperado.QuadroSocialParametroQuadroCooperadoService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;
import br.coop.somoscooperativismo.registro.api.v1.ramotroca.RamoTrocaService;
import br.coop.somoscooperativismo.registro.api.v1.ramotroca.entidade.RamoTroca;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.RedeSocialService;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.entidade.RedeSocial;
import br.coop.somoscooperativismo.registro.api.v1.sindicato.SindicatoCooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.sindicato.SindicatoService;
import br.coop.somoscooperativismo.registro.api.v1.sindicato.entidade.SindicatoCooperativa;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroStateFactory;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.TipoEnderecoEnum;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.TipoEnderecoService;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.entidade.TipoEndereco;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Service
public class DadosGeraisService {

    private final MessagesService messages;
    private final PessoaJuridicaService pessoaJuridicaService;
    private final CooperativaService cooperativaService;
    private final EnderecoService enderecoService;
    private final RamoTrocaService ramoTrocaService;
    private final RedeSocialService redeSocialService;
    private final GovernancaService governancaService;
    private final CooperativaVinculacaoService cooperativaVinculacaoService;
    private final TipoEnderecoService tipoEnderecoService;
    private final CooperativaPendenciaService cooperativaPendenciaService;
    private final QuadroSocialService quadroSocialService;
    private final CadastroRegistroService cadastroRegistroService;
    private final LocalizacaoClient localizacaoClient;
    private final DocumentoClient documentoCliente;
    private final PeriodoAtualizacaoService periodoAtualizacaoService;
    private final CooperativaManutencaoAbasService cooperativaManutencaoAbasService;
    private final MandatoService mandatoService;
    private final PessoaSegmProdServService segmProdService;
    private final KeycloakService keycloakService;
    private final SindicatoService sindicatoService;
    private final PeriodoAtualizacaoService periodoService;
    private final QuadroSocialParametroQuadroService parametroQuadroSocialService;
    private final QuadroSocialParametroQuadroCooperadoService parametroQuadroSocialCooperadoService;
    private final ProgressoCadastroStateFactory progressoCadastroStateFactory;
    private final SindicatoCooperativaService sindicatoCooperativaService;

    public DadosGeraisService(
            MessagesService messages,
            PessoaJuridicaService pessoaJuridicaService,
            @Lazy CooperativaService cooperativaService,
            EnderecoService enderecoService,
            RamoTrocaService ramoTrocaService,
            RedeSocialService redeSocialService,
            GovernancaService governancaService,
            CooperativaVinculacaoService cooperativaVinculacaoService,
            TipoEnderecoService tipoEnderecoService,
            CooperativaPendenciaService cooperativaPendenciaService,
            QuadroSocialService quadroSocialService,
            @Lazy CadastroRegistroService cadastroRegistroService,
            @Qualifier("localizacaoClientLocal") LocalizacaoClient localizacaoClient,
            DocumentoClient documentoCliente,
            PeriodoAtualizacaoService periodoAtualizacaoService,
            CooperativaManutencaoAbasService cooperativaManutencaoAbasService,
            MandatoService mandatoService,
            PessoaSegmProdServService segmProdService,
            KeycloakService keycloakService,
            SindicatoService sindicatoService,
            PeriodoAtualizacaoService periodoService,
            QuadroSocialParametroQuadroService parametroQuadroSocialService,
            QuadroSocialParametroQuadroCooperadoService parametroQuadroSocialCooperadoService,
            ProgressoCadastroStateFactory progressoCadastroStateFactory,
            SindicatoCooperativaService sindicatoCooperativaService) {
        this.messages = Objects.requireNonNull(messages, "messages");
        this.pessoaJuridicaService = Objects.requireNonNull(pessoaJuridicaService, "pessoaJuridicaService");
        this.cooperativaService = Objects.requireNonNull(cooperativaService, "cooperativaService");
        this.enderecoService = Objects.requireNonNull(enderecoService, "enderecoService");
        this.ramoTrocaService = Objects.requireNonNull(ramoTrocaService, "ramoTrocaService");
        this.redeSocialService = Objects.requireNonNull(redeSocialService, "redeSocialService");
        this.governancaService = Objects.requireNonNull(governancaService, "governancaService");
        this.cooperativaVinculacaoService = Objects.requireNonNull(cooperativaVinculacaoService, "cooperativaVinculacaoService");
        this.tipoEnderecoService = Objects.requireNonNull(tipoEnderecoService, "tipoEnderecoService");
        this.cooperativaPendenciaService = Objects.requireNonNull(cooperativaPendenciaService, "cooperativaPendenciaService");
        this.quadroSocialService = Objects.requireNonNull(quadroSocialService, "quadroSocialService");
        this.cadastroRegistroService = Objects.requireNonNull(cadastroRegistroService, "cadastroRegistroService");
        this.localizacaoClient = Objects.requireNonNull(localizacaoClient, "localizacaoClient");
        this.documentoCliente = Objects.requireNonNull(documentoCliente, "documentoCliente");
        this.periodoAtualizacaoService = Objects.requireNonNull(periodoAtualizacaoService, "periodoAtualizacaoService");
        this.cooperativaManutencaoAbasService = Objects.requireNonNull(cooperativaManutencaoAbasService, "cooperativaManutencaoAbasService");
        this.mandatoService = Objects.requireNonNull(mandatoService, "mandatoService");
        this.segmProdService = Objects.requireNonNull(segmProdService, "segmProdService");
        this.keycloakService = Objects.requireNonNull(keycloakService, "keycloakService");
        this.sindicatoService = Objects.requireNonNull(sindicatoService, "sindicatoService");
        this.periodoService = Objects.requireNonNull(periodoService, "periodoService");
        this.parametroQuadroSocialService = Objects.requireNonNull(parametroQuadroSocialService, "parametroQuadroSocialService");
        this.parametroQuadroSocialCooperadoService = Objects.requireNonNull(parametroQuadroSocialCooperadoService, "parametroQuadroSocialCooperadoService");
        this.progressoCadastroStateFactory = Objects.requireNonNull(progressoCadastroStateFactory, "progressoCadastroStateFactory");
        this.sindicatoCooperativaService = Objects.requireNonNull(sindicatoCooperativaService, "sindicatoCooperativaService");
    }

	public static final String NAO_ENCONTRADO = "dadosGerais.pessoaJuridica.naoEncontrada";

	public static final String VALIDACAO_COOPERATIVA_NAO_ENCONTRADA = "dadosGerais.validacao.cooperativaNaoEncontrada";
	public static final String VALIDACAO_COOPERATIVA_JA_REGISTRADA = "dadosGerais.validacao.cooperativaJaRegistrada";

	public static final String AGUARDANDO_PROCESSO = "dadosGerais.validacao.aguardandoProcesso";

	public static final String REDE_SOCIAL_SEM_LINK = "redeSocial.semLink";
	private static final String PERMISSAO_ALTERACAO = "permissao.alteracao.situacao";

    public Ramo obterRamoComDadosGovernacaENegocio(Integer idCooperativa, String idRamo) {

        Ramo r = null;
        idRamo = "null".equals(idRamo) ? "-1" : idRamo;
        Cooperativa c = cooperativaService.getCooperativa(idCooperativa);

        if (Objects.isNull(c) || Objects.isNull(c.getPessoaJuridica())) {
            return null;
        }

        if (Objects.nonNull(c.getPessoaJuridica().getRamo())) {
            List<Mandato> listaMandato = mandatoService.getMandatosPorCooperativa(c.getPessoaJuridica().getId());
            List<PessoaSegmProdServ> listaProdutos = segmProdService.buscaPorPessoaJuridica(c.getPessoaJuridica());
            if (!Objects.equals(c.getPessoaJuridica().getRamo().getId(), Integer.valueOf(idRamo))
                    && (ValidacaoCampos.validaCampoPreenchido(listaMandato)
                    || ValidacaoCampos.validaCampoPreenchido(listaProdutos))) {
                r = c.getPessoaJuridica().getRamo();
            }
        }

        return r;
    }

	public ValidacaoPrimeiroRegistroTO validarDadosGerais(Integer idCooperativa) {
		ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Dados Gerais");
		List<ServiceMessage> mensagens = new ArrayList<>();

		DadosGeraisValidacaoDadosBasicos validacaoDadosBasicos = new DadosGeraisValidacaoDadosBasicos();
		DadosGeraisValidacaoEndereco validacaoEndereco = new DadosGeraisValidacaoEndereco();
		DadosGeraisValidacaoContato validacaoContato = new DadosGeraisValidacaoContato();
		DadosGeraisValidacaoQuadroSocial validacaoQuadroSocial = new DadosGeraisValidacaoQuadroSocial();
		DadosGeraisValidacaoGrau validacaoGrau = new DadosGeraisValidacaoGrau();

		// Validando dados básicos
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);

        if (Objects.isNull(c) || Objects.isNull(c.getPessoaJuridica())) {
            mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_COOPERATIVA_NAO_ENCONTRADA)));
            vpr.setMensagens(mensagens);
            return vpr;
        }

        if (ValidacaoCampos.validaCampoPreenchido(c.getNumeroRegistroOCB())) {
            mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_COOPERATIVA_JA_REGISTRADA)));
            vpr.setMensagens(mensagens);
            return vpr;
        }

		mensagens = validacaoDadosBasicos.validaDadosBasicos(mensagens, c, messages);

        // Validando Endereço
        List<TipoEndereco> te = tipoEnderecoService.obterTiposEnderecosPrincipais();

        if (Objects.nonNull(te)) {
            Endereco enderecoAux;

			UFTO UFEndereco = null;
			for (TipoEndereco tipoEndereco : te) {
				enderecoAux = enderecoService.obterEndereco(c.getId(), tipoEndereco.getId());

                if (Objects.nonNull(enderecoAux) && Objects.nonNull(enderecoAux.getIdEstado())) {
                    UFEndereco = localizacaoClient.buscaUf(enderecoAux.getIdEstado());
                }

				mensagens = validacaoEndereco.validaEndereco(c, UFEndereco, mensagens, enderecoAux, tipoEndereco);
				localizacaoClient.validaCEP(enderecoAux, mensagens);
			}
		}

		// Validando Contatos

		mensagens = validacaoContato.validaContato(mensagens, c, messages);

		// Validando Dados Sociais

		QuadroSocial qs = quadroSocialService.getQuadroSocialAtual(c.getId());
		mensagens = validacaoQuadroSocial.validaQuadroSocial(mensagens, qs, messages, false);

		// Validando Grau (Categoria) da Cooperativa

		mensagens = validacaoGrau.validaGrau(mensagens, c, messages, cooperativaService);

        // ######### PARA MELHOR EXPERIÊNCIA DO USUÁRIO #####################
        // ######### Verificar se a aba está ativa, se não tiver, então não mostra as
        // mensagens ##########
        ValidacaoPendenciaTO pendenciasAbas = cooperativaPendenciaService.obterPendenciasAbas(c.getId());
        if (Objects.nonNull(pendenciasAbas) && Objects.nonNull(pendenciasAbas.getDadosGerais())
                && Objects.nonNull(pendenciasAbas.getDadosGerais().getAbaPreenchida())
                && Boolean.FALSE.equals(pendenciasAbas.getDadosGerais().getAbaPreenchida())) {
            mensagens.clear();
        }
        // ################################################################################################

		vpr.setMensagens(mensagens);

		// Se não tiver críticas, então está validado
		if (mensagens.isEmpty()) {
	      vpr.setValidadoNaoObrigatorios(
	              validacaoContato.validaNaoObrigatorios(c)
	              && validacaoQuadroSocial.validaNaoObrigatorios(qs));


			CooperativaPendenciaBlocoEnum[] lista = new CooperativaPendenciaBlocoEnum[] {
					CooperativaPendenciaBlocoEnum.DADOS_GERAIS_CONTATOS_DA_COOPERATIVA,
					CooperativaPendenciaBlocoEnum.DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA,
					CooperativaPendenciaBlocoEnum.DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA,
					CooperativaPendenciaBlocoEnum.DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA };
			vpr.setValidado(cooperativaPendenciaService.verificarAbaValidada(c, lista));
		} else {
			vpr.setValidado(false);
		}

        return vpr;
    }

    public ValidacaoPrimeiroRegistroTO validarDadosGeraisQuandoSalvar(Cooperativa cooperativa) {
        ValidacaoPrimeiroRegistroTO vpr = this.validarDadosGerais(cooperativa.getId());
        boolean validadoPendencias = true;
        if (Objects.isNull(vpr.getMensagens()) || (vpr.getMensagens().isEmpty() && vpr.getValidado())) {
            CooperativaPendenciaBlocoEnum[] lista = new CooperativaPendenciaBlocoEnum[]{
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_CONTATOS_DA_COOPERATIVA,
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA,
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA,
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA};
            validadoPendencias = cooperativaPendenciaService.verificarAbaValidadaQuandoSalvar(cooperativa, lista);
        }
        vpr.setValidado(validadoPendencias && vpr.getValidado());
        return vpr;
    }

	public ValidacaoPrimeiroRegistroTO validarDadosGeraisManutencao(Integer idCooperativa, boolean forcarValidacao) {
		ValidacaoPrimeiroRegistroTO vpr = new ValidacaoPrimeiroRegistroTO("Dados Gerais");
		List<ServiceMessage> mensagens = new ArrayList<>();

		DadosGeraisValidacaoDadosBasicos validacaoDadosBasicos = new DadosGeraisValidacaoDadosBasicos();
		DadosGeraisValidacaoEndereco validacaoEndereco = new DadosGeraisValidacaoEndereco();
		DadosGeraisValidacaoContato validacaoContato = new DadosGeraisValidacaoContato();
		DadosGeraisValidacaoQuadroSocial validacaoQuadroSocial = new DadosGeraisValidacaoQuadroSocial();
		DadosGeraisValidacaoGrau validacaoGrau = new DadosGeraisValidacaoGrau();

		// Validando dados básicos
		Cooperativa c = cooperativaService.getCooperativa(idCooperativa);

        if (Objects.isNull(c) || Objects.isNull(c.getPessoaJuridica())) {
            mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_COOPERATIVA_NAO_ENCONTRADA)));
            vpr.setMensagens(mensagens);
            return vpr;
        }

        mensagens = validacaoDadosBasicos.validaDadosBasicos(mensagens, c, messages);

        // Validando Endereço
        List<TipoEndereco> te = tipoEnderecoService.obterTiposEnderecosPrincipais();
        if (Objects.nonNull(te)) {
            Endereco enderecoAux;
            UFTO UFEndereco = null;
            for (TipoEndereco tipoEndereco : te) {
                enderecoAux = enderecoService.obterEndereco(c.getId(), tipoEndereco.getId());

                if (Objects.nonNull(enderecoAux) && Objects.nonNull(enderecoAux.getIdEstado())) {
                    UFEndereco = localizacaoClient.buscaUf(enderecoAux.getIdEstado());
                }

				mensagens = validacaoEndereco.validaEndereco(c, UFEndereco, mensagens, enderecoAux, tipoEndereco);
				localizacaoClient.validaCEP(enderecoAux, mensagens);
			}
		}

		// Validando Contatos
		mensagens = validacaoContato.validaContato(mensagens, c, messages);

        // Validando Dados Sociais
        List<QuadroSocial> qSociais = quadroSocialService.getQuadroSociaisManutencao(c.getId());
        if (Objects.nonNull(qSociais) && !qSociais.isEmpty()) {
            for (QuadroSocial quadro : qSociais) {
                mensagens = validacaoQuadroSocial.validaQuadroSocial(mensagens, quadro, messages, false);
            }
        }

		// Validando Grau (Categoria) da Cooperativa
		mensagens = validacaoGrau.validaGrau(mensagens, c, messages, cooperativaService);

        // ######### PARA MELHOR EXPERIÊNCIA DO USUÁRIO #####################
        // ######### Verificar se a aba está ativa, se não tiver, então não mostra as
        // mensagens ##########
        ValidacaoPendenciaTO pendenciasAbas = cooperativaPendenciaService.obterPendenciasAbasManutencao(c.getId());
        if (Objects.nonNull(pendenciasAbas) && Objects.nonNull(pendenciasAbas.getDadosGerais())
                && Objects.nonNull(pendenciasAbas.getDadosGerais().getAbaPreenchida())
                && Boolean.FALSE.equals(pendenciasAbas.getDadosGerais().getAbaPreenchida()) && Boolean.FALSE.equals(forcarValidacao)) {

			mensagens.clear();
		}
		// ################################################################################################

		vpr.setMensagens(mensagens);

		// Se não tiver críticas, então está validado
		if (mensagens.isEmpty()) {
			CooperativaPendenciaBlocoEnum[] lista = new CooperativaPendenciaBlocoEnum[] {
					CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_CONTATOS_DA_COOPERATIVA,
					CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA,
					CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA,
					CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA };
			vpr.setValidado(cooperativaPendenciaService.verificarAbaValidadaManutencao(c, lista));
		} else {
			vpr.setValidado(false);
		}

		return vpr;
	}

    @Deprecated
    public boolean salvarDadosGeraisManutencao(DadosGerais dadosGerais, boolean apenasDadosSociaisAnoCorrente, boolean importacao) {
        validarDadosManutencao(dadosGerais);

		// Estágio Inicial
		Cooperativa cooperativa = cooperativaService.getCooperativa(dadosGerais.getCooperativa().getId());
		PessoaJuridica pessoaJuridica = cooperativa.getPessoaJuridica();

		// Verificando mudança de Ramo
		boolean mudouRamo = !importacao && verificaMudouRamo(cooperativa, dadosGerais.getCooperativa().getPessoaJuridica());

        atualizarCooperativaEPessoaJuridica(
                cooperativa, pessoaJuridica, dadosGerais, importacao);

		// Sincronização de endereços
		cooperativaService.sincronizarEnderecos(cooperativa, dadosGerais.getEnderecos());

        // Sincronização de redes sociais
        cooperativaService.sincronizarRedesSociais(cooperativa, dadosGerais.getRedesSociais());

        //atualizar informacoes  do quadroscocial apenas para o ano corrente.
        ajustarQuadroSocialAnoCorrente(dadosGerais, apenasDadosSociaisAnoCorrente);


        // Sincronização de quadro social
        cooperativaService.sincronizarQuadroSocialManutencao(cooperativa, dadosGerais.getQuadroSocialManutencao());

		cooperativaService.save(cooperativa);

		if (mudouRamo) {
			excluiMandatosForaDoRamo(dadosGerais.getCooperativa());
			buscaExcluiProdutoServicos(dadosGerais.getCooperativa().getPessoaJuridica());
		}

        salvarParametrosQuadroSocial(dadosGerais.getQuadroSocialManutencao());

        // Salvando Vinculações
        salvarVinculacoes(cooperativa, dadosGerais);

		// Quadros Sociais
		salvarQuadrosSociaisManutencao(cooperativa, dadosGerais.getQuadroSocialManutencao());

        // ------------- Marcar como Validado ( PENDÊNCIAS ) ---------
        marcarAjustesManutencaoComoValidados(cooperativa);
        // ------------------------------------------------------------------

        ValidacaoPrimeiroRegistroTO vpr = validarDadosGeraisManutencao(cooperativa.getId(), false);
        boolean salvoComPendecias = Objects.nonNull(vpr)
                && !vpr.getValidado();

        ValidacaoPrimeiroRegistroTO vprDocumento = documentoCliente.validarDocumentosManutencao(cooperativa.getId());
        boolean salvoComPendeciasDocumento = Objects.nonNull(vprDocumento)
                && !vprDocumento.getValidado();

		//inserir dados abaDadosGerais
		//validandoAbaDadosGerais(cooperativa, salvoComPendecias);
		cooperativaManutencaoAbasService.salvarStatusAbasManutencao(cooperativa.getId(), !salvoComPendecias, AbaEnum.ABA_DADOS_GERAIS);
		cooperativaManutencaoAbasService.salvarStatusAbasManutencao(cooperativa.getId(), !salvoComPendeciasDocumento, AbaEnum.ABA_DOCUMENTOS);

		return !salvoComPendecias;
	}

    private void validarDadosManutencao(DadosGerais dadosGerais) {
        validaCooperativaManutencao(dadosGerais);
        validaEndereco(dadosGerais);
        preservarCamposCooperativaManutencao(dadosGerais);
        validaRedesSociais(dadosGerais);
        validaQuadrosSociais(dadosGerais.getQuadroSocialManutencao());
    }

    private void atualizarCooperativaEPessoaJuridica(
            Cooperativa cooperativa,
            PessoaJuridica pessoaJuridica,
            DadosGerais dadosGerais,
            boolean importacao) {
        Cooperativa dadosCooperativa = dadosGerais.getCooperativa();
        PessoaJuridica dadosPessoaJuridica = dadosCooperativa.getPessoaJuridica();

        dadosCooperativa.setDataAtualizacao(new Date());
        if ("C".equals(keycloakService.getTipoUsuario())
                && (Objects.isNull(dadosCooperativa.getProgressoManutencaoMicro())
                || ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2
                .equals(dadosCooperativa.getProgressoManutencaoMicro()))) {
            cooperativa.setNaoSubmeteu(Boolean.TRUE);
        }
        cooperativa.setDataAtualizacao(new Date());
        cooperativa.setLiquidacao(dadosCooperativa.getLiquidacao());
        cooperativa.setCategoria(dadosCooperativa.getCategoria());

        if ("N".equals(keycloakService.getTipoUsuario())
                || "E".equals(keycloakService.getTipoUsuario())) {
            cooperativa.setRegidaPorLei(dadosCooperativa.getRegidaPorLei());
        }
        if (Boolean.TRUE.equals(cooperativa.getLiquidacao())
                && Objects.nonNull(pessoaJuridica.getRazaoSocial())) {
            String sufixoLiquidacao = " - Em liquidação";
            String razaoSocial = pessoaJuridica.getRazaoSocial();
            pessoaJuridica.setRazaoSocial(razaoSocial.contains(sufixoLiquidacao)
                    ? razaoSocial
                    : razaoSocial + sufixoLiquidacao);
        }
        if ((keycloakService.isVerificaPossuiSubPerfil("UN_GES")
                || keycloakService.isVerificaPossuiSubPerfil("UE_GES"))
                && Objects.nonNull(dadosCooperativa.getCategoria())) {
            cooperativa.setCategoria(dadosCooperativa.getCategoria());
        }

        pessoaJuridica.setRazaoSocial(dadosPessoaJuridica.getRazaoSocial());
        pessoaJuridica.setNomeFantasia(dadosPessoaJuridica.getNomeFantasia());
        pessoaJuridica.setNire(dadosPessoaJuridica.getNire());
        pessoaJuridica.setDataConstituicao(dadosPessoaJuridica.getDataConstituicao());
        if (!importacao) {
            pessoaJuridica.setRamo(dadosPessoaJuridica.getRamo());
        }
        pessoaJuridica.setEmailGeral(dadosPessoaJuridica.getEmailGeral());
        pessoaJuridica.setTelefoneGeral(dadosPessoaJuridica.getTelefoneGeral());
        pessoaJuridica.setSite(dadosPessoaJuridica.getSite());
        pessoaJuridica.setLojaVirtual(dadosPessoaJuridica.getLojaVirtual());
        cooperativa.setCategoria(dadosCooperativa.getCategoria());
    }

    private static void ajustarQuadroSocialAnoCorrente(
            DadosGerais dadosGerais,
            boolean apenasDadosSociaisAnoCorrente) {
        if (!apenasDadosSociaisAnoCorrente) {
            return;
        }
        QuadroSocial quadroSocial = dadosGerais.getQuadroSocialManutencao();
        dadosGerais.setQuadroSocialManutencao(
                Objects.nonNull(quadroSocial) ? quadroSocial : new QuadroSocial());
    }

    private void salvarParametrosQuadroSocial(QuadroSocial quadroSocial) {
        if (!ValidacaoCampos.validaCampoPreenchido(quadroSocial)) {
            return;
        }
        if (Objects.nonNull(quadroSocial.getParametroQuadros())) {
            quadroSocial.getParametroQuadros().forEach(parametro -> {
                parametro.getIdQuadroSocialParametroQuadro()
                        .setSqQuadroSocial(quadroSocial.getId());
                parametroQuadroSocialService.salvar(parametro);
            });
        }
        if (Objects.nonNull(quadroSocial.getParametroQuadrosCooperado())) {
            quadroSocial.getParametroQuadrosCooperado().forEach(parametro -> {
                parametro.getIdQuadroSocialParametroQuadroCooperado()
                        .setSqQuadroSocial(quadroSocial.getId());
                parametroQuadroSocialCooperadoService.salvar(parametro);
            });
        }
    }

    private void salvarVinculacoes(Cooperativa cooperativa, DadosGerais dadosGerais) {
        if (Objects.nonNull(dadosGerais.getCooperativasVinculadas())) {
            cooperativaVinculacaoService.vinculaCooperativasBasicas(
                    cooperativa.getId(), dadosGerais.getCooperativasVinculadas());
        }
    }

    private void marcarAjustesManutencaoComoValidados(Cooperativa cooperativa) {
        ProgressoMicroEnum progresso = obterProgressoParaValidacaoManutencao(cooperativa);
        if (Objects.isNull(progresso)) {
            return;
        }
        marcarAjusteValidado(cooperativa, progresso,
                CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_CONTATOS_DA_COOPERATIVA);
        marcarAjusteValidado(cooperativa, progresso,
                CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA);
        marcarAjusteValidado(cooperativa, progresso,
                CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA);
        marcarAjusteValidado(cooperativa, progresso,
                CooperativaPendenciaBlocoEnum.MANUTENCAO_DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA);
    }

    private void marcarAjusteValidado(
            Cooperativa cooperativa,
            ProgressoMicroEnum progresso,
            CooperativaPendenciaBlocoEnum bloco) {
        cooperativaPendenciaService.marcarAjustesComoValidados(
                cooperativa.getId(), bloco.name(), progresso);
    }

    private void validaEndereco(DadosGerais dadosGerais) {
        if (ValidacaoCampos.validaCampoPreenchido(dadosGerais.getEnderecos())) {

			Optional<Endereco> enderecoPrincipal = dadosGerais.getEnderecos().stream()
					.filter(e -> Integer.valueOf(TipoEnderecoEnum.ENDERECO_PRINCIPAL.getValue()).equals(e.getTipoEndereco().getId())).findFirst();
			if(enderecoPrincipal.isEmpty()) {
				throw new RegraNegocioException("Endereço de sede não informado");
			}

			if(keycloakService.isTipoEntidadeNacional()) {
				return;
			}


			validaUFCooperativa(enderecoPrincipal);

		}

	}

    protected void validaUFCooperativa(Optional<Endereco> enderecoPrincipal) {
        if (Objects.isNull(enderecoPrincipal) || enderecoPrincipal.isEmpty()) {
            return;
        }
        Endereco endereco = enderecoPrincipal.orElseThrow();
        if (ValidacaoCampos.validaCampoPreenchido(endereco.getIdEstado())) {
            UFTO uf = localizacaoClient.buscaUf(endereco.getIdEstado());
            if (Objects.nonNull(uf)
                    && !Objects.equals(uf.getSigla(), keycloakService.getUFUsuario())) {

                throw new RegraNegocioException("Para mudança de UF é necessário solicitar para a UF destino");
            }
        }
    }

	private void preservarCamposCooperativaManutencao(DadosGerais dadosGerais) {
		Cooperativa c = cooperativaService.getCooperativa(dadosGerais.getCooperativa().getId());

		if (!(keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional())) {
			dadosGerais.getCooperativa().setCategoria(c.getCategoria()); // GRAU
		}

    }

	@Transactional
	public Boolean salvarDadosGerais(@Valid DadosGeraisResponse response) {

        if (Objects.isNull(response.getIdCooperativa())) {
            throw new RegraNegocioException("O ID da coopreativa não foi informado.");
        }

		Cooperativa cooperativa = cooperativaService.getCooperativa(response.getIdCooperativa());
		cooperativa.setCategoria(response.getCategoria());
		cooperativa.setRegidaPorLei(response.getRegidaPorLei());

        if (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual()) {
        	cooperativa.setFiliacaoSindical(response.getFiliadaSindicato());

        	if(ValidacaoCampos.validaCampoPreenchido(response.getFiliadaSindicato())
                    && ValidacaoCampos.validaCampoPreenchido(response.getIdSindicato())) {
                var sindVinculado = this.sindicatoCooperativaService.getSindicatoFiliadoByIdCooperativa(cooperativa.getId());

                if (!ValidacaoCampos.validaCampoPreenchido(sindVinculado)) {
                    this.vincularNovoSindicatoCooperativa(response, cooperativa);
                } else if (!sindVinculado.getSindicato().getId().equals(response.getIdSindicato())) {
                    this.sindicatoCooperativaService.deleteById(sindVinculado.getId());
                    this.vincularNovoSindicatoCooperativa(response, cooperativa);
                }
            } else {
                this.sindicatoCooperativaService.deleteByCooperativaId(cooperativa.getId());
            }
        }

        PessoaJuridica pessoaJuridicaAtual = cooperativa.getPessoaJuridica();
        PessoaJuridica dadosRecebidos = response.getPessoaJuridica();

		mapearDadosGeraisPessoaJuridica(pessoaJuridicaAtual, dadosRecebidos);

		DadosGerais dadosGerais = new DadosGerais();
		dadosGerais.setCooperativa(cooperativa);
		dadosGerais.setEnderecos(response.getEnderecos());
		dadosGerais.setContatoCooperativa(response.getContatoCooperativa());
		dadosGerais.setRedesSociais(response.getRedesSociais());
		dadosGerais.setCooperativasVinculadas(response.getCooperativasVinculadas());
		dadosGerais.setQuadroSocialAtual(response.getQuadroSocialAtual());
		dadosGerais.setQuadroSocialManutencao(response.getQuadroSocialManutencao());

		// Validando dados (PESSOA JURÍDICA)
		validaCooperativa(dadosGerais);

		validaEndereco(dadosGerais);

		validaRedesSociais(dadosGerais);

		// Validando Quadro Social
		validaQuadroSocial(dadosGerais.getQuadroSocialAtual());

		// Verificando mudança de Ramo
		boolean mudouRamo = verificaMudouRamo(cooperativa, cooperativa.getPessoaJuridica());

		//Chamar o PreCadastroState para avançar etapa
		if(cooperativaEmPreCadastro(dadosGerais)) {
			cooperativa.setProgressoCadastroState(progressoCadastroStateFactory.createPreCadastroState());
			cooperativa.trocarEstado();
		}

		Cooperativa cooperativaSalva = persistirCooperativaAguardandoCadastroState(cooperativa, dadosGerais, cooperativa.getPessoaJuridica());

		if (mudouRamo) {
			excluiMandatosForaDoRamo(cooperativa);
			buscaExcluiProdutoServicos(cooperativa.getPessoaJuridica());
		}

        // Se ramo diferente de nulo atualiza os documentos para o ano do ciclo
        if (Objects.nonNull(cooperativa.getPessoaJuridica().getRamo())) {
            documentoCliente.atualizaDocCicloAtual(cooperativa.getId(),
                    periodoAtualizacaoService.obterAno(cooperativa.getId()));
        }

		// Salvando Vinculações
		cooperativaVinculacaoService.vinculaCooperativasBasicas(cooperativa.getId(),
				dadosGerais.getCooperativasVinculadas());

		// ------------- Marcar como Validado ( PENDÊNCIAS ) ---------
//		Cooperativa c = cooperativaService.getCooperativa(dadosGerais.getCooperativa().getId());
        ProgressoMicroEnum microPesquisar = obterProgressoParaValidacao(cooperativaSalva);
        if (Objects.nonNull(microPesquisar)) {
            cooperativaPendenciaService.marcarAjustesComoValidados(cooperativaSalva.getId(),
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_CONTATOS_DA_COOPERATIVA.name(), microPesquisar);
            cooperativaPendenciaService.marcarAjustesComoValidados(cooperativaSalva.getId(),
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA.name(), microPesquisar);
            cooperativaPendenciaService.marcarAjustesComoValidados(cooperativaSalva.getId(),
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA.name(), microPesquisar);
            cooperativaPendenciaService.marcarAjustesComoValidados(cooperativaSalva.getId(),
                    CooperativaPendenciaBlocoEnum.DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA.name(), microPesquisar);
        }
        // ------------------------------------------------------------------

        ValidacaoPrimeiroRegistroTO vpr = validarDadosGeraisQuandoSalvar(cooperativaSalva);
        boolean validado = Objects.nonNull(vpr) && vpr.getValidado();
        boolean validadoNaoObrig = Objects.nonNull(vpr) && vpr.isValidadoNaoObrigatorios();;

        cooperativaManutencaoAbasService.salvarStatusAbas(cooperativa.getId(), validado, AbaEnum.ABA_DADOS_GERAIS, validado, validadoNaoObrig);

		return validado;
	}

    protected void vincularNovoSindicatoCooperativa(DadosGeraisResponse response, Cooperativa cooperativa) {
        SindicatoCooperativa sindicatoCooperativa = new SindicatoCooperativa();
        sindicatoCooperativa.setCooperativa(cooperativa);
        sindicatoCooperativa.setDataAtualizacaoSindical(new Date());
        sindicatoCooperativa.setSindicato(sindicatoService.buscarSindicato(response.getIdSindicato()));
        sindicatoCooperativaService.save(sindicatoCooperativa);
    }

    private void mapearDadosGeraisPessoaJuridica(PessoaJuridica pessoaJuridicaBanco, PessoaJuridica dadosRecebidos) {
        if (Objects.isNull(pessoaJuridicaBanco) || Objects.isNull(dadosRecebidos)) {
            return;
        }
        pessoaJuridicaBanco.setCnpj(dadosRecebidos.getCnpj());
        pessoaJuridicaBanco.setRazaoSocial(dadosRecebidos.getRazaoSocial());
        pessoaJuridicaBanco.setNomeFantasiaReceitaFederal(dadosRecebidos.getNomeFantasiaReceitaFederal());
		pessoaJuridicaBanco.setNomeFantasia(dadosRecebidos.getNomeFantasia());
		pessoaJuridicaBanco.setUfSigla(dadosRecebidos.getUfSigla());
		pessoaJuridicaBanco.setDataConstituicao(dadosRecebidos.getDataConstituicao());
		pessoaJuridicaBanco.setNire(dadosRecebidos.getNire());
		pessoaJuridicaBanco.setTelefoneGeral(dadosRecebidos.getTelefoneGeral());
		pessoaJuridicaBanco.setEmailGeral(dadosRecebidos.getEmailGeral());
		pessoaJuridicaBanco.setSite(dadosRecebidos.getSite());
		pessoaJuridicaBanco.setLojaVirtual(dadosRecebidos.getLojaVirtual());
		pessoaJuridicaBanco.setPreCadastro(dadosRecebidos.getPreCadastro());
		pessoaJuridicaBanco.setSituacaoReceita(dadosRecebidos.getSituacaoReceita());
		pessoaJuridicaBanco.setTipoPessoa(dadosRecebidos.getTipoPessoa());
		pessoaJuridicaBanco.setNaturezaJuridica(dadosRecebidos.getNaturezaJuridica());
		pessoaJuridicaBanco.setRamo(dadosRecebidos.getRamo());
		pessoaJuridicaBanco.setExcluido(dadosRecebidos.getExcluido());
		pessoaJuridicaBanco.setMatriz(dadosRecebidos.getMatriz());
		pessoaJuridicaBanco.setTipoUnidade(dadosRecebidos.getTipoUnidade());
		pessoaJuridicaBanco.setOptanteSimples(dadosRecebidos.getOptanteSimples());
		pessoaJuridicaBanco.setInscricaoEstadual(dadosRecebidos.getInscricaoEstadual());
		pessoaJuridicaBanco.setInscricaoMunicipal(dadosRecebidos.getInscricaoMunicipal());
		pessoaJuridicaBanco.setDescricaoObjetoSocial(dadosRecebidos.getDescricaoObjetoSocial());
		pessoaJuridicaBanco.setCelular(dadosRecebidos.getCelular());
		pessoaJuridicaBanco.setCodigoColigada(dadosRecebidos.getCodigoColigada());
	}

	public Cooperativa persistirCooperativaAguardandoCadastroState(@Valid Cooperativa cooperativa, DadosGerais dadosGerais, PessoaJuridica pessoaJuridica) {
		cooperativaService.sincronizarEnderecos(cooperativa, dadosGerais.getEnderecos());
		cooperativaService.sincronizarRedesSociais(cooperativa, dadosGerais.getRedesSociais());
		quadroSocialService.salvarQuadroSocial(dadosGerais.getQuadroSocialAtual(), cooperativa);

		cooperativa.setCategoria(dadosGerais.getCooperativa().getCategoria());
		pessoaJuridica.setRazaoSocial(dadosGerais.getCooperativa().getPessoaJuridica().getRazaoSocial());
		pessoaJuridica.setNomeFantasia(dadosGerais.getCooperativa().getPessoaJuridica().getNomeFantasia());
		pessoaJuridica.setNire(dadosGerais.getCooperativa().getPessoaJuridica().getNire());
		pessoaJuridica.setDataConstituicao(dadosGerais.getCooperativa().getPessoaJuridica().getDataConstituicao());
		pessoaJuridica.setRamo(dadosGerais.getCooperativa().getPessoaJuridica().getRamo());
		pessoaJuridica.setEmailGeral(dadosGerais.getCooperativa().getPessoaJuridica().getEmailGeral());
		pessoaJuridica.setTelefoneGeral(dadosGerais.getCooperativa().getPessoaJuridica().getTelefoneGeral());
		pessoaJuridica.setSite(dadosGerais.getCooperativa().getPessoaJuridica().getSite());
		pessoaJuridica.setLojaVirtual(dadosGerais.getCooperativa().getPessoaJuridica().getLojaVirtual());

		if (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual()) {
			cooperativa.setRegidaPorLei(dadosGerais.getCooperativa().getRegidaPorLei());
		}
		return cooperativaService.save(cooperativa);
	}

	private boolean cooperativaEmPreCadastro(@Valid DadosGerais dadosGerais) {
		return dadosGerais.getCooperativa().getProgressoMicro() == ProgressoMicroEnum.PRE_CADASTRO_0_0
				|| dadosGerais.getCooperativa().getProgressoMacro() == ProgressoMacroEnum.PRE_CADASTRO_0;
	}

	private ProgressoMicroEnum obterProgressoParaValidacao(Cooperativa c) {
		if (ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2.equals(c.getProgressoMicro())) {
			return ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1;
		}
		return ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2.equals(c.getProgressoMicro())
				? ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1
				: null;
	}

	private ProgressoMicroEnum obterProgressoParaValidacaoManutencao(Cooperativa c) {
		return ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2.equals(c.getProgressoManutencaoMicro())
				? ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1
				: ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2;
	}

	/**
	 * Verifica se a Cooperativa mudou de ramo, e registra o histórico da mudança.
	 *
	 * @param cooperativa    Cooperativa já existente em banco.
	 * @param pessoaJuridica Pessoa Jurídica com as novas alterações.
	 * @return true/false
	 */
	protected boolean verificaMudouRamo(Cooperativa cooperativa, PessoaJuridica pessoaJuridica) {

		boolean mudouRamo = false;

		PessoaJuridica pj = cooperativa.getPessoaJuridica();

        Integer idNovoRamo = Objects.nonNull(pessoaJuridica.getRamo())
                ? pessoaJuridica.getRamo().getId()
                : null;
        if (Objects.nonNull(pj.getRamo())
                && !Objects.equals(pj.getRamo().getId(), idNovoRamo)) {

            String ramoNovo = "[VAZIO]";
            if (Objects.nonNull(pessoaJuridica.getRamo())) {
                ramoNovo = String.format("%s - %s", pessoaJuridica.getRamo().getId(),
                        pessoaJuridica.getRamo().getNome());
            }

			// Criando um log na tabela RamoTroca
			RamoTroca rt = new RamoTroca();
			rt.setCooperativa(cooperativa);
			rt.setDataAlteracao(new Date());
			rt.setLogin(keycloakService.getUsername());
			rt.setRamoAntigo(String.format("%s - %s", pj.getRamo().getId(), pj.getRamo().getNome()));
			rt.setRamoNovo(ramoNovo);

			ramoTrocaService.salvar(rt);

			mudouRamo = true;
		}

        return mudouRamo;
    }

	@Deprecated
	private void buscaExcluiProdutoServicos(PessoaJuridica pessoaJuridica) {
		List<PessoaSegmProdServ> lista = segmProdService.listaPorPessoa(pessoaJuridica.getId());
		for (PessoaSegmProdServ p : lista) {
			segmProdService.deletar(p.getId());
		}

    }

	private void excluiMandatosForaDoRamo(Cooperativa cooperativa) {
		governancaService.atualizarRamoRegistro(cooperativa.getId());
	}

	private void validaRedesSociais(@Valid DadosGerais dadosGerais) {
		if (ValidacaoCampos.validaCampoPreenchido(dadosGerais.getRedesSociais())) {
			for (RedeSocial rs : dadosGerais.getRedesSociais()) {
				if (ValidacaoCampos.validaCampoPreenchido(rs.getTipoRedeSocial())
						&& !ValidacaoCampos.validaCampoPreenchido(rs.getLink())) {
					throw new RegraNegocioException(messages.get(REDE_SOCIAL_SEM_LINK));
				}
			}
		}
	}

    private void salvarQuadrosSociaisManutencao(Cooperativa cooperativa, QuadroSocial quadrosSociais) {
        if (Objects.nonNull(quadrosSociais) && Objects.nonNull(quadrosSociais.getAno())) {
            quadrosSociais.setCooperativa(cooperativa);
            quadroSocialService.createQuadroSocial(quadrosSociais);
        }
    }

	public List<QuadroSocial> salvarQuadrosSociaisManutencaoHistorico(Integer idCooperativa,
			List<QuadroSocial> quadrosSociais) {

		if (keycloakService.isVerificaPossuiSubPerfil("CO_VIS")
				|| keycloakService.isVerificaPossuiSubPerfil("UE_VIS")
				|| Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("UN_VIS"))) {
			throw new RegraNegocioException(messages.get(PERMISSAO_ALTERACAO));
		}

        quadrosSociais.forEach(q -> {
            if (Objects.nonNull(q.getParametroQuadros())) {
                q.getParametroQuadros().forEach(p -> {
                    p.getIdQuadroSocialParametroQuadro().setSqQuadroSocial(q.getId());
                    parametroQuadroSocialService.salvar(p);
                });
            }
            if (Objects.nonNull(q.getParametroQuadrosCooperado())) {
                q.getParametroQuadrosCooperado().forEach(p -> {
                    p.getIdQuadroSocialParametroQuadroCooperado().setSqQuadroSocial(q.getId());
                    parametroQuadroSocialCooperadoService.salvar(p);
                });
            }
        });

        Cooperativa c = cooperativaService.getCooperativa(idCooperativa);
        Integer anoCiclo = periodoService.obterAno(c.getPessoaJuridica().getRamo());
        Integer anoCicloAnterior = anoCiclo - 2;

        Cooperativa cooperativa = cooperativaService.findById(idCooperativa);
        if (Objects.nonNull(quadrosSociais)) {
            for (QuadroSocial qs : quadrosSociais) {
                if (Objects.nonNull(qs) && Objects.nonNull(qs.getAno())) {
                    if (qs.getAno() > anoCicloAnterior) {
                        throw new RegraNegocioException("Quadro social não pertencente ao histórico");
                    }
                    qs.setCooperativa(cooperativa);
                    quadroSocialService.createQuadroSocialHistorico(qs);
                }
            }
        }

        return quadrosSociais;
    }

	public void atualizarNovosEnderecos(List<Endereco> enderecosSalvar, @Valid DadosGerais dadosGerais) {

		final Endereco sede = new Endereco();

		enderecosSalvar.forEach(e -> {
			if (Boolean.TRUE.equals(e.getTipoEndereco().getEnderecoPrincipal())) {
				sede.setPessoa(dadosGerais.getCooperativa().getPessoaJuridica());
				sede.setBairro(e.getBairro());
				sede.setCep(e.getCep());
				sede.setComplemento(e.getComplemento());
				sede.setDescricaoEndereco(e.getDescricaoEndereco());
				sede.setIdEstado(e.getIdEstado());
				sede.setIdMunicipio(e.getIdMunicipio());
				sede.setNumero(e.getNumero());
				sede.setEnderecoReferencia(e.getEnderecoReferencia());
				sede.setTipoEndereco(e.getTipoEndereco());
			}
		});

		for (Endereco e : enderecosSalvar) {
			// caso endereço correspondência seja vazio, salvar o mesmo endereço da sede
			if (Boolean.FALSE.equals(e.getCorrespondenciaDiferente())) {
				e.setBairro(sede.getBairro());
				e.setCep(sede.getCep());
				e.setComplemento(sede.getComplemento());
				e.setDescricaoEndereco(sede.getDescricaoEndereco());
				e.setEnderecoReferencia(sede.getEnderecoReferencia());
				e.setIdEstado(sede.getIdEstado());
				e.setIdMunicipio(sede.getIdMunicipio());
				e.setNumero(sede.getNumero());
			}
		}

		// Atualizando novos endereços
		enderecosSalvar.forEach(endereco -> {
			endereco.setPessoa(dadosGerais.getCooperativa().getPessoaJuridica());
			enderecoService.save(endereco);
		});
	}

	public boolean excluirRedesocial(RedeSocial redeSocial, List<RedeSocial> redesSociais) {
		boolean excluir = true;

		if (!redesSociais.isEmpty()) {
			for (RedeSocial r : redesSociais) {

                if (Objects.nonNull(r.getId()) && r.getId().equals(redeSocial.getId())) {
                    excluir = false;
                }
            }
        }
        return excluir;
    }

    public void validaQuadrosSociais(QuadroSocial quadroSocial) {
        if (Objects.nonNull(quadroSocial)) {
            validaQuadroSocial(quadroSocial);
        }
    }

	private void validaQuadroSocial(QuadroSocial quadroSocial) {

        // Atualizar o total de cooperados
        if (Objects.nonNull(quadroSocial.getCooperadosHomens()) && Objects.nonNull(quadroSocial.getCooperadosMulheres())) {
            quadroSocial.setCooperadosPF(quadroSocial.getCooperadosHomens() + quadroSocial.getCooperadosMulheres());
        }

        if (Objects.nonNull(quadroSocial.getCooperadosPF()) && Objects.nonNull(quadroSocial.getCooperadosPJ())) {
            quadroSocial.setCooperadosTotal(quadroSocial.getCooperadosPF() + quadroSocial.getCooperadosPJ());
        }

        // Atualizar o total de empregados
        if (Objects.nonNull(quadroSocial.getEmpregadosHomens()) && Objects.nonNull(quadroSocial.getEmpregadosMulheres())) {
            quadroSocial.setEmpregadosTotal(quadroSocial.getEmpregadosHomens() + quadroSocial.getEmpregadosMulheres());
        }

    }

    private void validaCooperativa(DadosGerais dadosGerais) {
        if (Objects.isNull(dadosGerais) || Objects.isNull(dadosGerais.getCooperativa())
                || Objects.isNull(dadosGerais.getCooperativa().getPessoaJuridica())
                || Objects.isNull(dadosGerais.getCooperativa().getPessoaJuridica().getId())) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO));
        }

        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaBasico(dadosGerais.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }
    }

    protected void validaCooperativaManutencao(DadosGerais dadosGerais) {
        if (Objects.isNull(dadosGerais) || Objects.isNull(dadosGerais.getCooperativa())
                || Objects.isNull(dadosGerais.getCooperativa().getPessoaJuridica())
                || Objects.isNull(dadosGerais.getCooperativa().getPessoaJuridica().getId())) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO));
        }

		if (Boolean.FALSE.equals(cadastroRegistroService
				.podePreencherCadastroRegistroCooperativaManutencao(dadosGerais.getCooperativa().getId()))) {
			throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
		}
	}

}
