package br.coop.somoscooperativismo.api.v1.relatorio;

import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.UFTO;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.log.LoggerInstance;
import br.coop.somoscooperativismo.ocbcommonsapi.log.LoggerTracker;
import br.coop.somoscooperativismo.ocbcommonsapi.log.LoggerTypes;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.LocalizacaoClient;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;
import br.coop.somoscooperativismo.registro.api.v1.ramo.RamoService;
import br.coop.somoscooperativismo.registro.api.v1.util.RelatorioUtil;
import lombok.RequiredArgsConstructor;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Service
@RequiredArgsConstructor
public class RelatorioCoopertativasRegistradasService {
	
	private static final Logger LOGGER = Logger.getLogger(RelatorioCoopertativasRegistradasService.class);
	
	public static final String MODULO_TEMPLATE_RELATORIO_COOPERATIVAS_CADASTRADAS = "RELATORIO_COOPERATIVAS_REGISTRADAS";
    public static final String ERRO_AO_GERAR_RELATORIO_COOPERATIVAS_REGISTRADAS = "erro.relatorio.cooperatia.registrada";
    public static final String CLASS_PATH_RELATORIO = "relatorio/RELATORIO_COOPERATIVAS_REGISTRADAS/RELATORIO_COOPERATIVAS_REGISTRADAS.jrxml";
    public static final String CLASS_PATH_LOGO = "relatorio/RELATORIO_COOPERATIVAS_REGISTRADAS/LOGO/";
    public static final String PERMISSAO_NEGADA = "cooperativa.permissaoNegada";
    public static final String ATIVA = "ATIVA";
    
	@Autowired
    private MessagesService messages;

    @Autowired
    private KeycloakService keycloakService;

    @Autowired
    CooperativaService cooperativaService;

    @Autowired
    QuadroSocialService quadroSocialService;

    @Autowired
    RamoService ramoService;

    @Autowired
    @Qualifier("localizacaoClientLocal")
    LocalizacaoClient localizacao;

    @LoggerInstance(LoggerTypes.KIBANA)
    @Autowired
    private LoggerTracker loggerTracker;


    @Autowired
    private RelatorioCooperativasRegistradasRepository relatorioCooperativasRegistradasRepository;

    
	
    private byte[] printRelatorio(List<RelatorioCooperativasRegistradasTO> listaCooperativasPorUF) {
		try {
			List<RelatorioCooperativasRegistradasTO> listaCooperativasataset = listaCooperativasPorUF;
			JRBeanCollectionDataSource itemsJRB = new JRBeanCollectionDataSource(listaCooperativasataset);
			Map<String, Object> parametrosLocal = new HashMap<>();
			parametrosLocal.put("REPORT_LOCALE", new Locale("pt", "BR"));
			parametrosLocal.put("listaCooperativasRamoDataset", itemsJRB);
			RelatorioUtil relatorioUtil = new RelatorioUtil();
			byte[] bytesRelatorio;
			bytesRelatorio = relatorioUtil.gerarRelatorioPdf(listaCooperativasataset, parametrosLocal,
					CLASS_PATH_RELATORIO);
			LOGGER.info(loggerTracker.generateLog());

            listaCooperativasataset = null;
            itemsJRB = null;
            parametrosLocal = null;

			return bytesRelatorio;
		} catch (JRException e) {
			throw new RegraNegocioException(messages.get(ERRO_AO_GERAR_RELATORIO_COOPERATIVAS_REGISTRADAS),e);
		}

	}

    @Transactional
    public byte[] imprimirRelatorioCooperativasRegistradasUN() {
        if(!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }

        List<RelatorioCooperativasRegistradasRamoTO> listCooperativas = relatorioCooperativasRegistradasRepository.listaCooperativasRelatorioNacional();
        List<UFTO> listEstados =  localizacao.buscaUFs();
        List<Ramo> listaRamosAtivos = ramoService.getRamos();
        List<RelatorioCooperativasRegistradasTO> listaCooperativasPorUF = new ArrayList<>();
        Integer totalCooperativasNacional = 0;
        Integer totalCooperativasAtivasNacional = 0;
        Integer totalCooperativasRegularesNacional = 0;
        Integer totalCooperadosNacional = 0;
        Integer totalEmpregadosNacional = 0;

   
            if(!listCooperativas.isEmpty() && !listEstados.isEmpty()) {
                for(UFTO UF : listEstados) {
                    RelatorioCooperativasRegistradasTO dto = new RelatorioCooperativasRegistradasTO();
                    // adiciona a UF
                    dto.setUf(UF.getSigla());

                    // set o valor total das cooperativas
                    dto.setQtCooperativasTotal(BigInteger.valueOf(this.calculaTotalCooperativasByUF(UF.getSigla(), listCooperativas, null)));
                    totalCooperativasNacional += dto.getQtCooperativasTotal().intValue();

                    // set o valor total de cooperados
                    dto.setQtCooperadosTotal(BigInteger.valueOf(this.calculaTotalCooperadosByUF(UF.getSigla(), listCooperativas, null)));
                    totalCooperadosNacional = totalCooperadosNacional + dto.getQtCooperadosTotal().intValue();

                    // set o valor total de empregados
                    dto.setQtEmpregadosTotal(BigInteger.valueOf(this.calculaTotalEmpregadosByUF(UF.getSigla(), listCooperativas, null)));
                    totalEmpregadosNacional = totalEmpregadosNacional + dto.getQtEmpregadosTotal().intValue();

                    // set o valor total cooperativas ativas
                    dto.setQtCooperativasAtivasTotal(BigInteger.valueOf(this.calculaTotalCooperativasAtivas(UF.getSigla(), listCooperativas, null)));
                    totalCooperativasAtivasNacional += dto.getQtCooperativasAtivasTotal().intValue();

                    // set valor total cooperativas regulares
                    dto.setQtCooperativasRegularesTotal(BigInteger.valueOf(this.calculaTotalCooperativasRegulares(UF.getSigla(), listCooperativas)));
                    totalCooperativasRegularesNacional += dto.getQtCooperativasRegularesTotal().intValue();

                    // set cooperativas por ramo
                    List<RelatorioCooperativasRegistradasRamoTO> listCooperativasRamo = this.listaCooperativasRamo(UF.getSigla(), listCooperativas, listaRamosAtivos);
                    JRBeanCollectionDataSource itemJRB = new JRBeanCollectionDataSource(listCooperativasRamo, false);
                    dto.setListaCooperativasRamo(itemJRB);

                    dto.setLogo(CLASS_PATH_LOGO + UF.getSigla().toUpperCase() + ".png");

                    listaCooperativasPorUF.add(dto);
                }
            }

            RelatorioCooperativasRegistradasTO relatorioNacionalDTO = new RelatorioCooperativasRegistradasTO();
            relatorioNacionalDTO.setQtCooperativasTotal(BigInteger.valueOf(totalCooperativasNacional));
            relatorioNacionalDTO.setQtCooperativasAtivasTotal(BigInteger.valueOf(totalCooperativasAtivasNacional));
            relatorioNacionalDTO.setQtCooperativasRegularesTotal(BigInteger.valueOf(totalCooperativasRegularesNacional));
            relatorioNacionalDTO.setQtCooperadosTotal(BigInteger.valueOf(totalCooperadosNacional));
            relatorioNacionalDTO.setQtEmpregadosTotal(BigInteger.valueOf(totalEmpregadosNacional));
            relatorioNacionalDTO.setLogo(CLASS_PATH_LOGO+"NAC"+".png");
            List<RelatorioCooperativasRegistradasRamoTO> listCooperativasRamo = this.listaCooperativasRamoNacional(listCooperativas, listaRamosAtivos);
            relatorioNacionalDTO.setListaCooperativasRamo(new JRBeanCollectionDataSource(listCooperativasRamo));
            listaCooperativasPorUF.add(0,relatorioNacionalDTO);

            listEstados = null;
            listaRamosAtivos = null;
            listCooperativas = null;
            relatorioNacionalDTO = null;
            listCooperativasRamo = null;
            totalCooperativasNacional = null;
            totalCooperativasAtivasNacional = null;
            totalCooperativasRegularesNacional = null;
            totalCooperadosNacional = null;
            totalEmpregadosNacional = null;

            return printRelatorio(listaCooperativasPorUF);
    }

    @Transactional
    public byte[] imprimirRelatorioCooperativasRegistradasUE(String uf) {

        if(!keycloakService.isTipoEntidadeEstadual()) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }

        List<RelatorioCooperativasRegistradasRamoTO> listCooperativas = relatorioCooperativasRegistradasRepository.listaCooperativasRelatorioEstadual(uf);
        List<Ramo> listaRamosAtivos = ramoService.getRamos();
        List<RelatorioCooperativasRegistradasTO> listaCooperativasPorUF = new ArrayList<>();
        
            RelatorioCooperativasRegistradasTO dto = new RelatorioCooperativasRegistradasTO();
            // adiciona a UF
            dto.setUf(uf);

            // set o valor total das cooperativas
            dto.setQtCooperativasTotal(BigInteger.valueOf(this.calculaTotalCooperativasByUF(uf,listCooperativas, null)));

            // set o valor total de cooperados
            dto.setQtCooperadosTotal(BigInteger.valueOf(this.calculaTotalCooperadosByUF(uf, listCooperativas, null)));

            // set o valor total de empregados
            dto.setQtEmpregadosTotal(BigInteger.valueOf(this.calculaTotalEmpregadosByUF(uf, listCooperativas, null)));

            // set o valor total cooperativas ativas
            dto.setQtCooperativasAtivasTotal(BigInteger.valueOf(this.calculaTotalCooperativasAtivas(uf, listCooperativas, null)));

            // set valor total cooperativas regulares
            dto.setQtCooperativasRegularesTotal(BigInteger.valueOf(this.calculaTotalCooperativasRegulares(uf, listCooperativas)));

            // set cooperativas por ramo
            List<RelatorioCooperativasRegistradasRamoTO> listCooperativasRamo = this.listaCooperativasRamo(uf, listCooperativas, listaRamosAtivos);
            JRBeanCollectionDataSource itemJRB = new JRBeanCollectionDataSource(listCooperativasRamo, false);
            dto.setListaCooperativasRamo(itemJRB);
            dto.setLogo(CLASS_PATH_LOGO + uf.toUpperCase() + ".png");
            listaCooperativasPorUF.add(dto);

        listCooperativas = null;
        listCooperativasRamo = null;
        dto = null;

        return printRelatorio(listaCooperativasPorUF);
    }

    private List<RelatorioCooperativasRegistradasRamoTO> listaCooperativasRamoNacional(List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, List<Ramo> listaRamosAtivos){
        List<RelatorioCooperativasRegistradasRamoTO> lista = new ArrayList<>();
        for(Ramo ram : listaRamosAtivos) {
            Integer totalRamoCooperativasAtivas = 0;
            Integer totalRamoCooperativasRegulares = 0;
            Integer totalRamoCooperados = 0;
            Integer totalRamoEmpregados = 0;
            RelatorioCooperativasRegistradasRamoTO dto = new RelatorioCooperativasRegistradasRamoTO();
         // descrição do ramo
            dto.setRamo(ram.getNome()); 
            for(RelatorioCooperativasRegistradasRamoTO rel : listCooperativas) {
                if(ram.getId().equals(rel.getRamoId().intValue()) && rel.getSituacao().equals(ATIVA)) {
                	// conta quantidade cooperativas ativas no ramo
                	totalRamoCooperativasAtivas++; 
                }
                if(ram.getId().equals(rel.getRamoId().intValue()) && "R".equals(rel.getStatus())) {
                    totalRamoCooperativasRegulares++;
                }
                if(ram.getId().equals(rel.getRamoId().intValue())) {
                    totalRamoCooperados += rel.getQtCooperados().intValue();
                    totalRamoEmpregados += rel.getQtEmpregados().intValue();
                }

            }
            dto.setQtCooperativasAtivas(BigInteger.valueOf(totalRamoCooperativasAtivas));
            dto.setQtCooperativasRegulares(BigInteger.valueOf(totalRamoCooperativasRegulares));
            dto.setQtCooperados(BigInteger.valueOf(totalRamoCooperados));
            dto.setQtEmpregados(BigInteger.valueOf(totalRamoEmpregados));
            if(dto.getQtCooperativasAtivas().intValue() > 0 || dto.getQtCooperativasRegulares().intValue() > 0 ||
                    dto.getQtCooperados().intValue() > 0 || dto.getQtEmpregados().intValue() > 0) {
                lista.add(dto);
            }
        }
        return lista;
    }

    /**
     *
     * @param uf
     * @param listCooperativas
     * @param listaRamosAtivos
     * @return
     */
    private List<RelatorioCooperativasRegistradasRamoTO> listaCooperativasRamo(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, List<Ramo> listaRamosAtivos) {
        List<RelatorioCooperativasRegistradasRamoTO> listaCooperativasPorRamo = new ArrayList<>();
        if(!listCooperativas.isEmpty()) {
            for(Ramo r : listaRamosAtivos) {
                RelatorioCooperativasRegistradasRamoTO dto  = new RelatorioCooperativasRegistradasRamoTO();
                dto.setRamo(r.getNome());
                dto.setQtCooperados(BigInteger.valueOf(this.calculaQuantidadeCooperadosPorUFRamo(uf, listCooperativas, r.getId())));
                dto.setQtEmpregados(BigInteger.valueOf(this.calculaQuantidadeEmpregadosPorUFRamo(uf, listCooperativas, r.getId())));
                dto.setQtCooperativasAtivas(BigInteger.valueOf(this.calculaCooperativasAtivasPorUFRamo(uf, listCooperativas, r.getId())));
                dto.setQtCooperativasRegulares(BigInteger.valueOf(this.calculaCooperativasRegularesPorUFRamo(uf, listCooperativas, r.getId())));

                if(dto.getQtCooperativasAtivas().intValue() > 0 || dto.getQtCooperativasRegulares().intValue() > 0 ||
                        dto.getQtCooperados().intValue() > 0 || dto.getQtEmpregados().intValue() > 0) {
                    listaCooperativasPorRamo.add(dto);
                }

            }
        }
        return listaCooperativasPorRamo;
    }

    /**
     */
    private int calculaCooperativasRegularesPorUFRamo(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        Integer qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(r.getUf().equals(uf) && ramoId.equals(r.getRamoId().intValue())
                    && r.getSituacao().equals(ATIVA)
                    && "R".equals(r.getStatus())) {
                qt++;
            }
        }

        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @param ramoId
     * @return
     */
    private int calculaCooperativasAtivasPorUFRamo(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        Integer qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(r.getUf().equals(uf) && ramoId.equals(r.getRamoId().intValue()) && r.getSituacao().equals(ATIVA)) {
                qt++;
            }
        }

        return qt;
    }

    /**
     *
     * @param uf
     * @param listCooperativas
     * @param ramoId
     * @return
     */
    private int calculaQuantidadeEmpregadosPorUFRamo(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        Integer qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(r.getUf().equals(uf) && ramoId.equals(r.getRamoId().intValue())) {
                qt = qt + r.getQtEmpregados().intValue();
            }
        }

        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @param ramoId
     * @return
     */
    private int calculaQuantidadeCooperadosPorUFRamo(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId ) {
        Integer qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(r.getUf().equals(uf) && ramoId.equals(r.getRamoId().intValue())) {
                qt = qt + r.getQtCooperados().intValue();
            }
        }
        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @param ramoId
     * @return
     */
    private int calculaTotalEmpregadosByUF(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        int qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO dto: listCooperativas) {
            if(ramoId != null && dto.getUf().equals(uf) && ramoId.equals(dto.getRamoId().intValue())) {
                qt = qt + dto.getQtEmpregados().intValue();
            } else {
                if(uf.equals(dto.getUf())) {
                    qt = qt + dto.getQtEmpregados().intValue();
                }
            }
        }

        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @return
     */
    private int calculaTotalCooperativasRegulares(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas) {
        int qt = 0;

        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if("R".equals(r.getStatus()) && uf.equals(r.getUf())) {
                qt++;
            }
        }
        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @return
     */
    private int calculaTotalCooperativasAtivas(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        int qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(ramoId == null) {
                if(uf.equals(r.getUf()) && r.getSituacao().equals(ATIVA)) {
                    qt++;
                }
            }else {
                if(uf.equals(r.getUf()) && ramoId.equals(r.getRamoId().intValue()) && r.getSituacao().equals(ATIVA)) {
                    qt++;

                }
            }
        }


        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @return
     */
    private int calculaTotalCooperadosByUF(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        int qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(ramoId == null) {
                if(uf.equals(r.getUf())) {
                    qt = qt +  r.getQtCooperados().intValue();
                }
            } else {
                if(uf.equals(r.getUf()) && ramoId.equals(r.getRamoId().intValue())) {
                    qt = qt +  r.getQtCooperados().intValue();
                }
            }
        }
        return qt;
    }


    /**
     *
     * @param uf
     * @param listCooperativas
     * @return
     */
    private int calculaTotalCooperativasByUF(String uf, List<RelatorioCooperativasRegistradasRamoTO> listCooperativas, Integer ramoId) {
        int qt = 0;
        for(RelatorioCooperativasRegistradasRamoTO r : listCooperativas) {
            if(ramoId == null) {
                if(r.getUf().equals(uf)) {
                    qt++;
                }
            }else {
                if(r.getUf().equals(uf) && ramoId.equals(r.getRamoId().intValue())) {
                    qt++;
                }
            }

        }
        return qt;
    }


}





