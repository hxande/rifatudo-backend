package br.coop.somoscooperativismo.registro.api.v1.anuario.entidade;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

@Entity
@Table(name = "COOPERATIVA_ANUARIO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Anuario {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_COOPERATIVA_ANUARIO")
	private Integer id;

	@Column(name = "VL_ATIVO_TOTAL", columnDefinition = "money(19,2)")
	private BigDecimal ativoTotal;

	@Column(name = "VL_ATIVO_IMOBILIZADO", columnDefinition = "money(19,2)")
	private BigDecimal ativoImobilizado;

	@Column(name = "VL_PATRIMONIO_LIQUIDO", columnDefinition = "money(19,2)")
	private BigDecimal patrimonioLiquido;

	@Column(name = "VL_CAPITAL_SOCIAL", columnDefinition = "money(19,2)")
	private BigDecimal capitalSocial;

	@Column(name = "VL_SOBRAS_PERDAS_EXERCICIO", columnDefinition = "money(19,2)")
	private BigDecimal sobrasPerdasExercicio;

	@Column(name = "VL_INGRESSOS_RECEITAS_BRUTAS", columnDefinition = "money(19,2)")
	private BigDecimal ingressosReceitasBrutas;

	@Column(name = "VL_TRIBUTOS", columnDefinition = "money(19,2)")
	private BigDecimal tributos;

	@Column(name = "VL_DESPESAS_PESSOAL", columnDefinition = "money(19,2)")
	private BigDecimal despesasPessoal;

	@ManyToOne
	@JoinColumn(name = "SQ_COOPERATIVA")
	private Cooperativa cooperativa;

	@Column(name = "NR_ANO")
	private Integer ano;
	
	@Transient
	private String jsonDesempenho;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public BigDecimal getAtivoTotal() {
		return ativoTotal;
	}

	public void setAtivoTotal(BigDecimal ativoTotal) {
		this.ativoTotal = ativoTotal;
	}

	public BigDecimal getAtivoImobilizado() {
		return ativoImobilizado;
	}

	public void setAtivoImobilizado(BigDecimal ativoImobilizado) {
		this.ativoImobilizado = ativoImobilizado;
	}

	public BigDecimal getPatrimonioLiquido() {
		return patrimonioLiquido;
	}

	public void setPatrimonioLiquido(BigDecimal patrimonioLiquido) {
		this.patrimonioLiquido = patrimonioLiquido;
	}

	public BigDecimal getCapitalSocial() {
		return capitalSocial;
	}

	public void setCapitalSocial(BigDecimal capitalSocial) {
		this.capitalSocial = capitalSocial;
	}

	public BigDecimal getSobrasPerdasExercicio() {
		return sobrasPerdasExercicio;
	}

	public void setSobrasPerdasExercicio(BigDecimal sobrasPerdasExercicio) {
		this.sobrasPerdasExercicio = sobrasPerdasExercicio;
	}

	public BigDecimal getIngressosReceitasBrutas() {
		return ingressosReceitasBrutas;
	}

	public void setIngressosReceitasBrutas(BigDecimal ingressosReceitasBrutas) {
		this.ingressosReceitasBrutas = ingressosReceitasBrutas;
	}

	public BigDecimal getTributos() {
		return tributos;
	}

	public void setTributos(BigDecimal tributos) {
		this.tributos = tributos;
	}

	public Cooperativa getCooperativa() {
		return cooperativa;
	}

	public void setCooperativa(Cooperativa cooperativa) {
		this.cooperativa = cooperativa;
	}

	public BigDecimal getDespesasPessoal() {
		return despesasPessoal;
	}

	public void setDespesasPessoal(BigDecimal despesasPessoal) {
		this.despesasPessoal = despesasPessoal;
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}

	public String getJsonDesempenho() {
		return jsonDesempenho;
	}

	public void setJsonDesempenho(String jsonDesempenho) {
		this.jsonDesempenho = jsonDesempenho;
	}
}
