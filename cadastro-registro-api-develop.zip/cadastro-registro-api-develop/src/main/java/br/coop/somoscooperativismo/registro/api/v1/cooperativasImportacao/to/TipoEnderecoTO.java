package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TipoEnderecoTO {
    private Integer id;
    private String nome;
    private Boolean enderecoPrincipal;
    private Boolean enderecoCorrespondencia;
    private Boolean ativo;
    private Integer ordem;
}
