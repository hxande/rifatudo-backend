package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AdesaoUnidadeEstadualTO {
    private Integer id;

    private String ufSigla;
    private boolean adere;
}
