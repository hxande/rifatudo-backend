package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.TipoAcaoEnum;
import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.entidade.CooperativaSolicitacao;
import br.coop.somoscooperativismo.registro.api.v1.email.entidade.RegistroEmail;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "COOPERATIVA_REGISTRO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
@Getter
@Setter
public class CooperativaRegistro implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_PESSOA_REGISTRO")
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "SQ_COOPERATIVA")
	@JsonBackReference
	private Cooperativa cooperativa;

	@ManyToOne
	@JoinColumn(name = "SQ_SITUACAO_COOPERATIVA")
	private Situacao situacao;

	@Column(name = "TX_SITUTUACAO_COOPERATIVA")
	private String situacaoCooperativa;

	@Column(name = "DT_ALTERACAO_SITUACAO_STATUS")
	private Date dtAlteracao;

	@Column(name = "TX_LOGIN_USUARIO_ALTERACAO_SITUACAO_STATUS")
	private String loginAlteracaoSituacao;

	@Column(name = "TX_JUSTIFICATIVA_REGISTRO")
	private String justificativaRegistro;

	@Column(name = "IN_SOLICITACAO_INATIVACAO")
	private Boolean solicitacaoInativacao;

	@Column(name = "IN_SOLICITACAO_ATIVACAO")
	private Boolean solicitacaoAtivacao;

	@Column(name = "TX_JUSTIFICATIVA_SOLICITACAO_INATIVACAO")
	private String justificativaSolicitacaoInativacao;

	@Column(name = "TX_JUSTIFICATIVA_COOPERATIVA_CANCELADA")
	private String justificativaCancelada;

	@Column(name = "TX_JUSTIFICATIVA_COOPERATIVA_INATIVADA")
	private String justificativaInativada;

	@Column(name = "TX_JUSTIFICATIVA_COOPERATIVA_IRREGULAR")
	private String justificativaIrregular;
	
	@Column(name = "TX_JUSTIFICATIVA_SOLICITACAO_ATIVACAO")
	private String justificativaSolicitacaoAtivacao;

	@Column(name = "TX_JUSTIFICATIVA_ATIVACAO")
	private String justificativaAtivacao;

	@Column(name = "UP_ANEXO")
	private String anexo;

	@Column(name = "UP_ANEXO_NOTIFICACO")
	private String anexoNotificacao;

	@Column(name = "UP_ANEXO_PROVA_ORGAOS")
	private String anexoProvaOrgaos;

	@Column(name = "IN_SOLICITACAO_CANCELADA")
	private Boolean solicitacaoCancelamento;
	    
	@Column(name ="TX_JUSTIFICATIVA_SOLICITACAO_CANCELADA")
	private String justificativaSolicitacaoCancelamento;
	
	@OneToOne
	@JoinColumn(name = "SQ_COOPERATIVA_SOLICITACAO", nullable = true)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	CooperativaSolicitacao cooperativaSolicitacao;
	
	@Column(name = "IN_TIPO_ACAO")
	@Enumerated(EnumType.STRING)
	private TipoAcaoEnum tipoAcao;

	@OneToOne
	@JoinColumn(name="SQ_REGISTRO_EMAIL", nullable = true)
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	RegistroEmail registroEmail;
		
}
