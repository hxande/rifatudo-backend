package br.coop.somoscooperativismo.registro.api.v1.entidade;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="VW_USUARIO_INSCRITO_EMAIL")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class VwUsuarioInscritoEmail implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "SQ_USUARIO_ENTIDADE")
    private Integer id;

    @Column(name = "TX_USERNAME")
    private String nome;

    @Column(name = "EMAIL")
    private String email;

    @Column(name = "TX_CNPJ")
    private String cnpj;

    @Column(name = "TX_UF_SIGLA", columnDefinition = "char")
    private String uf;

    @Column(name = "TX_TIPO_PESSOA_JURIDICA", columnDefinition = "char")
    private String tipo;

    @Column(name = "TX_SISTEMA")
    private String sistema;

    @Column(name = "TX_GRUPO")
    private String grupo;

    @Column(name = "TX_CODIGO_SUBGRUPO")
    private String subGrupo;
    
    @Column(name = "DN_ATIVO", columnDefinition = "bit")
    private Boolean ativo;
}

