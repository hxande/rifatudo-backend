package br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao;

import java.util.List;
import java.util.Set;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/vinculacaocooperativa")
@Tag(name = "CooperativaVinculacao")
public class CooperativaVinculacaoRestController {

	@Autowired
    CooperativaVinculacaoService cooperativaVinculacaoService;

	@Autowired
	private MessagesService messages;

	@PostMapping("/vincular")
	@Operation(summary = "Vincula uma lista de Cooperativas")
	public ResponseEntity<ServiceResponse<Void>> vinculaCooperativaVinculacao(@RequestParam(required = true) Integer idCooperativaPai, @RequestBody @Valid List<CooperativaBasicaTO> listaCooperativaVinculacao) {
		cooperativaVinculacaoService.vinculaCooperativasBasicas(idCooperativaPai, listaCooperativaVinculacao);
		ServiceMessage message = new ServiceMessage((messages.get("cooperativaVinculacao.vinculado")));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.CREATED);
	}
	

	@GetMapping("/buscaCooperativasVinculadasPeloIdCoopertiva/{idCooperativa}")
	@Operation(summary = "Todas pendências da Cooperativa")
	public ServiceResponse<Set<Cooperativa>> buscaCooperativasVinculadasPeloIdCoopertiva(
			@PathVariable(required = true) Integer idCooperativa
			) {
		return new ServiceResponse<>(cooperativaVinculacaoService.buscaCooperativasVinculadasPeloIdCooperativa(idCooperativa));
	}
	
	
	
	@GetMapping("/buscaCooperativasVinculadasPeloCNPJ/{cnpj}")
	@Operation(summary = "Todas pendências da Cooperativa")
	public ServiceResponse<Set<Cooperativa>> buscaCooperativasVinculadasPeloCNPJ( 
			@PathVariable(required = true) String cnpj
			) {
		return new ServiceResponse<>(cooperativaVinculacaoService.buscaCooperativasVinculadasPeloCNPJ(cnpj));
	}
}
