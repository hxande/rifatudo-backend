package br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao;

public enum TipoSolicitacaoEnum {
	OUTROS(4),
	IRREGULARIZAR(2),
	INATIVACAO(1);
	
	private Integer tipo;
	
	TipoSolicitacaoEnum(Integer tipo){
		this.tipo = tipo;
	}
	public Integer getTipo() {
		return tipo;
	}

	
	
}
