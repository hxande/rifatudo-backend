package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.web.JsonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

@Service
public class ArrecadacaoClient {

    @Value("${arrecadacao_service_host}")
    private String arrecadacaoServiceHost;

    @Autowired
    private RestTemplate keycloakRestTemplate;

    @Autowired
    private MessagesService messagesService;


    /**
     * Retorna lista adesao.
     *
     * @return AdesaoUnidadeEstadualTO.
     */
    public Set<AdesaoUnidadeEstadualTO> getAllAdesao() {
        String url = arrecadacaoServiceHost + "/api/v1/adesao";

        Set<AdesaoUnidadeEstadualTO> adesaoUnidadeEstadualTOs;

        try {
            LinkedHashMap retorno = keycloakRestTemplate.getForObject(url, LinkedHashMap.class);
            String dados = "";
            if (retorno != null) {
                dados = JsonUtil.toJson(retorno.get("data"));
            }
            adesaoUnidadeEstadualTOs = (Set<AdesaoUnidadeEstadualTO>) JsonUtil.toObject(dados, new TypeReference<Set<AdesaoUnidadeEstadualTO>>() {
            });

            dados = null;

        } catch (RestClientException e) {
            throw new RegraNegocioException(messagesService.get("ERRO"), e);
        }

        url = null;

        return adesaoUnidadeEstadualTOs;
    }

    /**
     * Retorna o numero de pendencias.
     *
     * @return QuadroSituacaoFinanceiraTO.
     */
    public List<QuadroSituacaoFinanceiraTO> getListaArrecadacao(Integer idCooperativa, Integer tipoContribuicao) {
        String url = arrecadacaoServiceHost + "/api/v1/data-base-contribuicao/getSituacaoFinanceira/" + tipoContribuicao + "?idCooperativa=" + idCooperativa;

        List<QuadroSituacaoFinanceiraTO> quadroSituacaoFinanceiraTOES;

        try {
            quadroSituacaoFinanceiraTOES = Arrays.asList(keycloakRestTemplate.getForObject(url, QuadroSituacaoFinanceiraTO[].class));
        } catch (Exception e) {
            throw new RegraNegocioException(messagesService.get("ERRO"), e);
        }

        url = null;

        return quadroSituacaoFinanceiraTOES;
    }

    /**
     * Retorna o numero de pendencias.
     *
     * @return Integer.
     */
    public Integer getNumeroPendencia() {
        String url = arrecadacaoServiceHost + "/api/v1/contribuicao/numeroDePendencias";
        return keycloakRestTemplate.getForObject(url, Integer.class);
    }

    /**
     * Retorna informações da Taxa de Registro da cooperativa.
     *
     * @param idCooperativa
     * @return TaxaRegistroTO.
     */
    public TaxaRegistroTO getTaxaRegistro(Integer idCooperativa) {
        String url = arrecadacaoServiceHost + "/api/v1/taxa-registro/cooperativa/" + idCooperativa;

        try {
            LinkedHashMap retorno = keycloakRestTemplate.getForObject(url, LinkedHashMap.class);

            if (retorno == null || retorno.get("data") == null) {
                return null;
            }

            String dados = JsonUtil.toJson(retorno.get("data"));

            ObjectMapper mapper = new ObjectMapper()
                    .registerModule(new JavaTimeModule())
                    .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

            return mapper.readValue(dados, TaxaRegistroTO.class);

        } catch (Exception e) {
            throw new RegraNegocioException(messagesService.get("ERRO"), e);
        }
    }
}