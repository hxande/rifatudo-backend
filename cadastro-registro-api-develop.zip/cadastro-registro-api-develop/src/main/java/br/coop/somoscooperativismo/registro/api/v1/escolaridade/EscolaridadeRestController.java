package br.coop.somoscooperativismo.registro.api.v1.escolaridade;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/escolaridade")
@Tag(name = "EscolaridadeTO")
public class EscolaridadeRestController {

	private final EscolaridadeService escolaridadeService;

	public EscolaridadeRestController(EscolaridadeService escolaridadeService) {
		this.escolaridadeService = escolaridadeService;
	}


	@GetMapping
	@Operation(summary = "Lista")
	public ServiceResponse<List<EscolaridadeTO>> getEscolariade() {
		return new ServiceResponse<>(escolaridadeService.getEscolaridades());
	}
	
}
