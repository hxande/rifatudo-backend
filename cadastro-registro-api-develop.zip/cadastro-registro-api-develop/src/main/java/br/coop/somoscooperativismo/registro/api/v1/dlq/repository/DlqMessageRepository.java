package br.coop.somoscooperativismo.registro.api.v1.dlq.repository;

import br.coop.somoscooperativismo.registro.api.v1.dlq.entidade.DlqMessage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DlqMessageRepository extends JpaRepository<DlqMessage, Long> {
}
