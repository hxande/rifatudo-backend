package br.coop.somoscooperativismo.registro.api.v1.dlq.mapper;

import br.coop.somoscooperativismo.registro.api.v1.dlq.entidade.DlqMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Message;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class DlqMessageMapper {

    private final ObjectMapper objectMapper;

    public DlqMessageMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public DlqMessage mapToDlqMessage(Message message, String specificErrorMessage) {
        String payloadJson = new String(message.getBody());
        Map<String, Object> headers = message.getMessageProperties().getHeaders();

        String messageId = message.getMessageProperties().getMessageId();
        String publisher = "unknown";
        String eventType = "unknown";
        String originalQueue = "unknown";
        String originalExchange = "unknown";
        String originalRoutingKey = "unknown";
        String errorMessage = specificErrorMessage != null ? specificErrorMessage : "Mensagem falhou no processamento.";
        Integer deathCount = 0;

        if (headers.containsKey("x-death")) {
            List<Map<String, Object>> xDeathList = (List<Map<String, Object>>) headers.get("x-death");
            deathCount = xDeathList.size();

            if (!xDeathList.isEmpty()) {
                Map<String, Object> firstDeath = xDeathList.get(0);
                originalQueue = (String) firstDeath.getOrDefault("queue", "unknown");
                originalExchange = (String) firstDeath.getOrDefault("exchange", "unknown");
                List<String> routingKeys = (List<String>) firstDeath.get("routing-keys");
                if (routingKeys != null && !routingKeys.isEmpty()) {
                    originalRoutingKey = String.join(",", routingKeys);
                }
                if (firstDeath.containsKey("reason")) {
                    errorMessage += "\nMotivo da falha inicial: " + firstDeath.get("reason");
                }
            }
        }

        if (headers.containsKey("publisher")) {
            publisher = headers.get("publisher").toString();
        }
        if (headers.containsKey("eventType")) {
            eventType = headers.get("eventType").toString();
        }


        if (headers.containsKey("x-exception-stacktrace")) {
            errorMessage += "\nStacktrace: " + headers.get("x-exception-stacktrace");
        } else if (headers.containsKey("x-exception-message")) {
            errorMessage += "\nDetalhes: " + headers.get("x-exception-message");
        }

        return new DlqMessage(
                publisher,
                originalQueue,
                originalExchange,
                originalRoutingKey,
                eventType,
                payloadJson,
                deathCount,
                errorMessage
        );
    }
}
