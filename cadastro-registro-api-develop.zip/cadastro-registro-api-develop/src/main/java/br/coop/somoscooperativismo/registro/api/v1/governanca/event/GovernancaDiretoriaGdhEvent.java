package br.coop.somoscooperativismo.registro.api.v1.governanca.event;

import br.coop.somoscooperativismo.registro.api.v1.governanca.event.util.GovernancaEvent;
import br.coop.somoscooperativismo.registro.api.v1.governanca.event.util.GovernancaEventEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class GovernancaDiretoriaGdhEvent implements GovernancaEvent {
    private GovernancaEventEnum eventType;
    private GovernancaBeneficiarioDiretoriaGdhTO beneficiario;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private LocalDateTime dataEvento;
    private Integer idOrgao;
    private Integer idCargo;
    private Boolean isDiretoriaGdh;

    
    @Override
    public GovernancaEventEnum eventType() {
        return eventType;
    }

    public GovernancaDiretoriaGdhEvent(GovernancaEventEnum eventType, Integer SQ_COOPERATIVA) {
        this.beneficiario = new GovernancaBeneficiarioDiretoriaGdhTO();
        this.beneficiario.setSQ_COOPERATIVA(SQ_COOPERATIVA);
        this.eventType = eventType;
        this.dataEvento = LocalDateTime.now();
    }

    public GovernancaDiretoriaGdhEvent(GovernancaEventEnum eventType, Integer idOrgao, Integer idCargo, Boolean isDiretoriaGdh) {
        this.eventType = eventType;
        this.idOrgao = idOrgao;
        this.idCargo = idCargo;
        this.isDiretoriaGdh = isDiretoriaGdh;
    }
}
