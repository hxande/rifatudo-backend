package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;
import java.util.Set;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaIntegracaoFormularioResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaWebLectorResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.CooperativaVinculacaoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/cooperativas")
public class CooperativaImportacaoRestController {

    private final CooperativaService cooperativaService;
    private final CooperativaVinculacaoService cooperativaVinculacaoService;

    @GetMapping("/cnpj/{cnpj}")
    public ResponseEntity<Cooperativa> getByCnpj(@PathVariable String cnpj) {
        return ResponseEntity.ok(cooperativaService.getByCnpj(cnpj));
    }

    @GetMapping("/vinculadas/{idCooperativaPai}")
    public ResponseEntity<Set<Cooperativa>> getByCooperativaPaiId(@PathVariable Integer idCooperativaPai) {
        return ResponseEntity.ok(cooperativaVinculacaoService.buscaCooperativasVinculadasPeloIdCooperativa(idCooperativaPai));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Cooperativa> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(cooperativaService.getCooperativa(id));
    }

    @GetMapping("/web-lector")
    public ResponseEntity<List<CooperativaWebLectorResponseTO>> getCooperativaParaWebLector() {
        return ResponseEntity.ok(cooperativaService.getCooperativaParaWebLector());
    }

    @GetMapping("/integracao/formulario/{uf}")
    public ResponseEntity<List<CooperativaIntegracaoFormularioResponseTO>> getCooperativasParaIntegracaoFormulario(@PathVariable String uf) {
        return ResponseEntity.ok(cooperativaService.getCooperativasParaIntegracaoFormulario(uf));
    }
}
