package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.AbaDataTypeEnum;
import lombok.Data;

import java.util.List;

@Data
public class CooperativaAbaDataInterface {
    private AbaDataTypeEnum type;
    private List<AbaDataInterface> data;
}
