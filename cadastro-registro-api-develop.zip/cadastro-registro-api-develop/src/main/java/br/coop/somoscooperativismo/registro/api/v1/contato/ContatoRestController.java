package br.coop.somoscooperativismo.registro.api.v1.contato;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.contato.to.ContatoTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/contato")
@Tag(name = "Contato")
public class ContatoRestController {
	public static final String NAO_CORRESPONDE = "contato.naoCorresponde";
	public static final String CONTATO_DELETADO = "contato.deletado";
	
	public static final String REGISTRO_SALVO = "registroSalvo.sucesso";
	public static final String REGISTRO_PENDENCIA = "registroSalvo.pendencia";
	
	@Autowired
	ContatoService contatoService;
	
	@Autowired
	private MessagesService messages;
	
	@PostMapping("/{idPessoa}")
	@Operation(summary = "Salva/Atualiza lista de contato")
	public ResponseEntity<ServiceResponse<Void>> saveListaContatos(@RequestBody @Valid List<ContatoTO> contatos, @PathVariable Integer idPessoa){
		boolean successfully = contatoService.salvaListaContatos(contatos, idPessoa);
		ServiceMessage message = new ServiceMessage(messages.get((successfully ? REGISTRO_SALVO : REGISTRO_PENDENCIA)));
		return new ResponseEntity<>(new ServiceResponse<>(message), (successfully ? HttpStatus.OK : HttpStatus.ACCEPTED));
	}
	
	@GetMapping("/pessoa/{idArea}/{idPessoa}")
	@Operation(summary = "Lista por idArea e idPessoa")
	public ServiceResponse<List<Contato>> getAreaContatos(@PathVariable Integer idArea, @PathVariable Integer idPessoa) {
		return new ServiceResponse<>(contatoService.getAreaContatosPessoa(idArea, idPessoa));
	}
	
	@GetMapping("/pessoa/{idPessoa}")
	@Operation(summary = "Lista por idPessoa")
	public ServiceResponse<List<Contato>> getAreaContatosPorPessoa(@PathVariable Integer idPessoa) {
		return new ServiceResponse<>(contatoService.getContatosPessoa(idPessoa));
	}
	
}
