package br.coop.somoscooperativismo.registro.api.v1.cnae;

import br.coop.somoscooperativismo.registro.api.v1.cnae.entidade.Cnae;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Service
public class CnaeService {
	
	 public static final String NAO_ENCONTRADO = "cnae.naoEncontrado";

	
	@Autowired
	CnaeRepository cnaeRepository;
	
	@Autowired
	MessagesService messages;

	public Cnae getCnae(String id) {
		Optional<Cnae> cnae = findCnae(id);
		return cnae.get();
	}

	private Optional<Cnae> findCnae(String id) {
		Optional<Cnae> cnae = cnaeRepository.findById(id);
		
		if(cnae.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
		}
		return cnae;
	}

	public @Valid Cnae createCnae(@Valid Cnae cnae) {
		return cnaeRepository.save(cnae);
	}

	public Cnae updateCnae(@Valid Cnae cnae) {
		Optional<Cnae> cnaePresent = cnaeRepository.findById(cnae.getId());
		if(cnaePresent.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
		}
		return cnaeRepository.save(cnae);
	}

	public List<Cnae> getCnaes() {
		return cnaeRepository.findAll();
	}

	public void desativaCnae(String id) {
		Optional<Cnae> cnae = findCnae(id);
		
		Cnae cnaeUpdate = cnae.get();
		cnaeUpdate.setAtivo(false);
		cnaeRepository.save(cnaeUpdate);
	}

	public void excluiCnae(String id) {
		Optional<Cnae> cnae = findCnae(id);
		
		Cnae cnaeDelete = cnae.get();
		cnaeRepository.save(cnaeDelete);
	}

	@Transactional(readOnly = true)
	public List<Cnae> getAllAtivos() {
		return this.cnaeRepository.findAllByAtivoTrueOrderByIdAsc();
	}

	@Transactional(readOnly = true)
	public Page<Cnae> getPageCnaeByIdAndDescricaoAndClassificacao(String id, String descricao, Pageable pageable) {
		return this.cnaeRepository.findByIdContainingAndDescricaoContaining( id, descricao, pageable);
	}
}
