package br.coop.somoscooperativismo.registro.api.v1.apontamentos.entidade;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "COOPERATIVA_REGISTRO_APONTAMENTO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Apontamento implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_REGISTRO_APONTAMENTO")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_COOPERATIVA", referencedColumnName = "SQ_COOPERATIVA", nullable = false)
    private Cooperativa cooperativa;

    @Column(name = "TX_LOGIN_USUARIO_APONTAMENTO")
    @Size(max = 50)
    private String loginUsuario;

    @Column(name = "DT_APONTAMENTO")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataApontamento;

    @Column(name = "TX_APONTAMENTO")
    @Size(max = 2000)
    @NotNull
    private String apontamento;

}
