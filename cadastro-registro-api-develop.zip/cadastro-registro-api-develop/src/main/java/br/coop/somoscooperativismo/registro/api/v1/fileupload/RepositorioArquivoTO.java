package br.coop.somoscooperativismo.registro.api.v1.fileupload;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RepositorioArquivoTO {

	private String nome;
	private String tamanho;
	private String extensao;
	private String chaveArquivo;
	private String miniaturaBase64;
	private String caminhoDownload;
	private String mimeType;
	private String dataHoraCriacao;
	private String dataHoraExclusao;


}
