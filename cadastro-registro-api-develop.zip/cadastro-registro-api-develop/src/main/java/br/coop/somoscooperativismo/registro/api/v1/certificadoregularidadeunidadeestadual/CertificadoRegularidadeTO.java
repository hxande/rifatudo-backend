package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual;

public class CertificadoRegularidadeTO {

	private String numeroRegistro;
	private String cnpj;
	private String razaoSocial;
	private String endereco;
	private String uf;
	private String dataValidade;
	private String dataHoraInformacao;
	private String imgBackGround;
	private String statusRegularidade;
	private String unidadeResponsavel;
	private String observacaoUe;

	public String getNumeroRegistro() {
		return numeroRegistro;
	}

	public void setNumeroRegistro(String numeroRegistro) {
		this.numeroRegistro = numeroRegistro;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getDataValidade() {
		return dataValidade;
	}

	public void setDataValidade(String dataValidade) {
		this.dataValidade = dataValidade;
	}

	public String getDataHoraInformacao() {
		return dataHoraInformacao;
	}

	public void setDataHoraInformacao(String dataHoraInformacao) {
		this.dataHoraInformacao = dataHoraInformacao;
	}

	public String getStatusRegularidade() {
		return statusRegularidade;
	}

	public void setStatusRegularidade(String statusRegularidade) {
		this.statusRegularidade = statusRegularidade;
	}

	public String getImgBackGround() {
		return imgBackGround;
	}

	public void setImgBackGround(String imgBackGround) {
		this.imgBackGround = imgBackGround;
	}

	public String getUnidadeResponsavel() {
		return unidadeResponsavel;
	}

	public void setUnidadeResponsavel(String unidadeResponsavel) {
		this.unidadeResponsavel = unidadeResponsavel;
	}

	public String getObservacaoUe() {
		return observacaoUe;
	}

	public void setObservacaoUe(String observacaoUe) {
		this.observacaoUe = observacaoUe;
	}

	@Override
	public String toString() {
		return "CertificadoRegularidadeTO [numeroRegistro=" + numeroRegistro + ", cnpj=" + cnpj + ", razaoSocial="
				+ razaoSocial + ", endereco=" + endereco + ", uf=" + uf + ", dataValidade=" + dataValidade
				+ ", dataHoraInformacao=" + dataHoraInformacao + ", imgBackGround=" + imgBackGround
				+ ", statusRegularidade=" + statusRegularidade + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cnpj == null) ? 0 : cnpj.hashCode());
		result = prime * result + ((dataHoraInformacao == null) ? 0 : dataHoraInformacao.hashCode());
		result = prime * result + ((dataValidade == null) ? 0 : dataValidade.hashCode());
		result = prime * result + ((endereco == null) ? 0 : endereco.hashCode());
		result = prime * result + ((imgBackGround == null) ? 0 : imgBackGround.hashCode());
		result = prime * result + ((numeroRegistro == null) ? 0 : numeroRegistro.hashCode());
		result = prime * result + ((razaoSocial == null) ? 0 : razaoSocial.hashCode());
		result = prime * result + ((statusRegularidade == null) ? 0 : statusRegularidade.hashCode());
		result = prime * result + ((uf == null) ? 0 : uf.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CertificadoRegularidadeTO other = (CertificadoRegularidadeTO) obj;
		if (cnpj == null) {
			if (other.cnpj != null)
				return false;
		} else if (!cnpj.equals(other.cnpj))
			return false;
		if (dataHoraInformacao == null) {
			if (other.dataHoraInformacao != null)
				return false;
		} else if (!dataHoraInformacao.equals(other.dataHoraInformacao))
			return false;
		if (dataValidade == null) {
			if (other.dataValidade != null)
				return false;
		} else if (!dataValidade.equals(other.dataValidade))
			return false;
		if (endereco == null) {
			if (other.endereco != null)
				return false;
		} else if (!endereco.equals(other.endereco))
			return false;
		if (imgBackGround == null) {
			if (other.imgBackGround != null)
				return false;
		} else if (!imgBackGround.equals(other.imgBackGround))
			return false;
		if (numeroRegistro == null) {
			if (other.numeroRegistro != null)
				return false;
		} else if (!numeroRegistro.equals(other.numeroRegistro))
			return false;
		if (razaoSocial == null) {
			if (other.razaoSocial != null)
				return false;
		} else if (!razaoSocial.equals(other.razaoSocial))
			return false;
		if (statusRegularidade == null) {
			if (other.statusRegularidade != null)
				return false;
		} else if (!statusRegularidade.equals(other.statusRegularidade))
			return false;
		if (uf == null) {
			if (other.uf != null)
				return false;
		} else if (!uf.equals(other.uf))
			return false;
		if ((observacaoUe == null && other.getObservacaoUe() != null)
				|| (observacaoUe != null && other.getObservacaoUe() == null)) {
			return false;
		} else if (observacaoUe != null && other.getObservacaoUe() != null
				&& !observacaoUe.equals(other.getObservacaoUe())) {
			return false;
		}
		return true;
	}

}
