package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class RequestAnuarioTO implements Serializable {

    private Integer situacao;
    private List<RequestAnuarioFieldsTO> fields;

}
