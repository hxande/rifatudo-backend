package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import lombok.Data;

import java.util.List;

@Data
public class GrupoNegocioTO {
    private int id;
    private String nome;
    private List<Object> parametros;
}
