package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/complementos-anuarios/{complementoAnuarioId}/complementos-anuarios-ramos-urls")
public class ComplementoAnuarioRamoUrlRestController {

    public static final String COMPLEMENTO_ANUARIO_NAO_ENCONTRADO = "complementoAnuario.naoEncontrado";
    public static final String RAMO_URL_EXCLUIDO = "complementoAnuarioRamoUrl.excluido";
    public static final String RAMO_URL_NAO_ENCONTRADO = "complementoAnuarioRamoUrl.naoEncontrado";

    private final ComplementoAnuarioRamoUrlService complementoAnuarioRamoUrlService;
    private final MessagesService messages;

    @DeleteMapping("/{id}")
    @Operation(summary = "Exclui o Link por Ramo dos Dados Complementares do Anuário", description = "Devem ser informados IDs válido")
    public ResponseEntity<ServiceResponse<Void>> delete(@PathVariable Integer complementoAnuarioId, @PathVariable Integer id) {
        this.complementoAnuarioRamoUrlService.deleteById(complementoAnuarioId, id)
                .orElseThrow(() -> new RegraNegocioException(this.messages.get(COMPLEMENTO_ANUARIO_NAO_ENCONTRADO), HttpStatus.NOT_FOUND))
                .orElseThrow(() -> new RegraNegocioException(this.messages.get(RAMO_URL_NAO_ENCONTRADO), HttpStatus.NOT_FOUND));
        ServiceMessage message = new ServiceMessage(messages.get(RAMO_URL_EXCLUIDO));
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
}
