package br.coop.somoscooperativismo.registro.api.v1.email;

import java.time.LocalDate;

public class EmailServiceConstant {
	public static final String PROCESSO_DE_REGISTRO = "Processo de registro - Sistema OCB";
	public static final String SUSPENSAO_COOPERATIVA = "Suspensão de cooperativa - Sistema OCB";
	public static final String REGULARIZA_COOPERATIVA = "Cooperativa regular - Sistema OCB";
	public static final String SOLICITA_CANCELAMENTO_COOPERATIVA = "Solicitação de cancelamento da cooperativa - Sistema OCB";
	public static final String PROCESSO_DE_ATUALIZACAO = "Processo de atualização do registro - Sistema OCB";
	public static final String PROCESSO_DE_REGISTRO_UE = "Processo de registro - Cooperativa: ";
	public static final String EMAIL_OCB = "sistemas@sistemaocb.coop.br";
	public static final String MODULO_ENVIO_EMAIL = "CADASTRO_REGISTRO";
	public static final String CONTEUDO = "conteudo";
	public static final String GRUPO_RECEBER_EMAIL = "CADASTRO_REGISTRO_ESTADUAL_ANALISTA";
	public static final String SISTEMA_CLIENT_ID = "cadastro-registro";
	public static final String URL_CONTINUAR = "urlContinuar";
	public static final String NUMERO_PROCESSO = "numeroProcesso";
	public static final String URL_DATA = "urlDatas";
	public static final String TEXTO_VARIAVEL = "%textoVariavel%";
	public static final String URL_RECEBER_EMAIL = "urlRecebeEmail";
	public static final String COOPERATIVA = "cooperativa";
	public static final String UF = "UF";
	public static final String TRANSFERENCIA_UF = "Transferência de UF - Sistema OCB";
	public static final String FONT_STYLE = "<p style=\"Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-size:18px;font-family:lato, 'helvetica neue', helvetica, arial, sans-serif;line-height:27px;\">\n";
	public static final String USUARIOS_NAO_ENCONTRADOS = "usuários não encontrados: ";
	public static final String ATUALIZACAO_DE_DADOS_CADASTRAIS = "Atualização de Dados Cadastrais";
	public static final String NOTIFICACAO_SOU_COOP = "Notificação SouCoop";
	public static final String COOPERATIVA_INATIVA = "Cooperativa inativa";
	public static final String ERRO_AO_DISPARAR_UM_EMAIL = "Erro ao disparar um email: ";
	public static final String REALIZAR_ADEQUACAO_CADASTRAL = "Realizar adequação cadastral";
	public static final String REQUERIMENTO_DO_REGISTRO_REALIZADO = "Requerimento de Registro realizado";
	public static final String REALIZAR_ADEQUACAO_DE_ATUALIZACAO_CADASTRAL = "Realizar adequação de atualização cadastral";
	public static final String COOPERATIVA_IRREGULAR = "Cooperativa irregular";
	public static final String ANUARIO_ANO_SOUCOOP_SISTEMA_OCB = "Anuário ".concat(String.valueOf(LocalDate.now().getYear() - 1)).concat(" SouCoop - Sistema OCB");
	public static final String SOLICITACAO_VINCULO_COOPERATIVA = "Solicitação de Vínculo a Cooperativa";
	public static final String FILIACAO_SUPERIOR_APROVADA = "Filiação Superior Aprovada";
	public static final String FILIACAO_SUPERIOR_REPROVADA = "Filiação Superior Reprovada";

}
