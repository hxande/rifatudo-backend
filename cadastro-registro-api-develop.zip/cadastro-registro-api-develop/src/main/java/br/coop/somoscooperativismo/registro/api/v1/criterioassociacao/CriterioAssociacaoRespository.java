package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacao;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CriterioAssociacaoRespository extends JpaRepository<CriterioAssociacao, Integer> {

    List<CriterioAssociacao> findByRamoIdAndAtivoTrue(Integer ramoId);
    List<CriterioAssociacao> findByRamoIdAndExcluido(Integer ramoId, Boolean excluido);

	List<CriterioAssociacao> findByRamoIdAndExcluidoAndAtivoTrue(Integer ramoId, Boolean excluido);


	@Query("select new br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.CriterioAssociacaoRamoTO(r.id, r.nome, r.ativo, count(ca)) "
    		+ "from Ramo r "
    		+ "left join CriterioAssociacao ca "
    		+ "on r.id = ca.ramo.id "
    		+ "and ca.ativo = true "
    		+ "group by r.id, r.nome, r.ativo")
    Page<CriterioAssociacaoRamoTO> obterListaRamosCriterioAssociacao(Pageable pageable);
}
