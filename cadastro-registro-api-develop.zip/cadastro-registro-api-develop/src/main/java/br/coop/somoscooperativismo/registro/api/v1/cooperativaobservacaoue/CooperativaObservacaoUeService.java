package br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue.entidade.CooperativaObservacaoUe;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;

/**
 * CooperativaObservacaoUeService<br>
 * Service responsável pelas operações com a entidade CooperativaObservacaoUe.
 * 
 * @author brunno.stefanini
 * @since 19 de novembro de 2020.
 */
@Service
public class CooperativaObservacaoUeService {

	private static final String UNDEFINED = "undefined";
	private static final String NULL = "null";
	private static final String USUARIO_NAO_POSSUI_PERMISSAO_PARA_ESTE_ITEM = "Usuário não possui permissão para este item.";
	private static final int DUZENTOS_CINQUENTA = 250;

	@Autowired
	private KeycloakService keycloakService;

	@Autowired
	private CooperativaService cooperativaService;

	@Autowired
	private CooperativaObservacaoUeRepository cooperativaObservacaoUeRepository;

	/**
	 * Realiza a exclusão lógica da observação com o ID indicado.<br>
	 * <br>
	 * Permissões: Unidade Nacional (com permissão de gestor) e Unidade Estadual
	 * (com permissão de gestor e que seja mesma UF que a cooperativa).
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @param idObservacao  ID da observação a ser excluída.
	 * @return Observação após exlusão.
	 */
	public CooperativaObservacaoUe excluir(int idCooperativa, int idObservacao) {
		if (!temPermissaoDeGravacao(idCooperativa)) {
			throw new RegraNegocioException(USUARIO_NAO_POSSUI_PERMISSAO_PARA_ESTE_ITEM);
		}
		CooperativaObservacaoUe observacao = null;
		Optional<CooperativaObservacaoUe> observacaoOPtional = cooperativaObservacaoUeRepository.findById(idObservacao);
		if(observacaoOPtional.isPresent()) {
			observacao = observacaoOPtional.get();
		}
		if (observacao == null) {
			throw new RegraNegocioException("A observação não existe.");
		} else if (observacao.getIdCooperativa() != idCooperativa) {
			throw new RegraNegocioException("A observação não pertence a cooperativa indicada.");
		} else if (observacao.getDataDeExclusao() != null) {
			throw new RegraNegocioException("A observação já se encontra excluída.");
		}

		observacao.setDataDeExclusao(LocalDateTime.now());
		observacao.setNomeUsuarioExclusao(keycloakService.getUsername());
		cooperativaObservacaoUeRepository.save(observacao);

		return observacao;
	}

	/**
	 * Retorna a observação ativa para a cooperativa com o ID indicado.<br>
	 * <br>
	 * Permissões: Unidade Nacional e Unidade Estadual (apenas do estado da
	 * cooperativa)
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Observação.
	 */
	public CooperativaObservacaoUe getObservacaoAtiva(Integer idCooperativa) {
		if (!temPermissaoDeLeitura(idCooperativa)) {
			throw new RegraNegocioException(USUARIO_NAO_POSSUI_PERMISSAO_PARA_ESTE_ITEM);
		}
		return cooperativaObservacaoUeRepository.getObservacaoAtiva(idCooperativa);
	}
	
	/**
	 * Retorna a observação ativa para a cooperativa com o ID indicado, realiza o ignoramento das permissão de usuário.<br>
	 * <br>
	 * Permissões: Sem restrição. (Deve ser utilizado apenas para chamadas internas do sistemas, como por exemplo: Gerar Relatórios.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Observação.
	 */
	public CooperativaObservacaoUe getObservacaoAtivaIgnorarPermissoes(Integer idCooperativa) {
		return cooperativaObservacaoUeRepository.getObservacaoAtiva(idCooperativa);
	}

	/**
	 * Retorna o histórico de Observações da UE da Cooperativa com o ID
	 * indicado.<br>
	 * Permissões: Unidade Nacional e Unidade Estadual (apenas do estado da
	 * cooperativa)
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Lista com o histórico de Observações.
	 */
	public List<CooperativaObservacaoUe> getHistorico(Integer idCooperativa) {
		if (!temPermissaoDeLeitura(idCooperativa)) {
			throw new RegraNegocioException(USUARIO_NAO_POSSUI_PERMISSAO_PARA_ESTE_ITEM);
		}
		return cooperativaObservacaoUeRepository.getHistorico(idCooperativa);
	}

	/**
	 * Realiza a gravação da Observação da Unidade Estadual.<br>
	 * <br>
	 * Ao ser realizado a gravação, a observação ativa anterior deve ser marcada
	 * como excluída juntamente com o nome do Usuário que fez a exclusão.<br>
	 * <br>
	 * Permissões: Unidade Nacional (com permissão de gestor) e Unidade Estadual
	 * (com permissão de gestor e que de mesma UF que a cooperativa).
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Observação após gravação.
	 */
	public CooperativaObservacaoUe salvar(Integer idCooperativa, String observacao) {
		if (idCooperativa == null) {
			throw new RegraNegocioException("A cooperativa não foi definida.");
		}

		if (!temPermissaoDeGravacao(idCooperativa)) {
			throw new RegraNegocioException(USUARIO_NAO_POSSUI_PERMISSAO_PARA_ESTE_ITEM);
		}

		// Validação
		if (observacao == null || observacao.trim().isEmpty() || observacao.equals(NULL)
				|| observacao.equals(UNDEFINED))
			throw new RegraNegocioException("A observação não pode ser nula.");
		if (observacao.length() > DUZENTOS_CINQUENTA)
			throw new RegraNegocioException("O tamanho máximo da Observação é de 250 caracteres.");

		CooperativaObservacaoUe observacaoAnterior = cooperativaObservacaoUeRepository
				.getObservacaoAtiva(idCooperativa);

		// Se a nova observação é igual a observação vigente, não precisa gravar.
		if (observacaoAnterior != null && observacao.equals(observacaoAnterior.getObservacao()))
			return observacaoAnterior;

		String nomeDoUsuario = keycloakService.getUsername();
		CooperativaObservacaoUe observacaoUe = new CooperativaObservacaoUe();
		observacaoUe.setIdCooperativa(idCooperativa);
		observacaoUe.setDataDeInclusao(LocalDateTime.now());
		observacaoUe.setNomeUsuarioInclusao(nomeDoUsuario);
		observacaoUe.setObservacao(observacao);

		cooperativaObservacaoUeRepository.save(observacaoUe);

		// Realiza a marcação da observação anterior como excluída.
		if (observacaoAnterior != null) {
			observacaoAnterior.setDataDeExclusao(LocalDateTime.now());
			observacaoAnterior.setNomeUsuarioExclusao(nomeDoUsuario);

			cooperativaObservacaoUeRepository.save(observacaoAnterior);
		}

		observacaoAnterior = null;
		nomeDoUsuario = null;

		return observacaoUe;
	}

	/**
	 * Retorna se o usuário tem permissão de leitura à cooperativa com o ID
	 * indicado.<br>
	 * Permissões: Unidade Federal e Unidade Estadual (desde que seja da mesma UF da
	 * cooperativa).
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return true/false.
	 */
	public boolean temPermissaoDeLeitura(int idCooperativa) {
		if (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual()) {
			Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);
			if (cooperativa == null)
				throw new RegraNegocioException("Não existe a cooperativa com o ID indicado.");
			if (keycloakService.isTipoEntidadeNacional()) {
				// Usuário pertence ao nacional
				return true;
			} else if (keycloakService.isTipoEntidadeEstadual() && cooperativa.getPessoaJuridica() != null
					&& cooperativa.getPessoaJuridica().getUfSigla() != null && keycloakService.getUFUsuario() != null
					&& cooperativa.getPessoaJuridica().getUfSigla().equalsIgnoreCase(keycloakService.getUFUsuario())) {
				// Cooperativa pertence ao mesmo estado da Unidade Estadual.
				return true;
			}
		}
		return false;
	}

	/**
	 * Retorna se o usuário tem permissão de gravação de observações na cooperativa
	 * com o ID indicado.<br>
	 * <br>
	 * Permissões: Unidade Nacional (com permissão de gestor) e Unidade Estadual
	 * (com permissão de gestor e que possua a mesma UF que a cooperativa).
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return true/false.
	 */
	public boolean temPermissaoDeGravacao(int idCooperativa) {
		Cooperativa cooperativa = null;
		if (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual()) {
			cooperativa = cooperativaService.getCooperativa(idCooperativa);
			if (cooperativa == null)
				throw new RegraNegocioException("Não existe a cooperativa com o ID indicado.");
			if (keycloakService.isTipoEntidadeNacional()) {
				// Usuário pertence ao nacional
				if (Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil("UN_GES"))) {
					// Usuário é gestor.
					return true;
				}
				return false;
			} else if (keycloakService.isTipoEntidadeEstadual() && cooperativa.getPessoaJuridica() != null
					&& cooperativa.getPessoaJuridica().getUfSigla() != null && keycloakService.getUFUsuario() != null
					&& cooperativa.getPessoaJuridica().getUfSigla().equalsIgnoreCase(keycloakService.getUFUsuario())) {
				// Cooperativa pertence ao mesmo estado da Unidade Estadual.
				if (Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil(Arrays.asList("UE_GES","UE_ANA_DADOS","UE_RESP_SITUACAO")))) {
					// Usuário é gestor
					return true;
				}
				return false;
			}
		}
		return false;
	}

	
}
