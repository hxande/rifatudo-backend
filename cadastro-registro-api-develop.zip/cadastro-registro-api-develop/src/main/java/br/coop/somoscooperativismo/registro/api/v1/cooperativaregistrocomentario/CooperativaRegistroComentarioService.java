package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.CooperativaRegistroRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentario;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentarioMotivo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityNotFoundException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CooperativaRegistroComentarioService {

    @Autowired
    private CooperativaRegistroComentarioRepository comentarioRepository;

    @Autowired
    private CooperativaRegistroRepository cooperativaRegistroRepository;

    @Autowired
    private KeycloakService keycloakService;

    @Autowired
    private CooperativaRegistroComentarioMotivoRepository motivoRepository;

    public List<CooperativaRegistroComentario> findAllByCooperativaRegistroId(Integer cooperativaRegistroId) {
        return comentarioRepository.findByCooperativaRegistroId(cooperativaRegistroId);
    }

    protected CooperativaRegistroComentario convertToEntity(CooperativaRegistroComentarioTO comentarioTO) {
        CooperativaRegistroComentario comentario = new CooperativaRegistroComentario();
        //comentario.setAcao(comentarioTO.getAcao()); // TODO atribuir automaticamente a ação do tipo Alteração
        comentario.setUsuarioAlteracao(keycloakService.getUsername());

        CooperativaRegistro cooperativaRegistro = cooperativaRegistroRepository.findById(comentarioTO.getCooperativaRegistroId())
                .orElseThrow(() -> new EntityNotFoundException("CooperativaRegistro not found"));
        comentario.setCooperativaRegistro(cooperativaRegistro);

        cooperativaRegistro = null;

        return comentario;
    }

    @Transactional
    public CooperativaRegistroComentario saveComentario(CooperativaRegistroComentarioTO comentarioTO) {
        CooperativaRegistroComentario comentario = convertToEntity(comentarioTO);

        comentario.setAcao("Alteração");
        comentario.setUsuarioAlteracao(keycloakService.getUsername());
        comentario.setDataAlteracao(new Date());
        comentario.setObservacao(comentarioTO.getObservacao());

        comentario = comentarioRepository.save(comentario);
        CooperativaRegistroComentario finalComentario = comentario;

        List<CooperativaRegistroComentarioMotivo> motivos = comentarioTO.getMotivos().stream()
                .map(motivoStr -> {
                    CooperativaRegistroComentarioMotivo motivo = new CooperativaRegistroComentarioMotivo();
                    motivo.setCooperativaRegistroComentario(finalComentario);
                    motivo.setMotivo(motivoStr);
                    return motivo;
                })
                .collect(Collectors.toList());

        motivoRepository.saveAll(motivos);

        motivos = null;

        return comentario;
    }
}
