package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CooperativaSolicitacaoIrregularidadeTO {
	
	@NotNull
	private Integer idCooperativa;
	
	@NotNull
	private Integer idSolicitacao;
	
	@NotNull
	private String justificativa;
	
	private Boolean solicitacaoInativacao;

}
