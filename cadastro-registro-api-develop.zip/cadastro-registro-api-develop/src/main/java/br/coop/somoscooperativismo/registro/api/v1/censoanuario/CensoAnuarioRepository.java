package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import br.coop.somoscooperativismo.registro.api.v1.censoanuario.entidade.CensoAnuario;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CensoAnuarioRepository extends JpaRepository<CensoAnuario, Integer> {
    Optional<CensoAnuario> findByAnoAndCooperativaId(Integer ano, Integer cooperativaId);
    boolean existsByAnoAndCooperativaId(Integer ano, Integer cooperativaId);
}
