
package br.coop.somoscooperativismo.registro.api.v1.certificado;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/certificado")
@Tag(name = "Categoria")
public class CertificadoRestController {

    public static final String CATEGORIA_CRIADA = "categoria.criada";
    public static final String NAO_CORRESPONDE = "categoria.naoCorresponde";
    public static final String CATEGORIA_ATUALIZADA = "categoria.atualizada";
    public static final String CATEGORIA_DESATIVADA = "categoria.desativada";

    @Autowired
    private CertificadoService certificadoService;
    
    @GetMapping(value = "/pdf/{idCooperativa}")
    public ServiceResponse<byte[]> imprimirCertificadoCoopParam(@PathVariable Integer idCooperativa) {
        return new ServiceResponse<>(certificadoService.imprimirCertificado(idCooperativa), new ServiceMessage("Certificado de registro gerado com sucesso."));

    }

    @GetMapping("/pode-imprimir/{idCooperativa}")
    @Operation(summary = "Pode imprimir certificado")
    public ResponseEntity<ServiceResponse<Boolean>> podePreencherCadastroRegistro(@PathVariable Integer idCooperativa){
        return new ResponseEntity<>(new ServiceResponse<Boolean>(certificadoService.validaSePodeImprimir(idCooperativa)), HttpStatus.OK);
    }
}
