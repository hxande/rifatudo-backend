package br.coop.somoscooperativismo.registro.api.v1.complementoanuario;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.entidade.ComplementoAnuario;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.ComplementoAnuarioRamoUrlMapper;

@Mapper(componentModel = "spring", uses = {ComplementoAnuarioRamoUrlMapper.class})
public interface ComplementoAnuarioMapper {
    ComplementoAnuario toModel(ComplementoAnuarioTO complementoAnuarioTO);

    @Mapping(source = "complementoAnuarioRamoUrls", target = "complementoAnuarioRamoUrls", ignore = true)
    ComplementoAnuarioTO toDtoNoChilds(ComplementoAnuario complementoAnuario);

    ComplementoAnuarioTO toDto(ComplementoAnuario complementoAnuario);
}
