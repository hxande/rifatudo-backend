package br.coop.somoscooperativismo.registro.api.v1.controleportifolio.entidade;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "CONTROLE_PORTIFOLIO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
@Data
@NoArgsConstructor
public class ControlePortifolio {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SQ_CONTROLE_PORTIFOLIO")
	private Integer id;
	
	
	@Column(name="DN_INFORMAR_CAMPOS")
	private Boolean informarCampos;
	
	@Column(name="TX_UF")
	private String uf;
	
	
}
