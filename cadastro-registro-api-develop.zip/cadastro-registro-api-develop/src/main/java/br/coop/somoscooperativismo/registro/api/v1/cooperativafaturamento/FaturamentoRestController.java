package br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento;

import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade.Faturamento;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/faturamento")
@Tag(name = "Faturamento")
public class FaturamentoRestController {
	
	@Autowired
	private FaturamentoService faturamentoService;
	
	@GetMapping("/buscarFaturamentosPorCooperativaNoCiclo/{idCooperativa}")
	@Operation(summary = "Lista os dois ultimos faturamentos da cooperativa", description = "Um ID válido deve ser informado")
	public ServiceResponse<List<Faturamento>> getFaturamentosPorCooperativaNoCiclo(@PathVariable Integer idCooperativa) {
		return new ServiceResponse<>(faturamentoService.getFaturamentosPorCooperativaNoCiclo(idCooperativa));
	}

	@GetMapping("/buscaHistoricoFaturamento/{idCooperativa}")
	@Operation(summary = "Lista os dois ultimos faturamentos da cooperativa", description = "Um ID válido deve ser informado")
	public ServiceResponse<List<Faturamento>> getFaturamentoHistorico(@PathVariable Integer idCooperativa) {
		return new ServiceResponse<>(faturamentoService.getFaturamentoHistorico(idCooperativa));
	}

	@PutMapping("/salvarHistorico/{idCooperativa}")
	@Operation(summary = "Salva faturamento histórico", description = "Um ID válido deve ser informado")
	public ServiceResponse<List<Faturamento>> getFaturamentoHistorico(@RequestBody List<Faturamento> faturamentos, @PathVariable Integer idCooperativa) {
		return new ServiceResponse<>(faturamentoService.salvarHistoricoFaturamento(idCooperativa, faturamentos), new ServiceMessage("Salvo com sucesso"));
	}



}
