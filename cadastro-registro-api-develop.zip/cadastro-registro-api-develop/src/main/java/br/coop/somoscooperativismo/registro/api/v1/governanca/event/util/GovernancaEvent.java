package br.coop.somoscooperativismo.registro.api.v1.governanca.event.util;

public interface GovernancaEvent {
     GovernancaEventEnum eventType();
}
