package br.coop.somoscooperativismo.registro.api.v1.escolaridade;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.web.JsonUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

@Service
@SuppressWarnings("rawtypes")
public class EscolaridadeService {

	@Value("${desenvolvimento_humano_host}")
	private String desenvolvimentoServiceHost;


	private final RestTemplate keycloakRestTemplate;

	public EscolaridadeService(RestTemplate keycloakRestTemplate) {
		this.keycloakRestTemplate = keycloakRestTemplate;
	}

	public List<EscolaridadeTO> getEscolaridades() {
		String url = desenvolvimentoServiceHost + "/api/v1/escolaridade/all";
		List<EscolaridadeTO> listaEscolaridadeTO = new ArrayList<>();

		try {
			LinkedHashMap retorno = keycloakRestTemplate.getForObject(url, LinkedHashMap.class);
			assert retorno != null;
			String dados = JsonUtil.toJson(retorno.get("data"));
			listaEscolaridadeTO = JsonUtil.toObject(dados, new TypeReference<List<EscolaridadeTO>>() {});
		} catch(HttpClientErrorException e) {
			throw new RegraNegocioException(e.getMessage(),e);
		}

		url = null;

		return listaEscolaridadeTO;
	}
}
