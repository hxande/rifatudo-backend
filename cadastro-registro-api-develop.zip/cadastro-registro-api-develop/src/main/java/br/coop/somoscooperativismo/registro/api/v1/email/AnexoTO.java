package br.coop.somoscooperativismo.registro.api.v1.email;

public class AnexoTO {
	
	private String nomeArquivo;

    private String arquivoBase64;

	public String getNomeArquivo() {
		return nomeArquivo;
	}

	public void setNomeArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}

	public String getArquivoBase64() {
		return arquivoBase64;
	}

	public void setArquivoBase64(String arquivoBase64) {
		this.arquivoBase64 = arquivoBase64;
	}
	
	
        
}
