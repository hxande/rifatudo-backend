package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CriterioAssociacaoRamoTO {

	private Integer id;
	private String nome;
	private Boolean ativo;
	private Boolean ramoAtivo;
	
	public CriterioAssociacaoRamoTO(Integer id,String nome, Boolean ativo, Long qtdCriterioAssociacao) {
		this.id = id;
		this.nome = nome;
		this.ramoAtivo = ativo;
		this.ativo = !(qtdCriterioAssociacao == null || qtdCriterioAssociacao.equals(0L));
	}
}
