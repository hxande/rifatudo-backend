package br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual;

import br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual.entidade.CertificadoUnidadeEstadual;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;

@Service
public class CertificadoUnidadeEstadualService {

	 @Autowired
	 CertificadoUnidadeEstadualRepository certificadoUnidadeEstadualRepository;
	 
	public List<CertificadoUnidadeEstadual> findAll() {
		return certificadoUnidadeEstadualRepository.findAll();
	}
	
	public List<CertificadoUnidadeEstadual> salvarTodas(List<CertificadoUnidadeEstadual> listaCertificadoUnidadeEstadual) {
		if(!listaCertificadoUnidadeEstadual.isEmpty()) {	
			for(CertificadoUnidadeEstadual cert : listaCertificadoUnidadeEstadual) {
				try {
					certificadoUnidadeEstadualRepository.save(cert);				
				} catch (Exception e) {
					throw new RegraNegocioException(e.getMessage(),e);
				}				
			}
		}
		return certificadoUnidadeEstadualRepository.findAll();
	}

	public CertificadoUnidadeEstadual buscaPorUf(String uf) {
		Optional<CertificadoUnidadeEstadual> optCert = certificadoUnidadeEstadualRepository.findByUf(uf);
		if(optCert.isPresent()) {
			return optCert.get();
		}
		return  null;
	}
}
