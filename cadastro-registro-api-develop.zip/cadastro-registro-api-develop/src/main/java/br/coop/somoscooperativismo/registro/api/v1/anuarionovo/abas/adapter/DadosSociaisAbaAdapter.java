package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioFieldsTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util.ConversorParametroIntegracaoService;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util.MapeadorFieldService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.CensoAnuarioService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.DadosSociaisFinanceirosTO;
import br.coop.somoscooperativismo.registro.api.v1.quadroSocialParametroQuadro.to.QuadroSocialEmpregadosDadosAdicionaisTO;
import br.coop.somoscooperativismo.registro.api.v1.quadroSocialParametroQuadroCooperado.to.QuadroSocialCooperadosDadosAdicionaisTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.to.QuadroSocialAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocialuf.to.QuadroSocialUFTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class DadosSociaisAbaAdapter {

    private final MapeadorFieldService mapeadorFieldService;
    private final CensoAnuarioService censoAnuarioService;
    private final ConversorParametroIntegracaoService conversorParametroIntegracaoService;

    public boolean execute(Integer idCooperativa, Integer ano, RequestAnuarioTO request, boolean isSubmit) {
        QuadroSocialAnuarioTO quadroSocialAnuarioTO = new QuadroSocialAnuarioTO();
        DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO = new DadosSociaisFinanceirosTO(new QuadroSocial(), new DadosIntegracaoTO());

        boolean resultDadosFinanceiros = true;

        for (RequestAnuarioFieldsTO grupo : request.getFields()) {
            if (grupo.getName().equals(NomeQuadroEnum.QUANTIDADE_COOPERADOS.toString()) || grupo.getName().equals(NomeQuadroEnum.QUANTIDADE_EMPREGADOS.toString())) {
                this.processarQuantidadeCooperados(idCooperativa, ano, grupo, quadroSocialAnuarioTO);
            }

            if (grupo.getName().equals(NomeQuadroEnum.COOPERADOS_ADICIONAIS.toString())) {
                this.processarCooperadosAdicionais(grupo, quadroSocialAnuarioTO);
            }

            if (grupo.getName().equals(NomeQuadroEnum.EMPREGADOS_ADICIONAIS.toString())) {
                this.processarEmpregadosAdicionais(grupo, quadroSocialAnuarioTO);
            }

            if (grupo.getName().equals(NomeQuadroEnum.DADOS_COMPLEMENTARES.toString())) {
                dadosSociaisFinanceirosTO.getFinanceiro().setAno(ano);
                dadosSociaisFinanceirosTO.getFinanceiro().setIdCooperativa(idCooperativa);

                this.processarDadosComplementares(grupo, dadosSociaisFinanceirosTO);
                resultDadosFinanceiros = this.censoAnuarioService.salvarAbaDadosFinanceiros(idCooperativa, ano, dadosSociaisFinanceirosTO, isSubmit);
            }
        }

        Integer situacao = request.getSituacao() != null ? request.getSituacao() : this.inferirSituacaoImportacao(request);
        boolean resultDadosSociais = this.censoAnuarioService.salvarAbaDadosSociais(idCooperativa, ano, List.of(quadroSocialAnuarioTO), situacao, isSubmit);

        return resultDadosSociais && resultDadosFinanceiros;
    }

    private Integer inferirSituacaoImportacao(RequestAnuarioTO request) {
        if (request.getFields() == null || request.getFields().isEmpty()) {
            return 0;
        }

        List<FieldTO> campos = request.getFields().stream()
                .filter(grupo -> grupo.getFields() != null)
                .flatMap(grupo -> grupo.getFields().stream())
                .flatMap(row -> row != null ? row.stream() : Stream.empty())
                .toList();

        if (campos.isEmpty()) {
            return 0;
        }

        if (campos.stream().anyMatch(campo -> "pendencia-form".equals(campo.getId()) && temValor(campo.getValue()))) {
            return -1;
        }

        boolean possuiCamposEmBranco = campos.stream().anyMatch(campo -> !temValor(campo.getValue()));
        return possuiCamposEmBranco ? 0 : 1;
    }

    private boolean temValor(String value) {
        return value != null && !value.isBlank();
    }

    private void processarCooperadosAdicionais(RequestAnuarioFieldsTO grupo, QuadroSocialAnuarioTO quadroSocialAnuarioTO) {
        List<DadosDinamicosTO> dadosDinamicos = mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), QuadroSocialCooperadosDadosAdicionaisTO.class);

        dadosDinamicos.forEach(dado -> {
            for (DadoIntegracaoTO dadoIntegracaoTO : dado.getDadosIntegracao()) {
                QuadroSocialCooperadosDadosAdicionaisTO quadroSocial = new QuadroSocialCooperadosDadosAdicionaisTO();
                quadroSocial.setIdQuadroSocial(grupo.getIdQuadro());
                quadroSocial.setIdParametroQuadroSocialCooperado(dadoIntegracaoTO.getIdParametroAuxiliar());
                quadroSocial.setQuantidade(dadoIntegracaoTO.getValue() != null && !dadoIntegracaoTO.getValue().isBlank() ? Integer.valueOf(dadoIntegracaoTO.getValue()) : null);

                quadroSocialAnuarioTO.getListaCooperadosDadosAdicionais().add(quadroSocial);
            }
        });
    }

    private void processarQuantidadeCooperados(Integer idCooperativa, Integer ano, RequestAnuarioFieldsTO grupo, QuadroSocialAnuarioTO quadroSocialAnuarioTO) {
        List<DadosDinamicosTO> dadosDinamicos = mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), QuadroSocialUFTO.class);

        quadroSocialAnuarioTO.setId(grupo.getIdQuadro());
        quadroSocialAnuarioTO.setIdPessoaJuridica(idCooperativa);
        quadroSocialAnuarioTO.setAno(ano);

        Map<String, QuadroSocialUFTO> mapaQuadroSocialUF = quadroSocialAnuarioTO.getListaQuadroSocialUFTO().stream()
                .filter(q -> q.getUf() != null)
                .collect(Collectors.toMap(QuadroSocialUFTO::getUf, Function.identity(), (existing, replacement) -> existing));

        boolean processaCooperadosPorUf = false;
        boolean processaEmpregadosUf = false;
        boolean isCooperados = grupo.getName().equals(NomeQuadroEnum.QUANTIDADE_COOPERADOS.toString());
        boolean isEmpregados = grupo.getName().equals(NomeQuadroEnum.QUANTIDADE_EMPREGADOS.toString());

        for (DadosDinamicosTO dado : dadosDinamicos) {
            QuadroSocialUFTO quadroSocialNovo = (QuadroSocialUFTO) dado.getEntidadeMapeada();
            quadroSocialNovo.setId(quadroSocialNovo.getIdParametro());
            quadroSocialNovo.setIdQuadroSocial(grupo.getIdQuadro());

            QuadroSocialUFTO quadroSocial = quadroSocialNovo;

            if (quadroSocialNovo.getUf() != null && mapaQuadroSocialUF.containsKey(quadroSocialNovo.getUf())) {
                quadroSocial = mapaQuadroSocialUF.get(quadroSocialNovo.getUf());
                mergeCooperadosData(quadroSocial, quadroSocialNovo);
            } else {
                quadroSocialAnuarioTO.getListaQuadroSocialUFTO().add(quadroSocial);
                if (quadroSocial.getUf() != null) {
                    mapaQuadroSocialUF.put(quadroSocial.getUf(), quadroSocial);
                }
            }

            /* ---------------- COOPERADOS ---------------- */
            if (isCooperados && quadroSocial.getCooperadosPFUF() != null) {
                var qtd = quadroSocialAnuarioTO.getCooperadosPF() != null ? quadroSocialAnuarioTO.getCooperadosPF() : 0;
                quadroSocialAnuarioTO.setCooperadosPF(qtd + quadroSocial.getCooperadosPFUF());
            }

            if (isCooperados && quadroSocial.getCooperadosPJUF() != null) {
                var qtd = quadroSocialAnuarioTO.getCooperadosPJ() != null ? quadroSocialAnuarioTO.getCooperadosPJ() : 0;
                quadroSocialAnuarioTO.setCooperadosPJ(qtd + quadroSocial.getCooperadosPJUF());
            }

            if (isCooperados && quadroSocial.getCooperadosHomensUF() != null) {
                var qtd = quadroSocialAnuarioTO.getCooperadosHomens() != null ? quadroSocialAnuarioTO.getCooperadosHomens() : 0;
                quadroSocialAnuarioTO.setCooperadosHomens(qtd + quadroSocial.getCooperadosHomensUF());
            }

            if (isCooperados && quadroSocial.getCooperadosMulheresUF() != null) {
                var qtd = quadroSocialAnuarioTO.getCooperadosMulheres() != null ? quadroSocialAnuarioTO.getCooperadosMulheres() : 0;
                quadroSocialAnuarioTO.setCooperadosMulheres(qtd + quadroSocial.getCooperadosMulheresUF());
            }

            if (isCooperados && quadroSocial.getCooperadosTotalUF() != null) {
                var qtd = quadroSocialAnuarioTO.getCooperadosTotal() != null ? quadroSocialAnuarioTO.getCooperadosTotal() : 0;
                quadroSocialAnuarioTO.setCooperadosTotal(qtd + quadroSocial.getCooperadosTotalUF());
            }

            if (isCooperados && quadroSocial.getCooperadosAtivosUF() != null) {
                var qtd = quadroSocialAnuarioTO.getCooperadosAtivos() != null ? quadroSocialAnuarioTO.getCooperadosAtivos() : 0;
                quadroSocialAnuarioTO.setCooperadosAtivos(qtd + quadroSocial.getCooperadosAtivosUF());
            }

            /* ---------------- EMPREGADOS ---------------- */
            if (isEmpregados && quadroSocial.getEmpregadosHomensUF() != null) {
                var qtd = quadroSocialAnuarioTO.getEmpregadosHomens() != null ? quadroSocialAnuarioTO.getEmpregadosHomens() : 0;
                quadroSocialAnuarioTO.setEmpregadosHomens(qtd + quadroSocial.getEmpregadosHomensUF());
            }

            if (isEmpregados && quadroSocial.getEmpregadosMulheresUF() != null) {
                var qtd = quadroSocialAnuarioTO.getEmpregadosMulheres() != null ? quadroSocialAnuarioTO.getEmpregadosMulheres() : 0;
                quadroSocialAnuarioTO.setEmpregadosMulheres(qtd + quadroSocial.getEmpregadosMulheresUF());
            }

            if (isEmpregados && quadroSocial.getEmpregadosTotalUF() != null) {
                var qtd = quadroSocialAnuarioTO.getEmpregadosTotal() != null ? quadroSocialAnuarioTO.getEmpregadosTotal() : 0;
                quadroSocialAnuarioTO.setEmpregadosTotal(qtd + quadroSocial.getEmpregadosTotalUF());
            }

            if (isCooperados && quadroSocial.getUf() != null) {
                processaCooperadosPorUf = true;
            }

            if (isEmpregados && quadroSocial.getUf() != null) {
                processaEmpregadosUf = true;
            }
        }

        quadroSocialAnuarioTO.setInformaCooperadosUF(processaCooperadosPorUf);
        quadroSocialAnuarioTO.setInformaEmpregadosUF(processaEmpregadosUf);
    }

    private void mergeCooperadosData(QuadroSocialUFTO existente, QuadroSocialUFTO novo) {
        if (novo.getCooperadosPFUF() != null) {
            existente.setCooperadosPFUF(novo.getCooperadosPFUF());
        }
        if (novo.getCooperadosHomensUF() != null) {
            existente.setCooperadosHomensUF(novo.getCooperadosHomensUF());
        }
        if (novo.getCooperadosMulheresUF() != null) {
            existente.setCooperadosMulheresUF(novo.getCooperadosMulheresUF());
        }
        if (novo.getCooperadosPJUF() != null) {
            existente.setCooperadosPJUF(novo.getCooperadosPJUF());
        }
        if (novo.getCooperadosTotalUF() != null) {
            existente.setCooperadosTotalUF(novo.getCooperadosTotalUF());
        }
        if (novo.getCooperadosAtivosUF() != null) {
            existente.setCooperadosAtivosUF(novo.getCooperadosAtivosUF());
        }
        if (novo.getEmpregadosHomensUF() != null) {
            existente.setEmpregadosHomensUF(novo.getEmpregadosHomensUF());
        }
        if (novo.getEmpregadosMulheresUF() != null) {
            existente.setEmpregadosMulheresUF(novo.getEmpregadosMulheresUF());
        }
        if (novo.getEmpregadosTotalUF() != null) {
            existente.setEmpregadosTotalUF(novo.getEmpregadosTotalUF());
        }
    }

    private void processarEmpregadosAdicionais(RequestAnuarioFieldsTO grupo, QuadroSocialAnuarioTO quadroSocialAnuarioTO) {
        List<DadosDinamicosTO> dadosDinamicos = mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), QuadroSocialEmpregadosDadosAdicionaisTO.class);

        dadosDinamicos.forEach(dado -> {
            for (DadoIntegracaoTO dadoIntegracaoTO : dado.getDadosIntegracao()) {
                QuadroSocialEmpregadosDadosAdicionaisTO quadroSocial = new QuadroSocialEmpregadosDadosAdicionaisTO();
                quadroSocial.setIdQuadroSocial(grupo.getIdQuadro());
                quadroSocial.setIdParametroQuadroSocial(dadoIntegracaoTO.getIdParametroAuxiliar());
                quadroSocial.setQuantidade(dadoIntegracaoTO.getValue() != null && !dadoIntegracaoTO.getValue().isBlank() ? Integer.valueOf(dadoIntegracaoTO.getValue()) : null);

                quadroSocialAnuarioTO.getListaEmpregadosDadosAdicionais().add(quadroSocial);
            }
        });
    }

    private void processarDadosComplementares(RequestAnuarioFieldsTO grupo, DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO) {
        List<DadosDinamicosTO> dadosDinamicos = mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), DadosSociaisFinanceirosTO.class);

        String dadosSociaisFinanceiro = conversorParametroIntegracaoService.converterDadosDinamicos(dadosDinamicos);

        dadosSociaisFinanceirosTO.getFinanceiro().setSocialFinanceiro(dadosSociaisFinanceiro);
    }

}
