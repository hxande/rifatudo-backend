package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums;

public enum NomeAbaEnum {
    DADOS_SOCIAIS("DADOS_SOCIAIS", "Dados sociais", "tab-dado-social", 0),
    PORTFOLIO("PORTFOLIO", "Portfólio", "tab-portfolio", 1),
    CONTABIL_TRIBUTARIO("CONTABIL_TRIBUTARIO", "Detalhamento contábil", "tab-contabil-tribuario", 2),
    NEGOCIO("NEGOCIO", "Negócio", "tab-negocio", 3),
    DADOS_COMPLEMENTARES("DADOS_COMPLEMENTARES", "Dados Complementares", "tab-dados-complementares", 4);


    private String chaveAba;
    private String nomeAba;
    private String idAba;
    private Integer indice;

    NomeAbaEnum(String chaveAba, String nomeAba, String idAba, Integer indice) {
        this.chaveAba = chaveAba;
        this.nomeAba = nomeAba;
        this.idAba = idAba;
        this.indice = indice;
    }

    public static String getEnum(String chave) {
        for (NomeAbaEnum nomeAba : NomeAbaEnum.values()) {
            if (nomeAba.getChaveAba().equals(chave)) {
                return nomeAba.getNomeAba();
            }
        }
        return null;
    }

    public static String getIdEnum(String chave) {
        for (NomeAbaEnum nomeAba : NomeAbaEnum.values()) {
            if (nomeAba.getChaveAba().equals(chave)) {
                return nomeAba.getIdAba();
            }
        }
        return null;
    }

    public static Integer getIndice(String chave) {
        for (NomeAbaEnum nomeAba : NomeAbaEnum.values()) {
            if (nomeAba.getChaveAba().equals(chave)) {
                return nomeAba.getIndice() != null ? nomeAba.getIndice(): -1;
            }
        }
        return null;
    }

    public String getChaveAba() {
        return chaveAba;
    }

    public String getNomeAba() {
        return nomeAba;
    }

    public String getIdAba() {
        return idAba;
    }

    public Integer getIndice() {
        return indice;
    }

}
