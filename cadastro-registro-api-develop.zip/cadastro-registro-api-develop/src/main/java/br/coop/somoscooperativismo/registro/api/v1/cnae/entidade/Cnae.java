package br.coop.somoscooperativismo.registro.api.v1.cnae.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;

@Entity
@Table(name = "CNAE")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Cnae {

	@Id
	@Column(name="TX_CODIGO_CNAE", nullable=false)
	@Size(max = 11)
	private String id;

	@Column(name="TX_DESCRICAO_CNAE", nullable=false)
	@NotBlank(message = "A descricao do cnae nao pode ser em branco")
	@Size(max = 1000)
	private String descricao;
	
	@Column(name="IN_REGISTRO_ATIVO", nullable=false)
	@NotNull(message = "cnae ativa deve ser informado")
	private Boolean ativo;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public String getDescricaoFormatada() {
		return "%s - %s".formatted(this.getId(), this.descricao);
	}
}
