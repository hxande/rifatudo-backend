package br.coop.somoscooperativismo.registro.api.v1.fates;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.envers.Audited;

import java.io.Serializable;

@Entity
@Data
@Table(name = "COOPERATIVA_FATES_FINALIDADE")
@Audited
public class CooperativaFatesFinalidade implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private CooperativaFatesFinalidadeId id = new CooperativaFatesFinalidadeId();

    @MapsId("cooperativaFatesId")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_COOPERATIVA_FATES", nullable = false)
    @JsonBackReference
    private CooperativaFates cooperativaFates;

    @Column(name = "TX_FINALIDADE", nullable = false)
    private String nome;
}

