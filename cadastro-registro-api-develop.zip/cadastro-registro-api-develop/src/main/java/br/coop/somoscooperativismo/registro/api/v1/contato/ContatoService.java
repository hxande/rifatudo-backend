package br.coop.somoscooperativismo.registro.api.v1.contato;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.areacontato.AreaContatoRepository;
import br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade.AreaContato;
import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.contato.to.ContatoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.AbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.CooperativaManutencaoAbasService;
import br.coop.somoscooperativismo.registro.api.v1.pessoa.PessoaRepository;
import br.coop.somoscooperativismo.registro.api.v1.pessoa.entidade.Pessoa;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaRepository;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import jakarta.validation.Valid;


@Service
public class ContatoService {

    public static final String NAO_ENCONTRADO = "contato.naoEncontrado";
    public static final String PESSOA_NAO_ENCONTRADO = "pessoaJuridica.naoEncontrada";
    public static final String AREA_CONTATO_NAO_ENCONTRADA = "areaContato.naoEncontrado";
    public static final String CONTATO_EXISTENTE = "contato.existente";
    public static final String PESSOA_FISICA_NAO_ENCONTRADO = "pessoafisica.naoEncontrada";
    public static final String CONTATO_CAMPOS_OBRIGATORIOS = "contato.camposObrigatorios";
    public static final String CONTATO_NOME_NAO_INFORMADO = "contato.nomeNaoInformado";
    public static final String CONTATO_TELEFONE_NAO_INFORMADO = "contato.telefoneNaoInformado";
    public static final String CONTATO_EMAIL_NAO_INFORMADO = "contato.emailNaoInformado";
    public static final String CONTATO_EMAIL_INVALIDO = "contato.emailInvalido";
    public static final String CONTATO_CARGO_INVALIDO = "contato.cargoNaoInformado";
    public static final String CONTATO_CAMPOS_INVALIDO = "contato.camposInvalido";
    public static final String CONTATO_CAMPOS_NOME = "Para cadastrar, é necessário informar o nome";
    public static final String CONTATO_CAMPOS_OBRIGATORIO = "Para cadastrar, é necessário informar o telefone ou o E-mail";

    @Autowired
    ContatoRepository contatoRepository;

    @Autowired
    AreaContatoRepository areaContatoRepository;

    @Autowired
    PessoaRepository pessoaRepository;

    @Autowired
    PessoaJuridicaRepository pessoaJuridicaRepository;

    @Autowired
    CooperativaRepository cooperativaRepository;

    @Autowired
    private MessagesService messages;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    KeycloakService keycloakService;
    @Autowired
    private CooperativaManutencaoAbasService cooperativaManutencaoAbasService;


    public List<Contato> getContatosPessoa(Integer idPessoa) {
        return contatoRepository.buscaPorPessoa(idPessoa);
    }

    public List<Contato> getAreaContatosPessoa(Integer idArea, Integer idPessoa) {
        return contatoRepository.buscaPorAreaPessoa(idArea, idPessoa);
    }


    public boolean salvaListaContatos(@Valid List<ContatoTO> contatosTo, @Valid Integer idPessoa) {
        List<Contato> contatos = contatosTo.stream().map(this::converterTOParaContato).toList();

        contatos.forEach(this::validaContato);

        boolean retorno = verificarTodosCamposPreenchidos(contatos);
        boolean isTodosContatosPreenchidos = verificaSeInformouTodosContatos(contatos, idPessoa);

        // Salva a data de atualização Cadastral na cooperativa
        List<Cooperativa> coops = cooperativaRepository.findByVwPessoaJuridicaId(idPessoa);
        coops.forEach( x-> x.setDataAtualizacao(new Date()));
        cooperativaRepository.saveAll(coops);

        // Apaga Tudo
        contatoRepository.excluiPorAreaPessoa(idPessoa);
        // Salva Tudo
        contatos.forEach(c -> {
            c.setId(null);
            c.setDataAtualizacao(LocalDateTime.now());
            c.setUsuarioAtualizacao(keycloakService.getUsername());
            contatoRepository.save(c);
        });

        cooperativaManutencaoAbasService.salvarStatusAbasManutencao(idPessoa, retorno, AbaEnum.ABA_CONTATOS, isTodosContatosPreenchidos);

        return retorno;
    }

    /**
     * Verifica ao menos um contato informado para cada área de contato não obrigatória.
     *
     * @param contatos
     * @param idPessoa
     * @return
     */
    private boolean verificaSeInformouTodosContatos(List<Contato> contatos, Integer idPessoa) {
        final int OUTROS = 8;
        var pessoa = pessoaJuridicaRepository.findById(idPessoa).orElse(new PessoaJuridica());
        List<AreaContato> areas = areaContatoRepository.findByAtivoTrueAndExcluidoFalseOrderByPosicaoTela(pessoa.getUfSigla());
        areas.removeIf(ac -> ac.getId().equals(OUTROS));
        for (Contato contato : contatos) {
            areas.removeIf(a -> a.getId().equals(contato.getAreaContato().getId()));
        }
        return areas.isEmpty();
    }

    public Contato converterTOParaContato(ContatoTO to) {
        if (to == null) {
            return null;
        }

        if (to.getIdPessoa() == null) {
            throw new RegraNegocioException("Pessoa não informada.");
        }

        if (to.getIdAreaContato() == null) {
            throw new RegraNegocioException("Área de contato não informada.");
        }

        Pessoa pessoa = pessoaRepository.findById(to.getIdPessoa())
                .orElseThrow(() -> new RegraNegocioException("Pessoa não encontrada"));

        AreaContato areaContato =  areaContatoRepository.findById(to.getIdAreaContato())
                .orElseThrow(() -> new RegraNegocioException("Área de contato não encontrada"));


        Contato contato = new Contato();
        contato.setId(to.getId());

        contato.setPessoa(pessoa);
        contato.setAreaContato(areaContato);

        contato.setNomeResponsavel(to.getNomeResponsavel());
        contato.setTelefone(to.getTelefone());
        contato.setCelular(to.getCelular());
        contato.setEmail(to.getEmail());
        contato.setSite(to.getSite());
        contato.setCargo(to.getCargo());
        contato.setDataAtualizacao(LocalDateTime.now());
        contato.setUsuarioAtualizacao(keycloakService.getUsername());

        return contato;
    }

    public void validaContato(@Valid Contato contato) {
        Optional<AreaContato> a = areaContatoRepository.findById(contato.getAreaContato().getId());
        if (a.isEmpty()) {
            throw new RegraNegocioException(messages.get(AREA_CONTATO_NAO_ENCONTRADA)
                    + " para a pessoa jurídica:" + contato.getPessoa().getId(), HttpStatus.NOT_FOUND);
        }

        Optional<Pessoa> pf = pessoaRepository.findById(contato.getPessoa().getId());
        if (pf.isEmpty()) {
            throw new RegraNegocioException(messages.get(PESSOA_FISICA_NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
    }

    public boolean verificarTodosCamposPreenchidos(@Valid List<Contato> listaContato) {

        for (Contato contato : listaContato) {
            //Verificação de campos não preenchidos & obrigatórios (complexidade ciclomática alta)
            if(!ValidacaoCampos.validaCampoPreenchido(contato.getNomeResponsavel())
                    && !ValidacaoCampos.validaCampoPreenchido(contato.getEmail())
                    && !ValidacaoCampos.validaCampoPreenchido(contato.getTelefone())) {
                if (Boolean.TRUE.equals(contato.getAreaContato().getObrigatorio())) {
                    if (!ValidacaoCampos.validaCampoPreenchido(contato.getNomeResponsavel())
                            || !ValidacaoCampos.validaCampoPreenchido(contato.getEmail())
                            || !ValidacaoCampos.validaCampoPreenchido(contato.getTelefone())) {
                        return false;
                    }
                } else {
                    continue;
                }
            }

        	if(!ValidacaoCampos.validaCampoPreenchido(contato.getNomeResponsavel())){
        		throw new RegraNegocioException(messages.get(CONTATO_CAMPOS_NOME));
        	}

        	if(!ValidacaoCampos.validaCampoPreenchido(contato.getEmail()) && !ValidacaoCampos.validaCampoPreenchido(contato.getTelefone())) {
        		throw new RegraNegocioException(messages.get(CONTATO_CAMPOS_OBRIGATORIO), HttpStatus.NOT_FOUND);
            }

        	if(ValidacaoCampos.validaCampoPreenchido(contato.getEmail()) && !ValidacaoCampos.validarEmail(contato.getEmail())) {
        		throw new RegraNegocioException(messages.get(CONTATO_EMAIL_INVALIDO));
        	}

            if (Boolean.TRUE.equals(contato.getAreaContato().getUtilizaCargo() && !ValidacaoCampos.validaCampoPreenchido(contato.getCargo()))) {
            	throw new RegraNegocioException(messages.get(CONTATO_CARGO_INVALIDO));
            }
        }
        return true;
    }

    @Transactional(readOnly = true)
    public boolean validarContatos(Integer idPessoa) {
        try {
            return verificarTodosCamposPreenchidos(getContatosPessoa(idPessoa));
        } catch (RegraNegocioException e) {
            return false;
        }
    }

    @Transactional(readOnly = true)
    public List<Contato> getByUf(String uf) {
        return contatoRepository.buscaContatoPorUf(uf);
    }
}
