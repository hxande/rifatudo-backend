package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import br.coop.somoscooperativismo.registro.api.v1.desempenho.EstruturaPendenciaTO;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesTO;
import lombok.Data;

import java.util.List;

@Data
public class DadosContabilTributarioTO {

    String activeProfile;
    List<EstruturaIntegracaoTO> dadosEstrutura;
    CooperativaFatesTO dadosFates;
    List<EstruturaPendenciaTO> pendencias;
}
