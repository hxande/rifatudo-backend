package br.coop.somoscooperativismo.registro.api.v1.events.events;

import org.springframework.context.ApplicationEvent;

import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.entidade.CensoAnuarioPreenchimento;

public class CensoAnuarioPreenchimentoEvent extends ApplicationEvent {
	
	private static final long serialVersionUID = 1L;
	private CensoAnuarioPreenchimento censoAnuarioPreenchimento;

	public CensoAnuarioPreenchimentoEvent(Object source, CensoAnuarioPreenchimento censoAnuarioPreenchimento) {
		super(source);
		this.censoAnuarioPreenchimento = censoAnuarioPreenchimento;
	}
	
	public CensoAnuarioPreenchimento getCensoAnuarioPreenchimento() {
		return this.censoAnuarioPreenchimento;
	}
	
}
