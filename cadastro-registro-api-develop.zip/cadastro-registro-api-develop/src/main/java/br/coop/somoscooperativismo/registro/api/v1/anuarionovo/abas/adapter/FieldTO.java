package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
public class FieldTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String id;
    private String name;
    private Integer idQuadro;
    private Integer idQuadroAuxiliar;
    private Integer idParametro;
    private Integer idParametroAuxiliar;
    private String value;
    private String parametroIntegracao;

}
