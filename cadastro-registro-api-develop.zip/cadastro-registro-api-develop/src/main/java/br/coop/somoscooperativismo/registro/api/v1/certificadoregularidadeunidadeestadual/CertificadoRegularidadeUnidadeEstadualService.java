package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.log.LoggerInstance;
import br.coop.somoscooperativismo.ocbcommonsapi.log.LoggerTracker;
import br.coop.somoscooperativismo.ocbcommonsapi.log.LoggerTypes;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ExceptionUtil;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.certificado.CertificadoService;
import br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual.entidade.CertificadoRegularidadeUnidadeEstadual;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue.CooperativaObservacaoUeService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue.entidade.CooperativaObservacaoUe;
import br.coop.somoscooperativismo.registro.api.v1.endereco.EnderecoService;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.FileUploadClient;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.RepositorioArquivoTO;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.RepositorioTO;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.TipoEnderecoEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.RelatorioUtil;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.codec.binary.Base64;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service
public class CertificadoRegularidadeUnidadeEstadualService {
	
	private static final int TRINTA = 30;

	private static final Logger LOGGER = Logger.getLogger(CertificadoRegularidadeUnidadeEstadualService.class);
	
	private static final String FORMATO_DATA = "dd/MM/yyyy"; 
	
	public static final String CLASS_PATH_RELATORIO = "relatorio/CERTIFICADO_REGULARIDADE_UE/MyReports/CERTIFICADO_REGULARIDADE.jrxml";
	public static final String RELATORIO_CERTIFICADO_REGULARIDADE_REGISTRO_FUNDO = "relatorio/CERTIFICADO_REGULARIDADE_UE/modelo_certificado.png";
	public static final String MODULO_TEMPLATE_CERTIFICADO = "CERTIFICADO_REGULARIDADE_BACKGROUND_UNIDADE_ESTADUAL";
	
	@Autowired
	CertificadoRegularidadeUnidadeEstadualRepository certificadoRegularidadeUnidadeEstadualRepository;

	@Autowired
	CooperativaService cooperativaService;

	@Autowired
	CooperativaObservacaoUeService observacaoUeService;

	@Autowired
	EnderecoService enderecoService;

	@Autowired
	KeycloakService keycloakService;

	@Autowired
	private CertificadoService certificadoService;

	@Autowired
	private PessoaJuridicaService pessoaJuridicaService;



	@LoggerInstance(LoggerTypes.KIBANA)
	@Autowired
	private LoggerTracker loggerTracker;

	@Autowired
	@Qualifier("fileUploadClientLocal")
	private FileUploadClient fileUploadClient;

	@Autowired
	
	private ValidacaoCertificadoRegularidadeUnidadeEstadualService validacaoCertificadoRegularidadeUnidadeEstadualService;

	public List<CertificadoRegularidadeUnidadeEstadual> findAll() {
		return certificadoRegularidadeUnidadeEstadualRepository.findAll();
	}

	public List<CertificadoRegularidadeUnidadeEstadual> salvarTodas(
			List<CertificadoRegularidadeUnidadeEstadual> listaCertificadoRegularidadeUnidadeEstadual) {
		if (!listaCertificadoRegularidadeUnidadeEstadual.isEmpty()) {
			for (CertificadoRegularidadeUnidadeEstadual cert : listaCertificadoRegularidadeUnidadeEstadual) {
				try {
					certificadoRegularidadeUnidadeEstadualRepository.save(cert);
				} catch (Exception e) {
					throw new RegraNegocioException(e.getMessage(),e);
				}
			}
		}
		return certificadoRegularidadeUnidadeEstadualRepository.findAll();
	}

	public CertificadoRegularidadeUnidadeEstadual buscaPorUf(String uf) {
		Optional<CertificadoRegularidadeUnidadeEstadual> optCert = certificadoRegularidadeUnidadeEstadualRepository
				.findByUf(uf);
		if (optCert.isPresent()) {
			return optCert.get();
		}
		return null;
	}

	public byte[] imprimirCertificado(Integer idCooperativa) {
		validacaoCertificadoRegularidadeUnidadeEstadualService.podeEmitirCertificadoRegularidadeUnidadeEstadual();
		Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);

		if (cooperativa == null ||
				!isCooperativaRegular(cooperativa.getSituacaoCooperativa().getId())) {
			throw new RegraNegocioException("Cooperativa não está regular!");
		}

		PessoaJuridica pj = pessoaJuridicaService
				.buscarUnidadeResponsavel(cooperativa.getPessoaJuridica().getUfSigla());

		CooperativaObservacaoUe observacaoUe = observacaoUeService.getObservacaoAtivaIgnorarPermissoes(idCooperativa);

		Endereco endereco = enderecoService.obterEndereco(idCooperativa,
				TipoEnderecoEnum.ENDERECO_PRINCIPAL.getValue());
		CertificadoRegularidadeTO certificado = new CertificadoRegularidadeTO();
		Map<String, Object> map = new HashMap<>();
		certificado.setNumeroRegistro(cooperativa.getNumeroRegistroOCB());
		certificado.setRazaoSocial(cooperativa.getPessoaJuridica().getRazaoSocial());
		certificado.setCnpj(RemoveMascaraUtil.mascaraCNPJ(cooperativa.getPessoaJuridica().getCnpj()));
		certificado.setUf(cooperativa.getPessoaJuridica().getUfSigla());
		certificado.setEndereco(certificadoService.montaCidadeUF(endereco));
		certificado.setStatusRegularidade("regular");
		certificado.setObservacaoUe(observacaoUe != null ? observacaoUe.getObservacao() : null);
		if (pj != null) {
			certificado.setUnidadeResponsavel(pj.getRazaoSocial());
		}
		LocalDateTime now = LocalDateTime.now();
		now = now.plusDays(TRINTA);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(FORMATO_DATA);
		String dataValidade = now.format(formatter);
		// VER DE ONDE TIRAR ESSA DATA_VALIDADE
		certificado.setDataValidade(dataValidade);

		LocalDateTime localDateTimeDataHoraInformacao = LocalDateTime.now();
		DateTimeFormatter formatterData = DateTimeFormatter.ofPattern(FORMATO_DATA);
		DateTimeFormatter formatterHoras = DateTimeFormatter.ofPattern("HH:mm");
		String dataInformacao = localDateTimeDataHoraInformacao.format(formatterData);
		String dataHora = localDateTimeDataHoraInformacao.format(formatterHoras);

		InputStream inputStreamImagem = obterImagemFundoInputStream(cooperativa);
		certificado.setDataHoraInformacao(dataInformacao + ", às " + dataHora + " horas.");
		map.put("IMG_BACKGROUND", inputStreamImagem);
		RelatorioUtil relatorioUtil = new RelatorioUtil();
		List<CertificadoRegularidadeTO> listCertificadoRegularidadeTO = new ArrayList<>();
		listCertificadoRegularidadeTO.add(certificado);
		map.put("REPORT_LOCALE", new Locale("pt", "BR"));
		map.put("listCertificadoRegularidadeTO", listCertificadoRegularidadeTO);
		try {
			byte[] bytesRelatorio = relatorioUtil.gerarRelatorioPdf(listCertificadoRegularidadeTO, map,
					CLASS_PATH_RELATORIO);
			LOGGER.info(loggerTracker.generateLog());

			cooperativa = null;
			pj = null;
			endereco = null;
			now = null;
			formatter = null;
			certificado = null;
			formatterData = null;
			map = null;
			dataValidade = null;
			localDateTimeDataHoraInformacao = null;
			inputStreamImagem = null;
			formatterHoras = null;
			relatorioUtil = null;
			listCertificadoRegularidadeTO = null;

			return bytesRelatorio;
		} catch (JRException jre) {
			ExceptionUtil.explodirExcecao(jre);
		}

		return null;
	}

	private boolean isCooperativaRegular(Integer idSituacaoCooperativa) {
		return NovaSituacaoCooperativaEnum.REGULAR.getCodigo().equals(idSituacaoCooperativa);
	}

	public byte[] imprimirCertificadoPublico(Integer idCooperativa) {
		Cooperativa cooperativa = cooperativaService.getCooperativaSemVerificacao(idCooperativa);

		if (cooperativa == null || !isCooperativaRegular(cooperativa.getSituacaoCooperativa().getId())) {
			throw new RegraNegocioException("Cooperativa não está regular!");
		}

		PessoaJuridica pj = pessoaJuridicaService
				.buscarUnidadeResponsavel(cooperativa.getPessoaJuridica().getUfSigla());

		Endereco endereco = enderecoService.obterEndereco(idCooperativa,
				TipoEnderecoEnum.ENDERECO_PRINCIPAL.getValue());
		CertificadoRegularidadeTO certificado = new CertificadoRegularidadeTO();
		Map<String, Object> map = new HashMap<>();
		certificado.setNumeroRegistro(cooperativa.getNumeroRegistroOCB());
		certificado.setRazaoSocial(cooperativa.getPessoaJuridica().getRazaoSocial());
		certificado.setCnpj(RemoveMascaraUtil.mascaraCNPJ(cooperativa.getPessoaJuridica().getCnpj()));
		certificado.setUf(cooperativa.getPessoaJuridica().getUfSigla());
		certificado.setEndereco(certificadoService.montaCidadeUF(endereco));
		certificado.setStatusRegularidade("regular");
		if (pj != null) {
			certificado.setUnidadeResponsavel(pj.getRazaoSocial());
		}
		LocalDateTime now = LocalDateTime.now();
		now = now.plusDays(TRINTA);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(FORMATO_DATA);
		String dataValidade = now.format(formatter);
		// VER DE ONDE TIRAR ESSA DATA_VALIDADE
		certificado.setDataValidade(dataValidade);

		LocalDateTime localDateTimeDataHoraInformacao = LocalDateTime.now();
		DateTimeFormatter formatterData = DateTimeFormatter.ofPattern(FORMATO_DATA);
		DateTimeFormatter formatterHoras = DateTimeFormatter.ofPattern("HH:mm");
		String dataInformacao = localDateTimeDataHoraInformacao.format(formatterData);
		String dataHora = localDateTimeDataHoraInformacao.format(formatterHoras);

		InputStream inputStreamImagem = obterImagemFundoInputStream(cooperativa);
		certificado.setDataHoraInformacao(dataInformacao + ", às " + dataHora + " horas.");
		map.put("IMG_BACKGROUND", inputStreamImagem);
		RelatorioUtil relatorioUtil = new RelatorioUtil();
		List<CertificadoRegularidadeTO> listCertificadoRegularidadeTO = new ArrayList<>();
		listCertificadoRegularidadeTO.add(certificado);
		map.put("REPORT_LOCALE", new Locale("pt", "BR"));
		map.put("listCertificadoRegularidadeTO", listCertificadoRegularidadeTO);
		try {
			byte[] bytesRelatorio = relatorioUtil.gerarRelatorioPdf(listCertificadoRegularidadeTO, map,
					CLASS_PATH_RELATORIO);
			//LOGGER.info(loggerTracker.generateLog());

			cooperativa = null;
			pj = null;
			endereco = null;
			now = null;
			formatter = null;
			certificado = null;
			formatterData = null;
			map = null;
			dataValidade = null;
			localDateTimeDataHoraInformacao = null;
			inputStreamImagem = null;
			formatterHoras = null;
			relatorioUtil = null;
			listCertificadoRegularidadeTO = null;

			return bytesRelatorio;
		} catch (JRException jre) {
			ExceptionUtil.explodirExcecao(jre);
		}

		return null;
	}

	private InputStream obterImagemFundoInputStream(Cooperativa cooperativa) {
		String imagemCertificadoNaoEncontrada = "Imagem do certificado não encontrada.";
		try {
			String chaveRepositorio = obterChaveRepFundo(cooperativa);
			if (chaveRepositorio != null) {
				RepositorioTO repositorioTO = getRepositorioPublicoTO(chaveRepositorio);
				if (repositorioTO != null && repositorioTO.getArquivos() != null) {
					RepositorioArquivoTO arquivoTO = repositorioTO.getArquivos().stream().sorted().findFirst()
							.orElseThrow(() -> new RegraNegocioException(imagemCertificadoNaoEncontrada));
					String base64 = fileUploadClient.downloadBase64Publico(arquivoTO.getChaveArquivo());
					InputStream imagemInputStream =  new ByteArrayInputStream(Base64.decodeBase64(base64));

					chaveRepositorio = null;
					repositorioTO = null;
					arquivoTO = null;
					base64 = null;

					return imagemInputStream;
				}
			}
		} catch (Exception ex) {
			ExceptionUtil.explodirExcecao(ex);
			throw new RegraNegocioException(imagemCertificadoNaoEncontrada,ex);
		}
		throw new RegraNegocioException(imagemCertificadoNaoEncontrada);
	}


	private RepositorioTO getRepositorioPublicoTO(String chaveRepositorio) {
		RepositorioTO repositorioTO = null;
		try {
				repositorioTO = fileUploadClient.buscaRepositorioPublico(chaveRepositorio);
		} catch (Exception e) {
			LOGGER.info("Ocorreu um erro ao buscar  o repositório.\n Erro: " + e.getLocalizedMessage());
		}
		return repositorioTO;
	}

	private String obterChaveRepFundo(Cooperativa cooperativa) {
		if (cooperativa != null && cooperativa.getPessoaJuridica() != null) {
			CertificadoRegularidadeUnidadeEstadual certificadoRegularidadeUnidadeEstadual = buscaPorUf(
					cooperativa.getPessoaJuridica().getUfSigla());
			return certificadoRegularidadeUnidadeEstadual != null
					&& ValidacaoCampos.validaCampoPreenchido(certificadoRegularidadeUnidadeEstadual.getArquivo())
							? certificadoRegularidadeUnidadeEstadual.getArquivo()
							: null;
		}
		return null;
	}


	public boolean validaSePodeImprimir(Integer idCooperativa) {
		Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);
		return NovaSituacaoCooperativaEnum.REGULAR.name().equals(cooperativa.getSituacaoCooperativa().getNome());
	}

}
