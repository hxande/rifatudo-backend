package br.coop.somoscooperativismo.registro.api.v1.eventoemail;

import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import java.util.List;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.to.DisparoEmailTO;
import br.coop.somoscooperativismo.registro.api.v1.tipoprocessoemail.entidade.TipoProcessoEmail;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/disparoEmail")
@Tag(name = "DisparoEmail")
public class DisparoEmailRestController {

	private static final String DISPARO_EMAIL_ATUALIZADO = "eventoEmail.atualizado";
	final DisparoEmailService disparoEmailService;

	private final MessagesService messages;

	public DisparoEmailRestController(DisparoEmailService disparoEmailService, MessagesService messages) {
		this.disparoEmailService = disparoEmailService;
		this.messages = messages;
	}

	@Operation(summary = "Detalha um evento de disparo de email pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<DisparoEmail>> getDisparoEmail(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(disparoEmailService.getDisparoEmail(id)));
	}

	@PutMapping("/{id}")
	@Operation(summary = "Altera um evento de disparo de email")
	public ResponseEntity<ServiceResponse<DisparoEmail>> updateDisparoEmail(@PathVariable Integer id,
			@RequestBody @Valid DisparoEmail disparoEmail) {
		ServiceMessage message = new ServiceMessage(messages.get(DISPARO_EMAIL_ATUALIZADO));
		return new ResponseEntity<>(new ServiceResponse<>(disparoEmailService.updateDisparoEmail(disparoEmail), message), HttpStatus.OK);

	}

	@GetMapping("/filtro")
	@Operation(summary = "Lista as com filtro")
	public ServiceResponse<Page<DisparoEmailTO>> filtra(
			@RequestParam(required = false) String chaveEmail,
			@RequestParam(required = false) Boolean enviarEmail,
			@RequestParam(required = false) String textoDescricaoEmail,
			@RequestParam(required = false) String tipoPessoaEmail,
			@RequestParam(required = false) String tipoProcessoEmail,
			Pageable pageable) {
		return new ServiceResponse<>(disparoEmailService.filtra(tipoProcessoEmail,chaveEmail,textoDescricaoEmail,tipoPessoaEmail, enviarEmail, pageable));
	}
	
	@GetMapping("/listarTipoProcessoEmail")
	@Operation(summary = "Lista as com filtro")
	public ServiceResponse<List<TipoProcessoEmail>> getListTipoProcessoEmail(){
		return new ServiceResponse<>(disparoEmailService.getListTipoProcessoEmail());
	}
}
