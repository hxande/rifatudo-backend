package br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocialcooperado;

import org.springframework.data.jpa.repository.JpaRepository;

import br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocialcooperado.entidade.ControleParametroQuadroSocialCooperado;

public interface ControleParametroQuadroSocialCooperadoRepository extends JpaRepository<ControleParametroQuadroSocialCooperado, Integer> {

}

