package br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue;

import lombok.Getter;
import lombok.Setter;

/**
 * @author brunno.stefanini
 * @since 30 de novembro de 2020.
 */
@Getter
@Setter
public class CooperativaObservacaoTO {

	private Integer id;

	private Integer idCooperativa;

	private String observacao;

}
