package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name="VW_COOPERATIVAS_MATRIZES_REGISTRADAS")
public class CooperativaMatrizRegistradaTO {

	@Id
	@Column(name = "SQ_PESSOA")
	private Integer id;

	@Column(name = "TX_RAZAO_SOCIAL", nullable = false)
	@Size(max = 255)
	private String razaoSocial;

	@Column(name = "TX_NOME_FANTASIA")
	@Size(max = 255)
	private String nomeFantasia;

	@Column(name = "TX_SIGLA_ESTADO", columnDefinition = "char(2)")
	@Size(max = 2)
	private String ufSigla;

	@Column(name = "TX_CNPJ")
	@Size(max = 14)
	private String cnpj;

	@Column(name = "SQ_RAMO", columnDefinition = "tinyint(4)")
	private Integer idRamo;

	@Column(name = "TX_RAMO")
	private String nomeRamo;

	@Column(name = "SQ_SITUACAO_COOPERATIVA", columnDefinition = "tinyint(4)")
	private Integer idSituacaoCooperativa;
	@Column(name = "TX_NOVA_SITUACAO_COOPERATIVA")
	private String situacaoCooperativa;

}
