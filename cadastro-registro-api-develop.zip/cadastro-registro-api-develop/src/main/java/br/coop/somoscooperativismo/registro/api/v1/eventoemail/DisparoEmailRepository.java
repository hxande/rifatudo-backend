package br.coop.somoscooperativismo.registro.api.v1.eventoemail;

import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.coop.somoscooperativismo.registro.api.v1.eventoemail.to.DisparoEmailTO;

public interface DisparoEmailRepository extends JpaRepository<DisparoEmail, Integer> {

	@Query("select new br.coop.somoscooperativismo.registro.api.v1.eventoemail.to.DisparoEmailTO("
			+ " de.id ,de.chaveEmail, de.textoEmail, de.textoVariavelEmail, de.textoDescricaoEmail,de.destinatarioEmail,de.ativo,pe.id,pe.descricao) "
			+ " from DisparoEmail de " 
			+ " left join TipoProcessoEmail pe on pe.id = de.idTipoProcessoEmail "
			+ " where (:chaveEmail is null or de.chaveEmail = '' or de.chaveEmail like %:chaveEmail%) "
			+ " and (:enviarEmail is null or de.ativo = :enviarEmail) "
			+ " and (:textoDescricaoEmail is null or :textoDescricaoEmail = '' or de.textoDescricaoEmail like %:textoDescricaoEmail%) "
			+ " and (:tipoPessoalEmail is null or :tipoPessoalEmail = '' or de.destinatarioEmail like %:tipoPessoalEmail% )"
			+ " and (:tipoProcesso is null or :tipoProcesso = '' or pe.descricao like %:tipoProcesso%)")
	Page<DisparoEmailTO> filtra(String tipoProcesso, String chaveEmail, String textoDescricaoEmail,
			String tipoPessoalEmail, Boolean enviarEmail, Pageable pageable);

    @Query("Select d From DisparoEmail d where d.chaveEmail = :chaveEmail")
    Optional<DisparoEmail> findDisparoEmailByChaveEmail(String chaveEmail);

	Page<DisparoEmail> findByAtivoEqualsAndDestinatarioEmailLikeIgnoreCase(boolean ativo, String destinatarioEmail, Pageable pageable);
}
