package br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocial;

import org.springframework.data.jpa.repository.JpaRepository;

import br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocial.entidade.ControleParametroQuadroSocial;

public interface ControleParametroQuadroSocialRepository extends JpaRepository<ControleParametroQuadroSocial, Integer> {

}
