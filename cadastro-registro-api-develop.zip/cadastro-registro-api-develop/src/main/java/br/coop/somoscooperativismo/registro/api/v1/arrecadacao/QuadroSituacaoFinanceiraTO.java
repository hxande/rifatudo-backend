package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QuadroSituacaoFinanceiraTO {

    private Integer ano;
    private String statusEstadoFinanceiro;
    private Integer formasPagamento;
    private Boolean inNegociacao;
    private Boolean inBalanco;
    private Date ultimaAtualizacao;
}
