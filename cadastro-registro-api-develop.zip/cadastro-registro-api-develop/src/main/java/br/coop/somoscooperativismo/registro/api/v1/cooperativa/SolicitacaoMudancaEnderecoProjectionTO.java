package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import lombok.Data;

@Data
public class SolicitacaoMudancaEnderecoProjectionTO {
    private String ufDestino;
}
