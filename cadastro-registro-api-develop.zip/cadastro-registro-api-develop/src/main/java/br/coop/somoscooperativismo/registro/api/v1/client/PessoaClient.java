package br.coop.somoscooperativismo.registro.api.v1.client;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.pessoafisica.entidade.PessoaFisica;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Service
public class PessoaClient {
	
	public static final String DADOS_PF_INVALIDOS = "pessoafisica.dadosInvalidos";

	@Value("${pessoa_service_host:null}")
	String pessoaServiceHost;
	
	@Autowired
	RestTemplate keycloakRestTemplate;
	
	@Autowired
	MessagesService messages;
	
	
	public PessoaFisica buscaPorCpf(String cpf) {
		String url = pessoaServiceHost + "/api/v1/pessoa-fisica/buscaPorCpf/" + cpf;
		PessoaFisica pf = null;
		
		try {
			pf = keycloakRestTemplate.getForObject(url, PessoaFisica.class);
		} catch(HttpClientErrorException e) {
			throw new RegraNegocioException(e.getMessage(),e);
		}
		return pf;
	}
	
	public PessoaFisica createPessoaFisica(PessoaFisica pessoaFisica) {
		String url = pessoaServiceHost + "/api/v1/pessoa-fisica";
		PessoaFisica pf = null;
		pessoaFisica.setCpf(RemoveMascaraUtil.remove(pessoaFisica.getCpf()));
		
		try {
			pf = keycloakRestTemplate.postForObject(url, pessoaFisica, PessoaFisica.class);
		} catch(HttpClientErrorException e) {
			throw new RegraNegocioException(getMensagemErro(e),e);
		}
		
		return pf;
	}
	
	public PessoaFisica updatePessoaFisica(PessoaFisica pessoaFisica) {
		String url = pessoaServiceHost + "/api/v1/pessoa-fisica/" + pessoaFisica.getId();
		
		try {
			keycloakRestTemplate.put(url, pessoaFisica);
		} catch(HttpClientErrorException e) {
			throw new RegraNegocioException(getMensagemErro(e),e);
			
		}
		
		return pessoaFisica;
	}
	
	private String getMensagemErro(HttpClientErrorException e) {
		return e.getRawStatusCode() == 400 ? messages.get(DADOS_PF_INVALIDOS) : e.getMessage();
	}
}
