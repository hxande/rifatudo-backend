package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CooperativaRegistroTO {

    private CooperativaRegistro cooperativaRegistro;

    private boolean notificarPorEmail;

    private boolean jaNotificada;
}
