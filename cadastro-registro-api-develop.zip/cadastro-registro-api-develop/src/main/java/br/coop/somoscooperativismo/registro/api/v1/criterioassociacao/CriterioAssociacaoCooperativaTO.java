package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import lombok.Data;

@Data
public class CriterioAssociacaoCooperativaTO {
    private Integer id;
    private Integer sqCooperativa;
    private Integer sqCriterioAssociacao;
}
