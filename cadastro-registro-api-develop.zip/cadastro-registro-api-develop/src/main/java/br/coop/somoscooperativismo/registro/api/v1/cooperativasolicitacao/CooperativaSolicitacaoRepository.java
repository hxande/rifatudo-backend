package br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.entidade.CooperativaSolicitacao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.PathVariable;

public interface CooperativaSolicitacaoRepository extends JpaRepository<CooperativaSolicitacao, Integer>{
	
	@Query("select cs from CooperativaSolicitacao cs where cs.cooperativa.id = :id and cs.solicitacao.tipoSolicitacao.id = :tipoSolicitacao order by cs.id desc")
	List<CooperativaSolicitacao> buscaUltimaCooperativaSolicitacao(@PathVariable Integer id, @PathVariable Integer tipoSolicitacao, Pageable pageable);
}
