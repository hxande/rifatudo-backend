package br.coop.somoscooperativismo.registro.api.v1.endereco;

import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.EnderecoHistorico;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.entidade.TipoEndereco;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.TipoEnderecoRepository;

@Service
@Transactional
public class EnderecoService {

    public static final String NAO_ENCONTRADO = "endereco.naoEncontrado";
    public static final String DEPENDENCIA = "endereco.dependencia";
    public static final String CEP_INVALIDO = "endereco.cepInvalido";

    @Autowired
    private TipoEnderecoRepository tipoEnderecoRepository;

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Autowired
    private MessagesService messages;

    @Autowired
    private PessoaJuridicaService pessoaJuridicaService;


    public Page<Endereco> getEnderecos(Pageable pageable) {
        return enderecoRepository.findAll(pageable);
    }

    public Endereco save(Endereco endereco) {
        return enderecoRepository.save(endereco);
    }

    public Endereco buscarPorId(Integer id) {
        Optional<Endereco> endereco = enderecoRepository.findById(id);
        if (endereco.isPresent()) {
            return endereco.get();
        } else {
            throw new RegraNegocioException((messages.get(NAO_ENCONTRADO)), HttpStatus.NOT_FOUND);
        }
    }

    public void deletarEndereco(Integer id) {
        Optional<Endereco> endereco = enderecoRepository.findById(id);
        if (endereco.isPresent()) {
            enderecoRepository.deleteById(id);
        } else {
            throw new RegraNegocioException((messages.get(NAO_ENCONTRADO)), HttpStatus.NOT_FOUND);
        }
    }

    public Endereco updateEndereco(Endereco endereco) {
        Optional<Endereco> existingEndereco = enderecoRepository.findById(endereco.getId());
        if (existingEndereco.isPresent()) {
            return enderecoRepository.save(endereco);
        } else {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + endereco.getId(), HttpStatus.NOT_FOUND);
        }
    }

    public Page<Endereco> filtrarEnderecos(
            EnderecoFiltroTO enderecoFiltroTO,
            Pageable pageable) {
        return enderecoRepository.filtrarByLikeQuery(enderecoFiltroTO, pageable);
    }

    public List<Endereco> filtrarEnderecosSemPaginacao(EnderecoFiltroTO enderecoFiltroTO) {
        return enderecoRepository.filtrarSemPaginacao(enderecoFiltroTO);
    }

    public List<Endereco> obterEnderecosPessoa(Integer idPessoa) {

        List<Endereco> saida = new ArrayList<>();
        Endereco aux;

        PessoaJuridica pj = null;

        pj = pessoaJuridicaService.getPessoaJuridicaInterno(idPessoa);

        // Se pj for null a permissão foi negada, retorna lista vazia
        if (pj == null) {
            return saida;
        }

        // Obter endereços
        List<TipoEndereco> tiposEnderecoSituacao = tipoEnderecoRepository.filtrarPorSituacao(Boolean.TRUE);
        for (TipoEndereco te : tiposEnderecoSituacao) {
            aux = enderecoRepository.filtrarEnderecoPorTipo(idPessoa, te.getId());
            if (aux == null) {
                aux = new Endereco();
                aux.setTipoEndereco(te);
                aux.setPessoa(new PessoaJuridica());
                aux.getPessoa().setId(idPessoa);
            }
            saida.add(aux);
        }

        aux = null;

        return saida;
    }


    public boolean validaEndereco(Endereco endereco) {
        if (endereco != null) {
            return ValidacaoCampos.validaCampoPreenchido(endereco.getCep())
                    && ValidacaoCampos.validaCampoPreenchido(endereco.getNumero())
                    && ValidacaoCampos.validaCampoPreenchido(endereco.getDescricaoEndereco());
        }
        return false;
    }

    public boolean validaEnderecos(List<Endereco> enderecos) {
        boolean valido = true;
        if (enderecos != null && !enderecos.isEmpty()) {
            for (Endereco endereco : enderecos) {
                valido = validaEndereco(endereco);
            }
        }
        return valido;
    }

    public boolean validaEnderecosHistorico(List<EnderecoHistorico> enderecos) {
        boolean valido = true;
        if (enderecos != null && !enderecos.isEmpty()) {
            for (EnderecoHistorico endereco : enderecos) {
                valido = ValidacaoCampos.validaCampoPreenchido(endereco.getCep())
                        && ValidacaoCampos.validaCampoPreenchido(endereco.getNumero())
                        && ValidacaoCampos.validaCampoPreenchido(endereco.getEnderecoReferencia());
            }
        }
        return valido;
    }

    public Endereco obterEndereco(Integer idPessoa, Integer idTipoEndereco) {
        return enderecoRepository.filtrarEnderecoPorTipo(idPessoa, idTipoEndereco);
    }

    @Transactional(readOnly = true)
    public List<Endereco> getByUf(String uf) {
        return enderecoRepository.buscaPorUf(uf);
    }
}
