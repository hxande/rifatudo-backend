package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/comentarios")
public class CooperativaRegistroComentarioController {

    @Autowired
    private CooperativaRegistroComentarioService comentarioService;

    @GetMapping("/{cooperativaRegistroId}")
    public ResponseEntity<List<CooperativaRegistroComentario>> getComentariosByCooperativaRegistroId(@PathVariable Integer cooperativaRegistroId) {
        return ResponseEntity.ok(comentarioService.findAllByCooperativaRegistroId(cooperativaRegistroId));
    }

    @PostMapping
    public ResponseEntity<CooperativaRegistroComentario> createComentario(@RequestBody CooperativaRegistroComentarioTO comentarioTO) {
        CooperativaRegistroComentario comentario = comentarioService.saveComentario(comentarioTO);
        return ResponseEntity.ok(comentario);
    }
}
