package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;


import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacao;
import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacaoCooperativa;
import java.util.List;

import jakarta.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;

@Service
@Transactional
public class CriterioAssociacaoService {

    public static final String APENAS_USUARIO_DA_UNIDADE_NACIONAL_PODE_FAZER_ESTA_ACAO = "Apenas usuario da Unidade Nacional pode fazer esta ação.";
    public static final String O_RAMO_FOI_EXCLUIDO_OU_ESTA_INATIVO = "O Ramo foi excluído ou está inativo.";
    
    
    private final CriterioAssociacaoConverterService criterioAssociacaoConverterService;

    private final CriterioAssociacaoRespository criterioAssociacaoRepository;
    
    private final CriterioAssociacaoCooperativaRepository criterioAssociacaoCooperativaRepository;

    private final KeycloakService keycloakService;


    public CriterioAssociacaoService(CriterioAssociacaoConverterService criterioAssociacaoConverterService,
                                     CriterioAssociacaoRespository criterioAssociacaoRepository,
                                     CriterioAssociacaoCooperativaRepository criterioAssociacaoCooperativaRepository,
                                     KeycloakService keycloakService) {
		this.criterioAssociacaoConverterService = criterioAssociacaoConverterService;
		this.criterioAssociacaoRepository = criterioAssociacaoRepository;
		this.criterioAssociacaoCooperativaRepository = criterioAssociacaoCooperativaRepository;
		this.keycloakService = keycloakService;
	}

	public List<CriterioAssociacaoTO> salvarCriterioAssociacao(List<CriterioAssociacaoTO> listaCriterioAssociacaoDTO) {
        if(!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(APENAS_USUARIO_DA_UNIDADE_NACIONAL_PODE_FAZER_ESTA_ACAO);
        }
        
		if (listaCriterioAssociacaoDTO.parallelStream()
				.anyMatch(ca -> ca.getId() != null && (ca.getDescricao() == null || ca.getDescricao().isEmpty())))
        	throw new RegraNegocioException("Descrição do critério de associação é obrigatória");
		

		List<CriterioAssociacao> listaCriterioAssociacao = listaCriterioAssociacaoDTO.parallelStream()
				.filter(ca -> ca.getDescricao() != null && !ca.getDescricao().isEmpty())
				.map(ca -> criterioAssociacaoConverterService.toEntity(ca)).toList();
		
		listaCriterioAssociacao = criterioAssociacaoRepository.saveAll(listaCriterioAssociacao);
		
		// Deletar os criterios associacao por cooperativa
		List<Integer> listaCriterioAssociacaoId = listaCriterioAssociacao.parallelStream().filter(ca -> ca.getExcluido()).map(CriterioAssociacao::getId).toList();
		if(!listaCriterioAssociacaoId.isEmpty())
			criterioAssociacaoCooperativaRepository.deleteAllByCriterioAssociacaoIdIn(listaCriterioAssociacaoId);


		listaCriterioAssociacaoId = null;

		return criterioAssociacaoConverterService.toDTOList(listaCriterioAssociacao);
    }

    public List<CriterioAssociacaoTO> listarCriterioAssociacaoAtivosPorRamo(Integer sqRamo) {
        return criterioAssociacaoConverterService.toDTOList(criterioAssociacaoRepository.findByRamoIdAndAtivoTrue(sqRamo));
    }


	public List<CriterioAssociacaoTO> listarCriterioAssociacaoPorRamo(Integer sqRamo) {
		return criterioAssociacaoConverterService.toDTOList(criterioAssociacaoRepository.findByRamoIdAndExcluido(sqRamo,false));
	}
    
    public List<CriterioAssociacaoTO> listarCriterioAssociacaoPorRamoFiltro(Integer sqRamo) {
        return criterioAssociacaoConverterService.toDTOList(criterioAssociacaoRepository.findByRamoIdAndExcluidoAndAtivoTrue(sqRamo,false));
    }

	public void ativarDesativarCriterioAssociacaoRamo(CriterioAssociacaoRamoTO criterioAssociacaoRamoTO) {
		List<CriterioAssociacao> listaCriterioAssociacao = criterioAssociacaoRepository.findByRamoIdAndExcluido(criterioAssociacaoRamoTO.getId(),false);
		if(listaCriterioAssociacao.isEmpty()) {
			throw new RegraNegocioException("Sem critério(s) de associação cadastrado(s) para realizar esta operação.");
		}
		listaCriterioAssociacao.parallelStream().forEach(ca -> ca.setAtivo(criterioAssociacaoRamoTO.getAtivo()));
		criterioAssociacaoRepository.saveAll(listaCriterioAssociacao);
		
		ativaDesativaCriterioAssociacaoCooperativa(listaCriterioAssociacao,criterioAssociacaoRamoTO.getAtivo());
	}

	public Page<CriterioAssociacaoRamoTO> listarRamosCriterioAssociacao(Pageable pageable) {
		return criterioAssociacaoRepository.obterListaRamosCriterioAssociacao(pageable);
	}
	
	private void ativaDesativaCriterioAssociacaoCooperativa(List<CriterioAssociacao> listaCriterioAssociacao, Boolean ativa) {
		List<Integer> listaCriterioAssociacaoId = listaCriterioAssociacao.parallelStream().map(CriterioAssociacao::getId).toList();
		List<CriterioAssociacaoCooperativa> listaCriterioAssociacaoCooperativa = criterioAssociacaoCooperativaRepository.findByCriterioAssociacaoIdIn(listaCriterioAssociacaoId);
		listaCriterioAssociacaoCooperativa.parallelStream().forEach(cac -> cac.setAtivo(ativa));
		criterioAssociacaoCooperativaRepository.saveAll(listaCriterioAssociacaoCooperativa);

		listaCriterioAssociacaoId = null;
		
	}


}
