package br.coop.somoscooperativismo.registro.api.v1.complementoanuario;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.entidade.ComplementoAnuario;
import java.net.URI;

import jakarta.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/complementos-anuarios")
@Tag(name = "Informações Complementares do Anuário")
public class ComplementoAnuarioRestController {

    public static final String COMPLEMENTO_ANUARIO_CRIADO = "complementoAnuario.criado";
    public static final String COMPLEMENTO_ANUARIO_EXCLUIDO = "complementoAnuario.excluido";
    public static final String COMPLEMENTO_ANUARIO_ATUALIZADO = "complementoAnuario.atualizado";
    public static final String COMPLEMENTO_ANUARIO_NAO_CORRESPONDE = "complementoAnuario.naoCorresponde";
    public static final String COMPLEMENTO_ANUARIO_NAO_ENCONTRADO = "complementoAnuario.naoEncontrado";

    private final ComplementoAnuarioService complementoAnuarioService;
    private final MessagesService messages;

    @PostMapping
    @Operation(summary = "Cria os Dados Complementares para o Anuário")
    public ResponseEntity<ServiceResponse<ComplementoAnuarioTO>> create(@RequestBody @Valid ComplementoAnuarioTO complementoAnuarioTO) {
        ComplementoAnuarioTO complementoAnuarioTOCreated = this.complementoAnuarioService.create(complementoAnuarioTO);

        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(complementoAnuarioTOCreated.getId()).toUri();

        ServiceResponse<ComplementoAnuarioTO> serviceResponse =
                new ServiceResponse<>(complementoAnuarioTOCreated, new ServiceMessage(messages.get(COMPLEMENTO_ANUARIO_CRIADO)));

        return ResponseEntity.created(location).body(serviceResponse);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza os Dados Complementares do Anuário", description = "Deve ser informadao um Id válido")
    public ResponseEntity<ServiceResponse<ComplementoAnuarioTO>> update(
            @PathVariable Integer id,
            @RequestBody @Valid ComplementoAnuarioTO complementoAnuarioTO) {
        if (!complementoAnuarioTO.getId().equals(id)) {
            String message = String.format("URL ID: '%d' %s '%d'.", id,
                    messages.get(COMPLEMENTO_ANUARIO_NAO_CORRESPONDE), complementoAnuarioTO.getId());
            return ResponseEntity.badRequest().body(
                    new ServiceResponse<>(null, new ServiceMessage(MessageType.ERROR, message)));
        }

        ComplementoAnuarioTO complementoAnuarioTOUpdated = this.complementoAnuarioService.update(id, complementoAnuarioTO)
                .orElseThrow(() -> new RegraNegocioException(messages.get(COMPLEMENTO_ANUARIO_NAO_ENCONTRADO), HttpStatus.NOT_FOUND));

        ServiceMessage message = new ServiceMessage(messages.get(COMPLEMENTO_ANUARIO_ATUALIZADO));
        return ResponseEntity.ok(new ServiceResponse<>(complementoAnuarioTOUpdated, message));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retorna os Dados Complementares do Anuário por Id", description = "Deve ser informado um Id válido")
    public ResponseEntity<ServiceResponse<ComplementoAnuarioTO>> getById(@PathVariable Integer id) {
        ComplementoAnuarioTO complementoAnuarioTO = this.complementoAnuarioService.findById(id)
                .orElseThrow(() -> new RegraNegocioException(messages.get(COMPLEMENTO_ANUARIO_NAO_ENCONTRADO), HttpStatus.NOT_FOUND));
        return ResponseEntity.ok(new ServiceResponse<>(complementoAnuarioTO));
    }

    @GetMapping("/ue/{uf}")
    @Operation(summary = "Retorna os Dados Complementares do Anuário por UF", description = "Deve ser informada uma UF válida")
    public ResponseEntity<ServiceResponse<ComplementoAnuarioTO>> getByUf(@PathVariable String uf) {
        ComplementoAnuarioTO complementoAnuarioTO = this.complementoAnuarioService.findByUf(uf).orElseGet(() -> null);
        return ResponseEntity.ok(new ServiceResponse<>(complementoAnuarioTO));
    }

    @GetMapping("/ue/{uf}/exists")
    @Operation(summary = "Verifica se existe cadastro de Dados Complementares para a UF informada", description = "Deve ser informada uma UF válida")
    public ResponseEntity<ServiceResponse<Boolean>> existsByUf(@PathVariable String uf) {
        boolean exists = this.complementoAnuarioService.existsByUf(uf);
        return ResponseEntity.ok(new ServiceResponse<>(exists));
    }

    @GetMapping
    @Operation(summary = "Retorna os Dados Complementares do Anuário paginados e filtrados por Uf, Texto e/ou Url")
    public ResponseEntity<ServiceResponse<Page<ComplementoAnuarioTO>>> getAll(
            @RequestParam(required = false, defaultValue = "") String uf,
            @RequestParam(required = false, defaultValue = "") String texto,
            @RequestParam(required = false, defaultValue = "") String url,
            Pageable pageable) {

        Page<ComplementoAnuarioTO> page = this.complementoAnuarioService.findAll(uf, texto, url, pageable);

        return ResponseEntity.ok(new ServiceResponse<>(page));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Exclui o Dados Complementares do Anuário por Id", description = "Deve ser informado um Id válido")
    public ResponseEntity<ServiceResponse<Void>> delete(@PathVariable Integer id) {
        this.complementoAnuarioService.deleteById(id)
                .orElseThrow(() -> new RegraNegocioException(messages.get(COMPLEMENTO_ANUARIO_NAO_ENCONTRADO), HttpStatus.NOT_FOUND));
        ServiceMessage message = new ServiceMessage(messages.get(COMPLEMENTO_ANUARIO_EXCLUIDO));
        return ResponseEntity.ok(new ServiceResponse<>(message));
    }
}
