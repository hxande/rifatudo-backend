package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import java.util.List;

/**
 * Contrato de uma regra de governança (Strategy). Cada regra é independente,
 * recebe o {@link GovernancaContext} e devolve as violações encontradas
 * (lista vazia quando satisfeita). O {@link GovernancaRuleEngine} compõe todas
 * as regras (Composite) — ponto único de verdade consumido por Registro e
 * Manutenção (FR-002/FR-020, research D2).
 */
public interface GovernancaRule {

    /** Avalia a regra contra o contexto, acumulando violações tipadas. */
    List<ViolacaoGovernanca> avaliar(GovernancaContext contexto);

    /** Identificador legível para diagnóstico/auditoria (SC-002). */
    default String nome() {
        return getClass().getSimpleName();
    }
}
