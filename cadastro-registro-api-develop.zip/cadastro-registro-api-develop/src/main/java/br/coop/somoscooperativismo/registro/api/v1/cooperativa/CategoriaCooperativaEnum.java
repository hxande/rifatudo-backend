package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.util.HashSet;
import java.util.Set;

public enum CategoriaCooperativaEnum {

	
	SINGULAR(1, new Integer[]{1}), CENTRAL_FEDERACAO(2, new Integer[]{1, 2}), CONFEDEREACAO(3, new Integer[]{1, 2, 3});

	private Integer grau;
	private Set<Integer> permissaoVinculacao;

	public static CategoriaCooperativaEnum getValue(int value) {
		for (CategoriaCooperativaEnum e : CategoriaCooperativaEnum.values()) {
			if (e.getGrau() == value) {
				return e;
			}
		}
		return null;// not found
	}

	CategoriaCooperativaEnum(Integer grau, Integer[] permissaoVinculacao) {
		this.setGrau(grau);
		this.setPermissaoVinculacao(new HashSet<Integer>());
		
		for (int i = 0; i < permissaoVinculacao.length; i++) {
			this.getPermissaoVinculacao().add(permissaoVinculacao[i]);
		}
	}

	public Integer getGrau() {
		return grau;
	}

	private void setGrau(Integer grau) {
		this.grau = grau;
	}

	public Set<Integer> getPermissaoVinculacao() {
		return permissaoVinculacao;
	}

	private void setPermissaoVinculacao(Set<Integer> permissaoVinculacao) {
		this.permissaoVinculacao = permissaoVinculacao;
	}

}
