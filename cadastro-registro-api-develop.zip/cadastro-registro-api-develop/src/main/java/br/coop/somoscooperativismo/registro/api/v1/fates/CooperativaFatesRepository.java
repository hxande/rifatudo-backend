package br.coop.somoscooperativismo.registro.api.v1.fates;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CooperativaFatesRepository extends JpaRepository<CooperativaFates, Integer> {

    Optional<CooperativaFates> findByAnoAndCooperativaId(Integer ano, Integer cooperativaId);

    boolean existsByAnoAndCooperativaId(Integer ano, Integer cooperativaId);
}
