package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.entidade;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.entidade.ComplementoAnuario;
import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "COMPLEMENTO_ANUARIO_RAMO_URL")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class ComplementoAnuarioRamoUrl {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COMPLEMENTO_ANUARIO_RAMO_URL")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_COMPLEMENTO_ANUARIO", nullable = false)
    private ComplementoAnuario complementoAnuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_RAMO", columnDefinition = "tinyint(4)", updatable = false, nullable = false)
    private Ramo ramo;

    @Column(name = "TX_URL", columnDefinition = "varchar(2000)", nullable = false)
    private String url;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ComplementoAnuarioRamoUrl that = (ComplementoAnuarioRamoUrl) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
