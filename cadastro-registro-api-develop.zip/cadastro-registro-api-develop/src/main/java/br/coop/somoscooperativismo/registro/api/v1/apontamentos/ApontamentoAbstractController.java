package br.coop.somoscooperativismo.registro.api.v1.apontamentos;

import br.coop.somoscooperativismo.registro.api.v1.apontamentos.entidade.Apontamento;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaTO;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApontamentoAbstractController {
	
	
	@NonNull
    ModelMapper modelMapper;
	
    public ApontamentoAbstractController(ModelMapper modelMapper) {		
    	this.modelMapper = modelMapper;
	}
	
	

    protected final Converter<Apontamento, ApontamentoTO> converterEntidadeParaTO = context ->
            ApontamentoTO.builder()
                    .id(context.getSource().getId())
                    .cooperativa(CooperativaTO.builder()
                            .id(context.getSource().getCooperativa().getId())
                            .build())
                    .loginUsuario(context.getSource().getLoginUsuario())
                    .dataApontamento(context.getSource().getDataApontamento())
                    .apontamento(context.getSource().getApontamento())
                    .build();
}
