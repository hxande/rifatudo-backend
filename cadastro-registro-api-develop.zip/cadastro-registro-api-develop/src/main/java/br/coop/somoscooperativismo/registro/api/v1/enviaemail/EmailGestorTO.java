package br.coop.somoscooperativismo.registro.api.v1.enviaemail;

public class EmailGestorTO {

	private String uf;
	private String email;
	
	
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public EmailGestorTO(String uf, String email) {
		super();
		this.uf = uf;
		this.email = email;
	}
	
	
}
