package br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue.entidade.CooperativaObservacaoUe;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

/**
 * <b>CooperativaObservacaoUe</b><br>
 * Repositório/DAO para a entidade CooperativaObservacaoUe.
 * 
 * @author brunno.stefanini
 */
public interface CooperativaObservacaoUeRepository extends CrudRepository<CooperativaObservacaoUe, Integer> {

	/**
	 * Retorna a observação da unidade estadual que está ativa, ou seja, onde a data
	 * de exclusão é nula.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Observação ativa.
	 */
	@Query("FROM CooperativaObservacaoUe cou WHERE cou.idCooperativa = :idCooperativa AND cou.dataDeExclusao IS NULL")
	public CooperativaObservacaoUe getObservacaoAtiva(Integer idCooperativa);

	/**
	 * Retorna o histórico de observações da unidade estadual da cooperativa
	 * indicada.
	 * 
	 * @param idCooperativa ID da cooperativa.
	 * @return Lista de observações.
	 */
	@Query("FROM CooperativaObservacaoUe cou WHERE cou.idCooperativa = :idCooperativa ORDER BY cou.dataDeInclusao")
	public List<CooperativaObservacaoUe> getHistorico(Integer idCooperativa);

}
