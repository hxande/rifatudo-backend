package br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral;

import br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.to.ControleAtualizacaoCadastralTO;

public interface ControleAtualizacaoCadastralService {
	
	ControleAtualizacaoCadastralTO salvar(ControleAtualizacaoCadastralTO controleAtualizacaoCadastralTO);

	ControleAtualizacaoCadastralTO obterPorUf(String uf);
	
	ControleAtualizacaoCadastralTO obterControleNacional();
	
	ControleAtualizacaoCadastralTO buscarControleExistente(String uf);
	
	void desabilitarControleAtualizacaoCadastral(boolean ativa);
}
