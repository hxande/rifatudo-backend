package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas;

import lombok.Getter;

@Getter
public enum SituacaoAbaEnum {

	ALERTA("01","Aguardando verificação"),
	SALVO_PENDENCIAS("02","Salvo com pendências"),
	SALVO_SUCESSO("03","Salvo com sucesso"),
	AJUSTES("04","Salvo com sucesso");
	
	
	private SituacaoAbaEnum(String id, String valor) {
		this.id = id;
		this.valor = valor;
	}
	private String id;
	private String valor;
	
}
