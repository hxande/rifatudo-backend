package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl;

import java.util.Optional;

public interface ComplementoAnuarioRamoUrlService {
    Optional<Optional<ComplementoAnuarioRamoUrlTO>> deleteById(Integer complementoAnuarioId, Integer id);
}
