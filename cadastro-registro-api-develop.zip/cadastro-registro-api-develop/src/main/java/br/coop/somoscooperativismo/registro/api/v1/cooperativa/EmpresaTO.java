package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import jakarta.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmpresaTO {

    @NotNull(message = "CNPJ é obrigatório.")
    private String cnpj;

    private String tipoPessoaJuridica = "O";

}
