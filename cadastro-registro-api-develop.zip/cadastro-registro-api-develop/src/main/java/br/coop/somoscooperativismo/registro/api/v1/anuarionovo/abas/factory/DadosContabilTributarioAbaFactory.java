package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.ocbcommonsapi.web.JsonUtil;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.AbaCampoBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.SelectButtonOptionBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder.SelectButtonValueBuilder;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.*;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.InputTypeEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.desempenho.ParametroPendenciaTO;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesTO;
import br.coop.somoscooperativismo.registro.api.v1.fates.FinalidadeFatesEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.StringUtil;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class DadosContabilTributarioAbaFactory implements AbaFactory {

    private static final int INDICE_FINALIDADES_FATES = 2;

    private static final String MENSAGEM_CONTABIL = """
                <p>Os dados contábeis para construção do anuário da sua cooperativa serão considerados de acordo com as informações \
                lançadas no sistema <a href="%s" target="_blank" rel="noopener noreferrer">DESEMPENHO</a>, \
                e se aplicável, de órgãos reguladores. Eventuais informações faltantes estarão indicadas abaixo. Se houver pendências, \
                acesse o <a href="%s" target="_blank" rel="noopener noreferrer">DESEMPENHO</a> \
                para realizar os lançamentos e retorne ao Soucoop para finalizar a submissão do anuário.</p> \
            """;

    @Override
    public NomeAbaEnum getNomeAba() {
        return NomeAbaEnum.CONTABIL_TRIBUTARIO;
    }

    @Override
    public List<AbaDataInterface> build(Object dados) {
        var dadosRecebidos = (DadosContabilTributarioTO) dados;
        List<AbaDataInterface> lista = new ArrayList<>(buildDadosContabilTributario(dadosRecebidos));
        lista.add(buildDadosFates(dadosRecebidos.getDadosFates()));
        return lista;
    }

    public static List<AbaDataInterface> buildDadosContabilTributario(DadosContabilTributarioTO dadosContabilTributarioTO) {
        List<AbaDataInterface> abas = new ArrayList<>();

        if (dadosContabilTributarioTO == null || dadosContabilTributarioTO.getDadosEstrutura() == null) {
            return abas;
        }

        for (EstruturaIntegracaoTO estrutura : dadosContabilTributarioTO.getDadosEstrutura()) {
            if (estrutura == null || estrutura.getGrupos() == null) {
                continue;
            }

            var idAba = estrutura.getNome() != null ? StringUtil.toCamelCase(estrutura.getNome()) : "Outros" + estrutura.getId();
            AbaBuilder aba = new AbaBuilder(idAba, estrutura.getNome() != null ? StringUtil.toCamelCase(estrutura.getNome()) : "Outros", estrutura.getId(), null, estrutura.getNome())
                    .subTitle(null)
                    .info(null);

            List<AbaCampos> campos = new ArrayList<>();

            boolean existeCreditoAnoFalse = estrutura.getGrupos().stream()
                    .filter(grupo -> grupo.getParametros() != null)
                    .flatMap(grupo -> grupo.getParametros().stream())
                    .anyMatch(param -> !param.getPodePreencher());

            if (existeCreditoAnoFalse) {

                String pendencias = "";

                if (ValidacaoCampos.validaCampoPreenchido(dadosContabilTributarioTO.getPendencias())) {
                    String itensPendencia = dadosContabilTributarioTO
                            .getPendencias()
                            .stream()
                            .filter(estruturaIntegracao -> Integer.valueOf(1002).equals(estruturaIntegracao.getIdEstrutura()))
                            .flatMap(p -> p.getParametros().stream())
                            .map(ParametroPendenciaTO::getNome)
                            .map(nome -> "<li>" + nome + "</li>")
                            .collect(Collectors.joining());

                    if (!itensPendencia.isEmpty()) {
                        pendencias = "<p>Abaixo constam as contas obrigatórias não preenchidas:</p><ul>" + itensPendencia + "</ul>";
                    }
                }

                var linkDesempenho = getUrlDesempenho(dadosContabilTributarioTO.getActiveProfile());

                campos.add(AbaCampoBuilder.inputPendencia(pendencias).build());
                campos.add(
                        AbaCampoBuilder.html(
                                        StringUtil.toCamelCase(estrutura.getNome()) + estrutura.getId(),
                                        StringUtil.toCamelCase("mensagem" + estrutura.getNome()),
                                        estrutura.getId(),
                                        null,
                                        "")
                                .value(MENSAGEM_CONTABIL.formatted(linkDesempenho, linkDesempenho) + pendencias)
                                .parametroIntegracao(null)
                                .required(false)
                                .build()
                );

                campos.add(
                        AbaCampoBuilder.input(StringUtil.toCamelCase("placeholder1" + estrutura.getId()), StringUtil.toCamelCase("placeholder1" + estrutura.getId()), null, null, "")
                                .inputType(InputTypeEnum.TEXT.getType())
                                .value("")
                                .required(false)
                                .disabled(true)
                                .build()
                );

                campos.add(
                        AbaCampoBuilder.input(StringUtil.toCamelCase("placeholder2" + estrutura.getId()), StringUtil.toCamelCase("placeholder2" + estrutura.getId()), null, null, "")
                                .inputType(InputTypeEnum.TEXT.getType())
                                .value("")
                                .required(false)
                                .disabled(true)
                                .build()
                );
            } else {

                for (EstruturaGrupoTO grupo : estrutura.getGrupos()) {
                    campos.add(
                            AbaCampoBuilder.divisor(StringUtil.toCamelCase(grupo.getNome()) + grupo.getId(),
                                            grupo.getNome(),
                                            grupo.getId(),
                                            null, "", grupo.getNome())
                                    .value(null)
                                    .parametroIntegracao(null)
                                    .required(false)
                                    .build()
                    );

                    if (grupo.getParametros() != null) {
                        for (EstruturaIntegracaoParametroTO param : grupo.getParametros()) {
                            switch (param.getTipoUnidade()) {
                                case "NUMERO" -> campos.add(
                                        AbaCampoBuilder.input(StringUtil.toCamelCase(param.getNomeParametro()), StringUtil.toCamelCase(param.getNomeParametro()), param.getIdParametro(), null, param.getNomeParametro())
                                                .inputType(param.isValoresNegativos() ? InputTypeEnum.TEXT.getType() : InputTypeEnum.NUMBER.getType())
                                                .value(param.getValor())
                                                .required(param.isCampoObrigatorio())
                                                .isAceitaNegativo(param.isValoresNegativos())
                                                .mask((param.getQuantidadeCasasUnidade() != null && param.getQuantidadeCasasUnidade() > 0 ? (param.isValoresNegativos() ? "currencyNegative" : "currency") : null), param.getSiglaUnidade())
                                                .hasMask((param.getQuantidadeCasasUnidade() != null && param.getQuantidadeCasasUnidade() > 0))
                                                .subTitle(param.getDescricaoParametro())
                                                .parametroIntegracao(JsonUtil.toJson(param))
                                                .build()
                                );
                                case "TEXTO" -> campos.add(
                                        AbaCampoBuilder.input(StringUtil.toCamelCase(param.getNomeParametro()), StringUtil.toCamelCase(param.getNomeParametro()), param.getIdParametro(), null, param.getNomeParametro())
                                                .inputType(InputTypeEnum.TEXT.getType())
                                                .value(param.getValor())
                                                .required(param.isCampoObrigatorio())
                                                .parametroIntegracao(JsonUtil.toJson(param))
                                                .subTitle(param.getDescricaoParametro())
                                                .build()
                                );
                                case "BOOLEANO" -> campos.add(
                                        AbaCampoBuilder.selectButton("parametroSelectOption" + param.getIdParametro(), "parametroSelectOption", param.getIdParametro(), null, param.getNomeParametro())
                                                .value(new SelectButtonValueBuilder(
                                                        List.of(
                                                                new SelectButtonOptionBuilder("Sim", "1"),
                                                                new SelectButtonOptionBuilder("Não", "0")
                                                        ),
                                                        param.getValor()
                                                ))
                                                .required(param.isCampoObrigatorio())
                                                .parametroIntegracao(JsonUtil.toJson(param))
                                                .subTitle(param.getDescricaoParametro())
                                                .build()
                                );
                                default -> campos.add(
                                        AbaCampoBuilder.input(StringUtil.toCamelCase(param.getNomeParametro()), StringUtil.toCamelCase(param.getNomeParametro()), param.getIdParametro(), null, param.getNomeParametro())
                                                .inputType(InputTypeEnum.TEXT.getType())
                                                .value(param.getValor())
                                                .required(param.isCampoObrigatorio())
                                                .parametroIntegracao(JsonUtil.toJson(param))
                                                .subTitle(param.getDescricaoParametro())
                                                .build()
                                );
                            }
                        }
                    }
                }
            }
            aba.addCampos(campos);
            abas.add(aba.build());
        }

        return abas;
    }

    public static AbaDataInterface buildDadosFates(CooperativaFatesTO fates) {
        AbaBuilder aba = new AbaBuilder("destinacaoFates", NomeQuadroEnum.DESTINACAO_FATES.toString(), 1, null, "Destinação do FATES")
                .subTitle(null)
                .info(null);

        List<AbaCampos> campos = new ArrayList<>();

        campos.add(AbaCampoBuilder.input("valorFates", "valorFates", 1, null, "Qual foi o valor utilizado da conta de RATES/FATES em 2025?")
                .inputType(InputTypeEnum.NUMBER.getType())
                .value(fates.getValorFates() != null ? fates.getValorFates().toString() : null)
                .mask("currency", "R$")
                .build());

        List<SelectButtonOptionBuilder> listaFinalidades = Arrays.stream(FinalidadeFatesEnum.values())
                .map(f -> new SelectButtonOptionBuilder(f.getDescricao(), f.getCodigo().toString()))
                .collect(Collectors.toList());

        campos.add(
                AbaCampoBuilder.multCheckbox("finalidadesFates", "finalidadesFates", INDICE_FINALIDADES_FATES, null, "Indique as principais finalidades da destinação do valor utilizado da conta de RATES/FATES em 2025.", null)
                        .value(new SelectButtonValueBuilder(
                                listaFinalidades,
                                fates.getFinalidadesFates()
                                        .stream()
                                        .map(String::valueOf)
                                        .collect(Collectors.joining(", "))
                        ))
                        .build()
        );

        aba.addCampos(campos);
        return aba.build();
    }

    private static String getUrlDesempenho(String activeProfile) {
        return "https://desempenho-%s.apps.ocp.somos.coop.br".formatted(activeProfile);
    }

}
