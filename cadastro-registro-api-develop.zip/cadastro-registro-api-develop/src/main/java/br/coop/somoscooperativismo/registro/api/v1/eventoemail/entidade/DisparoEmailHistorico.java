package br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "EVENTO_EMAIL_HISTORICO")
public class DisparoEmailHistorico {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_EVENTO_EMAIL_HISTORICO")
    private Integer id;
    
    @ManyToOne
    @JoinColumn(name = "SQ_EVENTO_EMAIL")
    private DisparoEmail disparoEmail;
    
    @Column(name = "SQ_COOPERATIVA")
    private Integer idCooperativa;
    
    @Column(name = "IN_EMAIL_ENVIADO", columnDefinition = "bit")
    private Boolean enviado;
    
    @Column(name = "DT_ENVIO_EMAIL")
	private Date dataEnvio;
    
    @Column(name = "TX_DESTINATARIO")
    private String destinatario;

}
