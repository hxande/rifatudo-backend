package br.coop.somoscooperativismo.registro.api.v1.cooperativa.dao;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaPessoaDocumentoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaIntegracaoFormularioResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.util.sql.AbstractDAO;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;

import org.springframework.stereotype.Repository;

@Repository
public class CooperativaDAO extends AbstractDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public List<CooperativaIntegracaoFormularioResponseTO> fetchCooperativasParaIntegracaoFormulario(String uf) {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT ");
		sql.append(" C.SQ_COOPERATIVA AS id, ");
		sql.append(" CA.TX_CATEGORIA_COOPERATIVA AS categoria, ");
		sql.append(" C.DT_REGISTRO_OCB AS dataRegistroOcb, ");
		sql.append(" C.DT_ATUALIZACAO AS dataAtualizacao, ");
		sql.append(" C.IN_REGIDA_POR_LEI AS regidaPorLei, ");
		sql.append(" S.TX_NOVA_SITUACAO_COOPERATIVA AS situacao, ");
		sql.append(" PJ.TX_CNPJ AS cnpj, ");
		sql.append(" PJ.TX_RAZAO_SOCIAL AS razaoSocial, ");
		sql.append(" PJ.TX_NOME_FANTASIA AS nomeFantasia, ");
		sql.append(" PJ.DT_CONSTITUICAO_FUNDACAO AS dataConstituicaoFundacao, ");
		sql.append(" PJ.TX_NIRE AS nire, ");
		sql.append(" PJ.TX_TELEFONE_GERAL AS telefoneGeral, ");
		sql.append(" PJ.TX_EMAIL_GERAL AS emailGeral, ");
		sql.append(" PJ.TX_SITE AS site, ");
		sql.append(" R.TX_RAMO AS ramo, ");
		sql.append(" COALESCE((SELECT DISTINCT 'true' FROM COOPERATIVA_APROVACAO AP WHERE AP.SQ_COOPERATIVA=C.SQ_COOPERATIVA AND AP.NR_ANO = YEAR(GETDATE())), 'false') AS aprovada ");
		sql.append(" FROM COOPERATIVA C ");
		sql.append(" INNER JOIN PESSOA_JURIDICA PJ ON PJ.SQ_PESSOA = C.SQ_COOPERATIVA ");
		sql.append(" INNER JOIN CATEGORIA_COOPERATIVA CA ON CA.SQ_CATEGORIA_COOPERATIVA = C.SQ_CATEGORIA_COOPERATIVA ");
		sql.append(" INNER JOIN SITUACAO_COOPERATIVA S ON S.SQ_SITUACAO_COOPERATIVA = C.SQ_SITUACAO_COOPERATIVA ");
		sql.append(" INNER JOIN RAMO R ON R.SQ_RAMO = PJ.SQ_RAMO ");
		sql.append(" WHERE C.SQ_SITUACAO_COOPERATIVA NOT IN (3,4) ");
		if (uf != null && !uf.isEmpty()) {
			sql.append(" AND PJ.TX_UF_SIGLA LIKE :uf ");
		}
		sql.append(" ORDER BY C.SQ_COOPERATIVA ");

		Query query = em.createNativeQuery(sql.toString());
		if (uf != null && !uf.isEmpty()) query.setParameter("uf", uf);

		List<Object[]> resposta = query.getResultList();

		sql = null;
		query = null;

		return resposta.stream().map(CooperativaIntegracaoFormularioResponseTO::converter).toList();
	}

	public List<CooperativaPessoaDocumentoTO> emProcessoDeRegistroSemPaginacaComPessoaDocumento() {

		String select = "SELECT "
				+ " c.SQ_COOPERATIVA , "
				+ " pj.TX_CNPJ ,"
				+ " pj.TX_NOME_FANTASIA ,"
				+ " p.SQ_PESSOA_DOCUMENTO , "
				+ " p.NR_ANO ,"
				+ " p.SQ_DOCUMENTO "
				+ "FROM COOPERATIVA c "
				+ "	INNER JOIN PESSOA_JURIDICA pj on pj.SQ_PESSOA = c.SQ_COOPERATIVA "
				+ "	INNER JOIN  PESSOA_DOCUMENTO p on c.SQ_COOPERATIVA = p.SQ_PESSOA "
				+ "	WHERE c.SQ_SITUACAO_COOPERATIVA = 4 AND pj.IN_MATRIZ = 1 AND c.IN_ARQUIVADO = 0 ";
		StringBuilder sqlNativo = null;
		sqlNativo = new StringBuilder(select);

		Query query = entityManager.createNativeQuery(sqlNativo.toString(), Tuple.class);
		List<Tuple> resultList = query.getResultList();
		List<CooperativaPessoaDocumentoTO> result = new ArrayList<>();

		resultList.forEach(tuple -> result.add(new CooperativaPessoaDocumentoTO(
				tuple.get("SQ_COOPERATIVA", Integer.class).toString(),
				tuple.get("TX_CNPJ", String.class).toString(),
				tuple.get("TX_NOME_FANTASIA", String.class),
				tuple.get("SQ_PESSOA_DOCUMENTO", Integer.class).toString(),
				tuple.get("NR_ANO", Integer.class),
				tuple.get("SQ_DOCUMENTO", Integer.class)
		)));

		select = null;
		query = null;

		return result;
	}
}
