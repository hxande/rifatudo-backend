package br.coop.somoscooperativismo.registro.api.v1.fileupload;


import java.util.List;

public class ModuloTO {

	private Integer id;
	private String sistema;
	private String diretorio;
	private Integer quantidadeArquivos;
	private String chave;
	private Float tamanhoLimiteArquivo;
	private String extensoesPermitidas;
	private Boolean controlarHistorico;
	private Boolean podeApagarHistorico;
	private List<RepositorioTO> repositorios;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSistema() {
		return sistema;
	}

	public void setSistema(String sistema) {
		this.sistema = sistema;
	}

	public String getDiretorio() {
		return diretorio;
	}

	public void setDiretorio(String diretorio) {
		this.diretorio = diretorio;
	}

	public Integer getQuantidadeArquivos() {
		return quantidadeArquivos;
	}

	public void setQuantidadeArquivos(Integer quantidadeArquivos) {
		this.quantidadeArquivos = quantidadeArquivos;
	}

	public String getChave() {
		return chave;
	}

	public void setChave(String chave) {
		this.chave = chave;
	}

	public Float getTamanhoLimiteArquivo() {
		return tamanhoLimiteArquivo;
	}

	public void setTamanhoLimiteArquivo(Float tamanhoLimiteArquivo) {
		this.tamanhoLimiteArquivo = tamanhoLimiteArquivo;
	}

	public String getExtensoesPermitidas() {
		return extensoesPermitidas;
	}

	public void setExtensoesPermitidas(String extensoesPermitidas) {
		this.extensoesPermitidas = extensoesPermitidas;
	}

	public List<RepositorioTO> getRepositorios() {
		return repositorios;
	}

	public void setRepositorios(List<RepositorioTO> repositorios) {
		this.repositorios = repositorios;
	}

	public Boolean getControlarHistorico() {
		return controlarHistorico;
	}

	public void setControlarHistorico(Boolean controlarHistorico) {
		this.controlarHistorico = controlarHistorico;
	}

	public Boolean getPodeApagarHistorico() {
		return podeApagarHistorico;
	}

	public void setPodeApagarHistorico(Boolean podeApagarHistorico) {
		this.podeApagarHistorico = podeApagarHistorico;
	}

}
