package br.coop.somoscooperativismo.registro.api.v1.governanca.event;

import br.coop.somoscooperativismo.registro.api.v1.governanca.event.util.GovernancaEvent;
import br.coop.somoscooperativismo.registro.api.v1.governanca.event.util.GovernancaEventEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class GovernancaMandatoEncerradoDiretoriaGdhEvent implements GovernancaEvent {
    private GovernancaEventEnum eventType;
    private Integer SEQ_MANDATO;
    private List<GovernancaBeneficiarioDiretoriaGdhTO> beneficiarios;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private LocalDateTime dataEvento;

    @Override
    public GovernancaEventEnum eventType() {
        return eventType;
    }

    public GovernancaMandatoEncerradoDiretoriaGdhEvent(GovernancaEventEnum eventType, Integer SEQ_MANDATO) {
        this.beneficiarios = new ArrayList<>();
        this.SEQ_MANDATO = SEQ_MANDATO;
        this.eventType = eventType;
        this.dataEvento = LocalDateTime.now();
    }
}
