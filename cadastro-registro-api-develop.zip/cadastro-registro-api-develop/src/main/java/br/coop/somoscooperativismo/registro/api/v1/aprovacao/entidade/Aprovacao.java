package br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * @author jorge.stefanini
 */
@Entity
@Table(name = "COOPERATIVA_APROVACAO")
//@Audited - Sugerido pelo Ricardo 17-12-2024
@EntityListeners(RevisaoAuditoriaListener.class)
public class Aprovacao implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_APROVACAO")
    private Integer id;

    @Column(name = "NR_ANO", nullable=false)
    private Integer ano;

    @Column(name = "DT_ATUALIZACAO")
    private Date dataAtualizacao;
    
    @Column(name = "TX_USUARIO_APROVACAO")
    private String usuarioAprovacao;

    @ManyToOne
    @JoinColumn(name = "SQ_COOPERATIVA")
    @JsonIgnore
    private Cooperativa cooperativa;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public Date getDataAtualizacao() {
        return dataAtualizacao;
    }

    public void setDataAtualizacao(Date dataAtualizacao) {
        this.dataAtualizacao = dataAtualizacao;
    }

    public Cooperativa getCooperativa() {
        return cooperativa;
    }

    public void setCooperativa(Cooperativa cooperativa) {
        this.cooperativa = cooperativa;
    }

	public String getUsuarioAprovacao() {
		return usuarioAprovacao;
	}

	public void setUsuarioAprovacao(String usuarioAprovacao) {
		this.usuarioAprovacao = usuarioAprovacao;
	}
    
    
}
