package br.coop.somoscooperativismo.registro.api.v1.areacontato;

import br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade.AreaContato;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import jakarta.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class AreaContatoService {

    public static final String NAO_ENCONTRADO = "areaContato.naoEncontrado";

    private final AreaContatoRepository areaContatoRepository;
	private final MessagesService messages;
	
    public AreaContato getAreaContato(Integer id) {
        Optional<AreaContato> area = findAreaContato(id);
        return area.get();
    }

    private Optional<AreaContato> findAreaContato(Integer id) {
        Optional<AreaContato> area = areaContatoRepository.findById(id);

        if (area.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        return area;
    }

    public @Valid AreaContato createAreaContato(@Valid AreaContato areaContato) {
		areaContatoRepository.save(areaContato);
		reordenarPosicaoTela(areaContato);
        return areaContato;
    }

    public AreaContato updateAreaContato(@Valid AreaContato areaContato) {
        Optional<AreaContato> area = areaContatoRepository.findById(areaContato.getId());
        if (area.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        areaContatoRepository.save(areaContato);
        reordenarPosicaoTela(areaContato);

        area = null;

        return areaContato;
    }

    public void ativaAreaContato(Integer id, Boolean valor) {
        Optional<AreaContato> area = findAreaContato(id);

        AreaContato areaContato = area.get();
        areaContato.setAtivo(valor);
        areaContatoRepository.save(areaContato);

        area = null;
    }

    public void excluiAreaContato(Integer id) {
        Optional<AreaContato> area = findAreaContato(id);

        AreaContato areaContato = area.get();
        areaContato.setExcluido(true);
        areaContatoRepository.save(areaContato);

        area = null;
    }

	@Transactional(readOnly = true)
    public Page<AreaContato> filtra(String nome, Boolean ativo, Boolean utilizaCargo,
	                                Boolean obrigatorio, Integer posicaoTela, Pageable pageable) {
        return areaContatoRepository.filtra(nome, ativo, utilizaCargo, obrigatorio, posicaoTela, pageable);
    }

    @Transactional(readOnly = true)
    public Page<AreaContato> filtraEstadual(String nome, Boolean ativo, Boolean utilizaCargo, String uf, Pageable pageable) {
        return areaContatoRepository.filtraEstadual(nome, ativo, utilizaCargo, uf, pageable);
    }

    @Transactional(readOnly = true)
    public Page<AreaContato> filtraEstadualNacional(String nome, Boolean ativo, Boolean utilizaCargo,
                                                    Boolean obrigatorio, Integer posicaoTela, Pageable pageable) {
        return areaContatoRepository.filtraEstadualNacional(nome, ativo, utilizaCargo, obrigatorio, posicaoTela, pageable);
    }

	@Transactional(readOnly = true)
    public List<AreaContato> buscaListaAreaContatoAtivaOrderByPosicaoTela() {
        return areaContatoRepository.findByAtivoTrueAndExcluidoFalseOrderByPosicaoTela();
    }

    @Transactional(readOnly = true)
    public List<AreaContato> getAllAtivosNaoExcluidos() {
        return areaContatoRepository.findByAtivoTrueAndExcluidoFalseOrderByPosicaoTela();
    }

    @Transactional(readOnly = true)
    public List<AreaContato> buscaListaAreaContatoAtivaByUf(String uf) {
        return areaContatoRepository.findByAtivoTrueAndExcluidoFalseOrderByPosicaoTela(uf);
    }

    @Transactional(readOnly = true)
    public List<AreaContato> findAreaContatoOrderByPosicaoTela() {
        return areaContatoRepository.findAreaContatoOrderByPosicaoTela();
    }

    private void reordenarPosicaoTela(AreaContato areaContato) {
    	if(ValidacaoCampos.validaCampoPreenchido(areaContato.getPosicaoTela())) {
    		List<AreaContato> listAreaContato = areaContatoRepository
    				.findByUfAndAtivoAndPosicaoTelaGreaterThanEqualOrderByPosicaoTela(areaContato.getUf(), true,
    						areaContato.getPosicaoTela());
        	
        	AtomicInteger novaPosicaoTela = new AtomicInteger(areaContato.getPosicaoTela() + 1);
        	listAreaContato.stream().filter(ac -> !ac.getId().equals(areaContato.getId())).forEach(ac -> {
        		ac.setPosicaoTela(novaPosicaoTela.getAndIncrement());
        	});
        	areaContatoRepository.saveAll(listAreaContato);
    	}
	}
}
