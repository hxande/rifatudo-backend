package br.coop.somoscooperativismo.registro.api.v1.aprovacao;

import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/aprovacao")
@Tag(name = "Aprovacao")
public class AprovacaoRestController {
	
	public static final String APROVACAO_EXCLUIDA = "aprovacao.excluida";
	

	@Autowired
	private MessagesService messages;
	
	@Autowired
	private AprovacaoService aprovacaoService;
	
	@Operation(summary = "Detalha a última aprovação pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimaAtualizacaoCooperativa/{id}")
	public ResponseEntity<ServiceResponse<Aprovacao>> buscaUltimaAtualizacaoCooperativa(@PathVariable Integer id) {
	return new ResponseEntity<>(new ServiceResponse<>(aprovacaoService.getUltimaAtualizacao(id)),HttpStatus.OK);
	}
	
	@Operation(summary = "Busca a atualização da cooperativa no ano vigente", description = "Um ID válido deve ser informado")
	@GetMapping("buscaAtualizacaoCooperativaAnoVigente/{id}")
	public ResponseEntity<ServiceResponse<Aprovacao>> buscaAtualizacaoAnoVigentePorRamo(@PathVariable Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(aprovacaoService.getAprovacao(id)),HttpStatus.OK);
	}	
	
	@GetMapping("buscaAprovacaoCooperativaAnoAnterior/{id}")
	@Operation(summary = "Lista filtrado nao paginado")
	public ResponseEntity<ServiceResponse<Aprovacao>> buscaAprovacaoCooperativaAnoAnterior(@PathVariable Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(aprovacaoService.getAprovacaoCooperativaAnoAnterior(id)),HttpStatus.OK);
	}
	
	@Operation(summary = "Deleta a aprovação de uma cooperativa")
	@DeleteMapping("/excluirAprovacaoCooperativa/{idCooperativa}")
	public ResponseEntity<ServiceResponse<Void>> excluirAprovacaoCooperativa(@PathVariable Integer idCooperativa){
		aprovacaoService.excluirAprovacaoCooperativa(idCooperativa);
		ServiceMessage message = new ServiceMessage(messages.get(APROVACAO_EXCLUIDA));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
	
	@Operation(summary = "Busca a atualização da cooperativa no ano vigente", description = "Um ID válido deve ser informado")
	@GetMapping("buscaAtualizacaoCooperativaAnoVigentePorId/{id}")
	public ResponseEntity<ServiceResponse<Aprovacao>> buscaAtualizacaoAnoVigentePorIdCoop(@PathVariable Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(aprovacaoService.getAprovacaoSemException(id)),HttpStatus.OK);
	}

}
