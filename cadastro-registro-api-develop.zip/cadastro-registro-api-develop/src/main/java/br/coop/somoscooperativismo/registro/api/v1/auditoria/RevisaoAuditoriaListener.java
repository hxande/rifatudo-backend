package br.coop.somoscooperativismo.registro.api.v1.auditoria;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakServiceUtil;
import br.coop.somoscooperativismo.registro.api.v1.auditoria.entidade.RevisaoAuditoria;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.envers.RevisionListener;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

@Setter
@Getter
public class RevisaoAuditoriaListener implements RevisionListener {

	@Override
	public void newRevision(Object revisionEntity) {
		RevisaoAuditoria revisao = (RevisaoAuditoria) revisionEntity;
		revisao.setLoginUsuario(getCurrentUser());
	}

	private String getCurrentUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return authentication == null ? "sistema" : KeycloakServiceUtil.getStaticUsername();
	}

}
