
package br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento;

import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade.Faturamento;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.entidade.PeriodoAtualizacao;
import br.coop.somoscooperativismo.registro.api.v1.periodoatualizacao.PeriodoAtualizacaoService;

@Service
public class FaturamentoService {

    private static final String NAO_ENCONTRADO = "ciclo.naoEncontrado";

    @Autowired
    @Lazy
    private CooperativaService cooperativaService;

    @Autowired
    private PeriodoAtualizacaoService periodoService;

    @Autowired
    private FaturamentoRepository faturamentoRepository;

    @Autowired
    private MessagesService messages;

    @Autowired
    private PeriodoAtualizacaoService periodoAtualizacaoService;



    public void salvar(Faturamento faturamento) {
        faturamentoRepository.save(faturamento);
    }

    public List<Faturamento> obterFaturamentos(@Valid Cooperativa cooperativa) {
        return faturamentoRepository.obterFaturamentos(cooperativa);
    }
    
    public List<Faturamento> obterFaturamentosPorAprovacao(Integer idCooperativa, Integer idAprovacao) {
        return faturamentoRepository.obterFaturamentosPorCooperativaEAprovacao(idCooperativa, idAprovacao);
    }

    public Faturamento obterFaturamento(@Valid Cooperativa cooperativa, Integer ano) {
        Faturamento faturamento = faturamentoRepository.obterFaturamento(cooperativa, ano);
        if (faturamento == null) {
            return new Faturamento();
        }
        return faturamento;
    }

    public Faturamento update(Faturamento faturamento) {
        Optional<Faturamento> opFaturamento = faturamentoRepository.findById(faturamento.getId());
        if (opFaturamento.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }

        opFaturamento = null;

        return faturamentoRepository.save(faturamento);
    }
    
    public List<Faturamento> updateListaFaturamentos(List<Faturamento> listaFaturamentos){
		return faturamentoRepository.saveAll(listaFaturamentos);
	}

    public List<Faturamento> getFaturamentosPorCooperativaNoCiclo(Integer idCooperativa) {
        Faturamento fAnterior = null;
        Integer anoRegistro = null;
        Cooperativa c = cooperativaService.getCooperativa(idCooperativa);

        if (c.getDataRegistro() != null) {
            Calendar dataRegistro = Calendar.getInstance();
            dataRegistro.setTime(c.getDataRegistro());
            anoRegistro = dataRegistro.get(Calendar.YEAR);
        }

        Integer anoCiclo = periodoService.obterAno(c.getPessoaJuridica().getRamo());

        List<Faturamento> faturamentos = new ArrayList<>();

        if (anoRegistro != null && anoRegistro < anoCiclo) {
            fAnterior = getFaturamento(idCooperativa, anoCiclo - 1);
        }

        Integer anoInicialReferencia = periodoAtualizacaoService.obterAnoInicialReferencia(c);

        if (fAnterior != null) {
            faturamentos.add(fAnterior);

        } else if (anoInicialReferencia != null && (anoInicialReferencia < anoCiclo) && (anoRegistro != null && anoRegistro < anoCiclo)) {
            fAnterior = new Faturamento();
            fAnterior.setCooperativa(c);
            fAnterior.setAno(anoCiclo - 1);
            faturamentos.add(fAnterior);
        }

        c = null;
        anoCiclo = null;
        anoInicialReferencia = null;

        return faturamentos.stream().sorted(Comparator.comparingInt(Faturamento::getAno))
                .collect(Collectors.toList());
    }

    public List<Faturamento> getFaturamentoHistorico(Integer idCooperativa) {
        Cooperativa c = cooperativaService.findById(idCooperativa);
        List<Faturamento> saida = new ArrayList<>();
        Integer anoCiclo = periodoService.obterAno(c.getPessoaJuridica().getRamo());

        List<PeriodoAtualizacao> periodos =
                periodoService.buscaPeriodoAtualizacaoPorRamo(c.getPessoaJuridica().getRamo().getId());

        List<Integer> anosPeriodos = periodos.stream().map(PeriodoAtualizacao::getAno).collect(Collectors.toList());

        anosPeriodos = anosPeriodos.stream().filter(ano -> ano < anoCiclo).collect(Collectors.toList());

        for(Integer ano : anosPeriodos) {
            if(ano < (anoCiclo -1)) {
                Optional<Faturamento> faturamento = faturamentoRepository.buscaPorAno(idCooperativa, ano);
                if (faturamento.isPresent()) {
                    saida.add(faturamento.get());
                } else {
                    Faturamento fat = new Faturamento();
                    fat.setCooperativa(c);
                    fat.setAno(ano);
                    saida.add(fat);
                }
            }
        }

        c = null;

        return saida.stream().sorted(Comparator.comparingInt(Faturamento::getAno))
                .collect(Collectors.toList());
    }

    public Faturamento getFaturamento(Integer idCooperativa, Integer ano) {
        Optional<Faturamento> op = faturamentoRepository.buscaPorAno(idCooperativa, ano);
        return op.isPresent() ? op.get() : null;
    }

    public List<Faturamento> salvarHistoricoFaturamento(Integer idCooperativa, List<Faturamento> faturamentos) {
        Cooperativa c = cooperativaService.findById(idCooperativa);

        Integer anoCiclo = periodoService.obterAno(c.getPessoaJuridica().getRamo());

        for (Faturamento fat : faturamentos) {
            if (anoCiclo != null && fat.getAno() >= anoCiclo) {
                throw new RegraNegocioException("Faturamento não pertence ao histórico");
            }
            faturamentoRepository.save(fat);
        }

        c = null;
        anoCiclo = null;

        return faturamentos;
    }

    @Transactional(readOnly = true)
    public List<Faturamento> getByCooperativaId(Integer idCooperativa) {
        return faturamentoRepository.obterFaturamentosPorCooperativaId(idCooperativa);
    }

}
