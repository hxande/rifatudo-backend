package br.coop.somoscooperativismo.registro.api.v1.certificado;

/**
 * @author jorge.stefanini
 */
public class CertificadoTO {

    private String razaoSocial;
    private String enderecoCorrespondencia;
    private String cnpj;
    private String dataRegistro;
    private String numeroRegistro;
    private String dataAssinaturaDigital;
    private String processo;
    private String codigoAtenticidade;
    private String templateCertificado;

    private String situacaoCooperativa;

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getEnderecoCorrespondencia() {
        return enderecoCorrespondencia;
    }

    public void setEnderecoCorrespondencia(String enderecoCorrespondencia) {
        this.enderecoCorrespondencia = enderecoCorrespondencia;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(String dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public String getNumeroRegistro() {
        return numeroRegistro;
    }

    public void setNumeroRegistro(String numeroRegistro) {
        this.numeroRegistro = numeroRegistro;
    }

    public String getDataAssinaturaDigital() {
        return dataAssinaturaDigital;
    }

    public void setDataAssinaturaDigital(String dataAssinaturaDigital) {
        this.dataAssinaturaDigital = dataAssinaturaDigital;
    }

    public String getProcesso() {
        return processo;
    }

    public void setProcesso(String processo) {
        this.processo = processo;
    }

    public String getCodigoAtenticidade() {
        return codigoAtenticidade;
    }

    public void setCodigoAtenticidade(String codigoAtenticidade) {
        this.codigoAtenticidade = codigoAtenticidade;
    }

    public String getTemplateCertificado() {
        return templateCertificado;
    }

    public void setTemplateCertificado(String templateCertificado) {
        this.templateCertificado = templateCertificado;
    }

    public String getSituacaoCooperativa() {
        return situacaoCooperativa;
    }

    public void setSituacaoCooperativa(String situacaoCooperativa) {
        this.situacaoCooperativa = situacaoCooperativa;
    }
}
