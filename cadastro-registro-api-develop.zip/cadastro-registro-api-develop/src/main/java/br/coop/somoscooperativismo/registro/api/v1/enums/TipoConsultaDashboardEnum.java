package br.coop.somoscooperativismo.registro.api.v1.enums;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum TipoConsultaDashboardEnum {

    ATUALIZACAO_APROVADA_ANO(1, "Atualizações Aprovadas no Ano", "EXEC [DBO].[SP_PAINEL_SOUCOOP_ATUALIZACAO_APROVADA_ANO] "),
    CONSELHO_ADMINISTRACAO (2, "Conselho de Administração", "EXEC [DBO].[SP_PAINEL_SOUCOOP_CONSELHO_ADMINISTRACAO] "),
    CONSELHO_FISCAL(3, "Conselho Fiscal", "EXEC [DBO].[SP_PAINEL_SOUCOOP_CONSELHO_FISCAL] "),
    FATURAMENTO_RAMO(4, "Faturamento por Ramo", "EXEC [DBO].[SP_PAINEL_SOUCOOP_FATURAMENTO_RAMO] "),
    PROCESSO_REGISTRO (5, "Processo de Registro", "EXEC [DBO].[SP_PAINEL_SOUCOOP_PROCESSO_REGISTRO] "),
    QUADRO_SOCIAL_COOPERADOS (6, "Quadro Social - Cooperados", "EXEC [DBO].[SP_PAINEL_SOUCOOP_QUADRO_SOCIAL_COOPERADOS] "),
    QUADRO_SOCIAL_EMPREGADOS (7, "Quadro Social - Empregados", "EXEC [DBO].[SP_PAINEL_SOUCOOP_QUADRO_SOCIAL_EMPREGADOS] "),
    REGISTRADAS_RAMO (8, "Registradas por Ramo", "EXEC [DBO].[SP_PAINEL_SOUCOOP_REGISTRADAS_RAMO] "),
    SITUACAO_CICLO (9, "", "EXEC [DBO].[SP_PAINEL_SOUCOOP_SITUACAO_CICLO] "),
    SITUACAO_REGISTRADAS (10, "Situação das Cooperativas Registradas", "EXEC [DBO].[SP_PAINEL_SOUCOOP_SITUACAO_REGISTRADAS] "),
    TAXA_ATUALIZACAO (11, "Taxa de Atualização no Ano", "EXEC [DBO].[SP_PAINEL_SOUCOOP_TAXA_ATUALIZACAO] ")
    ;

    private Integer codigo;
    private String descricao;
    private String proc;

    public static TipoConsultaDashboardEnum getByEnumCodigo(Integer codigo) {
        for(TipoConsultaDashboardEnum  tipo : TipoConsultaDashboardEnum.values()) {
            if(tipo.getCodigo().equals(codigo)) {
                return tipo;
            }
        }
        throw new RegraNegocioException("Código inválido");
    }

}
