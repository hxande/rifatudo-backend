package br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual.entidade.CertificadoUnidadeEstadual;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/certificadoUnidadeEstadual")
@Tag(name = "CertificadoUnidadeEstadual")
public class CertificadoUnidadeEstadualRestController {

	public static final String LISTA_BACKGROUND_CERTIFICADO_NACIONAL_SALVO = "Certificados salvos com sucesso!";

	@Autowired
	private CertificadoUnidadeEstadualService certificadoUnidadeEstadualService;
	
	@Autowired
	MessagesService messages;
	
	
	@GetMapping()
	@Operation(summary="Lista Certificados das Unidades Estaduais", description="")
	public ResponseEntity<ServiceResponse<List<CertificadoUnidadeEstadual>>> listaCertificadoUnidadeEstadual() {
		return new ResponseEntity<>(new ServiceResponse<>(certificadoUnidadeEstadualService.findAll()),  HttpStatus.OK);
	}
	
	
	@PutMapping
	@Operation(summary = "Salva as alterações no certificado da unidade estadual")
	public ResponseEntity<ServiceResponse<List<CertificadoUnidadeEstadual>>> criaAcessoCooperativa(@RequestBody List<CertificadoUnidadeEstadual> listaCertificadoUnidadeEstadual) {
		certificadoUnidadeEstadualService.salvarTodas(listaCertificadoUnidadeEstadual);
		ServiceMessage message = new ServiceMessage(messages.get(LISTA_BACKGROUND_CERTIFICADO_NACIONAL_SALVO));		
		return ResponseEntity.ok(new ServiceResponse<>(listaCertificadoUnidadeEstadual, message));
	}
}
