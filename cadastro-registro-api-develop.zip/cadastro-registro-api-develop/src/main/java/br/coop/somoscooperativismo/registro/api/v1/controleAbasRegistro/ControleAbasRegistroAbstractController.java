package br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro;

import br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro.entidade.ControleAbasRegistro;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaTO;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class ControleAbasRegistroAbstractController {

    @NonNull
    ModelMapper modelMapper;

    protected Converter<ControleAbasRegistro, ControleAbasRegistroTO> converterEntidadeParaTO = context ->
            ControleAbasRegistroTO.builder()
                    .id(context.getSource().getId())
                    .cooperativa(CooperativaTO.builder()
                            .id(context.getSource().getCooperativa().getId())
                            .build())
                    .dataEnvio(context.getSource().getDataEnvio())
                    .aba(context.getSource().getAba())
                    .enviada(context.getSource().getEnviada())
                    .build();
}
