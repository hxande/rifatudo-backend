package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class NaturezaJuridicaImportacaoTO {
    private Integer id;
    private String nome;
    private Boolean naturezaJuridicaCooperativa;
    private Boolean registroAtivo;
}
