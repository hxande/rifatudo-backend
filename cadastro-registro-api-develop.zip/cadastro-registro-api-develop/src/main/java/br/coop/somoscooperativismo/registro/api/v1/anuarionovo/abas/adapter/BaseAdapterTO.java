package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BaseAdapterTO {

    private Integer idQuadro;
    private Integer idQuadroAuxiliar;
    private Integer idParametro;
    private Integer idParametroAuxiliar;
    private String parametroIntegracao;

}
