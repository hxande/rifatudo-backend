package br.coop.somoscooperativismo.registro.api.v1.categoria.entidade;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;

@Entity
@Table(name = "CATEGORIA_COOPERATIVA")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Categoria implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SQ_CATEGORIA_COOPERATIVA", columnDefinition="tinyint(4)")
	private Integer id;

	@Column(name="TX_CATEGORIA_COOPERATIVA", nullable=false)
	@NotBlank
	@Size(max = 255)
	private String descricao;
	
	@Column(name="NR_MINIMO_COOPERATIVAS")
	private Integer minimoCooperativa;
	
	@Column(name="IN_REGISTRO_ATIVO", nullable=false)
	private Boolean ativo;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Boolean getAtivo() {
		return ativo;
	}

	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

	public Integer getMinimoCooperativa() {
		return minimoCooperativa;
	}

	public void setMinimoCooperativa(Integer minimoCooperativa) {
		this.minimoCooperativa = minimoCooperativa;
	}
	
}
