package br.coop.somoscooperativismo.registro.api.v1.enums;

public enum ClientEnum {

	CADASTRO_REGISTRO("cadastro-registro"),
	GERENCIA_USUARIO("gerencia-usuario"),
	DESENVOLVIMENTO_HUMANO("desenvolvimento-humano"),
	GESTAO_INSTRUTOR("gestao-instrutor"),
	COOPERATIVAS_IMPORTACAO("cooperativas-importacao");
	
	private String clientId;
	
	ClientEnum(String clientId) {
		this.clientId = clientId;
	}
	
	public String getClientId() {
		return clientId;
	}
}
