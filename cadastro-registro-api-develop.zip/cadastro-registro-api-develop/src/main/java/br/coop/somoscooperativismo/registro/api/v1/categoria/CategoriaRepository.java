package br.coop.somoscooperativismo.registro.api.v1.categoria;

import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
	@Query("Select categoria from Categoria categoria where categoria.ativo = :ativo")
	List<Categoria> listAtivos(@Param("ativo") Boolean ativo);

	@Query("select c from Categoria c where c.descricao like %:descricao% "
			+ " and (:minimoCooperativa is null or c.minimoCooperativa = :minimoCooperativa) and (:ativo is null or c.ativo = :ativo)")
	Page<Categoria> filtra(String descricao, Integer minimoCooperativa, Boolean ativo, Pageable pageable);
}
 