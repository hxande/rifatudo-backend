package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import lombok.Setter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CooperativaPessoaDocumentoTO {
	private String sqCooperativa;
	private String sqCnpj;
	private String txNomeFantasia;
	private String sqPessoaDocumento;
	private Integer nrAno;
	private Integer sqDocumento;

}