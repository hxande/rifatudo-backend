package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnderecoImportacaoTO {
    private Integer id;
    private Integer idEstado;
    private Integer idMunicipio;
    private TipoEnderecoTO tipoEndereco;
    private PessoaImportacaoTO pessoa;
    private String cep;
    private String bairro;
    private String enderecoReferencia;
    private String numero;
    private String complemento;
    private String descricaoEndereco;
    private Boolean correspondenciaDiferente;

}
