package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CargoImportacaoTO {
    private Integer id;
    private Boolean ativo;
    private String nome;
}
