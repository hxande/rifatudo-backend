package br.coop.somoscooperativismo.registro.api.v1.events.publisher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.registro.api.v1.events.events.SolicitacaoMudancaEnderecoEvent;

@Component
public class SolicitacaoMudancaEnderecoPublisher implements ApplicationEventPublisherAware {

	@Autowired
    private ApplicationEventPublisher publisher;
	

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
		this.publisher = publisher;
		
	}
	
	public void publish(SolicitacaoMudancaEnderecoEvent event) {
        this.publisher.publishEvent(event);
    }


}
