package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public enum AbaEnum {

	ABA_DADOS_GERAIS("ABA_DADOS_GERAIS"),
	ABA_GOVERNANCA("ABA_GOVERNANCA"),
	ABA_SEGUIMENTOS_FILIAIS("ABA_SEGUIMENTOS_FILIAIS"),
	ABA_CONTATOS("ABA_CONTATOS"),
	ABA_DOCUMENTOS("ABA_DOCUMENTOS"),
	ABA_SUBMETER("ABA_SUBMETER"),;

	private String id;

	public static AbaEnum getValue(String value) {
		for (AbaEnum e : AbaEnum.values()) {
			if (Objects.equals(e.getId(), value)) {
				return e;
			}
		}
		return null;// not found
	}
	
}
