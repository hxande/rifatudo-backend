package br.coop.somoscooperativismo.registro.api.v1.complementoanuario;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.ComplementoAnuarioRamoUrlTO;
import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplementoAnuarioTO {

    private Integer id;

    @NotEmpty(message = "Campo UF é obrigatório!")
    @Size(min = 2, max = 2, message = "Campo UF deve possuir 2 caracteres!")
    private String uf;

    @NotEmpty(message = "Campo Texto é obrigatório!")
    private String texto;


    @Size(max = 2000)
    private String url;

    private List<ComplementoAnuarioRamoUrlTO> complementoAnuarioRamoUrls;
}
