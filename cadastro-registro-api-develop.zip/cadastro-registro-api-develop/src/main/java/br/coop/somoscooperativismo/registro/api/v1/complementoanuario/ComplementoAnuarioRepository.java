package br.coop.somoscooperativismo.registro.api.v1.complementoanuario;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.entidade.ComplementoAnuario;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ComplementoAnuarioRepository extends JpaRepository<ComplementoAnuario, Integer> {

    @EntityGraph(type = EntityGraph.EntityGraphType.FETCH, attributePaths = {"complementoAnuarioRamoUrls"})
    @Override
    Optional<ComplementoAnuario> findById(Integer id);

    Page<ComplementoAnuario> findByUfContainingAndTextoContainingAndUrlContaining(String uf, String texto, String url, Pageable pageable);
    
    @Query(value = "select ca from ComplementoAnuario ca "
    		+ "where (ca.uf = :uf or :uf is null or :uf = '') "
    		+ "and (ca.texto like %:texto% or :texto is null or :texto = '') "
    		+ "and (ca.url like %:url% or :url is null or :url = '')")
    Page<ComplementoAnuario> findByUfAndTextoAndUrl(String uf, String texto, String url, Pageable pageable);

    @EntityGraph(type = EntityGraph.EntityGraphType.FETCH, attributePaths = {"complementoAnuarioRamoUrls"})
    Optional<ComplementoAnuario> findByUf(String uf);

    boolean existsByUf(String uf);
}
