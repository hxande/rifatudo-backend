package br.coop.somoscooperativismo.registro.api.v1.complementoanuario.entidade;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.entidade.ComplementoAnuarioRamoUrl;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "COMPLEMENTO_ANUARIO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class ComplementoAnuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COMPLEMENTO_ANUARIO")
    private Integer id;

    @Column(name = "TX_UF", columnDefinition = "varchar(2)", nullable = false, unique = true)
    private String uf;

    @Column(name = "TX_TEXTO", columnDefinition = "varchar(3000)", nullable = false)
    private String texto;

    @Column(name = "TX_URL", columnDefinition = "varchar(2000)", nullable = false)
    private String url;

    @OneToMany(mappedBy = "complementoAnuario", cascade = {CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH}, orphanRemoval = true)
    @OnDelete(action = OnDeleteAction.CASCADE)
    private List<ComplementoAnuarioRamoUrl> complementoAnuarioRamoUrls;

    public void removeComplementoAnuarioRamoUrl(ComplementoAnuarioRamoUrl complementoAnuarioRamoUrl) {
        complementoAnuarioRamoUrl.setComplementoAnuario(null);
        this.complementoAnuarioRamoUrls.remove(complementoAnuarioRamoUrl);
    }

    public void addComplementoAnuarioRamoUrl(ComplementoAnuarioRamoUrl complementoAnuarioRamoUrl) {
        complementoAnuarioRamoUrl.setComplementoAnuario(this);
        this.complementoAnuarioRamoUrls.add(complementoAnuarioRamoUrl);
    }
}
