package br.coop.somoscooperativismo.registro.api.v1.certificado.entidade;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

@Entity
@Table(name = "COOPERATIVA_CERTIFICADO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class Certificado {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SQ_COOPERATIVA_CERTIFICADO")
	private Integer id;

	@Column(name="TX_CODIGO_AUTENTICIDADE")
	private String codigoAutenticidade;

	@Column(name="TX_JUSTIFICATIVA")
	private String justificativa;

	@Column(name="DT_GERACAO")
	private Date dataGeracao;

	@OneToOne
	@JoinColumn(name = "SQ_COOPERATIVA")
	private Cooperativa cooperativa;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCodigoAutenticidade() {
		return codigoAutenticidade;
	}

	public void setCodigoAutenticidade(String codigoAutenticidade) {
		this.codigoAutenticidade = codigoAutenticidade;
	}

	public String getJustificativa() {
		return justificativa;
	}

	public void setJustificativa(String justificativa) {
		this.justificativa = justificativa;
	}

	public Date getDataGeracao() {
		return dataGeracao;
	}

	public void setDataGeracao(Date dataGeracao) {
		this.dataGeracao = dataGeracao;
	}

	public Cooperativa getCooperativa() {
		return cooperativa;
	}

	public void setCooperativa(Cooperativa cooperativa) {
		this.cooperativa = cooperativa;
	}
}
