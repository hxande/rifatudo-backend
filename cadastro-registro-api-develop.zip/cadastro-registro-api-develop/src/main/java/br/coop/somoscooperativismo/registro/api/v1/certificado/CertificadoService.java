package br.coop.somoscooperativismo.registro.api.v1.certificado;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.certificado.entidade.Certificado;
import br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual.CertificadoUnidadeEstadualService;
import br.coop.somoscooperativismo.registro.api.v1.certificadounidadeestadual.entidade.CertificadoUnidadeEstadual;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.endereco.EnderecoService;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.FileUploadClient;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.RepositorioArquivoTO;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.RepositorioTO;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.LocalizacaoClient;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.MunicipioTO;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.RelatorioUtil;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import jakarta.validation.Valid;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import net.sf.jasperreports.engine.JRException;
import org.apache.commons.codec.binary.Base64;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

/**
 * @author jorge.stefanini
 */
@Service
public class CertificadoService {

	private static final int DOIS = 2;

	private static final Logger LOGGER = Logger.getLogger(CertificadoService.class);
    
	public static final String NOME_RELATORIO_JASPER = "emissao_certiticado_ocb.jrxml";
    public static final String MODULO_TEMPLATE_CERTIFICADO = "CERTIFICADO_REGISTRO_BACKGROUND_UNIDADE_ESTADUAL";
    public static final String RELATORIO_CERTIFICADO_REGISTRO_FUNDO = "relatorio/certificado_registro_fundo.png";
    public static final String CERTIFICADO_NAO_PODE_IMPRIMIR = "certificado.naoPodeImprimir";

    
    @Autowired
    @Lazy
    private CooperativaService cooperativaService;

    @Autowired
    private EnderecoService enderecoService;

    @Autowired
    private CertificadoRepository certificadoRepository;

    @Autowired
    @Qualifier("localizacaoClientLocal")
    private LocalizacaoClient localizacaoClient;

    @Autowired
    @Qualifier("fileUploadClientLocal")
    private FileUploadClient fileUploadClient;

    @Autowired
    private MessagesService messages;

    @Autowired
    private CertificadoUnidadeEstadualService certificadoUnidadeEstadualService;

    @Autowired
    private KeycloakService keycloakService;

    @Autowired
    private ValidacaoCertificadoService validacaoCertificadoService;

    public void save(Certificado certificado) {
        certificadoRepository.save(certificado);
    }

    public byte[] imprimirCertificado(Integer idCooperativa) {
        validacaoCertificadoService.podeEmitirCeritificadoRegistro();

        Cooperativa cooperativa = keycloakService.isTokenProvided() ? cooperativaService.getCooperativa(idCooperativa)
                : cooperativaService.getCooperativaSemVerificacao(idCooperativa);
        validaSePodeImprimir(cooperativa);
        InputStream inputStreamImagem = obterImagemFundoInputStream(cooperativa);
        Map<String, Object> parametrosLocal = new HashMap<>();
        parametrosLocal.put("REPORT_LOCALE", new Locale("pt", "BR"));
        parametrosLocal.put("IMGCERTIFICADO", inputStreamImagem);
        RelatorioUtil relatorioUtil = new RelatorioUtil();
        try {
            return relatorioUtil.gerarRelatorioPdf(java.util.Collections.singletonList(montaCertificado(cooperativa)), parametrosLocal,
                    "relatorio/" + NOME_RELATORIO_JASPER);
        } catch (JRException e) {
            throw new RegraNegocioException("Error ao gerar certificado, tente mais tarde!",e);
        }
    }

    public byte[] imprimirCertificadoPublico(Integer idCooperativa) {
        Cooperativa cooperativa = cooperativaService.getCooperativaSemVerificacao(idCooperativa);
        validaSePodeImprimir(cooperativa);
        InputStream inputStreamImagem = obterImagemFundoInputStream(cooperativa);
        Map<String, Object> parametrosLocal = new HashMap<>();
        parametrosLocal.put("REPORT_LOCALE", new Locale("pt", "BR"));
        parametrosLocal.put("IMGCERTIFICADO", inputStreamImagem);
        RelatorioUtil relatorioUtil = new RelatorioUtil();
        try {
            return relatorioUtil.gerarRelatorioPdf(java.util.Collections.singletonList(montaCertificado(cooperativa)), parametrosLocal,
                    "relatorio/" + NOME_RELATORIO_JASPER);
        } catch (JRException e) {
            throw new RegraNegocioException("Error ao gerar certificado, tente mais tarde!",e);
        }
    }

    private void validaSePodeImprimir(Cooperativa cooperativa) {
        Integer id = cooperativa.getSituacaoCooperativa().getId();

        if (cooperativa == null || isCooperativaSuspensa(cooperativa.getSituacaoCooperativa().getId())) {
            throw new RegraNegocioException("Cooperativa com registro suspenso.");
        }

        if ((id.equals(NovaSituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo())) || (id.equals(NovaSituacaoCooperativaEnum.CANCELADA.getCodigo()))) {
            throw new RegraNegocioException(messages.get(CERTIFICADO_NAO_PODE_IMPRIMIR));
        }

        id = null;
    }

    private boolean isCooperativaSuspensa(Integer idSituacaoCooperativa) {
        return NovaSituacaoCooperativaEnum.SUSPENSA.getCodigo().equals(idSituacaoCooperativa);
    }

    public boolean validaSePodeImprimir(Integer idCooperativa) {
        Cooperativa cooperativa = cooperativaService.getCooperativa(idCooperativa);
        Integer idSituacaoCooperativa = cooperativa.getSituacaoCooperativa().getId();

        cooperativa = null;

        return (!idSituacaoCooperativa.equals(NovaSituacaoCooperativaEnum.CANCELADA.getCodigo()) && (!idSituacaoCooperativa.equals(NovaSituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo())));
    }

    private CertificadoTO montaCertificado(Cooperativa cooperativa) {
        
        Certificado certificado = certificadoRepository.findByCooperativa(cooperativa);

        if (certificado == null && 
        		(!ValidacaoCampos.validaCampoPreenchido(cooperativa.getNumeroRegistroOCB()) 
        			|| !ValidacaoCampos.validaCampoPreenchido(cooperativa.getDataRegistro()))
        	) {
            throw new RegraNegocioException("Certificado não encontrado.");
        }  
        if (certificado == null 
        		&& ValidacaoCampos.validaCampoPreenchido(cooperativa.getNumeroRegistroOCB()) 
        		&& ValidacaoCampos.validaCampoPreenchido(cooperativa.getSituacaoCooperativa())
                && Objects.equals(cooperativa.getSituacaoCooperativa().getId(), NovaSituacaoCooperativaEnum.REGULAR.getCodigo())) {
            certificado = new Certificado();
            certificado.setDataGeracao(new Date());
            certificado.setCooperativa(cooperativa);
            certificado.setCodigoAutenticidade(cooperativa.gerarCodigoAutenticidade(new Date()));
            this.save(certificado);
        }
        
        List<Endereco> enderecos = enderecoService.obterEnderecosPessoa(cooperativa.getId()).stream()
                .filter(endereco -> endereco.getTipoEndereco().getEnderecoPrincipal()).toList();
        Endereco endereco = !enderecos.isEmpty() ? enderecos.get(0) : new Endereco();
        CertificadoTO certificadoTO = new CertificadoTO();
        certificadoTO.setCnpj(RemoveMascaraUtil.mascaraCNPJ(cooperativa.getPessoaJuridica().getCnpj()));
        String codigoAutenticidade = certificado != null ? certificado.getCodigoAutenticidade() : "";
        certificadoTO.setCodigoAtenticidade(codigoAutenticidade);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        certificadoTO.setDataAssinaturaDigital(montaDataLiteral(new Date()));
        certificadoTO.setEnderecoCorrespondencia(montaCidadeUF(endereco));
        certificadoTO.setDataRegistro(simpleDateFormat.format(cooperativa.getDataRegistro()));
        certificadoTO.setNumeroRegistro(cooperativa.getNumeroRegistroOCB());
        certificadoTO.setProcesso(String.valueOf(cooperativa.getId()));
        certificadoTO.setRazaoSocial(cooperativa.getPessoaJuridica().getRazaoSocial());
        certificadoTO.setSituacaoCooperativa(cooperativa.getSituacaoCooperativa().getNome());

        certificado = null;
        enderecos = null;
        codigoAutenticidade = null;
        simpleDateFormat = null;

        return certificadoTO;
    }

    private String montaDataLiteral(Date data) {
        SimpleDateFormat formatar = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formataNomeMes = new SimpleDateFormat("MMMM", new Locale("pt", "BR"));

        String dataFormatada = formatar.format(data);
        String nomeMes = formataNomeMes.format(data);
        String[] partesData = dataFormatada.split("\\/");

        formatar = null;
        formataNomeMes = null;

        return partesData[0] + " de " + nomeMes + " de " + partesData[DOIS];
    }

    public String montaCidadeUF(@Valid Endereco endereco) {
        MunicipioTO municipio = localizacaoClient.buscaMunicipio(endereco.getIdMunicipio());
        return municipio != null ? (municipio.getNome() + " - " + municipio.getUf().getSigla()) : "";
    }

    private InputStream obterImagemFundoInputStream(Cooperativa cooperativa) { 
        String chaveRepositorio = obterChaveRepFundo(cooperativa);
        if (chaveRepositorio != null) {
            RepositorioTO repositorioTO = getRepositorioTO(chaveRepositorio);

            if (repositorioTO != null && repositorioTO.getArquivos() != null) {
                RepositorioArquivoTO arquivoTO = repositorioTO.getArquivos().stream().sorted()
                        .toList().get(0);
                String base64 = fileUploadClient.downloadBase64Publico(arquivoTO.getChaveArquivo());
                if (base64 != null) {
                    InputStream inputStream =  new ByteArrayInputStream(Base64.decodeBase64(base64));
                    base64 = null;
                    return inputStream;
                }
            }
        }
        throw new RegraNegocioException("Imagem do certificado não encontrada.");
    }

    private RepositorioTO getRepositorioTO(String chaveRepositorio) {
        RepositorioTO repositorioTO = null;
        try {
            repositorioTO = fileUploadClient.buscaRepositorioPublico(chaveRepositorio);
        } catch (Exception e) {
            LOGGER.info("Ocorreu um erro ao buscar  o repositório.\n Erro: " + e.getLocalizedMessage());
        }
        return repositorioTO;
    }

    private String obterChaveRepFundo(Cooperativa cooperativa) {
        if (cooperativa != null && cooperativa.getPessoaJuridica() != null) {
            CertificadoUnidadeEstadual certificadoUnidadeEstadual = certificadoUnidadeEstadualService
                    .buscaPorUf(cooperativa.getPessoaJuridica().getUfSigla());
            return certificadoUnidadeEstadual != null ? certificadoUnidadeEstadual.getArquivo() : null;
        }
        return null;
    }


}
