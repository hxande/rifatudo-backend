package br.coop.somoscooperativismo.registro.api.v1.controleAbasRegistro;

import java.util.Date;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ControleAbasRegistroTO {
    private Integer id;
    private CooperativaTO cooperativa;
    private Date dataEnvio;
    private String aba;
    private Boolean enviada;
}
