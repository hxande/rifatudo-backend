package br.coop.somoscooperativismo.registro.api.v1.email;

import br.coop.somoscooperativismo.registro.api.v1.email.entidade.RegistroEmail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistroEmailRepository extends JpaRepository<RegistroEmail, Integer> {
    
}
