package br.coop.somoscooperativismo.registro.api.v1.email.publisher;

import br.coop.somoscooperativismo.registro.api.v1.email.EmailTO;
import br.coop.somoscooperativismo.registro.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class EmailPublisher {

    private final RabbitTemplate rabbitTemplate;

    public EmailPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void enviarEmail(EmailTO emailTo) {
        rabbitTemplate.convertAndSend(RabbitMQConfig.EMAIL_EXCHANGE, RabbitMQConfig.ROUTING_KEY_EMAIL, emailTo);
    }
}
