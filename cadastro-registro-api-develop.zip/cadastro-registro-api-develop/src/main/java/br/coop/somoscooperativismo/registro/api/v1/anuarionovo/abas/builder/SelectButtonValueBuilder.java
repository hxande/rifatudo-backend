package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class SelectButtonValueBuilder {
    private List<SelectButtonOptionBuilder> options;
    private String selected;
}
