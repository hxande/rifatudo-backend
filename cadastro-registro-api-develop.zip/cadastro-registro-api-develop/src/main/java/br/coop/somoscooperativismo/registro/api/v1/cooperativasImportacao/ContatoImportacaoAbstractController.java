package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.AreaContatoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.ContatoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.PessoaImportacaoTO;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class ContatoImportacaoAbstractController {

    @NonNull
    ModelMapper modelMapper;

    protected Converter<Contato, ContatoImportacaoTO> converterEntidadeParaTO = context ->
            ContatoImportacaoTO.builder()
                    .id(context.getSource().getId())
                    .pessoa(PessoaImportacaoTO.builder()
                            .id(context.getSource().getPessoa().getId())
                            .build())
                    .areaContato(AreaContatoTO.builder()
                            .id(context.getSource().getAreaContato().getId())
                            .nome(context.getSource().getAreaContato().getNome())
                            .ativo(context.getSource().getAreaContato().isAtivo())
                            .excluido(context.getSource().getAreaContato().getExcluido())
                            .posicaoTela(context.getSource().getAreaContato().getPosicaoTela())
                            .utilizaCargo(context.getSource().getAreaContato().getUtilizaCargo())
                            .build())
                    .nomeResponsavel(context.getSource().getNomeResponsavel())
                    .telefone(context.getSource().getTelefone())
                    .celular(context.getSource().getCelular())
                    .email(context.getSource().getEmail())
                    .site(context.getSource().getSite())
                    .cargo(context.getSource().getCargo())
                    .build();
}