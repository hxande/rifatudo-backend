package br.coop.somoscooperativismo.registro.api.v1.enviaemail;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.coop.somoscooperativismo.registro.api.v1.recebeemail.entidade.RecebeEmail;

public interface EnviaEmailRepository extends JpaRepository<RecebeEmail, Integer> {


    @Query(value =
            "Select new br.coop.somoscooperativismo.registro.api.v1.enviaemail.EmailGestorTO(vw.TX_UF_SIGLA, vw.EMAIL)"
            + " from VW_USUARIO_INSCRITO_EMAIL vw"
            + " where vw.TX_SISTEMA = 'cadastro-registro' "
            + " AND vw.TX_CODIGO_SUBGRUPO = 'UE_GES'"
            + " AND vw.DN_ATIVO = 1"
            + " ORDER BY 1", nativeQuery = true)
    List<EmailGestorTO> getEmailsGestorFiltro();


    @Query(value = "Select new br.coop.somoscooperativismo.registro.api.v1.enviaemail.EmailGestorTO(pj.TX_UF_SIGLA, uk.EMAIL) from "
            + "api_gerencia_usuario..USUARIO "
            + "			inner join PESSOA_JURIDICA pj on pj.TX_CNPJ = u.SQ_ENTIDADE and pj.TX_TIPO_PESSOA_JURIDICA = 'E'"
            + "			inner join Keycloak..USER_ENTITY uk on uk.ID = u.TX_ID"
            + "			inner join api_gerencia_usuario..USUARIO_ENTIDADE ue on ue.SQ_USUARIO = u.TX_ID"
            + "			inner join api_gerencia_usuario..USUARIO_ENTIDADE_SISTEMA ues on ues.SQ_USUARIO_ENTIDADE = ue.SQ_USUARIO_ENTIDADE"
            + "			inner join api_gerencia_usuario..USUARIO_SUBGRUPO usg on usg.SQ_USUARIO_ENTIDADE_SISTEMA = ues.SQ_USUARIO_ENTIDADE_SISTEMA"
            + "			inner join api_gerencia_usuario..SUBGRUPO sg on sg.SQ_SUBGRUPO = usg.SQ_SUBGRUPO"
            + "			where ues.TX_SISTEMA = 'cadastro-registro' AND sg.TX_CODIGO_SUBGRUPO = 'UE_GES'"
            + "			order by 1", nativeQuery = true)
    List<EmailGestorTO> getEmailsGestor();

}
