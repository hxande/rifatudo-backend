package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.RedeSocialImportacaoAbstractController;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.RedeSocialImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.entidade.RedeSocial;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.RedeSocialService;

@RestController
@RequestMapping("/api/v1/cooperativas-importacao/redes-sociais")
public class RedeSocialImportacaoRestController extends RedeSocialImportacaoAbstractController {

    private final RedeSocialService redeSocialService;

    public RedeSocialImportacaoRestController(@NonNull ModelMapper modelMapper, @NonNull RedeSocialService redeSocialService) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, RedeSocial.class, RedeSocialImportacaoTO.class);
        this.redeSocialService = redeSocialService;
    }

    @GetMapping("/uf/{uf}")
    public ResponseEntity<List<RedeSocialImportacaoTO>> getByUf(@PathVariable String uf) {
        return ResponseEntity.ok(redeSocialService.getByUf(uf).stream()
                .map(redeSocial -> modelMapper.map(redeSocial, RedeSocialImportacaoTO.class))
                .collect(Collectors.toList()));
    }
}
