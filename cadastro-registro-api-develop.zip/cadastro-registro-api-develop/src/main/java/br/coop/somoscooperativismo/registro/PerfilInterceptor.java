package br.coop.somoscooperativismo.registro;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import br.coop.somoscooperativismo.ocbcommonsapi.annotations.PertenceAoPerfil;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;

@Component
public class PerfilInterceptor implements HandlerInterceptor {

	private final KeycloakService keycloakService;

	public PerfilInterceptor(KeycloakService keycloakService) {
		this.keycloakService = keycloakService;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		
		if(handler instanceof HandlerMethod method) {
			final PertenceAoPerfil pertenceAoSubPerfil = method.getMethod().getAnnotation((PertenceAoPerfil.class));
	
			if (pertenceAoSubPerfil != null) {
				if(Boolean.FALSE.equals(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfilPermissoesTO.getSubperfis(pertenceAoSubPerfil.getPerfil()), SubPerfilPermissoesTO.getSubperfisPadrao()))) {
					throw new RegraNegocioException("Usuário sem permissão para acessar esse recurso", HttpStatus.FORBIDDEN);
				}
			}
		}
		return true;
	}
}
