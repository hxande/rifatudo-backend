package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaCampos;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.AbaDataTypeEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.InputTypeEnum;

public class AbaCampoBuilder {

    private final AbaCampos campo;

    public AbaCampoBuilder(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        campo = new AbaCampos();
        campo.setId(id);
        campo.setName(name);
        campo.setIdParametro(idParametro);
        campo.setIdParametroAuxiliar(idParametroAuxiliar);
        campo.setLabel(label);
        campo.setVisible(true);
        campo.setDisable(false);
    }

    public static AbaCampoBuilder create(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        return new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
    }

    public static AbaCampoBuilder input(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.INPUT.getChave());
        return campoBuild;
    }

    public static AbaCampoBuilder inputPendencia(String value) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder("pendencia-form", "pendencia-form", null, null, null);
        campoBuild.campo.setType(AbaDataTypeEnum.INPUT.getChave());
        campoBuild.campo.setValue(value.isEmpty() ? null : 1);
        campoBuild.campo.setRequired(!value.isEmpty());
        campoBuild.campo.setVisible(false);
        campoBuild.campo.setDisable(!value.isEmpty());

        return campoBuild;
    }

    public static AbaCampoBuilder divisor(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label, String infoText) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.DIVIDER.getChave());
        campoBuild.campo.setInputType(InputTypeEnum.TEXT.getType());
        campoBuild.campo.setId(id);
        campoBuild.campo.setVisible(true);
        campoBuild.campo.setDisable(false);
        campoBuild.campo.setInfoText(infoText);
        campoBuild.campo.setHasInfo(true);
        return campoBuild;
    }

    public static AbaCampoBuilder html(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.HTML.getChave());
        campoBuild.campo.setId(id);
        campoBuild.campo.setVisible(true);
        campoBuild.campo.setDisable(false);
        campoBuild.campo.setHasInfo(true);
        return campoBuild;
    }

    public static AbaCampoBuilder checkbox(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label, String infoText) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.CHECKBOX.getChave());
        campoBuild.campo.setId(id);
        campoBuild.campo.setVisible(true);
        campoBuild.campo.setDisable(false);
        campoBuild.campo.setInfoText(infoText);
        return campoBuild;
    }

    public static AbaCampoBuilder multCheckbox(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label, String infoText) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.MULT_CHECKBOX.getChave());
        campoBuild.campo.setId(id);
        campoBuild.campo.setVisible(true);
        campoBuild.campo.setDisable(false);
        campoBuild.campo.setInfoText(infoText);
        return campoBuild;
    }

    public static AbaCampoBuilder radio(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label, String infoText) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.RADIO.getChave());
        campoBuild.campo.setId(id);
        campoBuild.campo.setVisible(true);
        campoBuild.campo.setDisable(false);
        campoBuild.campo.setInfoText(infoText);
        return campoBuild;
    }

    public static AbaCampoBuilder selectButton(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.SELECT_BUTTON.getChave());
        campoBuild.campo.setId(id);
        campoBuild.campo.setLabel(label);
        campoBuild.campo.setVisible(true);
        campoBuild.campo.setDisable(false);
        return campoBuild;
    }

    public static AbaCampoBuilder textArea(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.TEXT_AREA.getChave());
        return campoBuild;
    }

    public static AbaCampoBuilder complementoAnuario(String id, String name, Integer idParametro, Integer idParametroAuxiliar, String label) {
        AbaCampoBuilder campoBuild = new AbaCampoBuilder(id, name, idParametro, idParametroAuxiliar, label);
        campoBuild.campo.setType(AbaDataTypeEnum.DADOS_COMPLEMENTARES.getChave());
        return campoBuild;
    }

    public AbaCampoBuilder type(String type, String inputType) {
        campo.setType(type);
        campo.setInputType(inputType);
        return this;
    }


    public AbaCampoBuilder inputType(String inputType) {
        campo.setInputType(inputType);
        return this;
    }

    public AbaCampoBuilder value(Object v) {
        campo.setValue(v);
        return this;
    }

    public AbaCampoBuilder required(boolean required) {
        campo.setRequired(required);
        return this;
    }

    public AbaCampoBuilder disabled(boolean disabled) {
        campo.setDisable(disabled);
        return this;
    }

    public AbaCampoBuilder placeholder(String placeholder) {
        campo.setPlaceHolder(placeholder);
        return this;
    }

    public AbaCampoBuilder subTitle(String subtitle) {
        campo.setSubTitle(subtitle);
        return this;
    }

    public AbaCampoBuilder icon(String icon) {
        campo.setHasIcon(true);
        campo.setIcon(icon);
        return this;
    }

    public AbaCampoBuilder visible(boolean visible) {
        campo.setVisible(visible);
        return this;
    }

    public AbaCampoBuilder isAceitaNegativo(boolean isAceitaNegativo) {
        campo.setAceitaNegativo(isAceitaNegativo);
        return this;
    }

    public AbaCampoBuilder mask(String mask, String pais) {
        campo.setHasMask(true);
        campo.setSiglaUnidade(pais);
        campo.setMask(mask);
        return this;
    }

    public AbaCampoBuilder hasMask(Boolean mask) {
        campo.setHasMask(mask);
        return this;
    }

    public AbaCampoBuilder isAccordion(boolean isAccordion) {
        campo.setAccordion(isAccordion);
        return this;
    }

    public AbaCampoBuilder info(String text) {
        campo.setHasInfo(true);
        campo.setInfoText(text);
        return this;
    }

    public AbaCampoBuilder parametroIntegracao(String parametro) {
        campo.setParametroIntegracao(parametro);
        return this;
    }

    public AbaCampoBuilder idParametro(Integer idParametro) {
        campo.setIdParametro(idParametro);
        return this;
    }

    public AbaCampoBuilder readonly(boolean readonly) {
        campo.setReadonly(readonly);
        return this;
    }

    public AbaCampoBuilder decimal(Integer quantidadeCasas){
    campo.setQuantidadeDeCasas(quantidadeCasas);
        return this;
    }

    public AbaCampos build() {
        return campo;
    }
}
