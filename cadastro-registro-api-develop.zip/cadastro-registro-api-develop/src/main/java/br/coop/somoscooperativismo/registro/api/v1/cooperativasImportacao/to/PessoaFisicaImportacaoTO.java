package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PessoaFisicaImportacaoTO {
    private Long seqCpf;
    private String cpf;
    private String nome;
    private Date dataNascimento;
    private String telefone;
    private String celular;
    private String email;
    private String genero;
    private Integer idEscolaridade;
}
