package br.coop.somoscooperativismo.registro.api.v1.events.publisher;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.registro.api.v1.events.events.CensoAnuarioPreenchimentoEvent;

@Component
public class CensoAnuarioPreenchimentoPublisher implements ApplicationEventPublisherAware  {

	@Autowired
    private ApplicationEventPublisher publisher;
	
	
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
		this.publisher = publisher;
	}
	
	public void publish(CensoAnuarioPreenchimentoEvent event) {
		this.publisher.publishEvent(event);
	}

}
