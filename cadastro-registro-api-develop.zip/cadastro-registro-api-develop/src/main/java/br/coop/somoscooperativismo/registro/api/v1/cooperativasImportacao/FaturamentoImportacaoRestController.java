package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade.Faturamento;
import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.FaturamentoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/faturamentos")
public class FaturamentoImportacaoRestController {

    private final FaturamentoService faturamentoService;

    @GetMapping("/cooperativa/{idCooperativa}")
    public ResponseEntity<List<Faturamento>> getByCooperativaId(@PathVariable Integer idCooperativa) {
        return ResponseEntity.ok(faturamentoService.getByCooperativaId(idCooperativa));
    }
}
