package br.coop.somoscooperativismo.registro.api.v1.fileupload;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ExceptionUtil;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

@Service("fileUploadClientLocal")
public class FileUploadClient {

    private static final Logger LOGGER = Logger.getLogger(FileUploadClient.class);

    private static final String URL_ARQUIVO_BASE64_PUBLICO = "/public/api/v1/arquivos/base64/";
    private static final String URL_MODULO_PUBLICO = "/public/api/v1/modulos/repositorios/";
    private static final String URL_REPOSITORIO_PUBLICO = "/public/api/v1/repositorios/";
    private static final String URL_ARQUIVO_BASE64 = "/api/v1/arquivos/base64/";
    private static final String URL_MODULO = "/api/v1/modulos/repositorios/";
    private static final String URL_REPOSITORIO = "/api/v1/repositorios/";
    private static final String ERROR = ".\n Erro: ";

    private final RestTemplate keycloakRestTemplate;
    private final String fileUploadServiceHost;
    private final RestTemplate restTemplate;

    public FileUploadClient(
            @Value("${fileupload_service_host}") String fileUploadServiceHost,
            @Qualifier("keycloakRestTemplate") RestTemplate keycloakRestTemplate,
            @Qualifier("restTemplate") RestTemplate restTemplate) {

        this.fileUploadServiceHost = Objects.requireNonNull(fileUploadServiceHost, "O host do serviço de arquivos não pode ser nulo.");
        this.keycloakRestTemplate = Objects.requireNonNull(keycloakRestTemplate, "O RestTemplate autenticado não pode ser nulo.");
        this.restTemplate = Objects.requireNonNull(restTemplate, "O RestTemplate público não pode ser nulo.");

    }

    public boolean existeArquivoNoRepositorio(String chaveRepositorio) {
        
        validarChave(chaveRepositorio, "A chave do repositório não pode ser nula.");
        String url = fileUploadServiceHost + "/api/v1/repositorios/existemArquivos/" + chaveRepositorio;

        Boolean existemArquivos = keycloakRestTemplate.getForObject(url, Boolean.class);

        return Boolean.TRUE.equals(existemArquivos);
    }

    @Nullable
    public ModuloTO buscaModulo(String chaveModulo) {

        validarChave(chaveModulo, "A chave do módulo não pode ser nula.");
        String url = fileUploadServiceHost + URL_MODULO + chaveModulo;

        try {
            return restTemplate.getForObject(url, ModuloTO.class);
        } catch (HttpClientErrorException e) {
            ExceptionUtil.explodirExcecao(e);
            LOGGER.error("Não foi possível encontrar módulo" + chaveModulo + ERROR + e.getLocalizedMessage());
            return null;
        }

    }

    @Nullable
    public ModuloTO buscaModuloPublico(String chaveModulo) {

        validarChave(chaveModulo, "A chave do módulo não pode ser nula.");
        String url = fileUploadServiceHost + URL_MODULO_PUBLICO + chaveModulo;

        try {
            return restTemplate.getForObject(url, ModuloTO.class);
        } catch (HttpClientErrorException e) {
            ExceptionUtil.explodirExcecao(e);
            LOGGER.error("Não foi possível encontrar módulo público " + chaveModulo + ERROR + e.getLocalizedMessage());
            return null;
        }

    }

    @Nullable
    public RepositorioTO buscaRepositorio(String chaveRepositorio) {

        validarChave(chaveRepositorio, "A chave do repositório não pode ser nula.");
        String url = fileUploadServiceHost + URL_REPOSITORIO + chaveRepositorio;

        try {
            return keycloakRestTemplate.getForObject(url, RepositorioTO.class);
        } catch (HttpClientErrorException e) {
            ExceptionUtil.explodirExcecao(e);
            LOGGER.error("Não foi possível encontrar o repositório " + chaveRepositorio + ERROR + e.getLocalizedMessage());
            return null;
        }

    }

    @Nullable
    public RepositorioTO buscaRepositorioPublico(String chaveRepositorio) {

        validarChave(chaveRepositorio, "A chave do repositório não pode ser nula.");
        String url = fileUploadServiceHost + URL_REPOSITORIO_PUBLICO + chaveRepositorio;

        try {
            return restTemplate.getForObject(url, RepositorioTO.class);
        } catch (HttpClientErrorException e) {
            ExceptionUtil.explodirExcecao(e);
            LOGGER.error("Não foi possível encontrar o repositório " + chaveRepositorio + ERROR + e.getLocalizedMessage());
            return null;
        }

    }

    @Nullable
    public String downloadBase64(String chaveArquivo) {

        validarChave(chaveArquivo, "A chave do arquivo não pode ser nula.");
        String url = fileUploadServiceHost + URL_ARQUIVO_BASE64 + chaveArquivo;

        try {
            return keycloakRestTemplate.getForObject(url, String.class);
        } catch (HttpClientErrorException e) {
            ExceptionUtil.explodirExcecao(e);
            LOGGER.error("Não foi possível encontrar o arquivo " + chaveArquivo + ERROR + e.getLocalizedMessage());
            return null;
        }

    }

    @Nullable
    public String downloadBase64Publico(String chaveArquivo) {

        validarChave(chaveArquivo, "A chave do arquivo não pode ser nula.");
        String url = fileUploadServiceHost + URL_ARQUIVO_BASE64_PUBLICO + chaveArquivo;

        try {
            return restTemplate.getForObject(url, String.class);
        } catch (HttpClientErrorException e) {
            ExceptionUtil.explodirExcecao(e);
            LOGGER.error("Não foi possível encontrar o arquivo " + chaveArquivo + ERROR + e.getLocalizedMessage());
            return null;
        }

    }

    public void deletarDiretorioLogicamente(String chaveRepositorio) {

        validarChave(chaveRepositorio, "A chave do repositório não pode ser nula.");

        String url = fileUploadServiceHost
                + URL_REPOSITORIO
                + "deletarDiretorioLogicamente/"
                + chaveRepositorio;

        keycloakRestTemplate.delete(url, Void.class);
    }

    private static void validarChave(String chave, String mensagem) {
        if (!Objects.nonNull(chave)) {
            throw new IllegalArgumentException(mensagem);
        }
    }

}
