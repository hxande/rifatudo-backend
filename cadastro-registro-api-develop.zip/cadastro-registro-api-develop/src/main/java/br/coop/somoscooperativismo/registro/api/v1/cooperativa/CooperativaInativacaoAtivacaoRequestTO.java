package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CooperativaInativacaoAtivacaoRequestTO {
	
	@NotNull
	private Integer idCooperativa;
	
	private String justificativaAtivacao;
}
