package br.coop.somoscooperativismo.registro.api.v1.endereco;

import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

public interface EnderecoRepository extends JpaRepository<Endereco, Integer> {

    @Query("select tb FROM Endereco tb Where tb.bairro like %:bairro% "
            + " and tb.cep like %:#{#endereco.cep}% "
            + " and tb.numero like %:#{#endereco.numero}% "
            + " and tb.complemento like %:#{#endereco.complemento}% "
            + " and tb.enderecoReferencia like %:#{#endereco.endereco}% "
            + " and (:id_estado is null or tb.idEstado = :#{#endereco.idEstado}) "
            + " and (:id_tipoEndereco is null or tb.tipoEndereco.id = :#{#endereco.idTipoEndereco}) "
            + " and (:id_municipio is null or tb.idMunicipio = :#{#endereco.idMunicipio})")
    Page<Endereco> filtrarByLikeQuery(
            @Param("endereco") EnderecoFiltroTO enderecoFiltroTO,
            Pageable pageable);
    
    @Query("select tb FROM Endereco tb Where tb.bairro like %:bairro% "
    		+ " and tb.cep like %:#{#endereco.cep}% "
    		+ " and tb.numero like %:#{#endereco.numero}% "
    		+ " and tb.complemento like %:#{#endereco.complemento}% "
    		+ " and tb.enderecoReferencia like %:#{#endereco.endereco}% "
    		+ " and (:id_estado is null or tb.idEstado = :#{#endereco.idEstado}) "
    		+ " and (:sq_pessoa is null or tb.pessoa.id = :#{#endereco.idPessoa}) "
    		+ " and (:id_tipoEndereco is null or tb.tipoEndereco.id = :#{#endereco.tipoEndereco}) "
    		+ " and (:id_municipio is null or tb.idMunicipio = :#{#endereco.idMunicipio})")
    List<Endereco> filtrarSemPaginacao(@Param("endereco") EnderecoFiltroTO enderecoFiltroTO);

    @Query(" select tb FROM Endereco tb "
    		+ " Where tb.pessoa.id = :idPessoa AND tb.tipoEndereco.id = :idTipoEndereco ")
    Endereco filtrarEnderecoPorTipo(@Param("idPessoa") Integer idPessoa,@Param("idTipoEndereco") Integer idTipoEndereco);

	@Modifying
	@Transactional
	@Query(value="delete from Endereco endereco where endereco.pessoa.id = :idPessoa")
	void deleteByPessoa(Integer idPessoa);

	@Query("Select e from Endereco e" +
			" inner join PessoaJuridica pj on e.pessoa.id = pj.id" +
			" where pj.ufSigla like :uf")
	List<Endereco> buscaPorUf(@Param("uf") String uf);
}
