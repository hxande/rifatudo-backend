package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao;

import java.util.List;

import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

@Component
public class DadosGeraisValidacaoDadosBasicos {
	
	
	public static final String VALIDACAO_NOME_FANTASIA_OBRIGATORIO = "dadosGerais.validadcao.nomeFantasiaObrigatorio";
	public static final String VALIDACAO_RAZAO_SOCIAL_OBRIGATORIO = "dadosGerais.validacao.razaoSocialObrigatorio";
	public static final String VALICADAO_IDENTIFICACAO_OBRIGATORIO = "dadosGerais.validacao.identificacaoObrigatorio";
	public static final String VALIDACAO_NIRE_OBRIGATORIO =  "dadosGerais.validacao.nireObrigatorio";
	public static final String VALIDACAO_DATA_CONSTITUICAO_OBRIGATORIO = "dadosGerais.validacao.dataConstituicaoObrigatorio";
	public static final String VALIDACAO_RAMO = "dadosGerais.validacao.ramo";
	
	public  List<ServiceMessage> validaDadosBasicos(List<ServiceMessage> mensagens, Cooperativa c,  MessagesService messages){
		
		
		if(!ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getNomeFantasia())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALICADAO_IDENTIFICACAO_OBRIGATORIO)));
		}
		
		if(!ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getRazaoSocial())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_RAZAO_SOCIAL_OBRIGATORIO)));
		}
		
		if(!ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getNire())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_NIRE_OBRIGATORIO)));
		}
		
		if(!ValidacaoCampos.validaCampoPreenchido(c.getPessoaJuridica().getDataConstituicao())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_DATA_CONSTITUICAO_OBRIGATORIO)));
		}
		
		if(c.getPessoaJuridica().getRamo() == null) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_RAMO)));
		}
		
		
		return mensagens;
		
	}
}