package br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.entidade;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;

@Entity
@Table(name = "COOPERATIVA_VINCULACAO")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class CooperativaVinculacao implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_COOPERATIVA_VINCULACAO")
	private Integer id;

	@ManyToOne
	@JoinColumn(name = "SQ_COOPERATIVA_PAI", nullable = false)
	private Cooperativa cooperativaPai;

	@ManyToOne
	@JoinColumn(name = "SQ_COOPERATIVA_VINCULADA", nullable = false)
	private Cooperativa cooperativaVinculada;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Cooperativa getCooperativaPai() {
		return cooperativaPai;
	}

	public void setCooperativaPai(Cooperativa cooperativaPai) {
		this.cooperativaPai = cooperativaPai;
	}

	public Cooperativa getCooperativaVinculada() {
		return cooperativaVinculada;
	}

	public void setCooperativaVinculada(Cooperativa cooperativaVinculada) {
		this.cooperativaVinculada = cooperativaVinculada;
	}

}
