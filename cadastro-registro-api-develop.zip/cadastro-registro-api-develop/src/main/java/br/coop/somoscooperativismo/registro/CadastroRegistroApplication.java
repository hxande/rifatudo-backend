package br.coop.somoscooperativismo.registro;

import java.util.concurrent.Executor;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication(scanBasePackages={"br.coop.somoscooperativismo"})
@EnableAsync
@ConfigurationPropertiesScan
public class CadastroRegistroApplication {
	
	private int COREPOOLSIZE = 2;
	private int MAXPOOLSIZE = 5;
	private int QUEUECAPACITY = 500;
	
	public static void main(String[] args) {
		SpringApplication.run(CadastroRegistroApplication.class, args);
	}
	
	
	@Bean
	public Executor asyncExecutor() {
	    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	    executor.setCorePoolSize(COREPOOLSIZE);
	    executor.setMaxPoolSize(MAXPOOLSIZE);
	    executor.setQueueCapacity(QUEUECAPACITY);
	    executor.initialize();
	    return executor;
	}

	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
}

