package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import br.coop.somoscooperativismo.registro.api.v1.criterioassociacao.entidade.CriterioAssociacao;
import java.util.List;

import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.registro.api.v1.ramo.entidade.Ramo;

@Component
public class CriterioAssociacaoConverterService {

    public CriterioAssociacaoTO toDTO(CriterioAssociacao entity) {
        CriterioAssociacaoTO dto = new CriterioAssociacaoTO();
        dto.setId(entity.getId());
        dto.setSqRamo(entity.getRamo().getId());
        dto.setDescricao(entity.getDescricao());
        dto.setAtivo(entity.getAtivo());
        dto.setExcluido(entity.getExcluido());
        return dto;
    }

    public CriterioAssociacao toEntity(CriterioAssociacaoTO dto) {
        CriterioAssociacao entity = new CriterioAssociacao();
        entity.setId(dto.getId());

        Ramo ramo = new Ramo();
        ramo.setId(dto.getSqRamo());
        entity.setRamo(ramo);

        entity.setDescricao(dto.getDescricao());
        entity.setAtivo(dto.getAtivo());
        entity.setExcluido(dto.getExcluido());
        return entity;
    }

    public List<CriterioAssociacaoTO> toDTOList(List<CriterioAssociacao> entityList) {
        return entityList.parallelStream().map(ca -> toDTO(ca)).toList();
    }
}

