package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.to;

import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.SituacaoAbaEnum;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CooperativaManutencaoAbasTO {

	private Integer id;	
	private Integer idCooperativa;
	private Integer anoCiclo;
	private String abaDocumentos;
	private String abaDadosGerais;
	private String abaGovernanca;
	private String abaSegmentacaoFilial;
	private String abaContatos;
	private String abaSubmeter;
	private Date dataAlteracao;
	private Date dataCriacao;
	private String usuario;
	private List<String> abasComAjusteSolicitado = new ArrayList<>();

	public CooperativaManutencaoAbasTO(Integer idCooperativa,Integer anoCiclo) {
		this.idCooperativa = idCooperativa;
		this.anoCiclo = anoCiclo;
		this.abaDocumentos = SituacaoAbaEnum.ALERTA.getId();
		this.abaDadosGerais = SituacaoAbaEnum.ALERTA.getId();
		this.abaGovernanca = SituacaoAbaEnum.ALERTA.getId();
		this.abaSegmentacaoFilial = SituacaoAbaEnum.ALERTA.getId();
		this.abaContatos = SituacaoAbaEnum.ALERTA.getId();
		this.abaSubmeter = SituacaoAbaEnum.ALERTA.getId();
		this.dataAlteracao = null;
		this.dataCriacao = new Date();
		this.usuario = null;;
	}
	
}
