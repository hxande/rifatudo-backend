
package br.coop.somoscooperativismo.registro.api.v1.cooperativa;


import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;

import com.querydsl.core.BooleanBuilder;

import br.coop.somoscooperativismo.api.v1.relatorio.RelatorioClient;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.interfaces.IGenericService;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.FiltroTO;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioExpressTO;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import br.coop.somoscooperativismo.registro.api.v1.cadastroregistro.CadastroRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.certificado.CertificadoService;
import br.coop.somoscooperativismo.registro.api.v1.certificado.entidade.Certificado;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.dao.CooperativaDAO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.CooperativaRegistroRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.CooperativaRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.TipoAcaoEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaresponsavel.CooperativaResponsavelRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaresponsavel.entidade.CooperativaResponsavel;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaIntegracaoFormularioResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.CooperativaWebLectorResponseTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.CooperativaSolicitacaoService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasolicitacao.entidade.CooperativaSolicitacao;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.CooperativaVinculacaoRepository;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum;
import br.coop.somoscooperativismo.registro.api.v1.email.util.EmailServiceEvent;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.FileUploadClient;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.AcaoProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroTO;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.FaseProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.LocalizacaoClient;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.SolicitacaoMudancaEnderecoService;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;
import br.coop.somoscooperativismo.registro.api.v1.naturezajuridica.NaturezaJuridicaRepository;
import br.coop.somoscooperativismo.registro.api.v1.parecer.ParecerService;
import br.coop.somoscooperativismo.registro.api.v1.parecer.entidade.Parecer;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaBlocoEnum;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaRepository;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.entidade.CooperativaPendencia;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.TipoPessoaJuridicaEnum;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.redesocial.entidade.RedeSocial;
import br.coop.somoscooperativismo.registro.api.v1.sindicato.SindicatoCooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.sindicato.entidade.SindicatoCooperativa;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import br.coop.somoscooperativismo.registro.api.v1.solicitacao.SolicitacaoService;
import br.coop.somoscooperativismo.registro.api.v1.solicitacao.entidade.Solicitacao;
import br.coop.somoscooperativismo.registro.api.v1.state.PreCadastroState;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroState;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroStateFactory;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import br.coop.somoscooperativismo.registro.api.v1.vinculosolicitacao.CooperativaSuperiorBuscaTO;
import br.coop.somoscooperativismo.registro.api.v1.visitatecnica.VisitaTecnicaRepository;
import br.coop.somoscooperativismo.registro.api.v1.visitatecnica.VisitaTecnicaService;
import br.coop.somoscooperativismo.registro.api.v1.visitatecnica.entidade.VisitaTecnica;
import jakarta.validation.Valid;

@Service
@Transactional
public class CooperativaService implements IGenericService<Cooperativa, Integer> {
	
	private static final Logger LOGGER = Logger.getLogger(CooperativaService.class);

    public static final String NAO_ENCONTRADO = "cooperativa.naoEncontrado";
    public static final String PROCESSO_NAO_ARQUIVADO = "processo.naoArquivado";
    public static final String JUSTIFICATIVA_OBRIGATORIA = "justificativa.obrigatoria";
    public static final String NENHUM_ANEXO_ENCONTRADO = "fileuploadclient.nenhumAnexoEncontrado";
    public static final String REPOSITORIOS_DIFERENTES = "fileuploadclient.repositoriosDiferentes";
    public static final String PERMISSAO_NEGADA = "cooperativa.permissaoNegada";
    public static final String ERRO_EXCLUIR_DOCUMENTO_CONFORMIDADE = "parecer.erroExcluirConformidade";
    public static final String ERRO_EXCLUIR_DOCUMENTO_DELIBERACAO = "parecer.erroExcluirDeliberacao";
    public static final String ERRO_EXCLUIR_PARECER_VISITA_TECNICA = "visitatecnica.erroExcluirParecerVisitaTecnica";
    public static final String ERRO_EXCLUIR_DOCUMENTO_RECURSO = "parecer.erroExcluirRecurso";
    public static final String ERRO_EXCLUIR_DOCUMENTO_RESULTADO_RECURSO = "parecer.erroExcluirResultadoRecurso";
    public static final String APONTAMENTO_OBRIGATORIO = "parecer.apontamentoObrigatorio";
    public static final String AGUARDANDO_PROCESSO = "dadosGerais.validacao.aguardandoProcesso";
    public static final String COOPERATIVA_JUSTIFICATIVA_OBRIGATORIA = "cooperativa.justificativa.obrigatoria";
	public static final String COOPERATIVA_REGRA_SUSPENSAO = "cooperativa.regra.suspensao";
    public static final String COOPERATIVA_PERMISSAO_ALTERAR = "permissao.alteracao";
    public static final String COOPERATIVA_PERMISSAO_CANCELAR = "permissao.cancelarAnaliseDados";
    public static final String ERRO_OPERACAO = "erro.operacao";
    public static final String COOPERATIVA_REGRA_CANCELAR = "cooperativa.regra.cancelar";
    public static final String ERRO_PLANILHA = "cooperativa.erroPlanilha";
    public static final String DATA_ATUALIZACAO = "Data de atualização";
    public static final String NOME_FANTASIA = "Nome fantasia";
    public static final String NAO_HA_REGISTROS_EXPORT = "Não há registros para exportar.";
    public static final String FASE_DO_PROCESSO = "Fase do Processo";
    public static final String SEM_SOLICITACAO_INATIVACAO = "Não existe solicitação de inativação para esta cooperativa";
    public static final String SEM_SOLICITACAO_CANCELAMENTO = "Não existe solicitação de cancelamento para esta cooperativa";
    public static final String ERRO_ATIVAR_COOPERATIVA = "Erro ao ativar a cooperativa!";
    public static final String ERRO_SUSPENDER_COOPERATIVA = "Erro ao suspender a cooperativa!";
    public static final String SOLICITACAO_SITUACAO_PENDENTE = "cooperativa.solicitacao.situacao.pendente";
    public static final String TELEFONE = "Telefone";
    public static final String RAZAO_SOCIAL = "Razão Social";

    private static final int LARGURA_4 = 4;
    private static final int LARGURA_5 = 5;
    private static final int LARGURA_14 = 14;
    private static final int LARGURA_16 = 16;
    private static final int LARGURA_18 = 18;
    private static final int LARGURA_20 = 20;
    private static final int LARGURA_24 = 24;
	private static final int LARGURA_25 = 25;
	private static final int LARGURA_28 = 28;
	private static final int LARGURA_30 = 30;
	private static final int LARGURA_36 = 36;
	private static final int LARGURA_40 = 40;
	private static final int LARGURA_35 = 35;
	private static final int LARGURA_45 = 45;
	private static final int LARGURA_50 = 50;

	private static final int VALUE_10 = 10;
	private static final int VALUE_2143 = 2143;
    private static final Pattern CNPJ_BUSCA_PATTERN = Pattern.compile("^[A-Z0-9]{12}\\d{2}$");
	
	private static final String DATA_SOLICITACAO = "Data de Solicitação";
	private static final String PRAZO = "Prazo";
	private static final String UF = "UF";
	private static final String NUMERO_PROCESSO = "Nº do Processo";
	private static final String RESPONSAVEL = "Responsável";

    @Value("${dias_concluir_solicitacao}")
    private int diasConcluirSolicitacao;

    @Autowired
    CooperativaRepository cooperativaRepository;

    @Autowired
    private CooperativaVinculacaoRepository cooperativaVinculacaoRepository;

    @Autowired
    CooperativaResponsavelRepository cooperativaResponsavelRepository;

    @Autowired
    VisitaTecnicaRepository visitaRepository;

    @Autowired
    CooperativaDAO cooperativaDAO;

    @Autowired
    private PessoaJuridicaService pessoaJuridicaService;

    @Autowired
    private MessagesService messages;

    @Autowired
    private KeycloakService keycloakService;

    @Autowired
    private CertificadoService certificadoService;

    @Autowired
    private CooperativaRegistroService cooperativaRegistroService;

    @Autowired
    private EmailService emailService;

    @Autowired
    private CooperativaPendenciaRepository pendenciaRepository;

    @Autowired
    private CooperativaPendenciaService cooperativaPendenciaService;

    @Autowired
    private CadastroRegistroService cadastroRegistroService;

    @Autowired
    private ParecerService parecerService;

    @Autowired
    private VisitaTecnicaService visitaService;

    @Autowired
    private FileUploadClient fileUploadClient;

    @Autowired
    private CooperativaRegistroRepository cooperativaRegistroRepository;

    @Autowired
    private SolicitacaoMudancaEnderecoService solicitacaoMudancaEnderecoService;

    @Autowired
    private RelatorioClient relatorioClient;

    @Autowired
    private CooperativaSolicitacaoService cooperativaSolicitacaoService;

    @Autowired
    private NaturezaJuridicaRepository naturezaJuridicaRepository;

    @Autowired
    @Qualifier("localizacaoClientLocal")
    private LocalizacaoClient localizacaoClient;

    @Autowired
    private ValidacaoCooperativaService validacaoCooperativa;

    @Autowired
    private ApplicationEventPublisher applicationEventPublisher;
    
    @Autowired
    private ProgressoCadastroStateFactory progressoCadastroStateFactory;
    
    @Autowired
    private SolicitacaoService solicitacaoService;

    @Autowired
    private CooperativaHistoricoProcessoRegistroService cooperativaHistoricoProcessoRegistroService;
    
    @Autowired
    private SindicatoCooperativaService sindicatoCooperativaService;

    @Override
    public List<Cooperativa> findAll() {
        FiltroTO filtro = keycloakService.getFiltro();
        return cooperativaRepository.findAll(filtro.getCnpj(), filtro.getUf());
    }

    @Override
    public Cooperativa findById(Integer id) {
        Cooperativa c = null;
        FiltroTO filtro = keycloakService.getFiltro();
        /**
         * Verifica se a cooperativa possui processo de mudança de UF caso tenha
         * processo em andamento as UES de destino e Nacional podem visualziar a
         * cooperativa
         **/
        SolicitacaoMudancaEndereco solicitacaoMudancaUF = solicitacaoMudancaEnderecoService
                .obterSolicitacaoMudancaUF(id);
        if (solicitacaoMudancaUF != null && solicitacaoMudancaUF.getUfDestino().equals(filtro.getUf())
                && keycloakService.isTipoEntidadeEstadual()) {
            Optional<Cooperativa> coopOpt = cooperativaRepository.findById(id);
            if (coopOpt.isPresent()) {
                c = coopOpt.get();
            }
            // Regra padrão
        } else {
            c = cooperativaRepository.findById(id, filtro.getCnpj(), filtro.getUf());
        }
        if (c == null) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        // O login do último editor (auditoria Envers) só é
        // exposto para a unidade Nacional — mesmo gate da última ação de governança
        // (UltimaAcaoGovernancaService). Nenhuma tela consome o campo hoje.
        if (keycloakService.isTipoEntidadeNacional()) {
            c.setUsuarioAuditoria(cooperativaRepository.recuperaUsuarioAuditoria(id));
        }
        
        if(ValidacaoCampos.validaCampoPreenchido(c.getFiliacaoSindical()) && Boolean.TRUE.equals(c.getFiliacaoSindical())) {
        	SindicatoCooperativa sc = sindicatoCooperativaService.getSindicatoFiliadoByIdCooperativa(c.getId());
        	c.setIdSindicato(sc.getSindicato().getId());      
    	}

        return c;
    }

    public Cooperativa getCooperativaSemException(Integer id) {
        return cooperativaRepository.findById(id).orElseThrow(() -> new RegraNegocioException(messages.get(NAO_ENCONTRADO)));
    }

    public Cooperativa getCooperativaSemVerificacao(Integer id) {
        Optional<Cooperativa> c = cooperativaRepository.findById(id);
        if (c.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        return c.get();
    }

    public CooperativaBasicaTO findByIdPublico(Integer id) {
        Optional<Cooperativa> c = cooperativaRepository.findById(id);
        return c.map(CooperativaUtil::formatarSaidaBasica).orElse(null);
    }

    public List<CooperativaBasicaTO> findByRazaoSocialPublico(String razaoSocial) {
        return cooperativaRepository.buscaPorRazaoSocial(razaoSocial);
    }

    public List<CooperativaBasicaTO> findCooperativaAtivaByRazaoSocialPublico(String razaoSocial) {
        List<Cooperativa> listaCooperativas = cooperativaRepository.buscaAtivasPorRazaoSocial(razaoSocial);
        return CooperativaUtil.formatarSaidaBasica(listaCooperativas);
    }

    public List<CooperativaBasicaTO> findCooperativaAtivaByRazaoSocialUFPublico(String razaoSocial, String uf) {
        List<Cooperativa> listaCooperativas = cooperativaRepository.buscaAtivasPorRazaoSocialEUf(razaoSocial, uf);
        return CooperativaUtil.formatarSaidaBasica(listaCooperativas);
    }

    public List<CooperativaBasicaTO> findCooperativaAtivaByCnpj(String cnpj) {
        List<Cooperativa> listaCooperativas = cooperativaRepository.buscaAtivasPorCnpj(cnpj);
        return CooperativaUtil.formatarSaidaBasica(listaCooperativas);
    }

    public List<CooperativaBasicaTO> findCooperativaByCnpj(String cnpj) {
        List<Cooperativa> listaCooperativas = cooperativaRepository.buscaPorCnpj(cnpj);
        return CooperativaUtil.formatarSaidaBasica(listaCooperativas);
    }

    public Page<CooperativaBasicaTO> findCooperativaAtivaByCnpj(String cnpj, String processo, Pageable pageable) {
        cnpj = cnpj == null ? "" : RemoveMascaraUtil.remove(cnpj);
        Integer numeroProcesso = processo != null ? Integer.valueOf(processo.replaceAll("\\D", "")) : null;
        Page<Cooperativa> listaCooperativasPage = cooperativaRepository.buscaAtivasPorCnpjPaginado(cnpj, numeroProcesso,
                pageable);

        numeroProcesso = null;

        return new PageImpl<>(CooperativaUtil.formatarSaidaBasica(listaCooperativasPage.getContent()), pageable,
                listaCooperativasPage.getTotalElements());
    }

    public Page<CooperativaBasicaTO> findCooperativaRegistradas(String cnpj, String processo, String uf, String nomeFantasia, Pageable pageable) {
        cnpj = cnpj == null ? "" : RemoveMascaraUtil.remove(cnpj);
        Page<Cooperativa> listaCooperativasPage = cooperativaRepository.buscaRegistradasPaginado(cnpj, processo, uf, nomeFantasia, pageable);
        return new PageImpl<>(CooperativaUtil.formatarSaidaBasica(listaCooperativasPage.getContent()), pageable,
                listaCooperativasPage.getTotalElements());
    }

    public Page<CooperativaBasicaTO> findByRazaoSocialPublicoPaginado(String razaoSocial, Pageable pageable) {

        Page<Cooperativa> listaCooperativas = cooperativaRepository.buscaPorRazaoSocialPaginado(razaoSocial, pageable);

        return new PageImpl<>(CooperativaUtil.formatarSaidaBasica(listaCooperativas.getContent()), pageable,
                listaCooperativas.getTotalElements());
    }

    public Page<CooperativaBasicaTO> findByNomeUfPublico(String razaoSocial, String nomeFantasia, String tipo,
                                                         Pageable pageable) {

        Page<Cooperativa> listaCooperativas = cooperativaRepository.buscaPorRazaoSocialUfPaginado(razaoSocial,
                nomeFantasia, tipo, pageable);

        return new PageImpl<>(CooperativaUtil.formatarSaidaBasica(listaCooperativas.getContent()), pageable,
                listaCooperativas.getTotalElements());
    }

    @Override
    public void delete(@Valid Cooperativa entity) {
        throw new RegraNegocioException("Não implementado");
    }

    @Override
    public void deleteById(Integer id) {
        Optional<Cooperativa> coop = cooperativaRepository.findById(id);

        if (coop.isPresent()) {
            cooperativaRepository.deleteById(id);
        }
    }

    public Cooperativa getCooperativa(Integer id) {
        return findById(id);
    }

    public @Valid Cooperativa save(@Valid Cooperativa cooperativa) {
        return cooperativaRepository.save(cooperativa);
    }

    @Deprecated(forRemoval = true)
    public CooperativaBasicaTO salvaPreCadastro(@Valid Integer idCooperativa) {
        CooperativaBasicaTO cAux = null;

        cAux = this.findByIdPublico(idCooperativa);

        if (cAux != null) {
            throw new RegraNegocioException("Cooperativa já existe");
        }

        Cooperativa cooperativa = new Cooperativa(idCooperativa);
        cooperativa.setPessoaJuridica(pessoaJuridicaService.getPessoaJuridicaInterno(idCooperativa));
        cooperativa.setProgressoMacro(ProgressoMacroEnum.PRE_CADASTRO_0);
        cooperativa.setProgressoMicro(ProgressoMicroEnum.PRE_CADASTRO_0_0);
        cooperativa.setProcesso(String.valueOf(idCooperativa));
        cooperativa.setLiquidacao(Boolean.FALSE);
        save(cooperativa);

        return findByIdPublico(cooperativa.getId());
    }
    
    public CooperativaBasicaTO salvarPreCadastroState(@Valid Integer idCooperativa) {
    	return new PreCadastroState(pessoaJuridicaService, cooperativaRepository).salvarPreCadastro(idCooperativa);
    }

    public Cooperativa cadastraSemUsuario(CooperativaBasicaTO cooperativaTO) {
        PessoaJuridica pj = buscarOuCriarPessoaJuridica(cooperativaTO);

        validarUfCooperativa(cooperativaTO, pj);

        CooperativaBasicaTO cooperativaBasicaTO = salvarPreCadastroState(pj.getId());
        Cooperativa cooperativa = findById(cooperativaBasicaTO.getId());
        cooperativa.setCadastroSemUsuario(Boolean.TRUE);

        return this.save(cooperativa);
    }

    private void validarUfCooperativa(CooperativaBasicaTO cooperativaTO, PessoaJuridica pj) {
        if (!keycloakService.isTipoEntidadeNacional()
                && !keycloakService.getUFUsuario().equals(cooperativaTO.getUfSigla())) {
            if (cooperativaTO.getUfSigla() == null) {
                throw new RegraNegocioException("UF da cooperativa é inválida.");
            } else if (pj != null) {
                throw new RegraNegocioException("Esse CNPJ já está cadastrado na UF: " + pj.getUfSigla() + ".");
            }
        }
    }

    private PessoaJuridica buscarOuCriarPessoaJuridica(CooperativaBasicaTO cooperativaTO) {
        PessoaJuridica pj = pessoaJuridicaService.buscaPorCnpj(cooperativaTO.getCnpj());

        if (pj == null) {
            return criarPessoaJuridica(cooperativaTO);
        }

        validarPessoaJuridicaExistente(pj);
        return pj;
    }

    private PessoaJuridica criarPessoaJuridica(CooperativaBasicaTO cooperativaTO) {
        PessoaJuridica pj = new PessoaJuridica();
        pj.setCnpj(cooperativaTO.getCnpj());
        pj.setUfSigla(cooperativaTO.getUfSigla());
        pj.setRazaoSocial(cooperativaTO.getRazaoSocial());
        pj.setNomeFantasia(cooperativaTO.getNomeFantasia());

        naturezaJuridicaRepository.findById(VALUE_2143).ifPresent(pj::setNaturezaJuridica);

        return pessoaJuridicaService.createPessoaJuridica(pj);
    }

    private void validarPessoaJuridicaExistente(PessoaJuridica pj) {
        if (!TipoPessoaJuridicaEnum.COOPERATIVA.getTipo().equals(pj.getTipoPessoa())) {
            if (pj.getNaturezaJuridica() == null || !pj.getNaturezaJuridica().getId().equals(VALUE_2143)) {
                throw new RegraNegocioException("Natureza Jurídica inválida.");
            }
        }
    }

    public Cooperativa updateCooperativa(@Valid Cooperativa cooperativa) {
        Cooperativa c = getCooperativa(cooperativa.getId());
        if (c == null) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }

        c = null;

        return cooperativaRepository.save(cooperativa);
    }

    public List<CooperativaBasicaTO> getCooperativasPorGrau(String busca, Integer idCategoria) {

        List<CooperativaBasicaTO> saida = null;
        CategoriaCooperativaEnum categoria = CategoriaCooperativaEnum.getValue(idCategoria);

        if (categoria != null) {

            Integer[] idsCategoria = Arrays.stream(categoria.getPermissaoVinculacao().toArray()).toArray(Integer[]::new);

            Integer[] situacoesPermitidas = {
                    NovaSituacaoCooperativaEnum.REGULAR.getCodigo(),
                    NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo(),
                    NovaSituacaoCooperativaEnum.SUSPENSA.getCodigo()
            };

            String buscaCnpj = normalizarCnpjBusca(busca);
            Pageable limite = PageRequest.of(0, VALUE_10);

            if (CNPJ_BUSCA_PATTERN.matcher(buscaCnpj).matches()) {
                saida = cooperativaRepository.getCooperativasPorGrauECnpj(
                        buscaCnpj,
                        idsCategoria,
                        situacoesPermitidas,
                        limite
                );
            } else {
                saida = cooperativaRepository.getCooperativasPorGrauENome(
                        normalizarTextoBusca(busca),
                        idsCategoria,
                        situacoesPermitidas,
                        limite
                );
            }
        }

        return saida;
    }

    private String normalizarCnpjBusca(String valor) {

        if (valor == null) {
            return "";
        }

        return valor
                .replaceAll("[.\\-/\\s]", "")
                .trim()
                .toUpperCase(Locale.ROOT);
    }

    private String normalizarTextoBusca(String valor) {

        if (valor == null) {
            return "";
        }

        String normalizado = java.text.Normalizer.normalize(valor, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");

        return normalizado.toLowerCase().trim();
    }

    public Cooperativa arquivarProcesso(Integer id) {
        validacaoCooperativa.podeArquivarProcesso();
        Cooperativa c = getCooperativa(id);
        if (c == null) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        c.setArquivado(true);
        c = cooperativaRepository.save(c);
        disparodeEmails(c, EnvioEmailEventEnum.EMAIL_ARQUIVA_REGISTRO);
        gravaProcessoRegistro(c, AcaoProcessoRegistroEnum.ARQUIVAR_PROCESSO, mapearFase(c.getProgressoMacro()));

        return c;
    }

    public Cooperativa desarquivarProcesso(Integer id) {
        validacaoCooperativa.podeDesarquivarProcesso();
        Cooperativa c = getCooperativa(id);
        validaCooperativa(c);
        desarquivarVisitaTecnica(c.getId());
        desarquivarParecer(c.getParecer());

        List<CooperativaPendencia> pendenciasNaoVisualizadas = pendenciaRepository.buscarPendencias(c.getId(), false);
        for (CooperativaPendencia pendencia : pendenciasNaoVisualizadas) {
            pendencia.setVisualizado(Boolean.TRUE);
            pendenciaRepository.save(pendencia);
        }

        c.setArquivado(false);
        c.trocarEstado();
        c = cooperativaRepository.save(c);

        disparodeEmails(c, EnvioEmailEventEnum.EMAIL_DESARQUIVA_REGISTRO);
        gravaProcessoRegistro(c, AcaoProcessoRegistroEnum.DESARQUIVAR_PROCESSO, FaseProcessoRegistroEnum.CADASTRO);

        return c;
    }

    private void desarquivarParecer(Parecer parecer) {
        if (Objects.nonNull(parecer)) {
            Parecer parecerArquivado = parecerService.getParecer(parecer.getId());
            if (parecerArquivado != null) {

                validarDeletarArquivo(parecerArquivado.getArquivoConformidade(), ERRO_EXCLUIR_DOCUMENTO_CONFORMIDADE);
                validarDeletarArquivo(parecerArquivado.getArquivoDeliberacao(), ERRO_EXCLUIR_DOCUMENTO_DELIBERACAO);
                validarDeletarArquivo(parecerArquivado.getArquivoRecursoDeliberacao(), ERRO_EXCLUIR_DOCUMENTO_RECURSO);
                validarDeletarArquivo(parecerArquivado.getArquivoResultadoRecurso(),
                        ERRO_EXCLUIR_DOCUMENTO_RESULTADO_RECURSO);
                parecerService.saveParecerAoDesarquivar(limparParecer(parecerArquivado));
            }
        }
    }

    private void validarDeletarArquivo(String arquivoConformidade, String erroExcluirDocumentoConformidade) {
        if (arquivoConformidade != null && !arquivoConformidade.isEmpty()) {
            try {
                fileUploadClient.deletarDiretorioLogicamente(arquivoConformidade);
            } catch (Exception ex) {
                LOGGER.error(messages.get(erroExcluirDocumentoConformidade), ex);
                throw new RegraNegocioException(ERRO_OPERACAO, ex, HttpStatus.NOT_FOUND);
            }
        }

    }

    private void desarquivarVisitaTecnica(Integer id) {
        VisitaTecnica visitaTecnicaArquivada = visitaService.getVisitaTecnicaCooperativaByIdPessoaJuridica(id);
        if (visitaTecnicaArquivada != null) {
            if (visitaTecnicaArquivada.getAnexoParecer() != null
                    && !visitaTecnicaArquivada.getAnexoParecer().isEmpty()) {
                try {
                    fileUploadClient.deletarDiretorioLogicamente(visitaTecnicaArquivada.getAnexoParecer());
                } catch (HttpClientErrorException ex) {
                    LOGGER.error(messages.get(ERRO_EXCLUIR_PARECER_VISITA_TECNICA), ex);
                    throw new RegraNegocioException(ERRO_OPERACAO,ex, HttpStatus.NOT_FOUND);
                }
            }
            visitaService.saveVisitaTecnicaAoDesarquivar(limparVisitaTecnica(visitaTecnicaArquivada));
        }
    }

    private void validaCooperativa(Cooperativa c) {
        if (Boolean.FALSE.equals(c.getArquivado())) {
            throw new RegraNegocioException(messages.get(PROCESSO_NAO_ARQUIVADO));
        }
    }

    private VisitaTecnica limparVisitaTecnica(VisitaTecnica vt) {
        vt.setDataSugerida1(null);
        vt.setDataSugerida2(null);
        vt.setDataSugerida3(null);
        vt.setDataAceitaCooperativa(null);
        vt.setParecerVisitaTecnica(false);
        vt.setObservacoesPrevisita(null);
        vt.setObservacoes(null);
        vt.setLoginUsuarioEnvioParecer(null);
        vt.setDataEnvioParecer(null);
        vt.setReconsideraSugestao(false);
        vt.setVisitaNaoRealizada(null);

        return vt;
    }

    private Parecer limparParecer(Parecer p) {
        p.setDataCadastro(null);
        p.setLoginCadastro(null);
        p.setDataConformidade(null);
        p.setLoginConformidade(null);
        p.setDataDeliberacao(null);
        p.setLoginDeliberacao(null);
        p.setLoginDeliberacaoRecurso(null);
        p.setJustificativaDeliberacao(null);
        p.setDataCertificado(null);
        p.setLoginCertificado(null);
        p.setDataIndeferimentoDeliberacao(null);
        p.setDataDeliberacaoRecurso(null);
        p.setLoginResultadoRecurso(null);
        p.setApontamentos(null);

        return p;
    }

    public Cooperativa salvarDocumentoConformidade(@Valid Cooperativa cooperativa, boolean atualizarData) {
        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());

        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativaBasico(cooperativa.getId()))) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }

        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getParecer().getArquivoConformidade())
                || !fileUploadClient.existeArquivoNoRepositorio(cooperativa.getParecer().getArquivoConformidade())) {
            throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
        }

        if (cooperativaSave.getParecer().getArquivoConformidade() != null && !cooperativaSave.getParecer()
                .getArquivoConformidade().equals(cooperativa.getParecer().getArquivoConformidade())) {
            throw new RegraNegocioException(messages.get(REPOSITORIOS_DIFERENTES));
        }

        // Valida se foi feita submissão com ajustes. Assim, não salva data de aprovação
        // de conformid. legal. Apenas o arquivo
        if (atualizarData) {
            cooperativaSave.getParecer().setLoginConformidade(keycloakService.getUsername());
            cooperativaSave.getParecer().setDataConformidade(new Date());
        }

        cooperativaSave.getParecer().setArquivoConformidade(cooperativa.getParecer().getArquivoConformidade());

        return cooperativaRepository.save(cooperativaSave);
    }

    public Cooperativa salvarDeliberacao(@Valid Cooperativa cooperativa, Boolean deferido) {
        validacaoCooperativa.podeDeferirPedido();

        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativa(cooperativa.getId()))) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }

        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getParecer().getJustificativaDeliberacao())
                && Boolean.TRUE.equals(!deferido)) {
            throw new RegraNegocioException(messages.get(JUSTIFICATIVA_OBRIGATORIA));
        }

        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getParecer().getArquivoDeliberacao())
                || !fileUploadClient.existeArquivoNoRepositorio(cooperativa.getParecer().getArquivoDeliberacao())) {
            throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
        }
        
        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());
        cooperativaSave.getParecer().setLoginDeliberacao(keycloakService.getUsername());
        cooperativaSave.getParecer().setArquivoDeliberacao(cooperativa.getParecer().getArquivoDeliberacao());
        
        if (Boolean.FALSE.equals(deferido)) {
        	cooperativaSave.getParecer().setDataIndeferimentoDeliberacao(new Date());
            cooperativaSave.getParecer()
                    .setJustificativaDeliberacao(cooperativa.getParecer().getJustificativaDeliberacao());
        }

        cooperativaSave.setProgressoCadastroState(progressoCadastroStateFactory.createAguardandoDeliberacaoState(deferido));
        cooperativaSave.trocarEstado();

        gravaProcessoRegistro(
                cooperativaSave,
                Boolean.TRUE.equals(deferido) ? AcaoProcessoRegistroEnum.DEFERIR_PEDIDO : AcaoProcessoRegistroEnum.INDEFERIR_PEDIDO,
                FaseProcessoRegistroEnum.DELIBERACAO
        );

        return cooperativaSave;
    }

    public Cooperativa salvarApontamentos(@Valid Cooperativa cooperativa) {
        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());

        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativa(cooperativa.getId()))) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }

        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getParecer().getApontamentos())) {
            throw new RegraNegocioException(messages.get(APONTAMENTO_OBRIGATORIO));
        }

        cooperativaSave.getParecer().setApontamentos(cooperativa.getParecer().getApontamentos());
        cooperativaSave.setProgressoMacro(ProgressoMacroEnum.PARECER_5);
        cooperativaSave.setProgressoMicro(ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1);
        cooperativa.setAtualizacaoNaoVisualizada(Boolean.TRUE);

        return cooperativaRepository.save(cooperativaSave);
    }

    public Cooperativa salvarRecursoDeliberacao(@Valid Cooperativa cooperativa) {
        validacaoCooperativa.podeSalvarRecursoDeLiberacao();
        
        // A cooperativa do paramentro vem com o cnpj mascarado

        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());
        
        cooperativaSave.setProgressoCadastroState(progressoCadastroStateFactory.createRegistroIndeferidoState(cooperativa));
        cooperativaSave.trocarEstado();

        /* TODO Rever essa regra 
		new RegistrosIndeferidosState(cadastroRegistroService, fileUploadClient, keycloakService, messages,
				cooperativaSave).trocarEstado(cooperativa); */ 

        gravaProcessoRegistro(cooperativaSave, AcaoProcessoRegistroEnum.SOLICITAR_RECURSO, FaseProcessoRegistroEnum.DELIBERACAO);
        return cooperativaRepository.save(cooperativaSave);
    }

    public Cooperativa salvarResultadoRecursoDeliberacao(@Valid Cooperativa cooperativa) {
        validacaoCooperativa.podeSalvarResultadoRecursoDeliberacao();
        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());

        cooperativaSave.setProgressoCadastroState(progressoCadastroStateFactory.createAguardandoLiberacaoState(cooperativa));
        cooperativaSave.trocarEstado();
        // TODO Rever essa regra
		/*new AguardandoLiberacaoState(cadastroRegistroService, cooperativaSave, fileUploadClient, keycloakService,
				messages).trocarEstado(cooperativa); */
        gravaProcessoRegistro(
                cooperativaSave,
                ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1.equals(cooperativaSave.getProgressoMicro()) ? AcaoProcessoRegistroEnum.DEFERIR_RECURSO : AcaoProcessoRegistroEnum.INDEFERIR_RECURSO,
                FaseProcessoRegistroEnum.DELIBERACAO
        );
        return cooperativaRepository.save(cooperativaSave);
     }

    public Cooperativa emitirCertificado(@Valid Cooperativa cooperativa) {
        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());
        
        ProgressoCadastroState progressoCadastroState = progressoCadastroStateFactory.createAguardandoEmissaoState(cooperativa.getParecer().getArquivoResultadoRecurso());
        
        cooperativaSave.setProgressoCadastroState(progressoCadastroState);
        cooperativaSave.trocarEstado();
        disparodeEmails(cooperativaSave, EnvioEmailEventEnum.EMAIL_REGISTRO_DEFERIDO);

        gravaProcessoRegistro(cooperativaSave, AcaoProcessoRegistroEnum.EMITIR_CERTIFICADO, FaseProcessoRegistroEnum.DELIBERACAO);
        
        return cooperativaSave;
    }

    /**
     * @param cooperativa
     * @return cooperativa
     * <p>
     * ESSA FUNÇÃO SÓ DEVE SER USADA VIA IMPORTAÇÃO Refatorar esse método
     */
    public Cooperativa emitirCertificadoViaImportacao(@Valid Cooperativa cooperativa) {
        Cooperativa cooperativaSave = getCooperativa(cooperativa.getId());
        if (cooperativaSave == null) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }

        // Verifica se o certificado já está emitido
        if (ValidacaoCampos.validaCampoPreenchido(cooperativaSave)
                && !ValidacaoCampos.validaCampoPreenchido(cooperativaSave.getNumeroRegistroOCB())) {
            Situacao situacao = new Situacao();
            situacao.setId(NovaSituacaoCooperativaEnum.REGULAR.getCodigo());
            if(cooperativa.getSituacaoCooperativa() != null) {
            	situacao.setId(cooperativa.getSituacaoCooperativa().getId());
            }
            
            Date dataAtual = new Date();
            String usernameLogado = keycloakService.getUsername();

            Parecer parecer = parecerService.criarParecerSeNaoExiste(cooperativaSave.getId());
            cooperativaSave.setParecer(parecer);
            cooperativaSave.getParecer().setDataCertificado(dataAtual);
            cooperativaSave.getParecer().setLoginCertificado(usernameLogado);
            cooperativaSave.setProgressoMacro(null);
            cooperativaSave.setProgressoMicro(null);
            cooperativaSave.setSituacaoCooperativa(situacao);
            Integer sqNumeroRegistroOCB = Integer.valueOf(cooperativaRepository.getNextValSequenciaNumeroRegistroOcb().toString());
            if (sqNumeroRegistroOCB != null) {
                cooperativaSave.setSqNumeroRegistroOCB(sqNumeroRegistroOCB);
                cooperativaSave.setNumeroRegistroOCB(CooperativaUtil.formataNumeroRegistroOCB(sqNumeroRegistroOCB));
            }
            cooperativaSave.setDataAtualizacao(dataAtual);

            CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
            cooperativaRegistro.setCooperativa(cooperativaSave);
            cooperativaRegistro.setSituacao(situacao);
            cooperativaRegistro.setDtAlteracao(dataAtual);
            cooperativaRegistro.setLoginAlteracaoSituacao(usernameLogado);
            cooperativaRegistroService.save(cooperativaRegistro);

            Certificado certificado = new Certificado();
            certificado.setDataGeracao(dataAtual);
            certificado.setCooperativa(cooperativaSave);
            certificado.setCodigoAutenticidade(cooperativaSave.gerarCodigoAutenticidade(dataAtual));
            certificadoService.save(certificado);
            cooperativaSave.setAtualizacaoNaoVisualizada(Boolean.FALSE);

            cooperativaSave = cooperativaRepository.save(cooperativaSave);
        }

        return cooperativaSave;
    }

    public Page<Cooperativa> consultaCooperativa(CooperativaFiltroTO cooperativaFiltro, Pageable pageable) {
        cooperativaFiltro.setCnpj(RemoveMascaraUtil.remove(cooperativaFiltro.getCnpj()));
        Page<Cooperativa> consulta = cooperativaRepository.consultaCooperativa(cooperativaFiltro,
                keycloakService.getFiltro(), pageable);
        if (cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia()) {
            buscaSolicitacaoCooperativa(consulta.getContent());
        }
        return consulta;
    }

    private void buscaSolicitacaoCooperativa(List<Cooperativa> cooperativas) {
        cooperativas.forEach(cooperativa -> cooperativa.setSolicitacaoMudancaEndereco(
                solicitacaoMudancaEnderecoService.obterSolicitacaoMudancaUF(cooperativa.getId())));
    }

    public List<Cooperativa> consultaCooperativaNaoPaginada(CooperativaFiltroTO cooperativaFiltro) {
        return cooperativaRepository.consultaCooperativaNaoPaginado(cooperativaFiltro, keycloakService.getFiltro());
    }

    public List<Cooperativa> getCooperativasVinculadas(Integer idCooperativaPai) {
        return cooperativaRepository.getCooperativasVinculadas(idCooperativaPai);
    }

    public String getStatusCooperativa(Integer idCooperativa) {
        Cooperativa cooperativa = findById(idCooperativa);
        return cooperativaRepository.getStatus(cooperativa.getId());
    }

    public void finalizarProcessoManutencao(Integer idCooperativa) {
        if (keycloakService.isTipoEntidadeCooperativa()) {
            throw new RegraNegocioException("Usuário sem permissão para esta ação");
        }

        cooperativaPendenciaService.marcaValidadoVisualizadoManutencao(idCooperativa);
        Cooperativa cooperativa = findById(idCooperativa);
        cooperativa.setProgressoManutencaoMicro(null);
        cooperativa.setProgressoManutencaoMacro(null);
        cooperativaRepository.save(cooperativa);
    }

    @Transactional(readOnly = true)
    public Page<CooperativaListagemTO> filtrarCooperativaListagemPaginado(CooperativaFiltroTO cooperativaFiltro,
                                                                          Pageable pageable) {
        cooperativaFiltro.setCnpj(RemoveMascaraUtil.remove(cooperativaFiltro.getCnpj()));

        if (cooperativaFiltro.getProcessoTransferencia() != null && cooperativaFiltro.getProcessoTransferencia()) {
            return cooperativaRepository.filtrarCooperativaListagemPaginado(cooperativaFiltro, keycloakService.getFiltro(), pageable);
        } else {
            throw new RegraNegocioException("Consulta inválida, Utilize a api de leitura");
        }
    }

    public List<Cooperativa> filtrarNaoPaginado(CooperativaFiltroTO cooperativaFiltro) throws IllegalAccessException {
        return cooperativaRepository.filtrarNaoPaginado(cooperativaFiltro, keycloakService.getFiltro());
    }

    public byte[] consultaCooperativaExcel(CooperativaFiltroTO cooperativaFiltro) {
        cooperativaFiltro.setCnpj(RemoveMascaraUtil.remove(cooperativaFiltro.getCnpj()));
        byte[] file = null;

        // consulta cooperativas em proc. de registro
        List<CooperativaListagemProcessoRegistroTO> result = cooperativaRepository
                .filtrarCooperativaListagemProcessoRegistroExcel(cooperativaFiltro, keycloakService.getFiltro());

        if (result.isEmpty()) {
            throw new RegraNegocioException(NAO_HA_REGISTROS_EXPORT, HttpStatus.NOT_FOUND);
        }

        // adiciona responsáveis
        result.forEach(coop -> {
            List<CooperativaResponsavel> responsaveis = cooperativaResponsavelRepository
                    .findCooperativaResponsavelByIdPessoaJuridica(coop.getId());
            if (!responsaveis.isEmpty()) {
                coop.setResponsavel(
                        responsaveis.stream().map(CooperativaResponsavel::getNome).collect(Collectors.joining(", ")));
                coop.setTelefone(responsaveis.stream().map(CooperativaResponsavel::getTelefone)
                        .collect(Collectors.joining(", ")));
            }
        });

        List<String> cabecalho = null;
        List<List<String>> linhas = new ArrayList<>();
        List<Integer> larguras = null;

        if (keycloakService.isTipoEntidadeNacional()) {
            if(cooperativaFiltro.getApontamento() != null && cooperativaFiltro.getApontamento()) {
                cabecalho = Arrays.asList(NUMERO_PROCESSO, "CNPJ", NOME_FANTASIA, "Ramo", "Grau", RESPONSAVEL, TELEFONE,
                        UF, DATA_SOLICITACAO, PRAZO, FASE_DO_PROCESSO, DATA_ATUALIZACAO, "Data do apontamento", "Data da Constituição");
                larguras = Arrays.asList(LARGURA_20, LARGURA_20, LARGURA_45, LARGURA_18, LARGURA_18, LARGURA_30, LARGURA_14, LARGURA_4, LARGURA_14, 
                		LARGURA_14, LARGURA_36, LARGURA_25, LARGURA_20, LARGURA_20);
                result.forEach(obj -> linhas.add(obj.objectToStringArrayUN()));
            }else{
                cabecalho = Arrays.asList(NUMERO_PROCESSO, "CNPJ", NOME_FANTASIA, "Ramo", "Grau", RESPONSAVEL, TELEFONE,
                        UF, DATA_SOLICITACAO, PRAZO, FASE_DO_PROCESSO, DATA_ATUALIZACAO, "Data da Constituição");
                larguras = Arrays.asList(LARGURA_20, LARGURA_20, LARGURA_45, LARGURA_18, LARGURA_18, LARGURA_30, LARGURA_14, 
                		LARGURA_4, LARGURA_14, LARGURA_14, LARGURA_36, LARGURA_25, LARGURA_25);
                result.forEach(obj -> {
                    linhas.add(obj.objectToStringArrayUNSemDataApontamento());
                });
            }
        }

        if (keycloakService.isTipoEntidadeEstadual()) {
            cabecalho = Arrays.asList(NUMERO_PROCESSO, "CNPJ", NOME_FANTASIA, "Ramo", "Grau", RESPONSAVEL, TELEFONE,
                    DATA_SOLICITACAO, PRAZO, FASE_DO_PROCESSO);
            result.forEach(obj -> linhas.add(obj.objectToStringArrayUE()));
        }

        file = montaRelatorio(file, cabecalho, linhas, larguras);

        result = null;
        cabecalho = null;
        larguras = null;

        return file;
    }


    private byte[] montaRelatorio(byte[] file, List<String> cabecalho, List<List<String>> linhas,
                                  List<Integer> larguras) {
        if (!linhas.isEmpty()) {
            try {
                RelatorioExpressTO relatorio = new RelatorioExpressTO();
                relatorio.setCabecalho(cabecalho);
                relatorio.setDados(linhas);
                relatorio.setLarguras(larguras);

                file = relatorioClient.gerarRelatorio(relatorio);
            } catch (Exception e) {
                throw new ErroSistemaException(messages.get(ERRO_PLANILHA),e);
            }
        }
        return file;
    }

    private Cooperativa getCooperativa(Cooperativa coop) {
        Optional<Cooperativa> cooperativaOptional = cooperativaRepository.findById(coop.getId());
        if (cooperativaOptional.isPresent()) {
            return cooperativaOptional.get();
        } else {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
    }

    public Cooperativa inativarCooperativa(CooperativaRegistro cooperativaRegistro) {

        validacaoCooperativa.podeInativarCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(cooperativaRegistro.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // inativar só pode ser feito pela UN
        if (!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
        }

        if (ValidacaoCampos.validaCampoPreenchido(cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao())) {
            if (ValidacaoCampos.validaCampoPreenchido(
                    cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao().getNecessitaDocumento())
                    && cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao().getNecessitaDocumento()
                    .equals(Boolean.TRUE)
                    && !fileUploadClient.existeArquivoNoRepositorio(cooperativaRegistro.getAnexo())) {
                throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
            }
        }

        // valida cooperativaSolicitacao
        if (ValidacaoCampos.validaCampoPreenchido(cooperativaRegistro.getCooperativa().getSolicitacaoInativacao())
                && Boolean.TRUE.equals(!cooperativaRegistro.getCooperativa().getSolicitacaoInativacao())) {
        	CooperativaSolicitacaoService.validaCooperativaSolicitacao(cooperativaRegistro.getCooperativaSolicitacao());
        }


        // verifica se existe arquivo no repositório e se preencheu a justificativa

        // para inativar uma cooperativa, ela deve estar com a situação Ativa, o status
        // Irregular,
        // apensa usuários com o perfil de UN podem fazer esse processo
        Optional<Cooperativa> opCoop = cooperativaRepository.findById(cooperativaRegistro.getCooperativa().getId());
        if (opCoop.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        } else {
            Cooperativa cooperativa = opCoop.get();

            // verifica se a cooperativa está ativa e irregular
			if (verificaCooperativaIrregular(cooperativa.getSituacaoCooperativa().getId())) {

				Situacao situacaoAnterior = cooperativa.getSituacaoCooperativa();
				cooperativa.setSituacaoCooperativa(getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum.SUSPENSA));
                cooperativa.setJustificativaInativada(cooperativaRegistro.getCooperativa().getJustificativaInativada());
                cooperativa.setSolicitacaoInativacao(null); // remove a solicitação de inativação, uma vez que ela está
                // inativada
                cooperativa.setJustificativaSolicitacaoInativacao(null);
                cooperativa.setJustificativaAtivacao(null);
                cooperativaRepository.save(cooperativa);
                
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_SUSPENDE_COOPERATIVA);
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
                cooperativaSolicitacaoService.salvar(cooperativaRegistro.getCooperativaSolicitacao());
                disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_INATIVAR_COOP);
            } else { // cooperativa não está ativa ou irregular
				throw new RegraNegocioException(messages.get(COOPERATIVA_REGRA_SUSPENSAO));
            }

            Optional<Cooperativa> cooperativaOptional = cooperativaRepository
                    .findById(cooperativaRegistro.getCooperativa().getId());
            if (cooperativaOptional.isPresent()) {
                return cooperativaOptional.get();
            } else {
                throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
            }
        }
    }

	private boolean verificaCooperativaIrregular(Integer idSituacaoCooperativa) {
		return Objects.equals(idSituacaoCooperativa, NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo());
	}

    public Cooperativa recusaSolicitacaoInativacao(@Valid CooperativaApresentacaoTO coop) {

        validacaoCooperativa.podeRecusarSolicitacaoInativacaoCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativaManutencao(coop.getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        Cooperativa cooperativa = getCooperativaPeloId(coop.getId());

        if (cooperativa != null && cooperativa.getSolicitacaoInativacao() == null) {
            throw new RegraNegocioException("Não existe solicitação para inativação da cooperativa!");
        }

        try {
            // manter cooperativa ativa só pode ser feito pela UN
            if (keycloakService.isTipoEntidadeNacional()) {
                // verifica se existe uma solicitação de inativação da cooperativa
                // e se a cooperativa está ativa e irregular
                if (cooperativa != null && Boolean.TRUE.equals(cooperativa.getSolicitacaoInativacao())
						&& NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo()
								.equals(cooperativa.getSituacaoCooperativa().getId())) {

                    cooperativa.setSolicitacaoInativacao(null);
                    cooperativa.setJustificativaSolicitacaoInativacao(null);
                    cooperativa.setJustificativaAtivacao(coop.getJustificativaAtivacao());

                    CooperativaRegistro cr = new CooperativaRegistro();
                    cr.setSolicitacaoInativacao(null);
                    cr.setJustificativaSolicitacaoInativacao(null);
                    cr.setJustificativaAtivacao(coop.getJustificativaAtivacao());
					cr.setTipoAcao(TipoAcaoEnum.UN_RECUSA_SOLICITACAO_SUSPENSAO);

                    cooperativaRepository.save(cooperativa);
					cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cr, null);
                } else { // cooperativa não está irregular ou ativa ou não existe uma solicitação de
                    // inativação
					throw new RegraNegocioException(messages.get(COOPERATIVA_REGRA_SUSPENSAO));
                }

            } else { // não possui perfil de UN
                throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
            }

        } catch (Exception e) { // erro nas transações do banco COOPERATIVA ou COOPERATIVA_REGISTRO

            throw new RegraNegocioException(messages.get(ERRO_OPERACAO),e);
        }
        disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_MANTER_SITUACAO_COOPERATIVA);

//        cooperativa = null;

        return getCooperativa(cooperativa);
    }

    public Cooperativa aceitaSolicitacaoInativacao(CooperativaRegistro cooperativaRegistro) {

        validacaoCooperativa.podeAceitarSolicitacaoInativacaoCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(cooperativaRegistro.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // inativar só pode ser feito pela UN
        if (!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
        }

        if (ValidacaoCampos.validaCampoPreenchido(cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao())) {
            if (ValidacaoCampos.validaCampoPreenchido(
                    cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao().getNecessitaDocumento())
                    && cooperativaRegistro.getCooperativaSolicitacao().getSolicitacao().getNecessitaDocumento().equals(Boolean.TRUE)) {
            	if(Boolean.FALSE.equals(verificaSeExisteArquivoAnexoNoRepositorio(cooperativaRegistro)) && !ValidacaoCampos.validaCampoPreenchido(cooperativaRegistro.getRegistroEmail())) {
            		throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
            	}
            }
        }

        // valida cooperativaSolicitacao
        if (ValidacaoCampos.validaCampoPreenchido(cooperativaRegistro.getCooperativa().getSolicitacaoInativacao())
                && Boolean.TRUE.equals(!cooperativaRegistro.getCooperativa().getSolicitacaoInativacao())) {
            CooperativaSolicitacaoService.validaCooperativaSolicitacao(cooperativaRegistro.getCooperativaSolicitacao());
        }

        // para inativar uma cooperativa, ela deve estar com a situação Ativa, o status
        // Irregular,
        // apensa usuários com o perfil de UN podem fazer esse processo
        Cooperativa cooperativa = getCooperativaPeloId(cooperativaRegistro.getCooperativa().getId());
        // verifica se a cooperativa está ativa e irregular
		if (verificaCooperativaIrregular(cooperativa.getSituacaoCooperativa().getId())) {

			Situacao situacaoAnterior = cooperativa.getSituacaoCooperativa();
			cooperativa.setSituacaoCooperativa(getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum.SUSPENSA));// INATIVADA
            cooperativa.setJustificativaInativada(cooperativaRegistro.getCooperativa().getJustificativaInativada());
            cooperativa.setSolicitacaoInativacao(null);
            
            cooperativa.setJustificativaSolicitacaoInativacao(null);
            cooperativaRepository.save(cooperativa);
            
            // buscar solicitacao anterior para referenciar a solicitacao aceita
            cooperativaRegistro.setCooperativaSolicitacao(buscaUltimoHistorico(cooperativa.getId()).getCooperativaSolicitacao());
            
            cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_ACEITA_SOLICITACAO_SUSPENSAO);
			cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
            cooperativaSolicitacaoService.salvar(cooperativaRegistro.getCooperativaSolicitacao());
            disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_INATIVAR_COOP);

            cooperativa = null;

        } else { // cooperativa não está ativa ou irregular
			throw new RegraNegocioException(messages.get(COOPERATIVA_REGRA_SUSPENSAO));
        }

        Optional<Cooperativa> cooperativaOptional = cooperativaRepository
                .findById(cooperativaRegistro.getCooperativa().getId());
        if (cooperativaOptional.isPresent()) {
            return cooperativaOptional.get();
        } else {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
    }

    private boolean verificaSeExisteArquivoAnexoNoRepositorio(CooperativaRegistro cooperativaRegistro) {
		boolean anexo = false;
		boolean anexoNotificacao = false;
		
		if(cooperativaRegistro.getAnexo() != null && !cooperativaRegistro.getAnexo().isBlank()) {
			anexo = fileUploadClient.existeArquivoNoRepositorio(cooperativaRegistro.getAnexo());
		}
		if(cooperativaRegistro.getAnexoNotificacao() != null && !cooperativaRegistro.getAnexoNotificacao().isBlank()) {
			anexoNotificacao = fileUploadClient.existeArquivoNoRepositorio(cooperativaRegistro.getAnexoNotificacao());
		}
    	
		return anexo || anexoNotificacao;
	}

	public CooperativaRegistro solicitaCancelamentoCooperativa(CooperativaRegistro cooperativaRegistro) {

        validacaoCooperativa.podeSolicitacaoCancelamentoCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(cooperativaRegistro.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // Verifica se justificativa foi preenchida
        if (!ValidacaoCampos.validaCampoPreenchido(
                cooperativaRegistro.getCooperativa().getJustificativaSolicitacaoCancelamento())) {
            throw new RegraNegocioException(COOPERATIVA_JUSTIFICATIVA_OBRIGATORIA);
        }

        if (!fileUploadClient.existeArquivoNoRepositorio(cooperativaRegistro.getAnexo())) {
            throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
        }

        // carrega objeto com os dados da cooperatativa
        Cooperativa cooperativa = this.getCooperativa(cooperativaRegistro.getCooperativa().getId());

        // verifica se já existe alguma solicitação pendente
        if (ValidacaoCampos.validaCampoPreenchido(cooperativa)
                && (ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoAtivacao())
                || ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoCancelamento())
                || ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoInativacao()))) {
            throw new RegraNegocioException(messages.get(SOLICITACAO_SITUACAO_PENDENTE));
        }

        try {
            cooperativa.setJustificativaSolicitacaoCancelamento(
                    cooperativaRegistro.getCooperativa().getJustificativaSolicitacaoCancelamento());
            cooperativa.setSolicitacaoCancelamento(Boolean.TRUE);
            cooperativa.setJustificativaAtivacao(null);
            cooperativaRepository.save(cooperativa);
            cooperativaRegistro.getCooperativaSolicitacao().setCooperativa(cooperativa);
            cooperativaSolicitacaoService.salvar(cooperativaRegistro.getCooperativaSolicitacao());

            cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO);

			cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, null);
        } catch (Exception e) {
            throw new RegraNegocioException(ERRO_OPERACAO,e);
        }

        Optional<Cooperativa> coopOptional = cooperativaRepository
                .findById(cooperativaRegistro.getCooperativa().getId());
        if (coopOptional.isPresent()) {
            cooperativaRegistro.setCooperativa(coopOptional.get());
        } else {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_SOLICITAR_CANCELAMENTO);

        cooperativa = null;

        return cooperativaRegistro;
    }
	
	public void solicitaCancelamentoCooperativa(CooperativaSolicitacaoCancelamentoTO cooperativaSolicitacaoCancelamentoTO) {
		
        validacaoCooperativa.podeSolicitacaoCancelamentoCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(cooperativaSolicitacaoCancelamentoTO.getIdCooperativa()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // Verifica se justificativa foi preenchida
        if (!ValidacaoCampos.validaCampoPreenchido(
        		cooperativaSolicitacaoCancelamentoTO.getJustificativaSolicitacaoCancelamento())) {
            throw new RegraNegocioException(COOPERATIVA_JUSTIFICATIVA_OBRIGATORIA);
        }

        if (!fileUploadClient.existeArquivoNoRepositorio(cooperativaSolicitacaoCancelamentoTO.getAnexo())) {
            throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
        }

        // carrega objeto com os dados da cooperatativa
        Cooperativa cooperativa = this.getCooperativa(cooperativaSolicitacaoCancelamentoTO.getIdCooperativa());

        // verifica se já existe alguma solicitação pendente
        if (ValidacaoCampos.validaCampoPreenchido(cooperativa)
                && (ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoAtivacao())
                || ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoCancelamento())
                || ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoInativacao()))) {
            throw new RegraNegocioException(messages.get(SOLICITACAO_SITUACAO_PENDENTE));
        }

        try {
        	CooperativaRegistro cooperativaRegistro = cooperativaRegistroService.getCooperativaRegistroByIdCooperativa(cooperativaSolicitacaoCancelamentoTO.getIdCooperativa());
        	Optional<Solicitacao> solicitacao = solicitacaoService.getSolicitacao(cooperativaSolicitacaoCancelamentoTO.getIdSolicitacao());
        	cooperativaRegistro.setAnexo(cooperativaSolicitacaoCancelamentoTO.getAnexo());
        	
            cooperativa.setJustificativaSolicitacaoCancelamento(cooperativaSolicitacaoCancelamentoTO.getJustificativaSolicitacaoCancelamento());
            cooperativa.setSolicitacaoCancelamento(Boolean.TRUE);
            cooperativa.setJustificativaAtivacao(null);
            cooperativaRepository.save(cooperativa);
            cooperativaRegistro.setCooperativaSolicitacao(new CooperativaSolicitacao());
            cooperativaRegistro.getCooperativaSolicitacao().setCooperativa(cooperativa);
            if (solicitacao.isPresent()) {            	
            	cooperativaRegistro.getCooperativaSolicitacao().setSolicitacao(solicitacao.get());
            }
            
            cooperativaSolicitacaoService.salvar(cooperativaRegistro.getCooperativaSolicitacao());

            cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO);

			cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, null);
        } catch (Exception e) {
            throw new RegraNegocioException(ERRO_OPERACAO,e);
        }
        
        disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_SOLICITAR_CANCELAMENTO);

        cooperativa = null;
    }

    public void statusEmPreenchimento(@Valid Cooperativa coop){
        if(!coop.isInPreenchimento()) {
            cooperativaRepository.alterarStatusEmPreenchimento(coop.getId(), true);
        }
    }

    public Cooperativa recusaSolicitacaoCancelamento(@Valid CooperativaApresentacaoTO coop) {

        validacaoCooperativa.podeRecusarSolicitacaoCancelamentoCooperativa();
        // recusa de cancelamento só pode ser feito pela UN
        if (!keycloakService.isTipoEntidadeNacional() && !keycloakService.isTipoEntidadeEstadual()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
        }

        Optional<Cooperativa> opt = cooperativaRepository.findById(coop.getId());
        Cooperativa cooperativa = opt.isPresent() ? opt.get() : null;
        // cooperativa deve estar inativa
        if (cooperativa != null) {
            try {
                cooperativa.setSolicitacaoCancelamento(null);
                cooperativa.setJustificativaSolicitacaoCancelamento(null);
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();

                cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO);
                
                if (ValidacaoCampos.validaCampoPreenchido(cooperativa.getSituacaoCooperativa()) && cooperativa
						.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.REGULAR.getCodigo())) {
                    cooperativa.setJustificativaAtivacao(coop.getJustificativaInativada());
                    cooperativa.setJustificativaInativada(null);
                }

                if (ValidacaoCampos.validaCampoPreenchido(cooperativa.getSituacaoCooperativa()) && cooperativa
						.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.SUSPENSA.getCodigo())) {
                    cooperativa.setJustificativaInativada(coop.getJustificativaInativada());
                }

                cooperativa = cooperativaRepository.save(cooperativa);
                cooperativaRegistro.setCooperativa(cooperativa);
				this.criaHistorico(cooperativa, cooperativaRegistro, null);
            } catch (Exception e) {

                throw new RegraNegocioException("Não foi possível cancelar a solicitação",e);
            }
        } else {
			throw new RegraNegocioException(COOPERATIVA_REGRA_SUSPENSAO);
        }
        disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_MANTER_SITUACAO_CANCELAMENTO_COOPERATIVA);
        return getCooperativa(cooperativa);
    }

	private void criaHistorico(Cooperativa cooperativa, CooperativaRegistro cooperativaRegistro, Situacao situacaoAnterior) {
		cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
    }

    public CooperativaRegistro solicitaInativacaoCooperativa(CooperativaRegistroTO cooperativaRegistroTo) {

        CooperativaRegistro cooperativaRegistro = cooperativaRegistroTo.getCooperativaRegistro();
        validacaoCooperativa.podeSolicitarInativacaoCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(cooperativaRegistro.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // carrega objeto com os dados da cooperatativa
        Cooperativa cooperativa = this.getCooperativa(cooperativaRegistro.getCooperativa().getId());

        // verifica se já existe alguma solicitação pendente
        if (ValidacaoCampos.validaCampoPreenchido(cooperativa)
                && (ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoAtivacao())
                || ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoCancelamento())
                || (ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoInativacao()) && cooperativa.getSolicitacaoInativacao().equals(Boolean.TRUE)))) {
            throw new RegraNegocioException(messages.get(SOLICITACAO_SITUACAO_PENDENTE));
        }

        solicitarInativacaoEnviaEmail(cooperativaRegistroTo, cooperativa);

        Optional<Cooperativa> coopOptional = cooperativaRepository
                .findById(cooperativaRegistro.getCooperativa().getId());
        if (ValidacaoCampos.validaCampoPreenchido(coopOptional)) {
            cooperativaRegistro.setCooperativa(coopOptional.get());
        } else {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_SOLICITAR_SUSPENSAO);

        cooperativa = null;

        return cooperativaRegistro;
    }


    protected void solicitarInativacaoEnviaEmail(CooperativaRegistroTO cooperativaRegistroTo, @Valid Cooperativa cooperativa) {

        // para solicitar uma inativação, a cooperativa precisa estar ativa e irregular
        if (verificaCooperativaIrregular(cooperativa.getSituacaoCooperativa().getId())) {

            Boolean solicitacaoInativacao = Boolean.TRUE;

            // Notifica cooperativa via e-mail caso cooperativa nao tenha sido notificada anteriormente
            if(!cooperativaRegistroTo.isJaNotificada() && cooperativaRegistroTo.isNotificarPorEmail()
                    && cooperativaRegistroTo.getCooperativaRegistro().getAnexoNotificacao() == null) {
                cooperativaRegistroTo.getCooperativaRegistro().setRegistroEmail(this.emailService.enviaEmailNotificarSuspensao(cooperativa));
                cooperativaRegistroTo.getCooperativaRegistro().setTipoAcao(TipoAcaoEnum.UE_NOTIFICA_SUSPENSAO);
                solicitacaoInativacao = Boolean.FALSE;
            } else {
                cooperativaRegistroTo.getCooperativaRegistro().setTipoAcao(TipoAcaoEnum.UE_SOLICITA_SUSPENSAO);
            }

            try {
                cooperativa.setJustificativaSolicitacaoInativacao(
                cooperativaRegistroTo.getCooperativaRegistro().getCooperativa().getJustificativaSolicitacaoInativacao());
                cooperativa.setSolicitacaoInativacao(solicitacaoInativacao);
                cooperativa.setJustificativaAtivacao(null);
                cooperativaRepository.save(cooperativa);
                cooperativaSolicitacaoService.salvar(cooperativaRegistroTo.getCooperativaRegistro().getCooperativaSolicitacao());
                cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistroTo.getCooperativaRegistro(), null);

            } catch (Exception e) {
                throw new RegraNegocioException(ERRO_OPERACAO,e);
            }
        }
    }

    public Cooperativa cancelaSolicitacaoCancelamentoEnviada(@Valid CooperativaApresentacaoTO coop) {
        validacaoCooperativa.podeCancelarSolicitacaoCancelamentoEnviada();

        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativaManutencao(coop.getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // carrega objeto com os dados da cooperatativa
        Cooperativa cooperativa = this.getCooperativa(coop.getId());

        // Verifica se justificativa foi preenchida
        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoCancelamento())) {
            throw new RegraNegocioException(SEM_SOLICITACAO_CANCELAMENTO);
        }

        // para solicitar um cancelamento, a cooperativa precisa estar inativa,
        // irregular
        if (Boolean.TRUE.equals(cooperativa.getSolicitacaoCancelamento())) {
            try {
                cooperativa.setJustificativaSolicitacaoCancelamento(null);
                cooperativa.setSolicitacaoCancelamento(null);
                cooperativaRepository.save(cooperativa);
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
                cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UE_CANCELA_SOLICITACAO_CANCELAMENTO);
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, null);
            } catch (Exception e) {
                throw new RegraNegocioException(ERRO_OPERACAO,e);
            }

        } else {
            throw new RegraNegocioException("Não existe solicitação de cancelamento.");
        }

//        cooperativa = null;

        return getCooperativa(cooperativa);

    }

    public Cooperativa cancelaSolicitacaoInativacaoEnviada(Integer id) {
        validacaoCooperativa.podeCancelarSolicitacaoInativacaoEnviada();

        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativaManutencao(id))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // carrega objeto com os dados da cooperatativa
        Cooperativa cooperativa = this.getCooperativa(id);
        
        // Verifica se justificativa foi preenchida
        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoInativacao())) {
            throw new RegraNegocioException(SEM_SOLICITACAO_INATIVACAO);
        }

		// para solicitar uma inativação, a cooperativa precisa estar ativa e irregular
		if (verificaCooperativaIrregular(cooperativa.getSituacaoCooperativa().getId())) {
            try {
                cooperativa.setJustificativaSolicitacaoInativacao(null);
                cooperativa.setSolicitacaoInativacao(null);
                cooperativaRepository.save(cooperativa);
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UE_CANCELA_SOLICITACAO_SUSPENSAO);
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, null);
            } catch (Exception e) {
                throw new RegraNegocioException(ERRO_OPERACAO,e);
            }

        }

//        cooperativa = null;

        return getCooperativa(cooperativa);

    }

    public Cooperativa cancelaRegistroCooperativa(CooperativaRegistro coopRegistro) {

        validacaoCooperativa.podeCancelarCooperativa();

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(coopRegistro.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // inativar só pode ser feito pela UN
        if (!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
        }

        // verifica se existe o upload do arquivo
        if (!ValidacaoCampos.validaCampoPreenchido(coopRegistro.getCooperativa().getSolicitacaoCancelamento())
                && !fileUploadClient.existeArquivoNoRepositorio(coopRegistro.getAnexo())) {
            throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
        }

        // verifica se existe arquivo no repositório e se preencheu a justificativa

        // para inativar uma cooperativa, ela deve estar com a situação Ativa, o status
        // Irregular,
        // apensa usuários com o perfil de UN podem fazer esse processo

        Optional<Cooperativa> optional = cooperativaRepository.findById(coopRegistro.getCooperativa().getId());
        Cooperativa cooperativa = optional.isPresent() ? optional.get() : null;

		// verifica se a cooperativa não está cancelada
		if (cooperativa != null && ValidacaoCampos.validaCampoPreenchido(cooperativa.getSituacaoCooperativa().getId())) {
			
			CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();

			if (cooperativa.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.REGULAR.getCodigo())) {
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_CANCELA_COOPERATIVA_REGULAR);
			}

			if (cooperativa.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo())) {
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_CANCELA_COOPERATIVA_IRREGULAR);
            }

			if (cooperativa.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.SUSPENSA.getCodigo())) {
                cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_CANCELA_COOPERATIVA);
            }

			Situacao situacaoAnterior = cooperativa.getSituacaoCooperativa();
			cooperativa.setSituacaoCooperativa(getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum.CANCELADA));// CANCELADA
            cooperativa.setJustificativaCancelada(null);
            if (ValidacaoCampos
                    .validaCampoPreenchido(coopRegistro.getCooperativa().getJustificativaCancelada())) {
                cooperativa.setJustificativaCancelada(coopRegistro.getCooperativa().getJustificativaCancelada());
            }
            cooperativa.setSolicitacaoInativacao(null); // remove a solicitação de inativação, uma vez que ela está
            // inativada
            cooperativa.setSolicitacaoCancelamento(null);
            cooperativa.setSolicitacaoAtivacao(null);
            cooperativa.setJustificativaAtivacao(null);
            cooperativa = cooperativaRepository.save(cooperativa);
			if (cooperativa.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.REGULAR.getCodigo())) {
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_CANCELA_COOPERATIVA_REGULAR);
            }
			cooperativaRegistro.setAnexo(coopRegistro.getAnexo());
			cooperativaRegistro.setJustificativaCancelada(coopRegistro.getJustificativaCancelada());
			cooperativaRegistro.setCooperativaSolicitacao(coopRegistro.getCooperativaSolicitacao());
			cooperativaSolicitacaoService.salvar(coopRegistro.getCooperativaSolicitacao());
			cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
        } else { // cooperativa não está ativa ou irregular
            throw new RegraNegocioException(messages.get(COOPERATIVA_REGRA_CANCELAR));
        }

		return getCooperativa(cooperativa);
    }

    public Cooperativa cancelaSolicitacaoInativacaoApontamentoIrregularidade(@Valid Cooperativa coop) {

        if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativaManutencao(coop.getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // carrega objeto com os dados da cooperatativa
        Cooperativa cooperativa = this.getCooperativa(coop.getId());

        // Verifica se existe solicitação de inativação que é gerado no apontamento de
        // irregularidade
        if (!ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoInativacao())) {
            throw new RegraNegocioException("Não existe apontamento de irregularidade cadastrado!");
        }

        // Verifica se cooperativa está irregular
		if (!Objects.equals(cooperativa.getSituacaoCooperativa().getId(), NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo())) {
            throw new RegraNegocioException("Cooeprativa não está Irregular!");
        }

        // para solicitar uma inativação, a cooperativa precisa estar ativa, irregular
		if (verificaCooperativaIrregular(cooperativa.getSituacaoCooperativa().getId())
                && Boolean.TRUE.equals(cooperativa.getSolicitacaoInativacao())
                && cooperativa.getJustificativaIrregular() != null) {

            try {
                cooperativa.setSolicitacaoInativacao(null);
                cooperativa.setJustificativaSolicitacaoInativacao(null);
                cooperativaRepository.save(cooperativa);
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, null);
            } catch (Exception e) {
                throw new RegraNegocioException(
                        "NÃO foi possível cancelar a solicitação de inativação da cooperativa.",e);
            }

        }

        cooperativa = null;

        return getCooperativa(coop);
    }

    public Cooperativa aceitaSolicitacaoCancelamento(CooperativaRegistro cooperativaRegistro) {

        // validação padrão
        if (Boolean.FALSE.equals(cadastroRegistroService
                .podePreencherCadastroRegistroCooperativaManutencao(cooperativaRegistro.getCooperativa().getId()))) {
            throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
        }

        // cancelar só pode ser feito pela UN
        if (!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
        }

        // verifica se existe o upload do arquivo
        if (!ValidacaoCampos.validaCampoPreenchido(cooperativaRegistro.getCooperativa().getSolicitacaoCancelamento())
                && !fileUploadClient.existeArquivoNoRepositorio(cooperativaRegistro.getAnexo())) {
            throw new RegraNegocioException(messages.get(NENHUM_ANEXO_ENCONTRADO));
        }

        // verifica se existe arquivo no repositório e se preencheu a justificativa
        // para aceitar uma solicitacao de cancelamento uma cooperativa, ela deve estar
        // com a situação inativa, o status Irregular,
        // possuir uma solicitacao de cancelamento
        // apensa usuários com o perfil de UN podem fazer esse processo
        Optional<Cooperativa> optional = cooperativaRepository.findById(cooperativaRegistro.getCooperativa().getId());
        Cooperativa cooperativa = optional.isPresent() ? optional.get() : null;

        // verifica se a cooperativa está inativa e irregular
        if (cooperativa != null && ValidacaoCampos.validaCampoPreenchido(cooperativa.getSituacaoCooperativa())
                && ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoCancelamento())) {

            cooperativa.setJustificativaCancelada(cooperativaRegistro.getCooperativa().getJustificativaCancelada());
            cooperativa.setSolicitacaoCancelamento(null);
            cooperativa.setJustificativaSolicitacaoCancelamento(null);
			Situacao situacaoAnterior = cooperativa.getSituacaoCooperativa();
			cooperativa.setSituacaoCooperativa(getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum.CANCELADA));// CANCELADA
            cooperativaRepository.save(cooperativa);
            
            cooperativaRegistro.setCooperativaSolicitacao(buscaUltimoHistorico(cooperativa.getId()).getCooperativaSolicitacao());
            cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_ACEITA_SOLICITACAO_CANCELAMENTO);
            cooperativaRegistro.setCooperativa(cooperativa);
			cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
        } else { // cooperativa não está ativa ou irregular
            throw new RegraNegocioException(messages.get(COOPERATIVA_REGRA_CANCELAR));
        }
        disparodeEmails(cooperativa, EnvioEmailEventEnum.EMAIL_ACEITAR_SOLICITACAO_CANCELAMENTO);
        Optional<Cooperativa> cooperativaOptional = cooperativaRepository
                .findById(cooperativaRegistro.getCooperativa().getId());
        if (cooperativaOptional.isPresent()) {
            return cooperativaOptional.get();
        } else {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Unidade Nacional torna uma cooperativa cancelada em inativa
     *
     * @param coop
     * @returnax
     */
    public Cooperativa tornarCooperativaInativa(@Valid Cooperativa coop) {
        validacaoCooperativa.podeTonarInativaCooperativa();

        // validação padrão

        // inativar só pode ser feito pela UN
        if (!keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_ALTERAR));
        }

        Cooperativa cooperativa = getCooperativaPeloId(coop.getId());

		// verifica se cooperativa está irregular
		if (cooperativa.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo())) {
            try {
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_SUSPENDE_COOPERATIVA_CANCELADA);
                cooperativa.setJustificativaInativada(coop.getJustificativaInativada());
				Situacao situacaoAnterior = cooperativa.getSituacaoCooperativa();
				cooperativa.setSituacaoCooperativa(getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum.SUSPENSA));
                cooperativa.setSolicitacaoInativacao(null);
                cooperativa.setJustificativaSolicitacaoInativacao(null);
                cooperativa.setJustificativaSolicitacaoAtivacao(null);
                cooperativa.setJustificativaCancelada(null);
                cooperativa.setSolicitacaoCancelamento(null);
                cooperativa.setJustificativaSolicitacaoCancelamento(null);
                cooperativa.setSolicitacaoAtivacao(null);
                cooperativa.setJustificativaAtivacao(null);
                cooperativaRepository.save(cooperativa);
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
            } catch (Exception e) {
                throw new RegraNegocioException(ERRO_ATIVAR_COOPERATIVA,e);
            }
		} else {
			throw new RegraNegocioException(COOPERATIVA_REGRA_SUSPENSAO);
        }

        cooperativa = null;

        return getCooperativa(coop);
    }
    
    /**
     * Unidade Nacional torna uma cooperativa Irregular em inativa
     *
     * @param coopRegistro
     * @returnax
     */
    public Cooperativa suspenderCooperativa(CooperativaRegistro coopRegistro) {
        validacaoCooperativa.podeTonarInativaCooperativa();

        Cooperativa coop =  coopRegistro.getCooperativa(); 
        // validação padrão

        Cooperativa cooperativa = getCooperativaPeloId(coop.getId());
        
        coopRegistro.getCooperativaSolicitacao().setCooperativa(cooperativa);
        

		// verifica se cooperativa está irregular
		if (cooperativa.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo())) {
            try {
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
				cooperativaRegistro.setTipoAcao(TipoAcaoEnum.UN_SUSPENDE_COOPERATIVA);
				cooperativaRegistro.setJustificativaInativada(coop.getJustificativaInativada());
				cooperativaRegistro.setCooperativaSolicitacao(coopRegistro.getCooperativaSolicitacao());
				cooperativaRegistro.setAnexo(coopRegistro.getAnexo());
                cooperativa.setJustificativaInativada(coop.getJustificativaInativada());
                cooperativa.setJustificativaSolicitacaoInativacao(
                		coopRegistro.getCooperativa().getJustificativaSolicitacaoInativacao());
				Situacao situacaoAnterior = cooperativa.getSituacaoCooperativa();
				cooperativa.setSituacaoCooperativa(getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum.SUSPENSA));
                cooperativa.setSolicitacaoInativacao(null);
                cooperativa.setJustificativaSolicitacaoInativacao(null);
                cooperativa.setJustificativaSolicitacaoAtivacao(null);
                cooperativa.setJustificativaCancelada(null);
                cooperativa.setSolicitacaoCancelamento(null);
                cooperativa.setJustificativaSolicitacaoCancelamento(null);
                cooperativa.setSolicitacaoAtivacao(null);
                cooperativa.setJustificativaAtivacao(null);
                cooperativa = cooperativaRepository.save(cooperativa);
                
                cooperativaSolicitacaoService.salvar(coopRegistro.getCooperativaSolicitacao());
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, cooperativaRegistro, situacaoAnterior);
            } catch (Exception e) {
                throw new RegraNegocioException(ERRO_SUSPENDER_COOPERATIVA,e);
            }
		} else {
			throw new RegraNegocioException(COOPERATIVA_REGRA_SUSPENSAO);
        }

        cooperativa = null;

        return getCooperativa(coop);
    }

    public Cooperativa cancelaAnaliseDadosAtualizaca(@Valid Cooperativa cooperativa) {

        // cancelar só pode ser feito pela COOPERATIVA
        if (!keycloakService.isTipoEntidadeCooperativa()) {
            throw new RegraNegocioException(messages.get(COOPERATIVA_PERMISSAO_CANCELAR));
        }

        if (Objects.equals(ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1,cooperativa.getProgressoManutencaoMicro())) {
            try {
                cooperativa.setProgressoManutencaoMicro(null);
                cooperativaRepository.save(cooperativa);
				cooperativaRegistroService.criaHistoricoCooperativa(cooperativa, new CooperativaRegistro(), null);
            } catch (Exception e) {
                throw new RegraNegocioException("Erro ao cadastrar a solicitação de ativação.",e);
            }
        } else {
            throw new RegraNegocioException(
                    "Para solicitar o cancelamento da análise de dados, o cadastro deverá já ter sido aprovado neste ano.");
        }

        return cooperativaRepository.findById(cooperativa.getId()).orElseThrow(() -> new RegraNegocioException(NAO_ENCONTRADO));
    }

    public Cooperativa getCooperativaPeloId(Integer coopertivaId) {
        return cooperativaRepository.getCooperativaPeloId(coopertivaId);
    }

    public Cooperativa getCooperativaByCNPJ(String cnpj) {
        return cooperativaRepository.getCooperativaByCNPJ(cnpj);
    }

    public List<CooperativaCnpjTO> buscaCooperativaTOporRamo(@Valid Integer idRamo, @Valid Integer anoAtual) {
        return cooperativaRepository.buscaCooperativaTOporRamo(idRamo, anoAtual);
    }

    public List<Cooperativa> getCooperativasRergistradasByUF(@Valid String uf) {
        return cooperativaRepository.getRelatorioCooperativasRegistradasPelaUF(uf);
    }

    public Situacao getSituacaoCooperativa(Integer id) {
        Optional<Cooperativa> op = cooperativaRepository.findById(id);
        if (op.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        return op.get().getSituacaoCooperativa();
    }

    public boolean isCooperativaNaoRegistradaAndInPreCadastro(String cnpj) {
        boolean flag = false;
        Cooperativa coop = cooperativaRepository.getCooperativaByCNPJ(cnpj);

        if (coop != null) {
            // cooperativas não registradas ou nos passos iniciais
			if (coop.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo())
                    && (coop.getProgressoMacro() == null
                    || coop.getProgressoMacro() == ProgressoMacroEnum.PRE_CADASTRO_0
                    || coop.getProgressoMacro() == ProgressoMacroEnum.CADASTRO_INICIADO_1)) {
                flag = true;
            }
        }

        coop = null;

        return flag;
    }

    public boolean isNaoRegistrada(String cnpj) {
        boolean flag = false;
        Cooperativa coop = cooperativaRepository.getCooperativaByCNPJ(cnpj);

        if (coop != null
				&& coop.getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo())) {
            flag = true;
        }

        coop = null;

        return flag;
    }

    public Integer quatidadeCooperativasNaoRegistradasAguardandoUnidadeEstadual() {
        // Somente usuários do tipo UE poderão ver no menu que existem pendencias de
        // ação.
        if (!keycloakService.isTipoEntidadeEstadual()) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }
        Integer result = 0;
        try {
            result = cooperativaRepository.quatidadeCooperativasNaoRegistradasAguardandoPorProcessoMicroUnidadeEstadual(
                    keycloakService.getUFUsuario());
        } catch (Exception e) {
            throw new RegraNegocioException(ERRO_OPERACAO,e);
        }
        return result;
    }

    public Integer quatidadeCooperativasRegistradasAguardandoPorProcessoMicroUnidadeEstadual() {
        // Somente usuários do tipo UE poderão ver no menu que existem pendencias de
        // ação.
        if (!keycloakService.isTipoEntidadeEstadual()) {
            throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
        }
        Integer result = 0;
        try {
            result = cooperativaRepository.quatidadeCooperativasRegistradasAguardandoPorProcessoMicroUnidadeEstadual(
                    keycloakService.getUFUsuario());
        } catch (Exception e) {
            throw new RegraNegocioException(ERRO_OPERACAO,e);
        }
        return result;
    }

    public Cooperativa marcarComoVisualizada(@Valid Integer id) {
        Optional<Cooperativa> op = cooperativaRepository.findById(id);
        if (op.isPresent()) {
            Cooperativa c = op.get();
            c.setAtualizacaoNaoVisualizada(Boolean.FALSE);

            op = null;

            return cooperativaRepository.save(c);
        }

        op = null;

        return null;
    }

    public Integer buscaRegistroAtualizacaoNaoVisualizada() {
        String uf = null;
        if ("N".equals(keycloakService.getTipoUsuario())) {
            return cooperativaRepository.buscaRegistroAtualizacaoNacionalNaoVisualizada();
        }
        if (keycloakService.isTipoEntidadeEstadual()) {
            uf = keycloakService.getUFUsuario();
        }
        return cooperativaRepository.buscaRegistroAtualizacaoNaoVisualizada(uf);
    }

    public Integer buscaAtualizacaoNaoVisualizadaRegistrada() {
        String uf = null;
        if ("N".equals(keycloakService.getTipoUsuario())) {
            return cooperativaRepository.buscaAtualizacaoNacionalNaoVisualizadaRegistrada();
        }
        if (keycloakService.isTipoEntidadeEstadual()) {
            uf = keycloakService.getUFUsuario();
        }
        return cooperativaRepository.buscaAtualizacaoNaoVisualizadaRegistrada(uf);
    }

    public byte[] filtrarCooperativasAnuarioListagemExcel(CooperativaFiltroTO cooperativaFiltro) {
        cooperativaFiltro.setCnpj(RemoveMascaraUtil.remove(cooperativaFiltro.getCnpj()));
        byte[] file = null;

        List<CooperativaAnuarioTO> result = cooperativaRepository
                .filtrarCooperativasAnuarioListagemExcel(cooperativaFiltro, keycloakService.getFiltro());

        if (result.isEmpty()) {
            throw new RegraNegocioException(NAO_HA_REGISTROS_EXPORT, HttpStatus.NOT_FOUND);
        }

        List<String> cabecalho = null;
        List<List<String>> linhas = new ArrayList<>();
        List<Integer> larguras = null;

        cabecalho = Arrays.asList("CNPJ", NOME_FANTASIA, "Ramo", UF, FASE_DO_PROCESSO, "Status da Cooperativa",
                "Anuário", "Ativo Total", "Ativo Imobilizado", "Patrimônio Líquido", "Capital Social",
                "Sobras ou Perda do Exercício", "Ingressos e Receitas Brutas", "Tributos Sobre Vendas e Serviço",
                "Total de Despesas");
        larguras = Arrays.asList(LARGURA_20, LARGURA_45, LARGURA_18, LARGURA_5, LARGURA_30, LARGURA_16, LARGURA_20, 
        		LARGURA_14, LARGURA_24, LARGURA_20, LARGURA_20, LARGURA_28, LARGURA_28, LARGURA_30, LARGURA_24);
        result.forEach(obj -> linhas.add(obj.objectToStringArray()));

        file = montaRelatorio(file, cabecalho, linhas, larguras);

        cabecalho = null;
        larguras = null;

        return file;
    }
    
    public List<CooperativaAnuarioTO> filtrarCooperativasAnuarioListagem(CooperativaFiltroTO cooperativaFiltro) {
    	cooperativaFiltro.setCnpj(RemoveMascaraUtil.remove(cooperativaFiltro.getCnpj()));
    	
        List<CooperativaAnuarioTO> cooperativasFiltradas = cooperativaRepository
                .filtrarCooperativasAnuarioListagemExcel(cooperativaFiltro, keycloakService.getFiltro());

        if (!ValidacaoCampos.validaCampoPreenchido(cooperativasFiltradas)) {
            throw new RegraNegocioException(NAO_HA_REGISTROS_EXPORT, HttpStatus.NOT_FOUND);
        }
        
        return cooperativasFiltradas;
    }

    public Cooperativa cancelaSolicitacaoInativacao(@Valid Cooperativa coop) {

        if (coop != null) {

            if (Boolean.FALSE.equals(cadastroRegistroService.podePreencherCadastroRegistroCooperativaManutencao(coop.getId()))) {
                throw new RegraNegocioException(messages.get(AGUARDANDO_PROCESSO));
            }

            // ação feita apenas pela UE
            if (!keycloakService.isTipoEntidadeEstadual()) {
                throw new RegraNegocioException(messages.get(PERMISSAO_NEGADA));
            }

            // Cooperativa deve ter uma solicatação de inativação ativa.
            if (ValidacaoCampos.validaCampoPreenchido(coop.getSolicitacaoInativacao())
                    && !coop.getSolicitacaoInativacao().equals(Boolean.TRUE)) {
                throw new RegraNegocioException("Não existe solicitação de inativação em aberto.");
            }

            try {
                coop.setSolicitacaoInativacao(null);
                cooperativaRepository.save(coop);
                CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
				cooperativaRegistroService.criaHistoricoCooperativa(coop, cooperativaRegistro, null);
            } catch (Exception e) {
                throw new RegraNegocioException("Não foi possível fazer a alteração.",e);
            }
        }

        return cooperativaRepository.save(coop);
    }

    public Cooperativa retonarCooperativaConfirmidadeById(Integer id) {

        // retorna a cooperativa para a
        if (!keycloakService.isTipoEntidadeEstadual() && !keycloakService.isTipoEntidadeNacional()) {
            throw new RegraNegocioException("Usuário sem permissão!");
        }

        Cooperativa cooper = getCooperativa(id);

        try {
            cooper.setProgressoMacro(ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3);
            cooper.setProgressoMicro(ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1);
            cooperativaRepository.save(cooper); // Atualiza cooperativa para a etapa de análise de conformidade
            parecerService.retornaParecerEtapaConformidadeLegal(cooper); // retorna o parecer para a etapa de análise de
            // conformidade
            return cooper;
        } catch (Exception e) {
            throw new RegraNegocioException("Não foi possível ajustar análise de conformidade!",e);
        }

    }

    /**
     * No fluxo ajustar a conformidade legal da cooperativa é possível fazer o
     * upload do arquivo de visita técnica
     *
     * @param idPessoa
     */
    public void ajustarVisitaTecnicaCooperativa(Integer idPessoa) {
        if (!(keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual())) {
            throw new RegraNegocioException("Você não tem permissão!");
        }

        Cooperativa cooperativa = cooperativaRepository.getCooperativaPeloId(idPessoa);
        //TODO Rever essa regra
        cooperativa.setProgressoCadastroState(progressoCadastroStateFactory.createVisitaTecnicaMarcadaState(Boolean.TRUE));
        cooperativa.trocarEstado();
        
        VisitaTecnica visitaTecnica = visitaRepository.findByPessoaJuridica(idPessoa);
        visitaTecnica.setDataEnvioParecer(null);
        visitaRepository.save(visitaTecnica);
        
        cooperativa = null;

    }

    public CooperativaRegistro buscaUltimoHistorico(Integer idCooperativa) {
        List<CooperativaRegistro> historico = cooperativaRegistroRepository.buscaHistoricoCooperativa(idCooperativa);
        CooperativaRegistro cooperativaRegistro = new CooperativaRegistro();
        if (!historico.isEmpty()) {
            cooperativaRegistro = historico.get(0);
        }

        historico = null;

        return cooperativaRegistro;
    }

    public byte[] filtrarCooperativaListagemProcessoRegistroAcompanhamentoExcel(CooperativaFiltroTO cooperativaFiltro) {
        cooperativaFiltro.setCnpj(RemoveMascaraUtil.remove(cooperativaFiltro.getCnpj()));
        byte[] file = null;

        List<CooperativaListagemProcessoRegistroTO> contato = cooperativaRepository
                .filtrarCooperativaListagemProcessoRegistroAcompanhamentoExcel(cooperativaFiltro,
                        keycloakService.getFiltro());

        if (contato.isEmpty()) {
            throw new RegraNegocioException(NAO_HA_REGISTROS_EXPORT, HttpStatus.NOT_FOUND);
        }

        List<String> cabecalho = null;
        List<List<String>> linhas = new ArrayList<>();
        List<Integer> larguras = null;

        cabecalho = Arrays.asList("CNPJ", RAZAO_SOCIAL, NOME_FANTASIA, "Nº Processo", "E-mail Geral", "Telefone Geral",
                "Regida pela lei 12690", "Ramo", "Categoria da Cooperativa", "NIRE", "CEP", "Região do Pais",
                "Sigla do Estado", "Nome da região da Organização Estadual", "Nome do Município", "Data de Atualização",
                "Data de Abertura do Processo", "Tempo Decorrido em Dias", "Data da Última Análise da UE",
                "Cadastro e Envio dos Documentos", "Validação dos Dados e Documentos", "Análise de Conformidade Legal",
                "Visita Técnica", "Deliberação da Organização Estadual", "Deliberação da Unidade Nacional");

        larguras = Arrays.asList(LARGURA_25, LARGURA_40, LARGURA_40, LARGURA_25, LARGURA_35, LARGURA_25, LARGURA_40, LARGURA_25, 
        		LARGURA_40, LARGURA_25, LARGURA_25, LARGURA_25, LARGURA_25, LARGURA_50, LARGURA_25, LARGURA_25, LARGURA_40, LARGURA_40, 
        		LARGURA_40, LARGURA_40, LARGURA_50, LARGURA_40, LARGURA_25, LARGURA_40, LARGURA_40);
        contato.forEach(obj -> linhas.add(obj.objectToStringArrayAcompanhamento()));

        try {
            RelatorioExpressTO relatorio = new RelatorioExpressTO();
            relatorio.setCabecalho(cabecalho);
            relatorio.setDados(linhas);
            relatorio.setLarguras(larguras);

            file = relatorioClient.gerarRelatorio(relatorio);
        } catch (Exception e) {
            throw new ErroSistemaException(messages.get(ERRO_PLANILHA),e);
        }

        return file;
    }

    public void podeExportarDadosListagemCooperativaRegistradas() {
        validacaoCooperativa.podeExportarDadosTabelaCooperativa();
    }

    /**
     * Realiza a sincronização das redes sociais na cooperativa indicada. <br>
     * Identifica quais redes sociais foram adicionadas, modificadas e/ou removidas,
     * realizando a atualização na Cooperativa.<br>
     * OBS: A rotina não executa o salvamento da cooperativa no banco de dados,
     *
     * @param cooperativa  Cooperativa.
     * @param redesSociais Lista de redes sociais.
     */
    public void sincronizarRedesSociais(@Valid Cooperativa cooperativa, @Valid List<RedeSocial> redesSociais) {
        if (cooperativa == null || redesSociais == null)
            return;

        if(cooperativa.getPessoaJuridica().getRedesSociais() == null) {
        	cooperativa.getPessoaJuridica().setRedesSociais(new LinkedList<>());
        }
        
        // Rede Sociais existentes.
        List<RedeSocial> redesSociaisExistentes = new ArrayList<>(cooperativa.getPessoaJuridica().getRedesSociais());
        
        
		// Redes Sociais a serem  removidas
		redesSociaisExistentes.forEach(rse -> {
			Optional<RedeSocial> redeSocial = redesSociais.stream()
					.filter(rs -> Objects.equals(rse.getId(), rs.getId())).findAny();

			if (redeSocial.isEmpty()) {
				cooperativa.getPessoaJuridica().removeRedeSocial(rse);
			}
		});

		// Rede Sociais a serem inseridas ou atualizadas
		redesSociais.forEach(rs -> {
			Optional<RedeSocial> redeSocial = redesSociaisExistentes.stream()
					.filter(rse -> Objects.equals(rse.getId(), rs.getId())).findAny();

			if (redeSocial.isEmpty() || Objects.isNull(rs.getId())) {
				cooperativa.getPessoaJuridica().addRedeSocial(rs);
			} else {
				redeSocial.get().setLink(rs.getLink());
				redeSocial.get().setTipoRedeSocial(rs.getTipoRedeSocial());
			}
		});

    }

    /**
     * Realiza a sincronização dos endereços na cooperativa indicada. <br>
     * Identifica quais endereços foram adicionados, modificados e/ou removidos,
     * realizando a atualização na Cooperativa.<br>
     * OBS: A rotina não executa o salvamento da cooperativa no banco de dados,
     *
     * @param cooperativa Cooperativa.
     * @param enderecos   Lista de endereços.
     */
    public void sincronizarEnderecos(@Valid Cooperativa cooperativa, @Valid List<Endereco> enderecos) {
        if (enderecos == null || cooperativa == null)
            return;

        // Endereco existentes
        // List<Endereco> enderecosExistentes = new LinkedList<Endereco>(Arrays.asList(cooperativa.getPessoaJuridica().getEnderecos());
        List<Endereco> enderecosExistentes = new LinkedList<>(cooperativa.getPessoaJuridica().getEnderecos());
        Map<Integer, Endereco> mapaEnderecosExistentes = new HashMap<>();
        for (Endereco endereco : cooperativa.getPessoaJuridica().getEnderecos()) {
            mapaEnderecosExistentes.put(endereco.getId(), endereco);
        }

        // Endereco a serem gravados.
        Map<Integer, Endereco> mapaEnderecosAlterados = new HashMap<>();
        for (Endereco endereco : enderecos) {
            if (endereco.getId() != null && endereco.getId() != 0) {
                Endereco enderecoExistente = mapaEnderecosExistentes.get(endereco.getId());
                enderecoExistente.setBairro(endereco.getBairro());
                enderecoExistente.setCep(endereco.getCep());
                enderecoExistente.setComplemento(endereco.getComplemento());
                enderecoExistente.setCorrespondenciaDiferente(endereco.getCorrespondenciaDiferente());
                enderecoExistente.setDescricaoEndereco(endereco.getDescricaoEndereco());
                enderecoExistente.setEnderecoReferencia(endereco.getEnderecoReferencia());
                enderecoExistente.setIdEstado(endereco.getIdEstado());
                enderecoExistente.setIdMunicipio(endereco.getIdMunicipio());
                enderecoExistente.setNumero(endereco.getNumero());
                if (endereco.getTipoEndereco() != null
                        && (enderecoExistente.getTipoEndereco() == null
                        || !Objects.equals(enderecoExistente.getTipoEndereco().getId(),
                        endereco.getTipoEndereco().getId()))) {
                    enderecoExistente.setTipoEndereco(endereco.getTipoEndereco());
                }
                mapaEnderecosAlterados.put(enderecoExistente.getId(), enderecoExistente);
            }
        }

        // Remove os endereços que foram removidos
        for (int i = enderecosExistentes.size() - 1; i >= 0; i--) {
            Endereco endereco = enderecosExistentes.get(i);
            if (!mapaEnderecosAlterados.containsKey(endereco.getId())) {
                enderecosExistentes.remove(i);
            }
        }

        // Adiciona os novos enderecos.
        for (Endereco endereco : enderecos) {
            if (endereco.getId() == null || endereco.getId() == 0) {
                cooperativa.getPessoaJuridica().add(endereco);
            }
        }
        
    }

    public void sincronizarQuadroSocialManutencao(@Valid Cooperativa cooperativa, QuadroSocial quadroSocialManutencao) {
        if (cooperativa == null || quadroSocialManutencao == null)
            return;

        List<QuadroSocial> quadrosSociais = cooperativa.getQuadrosSociais();

        QuadroSocial quadroSocialManaged = quadrosSociais.stream()
                .filter(quadroSocial -> quadroSocial.getAno().equals(quadroSocialManutencao.getAno()))
                .findFirst()
                .orElse(null);

        if (Objects.isNull(quadroSocialManaged)) {
            quadroSocialManutencao.setCooperativa(cooperativa);
            cooperativa.add(quadroSocialManutencao);
        } else {
            quadroSocialManaged.setCooperadosHomens(quadroSocialManutencao.getCooperadosHomens());
            quadroSocialManaged.setCooperadosMulheres(quadroSocialManutencao.getCooperadosMulheres());
            quadroSocialManaged.setCooperadosPF(quadroSocialManutencao.getCooperadosPF());
            quadroSocialManaged.setCooperadosPJ(quadroSocialManutencao.getCooperadosPJ());
            quadroSocialManaged.setCooperadosTotal(quadroSocialManutencao.getCooperadosTotal());
            quadroSocialManaged.setEmpregadosHomens(quadroSocialManutencao.getEmpregadosHomens());
            quadroSocialManaged.setEmpregadosMulheres(quadroSocialManutencao.getEmpregadosMulheres());
            quadroSocialManaged.setEmpregadosTotal(quadroSocialManutencao.getEmpregadosTotal());

            Aprovacao aprovacao = Optional.ofNullable(quadroSocialManutencao.getAprovacao())
                    .map(aprovacaoManutencao -> {
                        Aprovacao aprovacaoResponse;
                        if (Objects.isNull(quadroSocialManaged.getAprovacao())) {
                            aprovacaoResponse = aprovacaoManutencao;
                            aprovacaoResponse.setCooperativa(cooperativa);
                        } else {
                            aprovacaoResponse = quadroSocialManaged.getAprovacao();
                            aprovacaoResponse.setAno(aprovacaoManutencao.getAno());
                            aprovacaoResponse.setDataAtualizacao(aprovacaoManutencao.getDataAtualizacao());
                        }
                        return aprovacaoResponse;
                    })
                    .orElse(null);
            quadroSocialManaged.setAprovacao(aprovacao);
        }

        quadrosSociais = null;
    }

    public Page<CooperativaBasicaTO> buscaPaginada(CooperativaCriterioTO filtro) {
        BooleanBuilder builder = new BooleanBuilder();

        Page<Cooperativa> coops = builder.getValue() != null ? this.cooperativaRepository.findAll(builder.getValue(),
                PageRequest.of(filtro.getPageNumber(), filtro.getPageSize())) : this.cooperativaRepository.findAll(
                PageRequest.of(filtro.getPageNumber(), filtro.getPageSize()));


        builder = null;

        return coops.map(this::getCooperativaBasica);
    }

    private CooperativaBasicaTO getCooperativaBasica(Cooperativa c) {
        return CooperativaBasicaTO.builder()
                .id(c.getId())
                .idRamo(c.getVwPessoaJuridica().getIdRamo())
                .nomeRamo(c.getVwPessoaJuridica().getRamo())
                .nomeFantasia(c.getVwPessoaJuridica().getNomeFantasia())
                .cnpj(c.getVwPessoaJuridica().getCnpj())
                .idCategoria(c.getCategoria().getId())
                .categoria(c.getCategoria().getDescricao())
                .ufSigla(c.getVwPessoaJuridica().getUfSigla())
                .idMunicipio(c.getVwPessoaJuridica().getIdMunicipio())
                .municipio(c.getVwPessoaJuridica().getIdMunicipio() == null ?
                        "" : localizacaoClient.buscaMunicipio(c.getVwPessoaJuridica().getIdMunicipio()).getNome())
                .build();
    }

    public List<Cooperativa> buscarPendenciasData(ProgressoMicroEnum progressoMicro, ProgressoMicroEnum progressoMicroManutencao, Date dataAtual) {
        return cooperativaRepository.buscarPendenciasData(progressoMicro, progressoMicroManutencao, dataAtual);
    }

	private Situacao getSituacaoFromNovaSituacao(NovaSituacaoCooperativaEnum situacao) {
		Situacao situacaoRetorno = new Situacao();
		situacaoRetorno.setId(situacao.getCodigo());
		situacaoRetorno.setAtivo(true);
		situacaoRetorno.setNome(situacao.getNome());
		return situacaoRetorno;
	}


	public List<Cooperativa> buscaCooperativasIrregulares() {
		return cooperativaRepository.buscaCooperativasIrregulares();
	}

    @Transactional(readOnly = true)
    public Cooperativa getByCnpj(String cnpj) {
        return cooperativaRepository.findByPessoaJuridicaCnpj(cnpj);
    }

    @Transactional(readOnly = true)
    public List<CooperativaWebLectorResponseTO> getCooperativaParaWebLector() {
        return cooperativaRepository.fetchCooperativasParaWebLector();
    }

    @Transactional(readOnly = true)
    public List<CooperativaIntegracaoFormularioResponseTO> getCooperativasParaIntegracaoFormulario(String uf) {
        return cooperativaDAO.fetchCooperativasParaIntegracaoFormulario(uf);
    }

    public String buscaDestinatarios(Integer id){
        Cooperativa cooperativa = getCooperativa(id);
        return "" + cooperativa.getPessoaJuridica().getEmailGeral() + "; " + emailService.obtemDestinatariosCoop(Collections.singletonList(cooperativa.getPessoaJuridica()));
    }

    public void avisaUEConcluirSolicitacao() {
        LocalDate quinzeDiasAtras = LocalDate.now().minusDays(diasConcluirSolicitacao);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dataBuscar = sdf.format(Date.from(quinzeDiasAtras.atStartOfDay(ZoneId.systemDefault()).toInstant()));
        List<CooperativaRegistro> registros = cooperativaRegistroService.buscaNotificacoesAEnviarEmail(dataBuscar);
    
        registros.forEach(this::disparaEmailAvisarUeConcluirSolicitacao);
    }

    private void disparaEmailAvisarUeConcluirSolicitacao(CooperativaRegistro r) {
        EmailEventTO to = new EmailEventTO();
        to.setCooperativa(r.getCooperativa());
        to.setLogin(r.getLoginAlteracaoSituacao());
        EmailServiceEvent<EmailEventTO> event = new EmailServiceEvent<>(EnvioEmailEventEnum.EMAIL_AVISAR_UE_CONCLUIR_SOLICITACAO.getId(), EnvioEmailEventEnum.EMAIL_AVISAR_UE_CONCLUIR_SOLICITACAO, to);
        applicationEventPublisher.publishEvent(event);
    }

    private void disparodeEmails(Cooperativa c, EnvioEmailEventEnum type) {
        EmailEventTO to = new EmailEventTO();
        to.setCooperativa(c);
        EmailServiceEvent<EmailEventTO> event = new EmailServiceEvent<>(type.getId(), type, to);
        applicationEventPublisher.publishEvent(event);
    }

    public Integer obterDiasParaConcluirSolicitacao(){
        return diasConcluirSolicitacao;
    }
    
    public List<PessoaJuridica> buscarOEPorUf(String uf){
    	return pessoaJuridicaService.buscarUnidadesEstaduais(uf);
    }

    public boolean validarStatusAbaDocumento(Cooperativa cooperativa, CooperativaPendenciaBlocoEnum[] lista) {
		return cooperativaPendenciaService.verificarAbaValidada(cooperativa, lista);
    }

    public List<String> autocompleteCooperativa(String parcial) {
        return cooperativaRepository.autocompleteCooperativa(parcial);
    }

    public Cooperativa getCooperativaFilial(Integer id) {
        return findByIdFilial(id);
    }

    public Cooperativa findByIdFilial(Integer id) {
        Cooperativa c = null;
        FiltroTO filtro = keycloakService.getFiltro();
        /**
         * Verifica se a cooperativa possui processo de mudança de UF caso tenha
         * processo em andamento as UES de destino e Nacional podem visualziar a
         * cooperativa
         **/
        SolicitacaoMudancaEndereco solicitacaoMudancaUF = solicitacaoMudancaEnderecoService
                .obterSolicitacaoMudancaUF(id);
        if (solicitacaoMudancaUF != null && solicitacaoMudancaUF.getUfDestino().equals(filtro.getUf())
                && keycloakService.isTipoEntidadeEstadual()) {
            Optional<Cooperativa> coopOpt = cooperativaRepository.findById(id);
            if (coopOpt.isPresent()) {
                c = coopOpt.get();
            }
            // Regra padrão
        } else {
            c = cooperativaRepository.findById(id, null, null);
        }
        if (c == null) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        // Mesmo gate Nacional do findById (usuário de auditoria só para a Nacional).
        if (keycloakService.isTipoEntidadeNacional()) {
            c.setUsuarioAuditoria(cooperativaRepository.recuperaUsuarioAuditoria(id));
        }

        solicitacaoMudancaUF = null;
        filtro = null;

        return c;
    }

    private void gravaProcessoRegistro(Cooperativa cooperativa, AcaoProcessoRegistroEnum acao, FaseProcessoRegistroEnum fase) {
        CooperativaHistoricoProcessoRegistroTO to = new CooperativaHistoricoProcessoRegistroTO();
        to.setCooperativaId(cooperativa.getId());
        to.setDataAtualizacao(new Date());
        to.setAcao(acao);
        to.setFase(fase);
        to.setUsuario(keycloakService.getNome());
        cooperativaHistoricoProcessoRegistroService.salvar(to);
    }

    private FaseProcessoRegistroEnum mapearFase(ProgressoMacroEnum progresso) {
        if (progresso == null) {
            return null;
        }

        return switch (progresso) {
            case PRE_CADASTRO_0, CADASTRO_INICIADO_1 -> FaseProcessoRegistroEnum.CADASTRO;
            case VALIDACAO_DOCUMENTOS_2 -> FaseProcessoRegistroEnum.VALIDACAO;
            case ANALISE_CONFORMIDADE_LEGAL_3 -> FaseProcessoRegistroEnum.CONFORMIDADE;
            case VISITA_TECNICA_4 -> FaseProcessoRegistroEnum.VISITA;
            case PARECER_5, EMISSAO_CERTIFICADO_6 -> FaseProcessoRegistroEnum.DELIBERACAO;
            default -> null;
        };
    }

    public String findByUfSigla(Integer idCooperativa) {
        return cooperativaRepository.getUfSiglaCooperativa(idCooperativa);
    }

    public CooperativaSuperiorBuscaTO getCooperativasSuperioresPorCnpjPai(Integer idCooperativa, String cnpjSuperior) {

        Cooperativa atual = cooperativaRepository.findById(idCooperativa)
                .orElseThrow(() -> new RegraNegocioException("Cooperativa não encontrada."));

        Optional<Cooperativa> encontradaOpt =
                cooperativaRepository.buscarSuperiorPorCnpj(idCooperativa, cnpjSuperior);

        if (encontradaOpt.isEmpty()) {
            return respostaNaoEncontrada("Nenhuma cooperativa foi encontrada para o CNPJ informado.");
        }

        Cooperativa encontrada = encontradaOpt.get();

        Integer grauAtual = atual.getCategoria().getId();
        Integer grauEncontrado = encontrada.getCategoria().getId();

        String ramoAtual = atual.getPessoaJuridica().getRamo().getNome();
        String ramoEncontrado = encontrada.getPessoaJuridica().getRamo().getNome();

        if (!grauSuperiorPermitido(grauAtual, grauEncontrado)) {
            return respostaNaoPermitida(
                    true,
                    String.format(
                            "A cooperativa %s foi encontrada, mas pertence ao grau %s. Só é permitido indicar uma cooperativa de grau superior.",
                            encontrada.getPessoaJuridica().getNomeFantasia(),
                            encontrada.getCategoria().getDescricao()
                    )
            );
        }

        boolean mesmoRamo = Objects.equals(
                atual.getPessoaJuridica().getRamo().getId(),
                encontrada.getPessoaJuridica().getRamo().getId()
        );

        if (!mesmoRamo) {
            return respostaNaoPermitida(
                    true,
                    String.format(
                            "A cooperativa %s foi encontrada e pertence ao ramo %s. O vínculo não pode ser solicitado porque a cooperativa atual pertence ao ramo %s.",
                            encontrada.getPessoaJuridica().getNomeFantasia(),
                            ramoEncontrado,
                            ramoAtual
                    )
            );
        }

        CooperativaSuperiorBuscaTO resposta = new CooperativaSuperiorBuscaTO();
        resposta.setEncontrada(true);
        resposta.setVinculoPermitido(true);
        resposta.setMensagem("Cooperativa superior encontrada.");
        resposta.setRamoCooperativaAtual(ramoAtual);
        resposta.setRamoCooperativaEncontrada(ramoEncontrado);
        resposta.setCooperativa(getCooperativaBasica(encontrada));

        return resposta;
    }

    private boolean grauSuperiorPermitido(Integer grauAtual, Integer grauEncontrado) {

        if (grauAtual.equals(1)) {
            return grauEncontrado.equals(2) || grauEncontrado.equals(3);
        }

        if (grauAtual.equals(2)) {
            return grauEncontrado.equals(3);
        }

        return false;
    }

    private CooperativaSuperiorBuscaTO respostaNaoPermitida(boolean encontrada, String mensagem) {
        CooperativaSuperiorBuscaTO resposta = new CooperativaSuperiorBuscaTO();
        resposta.setEncontrada(encontrada);
        resposta.setVinculoPermitido(false);
        resposta.setMensagem(mensagem);
        return resposta;
    }

    private CooperativaSuperiorBuscaTO respostaNaoEncontrada(String mensagem) {
        CooperativaSuperiorBuscaTO resposta = new CooperativaSuperiorBuscaTO();
        resposta.setEncontrada(false);
        resposta.setVinculoPermitido(false);
        resposta.setMensagem(mensagem);
        return resposta;
    }

    public List<CooperativaBasicaTO> getCooperativaSuperiorVinculada(Integer idCooperativa) {
        List<Cooperativa> cooperativas = cooperativaRepository.getCooperativaSuperior(idCooperativa);
        return cooperativas.stream().map(this::getCooperativaBasica).toList();
    }

    public void removerCooperativaSuperiorVinculada(Integer idCooperativaFilha, Integer idCooperativaPai ) {
        cooperativaVinculacaoRepository.removerCooperativaSuperiorVinculada(idCooperativaFilha, idCooperativaPai);
    }

}
