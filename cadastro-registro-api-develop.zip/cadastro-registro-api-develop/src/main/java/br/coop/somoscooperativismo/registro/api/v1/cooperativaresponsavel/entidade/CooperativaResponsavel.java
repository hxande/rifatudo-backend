package br.coop.somoscooperativismo.registro.api.v1.cooperativaresponsavel.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name="VW_COOPERATIVA_RESPONSAVEL")
public class CooperativaResponsavel {
	
	@Id
	@Column(name="SQ_PESSOA_FISICA")
	private Integer idPessoaFisica;
	
	@Column(name="TX_CPF")
	private String cpf;
	
	@Column(name="TX_NOME")
	private String nome;
	
	@Column(name="TX_EMAIL")
	private String email;
	
	@Column(name="TX_TELEFONE")
	private String telefone;
	
	@Column(name="SQ_PESSOA_JURIDICA")
	private Integer idPessoaJuridica;
	
	@Column(name="TX_CNPJ")
	private String cnpj;
	
	

	public Integer getIdPessoaFisica() {
		return idPessoaFisica;
	}

	public void setIdPessoaFisica(Integer idPessoaFisica) {
		this.idPessoaFisica = idPessoaFisica;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Integer getIdPessoaJuridica() {
		return idPessoaJuridica;
	}

	public void setIdPessoaJuridica(Integer idPessoaJuridica) {
		this.idPessoaJuridica = idPessoaJuridica;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
}
