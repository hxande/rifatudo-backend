package br.coop.somoscooperativismo.registro.api.v1.events.listeners;

import java.util.Objects;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.events.events.SolicitacaoMudancaEnderecoEvent;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;

@Component
public class SolicitacaoMudancaEnderecoSolicitaListener implements ApplicationListener<SolicitacaoMudancaEnderecoEvent> {
	
	private EmailService emailService;
	
	public SolicitacaoMudancaEnderecoSolicitaListener(EmailService emailService) {
		this.emailService = emailService;
	}

	@Override
	public void onApplicationEvent(SolicitacaoMudancaEnderecoEvent event) {
		SolicitacaoMudancaEndereco solicitacaoMudancaEndereco = event.getSolicitacaoMudancaEndereco();
		
		try {
			if(Boolean.FALSE.equals(solicitacaoMudancaEndereco.getCancelado()) && 
					Objects.isNull(solicitacaoMudancaEndereco.getLoginUsuarioParecer()) &&
					Objects.isNull(solicitacaoMudancaEndereco.getAprovado())) {
				// Enviar email notificando OE de destino
				
				emailService.enviaEmailSolicitacaoMudancaEndereco(solicitacaoMudancaEndereco.getPessoa().getId(), solicitacaoMudancaEndereco.getUfDestino(),DisparoEmailEnum.SOLICITACAO_TRANSFERENCIA_UF,null);
			}
		} catch (Exception e) {
			throw new RegraNegocioException(e.getMessage(),e);
		}

		solicitacaoMudancaEndereco = null;
		
	}

}
