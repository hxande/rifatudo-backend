package br.coop.somoscooperativismo.registro.api.v1.governanca.event;

import br.coop.somoscooperativismo.registro.api.v1.governanca.event.util.GovernancaEvent;
import br.coop.somoscooperativismo.registro.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
public class GovernancaPublisher {
    private final RabbitTemplate rabbitTemplate;

    public GovernancaPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publicar(String routingKey, GovernancaEvent evento) {
        rabbitTemplate.convertAndSend(RabbitMQConfig.GOVERNANCA_EXCHANGE, routingKey, evento);
    }
}
