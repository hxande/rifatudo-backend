package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade;


import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "COOPERATIVA_REGISTRO_COMENTARIO")
@Getter
@Setter
public class CooperativaRegistroComentario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "SQ_PESSOA_REGISTRO", nullable = false)
    private CooperativaRegistro cooperativaRegistro;

    @Column(name = "ACAO")
    private String acao;

    @Column(name = "DT_ALTERACAO_SUB")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dataAlteracao;

    @Column(name = "USUARIO_ALTERACAO")
    private String usuarioAlteracao;

    @Column(name = "OBSERVACAO", length = 255)
    private String observacao;

}

