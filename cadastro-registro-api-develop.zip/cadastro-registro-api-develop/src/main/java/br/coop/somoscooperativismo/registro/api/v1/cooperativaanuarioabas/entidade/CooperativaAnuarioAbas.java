package br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.entidade;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "COOPERATIVA_ANUARIO_ABAS")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CooperativaAnuarioAbas {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_COOPERATIVA_ANUARIO_ABAS")
	private Integer id;
	@Column(name = "NR_ANO_CICLO")
	private Integer anoCiclo;
	@Column(name = "SQ_COOPERATIVA")
	private Integer idCooperativa;
	@Column(name = "TX_ABA_NOME")
	private String abaNome;
	@Column(name = "IN_ABA_PREENCHIDA", columnDefinition = "bit")
	private Boolean abaPreenchida;
	@Column(name = "TX_USUARIO")
	private String usuario;
    @Column(name = "IN_SITUACAO")
    private Integer situacao = 0;

	public CooperativaAnuarioAbas(Integer anoCiclo, Integer idCooperativa, String abaNome, Boolean abaPreenchida) {
		this.anoCiclo = anoCiclo;
		this.idCooperativa = idCooperativa;
		this.abaPreenchida = abaPreenchida;
		this.abaNome = abaNome;
	}
}
