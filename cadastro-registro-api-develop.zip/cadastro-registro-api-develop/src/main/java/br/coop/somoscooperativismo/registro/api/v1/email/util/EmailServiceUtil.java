package br.coop.somoscooperativismo.registro.api.v1.email.util;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaCnpjTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.email.AnexoTO;
import br.coop.somoscooperativismo.registro.api.v1.email.DisparoEmailTO;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailDestinatarioEnum;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailServiceConstant;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailTO;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmailHistorico;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaService;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.usuario.UsuarioClient;
import br.coop.somoscooperativismo.registro.api.v1.usuario.UsuarioTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceUtil {

    private final EmailService emailService;
    private final UsuarioClient usuarioClient;
    private final DisparoEmailService disparoEmailService;
    private final CooperativaService cooperativaService;
    private final PessoaJuridicaService pessoaJuridicaService;

    public void getEmailTOSemEnvioDeEmailGerandoLista(Collection<EmailTO> listaEmailTO, CooperativaCnpjTO cooperativa, DisparoEmail disparoEmail) {
        if (disparoEmail.getId() != null) {
            EmailTO emailTO = new EmailTO();
            emailTO.setChaveModulo(EmailServiceConstant.MODULO_ENVIO_EMAIL);
            emailTO.setAssunto(EmailServiceConstant.ATUALIZACAO_DE_DADOS_CADASTRAIS);
            emailTO.setDe(EmailServiceConstant.EMAIL_OCB);
            emailTO.setPara(obtemDestinatariosCoopCnpj(Collections.singletonList(cooperativa.getCnpj())));
            emailTO.setCorpo(disparoEmail.getTextoEmail());
            if (ValidacaoCampos.validaCampoPreenchido(emailTO.getPara())) {
                listaEmailTO.add(emailTO);
            }
        }
    }

    public String obtemDestinatarioPorLogin(String login) {
        UsuarioTO usuario = usuarioClient.obterUsuarioLogin(login);
        if (ValidacaoCampos.validaCampoPreenchido(usuario)) {
            return usuario.getEmail();
        } else {
            throw new RegraNegocioException("Usuário não existe!");
        }
    }

    public void salvarHistoricoEnvioEmail(DisparoEmail disparoEmail, Integer idCooperativa, String destinatario) {
        DisparoEmailHistorico disparoEmailHistorico = new DisparoEmailHistorico();
        disparoEmailHistorico.setDisparoEmail(disparoEmail);
        disparoEmailHistorico.setDestinatario(destinatario);
        disparoEmailHistorico.setIdCooperativa(idCooperativa);
        disparoEmailHistorico.setEnviado(Boolean.TRUE);
        disparoEmailHistorico.setDataEnvio(new Date());

        disparoEmailService.insertDisparoEmailHistorico(disparoEmailHistorico);
    }

    public DisparoEmailTO getDisparoEmailTO(EmailEventTO eventTO, DisparoEmailEnum disparoEmailEnum) {
        DisparoEmailTO disparoEmailTO = new DisparoEmailTO();
        disparoEmailTO.setNumeroProcesso(String.valueOf(eventTO.getCooperativa().getId()));
        disparoEmailTO.setCooperativa(eventTO.getCooperativa().getNomeCooperativa());
        disparoEmailTO.setCodigoDisparoEmail(disparoEmailEnum);
        disparoEmailTO.setUf(eventTO.getCooperativa().getPessoaJuridica().getUfSigla());
        return disparoEmailTO;
    }

    public EmailTO getEmailTO(String processoDeRegistro, String emailService, DisparoEmail disparoEmail, EmailDestinatarioEnum cooperativa, EmailEventTO to) {
        EmailTO emailTO = new EmailTO();
        emailTO.setAssunto(processoDeRegistro);
        emailTO.setPara(emailService);
        emailTO.setDe(EmailServiceConstant.EMAIL_OCB);
        emailTO.setCorpo(disparoEmail.getTextoEmail());
        emailTO.setChaveModulo(EmailServiceConstant.MODULO_ENVIO_EMAIL);

        if (to.getArquivoBase64() != null) {
            AnexoTO anexoTO = new AnexoTO();
            anexoTO.setNomeArquivo(to.getNomeArquivo());
            anexoTO.setArquivoBase64(to.getArquivoBase64());

            emailTO.setAnexos(new ArrayList<>());
            emailTO.getAnexos().add(anexoTO);
        }

        return emailTO;
    }

    public String getEmailService(EmailEventTO to) {
        return emailService.obtemDestinatariosCoop(Collections.singletonList(to.getCooperativa().getPessoaJuridica()));
    }

    public void gerarEmailsParaSeremEnviados(Iterable<CooperativaCnpjTO> cooperativasTO, List<EmailTO> listaEmailTO) {
        for (CooperativaCnpjTO cooperativa : cooperativasTO) {
            EmailEventTO to = new EmailEventTO();
            to.setCooperativa(cooperativaService.getCooperativa(cooperativa.getId()));
            to.setEmail(cooperativa.getEmail());
            DisparoEmailTO disparoEmailTO = getDisparoEmailTO(to, DisparoEmailEnum.ATUALIZAR_CADASTRO);
            DisparoEmail disparoEmail = emailService.getDisparoEmail(disparoEmailTO);
            if (disparoEmail.getId() != null) {
                EmailTO emailTO = getEmailTO(EmailServiceConstant.NOTIFICACAO_SOU_COOP, getEmailService(to), disparoEmail, EmailDestinatarioEnum.COOPERATIVA, to);
                listaEmailTO.add(emailTO);
            }
            getEmailTOSemEnvioDeEmailGerandoLista(listaEmailTO, cooperativa, disparoEmail);
        }
    }

    public String obtemDestinatariosCoopCnpj(List<String> asList) {
        StringBuilder destinatarios = new StringBuilder();
        try {
            List<String> emailsUsuarios = usuarioClient.obterEmailUsuariosEntidade(asList);
            emailsUsuarios.forEach(email -> destinatarios.append(email).append(';'));
        } catch (Exception e) {
            String message = EmailServiceConstant.ERRO_AO_DISPARAR_UM_EMAIL + e.getMessage();
            log.error(message, e);
        }
        return destinatarios.toString().length() > 0 ? destinatarios.substring(0, destinatarios.toString().length() - 1) : destinatarios.toString();
    }

    public String obtemDestinatariosOE(String uf) {
        StringBuilder destinatarios = new StringBuilder();
        List<PessoaJuridica> oes = pessoaJuridicaService.buscarUnidadesEstaduais(uf);

        oes.forEach(usuario -> destinatarios.append(usuario.getEmailGeral()).append("; "));

        return !destinatarios.toString().isEmpty() ? destinatarios.substring(0, destinatarios.toString().length() - 1) : destinatarios.toString();
    }

}
