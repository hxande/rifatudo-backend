package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaMembroService;
import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaService;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.GovernancaTO;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/manutencao-governanca")
public class ManutencaoGovernancaImportacaoRestController {

    private final GovernancaService governancaService;
    private final GovernancaMembroService governacaMembroService;

    @PostMapping("/{idCooperativa}")
    public ResponseEntity<Boolean> salvarGovernancaManutencaoImportacao(@PathVariable Integer idCooperativa,
                                                                        @RequestBody @Valid List<GovernancaTO> listaGovernancaTO) {
        Boolean result = governancaService.salvarGovernancaImportacao(listaGovernancaTO, idCooperativa);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/validacoes/{id}")
    public ResponseEntity<ValidacaoPrimeiroRegistroTO> getValidacoes(@PathVariable Integer id) {
        return ResponseEntity.ok(governancaService.validarGovernancaManutencao(id, true));
    }

    @DeleteMapping("/tornarUltimoNaoVigente/{idCooperativa}/{idOrgao}")
    public ResponseEntity<Void> tornarUltimoNaoVigente(@PathVariable Integer idCooperativa, @PathVariable Integer idOrgao){
        governacaMembroService.encerrarUltimoMandato(idCooperativa, idOrgao);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/buscaVigentesPorCooperativa/{idCooperativa}")
    public ResponseEntity<List<GovernancaTO>> buscaPorCooperativManutencaoa(@PathVariable Integer idCooperativa){
        return ResponseEntity.ok(governancaService.buscaPorCooperativaManutencao(idCooperativa));
    }

    @GetMapping("/buscaVigentesPorCooperativaRamo/{idCooperativa}/orgao/{idOrgao}")
    public ResponseEntity<GovernancaTO> buscaPorCooperativManutencaoaRamo(@PathVariable Integer idCooperativa, @PathVariable Integer idOrgao){
        return ResponseEntity.ok(governancaService.buscaPorCooperativaManutencaoRamo(idCooperativa, idOrgao));
    }
}
