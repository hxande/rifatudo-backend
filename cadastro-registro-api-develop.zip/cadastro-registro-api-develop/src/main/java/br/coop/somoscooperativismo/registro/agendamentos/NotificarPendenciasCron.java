package br.coop.somoscooperativismo.registro.agendamentos;

import br.coop.somoscooperativismo.registro.api.v1.enviaemail.EnviaEmailService;
import br.coop.somoscooperativismo.registro.api.v1.servidor.ServidorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@EnableScheduling
public class NotificarPendenciasCron {

    public static final String TIME_ZONE = "America/Sao_Paulo";

    @Value("${ativar-rotinas-automaticas:1}")
    private Boolean rotinaHabilitada;

    private Thread threadAgendaRapida;

    @Autowired
    private ServidorService servidorService;

    @Autowired
    private EnviaEmailService enviaEmailService;

    @Scheduled(cron = "${tempo-rotina}", zone = TIME_ZONE)
    public void notificarUsuarios() {
    	
        if (Boolean.FALSE.equals(rotinaHabilitada) || !servidorService.isServidorPrincipal()) {
            return;
        }

        if (threadAgendaRapida == null || !threadAgendaRapida.isAlive()) {
            threadAgendaRapida = new Thread(() -> {
                log.info("Notificando usuarios ( pendencias ).");
                enviaEmailService.filtrarAlteracaoCooperativaListagemExcel();
            });
            threadAgendaRapida.start();
        } else {
            log.info("(ocupado) executando atividade de notificacao.");
        }
    }
}

