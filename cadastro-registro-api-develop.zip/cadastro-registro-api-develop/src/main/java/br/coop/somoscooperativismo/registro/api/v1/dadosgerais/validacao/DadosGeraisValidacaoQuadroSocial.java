package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocialuf.entidade.QuadroSocialUf;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class DadosGeraisValidacaoQuadroSocial {

	public static final String VALIDACAO_CAMPOS_QUADRO_SOCIAL = "dadosGerais.validacao.campoQuadroSocial";
	public static final String VALIDACAO_QUADRO_SOCIAL_TOTAL_PF_PJ = "dadosGerais.validacao.quadroSocialTotalPfPj";
	public static final String VALIDACAO_QUADRO_SOCIAL_CAMPOS_OBRIGATORIOS = "dadosGerais.validacao.quadroSocialCamposObrigatorios";

	public List<ServiceMessage> validaQuadroSocial(List<ServiceMessage> mensagens, QuadroSocial qs,
												   MessagesService messages, boolean anuario) {
		Integer anoAnterior = Calendar.getInstance().get(Calendar.YEAR) - 1;
		if (qs == null) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_CAMPOS_QUADRO_SOCIAL)));
		} else if (anoAnterior.equals(qs.getAno()) && anuario) {
			validaMensagensAnoAnterior(mensagens, qs);
		} else if (((Calendar.getInstance().get(Calendar.YEAR) ) == qs.getAno())) {
			validaMensagensAnoCorrente(mensagens, qs);
		}

		anoAnterior = null;

		return mensagens;

	}

	private void validaMensagensAnoCorrente(List<ServiceMessage> mensagens, QuadroSocial qs) {
		mensagensComunsAnoAtual(mensagens, qs);
	}

	private void validaMensagensAnoAnterior(List<ServiceMessage> mensagens, QuadroSocial qs) {
		
		
		if(ValidacaoCampos.validaCampoPreenchido(qs.getListaCooperadosDadosAdicionais())) {
			qs.getListaCooperadosDadosAdicionais().forEach(cooperadoDadoAdicional -> {
				if(Boolean.TRUE.equals(cooperadoDadoAdicional.getObrigatorio()) && cooperadoDadoAdicional.getQuantidade() == null) {
					mensagens.add(new ServiceMessage(MessageType.ERROR,
							"<b>A quantidade de cooperados</b> é obrigatória para  " + cooperadoDadoAdicional.getNomeParametroQuadroSocialCooperado() ));
				}
			});
		}
		
		if(ValidacaoCampos.validaCampoPreenchido(qs.getListaEmpregadosDadosAdicionais())) {
			qs.getListaEmpregadosDadosAdicionais().forEach(empregadoDadoAdicional -> {
				if(Boolean.TRUE.equals(empregadoDadoAdicional.getObrigatorio()) && empregadoDadoAdicional.getQuantidade() == null) {
					mensagens.add(new ServiceMessage(MessageType.ERROR,
							"<b>A quantidade de empregados</b> é obrigatória para  " + empregadoDadoAdicional.getNomeParametroQuadroSocial() ));
				}
			});
		}
		
		if (qs.getCooperadosAtivos() == null) {
			mensagens.add(new ServiceMessage(MessageType.WARN,
					"<b>A quantidade de cooperados ativos</b> não foi preenchida para: " + qs.getAno()));
		}

		if(Objects.equals(Boolean.TRUE,qs.getInformaCooperadosUF())) {
			if (ValidacaoCampos.validaCampoPreenchido(qs.getQuadrosSociaisUf())) {
				qs.getQuadrosSociaisUf().forEach(qsUf -> {
					mensagensComunsCooperadosUf(mensagens, qsUf);
				});
			}
		} else {
			mensagensComuns(mensagens, qs);
		}
		
		
		if(Objects.equals(Boolean.TRUE,qs.getInformaEmpregadosUF())) {
			if (ValidacaoCampos.validaCampoPreenchido(qs.getQuadrosSociaisUf())) {
				qs.getQuadrosSociaisUf().forEach(qsUf -> {
					mensagensComunsEmpregadosUf(mensagens, qsUf);
				});
			}
		} else {
			mensagensComunsEmpregados(mensagens,qs);
		}
		

	}

	private void mensagensComunsEmpregados(List<ServiceMessage> mensagens, QuadroSocial qs) {
		if (((qs.getEmpregadosHomens() == null && qs.getEmpregadosMulheres() == null)
				&& qs.getEmpregadosTotal() == null)) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>A quantidade de empregados</b> é obrigatória para: " + qs.getAno()));
		}

		if (((qs.getEmpregadosHomens() == null && qs.getEmpregadosMulheres() != null)
				&& qs.getEmpregadosTotal() == null)) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>A quantidade de empregados homens</b> é obrigatória para: " + qs.getAno()));
		}

		if (((qs.getEmpregadosHomens() != null && qs.getEmpregadosMulheres() == null)
				&& qs.getEmpregadosTotal() == null)) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>A quantidade de empregados mulheres</b> é obrigatória para: " + qs.getAno()));
		}
		
	}

	private void mensagensComuns(List<ServiceMessage> mensagens, QuadroSocial qs) {
		if (!ValidacaoCampos.validaCampoPreenchido(qs.getAno())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Dados sociais</b> ano não preenchido"));
		}

		if (qs.getId() == null) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>Dados sociais</b> informar a quantidade de cooperados em " + qs.getAno()));
		}

		if ((qs.getCooperadosPF() == null && qs.getCooperadosPJ() == null) && qs.getCooperadosTotal() == null) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>Cooperados Pessoa Física e Pessoa Jurídica</b> são obrigatórios para: " + qs.getAno()));
		}

		if (Objects.nonNull(qs.getCooperadosPF()) && Objects.isNull(qs.getCooperadosPJ())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>Cooperados Pessoa Jurídica</b> são obrigatórios para: " + qs.getAno()));
		}

		if (Objects.isNull(qs.getCooperadosPF()) && Objects.nonNull(qs.getCooperadosPJ())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>Cooperados Pessoa Física</b> são obrigatórios para: " + qs.getAno()));
		}

		if (ValidacaoCampos.validaCampoPreenchido(qs.getCooperadosTotal())
				&& ValidacaoCampos.validaCampoPreenchido(qs.getCooperadosPF())
				&& ValidacaoCampos.validaCampoPreenchido(qs.getCooperadosPJ())) {
			if (qs.getCooperadosPF() + qs.getCooperadosPJ() != qs.getCooperadosTotal()) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>O total Pessoa Física + PessoaJurídica</b> não está correto para o ano: " + qs.getAno()));
			}
		}

		if (qs.getEmpregadosHomens() != null && qs.getEmpregadosMulheres() != null
				&& qs.getEmpregadosHomens() + qs.getEmpregadosMulheres() != qs.getEmpregadosTotal()) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, "O total de <b>empregados</b> não está correto"));
		}

		if (qs.getEmpregadosHomens() == null || qs.getEmpregadosMulheres() == null) {
			mensagens.add(new ServiceMessage(MessageType.ERROR,
					"<b>Os campos Homens e Mulheres da quantidade de empregados</b> são de preenchimento obrigatório para o ano: "
							+ qs.getAno()));
		}
	}

	private void mensagensComunsCooperadosUf(List<ServiceMessage> mensagens, QuadroSocialUf qsUf) {
		String message = "";

		if ((qsUf.getCooperadosPFUF() == null && qsUf.getCooperadosPJUF() == null) && qsUf.getCooperadosTotalUF() == null) {
			message = "<b>Cooperados Pessoa Física e Pessoa Jurídica</b> são obrigatórios para a(s) UF(s): ";
			getMessageByText(mensagens, message, qsUf.getUf());
		}

		if (Objects.nonNull(qsUf.getCooperadosPFUF()) && Objects.isNull(qsUf.getCooperadosPJUF())) {
			message = "<b>Cooperados Pessoa Jurídica</b> são obrigatórios para a(s) UF(s): ";
			getMessageByText(mensagens, message, qsUf.getUf());
		}

		if (Objects.isNull(qsUf.getCooperadosPFUF()) && Objects.nonNull(qsUf.getCooperadosPJUF())) {
			message = "<b>Cooperados Pessoa Física</b> são obrigatórios para a(s) UF(s): ";
			getMessageByText(mensagens, message, qsUf.getUf());
		}

		if (qsUf.getCooperadosHomensUF() == null || qsUf.getCooperadosMulheresUF() == null) {
			message = "<b>Os campos Homens e Mulheres da quantidade de cooperados</b> são de preenchimento obrigatório para a(s) UF(s): ";
			getMessageByText(mensagens, message, qsUf.getUf());
		}

		if (ValidacaoCampos.validaCampoPreenchido(qsUf.getCooperadosTotalUF())
				&& ValidacaoCampos.validaCampoPreenchido(qsUf.getCooperadosPFUF())
				&& ValidacaoCampos.validaCampoPreenchido(qsUf.getCooperadosPJUF())
				&& ((qsUf.getCooperadosPFUF() + qsUf.getCooperadosPJUF() != qsUf.getCooperadosTotalUF()))) {
			message = "<b>O total Pessoa Física + PessoaJurídica</b> não está correto para a(s) UF(s): ";
			getMessageByText(mensagens, message, qsUf.getUf());

		}

	}

	private void mensagensComunsEmpregadosUf(List<ServiceMessage> mensagens, QuadroSocialUf qsUf) {
		String message = "";
		if (qsUf.getEmpregadosHomensUF() != null && qsUf.getEmpregadosMulheresUF() != null
				&& qsUf.getEmpregadosHomensUF() + qsUf.getEmpregadosMulheresUF() != qsUf.getEmpregadosTotalUF()) {
			message = "O total de <b>empregados</b> não está correto para a UF: ";
			getMessageByText(mensagens, message, qsUf.getUf());
		}

		if (qsUf.getEmpregadosHomensUF() == null || qsUf.getEmpregadosMulheresUF() == null) {
			message = "<b>Os campos Homens e Mulheres da quantidade de empregados</b> são de preenchimento obrigatório para o UF: ";
			getMessageByText(mensagens, message, qsUf.getUf());
		}
	}

	private void getMessageByText(List<ServiceMessage> mensagens, String text, String uf) {
		Optional<ServiceMessage> optionalMessage = mensagens.stream()
				.filter(mensagem -> mensagem.getMessage().contains(text)).findFirst();
		if (optionalMessage.isPresent()) {
			String oldMessage = optionalMessage.get().getMessage();
			optionalMessage.get().setMessage(oldMessage + ", " + uf);
		} else {
			mensagens.add(new ServiceMessage(MessageType.ERROR, text + uf));
		}
	}

	private void mensagensComunsAnoAtual(List<ServiceMessage> mensagens, QuadroSocial qs) {
		if (!ValidacaoCampos.validaCampoPreenchido(qs.getAno())) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, "<b>Dados sociais</b> ano não preenchido"));
		}

		if(isCooperativaNaoRegistrada(qs)){
			if (qs.getId() == null) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>Dados sociais</b> informar a quantidade de cooperados em " + qs.getAno()));
			}

			if ((qs.getCooperadosPF() == null && qs.getCooperadosPJ() == null) && qs.getCooperadosTotal() == null) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>Cooperados Pessoa Física e Pessoa Jurídica</b> são obrigatórios para: " + qs.getAno()));
			}

			if (Objects.nonNull(qs.getCooperadosPF()) && Objects.isNull(qs.getCooperadosPJ())) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>Cooperados Pessoa Jurídica</b> são obrigatórios para: " + qs.getAno()));
			}

			if (Objects.isNull(qs.getCooperadosPF()) && Objects.nonNull(qs.getCooperadosPJ())) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>Cooperados Pessoa Física</b> são obrigatórios para: " + qs.getAno()));
			}

			if (qs.getCooperadosHomens() == null || qs.getCooperadosMulheres() == null || qs.getCooperadosPJ() == null) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>Os campos Homens, Mulheres e Pessoa Jurídica da quantidade de cooperados</b> são de preenchimento obrigatório para o ano: "
								+ qs.getAno()));
			}
		}

		if (ValidacaoCampos.validaCampoPreenchido(qs.getCooperadosTotal())
				&& ValidacaoCampos.validaCampoPreenchido(qs.getCooperadosPF())
				&& ValidacaoCampos.validaCampoPreenchido(qs.getCooperadosPJ())) {
			if (qs.getCooperadosPF() + qs.getCooperadosPJ() != qs.getCooperadosTotal()) {
				mensagens.add(new ServiceMessage(MessageType.ERROR,
						"<b>O total Pessoa Física + PessoaJurídica</b> não está correto para o ano: " + qs.getAno()));
			}
		}

		if (qs.getEmpregadosHomens() != null && qs.getEmpregadosMulheres() != null
				&& qs.getEmpregadosHomens() + qs.getEmpregadosMulheres() != qs.getEmpregadosTotal()) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, "O total de <b>empregados</b> não está correto"));
		}
	}

	private boolean isCooperativaNaoRegistrada(QuadroSocial qs) {
		return qs.getCooperativa().getProgressoMacro() != null && qs.getCooperativa().getProgressoMicro() != null;
	}

}
