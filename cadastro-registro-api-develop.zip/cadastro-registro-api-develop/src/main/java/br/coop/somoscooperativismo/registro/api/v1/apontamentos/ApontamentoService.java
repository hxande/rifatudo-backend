package br.coop.somoscooperativismo.registro.api.v1.apontamentos;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.AcaoProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroTO;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.FaseProcessoRegistroEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.registro.api.v1.apontamentos.entidade.Apontamento;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum;
import br.coop.somoscooperativismo.registro.api.v1.email.util.EmailServiceEvent;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroState;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroStateFactory;
import jakarta.validation.Valid;

@Service
public class ApontamentoService {

    private final ApplicationEventPublisher applicationEventPublisher;

    private final CooperativaHistoricoProcessoRegistroService cooperativaHistoricoProcessoRegistroService;

    private final ApontamentoRepository apontamentoRepository;

    private final KeycloakService keycloakService;

    private final CooperativaService cooperativaService;
    
    private final ProgressoCadastroStateFactory progressoCadastroStateFactory;
    

    public ApontamentoService(
            ApplicationEventPublisher applicationEventPublisher,
            CooperativaHistoricoProcessoRegistroService cooperativaHistoricoProcessoRegistroService,
            @NonNull ApontamentoRepository apontamentoRepository,
                              @NonNull KeycloakService keycloakService, CooperativaService cooperativaService,ProgressoCadastroStateFactory progressoCadastroStateFactory) {
        this.applicationEventPublisher = applicationEventPublisher;
        this.cooperativaHistoricoProcessoRegistroService = cooperativaHistoricoProcessoRegistroService;
        this.apontamentoRepository = apontamentoRepository;
        this.keycloakService = keycloakService;
        this.cooperativaService = cooperativaService;
        this.progressoCadastroStateFactory = progressoCadastroStateFactory;
    }

    public Apontamento save(@Valid Apontamento apontamento) {
        if (null != apontamento) {
            apontamento.setLoginUsuario(keycloakService.getUsername());
            apontamento.setDataApontamento(Calendar.getInstance(
                    TimeZone.getTimeZone("UTC-3"), new Locale("pt", "BR")).getTime());
        }
        assert apontamento != null;

        Boolean apontamentos =  apontamento != null;
        
        Cooperativa coop = cooperativaService.getCooperativa(apontamento.getCooperativa().getId());
        
        ProgressoCadastroState progressoCadastroState = progressoCadastroStateFactory.createAguardandoEmissaoState(apontamentos);
        coop.setProgressoCadastroState(progressoCadastroState);
        coop.trocarEstado();

        apontamento.setCooperativa(coop);
        disparodeEmails(coop, EnvioEmailEventEnum.EMAIL_ENVIAR_APONTAMENTOS);

        gravaProcessoRegistro(coop, AcaoProcessoRegistroEnum.ENVIAR_APONTAMENTOS_NACIONAL, FaseProcessoRegistroEnum.DELIBERACAO);

        coop = null;

        return apontamentoRepository.save(apontamento);
    }

    private void disparodeEmails(Cooperativa c, EnvioEmailEventEnum type) {
        EmailEventTO to = new EmailEventTO();
        to.setCooperativa(c);
        EmailServiceEvent<EmailEventTO> event = new EmailServiceEvent<>(type.getId(), type, to);
        applicationEventPublisher.publishEvent(event);
    }

    private void gravaProcessoRegistro(Cooperativa cooperativa, AcaoProcessoRegistroEnum acao, FaseProcessoRegistroEnum fase) {
        CooperativaHistoricoProcessoRegistroTO to = new CooperativaHistoricoProcessoRegistroTO();
        to.setCooperativaId(cooperativa.getId());
        to.setDataAtualizacao(new Date());
        to.setAcao(acao);
        to.setFase(fase);
        to.setUsuario(keycloakService.getNome());
        cooperativaHistoricoProcessoRegistroService.salvar(to);
    }
}
