package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MandatoImportacaoTO {
    private Integer id;
    private CooperativaImportacaoTO cooperativa;
    private Date dataAssembleia;
    private OrgaoImportacaoTO orgao;
    private Date fimMandato;
    private Integer anosDuracao;
    private Integer membrosMandato;
    private Boolean vigente;
    private List<MandatoMembroImportacaoTO> listaMandatoMembro;
}
