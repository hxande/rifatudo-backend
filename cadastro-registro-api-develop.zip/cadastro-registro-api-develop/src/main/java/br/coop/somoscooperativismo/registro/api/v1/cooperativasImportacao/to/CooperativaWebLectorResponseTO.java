package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.time.LocalDate;
import lombok.Data;

@Data
public class CooperativaWebLectorResponseTO {
    private Integer getId;
    private String getNomeFantasia;
    private String getRazaoSocial;
    private String getCnpj;
    private String getSituacao;
    private String getUfSiglaFinal;
    private String getCep;
    private String getEndereco;
    private String getBairro;
    private String getEnderecoNumero;
    private String getEnderecoComplemento;
    private Integer getMunicipioId;
    private LocalDate getDataAtualizacao;
    private String getUfSigla;
}
