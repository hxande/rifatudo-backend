package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import java.util.Objects;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;

public final class HistoricoCooperativaRegistroUtil {
	private static final String ATIVA = "Ativa";
	private static final String INATIVA = "Inativa";
	private static final String SUSPENSA = "Suspenso";
	private static final String CANCELADA = "Cancelada";
	private static final String IRREGULAR = "Irregular";
	private static final String REGULAR = "Regular";
	private static final String MANTIDA = "Mantido";
	private static final String ALTERADA = "Alterado";
	private static final String SOLICITACAO = "Solicitado";
	private static final String SOLICITACAO_CANCELADA = "Solicitação cancelada";
	private static final String SOLICITACAO_ACEITA = "Solicitação aceita";
	private static final String NOTIFICADA = "Notificação de suspensão";
	private static final String COMUNICACAO_SUSPENSAO = "Orgãos comunicados";
	private HistoricoCooperativaRegistroUtil() {}
	
	public static HistoricoCooperativaRegistroListagemTO getHistoricoCooperativaRegistroListagemTO(CooperativaRegistro registro) {
		// Primeiro histórico regular - regular
		HistoricoCooperativaRegistroListagemTO historico = new HistoricoCooperativaRegistroListagemTO();
		historico.setCooperativaRegistro(registro);
		historico.setCnpj(registro.getCooperativa().getPessoaJuridica().getCnpj());
		historico.setUf(registro.getCooperativa().getPessoaJuridica().getUfSigla());
		historico.setRazaoSocial(registro.getCooperativa().getPessoaJuridica().getRazaoSocial());
		historico.setNomeFantasia(registro.getCooperativa().getPessoaJuridica().getNomeFantasia());
		historico.setRamo(registro.getCooperativa().getPessoaJuridica().getRamo().getNome());
		
		if(ValidacaoCampos.validaCampoPreenchido(registro.getTipoAcao())) {
			
			if(ueSolicita(registro)) {
				historico.setAcao(SOLICITACAO);
			} else if(unMantida(registro)) {
				historico.setAcao(MANTIDA);
			} else if(ueCancela(registro)) {
				historico.setAcao(SOLICITACAO_CANCELADA);
			} else if(unAceita(registro)) {
				historico.setAcao(SOLICITACAO_ACEITA);
			} else if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_NOTIFICA_SUSPENSAO)){
				historico.setAcao(NOTIFICADA);
			} else if(ueComunica(registro)) {
				historico.setAcao(COMUNICACAO_SUSPENSAO);
			}else {
				historico.setAcao(ALTERADA);
			}
			
			// Irregulariza uma cooperativa
			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_APONTA_IRREGULARIDADE)
					|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_APONTA_IRREGULARIDADE)) {
				
				if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_APONTA_IRREGULARIDADE)) {
					historico.setJustificativaUE(registro.getJustificativaIrregular());					
				}
				
				if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_APONTA_IRREGULARIDADE)) {
					historico.setJustificativaUN(registro.getJustificativaIrregular());
				}
			
				historico.setNovaSituacao(IRREGULAR);
				return historico;
			}

			// Regulariza uma cooperativa
			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_REGULARIZA_COOPERATIVA)
					|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_REGULARIZA_COOPERATIVA)) {			
				historico.setNovaSituacao(REGULAR);
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_INATIVACAO)) {
				historico.getCooperativaRegistro().setSituacaoCooperativa(registro.getSituacao().getNome());
				historico.setNovaSituacao(INATIVA);
				historico.setJustificativaUE(registro.getJustificativaSolicitacaoInativacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_SUSPENSAO)) {
				historico.getCooperativaRegistro().setSituacaoCooperativa(registro.getSituacao().getNome());
				historico.setNovaSituacao(SUSPENSA);
				historico.setJustificativaUE(registro.getJustificativaSolicitacaoInativacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_INATIVA_COOPERATIVA)) {
				historico.setNovaSituacao(SUSPENSA);
				historico.setJustificativaUE(registro.getJustificativaInativada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_SUSPENDE_COOPERATIVA)) {
				historico.setNovaSituacao(SUSPENSA);
				historico.setJustificativaUE(registro.getJustificativaInativada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_INATIVACAO)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_SUSPENSAO)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_INATIVACAO)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				historico.setJustificativaUN(registro.getJustificativaAtivacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_SUSPENSAO)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				historico.setJustificativaUN(registro.getJustificativaAtivacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_INATIVACAO)) {
				historico.setNovaSituacao(INATIVA);
				historico.setJustificativaUN(registro.getJustificativaInativada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_SUSPENSAO)) {
				historico.setNovaSituacao(SUSPENSA);
				historico.setJustificativaUN(registro.getJustificativaInativada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO)) {
				historico.getCooperativaRegistro().setSituacaoCooperativa(registro.getSituacao().getNome());
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUE(registro.getJustificativaSolicitacaoCancelamento());
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO_COOPERATIVA_ATIVA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO_COOPERATIVA_REGULAR)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUE(registro.getJustificativaSolicitacaoCancelamento());
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO_ATIVA)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				historico.setJustificativaUE(registro.getJustificativaSolicitacaoCancelamento());
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO_REGULAR)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				historico.setJustificativaUE(registro.getJustificativaSolicitacaoCancelamento());
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_CANCELAMENTO)) {
				historico.setNovaSituacao(registro.getSituacao().getNome());
				carregaNovaSituacaoCooperativaHistorico(registro, historico);
				historico.setJustificativaUE("");
				historico.setJustificativaUN("");
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_CANCELAMENTO)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_CANCELAMENTO_ATIVA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_CANCELAMENTO_REGULAR)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO)) {
				historico.setNovaSituacao(INATIVA);
				carregaNovaSituacaoCooperativaHistorico(registro, historico);
				historico.setJustificativaUN(registro.getJustificativaInativada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_CANCELA_COOPERATIVA)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_CANCELA_COOPERATIVA_ATIVA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_CANCELA_COOPERATIVA_REGULAR)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_CANCELA_COOPERATIVA_IRREGULAR)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(ATIVA);
				historico.setJustificativaUN(registro.getJustificativaAtivacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(REGULAR);
				historico.setJustificativaUN(registro.getJustificativaAtivacao());
				return historico;
			}
			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA)) {
				historico.setNovaSituacao(ATIVA);
				historico.setJustificativaUN(registro.getJustificativaSolicitacaoAtivacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_SUSPENSA)) {
				historico.setNovaSituacao(REGULAR);
				historico.setJustificativaUN(registro.getJustificativaSolicitacaoAtivacao());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA)) {
				historico.setNovaSituacao(INATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_SUSPENSA)) {
				historico.setNovaSituacao(SUSPENSA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_ATIVACAO_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(CANCELADA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ATIVA_COOPERATIVA_INATIVA)) {
				historico.setNovaSituacao(ATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_REGULARIZA_COOPERATIVA_SUSPENSA)) {
				historico.setNovaSituacao(REGULAR);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_INATIVA_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(INATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_SUSPENDE_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(SUSPENSA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}
			
			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ATIVA_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(ATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_REGULARIZA_COOPERATIVA_CANCELADA)) {
				historico.setNovaSituacao(REGULAR);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_ATIVACAO)) {
				historico.setNovaSituacao(ATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_REGULARIZACAO)) {
				historico.getCooperativaRegistro().setSituacaoCooperativa(registro.getSituacao().getNome());
				historico.setNovaSituacao(REGULAR);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}
			
			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_ATIVACAO)) {
				historico.setNovaSituacao(INATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}

			if(Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_REGULARIZACAO)) {
				historico.setNovaSituacao(INATIVA);
				historico.setJustificativaUN(registro.getJustificativaCancelada());
				return historico;
			}
			
		}
		
		if (Boolean.TRUE.equals(registro.getSolicitacaoCancelamento())) {
			historico.setAcao(SOLICITACAO);
			historico.setNovaSituacao(CANCELADA);
			historico.getCooperativaRegistro().setSituacaoCooperativa(registro.getSituacao().getNome());
		}
		
		return historico;
		
	}

	private static void carregaNovaSituacaoCooperativaHistorico(CooperativaRegistro registro,
			HistoricoCooperativaRegistroListagemTO historico) {
		
		if(ValidacaoCampos.validaCampoPreenchido(registro.getCooperativa().getSituacaoCooperativa())
				&& registro.getCooperativa().getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.REGULAR.getCodigo())) {
			historico.setNovaSituacao(REGULAR);
		}
		
		if(ValidacaoCampos.validaCampoPreenchido(registro.getCooperativa().getSituacaoCooperativa())
				&& registro.getCooperativa().getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.CANCELADA.getCodigo())) {
			historico.setNovaSituacao(CANCELADA);
		}
		
		if(ValidacaoCampos.validaCampoPreenchido(registro.getCooperativa().getSituacaoCooperativa())
				&& registro.getCooperativa().getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.SUSPENSA.getCodigo())) {
			historico.setNovaSituacao(SUSPENSA);
		}
		
		if(ValidacaoCampos.validaCampoPreenchido(registro.getCooperativa().getSituacaoCooperativa())
				&& registro.getCooperativa().getSituacaoCooperativa().getId().equals(NovaSituacaoCooperativaEnum.IRREGULAR.getCodigo())) {
			historico.setNovaSituacao(IRREGULAR);
		}
	}
	
	private static boolean ueSolicita(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_ATIVACAO)
				|| ueSolicitaCancelamentoInativacaoSuspensao(registro)
				|| ueSolicitaCancelamentoCooperativaRegularizacaoCancelamentoCooperativaRegular(registro);
	}

	private static boolean ueComunica(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_COMUNICA_ORGAOS_SUSPENSAO);
	}
	
	private static boolean ueSolicitaCancelamentoInativacaoSuspensao(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_INATIVACAO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_SUSPENSAO);
	}
	
	private static boolean ueSolicitaCancelamentoCooperativaRegularizacaoCancelamentoCooperativaRegular(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO_COOPERATIVA_ATIVA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_REGULARIZACAO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_SOLICITA_CANCELAMENTO_COOPERATIVA_REGULAR);
	}
	
	private static boolean unMantida(CooperativaRegistro registro) {
		return unMantidaCooperativaInativaCanceladaCancelamento(registro)
				|| unMantidaSolicitacaoAtivaInativaSuspensao(registro)
				|| unMantidaSolicitacaoRegularSuspensaCancelada(registro);
	}
	
	private static boolean unMantidaCooperativaInativaCanceladaCancelamento(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_ATIVACAO_COOPERATIVA_CANCELADA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO);
	}
	
	private static boolean unMantidaSolicitacaoAtivaInativaSuspensao(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO_ATIVA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_INATIVACAO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_SUSPENSAO);
	}
	
	private static boolean unMantidaSolicitacaoRegularSuspensaCancelada(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_CANCELAMENTO_REGULAR)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_SUSPENSA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_RECUSA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_CANCELADA);
	}
	
	private static boolean ueCancela(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_CANCELAMENTO)
				|| ueCancelaInativacaoSuspensao(registro)
				|| ueCancelaAtivacaoRegularizacao(registro);
	}
	
	private static boolean ueCancelaInativacaoSuspensao(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_INATIVACAO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_SUSPENSAO);
	}
	
	private static boolean ueCancelaAtivacaoRegularizacao(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_ATIVACAO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UE_CANCELA_SOLICITACAO_REGULARIZACAO);
	}
	
	private static boolean unAceita(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA)
				|| unAceitaSolicitacaoCanceladaCancelamentoInativacao(registro)
				|| unAceitaSolicitacaoSuspensaoSuspensaCancelada(registro);
	}
	
	private static boolean unAceitaSolicitacaoCanceladaCancelamentoInativacao(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_CANCELADA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_CANCELAMENTO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_INATIVACAO);
	}
	
	private static boolean unAceitaSolicitacaoSuspensaoSuspensaCancelada(CooperativaRegistro registro) {
		return Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_SUSPENSAO)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_SUSPENSA)
				|| Objects.equals(registro.getTipoAcao(), TipoAcaoEnum.UN_ACEITA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_CANCELADA);
	}
}
