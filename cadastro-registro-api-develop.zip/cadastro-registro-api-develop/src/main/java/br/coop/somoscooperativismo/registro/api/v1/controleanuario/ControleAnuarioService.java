package br.coop.somoscooperativismo.registro.api.v1.controleanuario;

import br.coop.somoscooperativismo.registro.api.v1.controleanuario.entidade.ControleAnuario;
import java.util.Arrays;
import java.util.Optional;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Service
public class ControleAnuarioService {
    private static final String NAO_ENCONTRADO = "controleAnuario.naoEncontrado";
    final ControleAnuarioRepository controleAnuarioRepository;

    private final MessagesService messages;

    public ControleAnuarioService(ControleAnuarioRepository controleAnuarioRepository, MessagesService messages) {
        this.controleAnuarioRepository = controleAnuarioRepository;
        this.messages = messages;
    }

    public @Valid ControleAnuario findByChaveAnuario(@Valid String chaveAnuario) {
        Optional<ControleAnuario> op = controleAnuarioRepository.findControleAnuarioByChaveAnuario(chaveAnuario);
        if (op.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        return op.get();
    }

    public @Valid ControleAnuario updateControleAnuario(@Valid ControleAnuario controleAnuario) {
        Optional<ControleAnuario> op = controleAnuarioRepository.findControleAnuarioByChaveAnuario(controleAnuario.getChaveAnuario());
        if (op.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        return controleAnuarioRepository.save(controleAnuario);
    }

    public boolean podeSalvarAnuario(String entidade) {
        ControleAnuario controleAnuario = findControleAnuarioByChaveAnuario("SESCOOP");
        String[] ary = controleAnuario.getPreencherAnuario().split(",");

        controleAnuario = null;

        return Arrays.asList(ary).contains(entidade);
    }

    public boolean podeVisualizarAnuario(String entidade) {
        ControleAnuario controleAnuario = findControleAnuarioByChaveAnuario("SESCOOP");
        String[] ary = controleAnuario.getVisualizarAnuario().split(",");

        controleAnuario = null;

        return Arrays.asList(ary).contains(entidade);
    }

    protected ControleAnuario findControleAnuarioByChaveAnuario(String chaveAnuario) {
        Optional<ControleAnuario> op = controleAnuarioRepository.findControleAnuarioByChaveAnuario(chaveAnuario);
        if (op.isEmpty()) {
            throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
        }
        return op.get();
    }
}