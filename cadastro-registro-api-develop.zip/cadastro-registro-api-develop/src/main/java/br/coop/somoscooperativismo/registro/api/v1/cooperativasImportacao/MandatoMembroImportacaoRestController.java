package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.MandatoMembroImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.MandatoMembroService;

@RestController
@RequestMapping("/api/v1/cooperativas-importacao/mandatos-membros")
public class MandatoMembroImportacaoRestController extends MandatoMembroImportacaoAbstractController {

    private final MandatoMembroService mandatoMembroService;

    public MandatoMembroImportacaoRestController(ModelMapper modelMapper, MandatoMembroService mandatoMembroService) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, MandatoMembro.class, MandatoMembroImportacaoTO.class);
        this.mandatoMembroService = mandatoMembroService;
    }

    @GetMapping("/mandato/{idMandato}")
    public ResponseEntity<List<MandatoMembroImportacaoTO>> getByMandatoId(@PathVariable Integer idMandato) {
        return ResponseEntity.ok(mandatoMembroService.getMandatosMembroPorMandato(idMandato).stream()
                .map(mandatoMembro -> modelMapper.map(mandatoMembro, MandatoMembroImportacaoTO.class)).collect(Collectors.toList()));
    }
}
