package br.coop.somoscooperativismo.registro.api.v1.events.listeners;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.entidade.CensoAnuarioPreenchimento;
import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.CensoAnuarioPreenchimentoService;
import br.coop.somoscooperativismo.registro.api.v1.events.events.CensoAnuarioPreenchimentoEvent;

@Component
public class CensoAnuarioPreenchimentoFimListener implements ApplicationListener<CensoAnuarioPreenchimentoEvent>{

	private final CensoAnuarioPreenchimentoService censoAnuarioPreenchimentoService;
	
	public CensoAnuarioPreenchimentoFimListener(CensoAnuarioPreenchimentoService censoAnuarioPreenchimentoService) {
		this.censoAnuarioPreenchimentoService = censoAnuarioPreenchimentoService;
	}
	
	@Override
	public void onApplicationEvent(CensoAnuarioPreenchimentoEvent event) {
		CensoAnuarioPreenchimento censoAnuarioPreenchimento = event.getCensoAnuarioPreenchimento();
		if(Boolean.TRUE.equals(censoAnuarioPreenchimento.getFinaliza())) 
			censoAnuarioPreenchimentoService.finalizaPreenchimento(censoAnuarioPreenchimento);

		censoAnuarioPreenchimento = null;
	}

}
