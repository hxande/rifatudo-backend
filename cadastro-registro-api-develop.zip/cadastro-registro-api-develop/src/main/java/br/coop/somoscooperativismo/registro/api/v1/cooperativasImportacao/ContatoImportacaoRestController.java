package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import br.coop.somoscooperativismo.registro.api.v1.contato.ContatoService;
import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.contato.to.ContatoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.ContatoImportacaoTO;
import jakarta.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/cooperativas-importacao/contatos")
public class ContatoImportacaoRestController extends ContatoImportacaoAbstractController {

    private final ContatoService contatoService;

    public ContatoImportacaoRestController(@NonNull ModelMapper modelMapper, @NonNull ContatoService contatoService) {
        super(modelMapper);
        modelMapper.addConverter(converterEntidadeParaTO, Contato.class, ContatoImportacaoTO.class);
        this.contatoService = contatoService;
    }

    @PostMapping("/{idPessoa}")
    public ResponseEntity<Void> salvar(@PathVariable Integer idPessoa, @RequestBody @Valid List<ContatoTO> contatos) {
        contatoService.salvaListaContatos(contatos, idPessoa);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/uf/{uf}")
    public ResponseEntity<List<ContatoImportacaoTO>> getByUf(@PathVariable String uf) {
        return ResponseEntity.ok(contatoService.getByUf(uf).stream()
                .map(contato -> modelMapper.map(contato, ContatoImportacaoTO.class)).collect(Collectors.toList()));
    }

}
