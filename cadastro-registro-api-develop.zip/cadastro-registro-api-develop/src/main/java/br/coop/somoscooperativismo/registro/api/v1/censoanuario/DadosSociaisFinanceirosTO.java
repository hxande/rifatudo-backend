package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Getter
@AllArgsConstructor
@Builder
public final class DadosSociaisFinanceirosTO {
    private final QuadroSocial quadrosSociais;
    private final DadosIntegracaoTO financeiro;
}
