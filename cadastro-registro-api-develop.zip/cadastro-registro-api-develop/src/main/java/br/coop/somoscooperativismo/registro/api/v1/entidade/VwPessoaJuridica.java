package br.coop.somoscooperativismo.registro.api.v1.entidade;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;

@Entity
@Table(name="VW_PESSOA_JURIDICA")
public class VwPessoaJuridica implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SQ_PESSOA")
	private Integer id;

	@Column(name = "TX_CNPJ")
	@Size(max = 14)
	private String cnpj;

	@Column(name = "TX_RAZAO_SOCIAL", nullable = false)
	private String razaoSocial;

	@Column(name = "TX_NOME_FANTASIA")
	@Size(max = 255)
	private String nomeFantasia;

	@Column(name = "TX_UF_SIGLA", columnDefinition = "char(2)")
	private String ufSigla;

	@Column(name = "TX_TIPO_PESSOA_JURIDICA", columnDefinition = "char(1)")
	@Size(max = 1)
	private String tipoPessoa;

	@Column(name="SQ_RAMO", columnDefinition="tinyint(4)")
	private Integer idRamo;

	@Column(name = "TX_RAMO")
	private String ramo;
	
	@Column(name = "IN_MATRIZ", nullable = false)
	private Boolean matriz;
	
	@Column(name = "SEGMENTOS")
	private String segmentos;
	
	@Column(name = "SQ_REGIAO_PAIS")
	private Integer idRegiaoPais;
	
	@Column(name = "REGIOES_NO_ESTADO")
	private String regioesEstado;

	@Column(name = "NOME_REGIOES_NO_ESTADO")
	private String nomeRegioesEstado;

	@Column(name = "COOPERATIVAS_VINCULADAS")
	private String cooperativasVinculadas;

	@Column(name = "SQ_SITUACAO_COOPERATIVA", columnDefinition = "tinyint(1)")
	private Integer situacaoCooperativa;

	@Column(name = "DT_REGISTRO_OCB")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
	private Date dtRegistroOCB;

	@Column(name = "DT_ATUALIZACAO")
	private Date dataAtualizacao;

	@Column(name = "TX_TIPO_UNIDADE", columnDefinition = "char(1)")
	@Size(max = 1)
	private String tipoUnidade;

    @Column(name = "IN_REGULARIDADE_COOPERATIVA", columnDefinition = "char(1)")
    private String statusCooperativa;

	@Column(name="TX_NUMERO_REGISTRO_OCB")
	private String numeroRegistroOCB;

	@Column(name = "SQ_MUNICIPIO")
	private Integer idMunicipio;

	public Integer getId() {
		return id;
	}

	public String getCnpj() {
		return cnpj;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public String getNomeFantasia() {
		return nomeFantasia;
	}

	public String getUfSigla() {
		return ufSigla;
	}

	public String getTipoPessoa() {
		return tipoPessoa;
	}

	public Integer getIdRamo() {
		return idRamo;
	}

	public String getRamo() {
		return ramo;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	public void setUfSigla(String ufSigla) {
		this.ufSigla = ufSigla;
	}

	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	public void setIdRamo(Integer idRamo) {
		this.idRamo = idRamo;
	}

	public Boolean getMatriz() {
		return matriz;
	}

	public void setMatriz(Boolean matriz) {
		this.matriz = matriz;
	}

	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	public String getNomePessoaJuridica() {
		return ValidacaoCampos.validaCampoPreenchido(nomeFantasia) ? nomeFantasia : razaoSocial;
	}

	public String getSegmentos() {
		return segmentos;
	}

	public Integer getIdRegiaoPais() {
		return idRegiaoPais;
	}

	public String getRegioesEstado() {
		return regioesEstado;
	}

	public void setSegmentos(String segmentos) {
		this.segmentos = segmentos;
	}

	public void setIdRegiaoPais(Integer idRegiaoPais) {
		this.idRegiaoPais = idRegiaoPais;
	}

	public String getNomeRegioesEstado() {
		return nomeRegioesEstado;
	}

	public void setNomeRegioesEstado(String nomeRegioesEstado) {
		this.nomeRegioesEstado = nomeRegioesEstado;
	}

	public void setRegioesEstado(String regioesEstado) {
		this.regioesEstado = regioesEstado;
	}

	public String getNomeCompletoPessoaJuridica() {
		return "%s - %s - %s".formatted(cnpj, ufSigla, (ValidacaoCampos.validaCampoPreenchido(nomeFantasia) ? nomeFantasia : ""));
	}

	public String getCooperativasVinculadas() {
		return cooperativasVinculadas;
	}

	public void setCooperativasVinculadas(String cooperativasVinculadas) {
		this.cooperativasVinculadas = cooperativasVinculadas;
	}

	public Integer getSituacaoCooperativa() {
		return situacaoCooperativa;
	}

	public void setSituacaoCooperativa(Integer situacaoCooperativa) {
		this.situacaoCooperativa = situacaoCooperativa;
	}

	public Date getDtRegistroOCB() {
		return dtRegistroOCB;
	}

	public void setDtRegistroOCB(Date dtRegistroOCB) {
		this.dtRegistroOCB = dtRegistroOCB;
	}

	public Date getDataAtualizacao() {
		return dataAtualizacao;
	}

	public void setDataAtualizacao(Date dataAtualizacao) {
		this.dataAtualizacao = dataAtualizacao;
	}

	public String getTipoUnidade() {
		return tipoUnidade;
	}

	public void setTipoUnidade(String tipoUnidade) {
		this.tipoUnidade = tipoUnidade;
	}

    public String getStatusCooperativa() {
        return statusCooperativa;
    }

    public void setStatusCooperativa(String statusCooperativa) {
        this.statusCooperativa = statusCooperativa;
    }

	public String getNumeroRegistroOcb() {
		return numeroRegistroOCB;
	}

	public void setNumeroRegistroOcb(String numeroRegistroOcb) {
		this.numeroRegistroOCB = numeroRegistroOcb;
	}

	public Integer getIdMunicipio() {
		return idMunicipio;
	}

	public void setIdMunicipio(Integer idMunicipio) {
		this.idMunicipio = idMunicipio;
	}
}
