package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

@Service
public class ArrecadacaoService {

    private final ArrecadacaoClient arrecadacaoClient;

    public ArrecadacaoService(ArrecadacaoClient arrecadacaoClient) {
        this.arrecadacaoClient = arrecadacaoClient;
    }

    public Set<AdesaoUnidadeEstadualTO> getAllAdesao() {
        return arrecadacaoClient.getAllAdesao();
    }

    public Integer getNumeroPendencia() {
        return arrecadacaoClient.getNumeroPendencia();
    }

    public List<QuadroSituacaoFinanceiraTO> getListaArrecadacao(Integer idCooperativa, Integer tipoContribuicao) {
        return arrecadacaoClient.getListaArrecadacao(idCooperativa, tipoContribuicao);
    }

    public TaxaRegistroTO getTaxaRegistro(Integer idCooperativa) {
        return arrecadacaoClient.getTaxaRegistro(idCooperativa);
    }

}
