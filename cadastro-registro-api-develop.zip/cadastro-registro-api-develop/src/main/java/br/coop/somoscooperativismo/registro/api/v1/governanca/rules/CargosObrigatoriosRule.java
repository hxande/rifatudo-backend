package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import br.coop.somoscooperativismo.registro.api.v1.orgaocargo.entidade.OrgaoCargo;
import br.coop.somoscooperativismo.registro.api.v1.orgaoramo.entidade.OrgaoRamo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * INV-9 (FR-011) — os cargos obrigatórios do órgão permanecem atribuídos, e
 * nenhum membro fica com cargo que foi retirado do órgão. Órgão opcional
 * desmarcado (INV-7/FR-012, {@code obrigatorio || coopPossui} do legado) não é
 * avaliado — achado P2 nº 13 do code review 2026-07-03.
 *
 * <p>Paridade: {@code GovernancaService.validaCargos} e
 * {@code validaCargosRetiradosDoOrgao}.</p>
 */
@Component
@RequiredArgsConstructor
public class CargosObrigatoriosRule implements GovernancaRule {

    private final OrgaoRamoResolver resolver;

    @Override
    public List<ViolacaoGovernanca> avaliar(GovernancaContext contexto) {
        List<ViolacaoGovernanca> violacoes = new ArrayList<>();
        for (Mandato mandato : contexto.getMandatos()) {
            if (mandato.getOrgao() == null || mandato.getOrgao().getId() == null) {
                continue;
            }
            if (!Boolean.TRUE.equals(mandato.getVigente())) {
                continue;
            }
            if (orgaoOpcionalDesmarcado(contexto, mandato)) {
                continue; // INV-7: órgão opcional desmarcado não exige cargos
            }
            Integer idOrgao = mandato.getOrgao().getId();
            String nomeOrgao = mandato.getOrgao().getNome();
            List<MandatoMembro> membros = GovernancaContext.membros(mandato);

            Set<Integer> cargosDosMembros = new HashSet<>();
            for (MandatoMembro membro : membros) {
                if (membro.getCargo() != null && membro.getCargo().getId() != null) {
                    cargosDosMembros.add(membro.getCargo().getId());
                }
            }

            // Cargo obrigatório ausente
            for (OrgaoCargo cargoObrigatorio : contexto.cargosObrigatoriosDe(idOrgao)) {
                Integer idCargo = cargoObrigatorio.getCargo() != null ? cargoObrigatorio.getCargo().getId() : null;
                if (idCargo != null && !cargosDosMembros.contains(idCargo)) {
                    String nomeCargo = cargoObrigatorio.getCargo().getNome();
                    violacoes.add(ViolacaoGovernanca.deOrgaoDetalhe(
                            TipoViolacaoGovernanca.CARGO_OBRIGATORIO_AUSENTE, nomeOrgao, nomeCargo));
                }
            }

            // Cargo do membro retirado do órgão
            Set<Integer> cargosDoOrgao = new HashSet<>();
            for (OrgaoCargo orgaoCargo : contexto.cargosDe(idOrgao)) {
                if (orgaoCargo.getCargo() != null && orgaoCargo.getCargo().getId() != null) {
                    cargosDoOrgao.add(orgaoCargo.getCargo().getId());
                }
            }
            if (!cargosDoOrgao.isEmpty()) {
                for (MandatoMembro membro : membros) {
                    if (membro.getCargo() != null && membro.getCargo().getId() != null
                            && !cargosDoOrgao.contains(membro.getCargo().getId())) {
                        String nomeMembro = membro.getPessoaFisica() != null ? membro.getPessoaFisica().getNome() : null;
                        violacoes.add(ViolacaoGovernanca.deOrgaoDetalhe(
                                TipoViolacaoGovernanca.CARGO_RETIRADO_DO_ORGAO, nomeOrgao, nomeMembro));
                    }
                }
            }
        }
        return violacoes;
    }

    /**
     * Guard {@code deveValidar} do legado ({@code obrigatorio || coopPossui}). Sem
     * {@code OrgaoRamo} na matriz, mantém a avaliação (comportamento atual).
     */
    private boolean orgaoOpcionalDesmarcado(GovernancaContext contexto, Mandato mandato) {
        OrgaoRamo orgaoRamo = contexto.orgaoRamoDe(mandato.getOrgao().getId());
        if (orgaoRamo == null) {
            return false;
        }
        return !resolver.obrigatorio(contexto.getSituacao(), orgaoRamo)
                && !Boolean.TRUE.equals(mandato.getCoopPossui());
    }
}
