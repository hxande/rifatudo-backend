package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioFieldsTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.EstruturaIntegracaoParametroTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util.ConversorParametroIntegracaoService;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util.MapeadorFieldService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.CensoAnuarioService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.DadosSociaisFinanceirosTO;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.LocalizacaoClient;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.to.PaisTO;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoService;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DadosNegociosAbaAdapter {

    private final MapeadorFieldService mapeadorFieldService;
    private final CensoAnuarioService censoAnuarioService;
    private final ConversorParametroIntegracaoService conversorParametroIntegracaoService;
    private final NegocioExportacaoService negocioExportacaoService;
    private final LocalizacaoClient localizacaoClient;

    public boolean execute(Integer idCooperativa, Integer ano, RequestAnuarioTO request, boolean isSubmit) {
        NegocioExportacaoTO negocioExportacaoTO = new NegocioExportacaoTO();

        for (RequestAnuarioFieldsTO grupo : request.getFields()) {
            if (grupo.getName().equals(NomeQuadroEnum.NEGOCIO_EXPORTACAO.toString())) {
                this.processarNegocioExportacao(grupo, negocioExportacaoTO);
            }
        }

        negocioExportacaoTO.setCooperativaId(idCooperativa);
        negocioExportacaoTO.setAno(ano);
        this.negocioExportacaoService.salvarNegocioExportacao(negocioExportacaoTO);

        return this.processarDadosIntegracao(idCooperativa, ano, request, isSubmit);
    }

    private void processarNegocioExportacao(RequestAnuarioFieldsTO grupo, NegocioExportacaoTO negocioExportacaoTO) {
        List<DadosDinamicosTO> dadosDinamicos = mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), NegocioExportacaoTO.class);
        List<PaisTO> paises = localizacaoClient.listarPaises();

        dadosDinamicos.forEach(dado -> {
            for (Map.Entry<String, FieldTO> entry : dado.getCamposOriginais().entrySet()) {

                String chave = entry.getKey();
                FieldTO campo = entry.getValue();

                if ("realizaExportacao".equals(chave) && campo.getValue() != null) {
                    negocioExportacaoTO.setExportacao("1".equals(campo.getValue()));
                }

                if ("modalidadeExportacao".equals(chave)) {
                    negocioExportacaoTO.setModalidade(campo.getValue());
                }

                if ("paisesExportacao".equals(chave)) {
                    Set<Integer> idsSelecionados =
                            Optional.ofNullable(campo.getValue())
                                    .map(v -> v.replace("[", "").replace("]", ""))
                                    .stream()
                                    .flatMap(v -> Arrays.stream(v.split(",")))
                                    .map(String::trim)
                                    .filter(s -> !s.isEmpty())
                                    .map(Integer::valueOf)
                                    .collect(Collectors.toSet());

                    List<PaisTO> paisesFiltrados =
                            paises.stream()
                                    .filter(pais -> idsSelecionados.contains(pais.getId()))
                                    .toList();
                    negocioExportacaoTO.setPaises(paisesFiltrados);
                }
            }
        });
    }

    private boolean processarDadosIntegracao(
            Integer idCooperativa,
            Integer ano,
            RequestAnuarioTO request, boolean isSubmit) {

        List<DadosDinamicosTO> dadosDinamicos = request.getFields().stream()
                .flatMap(grupo ->
                        mapeadorFieldService
                                .mapFieldsToHybrid(grupo.getFields(), DadosSociaisFinanceirosTO.class)
                                .stream()
                )
                .toList();

        var dadosDinamicosNegocio =
                conversorParametroIntegracaoService.converterDadosDinamicosNegocio(dadosDinamicos);

        List<DadosIntegracaoTO> listaDadosIntegracao =
                dadosDinamicosNegocio.entrySet().stream()
                        .map(entry -> montarDadosIntegracao(
                                idCooperativa,
                                ano,
                                entry.getKey(),
                                entry.getValue(),
                                request.getSituacao()
                        ))
                        .toList();

        boolean processamento = false;
        for (var dado : listaDadosIntegracao) {
            processamento = censoAnuarioService.salvarIntegracao(dado, isSubmit);
        }

        return processamento;
    }

    private DadosIntegracaoTO montarDadosIntegracao(
            Integer idCooperativa,
            Integer ano,
            String chave,
            List<EstruturaIntegracaoParametroTO> valor,
            Integer situacao) {

        DadosIntegracaoTO dadosIntegracaoTO = new DadosIntegracaoTO();
        dadosIntegracaoTO.setIdCooperativa(idCooperativa);
        dadosIntegracaoTO.setAno(ano);
        dadosIntegracaoTO.setSituacao(situacao);

        var dados = conversorParametroIntegracaoService.montaParametro(valor);

        switch (chave) {
            case "Negócio - Setoriais" -> dadosIntegracaoTO.setNegociosSetorias(dados);
            case "Negócio - Intercooperação" -> dadosIntegracaoTO.setNegociosIntercooperacao(dados);
            case "Negócio - Exportação" -> dadosIntegracaoTO.setNegociosExportacao(dados);
            case "Negócio - Vendas On-line" -> dadosIntegracaoTO.setNegociosVendasOnline(dados);
            default -> throw new RegraNegocioException("Grupo negócio desconhecido: " + chave);
        }

        return dadosIntegracaoTO;
    }
}
