package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums;

public enum InputTypeEnum {
    TEXT("text"),
    NUMBER("number"),
    DATA ("data");

    public String type;

    InputTypeEnum(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

}
