package br.coop.somoscooperativismo.registro.api.v1.eventoemail;

import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmailHistorico;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DisparoEmailHistoricoRepository extends JpaRepository<DisparoEmailHistorico, Integer> {

	Optional<DisparoEmailHistorico> findByDisparoEmailAndIdCooperativa(DisparoEmail disparoEmail, Integer idCooperativa);

}
