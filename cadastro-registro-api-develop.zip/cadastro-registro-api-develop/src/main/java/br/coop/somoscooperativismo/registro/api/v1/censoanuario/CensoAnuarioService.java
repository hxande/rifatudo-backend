package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import java.util.List;
import java.util.Optional;

import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestPortfolioTO;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.entidade.PessoaSegmProdServ;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.to.QuadroSocialAnuarioTO;

public interface CensoAnuarioService {
    CensoAnuarioTO create(CensoAnuarioTO censoAnuarioTO, boolean isSubmit);
    Optional<CensoAnuarioTO> update(Integer id, CensoAnuarioTO censoAnuarioTO, boolean isSubmit);
    Optional<CensoAnuarioTO> getByAnoAndCooperativaId(Integer ano, Integer cooperativaId);
    boolean salvarIntegracao(DadosIntegracaoTO dadosIntegracao, boolean isSubmit);
    void comunicarUnidadeEstadualSubmissaoAnuario(Integer cooperativaId);
    boolean getCheckAnuarioAtualizado(Integer cooperativaId);
    boolean salvarAbaDadosSociais(Integer cooperativaId, Integer ano, List<QuadroSocialAnuarioTO> listQuadroSocialAnuarioTO, Integer situacao, boolean isSubmit);
    boolean salvarAbaDadosSociais(Integer cooperativaId, Integer ano, DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO, Integer situacao, boolean isSubmit);
    boolean salvarAbaPortfolio(Integer cooperativaId, Integer ano, RequestPortfolioTO requestPortfolioTO);
    boolean salvarAbaDadosFinanceiros(Integer cooperativaId, Integer ano, DadosSociaisFinanceirosTO dadosSociaisFinanceirosTO, boolean isSubmit);
    boolean salvarAbaIntercooperacao(DadosIntegracaoTO dadosIntegracaoTO, boolean isSubmit);
    boolean podeVisualizarAnuario();
    String getStatusAtualizacaoAnuario(Integer idCooperativa);
    CensoAnuarioRecord obterPorAnoAndCooperativaId(Integer ano, Integer cooperativaId);
    ImportacaoAnuarioResultadoTO processarImportacao(Integer cooperativaId, Integer ano);

}
