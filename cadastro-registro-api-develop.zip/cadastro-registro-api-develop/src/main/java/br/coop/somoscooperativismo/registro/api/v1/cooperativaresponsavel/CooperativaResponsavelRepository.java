package br.coop.somoscooperativismo.registro.api.v1.cooperativaresponsavel;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaresponsavel.entidade.CooperativaResponsavel;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

public interface CooperativaResponsavelRepository extends JpaRepository<CooperativaResponsavel, Integer> {

	
	List<CooperativaResponsavel> findCooperativaResponsavelByIdPessoaJuridica(@Param("idPessoaJuridica") Integer idPessoaJuridica);
}
