package br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote;

import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.entidade.CooperativaValidacaoLote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CooperativaValidacaoLoteRepository extends JpaRepository<CooperativaValidacaoLote, Long> {

    List<CooperativaValidacaoLote> findByAnoReferencia(Integer anoReferencia);

    Optional<CooperativaValidacaoLote> findByCooperativaIdAndAnoReferencia(Integer cooperativaId, Integer anoReferencia);

}
