package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.springframework.lang.NonNull;

import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.EnderecoImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.PessoaImportacaoTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to.TipoEnderecoTO;
import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class EnderecoImportacaoAbstractController {

    @NonNull
    protected ModelMapper modelMapper;

    protected Converter<Endereco, EnderecoImportacaoTO> converterEntidadeParaTO = context ->
            EnderecoImportacaoTO.builder()
                    .id(context.getSource().getId())
                    .idEstado(context.getSource().getIdEstado())
                    .idMunicipio(context.getSource().getIdMunicipio())
                    .tipoEndereco(TipoEnderecoTO.builder()
                            .id(context.getSource().getTipoEndereco().getId())
                            .nome(context.getSource().getTipoEndereco().getNome())
                            .enderecoPrincipal(context.getSource().getTipoEndereco().getEnderecoPrincipal())
                            .enderecoCorrespondencia(context.getSource().getTipoEndereco().getEnderecoCorrespondencia())
                            .ativo(context.getSource().getTipoEndereco().getAtivo())
                            .ordem(context.getSource().getTipoEndereco().getOrdem())
                            .build()
                    )
                    .pessoa(PessoaImportacaoTO.builder()
                            .id(context.getSource().getPessoa().getId())
                            .build())
                    .cep(context.getSource().getCep())
                    .bairro(context.getSource().getBairro())
                    .enderecoReferencia(context.getSource().getEnderecoReferencia())
                    .numero(context.getSource().getNumero())
                    .complemento(context.getSource().getComplemento())
                    .descricaoEndereco(context.getSource().getDescricaoEndereco())
                    .correspondenciaDiferente(context.getSource().getCorrespondenciaDiferente())
                    .build();
}
