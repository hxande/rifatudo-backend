package br.coop.somoscooperativismo.registro.api.v1.cooperativaobservacaoue.entidade;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <b>CooperativaObservacaoUe</b><br>
 * Entidade que representa uma observação no registro da cooperativa feita pela
 * Unidade Estadual. <br>
 * <br>
 * No máximo uma observação (ou nenhuma) deve estar ativa por cooperativa,
 * estando as outras (se houverem) com a data de exclusão preenchida.<br>
 * <br>
 * Permissões:<br>
 * Leitura: Unidade Estadual (do estado da cooperativa) e Unidade Nacional.<br>
 * Gravação: Unidade Estadual (do estado da cooperativa) e Unidade Nacional, no
 * entanto ambos devem possuir o perfil de gestor.
 * 
 * @since 19 de novembro de 2020.
 * @author brunno.stefanini
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "COOPERATIVA_OBSERVACAO_UE")
public class CooperativaObservacaoUe {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_COOPERATIVA_OBSERVACAO_UE")
	private Integer id;

	@Column(name = "SQ_COOPERATIVA", nullable = false)
	private Integer idCooperativa;

	@Column(name = "TX_NOME_USUARIO_INCLUSAO", nullable = false)
	private String nomeUsuarioInclusao;

	@Column(name = "DT_INCLUSAO", nullable = false)
	private LocalDateTime dataDeInclusao;

	@Column(name = "TX_OBSERVACAO", length = 250, nullable = false)
	private String observacao;

	@Column(name = "DT_EXCLUSAO")
	private LocalDateTime dataDeExclusao;

	@Column(name = "TX_NOME_USUARIO_EXCLUSAO")
	private String nomeUsuarioExclusao;

}
