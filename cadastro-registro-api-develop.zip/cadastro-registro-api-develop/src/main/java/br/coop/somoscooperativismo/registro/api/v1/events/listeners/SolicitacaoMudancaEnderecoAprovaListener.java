package br.coop.somoscooperativismo.registro.api.v1.events.listeners;

import java.util.Objects;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.events.events.SolicitacaoMudancaEnderecoEvent;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;

@Component
public class SolicitacaoMudancaEnderecoAprovaListener implements ApplicationListener<SolicitacaoMudancaEnderecoEvent> {

	private EmailService emailService;
	
	public SolicitacaoMudancaEnderecoAprovaListener(EmailService emailService) {
		this.emailService = emailService;
	}
	
	@Override
	public void onApplicationEvent(SolicitacaoMudancaEnderecoEvent event) {
		SolicitacaoMudancaEndereco solicitacaoMudancaEndereco = event.getSolicitacaoMudancaEndereco();
		try {
			if(Boolean.TRUE.equals(solicitacaoMudancaEndereco.getAprovado()) && 
					Objects.nonNull(solicitacaoMudancaEndereco.getLoginUsuarioParecer()) &&
					Objects.nonNull(solicitacaoMudancaEndereco.getDataParecer())) {
				
				// Notificar por e-mail Cooperativa e UF de origem
				emailService.enviaEmailSolicitacaoMudancaEndereco(solicitacaoMudancaEndereco.getPessoa().getId(),solicitacaoMudancaEndereco.getUfOrigem(), DisparoEmailEnum.APROVACAO_TRANSFERENCIA_UF,solicitacaoMudancaEndereco.getUfDestino());
			}
		} catch (Exception e) {
			throw new RegraNegocioException(e.getMessage(),e);
		}

		solicitacaoMudancaEndereco = null;
		
	}

}
