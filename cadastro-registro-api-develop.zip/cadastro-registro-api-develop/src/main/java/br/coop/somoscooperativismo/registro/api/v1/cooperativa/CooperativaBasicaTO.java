package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;

import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import lombok.AllArgsConstructor;
import lombok.Builder;

@Builder
@AllArgsConstructor
public class CooperativaBasicaTO {
    private Integer id;
    private String cnpj;
    private String razaoSocial;
    private String nomeFantasia;
    private String ufSigla;
    private Integer idRamo;
    private String nomeRamo;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataRegistro;
    private String numeroRegistro;
    private Situacao situacao;
    private String regularidade;
    private Integer idCategoria;
    private String categoria;
    private Integer idMunicipio;
    private String municipio;

    public CooperativaBasicaTO() {
    }

    public CooperativaBasicaTO(Integer id, String cnpj, String razaoSocial, String nomeFantasia, String ufSigla,
                               Integer idRamo, String nomeRamo) {
        super();
        this.id = id;
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.nomeFantasia = nomeFantasia;
        this.ufSigla = ufSigla;
        this.idRamo = idRamo;
        this.nomeRamo = nomeRamo;
    }

    public CooperativaBasicaTO(Integer id, String cnpj, String razaoSocial, String nomeFantasia, String ufSigla,
                               Integer idRamo, String nomeRamo, Date dataRegistro) {
        super();
        this.id = id;
        this.cnpj = cnpj;
        this.razaoSocial = razaoSocial;
        this.nomeFantasia = nomeFantasia;
        this.ufSigla = ufSigla;
        this.idRamo = idRamo;
        this.nomeRamo = nomeRamo;
        this.dataRegistro = dataRegistro;
    }


    public String getNomeCooperativa() {
        String nome = nomeFantasia != null ? nomeFantasia : razaoSocial;
        return "%s - %s - %s".formatted(cnpj, ufSigla, nome);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getUfSigla() {
        return ufSigla;
    }

    public void setUfSigla(String ufSigla) {
        this.ufSigla = ufSigla;
    }

    public Integer getIdRamo() {
        return idRamo;
    }

    public void setIdRamo(Integer idRamo) {
        this.idRamo = idRamo;
    }

    public String getNomeRamo() {
        return nomeRamo;
    }

    public void setNomeRamo(String nomeRamo) {
        this.nomeRamo = nomeRamo;
    }

    public Date getDataRegistro() {
        return dataRegistro;
    }

    public void setDataRegistro(Date dataRegistro) {
        this.dataRegistro = dataRegistro;
    }

    public String getNumeroRegistro() {
        return numeroRegistro;
    }

    public void setNumeroRegistro(String numeroRegistro) {
        this.numeroRegistro = numeroRegistro;
    }

    public Situacao getSituacao() {
        return situacao;
    }

    public void setSituacao(Situacao situacao) {
        this.situacao = situacao;
    }

    public String getRegularidade() {
        return regularidade;
    }

    public void setRegularidade(String regularidade) {
        this.regularidade = regularidade;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public Integer getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(Integer idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }
}
