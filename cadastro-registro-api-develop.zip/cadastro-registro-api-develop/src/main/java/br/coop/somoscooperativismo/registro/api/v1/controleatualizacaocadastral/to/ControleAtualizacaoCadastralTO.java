package br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.to;

import lombok.Data;

@Data
public class ControleAtualizacaoCadastralTO {
    private Integer id;
    private Boolean mostrarPopup = false;
    private Boolean destacarAtualizacaoCadastral = false;
    private String textoPopup = "";
    private Boolean permiteCooperativaPreencher = false;
    private Boolean permiteCooperativaVisualizar = false;
    private Boolean permiteEstadualPreencher = false;
    private Boolean visualizarPeriodoAtualizacao = false;
    private String uf;
}
