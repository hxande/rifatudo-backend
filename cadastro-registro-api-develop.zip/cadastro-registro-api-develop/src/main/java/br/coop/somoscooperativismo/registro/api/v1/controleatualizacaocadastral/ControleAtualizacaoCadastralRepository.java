package br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.entidade.ControleAtualizacaoCadastral;

public interface ControleAtualizacaoCadastralRepository extends JpaRepository<ControleAtualizacaoCadastral, Integer> {

	@Query(value = "select cac from ControleAtualizacaoCadastral cac where cac.uf = :uf or (cac.uf is null and :uf is null)")
	ControleAtualizacaoCadastral findByUf(String uf);

	@Query(value = "select cac from ControleAtualizacaoCadastral cac where cac.uf = :uf or cac.uf is null ")
	List<ControleAtualizacaoCadastral> findAllByUf(String uf);

}
