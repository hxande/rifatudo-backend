package br.coop.somoscooperativismo.registro.api.v1.certificadoregularidadeunidadeestadual.entidade;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.hibernate.envers.Audited;
/**
 * 
 * @author leo.stefanini
 *
 */
@Entity
@Table(name = "CERTIFICADO_REGULARIDADE_UNIDADE_ESTADUAL")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class CertificadoRegularidadeUnidadeEstadual {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_CERTIFICADO_REGULARIDADE_UNIDADE_ESTADUAL")
	private Integer id;
	
	@Column(name = "ARQUIVO")
	private String arquivo;
	
	@Column(name = "SQ_UF")
	private String uf;

	@Column(name = "IN_ATIVA")
	private Boolean inAtiva;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getArquivo() {
		return arquivo;
	}

	public void setArquivo(String arquivo) {
		this.arquivo = arquivo;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public Boolean getInAtiva() {
		return inAtiva;
	}

	public void setInAtiva(Boolean inAtiva){
		this.inAtiva = inAtiva;
	}

	@Override
	public String toString() {
		return "CertificadoRegularidadeUnidadeEstadual [id=" + id + ", arquivo=" + arquivo + ", uf=" + uf + "]";
	}
	
	
}
