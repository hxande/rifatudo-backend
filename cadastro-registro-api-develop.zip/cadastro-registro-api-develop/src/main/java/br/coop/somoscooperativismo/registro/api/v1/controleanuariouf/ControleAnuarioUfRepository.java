package br.coop.somoscooperativismo.registro.api.v1.controleanuariouf;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.coop.somoscooperativismo.registro.api.v1.controleanuariouf.entidade.ControleAnuarioUf;

public interface ControleAnuarioUfRepository extends JpaRepository<ControleAnuarioUf, Integer>{

    Optional<ControleAnuarioUf> findControleAnuarioUfByChaveAnuarioAndUf(String chaveAnuario, String uf);

	ControleAnuarioUf findByUfIsNull();

	@Query(value = "select cau from ControleAnuarioUf cau where cau.uf = :uf or cau.uf is null ")
	List<ControleAnuarioUf> findAllByUf(String uf);

	@Query(value = "select cau from ControleAnuarioUf cau where cau.uf = :uf or (cau.uf is null and :uf is null)")
	ControleAnuarioUf findByUf(String uf);

}