package br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigInteger;
import java.util.Date;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.cooperativafaturamento.entidade.Faturamento;
import br.coop.somoscooperativismo.registro.api.v1.mandato.entidade.Mandato;
import br.coop.somoscooperativismo.registro.api.v1.pessoacnae.entidade.PessoaCnae;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.entidade.PessoaSegmProdServ;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "VW_COOPERATIVAS_MATRIZES_REGISTRADAS")
public class VwCooperativaMatrizRegistrada {

    @Id
    @Column(name = "SQ_PESSOA")
    private Integer id;

    @Column(name = "TX_CNPJ")
    private String cnpj;

    @Column(name = "TX_RAZAO_SOCIAL")
    private String razaoSocial;

    @Column(name = "TX_NOME_FANTASIA")
    private String nomeFantasia;

    @Column(name = "TX_EMAIL_GERAL")
    private String emailGeral;

    @Column(name = "TX_TELEFONE_GERAL")
    private String telefoneGeral;

    @Column(name = "TX_NIRE")
    private String nire;

    @Column(name = "TX_NUMERO_REGISTRO_OCB")
    private String numeroRegistroOCB;

    @Column(name = "DT_REGISTRO_OCB")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataRegistro;

    @Temporal(TemporalType.DATE)
    @Column(name = "DT_ATUALIZACAO")
    private Date dataAtualizacao;

    @Column(name = "IN_REGIDA_POR_LEI")
    private Boolean regidaPorLei;

    @Column(name = "IN_ATUALIZACAO_NAO_VISUALIZADA")
    private Boolean atualizacaoNaoVisualizada;

    @Column(name = "IN_SOLICITACAO_ATIVACAO")
    private Boolean solicitacaoAtivacao;

    @Column(name = "IN_SOLICITACAO_INATIVACAO")
    private Boolean solicitacaoInativacao;

    @Column(name = "IN_SOLICITACAO_CANCELADA")
    private Boolean solicitacaoCancelamento;

    @Column(name = "IN_PROGRESSO_MANUTENCAO_MACRO")
    @Enumerated(EnumType.STRING)
    private ProgressoMacroEnum progressoManutencaoMacro;

    @Column(name = "IN_PROGRESSO_MANUTENCAO_MICRO")
    @Enumerated(EnumType.STRING)
    private ProgressoMicroEnum progressoManutencaoMicro;

    @Column(name = "SQ_RAMO", columnDefinition = "tinyint(4)")
    private Integer ramoId;

    @Column(name = "TX_RAMO")
    private String nomeRamo;

    @Column(name = "SQ_CATEGORIA_COOPERATIVA", columnDefinition = "tinyint(4)")
    private Integer categoriaCooperativaId;

    @Column(name = "TX_CATEGORIA_COOPERATIVA")
    private String descricaoCategoriaCooperativa;

    @Column(name = "SQ_SITUACAO_COOPERATIVA", columnDefinition = "tinyint(4)")
    private Integer situacaoCooperativaId;

    @Column(name = "TX_NOVA_SITUACAO_COOPERATIVA")
    private String nomeSituacaoCooperativa;

    @Column(name = "TX_CEP")
    private String cep;

    @Column(name = "TX_REGIAO_PAIS")
    private String regiao;

    @Column(name = "TX_ESTADO")
    private String estado;

    @Column(name = "TX_SIGLA_ESTADO")
    private String siglaEstado;

    @Column(name = "TX_NOME_REGIAO_UNIDADE_ESTADUAL")
    private String nomeRegiaoUnidadeEstadual;

    @Column(name = "TX_NOME_MUNICIPIO")
    private String nomeMunicipio;

    @Column(name = "CD_MUNICIPIO_IBGE")
    private Integer codigoMunicipioIbge;

    @Column(name = "DT_ALTERACAO_SITUACAO_STATUS")
    private Date dataAlteracao;

    @Column(name = "STATUS_ATUALIZACAO_ANUAL")
    private String statusAtualizacaoAnual;

    @Column(name = "IN_PROCESSO_TRANSFERENCIA")
    private Boolean processoTransferencia;

    @Column(name = "IN_ARQUIVADO")
    private Boolean arquivado;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_PESSOA")
    private Set<Contato> contatos;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_PESSOA")
    private Set<PessoaSegmProdServ> segmentosProdutosServs;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_COOPERATIVA")
    private Set<Faturamento> faturamentos;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_PESSOA")
    private Set<PessoaCnae> pessoaCnaes;

    @OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_COOPERATIVA")
    private Set<Mandato> mandatos;
}
