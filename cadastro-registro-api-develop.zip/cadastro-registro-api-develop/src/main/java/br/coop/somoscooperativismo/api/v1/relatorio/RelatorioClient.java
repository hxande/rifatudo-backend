package br.coop.somoscooperativismo.api.v1.relatorio;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioExpressTO;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioTO;
import br.coop.somoscooperativismo.ocbcommonsapi.util.TokenSecurity;


@Service
public class RelatorioClient {

	@Value("${relatorio_service_host:null}")
	private String relatorioServiceHost;

	private final RestTemplate restTemplate;
		
	public RelatorioClient(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public byte[] gerarRelatorio(RelatorioExpressTO relatorio) {
		String urlFinal = "%s/public/api/v1/planilha/gerarPlanilhaExpress/%s".formatted(relatorioServiceHost, TokenSecurity.gerarToken());
		return restTemplate.postForObject(urlFinal, relatorio, byte[].class);
	}

	public byte[] gerarRelatorio(RelatorioTO relatorio) {
		String urlFinal = "%s/public/api/v1/planilha/gerarPlanilha/%s".formatted(relatorioServiceHost, TokenSecurity.gerarToken());
		return restTemplate.postForObject(urlFinal, relatorio, byte[].class);
	}
	
	public byte[] gerarRelatorioTxt(List<String> dados) {
		String urlFinal = "%s/public/api/v1/txt/gerarRelatorio/%s".formatted(relatorioServiceHost, TokenSecurity.gerarToken());
		return restTemplate.postForObject(urlFinal, dados, byte[].class);
	} 
} 
