package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/arrecadacao")
@Tag(name = "Arrecadacao")
public class ArrecadacaoRestController {


    @Autowired
    private ArrecadacaoService arrecadacaoService;


    /**
     * Retorna lista adesao.
     *
     * @return AdesaoUnidadeEstadualTO.
     */
    @GetMapping("/adesao")
    @Operation(summary = "Lista de Adesao de Unidade Estadual")
    public ResponseEntity<ServiceResponse<Set<AdesaoUnidadeEstadualTO>>> getAllAdesao() {
        return new ResponseEntity<>(new ServiceResponse<>(arrecadacaoService.getAllAdesao()), HttpStatus.OK);
    }

    /**
     * Retorna o número de pendências na contribuição.
     *
     * @return Número de pendências.
     */
    @GetMapping("/numeroDePendencias")
    @Operation(summary = "Retorna o número de pendências na contribuição dos perfils UE e UN")
    public ResponseEntity<Integer> numeroDePendencias() {
        return new ResponseEntity<>(arrecadacaoService.getNumeroPendencia(), HttpStatus.OK);
    }

    /**
     * Retorna o QuadroSituacaoFinanceiraTO para preencher os dados do quadro
     * situaação financeira em cadastro-registro-front.
     * Qualquer alteração pode implicar quebra de integração
     *
     * @param tipoContribuicao, idCooperativa
     * @return QuadroSituacaoFinanceiraTO.
     */
    @GetMapping("getSituacaoFinanceira/{tipoContribuicao}")
    @Operation(summary = "Obter situação financeira da cooperativa")
    public ResponseEntity<List<QuadroSituacaoFinanceiraTO>> getSituacaoFinanceira(@PathVariable Integer tipoContribuicao, @RequestParam Integer idCooperativa) {
        return new ResponseEntity<>(arrecadacaoService.getListaArrecadacao(idCooperativa, tipoContribuicao), HttpStatus.OK);
    }

    /**
     * Retorna informações da Taxa de Registro da cooperativa.
     *
     * @param idCooperativa
     * @return TaxaRegistroTO.
     */
    @GetMapping("/taxa-registro/cooperativa/{idCooperativa}")
    @Operation(summary = "Obter informações da Taxa de Registro da cooperativa via integração com Arrecadação")
    public ResponseEntity<ServiceResponse<TaxaRegistroTO>> getTaxaRegistro(@PathVariable Integer idCooperativa) {
        return new ResponseEntity<>(new ServiceResponse<>(arrecadacaoService.getTaxaRegistro(idCooperativa)), HttpStatus.OK);
    }

}
