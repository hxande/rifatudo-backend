package br.coop.somoscooperativismo.registro.api.v1.auditoria.entidade;


import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Data;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;


@Data
@Entity
@Table(name = "REVISAO_AUDITORIA")
@RevisionEntity(RevisaoAuditoriaListener.class)
public class RevisaoAuditoria {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SQ_REVISAO")
	@RevisionNumber
	private Long id;

	@Column(name="DT_REVISAO")
	@Temporal(TemporalType.TIMESTAMP)
	@RevisionTimestamp
	private Date dataOperacao;

	@Column(name="NO_USUARIO")
	private String loginUsuario;
}
