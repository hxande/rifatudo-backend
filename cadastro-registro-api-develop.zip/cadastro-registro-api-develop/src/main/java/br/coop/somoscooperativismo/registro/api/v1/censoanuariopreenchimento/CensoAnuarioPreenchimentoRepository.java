package br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento;

import br.coop.somoscooperativismo.registro.api.v1.censoanuariopreenchimento.entidade.CensoAnuarioPreenchimento;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CensoAnuarioPreenchimentoRepository extends JpaRepository<CensoAnuarioPreenchimento, Integer> {

	Optional<CensoAnuarioPreenchimento> findByAnoAndIdCooperativa(Integer ano, Integer idCooperativa);

}
