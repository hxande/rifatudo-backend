package br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.entidade.CooperativaAnuarioAbas;

public interface CooperativaAnuarioAbasRepository extends JpaRepository<CooperativaAnuarioAbas, Integer> {

	List<CooperativaAnuarioAbas> findAllByIdCooperativaAndAnoCiclo(Integer idCooperativa, Integer ano);
	Optional<CooperativaAnuarioAbas> findByIdCooperativaAndAnoCicloAndAbaNome(Integer idCooperativa, Integer anoCiclo, String abaNome);

}
