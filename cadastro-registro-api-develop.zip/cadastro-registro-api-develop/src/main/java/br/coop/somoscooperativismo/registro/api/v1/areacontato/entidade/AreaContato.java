package br.coop.somoscooperativismo.registro.api.v1.areacontato.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import org.hibernate.envers.Audited;

import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "AREA_CONTATO") 
@Getter
@Setter
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
public class AreaContato {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="SQ_AREA_CONTATO")
	private Integer id;

	@Column(name="TX_AREA_CONTATO", nullable=false)
	@NotBlank(message = "O nome da are de contato nao pode ser em branco")
	@Size(max = 255)
	private String nome;

	@Column(name="IN_REGISTRO_ATIVO", nullable=false)
	@NotNull(message = "area de contato ativa deve ser informado")
	private boolean ativo;

	@Column(name="IN_REGISTRO_EXCLUIDO", nullable=false)
	@NotNull(message = "Area de contato excluido deve ser informado")
	private Boolean excluido;

	@Column(name = "NR_POSICAO_CONTATO_TELA", columnDefinition = "tinyint(4)")
	private Integer posicaoTela;

	@Column(name = "IN_UTILIZA_CARGO", nullable = false)
	private Boolean utilizaCargo;

	@Column(name = "IN_REGISTRO_OBRIGATORIO", nullable = false)
	private Boolean obrigatorio;

	@Column(name = "SQ_UF")
	private String uf;
	
	@PreUpdate @PrePersist
	private void updatePosicaoTela() {		
		this.posicaoTela = Boolean.FALSE.equals(this.ativo) ? null : this.posicaoTela;		
	}
}
