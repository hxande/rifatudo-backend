package br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacao;
import org.hibernate.annotations.Formula;
import org.hibernate.envers.Audited;
import org.hibernate.envers.NotAudited;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.auditoria.RevisaoAuditoriaListener;
import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaBasicaTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.entidade.CooperativaVinculacao;
import br.coop.somoscooperativismo.registro.api.v1.entidade.VwPessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;
import br.coop.somoscooperativismo.registro.api.v1.parecer.entidade.Parecer;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridicafiliacao.entidade.PessoaJuridicaFiliacao;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.entidade.QuadroSocial;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocialFilial.entidade.QuadroSocialFilial;
import br.coop.somoscooperativismo.registro.api.v1.sindicato.entidade.Sindicato;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.SituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import br.coop.somoscooperativismo.registro.api.v1.state.PreCadastroState;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroState;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistro;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "COOPERATIVA")
@Audited
@EntityListeners(RevisaoAuditoriaListener.class)
@Getter
@Setter
public class Cooperativa implements Serializable {

    private static final long serialVersionUID = 1L;

    public Cooperativa() {
        super();
        Situacao s = new Situacao();
        s.setId(SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo());
        this.situacaoCooperativa = s;
    }

    public Cooperativa(Integer idPessoaJuridica) {
        this.id = idPessoaJuridica;
        this.situacaoCooperativa = new Situacao();
        this.situacaoCooperativa.setId(SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo());
    }

    @Id
    @Column(name = "SQ_COOPERATIVA")
    private Integer id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "SQ_COOPERATIVA", referencedColumnName = "SQ_PESSOA", insertable = false, updatable = false)
    private PessoaJuridica pessoaJuridica;

    @ManyToOne
    @JoinColumn(name = "SQ_CATEGORIA_COOPERATIVA")
    private Categoria categoria;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "SQ_SINDICATO")
    private Sindicato sindicato;

    public Integer getIdSindicato() {
        return sindicato != null ? sindicato.getId() : null;
    }

    @OneToOne(mappedBy = "cooperativa")
    @JsonManagedReference
    private Parecer parecer;

    @Column(name = "DT_REGISTRO_OCB")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataRegistro;

    @Column(name = "TX_NUMERO_REGISTRO_OCB")
    @Size(max = 20)
    private String numeroRegistroOCB;

    @Column(name = "TX_PROCESSO")
    @Size(max = 20)
    private String processo;

    @Column(name = "IN_PROGRESSO_MICRO")
    @Enumerated(EnumType.STRING)
    private ProgressoMicroEnum progressoMicro;

    @Column(name = "IN_PROGRESSO_MACRO")
    @Enumerated(EnumType.STRING)
    private ProgressoMacroEnum progressoMacro;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "SQ_SITUACAO_COOPERATIVA")
    private Situacao situacaoCooperativa;

    @OneToMany(mappedBy = "cooperativaPai", fetch = FetchType.LAZY)
    @JsonBackReference(value = "cooperativa-vinculacao")
    private List<CooperativaVinculacao> cooperativaVinculacao;

    @OneToMany(mappedBy = "cooperativaMatriz", fetch = FetchType.LAZY)
    @JsonBackReference(value = "cooperativa-filiacao")
    private List<PessoaJuridicaFiliacao> cooperativaFiliacao;

    @Column(name = "DT_ABERTURA_PROCESSO_REGISTRO")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataAberturaProcesso;

    @Temporal(TemporalType.DATE)
    @Column(name = "DT_ATUALIZACAO")
    private Date dataAtualizacao;

    @Column(name = "IN_PROGRESSO_MANUTENCAO_MICRO")
    @Enumerated(EnumType.STRING)
    private ProgressoMicroEnum progressoManutencaoMicro;

    @Column(name = "IN_PROGRESSO_MANUTENCAO_MACRO")
    @Enumerated(EnumType.STRING)
    private ProgressoMacroEnum progressoManutencaoMacro;

    @Column(name = "IN_ARQUIVADO")
    private Boolean arquivado;

    @Column(name = "IN_SOLICITACAO_INATIVACAO")
    private Boolean solicitacaoInativacao;

    @Column(name = "IN_SOLICITACAO_ATIVACAO")
    private Boolean solicitacaoAtivacao;

    @Column(name = "TX_JUSTIFICATIVA_SOLICITACAO_INATIVACAO")
    private String justificativaSolicitacaoInativacao;

    @Column(name = "TX_JUSTIFICATIVA_COOPERATIVA_CANCELADA")
    private String justificativaCancelada;

    @Column(name = "TX_JUSTIFICATIVA_COOPERATIVA_INATIVADA")
    private String justificativaInativada;

    @Column(name = "TX_JUSTIFICATIVA_COOPERATIVA_IRREGULAR")
    private String justificativaIrregular;

    @Column(name = "TX_JUSTIFICATIVA_SOLICITACAO_ATIVACAO")
    private String justificativaSolicitacaoAtivacao;

    @Column(name = "TX_JUSTIFICATIVA_ATIVACAO")
    private String justificativaAtivacao;

    @Column(name = "IN_PROCESSO_TRANSFERENCIA")
    private Boolean processoTransferencia;

    @Column(name = "SQ_NUMERO_REGISTRO_OCB")
    private Integer sqNumeroRegistroOCB;

    @Column(name = "IN_ATUALIZACAO_NAO_VISUALIZADA")
    private Boolean atualizacaoNaoVisualizada;

    @Column(name = "IN_CADASTRO_SEM_USUARIO")
    private Boolean cadastroSemUsuario = false;

    @Column(name = "IN_NAO_SUBMETEU")
    private Boolean naoSubmeteu;

    @Column(name = "DT_ULTIMA_ANALISE_UE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataUltimaAnaliseUE;

    @Column(name = "IN_REGIDA_POR_LEI")
    private Boolean regidaPorLei;

    @Column(name = "IN_SOLICITACAO_CANCELADA")
    private Boolean solicitacaoCancelamento;

    @Column(name = "TX_JUSTIFICATIVA_SOLICITACAO_CANCELADA")
    private String justificativaSolicitacaoCancelamento;

    @Column(name = "IN_LIQUIDACAO")
    private Boolean liquidacao;


    @Column(name = "TX_USUARIO_SUBMISSAO")
    private String usuarioSubmissao;

    @Column(name = "IN_PREENCHIMENTO", columnDefinition = "bit")
    private boolean inPreenchimento;

    @Column(name = "TIPO_ACAO_SUSPENSAO", length = 100)
    private String tipoAcaoSuspensao;

    @NotAudited
    @ManyToOne
    @JoinColumn(name = "SQ_COOPERATIVA", insertable = false, updatable = false)
    private VwPessoaJuridica vwPessoaJuridica;

    @Transient
    private SolicitacaoMudancaEndereco solicitacaoMudancaEndereco;

    @Transient
    private Set<Cooperativa> cooperativasColigadas;

    @OneToMany(mappedBy = "cooperativa", fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<CooperativaRegistro> cooperativaRegistro;

    @NotAudited
    @Formula(value = "DATEADD(\"DAY\", 60, DT_ULTIMA_ANALISE_UE)")
    private LocalDate dataPrazoRegistro;

    @NotAudited
    @Formula(value = "DBO.FN_COOPERATIVA_ATUALIZACAO_CADASTRO_POR_COOPERATIVA(SQ_COOPERATIVA)")
    private String status;

    @Transient
    private String usuarioAuditoria;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "cooperativa", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<QuadroSocial> quadrosSociais;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "cooperativa", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<NegocioExportacao> negocioExportacao;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "cooperativa", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<QuadroSocialFilial> quadrosSociaisFilial;

    @OneToMany(mappedBy = "cooperativa", fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<CooperativaHistoricoProcessoRegistro> cooperativaHistoricoProcessoRegistro;

    @Transient
    private ProgressoCadastroState progressoCadastroState = new PreCadastroState();

    public void trocarEstado() {
        progressoCadastroState.trocarEstado(this);
    }

    public String getNomeCooperativa() {
        String cnpj = this.pessoaJuridica != null ? this.pessoaJuridica.getCnpj() : "";
        String nome = "";
        if (this.pessoaJuridica != null) {
            nome = this.pessoaJuridica.getNomeFantasia() != null ? this.pessoaJuridica.getNomeFantasia()
                    : this.pessoaJuridica.getRazaoSocial();
        }

        String uf = pessoaJuridica != null ? pessoaJuridica.getUfSigla() : null;
        return "%s - %s - %s".formatted(cnpj, uf, nome);
    }

    public String getProgressoMacroTexto() {
        return progressoMacro != null ? progressoMacro.getNome() : null;
    }

    public String getProgressoMicroTexto() {
        return progressoMicro != null ? progressoMicro.getNome() : null;
    }

    public String getProgressoManutencaoMacroTexto() {
        return progressoManutencaoMacro != null ? progressoManutencaoMacro.getNome() : null;
    }

    public String gerarCodigoAutenticidade(Date dataGeracaoCertificado) {
        return this.pessoaJuridica.getCnpj().concat(".")
                .concat(new SimpleDateFormat("yyyyMMddHHmmss").format(dataGeracaoCertificado)).concat(".")
                .concat(ValidacaoCampos.preencherCaracteresEsquerda(this.getId().toString(), '0', 10));
    }

    @Transient
    public LocalDate getPrazoRegistro() {
        if (this.dataUltimaAnaliseUE != null) {
            LocalDate prazo = this.dataUltimaAnaliseUE.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            return prazo.plusDays(60);
        } else {
            return null;
        }
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @Transient
    public Set<Cooperativa> getCooperativasColigadas() {
        return cooperativasColigadas;
    }

    public void setCooperativasColigadas(Set<Cooperativa> list) {
        this.cooperativasColigadas = list;
    }

    public Boolean getCadastroSemUsuario() {
        if (cadastroSemUsuario == null) {
            cadastroSemUsuario = Boolean.FALSE;
        }
        return cadastroSemUsuario;
    }

    public void setCadastroSemUsuario(Boolean cadastroSemUsuario) {
        this.cadastroSemUsuario = cadastroSemUsuario;
    }

    @Override
    public String toString() {
        return "Cooperativa [id=" + id + ", pessoaJuridica=" + pessoaJuridica + ", categoria=" + categoria
                + ", parecer=" + parecer + ", dataRegistro=" + dataRegistro + ", numeroRegistroOCB=" + numeroRegistroOCB
                + ", processo=" + processo + ", progressoMicro=" + progressoMicro + ", progressoMacro=" + progressoMacro
                + ", situacaoCooperativa="
                + situacaoCooperativa + ", cooperativaVinculacao=" + cooperativaVinculacao + ", cooperativaFiliacao="
                + cooperativaFiliacao + ", dataAberturaProcesso=" + dataAberturaProcesso + ", dataAtualizacao="
                + dataAtualizacao + ", progressoManutencaoMicro=" + progressoManutencaoMicro
                + ", progressoManutencaoMacro=" + progressoManutencaoMacro + ", arquivado=" + arquivado
                + ", solicitacaoInativacao=" + solicitacaoInativacao + ", solicitacaoAtivacao=" + solicitacaoAtivacao
                + ", justificativaSolicitacaoInativacao=" + justificativaSolicitacaoInativacao
                + ", justificativaCancelada=" + justificativaCancelada + ", justificativaInativada="
                + justificativaInativada + ", justificativaIrregular=" + justificativaIrregular
                + ", justificativaSolicitacaoAtivacao=" + justificativaSolicitacaoAtivacao + ", justificativaAtivacao="
                + justificativaAtivacao + ", processoTransferencia=" + processoTransferencia + ", sqNumeroRegistroOCB="
                + sqNumeroRegistroOCB + ", atualizacaoNaoVisualizada=" + atualizacaoNaoVisualizada
                + ", cadastroSemUsuario=" + cadastroSemUsuario + ", naoSubmeteu=" + naoSubmeteu
                + ", dataUltimaAnaliseUE=" + dataUltimaAnaliseUE + ", regidaPorLei=" + regidaPorLei
                + ", solicitacaoCancelamento=" + solicitacaoCancelamento + ", justificativaSolicitacaoCancelamento="
                + justificativaSolicitacaoCancelamento + ", solicitacaoMudancaEndereco=" + solicitacaoMudancaEndereco
                + ", cooperativasColigadas=" + cooperativasColigadas + ", cooperativaRegistro=" + cooperativaRegistro
                + ", usuarioAuditoria=" + usuarioAuditoria + "]";
    }

    public void add(QuadroSocial quadroSocial) {
        if (this.quadrosSociais == null)
            this.quadrosSociais = new ArrayList<>();
        this.quadrosSociais.add(quadroSocial);
    }

    public CooperativaBasicaTO cooperativaToCooperativaBasicaTO() {
        return CooperativaBasicaTO.builder()
                .id(this.getId())
                .cnpj(this.getPessoaJuridica().getCnpj())
                .razaoSocial(this.getPessoaJuridica().getRazaoSocial())
                .nomeFantasia(this.getPessoaJuridica().getNomeFantasia())
                .ufSigla(this.getPessoaJuridica().getUfSigla())
                .idRamo(this.getPessoaJuridica().getRamo().getId())
                .nomeRamo(this.getPessoaJuridica().getRamo().getNome())
                .dataRegistro(this.getDataRegistro())
                .numeroRegistro(this.getNumeroRegistroOCB())
                .situacao(this.getSituacaoCooperativa())
                .regularidade(this.getStatus())
                .idCategoria(this.getCategoria().getId())
                //.idMunicipio(cooperativa.getPessoaJuridica())
                //.municipio(cooperativa.getPessoaJuridica().))
                .build();
    }

}
