package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.FieldTO;
import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class RequestAnuarioFieldsTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private String name;
    private Integer idQuadro;
    private List<List<FieldTO>> fields;

}

