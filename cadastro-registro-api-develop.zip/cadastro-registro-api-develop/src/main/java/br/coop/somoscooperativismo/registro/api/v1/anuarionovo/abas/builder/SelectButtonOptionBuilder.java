package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SelectButtonOptionBuilder {
    private String label;
    private String value;
}
