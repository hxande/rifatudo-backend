package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import jakarta.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CensoAnuarioTO {

    private Integer id;

    @NotNull(message = "Deve ser informado o ano referente ao censo do anuário")
    private Integer ano;

    @NotNull(message = "Deve ser informada a cooperativa")
    private Integer cooperativaId;

}
