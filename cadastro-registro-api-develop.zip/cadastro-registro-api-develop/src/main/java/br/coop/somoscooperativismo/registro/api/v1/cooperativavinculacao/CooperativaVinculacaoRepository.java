package br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao;

import br.coop.somoscooperativismo.registro.api.v1.cooperativavinculacao.entidade.CooperativaVinculacao;
import java.util.HashSet;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CooperativaVinculacaoRepository extends JpaRepository<CooperativaVinculacao, Integer> {

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM COOPERATIVA_VINCULACAO WHERE SQ_COOPERATIVA_PAI = :id_cooperativa_pai ", nativeQuery = true)
	void excluiTodosIdPai(@Param("id_cooperativa_pai") Integer idCooperativaPai);
	
	HashSet<CooperativaVinculacao> findByCooperativaPaiId(@Param("id_cooperativa_pai") Integer idCooperativaPai);

    @Modifying
    @Transactional
    @Query(value = """
                DELETE FROM COOPERATIVA_VINCULACAO
                WHERE SQ_COOPERATIVA_VINCULADA = :idCooperativaFilha
                  AND SQ_COOPERATIVA_PAI = :idCooperativaPai
            """, nativeQuery = true)
    void removerCooperativaSuperiorVinculada(@Param("idCooperativaFilha") Integer idCooperativaFilha, @Param("idCooperativaPai") Integer idCooperativaPai);

}
