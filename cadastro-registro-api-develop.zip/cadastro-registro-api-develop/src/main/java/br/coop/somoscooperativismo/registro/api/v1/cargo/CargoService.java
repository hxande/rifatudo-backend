package br.coop.somoscooperativismo.registro.api.v1.cargo;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.cargo.entidade.Cargo;
import br.coop.somoscooperativismo.registro.api.v1.orgao.OrgaoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CargoService {
	public static final String NAO_ENCONTRADO = "cargo.naoEncontrado";
	public static final String ORGAO_NAO_ENCONTRADO = "orgao.naoEncontrado";

	@Autowired
	CargoRepository cargoRepository;

	@Autowired
	OrgaoRepository orgaoRepository;

	@Autowired
	private MessagesService messages;

	public List<Cargo> getCargos() {
		return cargoRepository.findAll(Sort.by(Sort.Direction.ASC, "nome"));
	}

	public Cargo getCargo(Integer id) {
		Optional<Cargo> cargo = cargoRepository.findById(id);
		if (cargo.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + id, HttpStatus.NOT_FOUND);
		}
		return cargo.get();
	}

	public @Valid Cargo createCargo(@Valid Cargo cargo) {
		
		return cargoRepository.save(cargo);
	}

	public @Valid Cargo updateCargo(@Valid Cargo cargo) {
		Optional<Cargo> op = cargoRepository.findById(cargo.getId());
		if (op.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + cargo.getId(), HttpStatus.NOT_FOUND);
		}

		op = null;

		return cargoRepository.save(cargo);
	}

	public void desativaCargo(Integer id, Boolean valor) {
		Optional<Cargo> op = cargoRepository.findById(id);
		if (op.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + id, HttpStatus.NOT_FOUND);
		}
		Cargo cargo = op.get();
		cargo.setAtivo(valor);
		cargoRepository.save(cargo);

		op = null;
	}

	public Page<Cargo> filtra(String nome, Boolean ativo, Pageable pageable) {
		return cargoRepository.filtra(nome, ativo, pageable);
	}
}
