package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.entidade.TipoEndereco;
import br.coop.somoscooperativismo.registro.api.v1.tipoendereco.TipoEnderecoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/tipos-enderecos")
public class TipoEnderecoImportacaoRestController {

    private final TipoEnderecoService tipoEnderecoService;

    @GetMapping("/ativos")
    public ResponseEntity<List<TipoEndereco>> getAtivos() {
        return ResponseEntity.ok(tipoEnderecoService.getAtivos());
    }
}
