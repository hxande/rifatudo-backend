package br.coop.somoscooperativismo.registro.api.v1.anuario;

import br.coop.somoscooperativismo.registro.api.v1.anuario.entidade.Anuario;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface AnuarioRepository extends CrudRepository<Anuario, Integer> {

	@Query("select an from Anuario an where an.cooperativa.id = :idCooperativa ")
	Anuario getByCooperativa(Integer idCooperativa);

	/**
	 * Retorna o Anuário da Cooperativa no ano informado.
	 * 
	 * @param idCooperativa ID da Cooperativa.
	 * @param ano           Ano.
	 * @return Anuário
	 */
	@Query("FROM Anuario an WHERE an.cooperativa.id = :idCooperativa AND an.ano = :ano")
	Anuario getByCooperativaAno(Integer idCooperativa, Integer ano);

	@Query("FROM Anuario an WHERE an.cooperativa.id = :idCooperativa ORDER BY an.ano DESC")
	List<Anuario> getListByCooperativa(Integer idCooperativa);
	
	@Query("FROM AnuarioTO anuario WHERE (:uf IS NULL OR anuario.ufSigla = :uf) "
			+ "AND (:ano IS NULL OR anuario.ano = :ano) ORDER BY anuario.nomeFantasia")
	public List<AnuarioTO> getListTO(String uf, Integer ano);
}
