package br.coop.somoscooperativismo.registro.api.v1.cadastroregistro;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.AprovacaoService;
import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import br.coop.somoscooperativismo.registro.api.v1.contato.ContatoService;
import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.AbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.CooperativaManutencaoAbasService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.CooperativaValidacaoLoteService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativavalidacaolote.entidade.CooperativaValidacaoLote;
import br.coop.somoscooperativismo.registro.api.v1.dadosgerais.DadosGeraisService;
import br.coop.somoscooperativismo.registro.api.v1.documentocliente.DocumentoClient;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EmailEventTO;
import br.coop.somoscooperativismo.registro.api.v1.email.event.EnvioEmailEventEnum;
import br.coop.somoscooperativismo.registro.api.v1.email.util.EmailServiceEvent;
import br.coop.somoscooperativismo.registro.api.v1.fileupload.FileUploadClient;
import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaService;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.AcaoProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroService;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.CooperativaHistoricoProcessoRegistroTO;
import br.coop.somoscooperativismo.registro.api.v1.historicoprocessoregistro.FaseProcessoRegistroEnum;
import br.coop.somoscooperativismo.registro.api.v1.negocio.NegocioService;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.ValidacaoPendenciaTO;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.entidade.CooperativaPendencia;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.SituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.state.ProgressoCadastroStateFactory;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import jakarta.validation.Valid;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.beans.Transient;
import java.time.Year;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Transactional
@Service
public class CadastroRegistroService {

	private static final Logger LOGGER = Logger.getLogger(CadastroRegistroService.class);
	
    private static final String DOCUMENTOS = "Documentos";
	private static final String UN_VIS = "UN_VIS";
	private static final String UE_VIS = "UE_VIS";
	private static final String TODAS_VALIDACOES = "Todas Validações";
	private static final String NAO_FOI_POSSIVEL_ENVIAR_O_FORMULARIO = "Não foi possível enviar o formulario porque você está na fase: %s.";
	private static final String ETAPA_INVALIDA = "Etapa inválida";
	private static final String CO_VIS = "CO_VIS";
	private static final int TRES = 3;
	private static final String CADASTRO_ABA_NAO_PREECHIDA = "cadastro.abaNaoPreenchida";
    private static final String CADASTRO_PENDENCIAS = "cadastro.pendencias";
    private static final String CADASTRO_AJUSTE_SOLICITADO_ABERTO = "cadastro.ajusteSolicitadoAberto";
    private static final String CADASTRO_DOCUMENTOS_COM_PENDENCIA = "cadastro.documentosComPendencia";

    private final DadosGeraisService dadosGeraisService;

    private final GovernancaService governancaService;

    private final NegocioService negocioService;

    private final ContatoService contatoService;

    private final DocumentoClient documentoCliente;

    private final FileUploadClient fileUploadClient;

    private final ApplicationEventPublisher applicationEventPublisher;

    private final CooperativaService cooperativaService;

    private final AprovacaoService aprovacaoService;

    private final CooperativaPendenciaService cooperativaPendenciaService;

    private final KeycloakService keycloakService;

    private final EmailService emailService;

    private final CooperativaValidacaoLoteService cooperativaValidacaoLoteService;

    private final MessagesService messages;

    private final CooperativaManutencaoAbasService cooperativaManutencaoAbasService;

    private final ProgressoCadastroStateFactory progressoCadastroStateFactory;

    private final CooperativaHistoricoProcessoRegistroService cooperativaHistoricoProcessoRegistroService;

    @SuppressWarnings("java:S107") // As dependências existentes permanecem explícitas e no mesmo serviço.
    public CadastroRegistroService(
            @Lazy DadosGeraisService dadosGeraisService,
            @Lazy GovernancaService governancaService,
            @Lazy NegocioService negocioService,
            ContatoService contatoService,
            DocumentoClient documentoCliente,
            @Qualifier("fileUploadClientLocal") FileUploadClient fileUploadClient,
            ApplicationEventPublisher applicationEventPublisher,
            @Lazy CooperativaService cooperativaService,
            AprovacaoService aprovacaoService,
            CooperativaPendenciaService cooperativaPendenciaService,
            KeycloakService keycloakService,
            EmailService emailService,
            CooperativaValidacaoLoteService cooperativaValidacaoLoteService,
            MessagesService messages,
            CooperativaManutencaoAbasService cooperativaManutencaoAbasService,
            ProgressoCadastroStateFactory progressoCadastroStateFactory,
            CooperativaHistoricoProcessoRegistroService cooperativaHistoricoProcessoRegistroService) {
        this.dadosGeraisService = Objects.requireNonNull(dadosGeraisService, "dadosGeraisService");
        this.governancaService = Objects.requireNonNull(governancaService, "governancaService");
        this.negocioService = Objects.requireNonNull(negocioService, "negocioService");
        this.contatoService = Objects.requireNonNull(contatoService, "contatoService");
        this.documentoCliente = Objects.requireNonNull(documentoCliente, "documentoCliente");
        this.fileUploadClient = Objects.requireNonNull(fileUploadClient, "fileUploadClient");
        this.applicationEventPublisher = Objects.requireNonNull(applicationEventPublisher, "applicationEventPublisher");
        this.cooperativaService = Objects.requireNonNull(cooperativaService, "cooperativaService");
        this.aprovacaoService = Objects.requireNonNull(aprovacaoService, "aprovacaoService");
        this.cooperativaPendenciaService = Objects.requireNonNull(cooperativaPendenciaService, "cooperativaPendenciaService");
        this.keycloakService = Objects.requireNonNull(keycloakService, "keycloakService");
        this.emailService = Objects.requireNonNull(emailService, "emailService");
        this.cooperativaValidacaoLoteService = Objects.requireNonNull(cooperativaValidacaoLoteService, "cooperativaValidacaoLoteService");
        this.messages = Objects.requireNonNull(messages, "messages");
        this.cooperativaManutencaoAbasService = Objects.requireNonNull(cooperativaManutencaoAbasService, "cooperativaManutencaoAbasService");
        this.progressoCadastroStateFactory = Objects.requireNonNull(progressoCadastroStateFactory, "progressoCadastroStateFactory");
        this.cooperativaHistoricoProcessoRegistroService = Objects.requireNonNull(cooperativaHistoricoProcessoRegistroService, "cooperativaHistoricoProcessoRegistroService");
    }

    @Transient
    public ResponseEntity<ServiceResponse<Boolean>> submeterCadastroValidacaoEmLote(List<Integer> idsCooperativa) {
        

        for(Integer idCooperativa : idsCooperativa){
            boolean retorno = this.submeterCadastroManutencao(idCooperativa, true);

            if(retorno){
                boolean primeiraVezSubmetido = aprovacaoService.criarAprovacaoAtualCooperativaEmLote(idCooperativa, retorno);

                Cooperativa c = obterCooperativa(idCooperativa);
                // Aprova todos os itens das abas exceto documentos da validação em lote
                aprovacaoService.aprovarDadosCoopLote( idCooperativa,  c);
                // Salva pendencia - aprova todos os campos que solicitam aprovação
                salvarPendenciasAproivacaoEmLote(c);

                // Para UN E UE se for a primeira subetido, aprova tudo e finaliza o processo
                if ((keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual())
                        && primeiraVezSubmetido) {
                    aprovacaoService.atualizaSeAindaNaoAtualizou(idCooperativa);
                    cooperativaService.finalizarProcessoManutencao(idCooperativa);
//                    aprovacaoService.aprovarTodosDadosCooperativaFluxoUEUN(idCooperativa);
                    
                }
            }

        }

        ServiceMessage message = new ServiceMessage("Validação realizada com sucesso!");
        return new ResponseEntity<>(new ServiceResponse<>(true, message), HttpStatus.OK);
    }


    public ValidacaoPrimeiroRegistroTO validarCadastroRegistroManutencao(Integer idCooperativa) {

        Cooperativa c = obterCooperativa(idCooperativa);

        if (!Boolean.FALSE.equals(podePreencherCadastroRegistroManutencao(idCooperativa)) &&
                (Objects.isNull(c.getProgressoManutencaoMacro()) || ProgressoMacroEnum.MANUTENCAO_10 == c.getProgressoManutencaoMacro())) {

            ValidacaoPrimeiroRegistroTO vDadosGerais = dadosGeraisService.validarDadosGeraisManutencao(idCooperativa, true);
            if (verificaDadosGerais(vDadosGerais)) {
                return vDadosGerais;
            }

             ValidacaoPrimeiroRegistroTO vDocumento = documentoCliente.validarDocumentosManutencao(idCooperativa);
            if (verificaDOcumento(vDocumento)) {
                return vDocumento;
            }

            ValidacaoPrimeiroRegistroTO vNegocio = negocioService.validarNegocioManutencao(idCooperativa, true);
            if (verificaNegocio(vNegocio)) {
                return vNegocio;
            }

            // Verificar se há pendências de preenchimento ( VALIDAÇÃO ) em documentos
            boolean validado = true;
            if (Boolean.FALSE.equals(cooperativaPendenciaService.verificarPendenciasValidadasManutencao(idCooperativa, "MANUTENCAO_DOCUMENTOS"))) {
                validado = false;
            }

            ValidacaoPrimeiroRegistroTO vSubmeter = new ValidacaoPrimeiroRegistroTO(TODAS_VALIDACOES);
            vSubmeter.setValidado(validado);

            return vSubmeter;

        } else {
            ValidacaoPrimeiroRegistroTO vSubmeter = new ValidacaoPrimeiroRegistroTO(ETAPA_INVALIDA);
            vSubmeter.setValidado(false);
            return vSubmeter;
        }
    }


    public ValidacaoPrimeiroRegistroTO validarCadastroRegistroManutencaoEmLote(Integer idCooperativa) {

        Cooperativa c = obterCooperativa(idCooperativa);

        if (!Boolean.FALSE.equals(podePreencherCadastroRegistroManutencao(idCooperativa)) &&
                (Objects.isNull(c.getProgressoManutencaoMacro()) || ProgressoMacroEnum.MANUTENCAO_10 == c.getProgressoManutencaoMacro())) {

            ValidacaoPrimeiroRegistroTO vContato = validaContato(c);
            if (verificaContato(vContato)) {
                return vContato;
            }

            ValidacaoPrimeiroRegistroTO vDadosGerais = dadosGeraisService.validarDadosGeraisManutencao(idCooperativa, true);
            if (verificaDadosGerais(vDadosGerais)) {
                return vDadosGerais;
            }

            ValidacaoPrimeiroRegistroTO vNegocio = negocioService.validarNegocioManutencao(idCooperativa, true);
            if (verificaNegocio(vNegocio)) {
                return vNegocio;
            }

            ValidacaoPrimeiroRegistroTO vGovernanca = governancaService.validarGovernancaManutencao(idCooperativa, true);
            if (verificaGovernanca(vGovernanca)) {
                return vGovernanca;
            }

            boolean validado = true;
            ValidacaoPrimeiroRegistroTO vSubmeter = new ValidacaoPrimeiroRegistroTO(TODAS_VALIDACOES);
            vSubmeter.setValidado(validado);

            return vSubmeter;

        } else {
            ValidacaoPrimeiroRegistroTO vSubmeter = new ValidacaoPrimeiroRegistroTO(ETAPA_INVALIDA);
            vSubmeter.setValidado(false);
            return vSubmeter;
        }

    }

    private ValidacaoPrimeiroRegistroTO validaContato(Cooperativa c) {

        Integer sqPessoa = c.getVwPessoaJuridica().getId();
        List<Contato> contatos =  contatoService.getContatosPessoa(sqPessoa);
        ValidacaoPrimeiroRegistroTO vContato = new ValidacaoPrimeiroRegistroTO("Contato");
        try{
            vContato.setValidado(contatoService.verificarTodosCamposPreenchidos(contatos));
            if (!vContato.getValidado()) {
                salvaMensagemErroContato("Campos não preenchidos", vContato);
            }
        }catch( Exception e){
        	LOGGER.error(e.getMessage());
            vContato.setValidado(false);
            salvaMensagemErroContato(e.getMessage(), vContato);
        }

        return vContato;
    }

    private static void salvaMensagemErroContato(String mensagemErro, ValidacaoPrimeiroRegistroTO vContato) {
        ServiceMessage msg = new ServiceMessage();
        msg.setType(MessageType.ERROR);
        msg.setMessage(mensagemErro);
        vContato.setMensagens(new ArrayList<>());
        vContato.getMensagens().add(msg);
    }

    public ValidacaoPrimeiroRegistroTO validarCadastroRegistro(Integer idCooperativa, boolean considerarCiclo) {

        Cooperativa c = obterCooperativa(idCooperativa);

        if ((!Boolean.FALSE.equals(podePreencherCadastroRegistro(idCooperativa)) && (
                ProgressoMacroEnum.PRE_CADASTRO_0 == c.getProgressoMacro()))
                        || ProgressoMacroEnum.CADASTRO_INICIADO_1 == c.getProgressoMacro()
                        || ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2 == c.getProgressoMacro()
                        || ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3 == c.getProgressoMacro()){

            ValidacaoPrimeiroRegistroTO vDadosGerais = dadosGeraisService.validarDadosGerais(idCooperativa);
            if (verificaDadosGerais(vDadosGerais)) {
                return comMotivoDeBloqueio(vDadosGerais);
            }

            ValidacaoPrimeiroRegistroTO vGovernanca = governancaService.validarGovernanca(idCooperativa, true);
            if (verificaGovernanca(vGovernanca)) {
                return comMotivoDeBloqueio(vGovernanca);
            }

            ValidacaoPrimeiroRegistroTO vNegocio = negocioService.validarNegocio(idCooperativa, true);
            if (verificaNegocio(vNegocio)) {
                return comMotivoDeBloqueio(vNegocio);
            }

            ValidacaoPrimeiroRegistroTO vDocumento = documentoCliente.validarDocumentos(idCooperativa, considerarCiclo);
            if (verificaDOcumento(vDocumento)) {
                return comMotivoDeBloqueio(vDocumento, CADASTRO_DOCUMENTOS_COM_PENDENCIA);
            }

            // Verificar se há pendências de preenchimento ( VALIDAÇÃO ) em documentos
            boolean validado = true;
            if (Boolean.FALSE.equals(cooperativaPendenciaService.verificarPendenciasValidadas(idCooperativa, "DOCUMENTOS"))) {
                validado = false;
            }

            ValidacaoPrimeiroRegistroTO vSubmeter = new ValidacaoPrimeiroRegistroTO(TODAS_VALIDACOES);
            vSubmeter.setValidado(validado);
            if (!validado) {
                return comMotivoDeBloqueio(vSubmeter, CADASTRO_DOCUMENTOS_COM_PENDENCIA);
            }

            return vSubmeter;

        } else {
            ValidacaoPrimeiroRegistroTO vSubmeter = new ValidacaoPrimeiroRegistroTO(ETAPA_INVALIDA);
            vSubmeter.setValidado(false);
            return vSubmeter;
        }

    }

    private boolean verificaDOcumento(ValidacaoPrimeiroRegistroTO vDocumento) {
        return Objects.nonNull(vDocumento) && !vDocumento.getValidado();
    }

    private boolean verificaNegocio(ValidacaoPrimeiroRegistroTO vNegocio) {
        return Objects.nonNull(vNegocio) && !vNegocio.getValidado();
    }

    ValidacaoPrimeiroRegistroTO comMotivoDeBloqueio(ValidacaoPrimeiroRegistroTO validacao) {
        return comMotivoDeBloqueio(validacao, CADASTRO_AJUSTE_SOLICITADO_ABERTO);
    }

    ValidacaoPrimeiroRegistroTO comMotivoDeBloqueio(ValidacaoPrimeiroRegistroTO validacao, String chaveMensagem) {
        if (Objects.isNull(validacao)) {
            return validacao;
        }
        if (Objects.isNull(validacao.getMensagens()) || validacao.getMensagens().isEmpty()) {
            ServiceMessage mensagem = new ServiceMessage();
            mensagem.setType(MessageType.ERROR);
            mensagem.setMessage(messages.get(chaveMensagem));
            List<ServiceMessage> mensagens = new ArrayList<>();
            mensagens.add(mensagem);
            validacao.setMensagens(mensagens);
        }
        return validacao;
    }

    private boolean verificaGovernanca(ValidacaoPrimeiroRegistroTO vGovernanca) {
        return Objects.nonNull(vGovernanca) && !vGovernanca.getValidado();
    }

    private boolean verificaDadosGerais(ValidacaoPrimeiroRegistroTO vDadosGerais) {
        return Objects.nonNull(vDadosGerais) && !vDadosGerais.getValidado();
    }

    private boolean verificaContato(ValidacaoPrimeiroRegistroTO vContato) {
        return Objects.nonNull(vContato) && !vContato.getValidado();
    }

    public Boolean podePreencherCadastroRegistro(Integer idCooperativa) {
        Cooperativa c = obterCooperativa(idCooperativa);
        return Objects.equals(c.getSituacaoCooperativa().getId(), SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo())
                && !Boolean.TRUE.equals(c.getArquivado());
    }

    public Boolean podePreencherCadastroRegistroManutencao(Integer idCooperativa) {
        Cooperativa c = obterCooperativa(idCooperativa);
        return (!Objects.equals(c.getSituacaoCooperativa().getId(), SituacaoCooperativaEnum.CANCELADA.getCodigo())
                && !Objects.equals(c.getSituacaoCooperativa().getId(), SituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo()))
                &&
                !Boolean.TRUE.equals(c.getArquivado());
    }

    public Boolean podePreencherCadastroRegistroCooperativaManutencao(Integer idCooperativa) {

        // Verifica sub perfil    	
        if (keycloakService.isVerificaPossuiSubPerfil(CO_VIS) ||
                keycloakService.isVerificaPossuiSubPerfil(UE_VIS) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil(UN_VIS))) {
            return false;
        }

        Cooperativa c = obterCooperativa(idCooperativa);
        Boolean saida = Boolean.FALSE;

        // Somente do estado
        // Só pode mexer em cooperativas do seu estado
        if (keycloakService.isTipoEntidadeEstadual()
                && !Objects.equals(c.getPessoaJuridica().getUfSigla(), keycloakService.getUFUsuario())) {
            return saida;
        }

        if ((keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional()) &&
                (!Objects.equals(c.getSituacaoCooperativa().getId(), SituacaoCooperativaEnum.CANCELADA.getCodigo()))) {
            return Boolean.TRUE;
        }

        if (Boolean.FALSE.equals(podePreencherCadastroRegistroManutencao(idCooperativa))) {
            return Boolean.FALSE;
        }

        // caso a cooperativa ja tenha iniciado o processo de manutensão
        if (Objects.nonNull(c.getProgressoManutencaoMicro())) {
            if (ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2 == c.getProgressoManutencaoMicro()) {
                saida = Boolean.TRUE;
            }

            if (keycloakService.isTipoEntidadeCooperativa() && ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1 == c.getProgressoManutencaoMicro()) {
                saida = Boolean.FALSE;
            }

            if ((keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional())) {
                saida = Boolean.TRUE;
            }

        } else {
            saida = Boolean.TRUE;
        }

        return saida;
    }

    public Boolean podePreencherCadastroRegistroCooperativaBasico(Integer idCooperativa) {

        if (Boolean.FALSE.equals(podePreencherCadastroRegistro(idCooperativa))) {
            return Boolean.FALSE;
        }

        Cooperativa c = obterCooperativa(idCooperativa);
        Boolean saida = Boolean.FALSE;

        // Somente do estado
        // Só pode mexer em cooperativas do seu estado
        if (keycloakService.isTipoEntidadeEstadual()
                && !Objects.equals(c.getPessoaJuridica().getUfSigla(), keycloakService.getUFUsuario())) {
            return saida;
        }

        // Verifica sub perfil
        if (keycloakService.isVerificaPossuiSubPerfil(CO_VIS) ||
                keycloakService.isVerificaPossuiSubPerfil(UE_VIS) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil(UN_VIS))) {
            return false;
        }


        // Deverá estar nas seguintes fases
        if (Objects.nonNull(c.getProgressoMicro())) {

            if (keycloakService.isTipoEntidadeCooperativa()) {
                if (ProgressoMicroEnum.PRE_CADASTRO_0_0 == c.getProgressoMicro()
                        || ProgressoMicroEnum.AGUARDANDO_CADASTRO_1_1 == c.getProgressoMicro()
                        || ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2 == c.getProgressoMicro()
                        || ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2 == c.getProgressoMicro()){
                    saida = Boolean.TRUE;
                }
            } else if (((keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional())
                    && (ProgressoMicroEnum.PRE_CADASTRO_0_0 == c.getProgressoMicro()
                    || ProgressoMicroEnum.AGUARDANDO_CADASTRO_1_1 == c.getProgressoMicro()
                    || ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2 == c.getProgressoMicro()))
                    || ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1 == c.getProgressoMicro()
                    || ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1 == c.getProgressoMicro()
                    || ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2 == c.getProgressoMicro()){
                saida = Boolean.TRUE;
            }
        } else {
            saida = Boolean.TRUE;
        }

        return saida;
    }

    public Boolean podePreencherCadastroRegistroCooperativa(Integer idCooperativa) {

        // Verifica sub perfil    	
        // Verifica sub perfil
        if (keycloakService.isVerificaPossuiSubPerfil(CO_VIS) ||
                keycloakService.isVerificaPossuiSubPerfil(UE_VIS) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil(UN_VIS))) {
            return false;
        }

        if (Boolean.FALSE.equals(podePreencherCadastroRegistro(idCooperativa))) {
            return Boolean.FALSE;
        }

        Cooperativa c = obterCooperativa(idCooperativa);
        Boolean saida = Boolean.FALSE;

        // Somente do estado
        // Só pode mexer em cooperativas do seu estado
        if (keycloakService.isTipoEntidadeEstadual() && !Objects.equals(c.getPessoaJuridica().getUfSigla(), keycloakService.getUFUsuario())) {
            return saida;
        }

        // Deverá estar nas seguintes fases
        saida = this.isEtapapodePreencherCadastroRegistroCooperativa(c);

        return saida;
    }

    private boolean isEtapapodePreencherCadastroRegistroCooperativa(Cooperativa c) {
        Boolean saida = false;
        // Deverá estar nas seguintes fases
        if (Objects.nonNull(c.getProgressoMicro())) {

            if (keycloakService.isTipoEntidadeCooperativa()) {
                if (ProgressoMicroEnum.AGUARDANDO_ACEITE_DATA_VISITA_4_2 == c.getProgressoMicro()) {
                    saida = Boolean.TRUE;
                }
            } else if (((keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional())
                    && (ProgressoMacroEnum.VISITA_TECNICA_4 == c.getProgressoMacro()))
                    || ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1 == c.getProgressoMicro()
                    || ProgressoMicroEnum.REGISTROS_INDEFERIDOS_OCE_5_2 == c.getProgressoMicro()){
                saida = Boolean.TRUE;
            } else if ((keycloakService.isTipoEntidadeNacional()
                    && (ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3 == c.getProgressoMicro()))
                    || ProgressoMacroEnum.EMISSAO_CERTIFICADO_6 == c.getProgressoMacro()){
                saida = Boolean.TRUE;
            }
        } else {
            saida = Boolean.TRUE;
        }
        return saida;
    }

    public Boolean podePreencherCadastroValidacaoManutencao(Integer idCooperativa) {

        if (Boolean.FALSE.equals(podePreencherCadastroRegistroManutencao(idCooperativa))) {
            return Boolean.FALSE;
        }

        // Verifica sub perfil
        if (keycloakService.isVerificaPossuiSubPerfil(CO_VIS) ||
                keycloakService.isVerificaPossuiSubPerfil(UE_VIS) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil(UN_VIS))) {
            return false;
        }

        Cooperativa c = obterCooperativa(idCooperativa);
        Boolean saida = Boolean.FALSE;

        // Nacional ou Estadual
        if ((keycloakService.isTipoEntidadeEstadual() ||
                keycloakService.isTipoEntidadeNacional()) &&
                (ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1 == c.getProgressoManutencaoMicro())) {
            saida = Boolean.TRUE;
        }

        return saida;
    }

    public Boolean podePreencherCadastroValidacao(Integer idCooperativa) {

        if (Boolean.FALSE.equals(podePreencherCadastroRegistro(idCooperativa))) {
            return Boolean.FALSE;
        }

        Cooperativa c = obterCooperativa(idCooperativa);
        Boolean saida = Boolean.FALSE;

        // Nacional ou Estadual
        if (((keycloakService.isTipoEntidadeEstadual() || keycloakService.isTipoEntidadeNacional()) &&
                (ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1 == c.getProgressoMicro())) ||
                        ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1  == c.getProgressoMicro()) {
            saida = Boolean.TRUE;
        }

        // Verifica sub perfil    	
        if (keycloakService.isVerificaPossuiSubPerfil(CO_VIS) ||
                keycloakService.isVerificaPossuiSubPerfil(UE_VIS) ||
                Boolean.TRUE.equals(keycloakService.isVerificaPossuiSubPerfil(UN_VIS))) {
            return false;
        }

        return saida;
    }

    public Boolean submeterCadastroManutencao(Integer idCooperativa, Boolean emLote) {
        Cooperativa c = obterCooperativa(idCooperativa);

        boolean controleGravacao = false;
        if (Boolean.FALSE.equals(podePreencherCadastroRegistroManutencao(idCooperativa))) {
            salvarStatusValidacaoLoteCooperativa( c, StatusValidacaoEnum.FALHA_VALIDACAO, "Situação da Cooperativa CANCELADA ou NAO REGISTRADA ou Verifique estado de arquivamento da cooperativa" );
            return Boolean.FALSE;
        }

        Boolean saida = Boolean.FALSE;

        ValidacaoPrimeiroRegistroTO vpr = Boolean.TRUE.equals(emLote)
                ? validarCadastroRegistroManutencaoEmLote(idCooperativa)
                : validarCadastroRegistroManutencao(idCooperativa);
        if (vpr.getValidado() || (Boolean.TRUE.equals(emLote) && DOCUMENTOS.equals(vpr.getTitulo()))) {
            if (Objects.isNull(c.getProgressoManutencaoMacro()) || ProgressoMacroEnum.MANUTENCAO_10 == c.getProgressoManutencaoMacro()) {

                Aprovacao aprovacao = aprovacaoService.getAprovacao(idCooperativa);
                // Se já foi aprovado não faz nada
                if (Objects.isNull(c.getProgressoMicro())
                        && Objects.nonNull(aprovacao) && Objects.nonNull(aprovacao.getDataAtualizacao())) {
                    salvarStatusValidacaoLoteCooperativa(c, StatusValidacaoEnum.VALIDADO, "Validado com Sucesso");
                    return Boolean.TRUE;
                }

                if (Objects.isNull(c.getProgressoManutencaoMicro())
                        || ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1 == c.getProgressoManutencaoMicro()) {
                    this.processaMicroAguardandoAnaliseManutencao(c);
                } else {
                    c.setId(idCooperativa);
                    this.processaCadastroManutencao(c);
                }
                saida = Boolean.TRUE;
            } else {
                controleGravacao = true;
                salvarStatusValidacaoLoteCooperativa( c, StatusValidacaoEnum.FALHA_VALIDACAO, String.format(NAO_FOI_POSSIVEL_ENVIAR_O_FORMULARIO, c.getProgressoMicro().getNome()) );
                if(Boolean.FALSE.equals(emLote)) {
                    throw new RegraNegocioException(String.format(NAO_FOI_POSSIVEL_ENVIAR_O_FORMULARIO, c.getProgressoMicro().getNome()));
                }
            }
        } else {
            controleGravacao = true;
            salvarStatusValidacaoLoteCooperativa( c, StatusValidacaoEnum.FALHA_VALIDACAO, "Aba " + vpr.getTitulo());
            if(Boolean.FALSE.equals(emLote)) {
                throw new RegraNegocioException(messages.get(CADASTRO_PENDENCIAS).formatted());
            }
        }

        if(!controleGravacao) {
            salvarStatusValidacaoLoteCooperativa(c, StatusValidacaoEnum.VALIDADO, "Validado com Sucesso");

        }

        cooperativaManutencaoAbasService.salvarStatusAbasManutencao(c.getId(), saida, AbaEnum.ABA_SUBMETER);

        return saida;
    }

    private void salvarPendenciasAproivacaoEmLote(Cooperativa c){
        int countIndAux = 1;
        List<CooperativaPendencia> pendencias = new ArrayList<>();
        pendencias.add(criarPendencia(c, "MANUTENCAO_DADOS_GERAIS_CONTATOS_DA_COOPERATIVA"));
        pendencias.add(criarPendencia(c, "MANUTENCAO_DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA"));
        pendencias.add(criarPendencia(c, "MANUTENCAO_DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA"));
        pendencias.add(criarPendencia(c, "MANUTENCAO_DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA"));
        for (int i = 0; i < TRES; i++) {
            pendencias.add(criarPendenciaComIdentificador(c, "MANUTENCAO_GOVERNANCA", countIndAux++));
        }
        pendencias.add(criarPendencia(c,"MANUTENCAO_NEGOCIO"));
        pendencias.add(criarPendencia(c,"MANUTENCAO_NEGOCIO_FILIADAS"));
        cooperativaPendenciaService.salvarPendenciasManutencao(pendencias);
    }

    private static CooperativaPendencia criarPendenciaComIdentificador(Cooperativa cooperativa, String blocoEnum, int identificador) {
        CooperativaPendencia pendencia = criarPendencia(cooperativa, blocoEnum);
        pendencia.setIdentificadorAuxiliar(identificador);
        return pendencia;
    }

    private static CooperativaPendencia criarPendencia(Cooperativa cooperativa, String blocoEnum) {
        CooperativaPendencia pendencia = new CooperativaPendencia();
        pendencia.setCooperativa(cooperativa);
        pendencia.setDataHoraAtualizacao(new Date());
        pendencia.setBloco(blocoEnum);
        pendencia.setBlocoAdequado(true);
        pendencia.setValidado(true);
        pendencia.setVisualizado(false);
        return pendencia;
    }

    public void salvarStatusValidacaoLoteCooperativa(@Valid Cooperativa c, StatusValidacaoEnum status, String descricaoErro) {
        Integer cooperativaId = c.getId();
        Integer anoReferencia = Year.now().getValue();

        CooperativaValidacaoLote cooperativaValidacaoLote =
                cooperativaValidacaoLoteService.findByCooperativaIdAndAnoReferencia(cooperativaId, anoReferencia)
                        .orElseGet(CooperativaValidacaoLote::new);

        cooperativaValidacaoLote.setCooperativa(c);
        cooperativaValidacaoLote.setDataValidacao(new Date());
        cooperativaValidacaoLote.setAnoReferencia(anoReferencia);
        cooperativaValidacaoLote.setUsuarioValidacao(keycloakService.getUsername());
        cooperativaValidacaoLote.setStatusValidacao(status.name());
        cooperativaValidacaoLote.setDescricaoValidacao(descricaoErro);

        cooperativaValidacaoLoteService.saveOrUpdate(cooperativaValidacaoLote);

    }


    private void processaCadastroManutencao(Cooperativa c) {
        if (Objects.nonNull(c)) {
            // Verificar se há pendências
            ValidacaoPendenciaTO validacao = cooperativaPendenciaService.obterPendenciasAbasManutencao(c.getId());
            if (Boolean.TRUE.equals(validacao.getPodeProgredir())) {
                // Aprovar Tudo
                aprovacaoService.aprovarTodosDadosCooperativa(c.getId());
                c.setProgressoManutencaoMicro(null);
                c.setProgressoManutencaoMacro(null);
                c.setDataAtualizacao(new Date());
            } else {
                c.setProgressoManutencaoMicro(ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1);
                c.setProgressoManutencaoMacro(ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1.getProgressoMacro());
            }
            this.processaSubmeterCadastroManutencao(c);
        }
    }

    private void processaMicroAguardandoAnaliseManutencao(Cooperativa c) {
        if (Objects.nonNull(c)) {

            ProgressoMicroEnum progressoMicroEnum = Objects.isNull(c.getProgressoManutencaoMicro()) ? ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1
                    : ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2;
            c.setProgressoManutencaoMicro(progressoMicroEnum);
            c.setProgressoManutencaoMacro(progressoMicroEnum.getProgressoMacro());
            
            // Limpar Ajustes Anteriores
            cooperativaPendenciaService.marcarAjustesComoVisualizados(c.getId());
            this.processaSubmeterCadastroManutencao(c);
        }
    }

    /**
     * @param c
     * @return
     * @description Marca os ajustes como visualizados, salva a cooperativa manutenção e envia email.
     */
    private boolean processaSubmeterCadastroManutencao(Cooperativa c) {
        if (Objects.nonNull(c)) {
            // Setando a data de primeira abertura do processo e ultima submissao
            // Limpar Ajustes Anteriores
            cooperativaPendenciaService.marcarAjustesComoVisualizados(c.getId());
            c.setUsuarioSubmissao(keycloakService.getUsername());
            c.setNaoSubmeteu(Boolean.FALSE);
            c.setAtualizacaoNaoVisualizada(Boolean.TRUE);
            cooperativaService.save(c);
            // envia email
            disparodeEmails(c, EnvioEmailEventEnum.EMAIL_MANUTENCAO_SUBMETER);
            return true;
        } else {
            return false;
        }
    }

    public Boolean submeterCadastro(Integer idCooperativa) {

        if (Boolean.FALSE.equals(podePreencherCadastroRegistro(idCooperativa))) {
            return Boolean.FALSE;
        }

        Cooperativa c = obterCooperativa(idCooperativa);

        ValidacaoPendenciaTO pendenciasAbas = cooperativaPendenciaService.obterPendenciasAbas(idCooperativa);

        if (!ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2.equals(c.getProgressoMicro()) && possuiAbaNaoPreenchida(pendenciasAbas)) {
            throw new RegraNegocioException(messages.get(CADASTRO_ABA_NAO_PREECHIDA));
        }

        Cooperativa cooperativa =  new Cooperativa();
        Boolean saida;
        ValidacaoPrimeiroRegistroTO vpr = validarCadastroRegistro(idCooperativa, false);

        FaseProcessoRegistroEnum fase =
                ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2.equals(c.getProgressoMacro()) ?
                        FaseProcessoRegistroEnum.VALIDACAO :
                        ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3.equals(c.getProgressoMacro()) ?
                                FaseProcessoRegistroEnum.CONFORMIDADE :
                                FaseProcessoRegistroEnum.CADASTRO;

        if (vpr.getValidado()) {
            if (preCadastroOuAnalise(c)) {
                c.setProgressoCadastroState(progressoCadastroStateFactory.createAguardandoCadastroState());
                c.trocarEstado();
                saida = Boolean.TRUE;
            } else {
                throw new RegraNegocioException(String.format(NAO_FOI_POSSIVEL_ENVIAR_O_FORMULARIO, c.getProgressoMicro().getNome()));
            }
        } else {
            throw new RegraNegocioException("Existem pendências no preenchimento do formulário ( %s ).".formatted(vpr.getTitulo()));
        }

        if (!keycloakService.isTipoEntidadeNacional() && !keycloakService.isTipoEntidadeEstadual()) {
            cooperativa.setCadastroSemUsuario(Boolean.FALSE);
        }
        
        cooperativaManutencaoAbasService.salvarStatusAbasManutencao(c.getId(), saida, AbaEnum.ABA_SUBMETER);

        gravaProcessoRegistro(c, AcaoProcessoRegistroEnum.SUBMETER_CADASTRO, fase);

        return saida;
    }

    public boolean isFluxoUeUnCadastro(@Valid Cooperativa c) {
        return ((ProgressoMicroEnum.AGUARDANDO_CADASTRO_1_1 == c.getProgressoMicro() || ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1 == c.getProgressoMicro())) && (keycloakService.isTipoEntidadeNacional() || keycloakService.isTipoEntidadeEstadual());
    }

    @Deprecated
    private void processaPrecadastroSubmeterCadastro (Cooperativa cooperativa) {
        if (Objects.nonNull(cooperativa)) {
            cooperativa.setProgressoMicro(ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1);
            cooperativa.setProgressoMacro(ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1.getProgressoMacro());
            cooperativa.getProgressoCadastroState().trocarEstado(cooperativa);
        }
    }

    @Deprecated
    private void processaPreCadastroAguardandoAjusteConformidade (Cooperativa c) {
        if (Objects.nonNull(c)) {
            c.setProgressoMicro(ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1);
            c.setProgressoMacro(ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1.getProgressoMacro());

            // Mover arquivo de conformidade para o histórico
            if (Objects.nonNull(c.getParecer()) && ValidacaoCampos.validaCampoPreenchido(c.getParecer().getArquivoConformidade())) {
                fileUploadClient.deletarDiretorioLogicamente(c.getParecer().getArquivoConformidade());
            }
            this.processaSubmeterCadastro(c);
        }
    }

    @Deprecated
    private void processaSubmeterCadastro (Cooperativa c) {
        // Setando a data de primeira abertura do processo e ultima submissao
        c.setAtualizacaoNaoVisualizada(Boolean.TRUE);
        inicializaDatas(c);
        c.setUsuarioSubmissao(keycloakService.getUsername());
        cooperativaService.save(c);
        // Limpar Ajustes Anteriores
        cooperativaPendenciaService.marcarAjustesComoVisualizados(c.getId());
        // envia email
        enviaEmailSubmeter(c);
        // Jogar a Conformidade para o histórico ( Verificado caso o fluxo volte para
        // essa etapa )
        if (verificarArquivoConformidade(c)) {
            fileUploadClient.deletarDiretorioLogicamente(c.getParecer().getArquivoConformidade());
        }
    }

    private void inicializaDatas(Cooperativa c) {
        if (keycloakService.isTipoEntidadeCooperativa() && Objects.isNull(c.getDataAberturaProcesso())) {
            c.setDataAberturaProcesso(new Date());
        }
    }

    private boolean verificarArquivoConformidade (Cooperativa c) {
        return (ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2 == c.getProgressoMicro())
                && (Objects.nonNull(c.getParecer())
                && ValidacaoCampos.validaCampoPreenchido(c.getParecer().getArquivoConformidade()));
    }


    private boolean preCadastroOuAnalise(Cooperativa c) {
        return Objects.isNull(c.getProgressoMicro())
                || (ProgressoMicroEnum.PRE_CADASTRO_0_0 == c.getProgressoMicro())
                || ProgressoMicroEnum.AGUARDANDO_CADASTRO_1_1 == c.getProgressoMicro()
                || ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2 == c.getProgressoMicro()
                || ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2 == c.getProgressoMicro();
    }

    public void enviaEmailSubmeter (@Valid Cooperativa cooperativa) {
        this.emailService.enviaEmailSubmeter(cooperativa);
    }

    public void notificarOrganizacaoEstadual(Integer idCooperativa) {
        Cooperativa coop = obterCooperativa(idCooperativa);
        List<PessoaJuridica> listaOe = cooperativaService.buscarOEPorUf(coop.getPessoaJuridica().getUfSigla());
        String emails = listaOe.stream()
                .filter(Objects::nonNull)
                .map(PessoaJuridica::getEmailGeral)
                .filter(email -> Objects.nonNull(email) && !email.isEmpty())
                .collect(Collectors.joining(","));
        disparodeEmails(coop, EnvioEmailEventEnum.EMAIL_INICIO_PROCESSO_REGISTRO, emails);
        gravaProcessoRegistro(coop, AcaoProcessoRegistroEnum.INICIAR_PROCESSO_REGISTRO, FaseProcessoRegistroEnum.CADASTRO);
    }

    private void disparodeEmails(Cooperativa c, EnvioEmailEventEnum type) {
        disparodeEmails(c, type, null);
    }

    private void disparodeEmails(Cooperativa c, EnvioEmailEventEnum type, String destinatarios) {
        EmailEventTO to = new EmailEventTO();
        to.setCooperativa(c);
        to.setDestinatarios(destinatarios);
        EmailServiceEvent<EmailEventTO> event = new EmailServiceEvent<>(type.getId(), type, to);
        applicationEventPublisher.publishEvent(event);
    }

    private void gravaProcessoRegistro(Cooperativa cooperativa, AcaoProcessoRegistroEnum acao, FaseProcessoRegistroEnum fase) {
        CooperativaHistoricoProcessoRegistroTO to = new CooperativaHistoricoProcessoRegistroTO();
        to.setCooperativaId(cooperativa.getId());
        to.setDataAtualizacao(new Date());
        to.setAcao(acao);
        to.setFase(fase);
        to.setUsuario(keycloakService.getNome());
        cooperativaHistoricoProcessoRegistroService.salvar(to);
    }

    private Cooperativa obterCooperativa(Integer idCooperativa) {
        return Objects.requireNonNull(cooperativaService.getCooperativa(idCooperativa), "Cooperativa não encontrada");
    }

    private static boolean possuiAbaNaoPreenchida(ValidacaoPendenciaTO pendenciasAbas) {
        return Objects.isNull(pendenciasAbas)
                || Objects.isNull(pendenciasAbas.getGovernanca())
                || !Boolean.TRUE.equals(pendenciasAbas.getGovernanca().getAbaPreenchida())
                || Objects.isNull(pendenciasAbas.getNegocio())
                || !Boolean.TRUE.equals(pendenciasAbas.getNegocio().getAbaPreenchida())
                || Objects.isNull(pendenciasAbas.getDadosGerais())
                || !Boolean.TRUE.equals(pendenciasAbas.getDadosGerais().getAbaPreenchida())
                || Objects.isNull(pendenciasAbas.getDocumentos())
                || !Boolean.TRUE.equals(pendenciasAbas.getDocumentos().getAbaPreenchida());
    }

}
