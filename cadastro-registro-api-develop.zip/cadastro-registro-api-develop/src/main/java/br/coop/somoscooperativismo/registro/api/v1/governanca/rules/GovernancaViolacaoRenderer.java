package br.coop.somoscooperativismo.registro.api.v1.governanca.rules;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.governanca.GovernancaConstants;
import br.coop.somoscooperativismo.registro.api.v1.util.RemoveMascaraUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Converte {@link ViolacaoGovernanca} (tipada, pura) na {@code ServiceMessage}
 * pt-BR exibida hoje, na fronteira do serviço. Centraliza a montagem das
 * mensagens que estavam duplicadas entre Registro e Manutenção, garantindo
 * <b>texto idêntico</b> nos dois fluxos (SC-001/SC-002, research D2).
 */
@Component
@RequiredArgsConstructor
public class GovernancaViolacaoRenderer {

    private final MessagesService messages;

    public List<ServiceMessage> render(ResultadoValidacaoGovernanca resultado) {
        List<ServiceMessage> lista = new ArrayList<>();
        for (ViolacaoGovernanca v : resultado.getViolacoes()) {
            lista.add(new ServiceMessage(MessageType.ERROR, render(v)));
        }
        return lista;
    }

    public String render(ViolacaoGovernanca v) {
        String orgao = v.orgaoNome();
        String cpf = v.cpf() == null ? "" : RemoveMascaraUtil.mascaraCPF(v.cpf());
        switch (v.tipo()) {
            case NUMERO_MINIMO_MEMBROS:
                return "<b>" + orgao + GovernancaConstants.NEGRITO
                        + messages.get(GovernancaConstants.GOVERNANCA_NUMERO_MINIMO_MEMBRO) + " " + v.minimo() + ".";
            case NUMERO_MEMBROS_NAO_CORRESPONDE:
                return "<b>" + orgao + GovernancaConstants.NEGRITO
                        + messages.get(GovernancaConstants.GOVERNANCA_NUMERO_MEMBROS_NAO_CORRESPONDE);
            case CARGO_OBRIGATORIO_AUSENTE:
                return "<b>" + v.detalhe() + GovernancaConstants.NEGRITO
                        + messages.get(GovernancaConstants.GOVERNANCA_CARGO_OBRIGATORIO) + " " + orgao;
            case CARGO_RETIRADO_DO_ORGAO:
                return "<b> O cargo do membro " + v.detalhe() + GovernancaConstants.NEGRITO
                        + " foi retirado do órgão " + orgao + ". Selecione um novo cargo";
            case ORGAO_OBRIGATORIO_NAO_CADASTRADO:
                // QA N4 (varredura): espaço após o fechamento do negrito — antes
                // renderizava "…Diretoria:</b>órgão de cadastro…" (texto colado).
                return "<b>" + orgao + ":" + GovernancaConstants.NEGRITO + " "
                        + messages.get(GovernancaConstants.GOVERNANCA_ORGAO_OBRIGATORIO);
            case RESPONSAVEL_LEGAL_OBRIGATORIO:
                return "<b>" + orgao + "</b>: "
                        + messages.get(GovernancaConstants.GOVERNANCA_RESPONSAVEL_LEGAL_OBRIGATORIO);
            case DATA_ASSEMBLEIA_OBRIGATORIA:
                return messages.get(GovernancaConstants.GOVERNANCA_DATA_ASSEMBLEIA_OBRIGATORIA) + " " + orgao;
            case ASSEMBLEIA_ANTERIOR_CONSTITUICAO_CONS_ADM:
                return messages.get(GovernancaConstants.GOVERNANCA_DATAASSEMBLEIA_ANTERIOR_CONSTITUICAO_CONSELHOADM);
            case ASSEMBLEIA_ANTERIOR_CONSTITUICAO_CONS_FISCAL:
                return messages.get(GovernancaConstants.GOVERNANCA_DATAASSEMBLEIA_ANTERIOR_CONSTITUICAO_CONSELHOFISCAL);
            // QA N4 (varredura): separador "</b>: " nas mensagens de membro — antes o
            // texto saía colado ao órgão (ex.: "…Fiscal</b>cargo é obrigatório…"),
            // mesmo padrão das demais mensagens do catálogo ("<b>órgão</b>: …").
            case PESSOA_FISICA_NOME_OBRIGATORIO:
                return "<b>" + orgao + GovernancaConstants.NEGRITO + ": "
                        + messages.get(GovernancaConstants.PESSOA_FISICA_NOME_OBRIGATORIO) + " " + cpf;
            case PESSOA_FISICA_GENERO_OBRIGATORIO:
                return "<b>" + orgao + GovernancaConstants.NEGRITO + ": "
                        + messages.get(GovernancaConstants.PESSOA_FISICA_GENERO_OBRIGATORIO) + " " + cpf;
            case MEMBRO_CARGO_OBRIGATORIO:
                return "<b>" + orgao + GovernancaConstants.NEGRITO + ": "
                        + messages.get(GovernancaConstants.CARGO_OBRIGATORIO) + " " + cpf;
            case INICIO_OBRIGATORIO:
                return "<b>" + orgao + GovernancaConstants.NEGRITO + ": "
                        + messages.get(GovernancaConstants.INICIO_OBRIGATORIO) + GovernancaConstants.CPF + cpf;
            case MEMBRO_FIM_OBRIGATORIO:
                return "<b>" + orgao + GovernancaConstants.NEGRITO + ": "
                        + messages.get(GovernancaConstants.FIM_OBRIGATORIO) + GovernancaConstants.CPF + cpf;
            case FIM_OBRIGATORIO_INATIVO:
                return "<b>Data de desligamento</b> é obrigatória para membro inativo para o CPF: " + cpf;
            case INICIO_INVALIDO:
                return messages.get(GovernancaConstants.INICIO_INVALIDO) + cpf;
            case DATA_INICIO_SUPERIOR:
                return messages.get(GovernancaConstants.DATA_INICIO_SUPERIOR) + cpf;
            case CPF_DUPLICADO:
                return "CPF " + v.cpf() + " está duplicado na governança";
            case CPF_DUPLICADO_ENTRE_CONSELHOS:
                return "CPF " + cpf + " já ocupa uma posição ativa no órgão " + v.detalhe()
                        + " e não pode ocupar outra posição ativa no órgão " + orgao;
            default:
                return messages.get("governanca.violacao.desconhecida");
        }
    }
}
