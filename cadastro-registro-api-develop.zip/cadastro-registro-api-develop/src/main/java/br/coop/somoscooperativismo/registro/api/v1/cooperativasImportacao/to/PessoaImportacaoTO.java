package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PessoaImportacaoTO {
    private Integer id;
    private List<EnderecoImportacaoTO> enderecos;
    private List<RedeSocialImportacaoTO> redesSociais;
}
