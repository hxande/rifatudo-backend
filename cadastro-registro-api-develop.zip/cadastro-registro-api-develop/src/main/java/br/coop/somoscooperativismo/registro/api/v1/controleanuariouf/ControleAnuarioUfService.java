package br.coop.somoscooperativismo.registro.api.v1.controleanuariouf;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

import jakarta.validation.Valid;

import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.controleanuariouf.entidade.ControleAnuarioUf;


@Service
public class ControleAnuarioUfService {
    private static final String NAO_ENCONTRADO = "controleAnuario.naoEncontrado";
    final ControleAnuarioUfRepository controleAnuarioUfRepository;
    
    final KeycloakService keycloakService; 
    final MessagesService messages;

    public ControleAnuarioUfService(ControleAnuarioUfRepository controleAnuarioUfRepository, MessagesService messages, KeycloakService keycloakService) {
        this.controleAnuarioUfRepository = controleAnuarioUfRepository;
        this.messages = messages;
        this.keycloakService = keycloakService;
    }
    
    public ControleAnuarioUf findByUf(String uf) {
		uf = "null".equals(uf) ? null : uf;
		if (keycloakService.isTipoEntidadeEstadual()) {
			uf = keycloakService.getUFUsuario();
		}
		ControleAnuarioUf controleAnuarioUf = controleAnuarioUfRepository.findByUf(uf);
		if(controleAnuarioUf == null) {
			return novoControleUf(uf);
		}
		return controleAnuarioUf;
    }
    
    private ControleAnuarioUf novoControleUf(String uf) {
		var controleAnuarioUf = new ControleAnuarioUf();
		controleAnuarioUf.setUf(uf);
		controleAnuarioUf.setChaveAnuario("SESCOOP");
		controleAnuarioUf.setVisualizarPeriodoAtualizacao(Boolean.FALSE);
		controleAnuarioUf.setCooperativaPodePreencher(Boolean.FALSE);
		controleAnuarioUf.setCooperativaPodeVisualizar(Boolean.FALSE);
		controleAnuarioUf.setDestacarAnuario(Boolean.FALSE);
		controleAnuarioUf.setMostrarpopup(Boolean.FALSE);
		controleAnuarioUf.setHabilitarPreenchimentoAnuario(Boolean.TRUE);
		return controleAnuarioUf;
	}

	public ControleAnuarioUf updateControleAnuarioUf(Integer id, ControleAnuarioUf controleAnuarioUfUpdated) {    	
    	ControleAnuarioUf controleAnuarioUf = this.controleAnuarioUfRepository.findById(id).orElse(null);
    	 
    	if(controleAnuarioUf == null) {
    		throw new RegraNegocioException(NAO_ENCONTRADO);
    	}
    	
    	if(keycloakService.isTipoEntidadeNacional()) {
    		controleAnuarioUfUpdated.setId(id);
    		controleAnuarioUfUpdated.setUf(controleAnuarioUf.getUf());
    		controleAnuarioUfUpdated.setChaveAnuario(controleAnuarioUf.getChaveAnuario());
    		controleAnuarioUf = this.controleAnuarioUfRepository.save(controleAnuarioUfUpdated);
    	}else if(keycloakService.isTipoEntidadeEstadual()) {
    		String uf;
    		uf = keycloakService.getUFUsuario();
    		if(controleAnuarioUf.getUf() != null && !controleAnuarioUf.getUf().equals(uf)) {
    			throw new RegraNegocioException("Controle do Anuário não pode ser atualizad por este usuário");
    		}
    		
    		controleAnuarioUfUpdated.setId(id);
    		controleAnuarioUfUpdated.setUf(uf);
    		controleAnuarioUfUpdated.setChaveAnuario(controleAnuarioUf.getChaveAnuario());
    		
    		controleAnuarioUf = this.controleAnuarioUfRepository.save(controleAnuarioUfUpdated);
    	}
    	    	
    	return controleAnuarioUf;
    }

	public ControleAnuarioUf salvar(@Valid ControleAnuarioUf controleAnuarioUf) {
		
		if(this.keycloakService.isTipoEntidadeEstadual()) {
			ControleAnuarioUf controleAnuarioUfEstadual = controleAnuarioUfRepository.findByUf(keycloakService.getUFUsuario());
			if(!ValidacaoCampos.validaCampoPreenchido(controleAnuarioUfEstadual)) {
				// Se nao encontrar o registro, é um insert
				controleAnuarioUf.setId(null);
			}
			controleAnuarioUf.setUf(keycloakService.getUFUsuario());
		}
		return this.controleAnuarioUfRepository.save(controleAnuarioUf);
	}

	public ControleAnuarioUf obterControleNacional() {

		return this.controleAnuarioUfRepository.findByUfIsNull();
	}

	public ControleAnuarioUf buscarControleExistente(String uf) {
		List<ControleAnuarioUf> listControleAnuarioUf = controleAnuarioUfRepository.findAllByUf(uf);
		final String ufFinal = uf;
		Predicate<ControleAnuarioUf> filtroUf = cau -> Objects.equals(ufFinal,cau.getUf());
		return listControleAnuarioUf.stream()
				.filter(filtroUf).findAny().orElse(listControleAnuarioUf.get(0));
	}
	
	
	public void desabilitarControleAtualizacaoCadastral(boolean ativa) {
		if(!keycloakService.isTipoEntidadeNacional()) {
			throw new RegraNegocioException("Usuário sem permissão para esta operação");
		}
		List<ControleAnuarioUf> listControleAnuarioUf = controleAnuarioUfRepository.findAll();		
		listControleAnuarioUf.forEach(controleAnuarioUf -> {
			habilitaDesabilitaControleAnuarioUf(controleAnuarioUf,ativa);
			
		});
		controleAnuarioUfRepository.saveAll(listControleAnuarioUf);
	}
	
	private void habilitaDesabilitaControleAnuarioUf(ControleAnuarioUf controleAnuarioUf, boolean ativa) {
		if(ativa) {
			controleAnuarioUf.setHabilitarPreenchimentoAnuario(Boolean.TRUE);
		} else {
			controleAnuarioUf.setDestacarAnuario(Boolean.FALSE);
			controleAnuarioUf.setCooperativaPodePreencher(Boolean.FALSE);
			controleAnuarioUf.setCooperativaPodeVisualizar(Boolean.TRUE);
			controleAnuarioUf.setHabilitarPreenchimentoAnuario(Boolean.FALSE);
			controleAnuarioUf.setMostrarpopup(Boolean.FALSE);
			controleAnuarioUf.setVisualizarPeriodoAtualizacao(Boolean.FALSE);
			controleAnuarioUf.setTextoPop(null);
		}
	}
    

}