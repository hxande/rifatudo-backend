package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContatoImportacaoTO {
    private Integer id;
    private PessoaImportacaoTO pessoa;
    private AreaContatoTO areaContato;
    private String nomeResponsavel;
    private String telefone;
    private String celular;
    private String email;
    private String site;
    private String cargo;
}
