package br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuarioramourl.entidade.ComplementoAnuarioRamoUrl;
import java.util.Optional;

import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.ComplementoAnuarioRepository;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class ComplementoAnuarioRamoUrlServiceImpl implements ComplementoAnuarioRamoUrlService {

    private final ComplementoAnuarioRepository complementoAnuarioRepository;
    private final ComplementoAnuarioRamoUrlRepository complementoAnuarioRamoUrlRepository;
    private final ComplementoAnuarioRamoUrlMapper complementoAnuarioRamoUrlMapper;

    @Override
    public Optional<Optional<ComplementoAnuarioRamoUrlTO>> deleteById(Integer complementoAnuarioId, Integer id) {
        return this.complementoAnuarioRepository.findById(complementoAnuarioId).map(complementoAnuario -> {
           return this.complementoAnuarioRamoUrlRepository.findById(id).map(complementoAnuarioRamoUrl -> {
                       complementoAnuario.removeComplementoAnuarioRamoUrl(complementoAnuarioRamoUrl);
                       this.complementoAnuarioRepository.save(complementoAnuario);
                       return this.toDto(complementoAnuarioRamoUrl);
                   }) ;
        });
    }

    private ComplementoAnuarioRamoUrlTO toDto(ComplementoAnuarioRamoUrl complementoAnuarioRamoUrl) {
        return this.complementoAnuarioRamoUrlMapper.toDto(complementoAnuarioRamoUrl);
    }
}
