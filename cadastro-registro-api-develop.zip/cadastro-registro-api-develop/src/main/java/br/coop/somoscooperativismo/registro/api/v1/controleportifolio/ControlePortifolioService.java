package br.coop.somoscooperativismo.registro.api.v1.controleportifolio;


import br.coop.somoscooperativismo.registro.api.v1.controleportifolio.entidade.ControlePortifolio;

public interface ControlePortifolioService {

	ControlePortifolio salvar(ControlePortifolio controlePortifolio);

	ControlePortifolio obterPorUf(String uf);
	
	ControlePortifolio obterControleNacional();
	
	ControlePortifolio habilitaControleNacional(boolean habilita);
	
	
}
