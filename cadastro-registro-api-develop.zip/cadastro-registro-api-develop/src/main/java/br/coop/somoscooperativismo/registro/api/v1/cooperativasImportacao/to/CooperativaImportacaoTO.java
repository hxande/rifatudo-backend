package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CooperativaImportacaoTO {
    private Integer id;
    private PessoaJuridicaImportacaoTO pessoaJuridica;
    private CategoriaImportacaoTO categoria;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataRegistro;
    private String numeroRegistroOCB;
    private String processo;
    private ProgressoMicroEnum progressoMicro;
    private ProgressoMacroEnum progressoMacro;
    private SituacaoImportacaoTO situacaoCooperativa;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataAberturaProcesso;
    private Date dataAtualizacao;
    private ProgressoMicroEnum progressoManutencaoMicro;
    private ProgressoMacroEnum progressoManutencaoMacro;
    private Boolean arquivado;
    private Boolean solicitacaoInativacao;
    private Boolean solicitacaoAtivacao;
    private String justificativaSolicitacaoInativacao;
    private String justificativaCancelada;
    private String justificativaInativada;
    private String justificativaIrregular;
    private String justificativaAtivacao;
    private Boolean processoTransferencia;
    private Integer sqNumeroRegistroOCB;
    private Boolean atualizacaoNaoVisualizada;
    private Boolean cadastroSemUsuario;
    private Boolean naoSubmeteu;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
    private Date dataUltimaAnaliseUE;
    private Boolean regidaPorLei;
    private Boolean liquidacao;
    private List<QuadroSocialImportacaoTO> quadrosSociais;
    private Set<CooperativaImportacaoTO> cooperativasColigadas;
}
