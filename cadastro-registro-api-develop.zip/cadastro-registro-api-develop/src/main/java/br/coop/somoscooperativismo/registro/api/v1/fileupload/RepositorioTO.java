package br.coop.somoscooperativismo.registro.api.v1.fileupload;

import java.util.List;

public class RepositorioTO {

	private String chaveRepositorio;
	private String expiraEm;
	private List<RepositorioArquivoTO> arquivos;
	private List<RepositorioArquivoTO> arquivosExcluidos;

	public String getChaveRepositorio() {
		return chaveRepositorio;
	}

	public void setChaveRepositorio(String chaveRepositorio) {
		this.chaveRepositorio = chaveRepositorio;
	}

	public List<RepositorioArquivoTO> getArquivos() {
		return arquivos;
	}

	public void setArquivos(List<RepositorioArquivoTO> arquivos) {
		this.arquivos = arquivos;
	}

	public String getExpiraEm() {
		return expiraEm;
	}

	public void setExpiraEm(String expiraEm) {
		this.expiraEm = expiraEm;
	}

	public List<RepositorioArquivoTO> getArquivosExcluidos() {
		return arquivosExcluidos;
	}

	public void setArquivosExcluidos(List<RepositorioArquivoTO> arquivosExcluidos) {
		this.arquivosExcluidos = arquivosExcluidos;
	}

}
