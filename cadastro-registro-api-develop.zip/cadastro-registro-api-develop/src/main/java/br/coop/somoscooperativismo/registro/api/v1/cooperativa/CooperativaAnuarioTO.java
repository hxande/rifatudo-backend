package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.regularidadecooperativa.RegularidadeCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CooperativaAnuarioTO {

	private Integer id;	
	private String cnpj;
	private String razaoSocial;
	private String nomeFantasia;
	private String ufSigla;
	private String ramo;
	private String situacaoRegistro;
	private Character regularidadeCooperativa;
	private String anuarioPreenchido;
	private BigDecimal ativoTotal;
	private BigDecimal ativoImobilizado;
	private BigDecimal patrimonioLiquido;
	private BigDecimal capitalSocial;
	private BigDecimal sobrasPerdasExercicio;
	private BigDecimal ingressosReceitasBrutas;
	private BigDecimal tributos;
	private BigDecimal despesasPessoal;
	
	public CooperativaAnuarioTO() { }
	
	public CooperativaAnuarioTO(Integer id, String cnpj, String razaoSocial, String nomeFantasia, String ufSigla,
			String ramo, String situacaoRegistro, Character regularidadeCooperativa, 
			BigDecimal ativoTotal, BigDecimal ativoImobilizado, BigDecimal patrimonioLiquido, BigDecimal capitalSocial,
			BigDecimal sobrasPerdasExercicio, BigDecimal ingressosReceitasBrutas, BigDecimal tributos,
			BigDecimal despesasPessoal, String anuarioPreenchido) {
		super();
		this.id = id;
		this.cnpj = cnpj;
		this.razaoSocial = razaoSocial;
		this.nomeFantasia = nomeFantasia;
		this.ufSigla = ufSigla;
		this.ramo = ramo;
		this.situacaoRegistro = situacaoRegistro;
		this.regularidadeCooperativa = regularidadeCooperativa;
		this.anuarioPreenchido = anuarioPreenchido;
		this.ativoTotal = ativoTotal;
		this.ativoImobilizado = ativoImobilizado;
		this.patrimonioLiquido = patrimonioLiquido;
		this.capitalSocial = capitalSocial;
		this.sobrasPerdasExercicio = sobrasPerdasExercicio;
		this.ingressosReceitasBrutas = ingressosReceitasBrutas;
		this.tributos = tributos;
		this.despesasPessoal = despesasPessoal;
	}
	
	public List<String> objectToStringArray() {
		List<String> result = null;
			result = Arrays.asList(this.cnpj != null ? cnpj.replaceAll("\\b(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5") : null, 
					this.nomeFantasia, this.ramo, this.ufSigla, NovaSituacaoCooperativaEnum.valueOf(this.situacaoRegistro).getNome(),
					this.regularidadeCooperativa != null ? RegularidadeCooperativaEnum.valueOf(this.regularidadeCooperativa.toString()).getNome() : null, 
					this.anuarioPreenchido != null ? this.anuarioPreenchido : "Não preenchido", 
					this.ativoTotal != null ? this.ativoTotal.setScale(2, RoundingMode.FLOOR).toString() : "", 
					this.ativoImobilizado != null ? this.ativoImobilizado.setScale(2, RoundingMode.FLOOR).toString() : "",
					this.patrimonioLiquido != null? this.patrimonioLiquido.setScale(2, RoundingMode.FLOOR).toString() : "",
					this.capitalSocial != null ? this.capitalSocial.setScale(2, RoundingMode.FLOOR).toString() : "", 
					this.sobrasPerdasExercicio != null? this.sobrasPerdasExercicio.setScale(2, RoundingMode.FLOOR).toString(): "",
					this.ingressosReceitasBrutas != null ? this.ingressosReceitasBrutas.setScale(2, RoundingMode.FLOOR).toString() : "",
					this.tributos != null? this.tributos.setScale(2, RoundingMode.FLOOR).toString() : "",
					this.despesasPessoal != null? this.despesasPessoal.setScale(2, RoundingMode.FLOOR).toString() : "");
		return result;
	}
}
