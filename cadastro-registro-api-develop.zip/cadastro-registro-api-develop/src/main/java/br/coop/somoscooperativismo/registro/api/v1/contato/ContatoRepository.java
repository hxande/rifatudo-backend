package br.coop.somoscooperativismo.registro.api.v1.contato;

import br.coop.somoscooperativismo.registro.api.v1.contato.entidade.Contato;
import java.util.List;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.coop.somoscooperativismo.registro.api.v1.pessoa.entidade.Pessoa;

public interface ContatoRepository extends JpaRepository<Contato, Integer>{

	@Query("Select contato from Contato contato where contato.areaContato.id = :idArea and contato.pessoa.id = :idJuridica")
	Optional<Contato> buscaPorAreaPJ(@Param("idArea") Integer idArea, @Param("idJuridica") Integer idJuridica);

	Optional<Contato> findByPessoa(Pessoa pessoa);
	
	@Query("Select contato from Contato contato where contato.pessoa.id = :idPessoa")
	List<Contato> buscaPorPessoa(@Param("idPessoa") Integer idPessoa);
	
	@Query("Select contato from Contato contato where contato.areaContato.id = :idArea and contato.pessoa.id = :idPessoa")
	List<Contato> buscaPorAreaPessoa(@Param("idArea") Integer idArea, @Param("idPessoa") Integer idPessoa);
	
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM PESSOA_CONTATO WHERE SQ_PESSOA = :idPessoa ", nativeQuery = true)
	void excluiPorAreaPessoa(@Param("idPessoa") Integer idPessoa);

	@Query("select c from Contato c inner join PessoaJuridica pj on pj.id = c.pessoa.id "
			+ "where pj.ufSigla =:uf" )
	List<Contato> buscaContatoPorUf(@Param("uf") String uf);
}
