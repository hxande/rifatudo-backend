package br.coop.somoscooperativismo.registro.api.v1.fates;

import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.envers.Audited;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Table(name = "COOPERATIVA_FATES")
@Audited
public class CooperativaFates {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_COOPERATIVA_FATES")
    private Integer id;

    @OneToOne
    @JoinColumn(name = "SQ_COOPERATIVA", nullable = false, unique = true)
    private Cooperativa cooperativa;

    @Column(name = "VL_FATES", nullable = false)
    private BigDecimal valorFates;

    @Column(name = "NR_ANO", nullable = false)
    private Integer ano;

    @OneToMany(mappedBy = "cooperativaFates", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<CooperativaFatesFinalidade> finalidades = new ArrayList<>();
}

