package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.orgaocargo.entidade.OrgaoCargo;
import br.coop.somoscooperativismo.registro.api.v1.orgaocargo.OrgaoCargoService;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/cooperativas-importacao/orgaos-cargos")
public class OrgaoCargoImportacaoRestController {

    private final OrgaoCargoService orgaoCargoService;

    @GetMapping("/orgao/{idOrgao}/ativos")
    public ResponseEntity<List<OrgaoCargo>> getByOrgaoIdAndAtivos(@PathVariable Integer idOrgao) {
        return ResponseEntity.ok(orgaoCargoService.listaPorOrgaoId(idOrgao));
    }

    @GetMapping("/ativos")
    public ResponseEntity<List<OrgaoCargo>> getAllByOrgaoAtivoTrueAndCargoAtivoTrue() {
        return ResponseEntity.ok(orgaoCargoService.getAllByOrgaoAtivoTrueAndCargoAtivoTrue());
    }

    @GetMapping("/page")
    public ResponseEntity<Page<OrgaoCargo>> getOrgaosCargos(
            @RequestParam(name = "orgao.id", required = false) Integer orgaoId,
            @RequestParam(name = "orgao.nome", required = false) String orgaoNome,
            @RequestParam(name = "cargo.id", required = false) Integer cargoId,
            @RequestParam(name = "cargo.nome", required = false) String cargoNome,
            @PageableDefault(sort = {"orgao.id", "cargo.id"}, direction = Sort.Direction.ASC) Pageable pageable) {
        return ResponseEntity.ok(orgaoCargoService.findAll(orgaoId, orgaoNome, cargoId, cargoNome, pageable));
    }
}
