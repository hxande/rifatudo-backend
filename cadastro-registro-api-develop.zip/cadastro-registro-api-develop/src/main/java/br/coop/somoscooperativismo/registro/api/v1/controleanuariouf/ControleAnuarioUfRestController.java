package br.coop.somoscooperativismo.registro.api.v1.controleanuariouf;

import br.coop.somoscooperativismo.registro.api.v1.controleanuario.entidade.ControleAnuario;
import br.coop.somoscooperativismo.registro.api.v1.controleanuariouf.entidade.ControleAnuarioUf;


import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/controle-anuario-uf")
@Tag(name = "ControleAnuarioUf")
public class ControleAnuarioUfRestController {

    private static final String DISPARO_EMAIL_ATUALIZADO = "controleAnuario.atualizado";

    private final ControleAnuarioUfService controleAnuarioUfService;

    private final MessagesService messages;

    public ControleAnuarioUfRestController(ControleAnuarioUfService controleAnuarioUfService, MessagesService messages) {
        this.controleAnuarioUfService = controleAnuarioUfService;
        this.messages = messages;
    }

    @Operation(summary = "Detalha o controle de anuario por chave de anuario para a uf", description = "Uma chave de anuario válida deve ser informado")
    @GetMapping("/{uf}")
    public ResponseEntity<ServiceResponse<ControleAnuarioUf>> getControleAnuarioUf( @PathVariable String uf) {
        return ResponseEntity.ok(new ServiceResponse<>(controleAnuarioUfService.findByUf(uf)));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Altera o controle do anuario")
    public ResponseEntity<ServiceResponse<ControleAnuarioUf>> updateControleAnuario(@PathVariable Integer id, @RequestBody @Valid ControleAnuarioUf controleAnuarioUf) {
        ServiceMessage message = new ServiceMessage(messages.get(DISPARO_EMAIL_ATUALIZADO));
        return new ResponseEntity<>(new ServiceResponse<>(controleAnuarioUfService.updateControleAnuarioUf(id, controleAnuarioUf), message), HttpStatus.OK);
    }
    
	@PostMapping
	@Operation(summary = "Salva o controle do anuario por UF")
	public ResponseEntity<ServiceResponse<ControleAnuarioUf>> salvarControleAnuarioUf(
			@RequestBody @Valid ControleAnuarioUf controleAnuarioUf) {
		ServiceMessage message = new ServiceMessage("Registro atualizado com sucesso");
		return new ResponseEntity<>(
				new ServiceResponse<>(controleAnuarioUfService.salvar(controleAnuarioUf), message),
				HttpStatus.OK);
	}
	
	@Operation(summary = "Obter controle do anuário por UF Nacional")
	@GetMapping("/obter-controle-nacional")
	public ResponseEntity<ServiceResponse<ControleAnuarioUf>> obterControleAtualizacaoCadastralNacional() {
		return ResponseEntity.ok(new ServiceResponse<>(controleAnuarioUfService.obterControleNacional()));
	}
	
	@Operation(summary = "Obter controle do anuário por UF")
	@GetMapping("/obter-por-uf/{uf}")
	public ResponseEntity<ServiceResponse<ControleAnuarioUf>> obterControleAtualizacaoCadastralPorUf(
			@PathVariable String uf) {
		return ResponseEntity.ok(new ServiceResponse<>(controleAnuarioUfService.buscarControleExistente(uf)));
	}
	
	@PostMapping("/atualizar-controle-anuario-uf")
	@Operation(summary = "Altera o controle do anuário das UF")
	public ResponseEntity<ServiceResponse<Void>> desabilitaControleAtualizacaoCadastral(@RequestBody boolean ativa){
		controleAnuarioUfService.desabilitarControleAtualizacaoCadastral(ativa);
		ServiceMessage message = new ServiceMessage("Controles do anuário atualizados com sucesso");
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}
}
