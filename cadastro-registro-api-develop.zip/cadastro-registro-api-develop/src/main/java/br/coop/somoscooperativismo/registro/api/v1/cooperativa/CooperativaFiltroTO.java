package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class CooperativaFiltroTO {

	private String processo;
	private String cnpj;
	private String nomeFantasia;
	private String ramo;
	private Integer[] ramos;
	private String dataAberturaProcesso;
	private String dataUltimaSubmissao;
	private String nomeUsuario;
	private String telefoneUsuario;
	private String pesquisaLivre;
	private String progressoMacro;
	private String[] progressosMacros;
	private String progressoMicro;
	private String situacaoCooperativa;
	private String uf;
	private String numeroRegistroOCB;
	private Boolean arquivado;
	private String[] cnpjResponsavel;
	private Boolean processoTransferencia;
	private String ufDestino;
    private CooperativaStatusManutencaoEnum cooperativaStatusManutencao;
    private AnuarioEnum anuario;
    private Boolean naoVisualizada;

	private Boolean apontamento;
    private Integer idCooperativa;
    private Date dataAtualizacao;
    private Boolean solicitacaoInativacao;
    private Boolean solicitacaoAtivacao;
    private Boolean solicitacaoCancelamento;
    private Integer idSegmento;
	private String prazoRegistro;
	
}
