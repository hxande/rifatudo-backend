package br.coop.somoscooperativismo.registro.api.v1.fates;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CooperativaFatesFinalidadeRepository extends JpaRepository<CooperativaFatesFinalidade, Integer> {
}
