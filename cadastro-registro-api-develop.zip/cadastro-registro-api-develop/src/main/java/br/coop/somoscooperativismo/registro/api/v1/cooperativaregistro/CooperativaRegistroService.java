package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro;

import br.coop.somoscooperativismo.api.v1.relatorio.RelatorioClient;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioExpressTO;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.CooperativaRegistroComentarioMotivoRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.CooperativaRegistroComentarioService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.CooperativaRegistroComentarioTO;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.CooperativaRegistroComentarioUtil;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentario;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentarioMotivo;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.entidade.Situacao;
import jakarta.validation.Valid;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CooperativaRegistroService {

	public static final String NAO_ENCONTRADO = "cooperativaRegistro.naoEncontrado";

	@Autowired
	CooperativaRegistroRepository cooperativaRegistroRepository;

	@Autowired
	private MessagesService messages;

	@Autowired
	private KeycloakService keycloakService;
	
	
    @Autowired
	private RelatorioClient relatorioClient;

	@Autowired
	private CooperativaRegistroComentarioService cooperativaRegistroComentarioService;
    
    @Autowired
    CooperativaRepository cooperativaRepository;

	@Autowired
	CooperativaRegistroComentarioMotivoRepository cooperativaRegistroComentarioMotivoRepository;

    public void save(CooperativaRegistro cr) {
		cooperativaRegistroRepository.save(cr);
	}
	
	public List<CooperativaRegistro> getCooperativaRegistros() {
		return cooperativaRegistroRepository.findAll();
	}

	public CooperativaRegistro getCooperativaRegistro(Integer id) {
		Optional<CooperativaRegistro> cooperativaRegistro = cooperativaRegistroRepository.findById(id);
		if(cooperativaRegistro.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO) + id, HttpStatus.NOT_FOUND);
		}
		return cooperativaRegistro.get();
	}
	
	public CooperativaRegistro getCooperativaRegistroByIdCooperativa(Integer idCooperativa) {
		return cooperativaRegistroRepository.findTop1ByCooperativaId(idCooperativa);
	}

	public @Valid CooperativaRegistro createCooperativaRegistro(@Valid CooperativaRegistro cooperativaRegistro) {
		return cooperativaRegistroRepository.save(cooperativaRegistro);
	}

	public CooperativaRegistro updateCooperativaRegistro(@Valid CooperativaRegistro cooperativaRegistro) {
		Optional<CooperativaRegistro> op = cooperativaRegistroRepository.findById(cooperativaRegistro.getId());
		if(op.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
		}

		op = null;

		return cooperativaRegistroRepository.save(cooperativaRegistro);
	}

	public void desativaCooperativaRegistro(Integer id) {
		Optional<CooperativaRegistro> op = cooperativaRegistroRepository.findById(id);
		if(op.isEmpty()) {
			throw new RegraNegocioException(messages.get(NAO_ENCONTRADO), HttpStatus.NOT_FOUND);
		}
		CooperativaRegistro cooperativaRegistro = op.get();
		cooperativaRegistroRepository.save(cooperativaRegistro);
	}
		

	/**
	 * @description Retorna o último registro da tabela COOPERATIVA_REGISTRO pelo id da cooperativa
	 * @param idCooperativa
	 * @return
	 */
	public CooperativaRegistro getUltimoRegistroAtivo(Integer idCooperativa) {
		return cooperativaRegistroRepository.findByCooperativaIdAndUltimoRegistroTrue(idCooperativa); 
	}
	
	/**
	 * @description gera um linha de histórico da cooperativa que possui anexo
	 * @param cooperativa
	 * @param situacaoAnterior
	 */
	public void criaHistoricoCooperativa(Cooperativa cooperativa, CooperativaRegistro registro, Situacao situacaoAnterior) {
		if(ValidacaoCampos.validaCampoPreenchido(cooperativa)) {
			try {
				CooperativaRegistro cr = new CooperativaRegistro();
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getId())) {
					cr.setCooperativa(cooperativa);					
				}
				cr.setDtAlteracao(LocalDate.now().toDate());
				
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaSolicitacaoInativacao())) {
					cr.setJustificativaSolicitacaoInativacao(cooperativa.getJustificativaSolicitacaoInativacao());					
				}
				
				if(ValidacaoCampos.validaCampoPreenchido(keycloakService.getUsername())) {
					cr.setLoginAlteracaoSituacao(keycloakService.getUsername());					
				}
				
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getSituacaoCooperativa())) {
					cr.setSituacao(cooperativa.getSituacaoCooperativa());
					if(situacaoAnterior != null) {
						cr.setSituacaoCooperativa(situacaoAnterior.getNome());
					}
				}

				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoInativacao())) {
					cr.setSolicitacaoInativacao(cooperativa.getSolicitacaoInativacao());					
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaInativada())) {
					cr.setJustificativaInativada(cooperativa.getJustificativaInativada()); 					
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaIrregular())) {
					cr.setJustificativaIrregular(cooperativa.getJustificativaIrregular()); 					
				}	
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaCancelada())) {
					cr.setJustificativaCancelada(cooperativa.getJustificativaCancelada()); 					
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoCancelamento())) {
					cr.setSolicitacaoCancelamento(cooperativa.getSolicitacaoCancelamento());					
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaSolicitacaoCancelamento())) {
					cr.setJustificativaSolicitacaoCancelamento(cooperativa.getJustificativaSolicitacaoCancelamento());					
				}
				if(ValidacaoCampos.validaCampoPreenchido(registro.getTipoAcao())) {
					cr.setTipoAcao(registro.getTipoAcao());
				}
				if(ValidacaoCampos.validaCampoPreenchido(registro.getAnexo())) {
					cr.setAnexo(registro.getAnexo());	
				}
				if(ValidacaoCampos.validaCampoPreenchido(registro.getAnexoNotificacao())) {
					cr.setAnexoNotificacao(registro.getAnexoNotificacao());
				}
				if(ValidacaoCampos.validaCampoPreenchido(registro.getAnexoProvaOrgaos())) {
					cr.setAnexoProvaOrgaos(registro.getAnexoProvaOrgaos());
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaAtivacao())) {
					cr.setJustificativaAtivacao(cooperativa.getJustificativaAtivacao());					
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getSolicitacaoAtivacao())) {
					cr.setSolicitacaoAtivacao(cooperativa.getSolicitacaoAtivacao());					
				}
				if(ValidacaoCampos.validaCampoPreenchido(registro.getCooperativaSolicitacao())) {
					cr.setCooperativaSolicitacao(registro.getCooperativaSolicitacao());					
				}
				if(ValidacaoCampos.validaCampoPreenchido(cooperativa.getJustificativaSolicitacaoAtivacao())) {
					cr.setJustificativaSolicitacaoAtivacao(cooperativa.getJustificativaSolicitacaoAtivacao());					
				}

				CooperativaRegistro ultimo = buscaUltimoHistorico(cooperativa.getId());

				if(ValidacaoCampos.validaCampoPreenchido(ultimo) 
				&& registro.getTipoAcao() != null && !registro.getTipoAcao().equals(TipoAcaoEnum.UE_CANCELA_SOLICITACAO_SUSPENSAO)){
					cr.setRegistroEmail(ultimo.getRegistroEmail());
				}

				if(ValidacaoCampos.validaCampoPreenchido(registro.getRegistroEmail())){
					cr.setRegistroEmail(registro.getRegistroEmail());
				}
				
				cooperativaRegistroRepository.save(cr);				
			} catch (Exception e) {
				throw new RegraNegocioException(e.getMessage(), e);
			}

		}
	}
	
	public CooperativaRegistro buscaHistoricoInativacao(Integer idCooperativa) {
		if(idCooperativa != null) {
			Integer idSitucao = 2; // Inativa
			Pageable pageable = PageRequest.of(0,1);
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.getUltimoHistoricoInativacao(idCooperativa,idSitucao,pageable);
			if(!cr.isEmpty()) {
				return cr.get(0);
			}
		}
		return null;
	}
	
	
	
	public CooperativaRegistro buscaHistoricoSolicitacaoInativacao(Integer idCooperativa) {
		if(idCooperativa != null) {
			Integer idSitucao = 1; // Inativa
			return cooperativaRegistroRepository.
					findTop1ByCooperativaIdAndSituacaoIdAndSolicitacaoInativacaoTrueOrderByIdDesc(idCooperativa,idSitucao);
		}
		return null;
	}
		
	
	public CooperativaRegistro buscaHistoricoApontamentoIrregularidade(Integer idCooperativa) {
		if(idCooperativa != null) {
			Integer idSitucao = 1; // Inativa
			Pageable pageable = PageRequest.of(0,1);
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.
					getUltimoHistoricoApontamentoIrregularidadeSolicitacaoInativacao(idCooperativa, idSitucao,pageable);
			if(!cr.isEmpty()) {
				return cr.get(0);	
			}
		}
		return null;
	}
	
	
	
	public CooperativaRegistro buscaUltimoHistoricoCancelamento(Integer idCooperativa) {
		if(idCooperativa != null) {
			Integer idSitucao = 3; // Inativa
			Pageable pageable = PageRequest.of(0,1);
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.getUltimoHistoricoCancelamento(idCooperativa, idSitucao, pageable);
			if(!cr.isEmpty()) {
				return cr.get(0);
			}
		}
		return null;
	}
	
	public CooperativaRegistro buscaUltimoHistoricoSolicitacaoCancelamento(Integer idCooperativa) {
		if(idCooperativa != null) {
			Cooperativa cooperativa = cooperativaRepository.getCooperativaPeloId(idCooperativa);
			Pageable pageable = PageRequest.of(0,1);
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.buscaUltimoHistoricoSolicitacaoCancelamento(idCooperativa, cooperativa.getSituacaoCooperativa().getId(), Boolean.TRUE, pageable);
			if(!cr.isEmpty()) {
				return cr.get(0);
			}
		}
		return null;
	}

	public CooperativaRegistro buscaUltimoHistoricoSolicitacaoAtivacao(Integer idCooperativa) {
		if(idCooperativa != null) {
			Cooperativa cooperativa = cooperativaRepository.getCooperativaPeloId(idCooperativa);
			Pageable pageable = PageRequest.of(0,1);
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.
					getUltimoHistoricoSolicitacaoAtivacao(idCooperativa, cooperativa.getSituacaoCooperativa().getId(),Boolean.TRUE, pageable);
			if(!cr.isEmpty()) {
				return cr.get(0);	
			}
		}
		return null;
	}
	
	public CooperativaRegistro buscaUltimoHistoricoSolicitacaoInativacao(Integer idCooperativa) {
		if(idCooperativa != null) {
			Pageable pageable = PageRequest.of(0,1);
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.
				buscaUltimoHistoricoSolicitacaoInativacao(idCooperativa, 5,pageable);
			if(!cr.isEmpty()) {
				return cr.get(0);	
			}
		}
		return null;
	}

	public CooperativaRegistro buscaUltimoHistorico(Integer idCooperativa) {
		if(idCooperativa != null) {
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.
			buscaHistoricoCooperativa(idCooperativa);
			if(!cr.isEmpty()) {
				return cr.get(0);	
			}
		}
		return null;
	
	}


	
	public List<CooperativaRegistro> buscaHistoricoSituacaoCooperativa(Integer idCooperativa) {
		if(idCooperativa != null) {
			List<CooperativaRegistro> cr = cooperativaRegistroRepository.buscaHistoricoSituacaoCooperativa(idCooperativa);			
			if(!cr.isEmpty()) {
				return cr;
			}
		}
		return null;
	}

	public List<HistoricoCooperativaRegistroListagemTO> buscaHistoricoCooperativaRegistroListagem(Integer idCooperativa) {
		List<CooperativaRegistro> cr = cooperativaRegistroRepository.buscaHistoricoCooperativa(idCooperativa);
		List<HistoricoCooperativaRegistroListagemTO> listaH = new ArrayList<>();

		for (CooperativaRegistro registro : cr) {
			List<CooperativaRegistroComentario> subHistorico = cooperativaRegistroComentarioService.findAllByCooperativaRegistroId(registro.getId());
			HistoricoCooperativaRegistroListagemTO hcrListagemTO = HistoricoCooperativaRegistroUtil.getHistoricoCooperativaRegistroListagemTO(registro);

			if(subHistorico != null) {
				List<CooperativaRegistroComentarioTO> subHistoricoTO = subHistorico.stream()
						.map(comentario -> {
							List<Long> motivoIds = cooperativaRegistroComentarioMotivoRepository.findByCooperativaRegistroComentario(comentario)
									.stream()
									.map(CooperativaRegistroComentarioMotivo::getMotivo)
									.filter(Objects::nonNull)
									.collect(Collectors.toList());
							return CooperativaRegistroComentarioUtil.toDTO(comentario, motivoIds);
						})
						.collect(Collectors.toList());
				hcrListagemTO.setSubHistorico(subHistoricoTO);
			}
			listaH.add(hcrListagemTO);

		}

		return listaH;
	}


	public byte[] buscaHistoricoCooperativaRegistroListagemRelatorioXls(Integer id) {
		List<HistoricoCooperativaRegistroListagemTO> listaHis = buscaHistoricoCooperativaRegistroListagem(id);
		byte[] file = null;
		
		if (listaHis.isEmpty()) {
    		throw new RegraNegocioException("Não há registros para serem exportados.", HttpStatus.NOT_FOUND);
    	}
		
    	List<String> cabecalho = null;
		List<List<String>> linhas = new ArrayList<>();
		List<Integer> larguras = null;
		
		cabecalho = Arrays.asList(
				"UF",
				"CNPJ", 
				"Razão Social",
				"Nome Fantasia",
				"Ramo", 
				"Ação",
				"Data alteração", 
				"Situação",
				"Regularidade",
				"Nova situação",
				"Motivo",
				"Complemento do Motivo",
				"Justificativa UE",
				"Justificativa UN");
		larguras = Arrays.asList(20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20);
		for(HistoricoCooperativaRegistroListagemTO his : listaHis){
			linhas.add(his.objectToListString());
		}
		//listaHis.forEach(obj -> linhas.add(obj.objectToListString()));
		if (!linhas.isEmpty()) {
			try {
				RelatorioExpressTO relatorio = new RelatorioExpressTO();
				relatorio.setCabecalho(cabecalho);
				relatorio.setDados(linhas);
				relatorio.setLarguras(larguras);
				file = relatorioClient.gerarRelatorio(relatorio);
			} catch (Exception e) {
				throw new ErroSistemaException(messages.get(e.getMessage()), e);
			}
		}

    	return file;
	}

	public List<CooperativaRegistro> buscaNotificacoesAEnviarEmail(String data){
		return cooperativaRegistroRepository.buscaRegistrosNotificacaoAEnviar(data);
	}

	public List<CooperativaRegistro> buscaHistoricoCooperativa(Integer idCooperativa) {
		return cooperativaRegistroRepository.buscaHistoricoCooperativa(idCooperativa);
	}
}
