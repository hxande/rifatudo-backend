package br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral;

import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.entidade.ControleAtualizacaoCadastral;
import br.coop.somoscooperativismo.registro.api.v1.controleatualizacaocadastral.to.ControleAtualizacaoCadastralTO;


@Service
public class ControleAtualizacaoCadastralServiceImpl implements ControleAtualizacaoCadastralService {
	
	private final ControleAtualizacaoCadastralRepository controleAtualizacaoCadastralRepository;
	private final KeycloakService keycloakService;

	
	
	public ControleAtualizacaoCadastralServiceImpl(
			ControleAtualizacaoCadastralRepository controleAtualizacaoCadastralRepository,
			KeycloakService keycloakService) {
		this.controleAtualizacaoCadastralRepository = controleAtualizacaoCadastralRepository;
		this.keycloakService = keycloakService;
	}

	@Override
	public ControleAtualizacaoCadastralTO salvar(ControleAtualizacaoCadastralTO controleAtualizacaoCadastralTO) {
		if(keycloakService.isTipoEntidadeEstadual()) {
			controleAtualizacaoCadastralTO.setUf(keycloakService.getUFUsuario());
		}
		ControleAtualizacaoCadastral controleAtualizacaoCadastral = new ControleAtualizacaoCadastral();
		BeanUtils.copyProperties(controleAtualizacaoCadastralTO,controleAtualizacaoCadastral);
		controleAtualizacaoCadastralRepository.save(controleAtualizacaoCadastral);
		return converterEntidade(controleAtualizacaoCadastral);
	}

	@Override
	public ControleAtualizacaoCadastralTO obterPorUf(String uf) {
		uf = "null".equals(uf) ? null : uf;
		if(keycloakService.isTipoEntidadeEstadual()) {
			uf = keycloakService.getUFUsuario();
		}
		ControleAtualizacaoCadastral controleAtualizacaoCadastral = controleAtualizacaoCadastralRepository.findByUf(uf);
		return converterEntidade(controleAtualizacaoCadastral);
	}
	
	@Override
	public ControleAtualizacaoCadastralTO buscarControleExistente(String uf) {
		List<ControleAtualizacaoCadastral> listControleAtualizacaoCadastral = controleAtualizacaoCadastralRepository.findAllByUf(uf);
		final String ufFinal = uf;
		Predicate<ControleAtualizacaoCadastral> filtroUf = cac -> Objects.equals(ufFinal,cac.getUf());
		ControleAtualizacaoCadastral controleAtualizacaoCadastral = listControleAtualizacaoCadastral.stream()
				.filter(filtroUf).findAny().orElse(listControleAtualizacaoCadastral.get(0));

		filtroUf = null;

		return  converterEntidade(controleAtualizacaoCadastral);
	}
	
	@Override
	public void desabilitarControleAtualizacaoCadastral(boolean ativa) {
		if(!keycloakService.isTipoEntidadeNacional()) {
			throw new RegraNegocioException("Usuário sem permissão para esta operação");
		}
		List<ControleAtualizacaoCadastral> listControleAtualizacaoCadastral = controleAtualizacaoCadastralRepository.findAll();		
		listControleAtualizacaoCadastral.forEach(controleAtualizacaoCadastral -> {
			habilitaDesabilitaControleAtualizacaoCadastral(controleAtualizacaoCadastral,ativa);
			
		});
		controleAtualizacaoCadastralRepository.saveAll(listControleAtualizacaoCadastral);
	}
	
	private void habilitaDesabilitaControleAtualizacaoCadastral(ControleAtualizacaoCadastral controleAtualizacaoCadastral, boolean ativa) {
		if(ativa) {
			controleAtualizacaoCadastral.setPermiteEstadualPreencher(Boolean.TRUE);
		} else {
			controleAtualizacaoCadastral.setDestacarAtualizacaoCadastral(Boolean.FALSE);
			controleAtualizacaoCadastral.setPermiteCooperativaPreencher(Boolean.FALSE);
			controleAtualizacaoCadastral.setPermiteCooperativaVisualizar(Boolean.TRUE);
			controleAtualizacaoCadastral.setPermiteEstadualPreencher(Boolean.FALSE);
			controleAtualizacaoCadastral.setVisualizarPeriodoAtualizacao(Boolean.FALSE);
			controleAtualizacaoCadastral.setMostrarPopup(Boolean.FALSE);
			controleAtualizacaoCadastral.setTextoPopup(null);
		}
	}
	
	private ControleAtualizacaoCadastralTO converterEntidade(ControleAtualizacaoCadastral controleAtualizacaoCadastral) {
		ControleAtualizacaoCadastralTO controleAtualizacaoCadastralTO = new ControleAtualizacaoCadastralTO();
		if(ValidacaoCampos.validaCampoPreenchido(controleAtualizacaoCadastral)) {
			BeanUtils.copyProperties(controleAtualizacaoCadastral, controleAtualizacaoCadastralTO);
		}
		return controleAtualizacaoCadastralTO;
	}

	@Override
	public ControleAtualizacaoCadastralTO obterControleNacional() {
		return converterEntidade(controleAtualizacaoCadastralRepository.findByUf(null));
	}

}
