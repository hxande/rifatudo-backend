package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistro.entidade.CooperativaRegistro;
import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@RestController
@RequestMapping("/api/v1/cooperativa-registro")
@Tag(name = "CooperativaRegistro")
public class CooperativaRegistroRestController {

	public static final String CATEGORIA_CRIADA = "cooperativaRegistro.criada";
	public static final String NAO_CORRESPONDE = "cooperativaRegistro.naoCorresponde";
	public static final String CATEGORIA_ATUALIZADA = "cooperativaRegistro.atualizada";
	public static final String CATEGORIA_DESATIVADA = "cooperativaRegistro.desativada";
	
	public static final String MEDIA_TYPE_EXCEL = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String ATTACHMENT_EXCEL = "attachment; filename=Relatório.xlsx";
	public static final String CACHE_CTRL_PARAM = "no-cache, no-store, must-revalidate";
	public static final String NO_CACHE = "no-cache";
	
	@Autowired
	private CooperativaRegistroService cooperativaRegistroService;
	
	@Autowired
	private MessagesService messages;

	@Operation(summary = "Detalha uma cooperativaRegistro pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> getCooperativaRegistro(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.getCooperativaRegistro(id)));
	}
	
	@PostMapping
	@Operation(summary = "Cria uma cooperativaRegistro")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> createCooperativaRegistro(@RequestBody @Valid CooperativaRegistro cooperativaRegistro){
		cooperativaRegistro = cooperativaRegistroService.createCooperativaRegistro(cooperativaRegistro);
		HttpHeaders headers = new HttpHeaders();
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(cooperativaRegistro.getId()).toUri();
		headers.setLocation(location);

		location = null;

		ServiceMessage message = new ServiceMessage(messages.get(CATEGORIA_CRIADA));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaRegistro, message), headers, HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	@Operation(summary = "Altera uma cooperativaRegistro")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> updateCooperativaRegistro(@PathVariable Integer id, @RequestBody @Valid CooperativaRegistro cooperativaRegistro){
		if(!cooperativaRegistro.getId().equals(id)) {
			return new ResponseEntity<>(new ServiceResponse<>(null,new ServiceMessage(MessageType.ERROR, "URL ID: '" + id+" " + messages.get(NAO_CORRESPONDE) + cooperativaRegistro.getId() + "'.")), HttpStatus.BAD_REQUEST);
		}
		ServiceMessage message = new ServiceMessage(messages.get(CATEGORIA_ATUALIZADA));
		return new ResponseEntity<>(new ServiceResponse<>(cooperativaRegistroService.updateCooperativaRegistro(cooperativaRegistro), message), HttpStatus.OK);
				
	}
	@GetMapping
	@Operation(summary = "Lista")
	public ServiceResponse<List<CooperativaRegistro>> getCooperativaRegistros() {
		return new ServiceResponse<>(cooperativaRegistroService.getCooperativaRegistros());
	}
	
	@DeleteMapping("/{id}")
	@Operation(summary = "Desativa uma cooperativaRegistro", description = "Um ID válido deve ser informado")
	public ResponseEntity<ServiceResponse<Void>> desativaCooperativaRegistro(@PathVariable Integer id) {
		cooperativaRegistroService.desativaCooperativaRegistro(id);
		ServiceMessage message = new ServiceMessage(messages.get(CATEGORIA_DESATIVADA));
		return new ResponseEntity<>(new ServiceResponse<>(message), HttpStatus.OK);
	}

	@Operation(summary = "Detalha o último Cooperativa Registro pela Cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoCooperativaRegistroPelaCooperativa/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoCooperativaRegistroPelaCooperativa(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.getUltimoRegistroAtivo(id)));
	}
	
	@Operation(summary = "Detalha o último registro de inativação da cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoHistoricoInativacao/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoHistoricoInativacao(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaHistoricoInativacao(id)));
	}
	
	
	@Operation(summary = "Detalha o último registro de apontamento de irregularidade de uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoHistoricoApontamento/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoHistoricoApontamento(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaHistoricoApontamentoIrregularidade(id)));
	}
	
	
	
	@Operation(summary = "Detalha o último registro de apontamento de irregularidade de uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoHistoricoCancelamento/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoHistoricoCancelamento(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaUltimoHistoricoCancelamento(id)));
	}
	
	@Operation(summary = "Detalha o último registro de solicitacao de cancelamento de uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoHistoricoSolicitacaoCancelamento/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoHistoricoSolicitacaoCancelamento(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaUltimoHistoricoSolicitacaoCancelamento(id)));
	}
	
	@Operation(summary = "Detalha o último registro de apontamento de irregularidade de uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoHistoricoSolicitacaoAtivacao/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoHistoricoSolicitacaoAtivacao(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaUltimoHistoricoSolicitacaoAtivacao(id)));
	}
	
	
	@Operation(summary = "Detalha o último registro de solicitação de inativação de uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaUltimoHistoricoSolicitacaoInativacao/{id}")
	public ResponseEntity<ServiceResponse<CooperativaRegistro>> buscaUltimoHistoricoSolicitacaoInativacao(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaUltimoHistoricoSolicitacaoInativacao(id)));
	}
	
	@Operation(summary = "Detalha o historico de situações uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaHistoricoSituacaoCooperativa/{id}")
	public ResponseEntity<ServiceResponse<List<CooperativaRegistro>>> buscaHistoricoSituacaoCooperativa(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaHistoricoSituacaoCooperativa(id)));
	}
	
	
	@Operation(summary = "Detalha o historico de situações uma cooperativa", description = "Um ID válido deve ser informado")
	@GetMapping("buscaHistoricoCooperativaRegistroListagem/{id}")
	public ResponseEntity<ServiceResponse<List<HistoricoCooperativaRegistroListagemTO>>> buscaHistoricoCooperativaRegistroListagem(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(cooperativaRegistroService.buscaHistoricoCooperativaRegistroListagem(id)));
	}
	
	
	@GetMapping("/exportaHistoricoRegistro/{id}")
	@Operation(summary = "Retorna Excel com o histórico de registro da cooperativa")
	public ResponseEntity<Resource> filtraFilialNaoPaginado(@PathVariable Integer id) {
		byte[] dados = cooperativaRegistroService.buscaHistoricoCooperativaRegistroListagemRelatorioXls(id);
		
		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_EXCEL);
		header.add(HttpHeaders.CACHE_CONTROL, CACHE_CTRL_PARAM);
		header.add(HttpHeaders.PRAGMA, NO_CACHE);
		header.add(HttpHeaders.EXPIRES, "0");
		
			return ResponseEntity.ok().headers(header)
					.contentLength(!ArrayUtils.isEmpty(dados) ? dados.length : 0)
					.contentType(MediaType.parseMediaType(MEDIA_TYPE_EXCEL))
					.body(!ArrayUtils.isEmpty(dados) ? new ByteArrayResource(dados) : null);			
		}
	
}
