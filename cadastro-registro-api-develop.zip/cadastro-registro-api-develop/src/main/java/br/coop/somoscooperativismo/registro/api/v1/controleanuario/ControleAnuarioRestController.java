package br.coop.somoscooperativismo.registro.api.v1.controleanuario;

import br.coop.somoscooperativismo.registro.api.v1.controleanuario.entidade.ControleAnuario;
import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/controle-anuario")
@Tag(name = "ControleAnuario")
public class ControleAnuarioRestController {

    private static final String CONTROLE_ANUARIO_ATUALIZADO = "controleAnuario.atualizado";

    private final ControleAnuarioService controleAnuarioService;

    private final MessagesService messages;

    public ControleAnuarioRestController(ControleAnuarioService controleAnuarioService, MessagesService messages) {
        this.controleAnuarioService = controleAnuarioService;
        this.messages = messages;
    }

    @Operation(summary = "Detalha o controle de anuario por chave de anuario", description = "Uma chave de anuario válida deve ser informado")
    @GetMapping("/{chaveAnuario}")
    public ResponseEntity<ServiceResponse<ControleAnuario>> getControleAnuario(@PathVariable String chaveAnuario) {
        return ResponseEntity.ok(new ServiceResponse<>(controleAnuarioService.findByChaveAnuario(chaveAnuario)));
    }

    @PutMapping("")
    @Operation(summary = "Altera o controle do anuáiro")
    public ResponseEntity<ServiceResponse<ControleAnuario>> updateControleAnuario(@RequestBody @Valid ControleAnuario controleAnuario) {
        ServiceMessage message = new ServiceMessage(messages.get(CONTROLE_ANUARIO_ATUALIZADO));
        return new ResponseEntity<>(new ServiceResponse<>(controleAnuarioService.updateControleAnuario(controleAnuario), message), HttpStatus.OK);
    }
}
