package br.coop.somoscooperativismo.registro.api.v1.governanca;

import br.coop.somoscooperativismo.registro.api.v1.governanca.to.GovernancaTO;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.MandatoTO;
import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.governanca.to.AcaoGovernancaTO;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.IntegracaoGdhRetornoTO;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.IntegracaoGdhTO;
import br.coop.somoscooperativismo.registro.api.v1.governanca.to.PendenciasGovernancaTO;
import br.coop.somoscooperativismo.registro.api.v1.mandatoacao.UltimaAcaoGovernancaService;
import br.coop.somoscooperativismo.registro.api.v1.mandatomembro.entidade.MandatoMembro;
import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/governanca")
@Tag(name = "GovernancaTO")
public class GovernancaRestController {
	
	private final MessagesService messages;

	private final GovernancaService governancaService;

	private final UltimaAcaoGovernancaService ultimaAcaoGovernancaService;

	public GovernancaRestController(MessagesService messages, GovernancaService governancaService,
			UltimaAcaoGovernancaService ultimaAcaoGovernancaService) {
		this.messages = messages;
		this.governancaService = governancaService;
		this.ultimaAcaoGovernancaService = ultimaAcaoGovernancaService;
	}

	// Os endpoints de salvar-da-aba (POST /{idCooperativa} e
	// POST /cria-governanca/{idCooperativa}) foram REMOVIDOS — a gravação é
	// exclusivamente por conselho (salvarPorConselho/incluirMembroPorConselho).

	@GetMapping("/validarGovernanca/{id}")
	@Operation(summary = "Validando Dados Gerais do Primeiro Registro")
	public ResponseEntity<ServiceResponse<ValidacaoPrimeiroRegistroTO>> validarGovernanca(@PathVariable Integer id){
		return new ResponseEntity<>(new ServiceResponse<>(governancaService.validarGovernancaESincronizarAba(id)), HttpStatus.OK);
				
	}
	
	@GetMapping("/buscaPorCooperativa/{idCooperativa}")
	@Operation(summary = "Busca lista de governança por id da cooperativa")
	public ResponseEntity<ServiceResponse<List<GovernancaTO>>> buscaPorCooperativa(@PathVariable Integer idCooperativa){
		return new ResponseEntity<>(new ServiceResponse<>(governancaService.buscaPorCooperativa(idCooperativa)), HttpStatus.OK);
	}

	@PostMapping("/{idCooperativa}/conselho/{idOrgao}")
	@Operation(summary = "Salvar-por-conselho: grava apenas o órgão informado, com isolamento por conselho")
	public ResponseEntity<ServiceResponse<MandatoTO>> salvarPorConselho(@PathVariable Integer idCooperativa, @PathVariable Integer idOrgao, @RequestParam(name = "manutencao", defaultValue = "false") boolean manutencao, @RequestBody @Valid MandatoTO mandato){
		MandatoTO salvo = governancaService.salvarPorConselho(idCooperativa, idOrgao, mandato, manutencao);
		return new ResponseEntity<>(new ServiceResponse<>(salvo), HttpStatus.OK);
	}

	@PostMapping("/{idCooperativa}/conselho/{idOrgao}/membro")
	@Operation(summary = "Inclusão inline de membro: adiciona um membro ao conselho preservando os demais")
	public ResponseEntity<ServiceResponse<MandatoTO>> incluirMembroPorConselho(@PathVariable Integer idCooperativa, @PathVariable Integer idOrgao, @RequestParam(name = "manutencao", defaultValue = "false") boolean manutencao, @RequestBody @Valid MandatoMembro membro){
		MandatoTO salvo = governancaService.incluirMembroPorConselho(idCooperativa, idOrgao, membro, manutencao);
		return new ResponseEntity<>(new ServiceResponse<>(salvo), HttpStatus.OK);
	}

    @PostMapping("/membro-ativo/consulta")
    @Operation(summary = "Busca dados dos beneficiarios da integração com GDH")
    public ResponseEntity<ServiceResponse<List<IntegracaoGdhRetornoTO>>> buscaDadosBeneficiariosIntegracaoGdh(@RequestBody @Valid IntegracaoGdhTO integracaoGdh) {
        return new ResponseEntity<>(new ServiceResponse<>(governancaService.buscaDadosBeneficiariosIntegracaoGdh(integracaoGdh)), HttpStatus.OK);
    }

    @GetMapping("/{idCooperativa}/pendencias")
    @Operation(summary = "Pendências de governança por conselho + flag agregada \"pode avançar\"")
    public ResponseEntity<ServiceResponse<PendenciasGovernancaTO>> obterPendencias(@PathVariable Integer idCooperativa) {
        return new ResponseEntity<>(new ServiceResponse<>(governancaService.obterPendenciasGovernanca(idCooperativa)), HttpStatus.OK);
    }

    @GetMapping("/{idCooperativa}/conselho/{idOrgao}/trilha-acoes")
    @Operation(summary = "Trilha completa de ações do conselho (auditoria) — restrita à unidade Nacional")
    public ResponseEntity<ServiceResponse<List<AcaoGovernancaTO>>> trilhaAcoes(@PathVariable Integer idCooperativa,
            @PathVariable Integer idOrgao) {
        return new ResponseEntity<>(
                new ServiceResponse<>(ultimaAcaoGovernancaService.listarTrilhaConselho(idCooperativa, idOrgao)),
                HttpStatus.OK);
    }
}
