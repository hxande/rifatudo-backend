package br.coop.somoscooperativismo.registro.api.v1.cooperativasImportacao.to;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SituacaoImportacaoTO implements Serializable {
    private Integer id;
    private String nome;
    private Boolean ativo;
}
