package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.builder;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaCampos;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.AbaDataInterface;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;

import java.util.ArrayList;
import java.util.List;

public class AbaBuilder {

    private final AbaDataInterface aba;

    public AbaBuilder(String id, String name, Integer idQuadro, Integer idQuadroAuxiliar, String title) {
        aba = new AbaDataInterface();
        aba.setId(id);
        aba.setIdQuadro(idQuadro);
        aba.setIdQuadroAuxiliar(idQuadroAuxiliar);
        aba.setName(name);
        aba.setTitle(title);
        aba.setHasIcon(true);
        aba.setIcon("");
        aba.setHasInfo(true);
        aba.setFields(new ArrayList<>());
    }

    public AbaBuilder subTitle(String subTitle) {
        aba.setSubTitle(subTitle);
        return this;
    }

    public AbaBuilder info(String info) {
        aba.setInfoText(info);
        aba.setHasInfo(true);
        return this;
    }

    public AbaBuilder addCampo(AbaCampos campo) {
        aba.getFields().add(List.of(campo));
        return this;
    }

    public AbaBuilder addCampos(List<AbaCampos> campos) {
        aba.getFields().add(campos);
        return this;
    }

    public AbaDataInterface build() {
        return aba;
    }
}
