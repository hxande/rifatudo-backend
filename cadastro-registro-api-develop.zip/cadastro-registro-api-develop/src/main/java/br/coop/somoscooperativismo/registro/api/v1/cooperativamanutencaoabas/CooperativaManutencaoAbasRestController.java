package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.record.CooperativaManutencaoRequestRecord;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.to.CooperativaManutencaoAbasTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/cooperativa-manutencao-abas")
@Tag(name = "CooperativaManutencaoAbas")
public class CooperativaManutencaoAbasRestController {

	@Autowired
	private CooperativaManutencaoAbasService cooperativaManutencaoAbasService;
	
	@GetMapping("/{idCooperativa}/{anoCiclo}")
	@Operation(summary = "Consultar manutenção das abas por cooperativa e ano")
	public ResponseEntity<CooperativaManutencaoAbasTO> obterCooperativaManutencaoAbas(@PathVariable Integer idCooperativa,
			@PathVariable Integer anoCiclo){
		return ResponseEntity.ok().body(cooperativaManutencaoAbasService.obterAbaPorCooperativaEAno(idCooperativa,anoCiclo));
	}
	
	@PostMapping("/salvar")
	@Operation(summary = "Salvar situações das abas da atualização cadastral")
	public ResponseEntity<CooperativaManutencaoAbasTO> salvarCooperativaManutencaoAbas(@RequestBody CooperativaManutencaoAbasTO manutencaoAbas){
		return ResponseEntity.ok().body(cooperativaManutencaoAbasService.salvarCooperativaAbas(manutencaoAbas));
	}

	@PostMapping("/salvar-status")
	@Operation(summary = "Salvar situações das abas da atualização cadastral")
	public ResponseEntity<Boolean> salvarPorCooperativa(@RequestBody CooperativaManutencaoRequestRecord request){
		boolean success = cooperativaManutencaoAbasService.salvarStatusAbaDocumento(request.idCooperativa(), request.validacao(), request.getTipo());
		return new ResponseEntity<>(success, (success ? HttpStatus.OK : HttpStatus.ACCEPTED));
	}
	
}
