package br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.entidade;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "EVENTO_EMAIL_ESTADUAL")
public class DisparoEmailEstadual {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_EVENTO_EMAIL_ESTADUAL")
    private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "SQ_EVENTO_EMAIL")
	private DisparoEmail disparoEmail;
	
	@Column(name = "TX_UF")
	private String uf;
	
	@Column(name = "DN_ENVIAR_EMAIL")
	private Boolean envia;
}
