package br.coop.somoscooperativismo.registro.agendamentos;

import br.coop.somoscooperativismo.registro.api.v1.servidor.ServidorService;
import br.coop.somoscooperativismo.registro.api.v1.updatecooperativaanonovo.UpdateCooperativaAnoNovoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@EnableScheduling
public class UpdateCooperativaMudancaAnoCron {

    public static final String TIME_ZONE = "America/Sao_Paulo";

    @Autowired
    private ServidorService servidorService;
    
    @Autowired
    private UpdateCooperativaAnoNovoService updateCooperativaAnoNovoService;
    
    @Value("${ativar-rotinas-automaticas:1}")
    private Boolean rotinaHabilitada;
    
    @Scheduled(cron = "${tempo-rotina-update-mudanca-ano}", zone = TIME_ZONE)
    public void executar() {
    	
    	if (Boolean.FALSE.equals(rotinaHabilitada) || !servidorService.isServidorPrincipal()) {
    		log.info("rotina de migração dos dados das cooperativa em processo de registro não iniciada servidor principal false ou rotina desabilitada.");
    		return;
        }
    	
    	log.info("Iniciar migração dos dados das cooperativa em processo de registro.");
    	updateCooperativaAnoNovoService.executar();
    	log.info("Finalização da migração dos dados das cooperativa em processo de registro.");
    }
}

