package br.coop.somoscooperativismo.registro.api.v1.censoanuario;

import java.time.LocalDateTime;

public record CensoAnuarioRecord(Integer ano, Integer idCooperativa, LocalDateTime dataSubmissao, String usuario) {

}
