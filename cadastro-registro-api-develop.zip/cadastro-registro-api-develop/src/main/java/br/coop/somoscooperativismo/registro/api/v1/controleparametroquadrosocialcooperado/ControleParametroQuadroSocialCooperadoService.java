package br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocialcooperado;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.controleparametroquadrosocialcooperado.entidade.ControleParametroQuadroSocialCooperado;
import br.coop.somoscooperativismo.registro.api.v1.parametroquadrosocialcooperado.ParametroQuadroSocialCooperadoService;
import br.coop.somoscooperativismo.registro.api.v1.parametroquadrosocialcooperado.entidade.ParametroQuadroSocialCooperado;

@Service
@Transactional
public class ControleParametroQuadroSocialCooperadoService  {

	private final ControleParametroQuadroSocialCooperadoRepository controleParametroQuadroSocialCooperadoRepository;
	private final KeycloakService keycloakService;
	private final ParametroQuadroSocialCooperadoService parametroQuadroSocialCooperadoService;

	public ControleParametroQuadroSocialCooperadoService(
			ControleParametroQuadroSocialCooperadoRepository controleParametroQuadroSocialCooperadoRepository,
			KeycloakService keycloakService,
			ParametroQuadroSocialCooperadoService parametroQuadroSocialCooperadoService) {
		this.controleParametroQuadroSocialCooperadoRepository = controleParametroQuadroSocialCooperadoRepository;
		this.keycloakService = keycloakService;
		this.parametroQuadroSocialCooperadoService = parametroQuadroSocialCooperadoService;
	}
	
	public void habilitarDesabilitarCampos(boolean habilitar) {
		
		if(!keycloakService.isTipoEntidadeNacional()) {
			throw new RegraNegocioException("Usuário não possui permissão para realizar esta operação.");
		}
		
		ControleParametroQuadroSocialCooperado controleParametroQuadroSocialCooperado = null;
		List<ControleParametroQuadroSocialCooperado> listControleParametroQuadroSocialCooperado = controleParametroQuadroSocialCooperadoRepository.findAll();
		
		controleParametroQuadroSocialCooperado = ValidacaoCampos.validaCampoPreenchido(listControleParametroQuadroSocialCooperado)
				? listControleParametroQuadroSocialCooperado.get(0)
				: new ControleParametroQuadroSocialCooperado();
		
		controleParametroQuadroSocialCooperado.setInformarCampos(habilitar);
		controleParametroQuadroSocialCooperado.setUsuario(keycloakService.getUsername());
		controleParametroQuadroSocialCooperado.setDataAlteracao(LocalDate.now());
		controleParametroQuadroSocialCooperadoRepository.save(controleParametroQuadroSocialCooperado);
		
		List<ParametroQuadroSocialCooperado> listParametroQuadroSocialCooperado = parametroQuadroSocialCooperadoService.findAll();
		if(ValidacaoCampos.validaCampoPreenchido(listParametroQuadroSocialCooperado)) {
			listParametroQuadroSocialCooperado.forEach(parametroQuadroSocialCooperado -> {
				parametroQuadroSocialCooperado.setObrigatorio(habilitar);
				parametroQuadroSocialCooperadoService.saveParametroQuadroSocialCooperado(parametroQuadroSocialCooperado);
			});
		}

		listControleParametroQuadroSocialCooperado = null;
		listParametroQuadroSocialCooperado = null;
	}

	public Boolean obterControlePreenchimentoDadosAdicionais() {
		List<ControleParametroQuadroSocialCooperado> listaControleParametroQuadroSocialCooperado = controleParametroQuadroSocialCooperadoRepository.findAll();
		
		return ValidacaoCampos.validaCampoPreenchido(listaControleParametroQuadroSocialCooperado) ? listaControleParametroQuadroSocialCooperado.get(0).getInformarCampos() : Boolean.FALSE;
	}
}
