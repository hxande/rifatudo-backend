package br.coop.somoscooperativismo.registro.api.v1.events.listeners;

import java.util.Objects;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.events.events.SolicitacaoMudancaEnderecoEvent;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;

@Component
public class SolicitacaoMudancaEnderecoReprovaListener implements ApplicationListener<SolicitacaoMudancaEnderecoEvent> {

	private EmailService emailService;
	
	public SolicitacaoMudancaEnderecoReprovaListener(EmailService emailService) {
		this.emailService = emailService;
	}

	
	@Override
	public void onApplicationEvent(SolicitacaoMudancaEnderecoEvent event) {
		SolicitacaoMudancaEndereco solicitacaoMudancaEndereco = event.getSolicitacaoMudancaEndereco();
		
		try {
			if(Boolean.FALSE.equals(solicitacaoMudancaEndereco.getCancelado()) && 
					Objects.nonNull(solicitacaoMudancaEndereco.getLoginUsuarioParecer()) &&
					Boolean.FALSE.equals(solicitacaoMudancaEndereco.getAprovado())) {
				// Enviar email notificando OE de origem
				
				emailService.enviaEmailSolicitacaoMudancaEndereco(solicitacaoMudancaEndereco.getPessoa().getId(),solicitacaoMudancaEndereco.getUfOrigem(), DisparoEmailEnum.REPROVACAO_TRANSFERENCIA_UF,solicitacaoMudancaEndereco.getUfDestino());
			}
		} catch (RuntimeException e) {
			throw new RegraNegocioException(e.getMessage(),e);
		}

		solicitacaoMudancaEndereco = null;
	}

}
