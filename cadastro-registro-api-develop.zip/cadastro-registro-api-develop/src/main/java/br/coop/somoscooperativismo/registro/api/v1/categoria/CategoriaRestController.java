package br.coop.somoscooperativismo.registro.api.v1.categoria;

import br.coop.somoscooperativismo.registro.api.v1.categoria.entidade.Categoria;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/categoria")
@Tag(name = "Categoria")
public class CategoriaRestController {

	public static final String CATEGORIA_CRIADA = "categoria.criada";
	public static final String NAO_CORRESPONDE = "categoria.naoCorresponde";
	public static final String CATEGORIA_ATUALIZADA = "categoria.atualizada";
	public static final String CATEGORIA_DESATIVADA = "categoria.desativada";
	
	@Autowired
	private CategoriaService categoriaService;

	
	@Operation(summary = "Detalha uma categoria pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public ResponseEntity<ServiceResponse<Categoria>> getCategoria(@PathVariable Integer id) {
		return ResponseEntity.ok(new ServiceResponse<>(categoriaService.getCategoria(id)));
	}
	
	@GetMapping
	@Operation(summary = "Lista")
	public ServiceResponse<List<Categoria>> getCategorias() {
		return new ServiceResponse<>(categoriaService.getCategorias());
	}
	
	@GetMapping("/buscaAtivos/{ativo}")
	@Operation(summary = "Lista Ativos")
	public ServiceResponse<List<Categoria>> getCategorias(@PathVariable Boolean ativo) {
		return new ServiceResponse<>(categoriaService.listAtivos(ativo));
	}
	
	@GetMapping("/filtro")
	@Operation(summary = "Lista Categorias com filtro")
	public ServiceResponse<Page<Categoria>> listaCategoriaFiltradoPaginado(
			@RequestParam(required = false) String descricao, @RequestParam(required = false) Integer minimoCooperativa, 
			@RequestParam(required = false) Boolean ativo,
			Pageable pageable) {
		return new ServiceResponse<>(categoriaService.filtra(descricao != null ? descricao : "", minimoCooperativa, ativo, pageable));
	}
	
}
