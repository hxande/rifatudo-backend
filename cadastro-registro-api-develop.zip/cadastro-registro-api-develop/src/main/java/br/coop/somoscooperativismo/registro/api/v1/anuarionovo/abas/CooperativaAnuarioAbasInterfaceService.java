package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.*;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.AbaDataTypeEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory.DadosComplementaresAbaFactory;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory.DadosContabilTributarioAbaFactory;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory.DadosNegocioAbaFactory;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.factory.DadosSociaisAbaFactory;
import br.coop.somoscooperativismo.registro.api.v1.complementoanuario.ComplementoAnuarioService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.CooperativaAnuarioAbasRepository;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.entidade.CooperativaAnuarioAbas;
import br.coop.somoscooperativismo.registro.api.v1.desempenho.DesempenhoClient;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesService;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesTO;
import br.coop.somoscooperativismo.registro.api.v1.localizacao.LocalizacaoClient;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacao;
import br.coop.somoscooperativismo.registro.api.v1.negocioexportacao.NegocioExportacaoService;
import br.coop.somoscooperativismo.registro.api.v1.pessoasegmprodserv.PessoaSegmProdServService;
import br.coop.somoscooperativismo.registro.api.v1.quadrosocial.QuadroSocialService;
import br.coop.somoscooperativismo.registro.api.v1.util.ValidacaoPrimeiroRegistroTO;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CooperativaAnuarioAbasInterfaceService {

    @Value("${spring.profiles.active}")
    private String activeProfile;

    private final DesempenhoClient desempenhoClient;
    private final CooperativaAnuarioAbasRepository cooperativaAnuarioAbasRepository;
    private final DadosSociaisAbaFactory dadosSociaisAbaFactory;
    private final DadosContabilTributarioAbaFactory dadosContabilTributarioAbaFactory;
    private final DadosNegocioAbaFactory dadosNegocioAbaFactory;
    private final QuadroSocialService quadroSocialService;
    private final DadosComplementaresAbaFactory dadosComplementaresAbaFactory;
    private final ComplementoAnuarioService complementoAnuarioService;
    private final CooperativaService cooperativaService;
    private final CooperativaFatesService cooperativaFatesService;
    private final NegocioExportacaoService negocioExportacaoService;
    private final LocalizacaoClient localizacaoClient;
    private final PessoaSegmProdServService pessoaSegmProdServService;

    public CooperativaAnuarioAbasInterfaceService(
            DesempenhoClient desempenhoClient,
            CooperativaAnuarioAbasRepository cooperativaAnuarioAbasRepository,
            DadosSociaisAbaFactory dadosSociaisAbaFactory,
            DadosContabilTributarioAbaFactory dadosContabilTributarioAbaFactory,
            DadosNegocioAbaFactory dadosNegocioAbaFactory,
            QuadroSocialService quadroSocialService,
            DadosComplementaresAbaFactory dadosComplementaresAbaFactory,
            ComplementoAnuarioService complementoAnuarioService,
            CooperativaService cooperativaService,
            CooperativaFatesService cooperativaFatesService,
            NegocioExportacaoService negocioExportacaoService,
            LocalizacaoClient localizacaoClient,
            PessoaSegmProdServService pessoaSegmProdServService) {
        this.desempenhoClient = desempenhoClient;
        this.cooperativaAnuarioAbasRepository = cooperativaAnuarioAbasRepository;
        this.dadosSociaisAbaFactory = dadosSociaisAbaFactory;
        this.dadosContabilTributarioAbaFactory = dadosContabilTributarioAbaFactory;
        this.dadosNegocioAbaFactory = dadosNegocioAbaFactory;
        this.quadroSocialService = quadroSocialService;
        this.dadosComplementaresAbaFactory = dadosComplementaresAbaFactory;
        this.complementoAnuarioService = complementoAnuarioService;
        this.cooperativaService = cooperativaService;
        this.cooperativaFatesService = cooperativaFatesService;
        this.negocioExportacaoService = negocioExportacaoService;
        this.localizacaoClient = localizacaoClient;
        this.pessoaSegmProdServService = pessoaSegmProdServService;
    }

    public List<CooperativaAbaInterface> obterListaAbaAnuario(Integer idCooperativa, Integer ano) {
        List<CooperativaAnuarioAbas> listaAbas = cooperativaAnuarioAbasRepository.findAllByIdCooperativaAndAnoCiclo(idCooperativa, ano);

        criaAbasAnuario(idCooperativa, ano, listaAbas);

        // Valida Caso da aba de Dados Complementares
        var complementoAnuario = complementoAnuarioService.findByUf(cooperativaService.findByUfSigla(idCooperativa)).orElse(null);
        if (Objects.nonNull(complementoAnuario) && listaAbas.stream().noneMatch(abas -> abas.getAbaNome().equals(NomeAbaEnum.DADOS_COMPLEMENTARES.getChaveAba()))) {
            listaAbas.add(toAnuarioAbasComplemeto(idCooperativa, ano));
        }

        return listaAbas.stream()
                .map(this::toInterface)
                .filter(aba -> aba.getTitle() != null)
                .peek(aba -> aba.setTemPendencia(
                        verificarPendencia(aba, idCooperativa, ano)
                ))
                .sorted(Comparator.comparingInt(CooperativaAbaInterface::getIndice))
                .collect(Collectors.toList());
    }

    private boolean verificarPendencia(CooperativaAbaInterface aba, Integer idCooperativa, Integer ano) {

        if (aba.getTitle() == null) {
            return false;
        }

        switch (aba.getTitle()) {
            case "Dados sociais" -> {
                ValidacaoPrimeiroRegistroTO msg = quadroSocialService.validarQuadroSocial(idCooperativa, true);
                return this.desempenhoClient.verificarPendencia("SOCIAL_FINANCEIRO", idCooperativa, ano) ||
                        (msg != null && msg.getMensagens() != null && !msg.getMensagens().isEmpty());
            }

            case "Negócio" -> {
                return this.desempenhoClient.verificarPendencia("NEGOCIO_SETORIAIS", idCooperativa, ano) ||
                        this.desempenhoClient.verificarPendencia("NEGOCIO_INTERCOOPERACAO", idCooperativa, ano) ||
                        this.desempenhoClient.verificarPendencia("NEGOCIO_EXPORTACAO", idCooperativa, ano) ||
                        this.desempenhoClient.verificarPendencia("NEGOCIO_VENDAS_ONLINE", idCooperativa, ano) ||
                        !this.negocioExportacaoService.verificarPendencias(idCooperativa, ano).isEmpty();
            }

            case "Detalhamento contábil" -> {
                return this.desempenhoClient.verificarPendencia("CONTABIL_TRIBUTARIO", idCooperativa, ano) ||
                        !this.cooperativaFatesService.verificarPendencias(idCooperativa, ano).isEmpty();
            }

            case "Portfólio" -> {
                ValidacaoPrimeiroRegistroTO validacaoPrimeiroRegistroTO = this.pessoaSegmProdServService.validarSegmentoProdutoServico(idCooperativa);
                return validacaoPrimeiroRegistroTO.getMensagens() != null && validacaoPrimeiroRegistroTO.getMensagens().size() > 0;
            }

            case "Dados Complementares" -> {
                return Objects.nonNull(aba.getSituacao()) && aba.getSituacao() != 1;
            }

            default -> {
                return false;
            }
        }
    }

    public CooperativaAbaInterface toInterface(CooperativaAnuarioAbas cooperativaAnuarioAbas) {
        CooperativaAbaInterface cooperativaAbaInterface = new CooperativaAbaInterface();

        cooperativaAbaInterface.setId(NomeAbaEnum.getIdEnum(cooperativaAnuarioAbas.getAbaNome()));
        cooperativaAbaInterface.setTitle(NomeAbaEnum.getEnum(cooperativaAnuarioAbas.getAbaNome()));
        cooperativaAbaInterface.setTabPreenchida(cooperativaAnuarioAbas.getAbaPreenchida());

        CooperativaAbaDataInterface cooperativaAbaDataInterface = new CooperativaAbaDataInterface();
        cooperativaAbaDataInterface.setType(AbaDataTypeEnum.ACCORDION);
        cooperativaAbaDataInterface.setData(Collections.emptyList());

        cooperativaAbaInterface.setContent(cooperativaAbaDataInterface);

        cooperativaAbaInterface.setIndice(NomeAbaEnum.getIndice(cooperativaAnuarioAbas.getAbaNome()));
        cooperativaAbaInterface.setSituacao(cooperativaAnuarioAbas.getSituacao());

        return cooperativaAbaInterface;
    }

    public CooperativaAnuarioAbas toAnuarioAbasComplemeto(Integer idCooperativa, Integer ano) {
        CooperativaAnuarioAbas cooperativaAnuarioAbas = new CooperativaAnuarioAbas();
        cooperativaAnuarioAbas.setAbaNome(NomeAbaEnum.DADOS_COMPLEMENTARES.getChaveAba());
        cooperativaAnuarioAbas.setIdCooperativa(idCooperativa);
        cooperativaAnuarioAbas.setAnoCiclo(ano);
        cooperativaAnuarioAbas.setAbaPreenchida(true);
        cooperativaAnuarioAbas.setSituacao(0);

        return cooperativaAnuarioAbas;
    }

    public List<AbaDataInterface> obterListaAbaAnuarioDadosSociais(Integer idCooperativa, Integer ano) {
        var quadroSocial = quadroSocialService.obterQuadroSocialAnuarioTO(idCooperativa, ano);

        var dadosComplementares = desempenhoClient.obterLancamentos("SOCIAL_FINANCEIRO", idCooperativa, ano);

        quadroSocial.setDadosComplementares(dadosComplementares);

        List<AbaDataInterface> accordions = dadosSociaisAbaFactory.build(quadroSocial);

        CooperativaAbaInterface cooperativaAbaInterface = new CooperativaAbaInterface();
        cooperativaAbaInterface.setId(NomeAbaEnum.DADOS_SOCIAIS.getIdAba());
        cooperativaAbaInterface.setTitle("Dados Sociais");
        cooperativaAbaInterface.setTabPreenchida(true);

        CooperativaAbaDataInterface content = new CooperativaAbaDataInterface();
        content.setType(AbaDataTypeEnum.ACCORDION);
        content.setData(accordions);

        cooperativaAbaInterface.setContent(content);

        return accordions;
    }

    public List<AbaDataInterface> obterListaAbaAnuarioDadosContabilTributario(Integer ano, Integer idCooperativa) {
        DadosContabilTributarioTO to = new DadosContabilTributarioTO();

        CooperativaFatesTO cooperativaFatesTO = cooperativaFatesService.buscarPorAnoCooperativa(ano, idCooperativa);

        var contabilTribuario = desempenhoClient.obterLancamentos(NomeAbaEnum.CONTABIL_TRIBUTARIO.getChaveAba(), idCooperativa, ano);
        to.setActiveProfile(activeProfile);
        to.setDadosEstrutura(contabilTribuario);
        to.setDadosFates(cooperativaFatesTO);

        var pendencias = this.desempenhoClient.buscarPendencia("CONTABIL_TRIBUTARIO", idCooperativa, ano);
        to.setPendencias(pendencias);

        List<AbaDataInterface> accordions = dadosContabilTributarioAbaFactory.build(to);

        CooperativaAbaInterface cooperativaAbaInterface = new CooperativaAbaInterface();
        cooperativaAbaInterface.setId(NomeAbaEnum.CONTABIL_TRIBUTARIO.getIdAba());
        cooperativaAbaInterface.setTitle("Contábil Tributário");
        cooperativaAbaInterface.setTabPreenchida(true);

        CooperativaAbaDataInterface content = new CooperativaAbaDataInterface();
        content.setType(AbaDataTypeEnum.ACCORDION);
        content.setData(accordions);

        cooperativaAbaInterface.setContent(content);

        return accordions;
    }

    public List<AbaDataInterface> obterListaAbaNegocios(Integer ano, Integer idCooperativa) {
        DadosNegocioTO to = new DadosNegocioTO();
        to.setAno(ano);

        var negocios = desempenhoClient.obterLancamentosNegocios(idCooperativa, ano);
        to.setDadosEstrutura(negocios);

        var cooperativa = cooperativaService.getCooperativa(idCooperativa);
        if (cooperativa.getPessoaJuridica().getRamo().getId().equals(1) || cooperativa.getPessoaJuridica().getRamo().getId().equals(7)) {
            NegocioExportacao negocioExportacao = negocioExportacaoService.getByCooperativaIdAno(idCooperativa, ano);
            var paises = localizacaoClient.listarPaises();

            to.setDadosNegocioExportacao(negocioExportacao);
            to.setPaises(paises);
        }

        List<AbaDataInterface> accordions = dadosNegocioAbaFactory.build(to);

        CooperativaAbaInterface cooperativaAbaInterface = new CooperativaAbaInterface();
        cooperativaAbaInterface.setId(NomeAbaEnum.NEGOCIO.getIdAba());
        cooperativaAbaInterface.setTitle("Negócio");
        cooperativaAbaInterface.setTabPreenchida(true);

        CooperativaAbaDataInterface content = new CooperativaAbaDataInterface();
        content.setType(AbaDataTypeEnum.ACCORDION);
        content.setData(accordions);

        cooperativaAbaInterface.setContent(content);

        return accordions;
    }

    public List<AbaDataInterface> obterListaAbaAnuarioDadosComplementares(Integer idCooperativa, Integer ano) {

        var complementoAnuario = complementoAnuarioService.findByUf(cooperativaService.findByUfSigla(idCooperativa));

        List<AbaDataInterface> accordions = dadosComplementaresAbaFactory.build(complementoAnuario.orElse(null));

        CooperativaAbaInterface cooperativaAbaInterface = new CooperativaAbaInterface();
        cooperativaAbaInterface.setId(NomeAbaEnum.DADOS_COMPLEMENTARES.getIdAba());
        cooperativaAbaInterface.setTitle("Dados Complementares");
        cooperativaAbaInterface.setTabPreenchida(true);

        CooperativaAbaDataInterface content = new CooperativaAbaDataInterface();
        content.setType(AbaDataTypeEnum.ACCORDION);
        content.setData(accordions);

        cooperativaAbaInterface.setContent(content);

        return accordions;
    }


    private void criaAbasAnuario(Integer idCooperativa, Integer ano, List<CooperativaAnuarioAbas> abas) {
        Set<String> abasExistentes = abas.stream()
                .map(CooperativaAnuarioAbas::getAbaNome)
                .collect(Collectors.toSet());

        Set<String> abasEsperadas = obterChavesAbasEsperadas(idCooperativa, ano);
        abasEsperadas.remove(NomeAbaEnum.DADOS_COMPLEMENTARES.getChaveAba());

        List<CooperativaAnuarioAbas> novasAbas = new ArrayList<>();
        for (String chave : abasEsperadas) {
            if (!abasExistentes.contains(chave)) {
                novasAbas.add(new CooperativaAnuarioAbas(ano, idCooperativa, chave, false));
            }
        }

        abas.addAll(novasAbas);
    }

    public Set<String> obterChavesAbasEsperadas(Integer idCooperativa, Integer ano) {
        Set<String> esperadas = new java.util.LinkedHashSet<>();
        esperadas.add(NomeAbaEnum.DADOS_SOCIAIS.getChaveAba());
        esperadas.add(NomeAbaEnum.PORTFOLIO.getChaveAba());
        esperadas.add(NomeAbaEnum.CONTABIL_TRIBUTARIO.getChaveAba());

        var cooperativa = cooperativaService.getCooperativa(idCooperativa);
        boolean ramoNegocio = cooperativa.getPessoaJuridica().getRamo().getId().equals(1)
                || cooperativa.getPessoaJuridica().getRamo().getId().equals(7);
        if (ramoNegocio || !desempenhoClient.obterLancamentosNegocios(idCooperativa, ano).isEmpty()) {
            esperadas.add(NomeAbaEnum.NEGOCIO.getChaveAba());
        }

        String ufSigla = cooperativaService.findByUfSigla(idCooperativa);
        if (complementoAnuarioService.findByUf(ufSigla).isPresent()) {
            esperadas.add(NomeAbaEnum.DADOS_COMPLEMENTARES.getChaveAba());
        }

        return esperadas;
    }
}
