package br.coop.somoscooperativismo.registro.api.v1.dlq.entidade;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "DLQ_MESSAGE")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DlqMessage {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SQ_ERRO_INTEGRACAO")
    private Long id;

    @Column(name = "TX_PUBLISHER")
    private String publisher;

    @Column(name = "TX_ORIGINAL_ROUTING_KEY")
    private String routingKey;

    @Column(name = "TX_ORIGINAL_QUEUE")
    private String queue;

    @Column(name = "TX_ORIGINAL_EXCHANGE")
    private String exchange;

    @Column(name = "TX_EVENT_TYPE")
    private String eventType;

    @Lob
    @Column(name = "JS_BODY", columnDefinition = "NVARCHAR(MAX)", nullable = false)
    private String payload;

    @Lob
    @Column(name = "TX_LOG_ERROR", columnDefinition = "NVARCHAR(MAX)")
    private String errorMessage;

    @Column(name = "NR_RETRY", nullable = false)
    private Integer deathCount;

    @Column(name = "DT_INTEGRACAO", nullable = false)
    private LocalDateTime dataHoraFalha;

    public DlqMessage(String publisher, String queue, String exchange,
                      String routingKey, String eventType, String payload,
                      Integer deathCount, String errorMessage) {
        this.publisher = publisher;
        this.routingKey = routingKey;
        this.queue = queue;
        this.exchange = exchange;
        this.eventType = eventType;
        this.payload = payload;
        this.deathCount = deathCount;
        this.errorMessage = errorMessage;
        this.dataHoraFalha = LocalDateTime.now();
    }
}
