package br.coop.somoscooperativismo.registro.api.v1.arrecadacao;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TaxaRegistroParcelaTO {

    private Integer id;
    private Integer numeroParcela;
    private BigDecimal valor;
    private BigDecimal desconto;
    private BigDecimal juros;
    private BigDecimal multa;
    private BigDecimal valorFinal;
    private BigDecimal valorPago;
    private Date dataPagamento;
    private Date dataVencimento;
    private Date dataGeracao;
    private LocalDate dataRepasse;
    private String usuario;
    private String status;
}
