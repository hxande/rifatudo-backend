package br.coop.somoscooperativismo.registro.api.v1.dadosgerais.validacao;

import java.util.List;

import br.coop.somoscooperativismo.ocbcommonsapi.response.MessageType;
import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceMessage;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CategoriaCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;

public class DadosGeraisValidacaoGrau {
	public static final String  VALIDACAO_GRAU_OBRIGATORIO = "dadosGerais.validacao.grauObrigatorio";
	public static final String VALIDACAO_GRAU_INVALIDO = "dadosGerais.validacao.grauInvalido";
	public static final String VALIDCAO_GRAU_VINCULACAO_NAO_ENCONTRADA = "dadosGerais.validcao.grauVinculacaoNaoEncontrada";

	public List<ServiceMessage> validaGrau(List<ServiceMessage> mensagens, Cooperativa c,  MessagesService messages, CooperativaService cooperativaService){
		
		if(c.getCategoria() == null) {
			mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get( VALIDACAO_GRAU_OBRIGATORIO )));
		} else {
			CategoriaCooperativaEnum categoria = CategoriaCooperativaEnum.getValue(c.getCategoria().getId());
			if(categoria == null) {
				mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDACAO_GRAU_INVALIDO)));
			} else {
				
				List<Cooperativa> vinculadas = cooperativaService.getCooperativasVinculadas(c.getId());
				
				if(c.getCategoria().getMinimoCooperativa() != 0) {
					if(vinculadas == null) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, messages.get(VALIDCAO_GRAU_VINCULACAO_NAO_ENCONTRADA)));
					} else if(vinculadas.size() < c.getCategoria().getMinimoCooperativa()) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, String.format("Número mínimo de %s cooperativas não foi atendido.", c.getCategoria().getMinimoCooperativa())));
					}
				}
				
				// Varrer o GRAU das cooperativas
				validarGrauCooperativaVinculada(mensagens, c, categoria, vinculadas);
				
			}
		}
		
		return mensagens;
		
	}

	private void validarGrauCooperativaVinculada(List<ServiceMessage> mensagens, Cooperativa c,
			CategoriaCooperativaEnum categoria, List<Cooperativa> vinculadas) {
		if(vinculadas != null && !vinculadas.isEmpty()) {
			CategoriaCooperativaEnum aux;
			for(Cooperativa vinc : vinculadas) {
				if(vinc.getCategoria() == null) {
					mensagens.add(new ServiceMessage(MessageType.ERROR, "Cooperativa %s não tem categoria informada".formatted(vinc.getNomeCooperativa())));
				} else {
					aux = CategoriaCooperativaEnum.getValue(vinc.getCategoria().getId());
					
					if(!categoria.getPermissaoVinculacao().contains(aux.getGrau())) {
						mensagens.add(new ServiceMessage(MessageType.ERROR, String.format("Cooperativa com categoria %s não pode ser vinculada à essa tipo de cooperativa (%s).", vinc.getCategoria().getDescricao(), c.getCategoria().getDescricao())));
					}
				}
			}
		}
	}
}
