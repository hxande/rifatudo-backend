package br.coop.somoscooperativismo.registro.api.v1.desempenho;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ParametroPendenciaTO {

	private Integer idParametro;
	private String nome;
}
