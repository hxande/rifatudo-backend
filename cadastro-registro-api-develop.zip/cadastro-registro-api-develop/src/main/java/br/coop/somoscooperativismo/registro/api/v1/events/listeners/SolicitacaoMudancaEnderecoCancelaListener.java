package br.coop.somoscooperativismo.registro.api.v1.events.listeners;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.registro.api.v1.email.EmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.events.events.SolicitacaoMudancaEnderecoEvent;
import br.coop.somoscooperativismo.registro.api.v1.mudancaendereco.entidade.SolicitacaoMudancaEndereco;

@Component
public class SolicitacaoMudancaEnderecoCancelaListener implements ApplicationListener<SolicitacaoMudancaEnderecoEvent> {
	
	private EmailService emailService;
	
	
	public SolicitacaoMudancaEnderecoCancelaListener(EmailService emailService) {
		this.emailService = emailService;
	}

	@Override
	public void onApplicationEvent(SolicitacaoMudancaEnderecoEvent event) {
		SolicitacaoMudancaEndereco solicitacaoMudancaEndereco = event.getSolicitacaoMudancaEndereco();
		
		try {
			if(Boolean.TRUE.equals(solicitacaoMudancaEndereco.getCancelado()) ) {
				// Enviar email notificando OE de destino
				emailService.enviaEmailSolicitacaoMudancaEndereco(solicitacaoMudancaEndereco.getPessoa().getId(), solicitacaoMudancaEndereco.getUfDestino(), DisparoEmailEnum.CANCELAMENTO_TRANSFERENCIA_UF, null);
			}
		} catch (Exception e) {
			throw new RegraNegocioException(e.getMessage(),e);
		}

		solicitacaoMudancaEndereco = null;
	}

}
