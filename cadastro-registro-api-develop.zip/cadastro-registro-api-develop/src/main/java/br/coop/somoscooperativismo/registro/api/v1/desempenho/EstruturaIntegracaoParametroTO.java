package br.coop.somoscooperativismo.registro.api.v1.desempenho;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EstruturaIntegracaoParametroTO {
	
	
	private Integer idParametro;
	private String nomeParametro;
	private String descricaoParametro;

	private String nomeUnidade;
	private String siglaUnidade;
	private String tipoUnidade;
	private Integer quantidadeCasasUnidade;

	private Integer idEstruturaModeloRamo;
	private String valor;
	private Boolean podePreencher;
	
	private Boolean fechado;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
	private Date dtRegistroOcb;
	private String situacao;
	private String uf;
	private String ramo;
	private Integer sqPessoa;
	private String dtSubmissao;
	private Integer ano;
	private String grupo;
	private String nomeFantasia;
	private String cnpj;

	private boolean isCreditoAno;
	private boolean isValoresNegativos;
	private boolean isCampoObrigatorio;
	private String descricaoRamo;

}
