package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

public enum CooperativaStatusManutencaoEnum {
	DADOS_DESATUALIZADOS, 		    //  - Olhar para a regra período de atualização.
	DADOS_ATUALIZADOS, 				//  - Cooperativa atualizou e enviou os dados para a Unidade Estadual validar.
	AGUARDANDO_AJUSTE, 				//	- Unidade estadual solicitou ajustes para a cooperativa.
	AGUARDANDO_ANALISE; 	//  - Cooperativa atualizou os dados e a unidade estadual validou.
}
