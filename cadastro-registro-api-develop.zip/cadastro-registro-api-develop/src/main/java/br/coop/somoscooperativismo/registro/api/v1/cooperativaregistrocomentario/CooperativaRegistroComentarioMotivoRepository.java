package br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentario;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaregistrocomentario.entidade.CooperativaRegistroComentarioMotivo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CooperativaRegistroComentarioMotivoRepository extends JpaRepository<CooperativaRegistroComentarioMotivo, Integer> {

    List<CooperativaRegistroComentarioMotivo> findByCooperativaRegistroComentario(CooperativaRegistroComentario cooperativaRegistroComentario);

}
