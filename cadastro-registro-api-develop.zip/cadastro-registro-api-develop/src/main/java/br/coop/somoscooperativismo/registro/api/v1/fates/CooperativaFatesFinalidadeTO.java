package br.coop.somoscooperativismo.registro.api.v1.fates;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CooperativaFatesFinalidadeTO {
    private Integer cooperativaFateId;
    private Integer cooperativaFateFinalidadeId;
    private String nomeFinalidade;
}
