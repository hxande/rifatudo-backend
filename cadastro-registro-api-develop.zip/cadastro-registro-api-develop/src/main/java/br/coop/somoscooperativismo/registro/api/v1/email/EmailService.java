package br.coop.somoscooperativismo.registro.api.v1.email;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.ErroSistemaException;
import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.ocbcommonsapi.util.FreeMarkerTemplateService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.email.entidade.RegistroEmail;
import br.coop.somoscooperativismo.registro.api.v1.email.publisher.EmailPublisher;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailEnum;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.DisparoEmailService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmail;
import br.coop.somoscooperativismo.registro.api.v1.eventoemail.entidade.DisparoEmailHistorico;
import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.DisparoEmailEstadualService;
import br.coop.somoscooperativismo.registro.api.v1.eventoemailestadual.entidade.DisparoEmailEstadual;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.PessoaJuridicaUtil;
import br.coop.somoscooperativismo.registro.api.v1.pessoajuridica.entidade.PessoaJuridica;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;
import br.coop.somoscooperativismo.registro.api.v1.usuario.UsuarioClient;
import br.coop.somoscooperativismo.registro.api.v1.usuario.UsuarioDestinatarioTO;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.jboss.logging.Logger;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class EmailService {

    public static final String SUSPENSAO_COOPERATIVA = "Suspensão de cooperativa - Sistema OCB";
    public static final String EMAIL_OCB = "sistemas@sistemaocb.coop.br";
    public static final String MODULO_ENVIO_EMAIL = "CADASTRO_REGISTRO";
    private static final Logger LOGGER = Logger.getLogger(EmailService.class);
        
    private final EmailPublisher emailPublisher;
    private final UsuarioClient usuarioClient;
    private final CooperativaService cooperativaService;
    private final DisparoEmailService disparoEmailService;
    private final RegistroEmailRepository registroEmailRepository;
    private final DisparoEmailEstadualService disparoEmailEstadualService;
    private final KeycloakService keycloakService;
    private final FreeMarkerTemplateService freeMarkerTemplateService;


    public EmailService(
            EmailPublisher emailPublisher,
            UsuarioClient usuarioClient,
            @Lazy CooperativaService cooperativaService,
            DisparoEmailService disparoEmailService,
            RegistroEmailRepository registroEmailRepository,
            DisparoEmailEstadualService disparoEmailEstadualService,
            KeycloakService keycloakService,
            FreeMarkerTemplateService freeMarkerTemplateService) {
        this.emailPublisher = emailPublisher;
        this.usuarioClient = usuarioClient;
        this.cooperativaService = cooperativaService;
        this.disparoEmailService = disparoEmailService;
        this.registroEmailRepository = registroEmailRepository;
        this.disparoEmailEstadualService = disparoEmailEstadualService;
        this.keycloakService = keycloakService;
        this.freeMarkerTemplateService = freeMarkerTemplateService;
    }

    private void salvarHistoricoEnvioEmail(DisparoEmail disparoEmail, Integer idCooperativa, String destinatario) {
    	DisparoEmailHistorico disparoEmailHistorico = new DisparoEmailHistorico();
        disparoEmailHistorico.setDisparoEmail(disparoEmail);
        disparoEmailHistorico.setDestinatario(destinatario);
        disparoEmailHistorico.setIdCooperativa(idCooperativa);
        disparoEmailHistorico.setEnviado(Boolean.TRUE);
        disparoEmailHistorico.setDataEnvio(new Date());
        this.disparoEmailService.insertDisparoEmailHistorico(disparoEmailHistorico);
    }

    public String obtemDestinatariosCoop(List<PessoaJuridica> listaPJ) {
        StringBuilder destinatarios = new StringBuilder();
        List<String> listaCnpj = new ArrayList<>();
        for (PessoaJuridica pessoaJuridica : listaPJ) {
            listaCnpj.add(pessoaJuridica.getCnpj());
        }
        try {
            List<UsuarioDestinatarioTO> usuarios = usuarioClient.obterDestinatariosEntidade(listaCnpj);
            if(usuarios.stream().noneMatch(UsuarioDestinatarioTO::isUsuarioAtivo)) {
                LOGGER.warn(EmailServiceConstant.USUARIOS_NAO_ENCONTRADOS);
            }
            usuarios.stream()
                    .filter(UsuarioDestinatarioTO::isUsuarioAtivo)
                    .filter(usuario -> ValidacaoCampos.validaCampoPreenchido(usuario.getEmail()))
                    .forEach(usuario -> destinatarios.append(usuario.getEmail()+"; "));
        } catch (Exception e) {
            LOGGER.warn(EmailServiceConstant.USUARIOS_NAO_ENCONTRADOS + listaCnpj, e);
        }

        return destinatarios.toString().length() > 0 ? destinatarios.substring(0, destinatarios.toString().length() - 1) : destinatarios.toString();
    }

    public void enviaEmailSubmeter(Cooperativa cooperativa) {
        DisparoEmailTO disparoEmailTO = new DisparoEmailTO();
        disparoEmailTO.setNumeroProcesso(String.valueOf(cooperativa.getId()));
        disparoEmailTO.setCooperativa(cooperativa.getNomeCooperativa());
        disparoEmailTO.setCodigoDisparoEmail(DisparoEmailEnum.SUBMETER);
        disparoEmailTO.setUf(cooperativa.getPessoaJuridica().getUfSigla());
        DisparoEmail disparoEmail = getDisparoEmail(disparoEmailTO);

        if(disparoEmail.getId() != null) {
            EmailTO emailTO = new EmailTO();
            emailTO.setAssunto("Requerimento de Registro realizado");
            emailTO.setPara(obtemDestinatariosCoop(Collections.singletonList(cooperativa.getPessoaJuridica())));
            emailTO.setDe(EmailServiceConstant.EMAIL_OCB);
            emailTO.setCorpo(disparoEmail.getTextoEmail());
            emailTO.setChaveModulo(EmailServiceConstant.MODULO_ENVIO_EMAIL);
            this.enviarEmail(emailTO);
        }
    }

    public RegistroEmail enviaEmailNotificarSuspensao(Cooperativa cooperativa) {
        DisparoEmailTO disparoEmailTO = new DisparoEmailTO();
        disparoEmailTO.setNumeroProcesso(String.valueOf(cooperativa.getId()));
        disparoEmailTO.setCooperativa(cooperativa.getNomeCooperativa());
        disparoEmailTO.setCodigoDisparoEmail(DisparoEmailEnum.NOTIFICAR_SUSPENSAO);
        disparoEmailTO.setUf(cooperativa.getPessoaJuridica().getUfSigla());
        

        RegistroEmail registroEmail = new RegistroEmail();

        DisparoEmail disparoEmail = getDisparoEmail(disparoEmailTO);

        if(disparoEmail.getId() != null) {
            EmailTO emailTO = new EmailTO();
            emailTO.setAssunto(SUSPENSAO_COOPERATIVA);
            String destinatariosCoop = obtemDestinatariosCoop(Collections.singletonList(cooperativa.getPessoaJuridica()));
            destinatariosCoop += " " + keycloakService.getAttribute("email");
            emailTO.setPara(destinatariosCoop);
            emailTO.setDe(EMAIL_OCB);
            emailTO.setCorpo(disparoEmail.getTextoEmail());
            emailTO.setChaveModulo(MODULO_ENVIO_EMAIL);
            this.enviarEmail(emailTO);
            registroEmail.setPara(cooperativa.getPessoaJuridica().getEmailGeral() + "; " + destinatariosCoop);
            registroEmail.setCorpo(emailTO.getCorpo());
            registroEmail.setDtEnvio(new Date());

            return this.registroEmailRepository.save(registroEmail);
        }

        return null;
    }

    @SneakyThrows
    private String replaceData(DisparoEmailTO disparoEmailTO) throws IOException {
        String textoVariavel = disparoEmailTO.getTextoVariavelEmail().replace("<p>", EmailServiceConstant.FONT_STYLE);
        String emailCorpoParcial = disparoEmailTO.getCorpoEmail().replaceAll(EmailServiceConstant.TEXTO_VARIAVEL, textoVariavel);
        emailCorpoParcial = emailCorpoParcial.replaceAll(" %([a-zA-Z]\\w*)%", " \\${$1}");

        String templatePadrao = new String(freeMarkerTemplateService.templatePadrao(), StandardCharsets.UTF_8);
        Map<String, String> bodyParcial = new HashMap<>();
        bodyParcial.put("conteudo", emailCorpoParcial);
        templatePadrao = freeMarkerTemplateService.processTemplateConteudo(templatePadrao, bodyParcial);

        Map<String, String> bodyMap = new HashMap<>();
        bodyMap.put(EmailServiceConstant.NUMERO_PROCESSO, disparoEmailTO.getNumeroProcesso());
        bodyMap.put(EmailServiceConstant.URL_CONTINUAR, disparoEmailTO.getBotaoContinuar());
        bodyMap.put(EmailServiceConstant.URL_DATA, disparoEmailTO.getBotaoData());
        bodyMap.put(EmailServiceConstant.URL_RECEBER_EMAIL, disparoEmailTO.getBotaoRecebeEmail());
        bodyMap.put(EmailServiceConstant.COOPERATIVA, disparoEmailTO.getCooperativa());
        bodyMap.put(EmailServiceConstant.UF, disparoEmailTO.getUf());
        bodyMap.put(EmailServiceConstant.TEXTO_VARIAVEL, disparoEmailTO.getUf());

        return freeMarkerTemplateService.processTemplateConteudo(templatePadrao, bodyMap);
    }

    public DisparoEmail getDisparoEmail(DisparoEmailTO disparoEmailTO) {
        DisparoEmail disparoEmailModel = disparoEmailService.findDisparoEmailByChaveEmail(disparoEmailTO.getCodigoDisparoEmail().name());
        
        DisparoEmailEstadual disparoEmailEstadual = disparoEmailEstadualService.findByDisparoEmailIdAndUf(disparoEmailModel.getId(),disparoEmailTO.getUf());
        
        if (disparoEmailModel.isAtivo() && verificaParametroEstadual(disparoEmailEstadual)) {
            disparoEmailTO.setCorpoEmail(disparoEmailModel.getTextoEmail());
            disparoEmailTO.setTextoVariavelEmail(disparoEmailModel.getTextoVariavelEmail());

            DisparoEmail disparoEmail = new DisparoEmail();
            disparoEmail.setId(disparoEmailModel.getId());

            try {
                disparoEmail.setTextoEmail(this.replaceData(disparoEmailTO));

                return disparoEmail;
            } catch (Exception e) {
                String message = "Erro ao disparar um email: " + e.getMessage();
                LOGGER.error(message, e);
            }
        }

        return new DisparoEmail();
    }

    private boolean verificaParametroEstadual(DisparoEmailEstadual disparoEmailEstadual) {
		
		return disparoEmailEstadual == null || disparoEmailEstadual.getEnvia();
	}

    public void enviaEmailSolicitacaoMudancaEndereco(Integer idPessoa, String ufEmail,DisparoEmailEnum tipoEmail, String ufDestino) {
    	
		String destinatarios = cooperativaService.buscarOEPorUf(ufEmail).stream()
				.filter(pj -> pj.getEmailGeral() != null && !pj.getEmailGeral().isEmpty())
				.map(PessoaJuridica::getEmailGeral).collect(Collectors.joining(","));
    	Cooperativa cooperativa = cooperativaService.getCooperativaSemVerificacao(idPessoa);
		
    	DisparoEmailTO disparoEmailTO = new DisparoEmailTO();
        disparoEmailTO.setCooperativa(PessoaJuridicaUtil.getCnpjNome(cooperativa.getPessoaJuridica()));
        disparoEmailTO.setCodigoDisparoEmail(tipoEmail);
        disparoEmailTO.setUf(ufDestino);

        if(Objects.equals(tipoEmail, DisparoEmailEnum.APROVACAO_TRANSFERENCIA_UF) &&
        		cooperativa.getPessoaJuridica().getEmailGeral() != null &&
        		!cooperativa.getPessoaJuridica().getEmailGeral().isEmpty()) {
        	destinatarios = destinatarios.concat(",").concat(cooperativa.getPessoaJuridica().getEmailGeral());
        }
        	
        
        DisparoEmail disparoEmail = getDisparoEmail(disparoEmailTO);

        if (disparoEmail.getId() != null) {
            EmailTO emailTO = criarEmailTO(EmailServiceConstant.TRANSFERENCIA_UF,destinatarios, disparoEmail);
            this.enviarEmail(emailTO);
            
            // Gerar historico de envio
            salvarHistoricoEnvioEmail(disparoEmail,idPessoa,destinatarios);
            
         }
    }
	
    private EmailTO criarEmailTO(String assunto, String destinatarios,DisparoEmail disparoEmail) {
		EmailTO emailTO = new EmailTO();
        emailTO.setAssunto(assunto);
        emailTO.setPara(destinatarios);
        emailTO.setDe(EmailServiceConstant.EMAIL_OCB);
        emailTO.setCorpo(disparoEmail.getTextoEmail());
        emailTO.setChaveModulo(EmailServiceConstant.MODULO_ENVIO_EMAIL);
        return emailTO;
	}

    public void enviarEmail(EmailTO emailTo) {
        try {
            if (emailTo.getPara() != null && !emailTo.getPara().equalsIgnoreCase("") && !emailTo.getPara().equalsIgnoreCase("null")) {
                emailPublisher.enviarEmail(emailTo);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new ErroSistemaException(e.getMessage());
        }
    }

    public void enviaEmailsEmLote(List<EmailTO> emailsTo) {
        try {
            if (emailsTo != null) {
                emailsTo.forEach(this::enviarEmail);
            }
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new ErroSistemaException(e.getMessage());
        }
    }
}
