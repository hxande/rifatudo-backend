package br.coop.somoscooperativismo.registro;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class SubPerfilPermissoesTO {


    public static final String NOME_CASO_DE_USO = "NOME_CASO_DE_USO";

    private static final Map<String, List<String>> subPerfis = new HashMap<>();
    private static final Map<String, List<String>> subPerfisPadrao = new HashMap<>();

    static {
        subPerfis.put(NOME_CASO_DE_USO, Arrays.asList("SUBGRUPO_1", "SUBGRUPO_2", "SUBGRUPO_3"));
    }

    public static List<String> getSubperfis(String nomePerfil) {
        return subPerfis.get(nomePerfil);
    }

    public static Map<String, List<String>> getSubperfisPadrao() {
        return subPerfisPadrao;
    }
    
}
