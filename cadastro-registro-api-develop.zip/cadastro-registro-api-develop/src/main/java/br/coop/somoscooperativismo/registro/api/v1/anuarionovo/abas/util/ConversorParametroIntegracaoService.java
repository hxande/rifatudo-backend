package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util;

import br.coop.somoscooperativismo.ocbcommonsapi.web.JsonUtil;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadoIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter.DadosDinamicosTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade.EstruturaIntegracaoParametroTO;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ConversorParametroIntegracaoService {

    public String converterDadosDinamicos(List<DadosDinamicosTO> dadosDinamicosList) {
        List<EstruturaIntegracaoParametroTO> parametrosIntegracao = dadosDinamicosList.stream()
                .filter(Objects::nonNull)
                .map(DadosDinamicosTO::getDadosIntegracao)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .filter(dadoIntegracao -> dadoIntegracao.getParametroIntegracao() != null
                        && !dadoIntegracao.getParametroIntegracao().isEmpty())
                .map(dadoIntegracao -> {
                    String jsonParametro = replaceParametro(dadoIntegracao);
                    return JsonUtil.toObject(jsonParametro, EstruturaIntegracaoParametroTO.class);
                })
                .collect(Collectors.toList());

        return montaParametro(parametrosIntegracao);
    }

    public Map<String, List<EstruturaIntegracaoParametroTO>> converterDadosDinamicosNegocio(Collection<DadosDinamicosTO> dadosDinamicosList) {
        return dadosDinamicosList.stream()
                .filter(Objects::nonNull)
                .map(DadosDinamicosTO::getDadosIntegracao)
                .filter(Objects::nonNull)
                .flatMap(dadosIntegracao ->
                        dadosIntegracao.stream()
                                .filter(dadoIntegracao ->
                                        dadoIntegracao.getParametroIntegracao() != null
                                                && !dadoIntegracao.getParametroIntegracao().isEmpty()
                                )
                                .map(dadoIntegracao -> Map.entry(
                                        dadoIntegracao.getName(),
                                        JsonUtil.toObject(
                                                replaceParametro(dadoIntegracao),
                                                EstruturaIntegracaoParametroTO.class
                                        )
                                ))
                )
                .collect(Collectors.groupingBy(
                        Map.Entry::getKey,
                        Collectors.mapping(Map.Entry::getValue, Collectors.toList())
                ));
    }

    public String replaceParametro(DadoIntegracaoTO dadoIntegracaoTO) {
        EstruturaIntegracaoParametroTO parametroTO = JsonUtil.toObject(dadoIntegracaoTO.getParametroIntegracao(), EstruturaIntegracaoParametroTO.class);

        parametroTO.setValor(dadoIntegracaoTO.getValue());

        return JsonUtil.toJson(parametroTO);
    }

    public String montaParametro(List<EstruturaIntegracaoParametroTO> parametrosIntegracao) {
        return JsonUtil.toJson(List.of(new JsonIntegracao(parametrosIntegracao)));
    }

}

