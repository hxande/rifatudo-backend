package br.coop.somoscooperativismo.registro.api.v1.cooperativa;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import br.coop.somoscooperativismo.registro.api.v1.endereco.entidade.Endereco;
import br.coop.somoscooperativismo.registro.api.v1.regularidadecooperativa.RegularidadeCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.DataUtil;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CooperativaListagemTO {

	private Integer id;
	private String cnpj;
	private String numeroRegistroOCB;
	private String razaoSocial;
	private String nomeFantasia;
	private String ufSigla;
	private String ramo;
	private String grau;
	private String situacaoRegistro;
	private Date dataMudancaSituacao;
	private Character regularidadeCooperativa;
	private Date dataAtualizacao;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
	private Date dataRegistro;
	private String ufDestino;
	private String estado;
	private Boolean atualizacaoNaoVisualizada;
//	private String anuarioPreenchido;
	private Boolean solicitacaoInativacao;
	private Integer totalCooperados;
	private Integer totalEmpregados;
	private BigDecimal faturamento;
	private BigDecimal faturamentoExportacao;
	private Integer anoReferencia;
	private Endereco endereco;
	private Endereco enderecoCorrespondencia;
	private String email;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
	private Date dataAberturaProcesso;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "America/Sao_Paulo")
	private Date dataPrazoRegistro;

	public CooperativaListagemTO(Integer id, String numeroRegistroOCB, String cnpj, String razaoSocial,
			String nomeFantasia, String ufSigla, String ramo, String grau, String situacaoRegistro,
			Character regularidadeCooperativa, Date dataAtualizacao, String estado, Boolean atualizacaoNaoVisualizada,
			String ufDestino, Boolean solicitacaoInativacao) {
		super();
		this.id = id;
		this.cnpj = cnpj;
		this.numeroRegistroOCB = numeroRegistroOCB;
		this.razaoSocial = razaoSocial;
		this.nomeFantasia = nomeFantasia;
		this.ufSigla = ufSigla;
		this.ramo = ramo;
		this.grau = grau;
		this.situacaoRegistro = situacaoRegistro;
		this.regularidadeCooperativa = regularidadeCooperativa;
		this.dataAtualizacao = dataAtualizacao;
		this.estado = estado;
		this.ufDestino = ufDestino;
		this.atualizacaoNaoVisualizada = atualizacaoNaoVisualizada;
//		this.anuarioPreenchido = anuarioPreenchido;
		this.solicitacaoInativacao = solicitacaoInativacao;
	}

	public CooperativaListagemTO(Integer id, String numeroRegistroOCB, String cnpj, String razaoSocial,
			String nomeFantasia, String ufSigla, String email, String ramo, String grau, String situacaoRegistro,
			Date dataMudancaSituacao, Character regularidadeCooperativa, Date dataRegistro, Date dataAtualizacao,
			String estado, Boolean atualizacaoNaoVisualizada,
//			String anuarioPreenchido,
			String ufDestino, Boolean solicitacaoInativacao, Integer anoReferencia, Integer totalCooperados,
			Integer totalEmpregados) {
		super();
		this.id = id;
		this.cnpj = cnpj;
		this.numeroRegistroOCB = numeroRegistroOCB;
		this.razaoSocial = razaoSocial;
		this.nomeFantasia = nomeFantasia;
		this.ufSigla = ufSigla;
		this.email = email;
		this.ramo = ramo;
		this.grau = grau;
		this.situacaoRegistro = situacaoRegistro;
		this.dataMudancaSituacao = dataMudancaSituacao;
		this.regularidadeCooperativa = regularidadeCooperativa;
		this.dataAtualizacao = dataAtualizacao;
		this.estado = estado;
		this.ufDestino = ufDestino;
		this.atualizacaoNaoVisualizada = atualizacaoNaoVisualizada;
//		this.anuarioPreenchido = anuarioPreenchido;
		this.solicitacaoInativacao = solicitacaoInativacao;
		this.totalCooperados = totalCooperados;
		this.totalEmpregados = totalEmpregados;
		this.anoReferencia = anoReferencia;
		this.dataRegistro = dataRegistro;
	}

	public CooperativaListagemTO(Integer id, String numeroRegistroOCB, String cnpj, String razaoSocial,
			String nomeFantasia, String ufSigla, String ramo, String grau, String situacaoRegistro,
			Character regularidadeCooperativa, Date dataAtualizacao, String estado, Boolean atualizacaoNaoVisualizada,
			Boolean solicitacaoInativacao) {
		super();
		this.id = id;
		this.cnpj = cnpj;
		this.numeroRegistroOCB = numeroRegistroOCB;
		this.razaoSocial = razaoSocial;
		this.nomeFantasia = nomeFantasia;
		this.ufSigla = ufSigla;
		this.ramo = ramo;
		this.grau = grau;
		this.situacaoRegistro = situacaoRegistro;
		this.regularidadeCooperativa = regularidadeCooperativa;
		this.dataAtualizacao = dataAtualizacao;
		this.estado = estado;
		this.atualizacaoNaoVisualizada = atualizacaoNaoVisualizada;
//		this.anuarioPreenchido = anuarioPreenchido;
		this.solicitacaoInativacao = solicitacaoInativacao;
	}

	public CooperativaListagemTO() {
		super();
	}

//	public String getAnuario() {
//		return this.anuarioPreenchido == null ? "Não preenchido": this.anuarioPreenchido;
//	}

	public List<String> objectToListString(boolean isProcessoTransferenciaUf) {
		List<String> result = null;
		if (isProcessoTransferenciaUf) {
			result = Arrays.asList(this.numeroRegistroOCB,
					this.cnpj != null ? cnpj.replaceAll("\\b(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5")
							: null,
					this.nomeFantasia, this.ramo,
					this.endereco != null && endereco.getMunicipio() != null
							? endereco.getMunicipio().getUf().getSigla()
							: null,
					this.endereco != null && endereco.getMunicipio() != null ? endereco.getMunicipio().getNome() : null,
					this.endereco != null ? endereco.getCep() : null,
					this.endereco != null ? endereco.getBairro() : null,
					this.endereco != null ? endereco.getDescricaoEndereco() : null,
					this.endereco != null ? endereco.getNumero() : null,
					this.endereco != null ? endereco.getComplemento() : null, this.email,
					this.enderecoCorrespondencia != null && enderecoCorrespondencia.getMunicipio() != null
							? enderecoCorrespondencia.getMunicipio().getUf().getSigla()
							: null,
					this.enderecoCorrespondencia != null && enderecoCorrespondencia.getMunicipio() != null
							? enderecoCorrespondencia.getMunicipio().getNome()
							: null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getCep() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getBairro() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getDescricaoEndereco() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getNumero() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getComplemento() : null,
					this.ufDestino, this.grau, NovaSituacaoCooperativaEnum.valueOf(this.situacaoRegistro).getNome(),
					this.dataMudancaSituacao != null ? DataUtil.transformarDataParaString(this.dataMudancaSituacao)
							: null,
					this.regularidadeCooperativa != null
							? RegularidadeCooperativaEnum.valueOf(this.regularidadeCooperativa.toString()).getNome()
							: null,
					this.estado,
					this.dataRegistro != null ? DataUtil.transformarDataParaString(this.dataRegistro) : null,
					this.dataAtualizacao != null ? DataUtil.transformarDataParaString(this.dataAtualizacao) : null,
					this.anoReferencia != null ? this.anoReferencia.toString() : null,
					this.totalCooperados != null ? this.totalCooperados.toString() : null,
					this.totalEmpregados != null ? this.totalEmpregados.toString() : null);
		} else {
			result = Arrays.asList(this.numeroRegistroOCB,
					this.cnpj != null ? cnpj.replaceAll("\\b(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5")
							: null,
					this.nomeFantasia, this.ramo,
					this.endereco != null && endereco.getMunicipio() != null
							? endereco.getMunicipio().getUf().getSigla()
							: null,
					this.endereco != null && endereco.getMunicipio() != null ? endereco.getMunicipio().getNome() : null,
					this.endereco != null ? endereco.getCep() : null,
					this.endereco != null ? endereco.getBairro() : null,
					this.endereco != null ? endereco.getDescricaoEndereco() : null,
					this.endereco != null ? endereco.getNumero() : null,
					this.endereco != null ? endereco.getComplemento() : null, this.email,
					this.enderecoCorrespondencia != null && enderecoCorrespondencia.getMunicipio() != null
							? enderecoCorrespondencia.getMunicipio().getUf().getSigla()
							: null,
					this.enderecoCorrespondencia != null && enderecoCorrespondencia.getMunicipio() != null
							? enderecoCorrespondencia.getMunicipio().getNome()
							: null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getCep() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getBairro() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getDescricaoEndereco() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getNumero() : null,
					this.enderecoCorrespondencia != null ? enderecoCorrespondencia.getComplemento() : null, this.grau,
					NovaSituacaoCooperativaEnum.valueOf(this.situacaoRegistro).getNome(),
					this.dataMudancaSituacao != null ? DataUtil.transformarDataParaString(this.dataMudancaSituacao)
							: null,
					this.regularidadeCooperativa != null
							? RegularidadeCooperativaEnum.valueOf(this.regularidadeCooperativa.toString()).getNome()
							: null,
					this.estado,
					this.dataRegistro != null ? DataUtil.transformarDataParaString(this.dataRegistro) : null,
					this.dataAtualizacao != null ? DataUtil.transformarDataParaString(this.dataAtualizacao) : null,
					this.anoReferencia != null ? this.anoReferencia.toString() : null,
					this.totalCooperados != null ? this.totalCooperados.toString() : null,
					this.totalEmpregados != null ? this.totalEmpregados.toString() : null);
		}
		return result;
	}

}
