package br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas;

import br.coop.somoscooperativismo.ocbcommonsapi.keycloak.KeycloakService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.CooperativaService;
import br.coop.somoscooperativismo.registro.api.v1.cooperativa.entidade.Cooperativa;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.entidade.CooperativaManutencaoAbas;
import br.coop.somoscooperativismo.registro.api.v1.cooperativamanutencaoabas.to.CooperativaManutencaoAbasTO;
import br.coop.somoscooperativismo.registro.api.v1.documentocliente.DocumentoClient;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaBlocoEnum;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.CooperativaPendenciaService;
import br.coop.somoscooperativismo.registro.api.v1.pendencia.ValidacaoPendenciaTO;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMacroEnum;
import br.coop.somoscooperativismo.registro.api.v1.progresso.ProgressoMicroEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CooperativaManutencaoAbasService {

    private final DocumentoClient documentoClient;

    private final CooperativaManutencaoAbasRepository cooperativaManutencaoAbasRepository;

    private final CooperativaService cooperativaService;

    private final CooperativaPendenciaService cooperativaPendenciaService;

    private final KeycloakService keycloakService;


    public CooperativaManutencaoAbasService(CooperativaManutencaoAbasRepository cooperativaManutencaoAbasRepository,
                                            @Lazy CooperativaService cooperativaService, @Lazy CooperativaPendenciaService cooperativaPendenciaService,
                                            KeycloakService keycloakService, DocumentoClient documentoClient) {

        this.cooperativaManutencaoAbasRepository = Objects.requireNonNull(cooperativaManutencaoAbasRepository, "Repository de manutenção das abas não informado");
        this.cooperativaService = Objects.requireNonNull(cooperativaService, "Serviço de cooperativa não informado");
        this.cooperativaPendenciaService = Objects.requireNonNull(cooperativaPendenciaService, "Serviço de pendências não informado");
        this.keycloakService = Objects.requireNonNull(keycloakService, "Serviço do Keycloak não informado");
        this.documentoClient = documentoClient;
    }

    public CooperativaManutencaoAbasTO obterAbaPorCooperativaEAno(Integer idCooperativa, Integer anoCiclo) {
        Optional<CooperativaManutencaoAbas> optManutencaoAba = cooperativaManutencaoAbasRepository.findByIdCooperativaAndAnoCiclo(idCooperativa, anoCiclo);
        CooperativaManutencaoAbasTO retornar = new CooperativaManutencaoAbasTO();
        optManutencaoAba.ifPresent(cooperativaManutencaoAbas -> BeanUtils.copyProperties(cooperativaManutencaoAbas, retornar));
        CooperativaManutencaoAbasTO resultado = optManutencaoAba.isPresent() ? retornar : new CooperativaManutencaoAbasTO(idCooperativa, anoCiclo);
        aplicarAlertaPendenciasAbertas(idCooperativa, resultado);
        aplicarAlertaCamposNaoPreenchidos(idCooperativa, resultado);
        return resultado;
    }

    private void aplicarAlertaCamposNaoPreenchidos(Integer idCooperativa, CooperativaManutencaoAbasTO to) {
        if (Objects.isNull(to)) {
            return;
        }

        if (SituacaoAbaEnum.SALVO_SUCESSO.getId().equals(to.getAbaDocumentos())) {
            validaCamposNaoObrigatoriosDocumentos(idCooperativa, to);
        }
    }

    private void validaCamposNaoObrigatoriosDocumentos(Integer idCooperativa, CooperativaManutencaoAbasTO to) {
        documentoClient.validarDocumentos(idCooperativa, false);
    }

    private void aplicarAlertaPendenciasAbertas(Integer idCooperativa, CooperativaManutencaoAbasTO to) {
        if (Objects.isNull(to)) {
            return;
        }
        Set<AbaEnum> abasComApontamento = EnumSet.noneOf(AbaEnum.class);
        abasComApontamento.addAll(cooperativaPendenciaService.obterAbasComAjusteSolicitado(idCooperativa));
        abasComApontamento.addAll(cooperativaPendenciaService.obterAbasComPendenciaManutencao(idCooperativa));

        to.setAbasComAjusteSolicitado(abasComApontamento.stream().map(AbaEnum::name).collect(Collectors.toList()));

        if (abasComApontamento.contains(AbaEnum.ABA_DOCUMENTOS)) {
            to.setAbaDocumentos(alertaOuPendencia(to.getAbaDocumentos()));
        }
        if (abasComApontamento.contains(AbaEnum.ABA_DADOS_GERAIS)) {
            to.setAbaDadosGerais(alertaOuPendencia(to.getAbaDadosGerais()));
        }
        if (abasComApontamento.contains(AbaEnum.ABA_GOVERNANCA)) {
            to.setAbaGovernanca(alertaOuPendencia(to.getAbaGovernanca()));
        }
        if (abasComApontamento.contains(AbaEnum.ABA_SEGUIMENTOS_FILIAIS)) {
            to.setAbaSegmentacaoFilial(alertaOuPendencia(to.getAbaSegmentacaoFilial()));
        }
        if (abasComApontamento.contains(AbaEnum.ABA_CONTATOS)) {
            to.setAbaContatos(alertaOuPendencia(to.getAbaContatos()));
        }
    }

    private String alertaOuPendencia(String statusAtual) {
        return SituacaoAbaEnum.SALVO_PENDENCIAS.getId().equals(statusAtual)
                ? SituacaoAbaEnum.SALVO_PENDENCIAS.getId()
                : SituacaoAbaEnum.ALERTA.getId();
    }

    public CooperativaManutencaoAbasTO getCooperativaManutencaoAbasTO(Integer idCooperativa, Integer anoCiclo) {
        Optional<CooperativaManutencaoAbas> optManutencaoAba = cooperativaManutencaoAbasRepository.findByIdCooperativaAndAnoCiclo(idCooperativa, anoCiclo);
        return optManutencaoAba.map(this::converterTO).orElse(null);
    }

    public CooperativaManutencaoAbasTO salvarCooperativaAbas(CooperativaManutencaoAbasTO manutencaoAbasTO) {
        if (Objects.isNull(manutencaoAbasTO)) {
            throw new IllegalArgumentException("Objeto de manutenção das abas não informado");
        }

        CooperativaManutencaoAbas manutencaoAba = converterEntidade(manutencaoAbasTO);
        manutencaoAba.setUsuario(keycloakService.getUsername());

        List<String> abas = Arrays.asList(
                manutencaoAba.getAbaContatos(),
                manutencaoAba.getAbaDadosGerais(),
                manutencaoAba.getAbaDocumentos(),
                manutencaoAba.getAbaGovernanca(),
                manutencaoAba.getAbaSegmentacaoFilial()
        );
        if (abas.stream().anyMatch(SituacaoAbaEnum.ALERTA.getId()::equals)) {
            manutencaoAba.setAbaSubmeter(SituacaoAbaEnum.ALERTA.getId());
        }

        return converterTO(cooperativaManutencaoAbasRepository.save(manutencaoAba));
    }

    public void salvarStatusAbasManutencao(int cooperativaId, boolean validado, AbaEnum tipo, boolean validadoNaoObrigatorios) {
        validandoAbaDadosGeraisManutencao(cooperativaId, validado, tipo, validadoNaoObrigatorios);
    }

    public void salvarStatusAbasManutencao(int cooperativaId, boolean validado, AbaEnum tipo) {
        validandoAbaDadosGeraisManutencao(cooperativaId, validado, tipo, true);
    }

    public void marcarAbaComAjusteSolicitadoManutencao(int cooperativaId, AbaEnum tipo) {
        CooperativaManutencaoAbasTO to = getCooperativaManutencaoAbasTO(cooperativaId, getDataAno());
        if (SituacaoAbaEnum.SALVO_PENDENCIAS.getId().equals(situacaoGravada(to, tipo))) {
            return;
        }
        gravarSituacaoAbaManutencao(cooperativaId, tipo, SituacaoAbaEnum.AJUSTES);
    }

    public void salvarStatusAbas(int cooperativaId, boolean validado, AbaEnum tipo, boolean validadoPendencias) {
        Cooperativa cooperativa = cooperativaService.getCooperativa(cooperativaId);
        validandoAbaDadosGerais(cooperativa, validado, tipo, validadoPendencias, true);
    }

    public void salvarStatusAbas(int cooperativaId, boolean validadoObrigatorios, AbaEnum tipo,
            boolean validadoPendencias, boolean validadoNaoObrigatorios) {
        Cooperativa cooperativa = cooperativaService.getCooperativa(cooperativaId);
        validandoAbaDadosGerais(cooperativa, validadoObrigatorios, tipo, validadoPendencias, validadoNaoObrigatorios);
    }

    public void salvarStatusAbas(Cooperativa cooperativa, boolean validado, AbaEnum tipo, boolean validadoPendencias) {
        validandoAbaDadosGerais(cooperativa, validado, tipo, validadoPendencias, true);
    }

    public boolean salvarStatusAbaDocumento(int cooperativaId, boolean validado, AbaEnum tipo, boolean validadoNaoObrigatorios) {
        CooperativaPendenciaBlocoEnum[] lista = new CooperativaPendenciaBlocoEnum[]{
                CooperativaPendenciaBlocoEnum.DOCUMENTOS};

        // ------------- Marcar como Validado ( PENDÊNCIAS ) ---------
        Cooperativa cooperativa = cooperativaService.getCooperativaFilial(cooperativaId);
        validarCooperativa(cooperativa);
        ProgressoMicroEnum microPesquisar = obterProgressoParaValidacao(cooperativa);
        if (Objects.nonNull(microPesquisar)) {
            cooperativaPendenciaService.marcarAjustesComoValidados(cooperativa.getId(),
                    CooperativaPendenciaBlocoEnum.DOCUMENTOS.name(), microPesquisar);
        }

        // validadoPendencias = aprovado ou solicitação de ajustes
        boolean validadoPendencias = cooperativaService.validarStatusAbaDocumento(cooperativa, lista);

        validandoAbaDadosGerais(cooperativa, validado, tipo, validadoPendencias, validadoNaoObrigatorios);

        // validado = preenchimento das informações brigatórias
        boolean validacaoFinal = validadoPendencias && validado;

        Optional<CooperativaManutencaoAbas> optManutencaoAba = cooperativaManutencaoAbasRepository.findByIdCooperativaAndAnoCiclo(cooperativaId, getDataAno());

        validacaoFinal = optManutencaoAba.map(cooperativaManutencaoAbas -> !(Objects.equals(cooperativaManutencaoAbas.getAbaDocumentos(), SituacaoAbaEnum.SALVO_PENDENCIAS.getId())
                || Objects.equals(cooperativaManutencaoAbas.getAbaDocumentos(), SituacaoAbaEnum.AJUSTES.getId()))).orElseGet(() -> validadoPendencias && validado);

        return validacaoFinal;
    }

    private ProgressoMicroEnum obterProgressoParaValidacao(Cooperativa cooperativa) {
        if (Objects.isNull(cooperativa)) {
            return null;
        }

        if (ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2.equals(cooperativa.getProgressoMicro())) {
            return ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1;
        }
        return ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2.equals(cooperativa.getProgressoMicro())
                ? ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1
                : null;
    }

    private CooperativaManutencaoAbasTO converterTO(CooperativaManutencaoAbas entidade) {
        if (Objects.isNull(entidade)) {
            return null;
        }
        CooperativaManutencaoAbasTO cooperativaManutencaoAbasTO = new CooperativaManutencaoAbasTO();
        BeanUtils.copyProperties(entidade, cooperativaManutencaoAbasTO);
        return cooperativaManutencaoAbasTO;
    }

    private CooperativaManutencaoAbas converterEntidade(CooperativaManutencaoAbasTO to) {
        if (Objects.isNull(to)) {
            return null;
        }
        CooperativaManutencaoAbas cooperativaManutencaoAbas = new CooperativaManutencaoAbas();
        BeanUtils.copyProperties(to, cooperativaManutencaoAbas);
        return cooperativaManutencaoAbas;
    }

    private void validandoAbaDadosGerais(Cooperativa cooperativa, boolean validado, AbaEnum tipo, boolean validadoPendencias,
            boolean validadoNaoObrigatorios) {
        validarCooperativa(cooperativa);

        SituacaoAbaEnum situacaoAbaEnum;

        if (!this.keycloakService.isTipoEntidadeCooperativa()
                && Objects.nonNull(cooperativa.getProgressoMacro())
                && cooperativa.getProgressoMacro().equals(ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2)
        ) {
            situacaoAbaEnum = validacaoPreenchimentoEPendencia(cooperativa.getId(), validado, validadoPendencias, tipo);
        } else {

            if (validado && validadoNaoObrigatorios) {
                situacaoAbaEnum = SituacaoAbaEnum.SALVO_SUCESSO;
            } else if (validado && !validadoNaoObrigatorios) {
                situacaoAbaEnum = SituacaoAbaEnum.SALVO_PENDENCIAS;
            } else {
                situacaoAbaEnum = SituacaoAbaEnum.ALERTA;
            }
        }

        if (situacaoAbaEnum != SituacaoAbaEnum.SALVO_PENDENCIAS
                && cooperativaPendenciaService.abaManutencaoPossuiPendencia(cooperativa.getId(), tipo)) {
            situacaoAbaEnum = SituacaoAbaEnum.ALERTA;
        }

        CooperativaManutencaoAbasTO to;
        to = getCooperativaManutencaoAbasTO(cooperativa.getId(), getDataAno());
        situacaoAbaEnum = preservarAjusteNaoTratado(to, tipo, situacaoAbaEnum, validadoPendencias);
        if (Objects.nonNull(to)) {
            if (situacaoJaGravada(to, tipo, situacaoAbaEnum)) {
                return;
            }
            validEnum(tipo, to, situacaoAbaEnum);
            to.setDataAlteracao(new Date());
            to.setUsuario(keycloakService.getUFUsuario());
            salvarCooperativaAbas(to);
        } else {
            CooperativaManutencaoAbasTO novoTo = new CooperativaManutencaoAbasTO(cooperativa.getId(), getDataAno());
            novoTo.setIdCooperativa(cooperativa.getId());
            novoTo.setAnoCiclo(getDataAno());
            validEnum(tipo, novoTo, situacaoAbaEnum);
            novoTo.setUsuario(keycloakService.getUFUsuario());
            salvarCooperativaAbas(novoTo);
        }

    }

    private void validandoAbaDadosGeraisManutencao(int cooperativaId, boolean validado, AbaEnum tipo, boolean validadoNaoObrigatorios) {
        SituacaoAbaEnum situacaoAbaEnum = null;

        if (validado && validadoNaoObrigatorios) {
            situacaoAbaEnum = SituacaoAbaEnum.SALVO_SUCESSO;
        } else if (validado && !validadoNaoObrigatorios) {
            situacaoAbaEnum = SituacaoAbaEnum.SALVO_PENDENCIAS;
        } else {
            situacaoAbaEnum = SituacaoAbaEnum.ALERTA;
        }

        if (cooperativaPendenciaService.abaManutencaoPossuiPendencia(cooperativaId, tipo)) {
            situacaoAbaEnum = SituacaoAbaEnum.ALERTA;
        }

        gravarSituacaoAbaManutencao(cooperativaId, tipo, situacaoAbaEnum);
    }

    protected void gravarSituacaoAbaManutencao(int cooperativaId, AbaEnum tipo, SituacaoAbaEnum situacaoAbaEnum) {
        CooperativaManutencaoAbasTO to;
        to = getCooperativaManutencaoAbasTO(cooperativaId, getDataAno());
        if (Objects.nonNull(to)) {
            if (situacaoJaGravada(to, tipo, situacaoAbaEnum)) {
                return;
            }
            validEnum(tipo, to, situacaoAbaEnum);
            to.setDataAlteracao(new Date());
            to.setUsuario(keycloakService.getUFUsuario());
            salvarCooperativaAbas(to);
        } else {
            CooperativaManutencaoAbasTO novoTo = new CooperativaManutencaoAbasTO(cooperativaId, getDataAno());
            novoTo.setIdCooperativa(cooperativaId);
            novoTo.setAnoCiclo(getDataAno());
            validEnum(tipo, novoTo, situacaoAbaEnum);
            novoTo.setUsuario(keycloakService.getUFUsuario());
            salvarCooperativaAbas(novoTo);
        }
    }

    private static SituacaoAbaEnum preservarAjusteNaoTratado(CooperativaManutencaoAbasTO to, AbaEnum tipo,
            SituacaoAbaEnum situacaoAbaEnum, boolean validadoPendencias) {
        if (validadoPendencias || Objects.isNull(to) || SituacaoAbaEnum.SALVO_SUCESSO != situacaoAbaEnum) {
            return situacaoAbaEnum;
        }
        return SituacaoAbaEnum.AJUSTES.getId().equals(situacaoGravada(to, tipo))
                ? SituacaoAbaEnum.AJUSTES
                : situacaoAbaEnum;
    }

    private static boolean situacaoJaGravada(CooperativaManutencaoAbasTO to, AbaEnum tipo,
            SituacaoAbaEnum situacaoAbaEnum) {
        return Objects.nonNull(situacaoAbaEnum) && Objects.equals(situacaoGravada(to, tipo), situacaoAbaEnum.getId());
    }

    private static String situacaoGravada(CooperativaManutencaoAbasTO to, AbaEnum tipo) {
        if (Objects.isNull(to) || Objects.isNull(tipo)) {
            return null;
        }
        switch (tipo) {
            case ABA_DOCUMENTOS:
                return to.getAbaDocumentos();
            case ABA_DADOS_GERAIS:
                return to.getAbaDadosGerais();
            case ABA_GOVERNANCA:
                return to.getAbaGovernanca();
            case ABA_SEGUIMENTOS_FILIAIS:
                return to.getAbaSegmentacaoFilial();
            case ABA_CONTATOS:
                return to.getAbaContatos();
            case ABA_SUBMETER:
                return to.getAbaSubmeter();
            default:
                return null;
        }
    }

    private static void validEnum(AbaEnum tipo, CooperativaManutencaoAbasTO to, SituacaoAbaEnum situacaoAbaEnum) {
        if (Objects.isNull(tipo)) {
            throw new IllegalArgumentException("Tipo da aba não pode ser nulo");
        }
        if (Objects.isNull(to)) {
            throw new IllegalArgumentException("Objeto de manutenção das abas não pode ser nulo");
        }
        if (Objects.isNull(situacaoAbaEnum)) {
            throw new IllegalArgumentException("Situação da aba não pode ser nula");
        }

        switch (tipo) {
            case ABA_DOCUMENTOS:
                to.setAbaDocumentos(situacaoAbaEnum.getId());
                break;
            case ABA_DADOS_GERAIS:
                to.setAbaDadosGerais(situacaoAbaEnum.getId());
                break;
            case ABA_GOVERNANCA:
                to.setAbaGovernanca(situacaoAbaEnum.getId());
                break;
            case ABA_SEGUIMENTOS_FILIAIS:
                to.setAbaSegmentacaoFilial(situacaoAbaEnum.getId());
                break;
            case ABA_CONTATOS:
                to.setAbaContatos(situacaoAbaEnum.getId());
                break;
            case ABA_SUBMETER:
                to.setAbaSubmeter(situacaoAbaEnum.getId());
                break;
            default:
        }
    }

    private int getDataAno() {
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        return calendar.get(Calendar.YEAR);
    }

    private SituacaoAbaEnum validacaoPreenchimentoEPendencia(int cooperativaId, boolean validado, boolean validadoPendencias, AbaEnum tipo) {

        if (!validado) {
            return SituacaoAbaEnum.ALERTA;
        }

        ValidacaoPendenciaTO validacao = cooperativaPendenciaService.obterPendenciasAbas(cooperativaId);
        validacao = cooperativaPendenciaService.getCadastroValidacaoPendenciaTO(cooperativaId, validacao);

        if (Objects.isNull(validacao)) {
            throw new IllegalStateException("A validação das pendências não foi retornada");
        }
        if (Objects.isNull(tipo)) {
            throw new IllegalArgumentException("Tipo da aba não pode ser nulo");
        }

        SituacaoAbaEnum situacaoAbaEnum = null;

        switch (tipo) {
            case ABA_DOCUMENTOS:
                situacaoAbaEnum = validaCamposDocumentos(validacao, validadoPendencias);
                break;
            case ABA_DADOS_GERAIS:
                situacaoAbaEnum = validaCamposDadosGerais(validacao, validadoPendencias);
                break;
            case ABA_GOVERNANCA:
                situacaoAbaEnum = validaCamposGovernanca(validacao, validadoPendencias);
                break;
            case ABA_SEGUIMENTOS_FILIAIS:
                situacaoAbaEnum = validaCamposSeguimentosFiliais(validacao, validadoPendencias);
                break;
            case ABA_CONTATOS:
                situacaoAbaEnum = validaCamposContatos(validacao, validadoPendencias);
                break;
            default:
        }

        return situacaoAbaEnum;
    }

    private SituacaoAbaEnum validaCamposDocumentos(ValidacaoPendenciaTO validacao, boolean validadoPendencias) {
        validarRetornoValidacao(validacao);
        var documentos = validacao.getDocumentos();
        Boolean campoValidado = Objects.nonNull(documentos) ? documentos.getValidado() : null;
        return definirSituacaoCampo(campoValidado, validadoPendencias);
    }

    private SituacaoAbaEnum validaCamposDadosGerais(ValidacaoPendenciaTO validacao, boolean validadoPendencias) {
        validarRetornoValidacao(validacao);
        var dadosGerais = validacao.getDadosGerais();
        Boolean campoValidado = Objects.nonNull(dadosGerais) ? dadosGerais.getValidado() : null;
        return definirSituacaoCampo(campoValidado, validadoPendencias);
    }

    private SituacaoAbaEnum validaCamposGovernanca(ValidacaoPendenciaTO validacao, boolean validadoPendencias) {
        validarRetornoValidacao(validacao);
        var governanca = validacao.getGovernanca();
        Boolean campoValidado = Objects.nonNull(governanca) ? governanca.getAbaPreenchida() : null;
        return definirSituacaoCampo(campoValidado, validadoPendencias);
    }

    private SituacaoAbaEnum validaCamposSeguimentosFiliais(ValidacaoPendenciaTO validacao, boolean validadoPendencias) {
        validarRetornoValidacao(validacao);
        var negocio = validacao.getNegocio();
        Boolean campoValidado = Objects.nonNull(negocio) ? negocio.getValidado() : null;
        return definirSituacaoCampo(campoValidado, validadoPendencias);
    }

    private SituacaoAbaEnum validaCamposContatos(ValidacaoPendenciaTO validacao, boolean validadoPendencias) {
        validarRetornoValidacao(validacao);
        var contatos = validacao.getContatos();
        Boolean campoValidado = Objects.nonNull(contatos) ? contatos.getValidado() : null;
        return definirSituacaoCampo(campoValidado, validadoPendencias);
    }

    private static SituacaoAbaEnum definirSituacaoCampo(
            Boolean campoValidado,
            boolean validadoPendencias) {
        if (Boolean.FALSE.equals(campoValidado)) {
            return SituacaoAbaEnum.SALVO_PENDENCIAS;
        }
        if (!validadoPendencias) {
            return SituacaoAbaEnum.AJUSTES;
        }
        return SituacaoAbaEnum.SALVO_SUCESSO;
    }

    private static void validarRetornoValidacao(ValidacaoPendenciaTO validacao) {
        if (Objects.isNull(validacao)) {
            throw new IllegalStateException("A validação das pendências não foi retornada");
        }
    }

    private static void validarCooperativa(Cooperativa cooperativa) {
        if (Objects.isNull(cooperativa)) {
            throw new IllegalStateException("A cooperativa não foi encontrada");
        }
    }

}