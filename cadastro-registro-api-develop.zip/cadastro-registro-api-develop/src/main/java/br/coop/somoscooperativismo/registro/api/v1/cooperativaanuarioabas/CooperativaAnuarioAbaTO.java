package br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas;

import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.entidade.CooperativaAnuarioAbas;
import lombok.Data;

@Data
public class CooperativaAnuarioAbaTO {

	private Integer id;
	private Integer anoCiclo;
	private Integer idCooperativa;
	private String abaNome;
	private Boolean abaPreenchida;
	private String usuario;
	
	public CooperativaAnuarioAbaTO(CooperativaAnuarioAbas cooperativaAnuarioAbas) {
		this.id = cooperativaAnuarioAbas.getId();
		this.anoCiclo = cooperativaAnuarioAbas.getAnoCiclo();
		this.idCooperativa = cooperativaAnuarioAbas.getIdCooperativa();
		this.abaNome = cooperativaAnuarioAbas.getAbaNome();
		this.abaPreenchida = cooperativaAnuarioAbas.getAbaPreenchida();
		this.usuario = cooperativaAnuarioAbas.getUsuario();
	}
}
