package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.entidade;

import lombok.Data;

import java.util.List;

@Data
public class AbaDataInterface {
    private String id;
    private Integer idQuadro;
    private Integer idQuadroAuxiliar;
    private String name;
    private String title;
    private String subTitle;
    private boolean hasIcon;
    private String icon;
    private boolean hasInfo;
    private String infoText;
    List<List<AbaCampos>> fields;

}
