package br.coop.somoscooperativismo.registro.api.v1.criterioassociacao;

import lombok.Data;

@Data
public class CriterioAssociacaoCooperativaReadOnlyTO {
    private Integer id;
    private Integer idCriterioAssociacao;
    private Integer idCooperativa;
    private String nomeCriterioAssociacao;
    private String nomeCooperativa;

}

