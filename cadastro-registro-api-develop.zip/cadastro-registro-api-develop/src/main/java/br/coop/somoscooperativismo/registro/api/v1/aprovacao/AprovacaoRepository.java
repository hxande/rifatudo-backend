package br.coop.somoscooperativismo.registro.api.v1.aprovacao;

import br.coop.somoscooperativismo.registro.api.v1.aprovacao.entidade.Aprovacao;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AprovacaoRepository extends JpaRepository<Aprovacao, Integer>{

	@Query("select ap from Aprovacao ap where ap.ano = :ano AND ap.cooperativa.id = :idCooperativa AND ap.dataAtualizacao IS NOT NULL")
	Aprovacao obterAprovacaoCooperativa(Integer ano, Integer idCooperativa);
	
	@Query("select ap from Aprovacao ap where ap.ano = :ano AND ap.cooperativa.id = :idCooperativa")
	Aprovacao obterAprovacaoCooperativaSemDataAtualizacao(Integer ano, Integer idCooperativa);
	
	@Query("select ap from Aprovacao ap where ap.cooperativa.id = :idCooperativa order by ap.id desc")
	List<Aprovacao> getUltimasAprovacoes(Integer idCooperativa);
	
	@Query("select ap from Aprovacao ap where ap.cooperativa.id = :idCooperativa AND ap.dataAtualizacao IS NOT NULL order by ap.dataAtualizacao desc")
	List<Aprovacao> getUltimaAtualizacaoCooperativa(Integer idCooperativa, Pageable page);
	
}
