package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums;

public enum AbaDataTypeEnum {

    ACCORDION("accordion"),
    INPUT("input"),
    CHECKBOX("checkbox"),
    TEXT_AREA("textArea"),
    RADIO("radio"),
    MULT_CHECKBOX("multCheckbox"),
    SELECT("select"),
    TAG("tag"),
    DIVIDER("divider"),
    SECTION("section"),
    HTML("html"),
    SELECT_BUTTON("selectButton"),
    DADOS_COMPLEMENTARES("dadosComplementares");

    private String chave;

    public static AbaDataTypeEnum getEnum(String valor) {
        for (AbaDataTypeEnum abaDataTypeEnum : AbaDataTypeEnum.values()) {
            if (abaDataTypeEnum.getChave().equals(valor)) {
                return abaDataTypeEnum;
            }
        }
        return null;
    }

    AbaDataTypeEnum(String chave) {
        this.chave = chave;
    }

    public String getChave() {
        return chave;
    }

}
