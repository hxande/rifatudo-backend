# Glossário

## Termos do domínio cooperativista

| Termo | Definição |
|---|---|
| **OCB** | Organização das Cooperativas Brasileiras. Entidade nacional que representa o cooperativismo. |
| **OCB Estadual / UF** | Representação regional da OCB. Atua como analista do registro de cooperativas da sua UF. |
| **SESCOOP** | Serviço Nacional de Aprendizagem do Cooperativismo. Mantém o sistema SOUCOOP. |
| **Cooperativa** | Sociedade autônoma de pessoas unidas voluntariamente. Entidade central do sistema. |
| **Registro** | Processo formal de inscrição de uma cooperativa na OCB. |
| **Anuário** | Declaração anual obrigatória de dados econômicos e sociais. |
| **Quadro social** | Conjunto de pessoas físicas e jurídicas associadas à cooperativa. |
| **Governança** | Composição dos órgãos administrativos (Conselho Administrativo, Fiscal, Diretoria). |
| **Filiada** | Cooperativa vinculada a uma federação ou central. |
| **Filial** | Estabelecimento secundário da cooperativa. |
| **Transferência de UF** | Mudança de jurisdição entre OCB Estaduais. |
| **Ramo cooperativista** | Categoria do cooperativismo (Agropecuário, Crédito, Saúde, Trabalho, etc.). |
| **Taxa de registro** | Boleto emitido para custear o processo de registro. |
| **Apontamento** | Observação de analista OCB sobre o processo de registro. |
| **Mandato** | Período de exercício de um cargo na governança. |
| **Critério de associação** | Regra para uma cooperativa se associar à OCB. |
| **Censo** | Coleta agregada de dados das cooperativas. |
| **GDH** | Gestão de Desenvolvimento Humano — sistema do SESCOOP integrado ao SOUCOOP. |

## Termos técnicos do frontend

| Termo | Definição |
|---|---|
| **SPA** | Single Page Application. Aplicação renderizada client-side. |
| **Lazy module** | NgModule carregado sob demanda via `loadChildren()`. Reduz bundle inicial. |
| **Standalone component** | Componente Angular sem NgModule (Angular 14+). Não usado predominantemente neste projeto ainda. |
| **Path alias** | Atalho de import configurado em `tsconfig.json` (ex.: `@core/*`). |
| **Interceptor** | Classe Angular que intercepta requisições HTTP. Aqui: `AuthHttpInterceptor`, `MessageHttpInterceptor`. |
| **AuthGuard** | Implementação de `CanActivate` que protege rotas. |
| **TO** | Transport Object. DTO no padrão SESCOOP. Sufixo obrigatório nas classes (ex.: `CooperativaTO`). |
| **FiltroTO** | TO usado para parâmetros de busca paginada. |
| **public-includes** | Submódulo Git compartilhado entre todos os frontends OCB. Reside em `src/public/`. |
| **Submódulo Git** | Repositório embutido em outro. Requer `git submodule init && update`. |
| **PrimeNG** | Biblioteca de componentes UI corporativa. Tema base `lara-light-blue`. |
| **PrimeFlex** | Sistema de grid utilitário acompanha o PrimeNG. |
| **CQRS leve** | Separação entre API de escrita (`-api`) e leitura (`-leitura-api`). |
| **Bearer token** | Token JWT injetado em `Authorization` por interceptor. |
| **PKCE** | Proof Key for Code Exchange. Padrão OAuth2 usado pelo Keycloak. |
| **Multi-entidade** | Capacidade do usuário atuar em mais de uma entidade. Rota `/selecionar-entidade`. |
| **environment.ts** | Arquivo de configuração por ambiente (`dev`, `hmlg`, `prod`). |
| **backendEnv** | Default global do ambiente backend (`local | hmlg | trt`). |
| **apisEnv** | Mapa granular para apontar APIs específicas para ambientes distintos. |
| **HMLG** | Homologação. Ambiente pré-produção. |
| **PRD** | Produção. |
| **Liquibase** | Ferramenta de migração de banco usada pelos backends — referenciada aqui apenas para contexto. |
| **Hibernate Envers** | Auditoria de mudanças no backend; relevante para LGPD e rastreabilidade. |
| **Spring Cloud Config** | Servidor de configuração externalizada usado pelos backends. |
| **OpenShift** | Plataforma de container do ecossistema OCB. |
| **Power BI Embedded** | Dashboard analítico embutido via `powerbi-client-angular`. |
| **CKEditor / Quill** | Editores de texto rico usados em diferentes telas. |
| **ng-idle** | Biblioteca de detecção de inatividade. |
| **ng2-currency-mask** | Máscara de moeda em inputs numéricos. |
| **file-saver** | Helper para salvar arquivos no client. |
| **puppeteer** | Headless Chromium; uso pontual no projeto. |
