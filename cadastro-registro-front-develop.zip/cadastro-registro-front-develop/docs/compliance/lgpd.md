# Conformidade LGPD — SOUCOOP Front

Este documento mapeia o tratamento de dados pessoais realizado pelo `cadastro-registro-front` e os gaps conhecidos em relação à Lei nº 13.709/2018 (LGPD).

## 1. Dados pessoais tratados

| Categoria | Origem | Onde aparece |
|---|---|---|
| **CPF** | Representantes legais, quadro social, contadores | `features/cooperativa/quadro-social`, `features/cooperativa/responsaveis`, `features/registro/governanca` |
| **Nome completo** | Pessoas físicas vinculadas | Diversas telas de governança e quadro social |
| **Endereço** | Pessoas físicas e cooperativa | `features/cooperativa/dados-gerais`, filiais |
| **E-mail** | Contato de pessoas físicas/jurídicas | Cadastro de responsáveis, confirmação de e-mail |
| **Telefone** | Contato | Idem |
| **Dados bancários** | Cooperativa | Dados gerais |

> CNPJ é dado de pessoa jurídica e não é PII no sentido da LGPD, mas é tratado com cuidado equivalente para auditoria.

## 2. Bases legais aplicáveis

- **Cumprimento de obrigação legal/regulatória** (art. 7º, II) — registro cooperativista é regulado.
- **Execução de contrato** (art. 7º, V) — associação à OCB.
- **Exercício regular de direitos** (art. 7º, VI) — análise e aprovação de processos.

## 3. Controles implementados

| Controle | Implementação |
|---|---|
| AuthN forte | Keycloak OAuth2 PKCE |
| AuthZ por papel | `AuthGuardService` + `AUTH_GUARD_ROUTE_MAPS` |
| Multi-entidade | Rota `/selecionar-entidade` evita vazamento cross-tenant |
| Transporte | HTTPS terminado no OpenShift Route |
| Auditoria | Hibernate Envers no backend (front preserva identidade no Bearer) |
| Validação de identidade | Validação algorítmica de CPF/CNPJ (CNPJ alfanumérico) via `@utils`/`public-includes` e serviços por componente — ver [ADR 0006](../architecture/decisions/0006-cnpj-alfanumerico.md) |

## 4. Gaps identificados ⚠️

### 4.1 Máscara de CPF/CNPJ — parcialmente endereçado ⚠️ Média

- Em 2026-06 a máscara de CPF/CNPJ foi **padronizada nas telas e relatórios** (agora também com suporte a CNPJ alfanumérico — ver [ADR 0006](../architecture/decisions/0006-cnpj-alfanumerico.md)).
- **Risco residual:** confirmar cobertura em todos os inputs de CPF de quadro social/responsáveis e ofuscação onde aplicável.
- **Recomendação:** garantir máscara em 100% dos inputs de CPF e consolidar a validação em utilitário único.

### 4.2 Tokens em localStorage ⚠️ Alta

- Comportamento padrão do `keycloak-js`.
- **Risco:** XSS pode exfiltrar token JWT contendo claims do usuário.
- **Mitigação imediata:** auditar uso de `bypassSecurityTrust*` e fontes externas (CKEditor, Quill) para garantir CSP.
- **Mitigação estrutural:** avaliar BearerOnly + token em memória.

### 4.3 Sem consent manager ⚠️ Média

- Não há banner LGPD nem registro de consentimento client-side.
- **Contexto:** o sistema é interno, autenticado e regulamentado — bases legais aplicáveis dispensam consentimento na maioria dos fluxos. Mesmo assim, é recomendado um aviso explícito sobre tratamento de dados após o login.
- **Recomendação:** alinhar com DPO; eventual banner deve apontar para a política de privacidade da OCB.

### 4.4 Logs com PII potencial ⚠️ Alta

- 15+ componentes contêm `console.log/error` (ver [08-technical-debt](../architecture/08-technical-debt.md)).
- **Risco:** dados sensíveis podem chegar ao console do browser do usuário e a sistemas que coletem `console.*`.
- **Recomendação:** ESLint rule `no-console: error` + logger centralizado com nível e máscara de PII.

### 4.5 Exportações com PII

- Excel/PDF de quadro social e governança contêm CPF e dados pessoais.
- **Controle:** download exige autenticação e autorização; backend aplica RBAC.
- **Recomendação:** registrar trilha de download (auditoria backend), avaliar marca d'água no PDF.

## 5. Direitos dos titulares

O front não implementa portal próprio de exercício de direitos LGPD. Solicitações de acesso, correção ou exclusão são tratadas pela DPO OCB pelos canais oficiais. Front auxilia indiretamente:

- Pessoa física pode atualizar seus próprios dados via `responsaveis`/`quadro-social` quando logada e autorizada.
- Histórico (`historico-processo-registro`) atende ao direito de informação.

## 6. Retenção

Retenção é responsabilidade dos backends. O front não armazena PII além do necessário para preencher formulários em sessão.

## 7. Incidentes

⚠️ Sem Sentry/Crashlytics. Erros em produção que possam indicar vazamento são invisíveis. Ver [Observabilidade](../architecture/07-quality.md) e [débitos técnicos](../architecture/08-technical-debt.md).

## 8. Recomendações priorizadas

1. **Curto prazo:** ESLint `no-console: error` + remoção dos logs existentes.
2. **Curto prazo:** máscara visual de CPF/CNPJ.
3. **Médio prazo:** Sentry com scrubbing de PII configurado.
4. **Médio prazo:** revisão de armazenamento de token (memória vs localStorage).
5. **Longo prazo:** consent manager + política de privacidade visível pós-login.
