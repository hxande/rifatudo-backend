# Documentação Técnica — cadastro-registro-front (SOUCOOP)

Frontend Angular do sistema SOUCOOP de Cadastro e Registro de Cooperativas do Sescoop/OCB. Esta documentação consolida visão arquitetural (arc42), modelo C4, decisões (ADR), conformidade LGPD e referências operacionais.

## Visão geral

O SOUCOOP é a interface web utilizada por cooperativas, OCB Estaduais e OCB Nacional para conduzir o ciclo completo de registro, manutenção cadastral, anuário, governança, quadro social, filiais, transferência de UF e relatórios. A aplicação consome múltiplas APIs do ecossistema SESCOOP-OCB e é autenticada via Keycloak com suporte a múltiplas entidades por usuário.

## Stack

| Camada | Tecnologia | Versão |
|---|---|---|
| Framework | Angular | 18.2.13 |
| Linguagem | TypeScript | 5.4.5 |
| Reatividade | RxJS | 7.4.0 |
| UI | PrimeNG / PrimeFlex | 17.18.15 / 3.3.0 |
| Ícones | FontAwesome / Material Icons | 6.4.0 |
| Build | Angular CLI / @angular-devkit | 18.2.20 |
| Estilos | Sass | 1.51.0 |
| Testes | Karma + Jasmine + Istanbul | — |
| Lint | ESLint + @angular-eslint | 8.57.0 / 14.4.0 ⚠️ |
| Auth | Keycloak | OAuth2 PKCE |
| Especialistas | CKEditor 5, Quill, ng-idle, powerbi-client-angular, puppeteer | — |

## Como navegar

| Pasta | Conteúdo |
|---|---|
| [`architecture/`](./architecture/) | Visão arc42 (overview, restrições, contexto, blocos, runtime, deploy, qualidade, débitos) |
| [`architecture/decisions/`](./architecture/decisions/) | ADRs aceitos (0001–0006) |
| [`architecture/diagrams/`](./architecture/diagrams/) | Diagramas C4 (Contexto, Containers, Componentes) em Mermaid |
| [`modules/`](./modules/) | Documentação por feature (administracao, cooperativa, registro, relatorio, transferencia-uf) |
| [`compliance/lgpd.md`](./compliance/lgpd.md) | Mapa LGPD e gaps |
| [`api/endpoints.md`](./api/endpoints.md) | Padrões de consumo das APIs backend |
| [`glossary.md`](./glossary.md) | Termos cooperativistas e técnicos |

## Setup rápido

```bash
git clone <repo>
cd cadastro-registro-front
git submodule init && git submodule update   # Obrigatório — pulls public-includes
npm ci
npm start                                     # http://localhost:4200
```

⚠️ O diretório `src/public/` é um **submódulo Git** (`public-includes`). Sem `git submodule update` o build falha — ver [ADR 0004](./architecture/decisions/0004-public-includes-submodule.md).

## Scripts principais

| Script | Função |
|---|---|
| `npm start` | Dev server (4GB heap) |
| `npm run start:prod` | Dev server apontando para produção |
| `npm run build` | Build de produção |
| `npm test` | Testes Karma watch |
| `npm run test-coverage` | Cobertura via Istanbul |
| `npm run lint` / `lint-fix` | ESLint |
| `npm run analyze` | webpack-bundle-analyzer |
| `npm run sonar` | Análise SonarQube |
| `npm run lighthouse` | Auditoria Lighthouse |
| `npm run purgecss` | Remove CSS não utilizado |

## Pilares Sescoop/OCB (adaptados para frontend)

1. **Harmonia do projeto** — convenções de nomenclatura `api-<entity>.service.ts`, `*Component`, `*TO`, path aliases padronizados.
2. **Componentização** — features lazy-loaded, componentes compartilhados em `shared/` e `public/gui/`.
3. **Integração com APIs** — services dedicados por recurso, interceptors transversais (auth + mensagens).
4. **Facilidades/OTS** — PrimeNG, CKEditor, Quill, powerbi-client, ng-idle reutilizados ao invés de reimplementar.
5. **Segurança** — Keycloak OAuth2, AuthGuard por rota, sanitização nativa Angular, HTTPS via Keycloak.
6. **Observabilidade** — ⚠️ ainda imatura; ver [08-technical-debt](./architecture/08-technical-debt.md).
7. **Gestão de dependências** — package-lock fixado; auditar trimestralmente.
8. **Evolução do stack** — Angular 18 + standalone-ready; migração futura para signals e standalone components.

## Convenções

- **Idioma:** código técnico em inglês; domínio em português (`Cooperativa`, `QuadroSocialTO`); mensagens pt-BR.
- **Nomenclatura:** `api-<entity>.service.ts`, `*.component.ts`, `*TO.ts`, `Enum*.ts`.
- **Estrutura:** feature modules lazy-loaded em `src/app/features/`.
- **Path aliases:** `@core/*`, `@shared/*`, `@gui/*`, `@auth/*`, `@utils/*`, `@cadastro-registro-api/*`, `@cadastro-registro-leitura-api/*`, `@cadastro-registro/*`, `@documentacao-api/*`, `@localizacao-api/*`, `@upload-api/*`, `@boleto-api/*`, `@gerencia-usuario-api/*`, `@desempenho-api/*`, `@relatorio-api/*` (ver `tsconfig.json`).

## Atualização desta documentação

Esta documentação é versionada junto ao código. Sempre que houver mudança arquitetural relevante:
1. Atualize o arquivo arc42 correspondente.
2. Registre uma nova ADR (não edite ADRs aceitos — crie superseding).
3. Atualize diagramas C4 e o glossário se novos termos surgirem.
4. Reflita débitos técnicos em [`08-technical-debt.md`](./architecture/08-technical-debt.md).

---

*Última atualização: 2026-06-19 — revisão contra o `develop` atual (~51 commits desde a geração inicial de 2026-05-15). Conferido: stack inalterada (Angular 18.2.13 / TypeScript 5.4.5 / PrimeNG 17.18.15 / RxJS 7.4.0 — a migração Angular 14→18 já estava consolidada na linha de base anterior). Novidades do período: suporte a CNPJ alfanumérico (novo [ADR 0006](./architecture/decisions/0006-cnpj-alfanumerico.md)), padronização de máscara visual de CPF/CNPJ, relatório Quadro Social por UF, controle de ativação/inativação de membros na governança e checkbox/endpoint Diretoria GDH.*
