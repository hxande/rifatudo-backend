# ADR 0003 — Lazy-loading por feature module

- **Status:** Aceito
- **Data:** 2026-05-15
- **Decisores:** Tech Lead Frontend OCB

## Contexto

O SOUCOOP é uma aplicação ampla, com features de naturezas distintas: administração, cooperativa, registro, relatório, transferência de UF, exportação, dashboard inicial. Carregar todo o código no bootstrap inicial penalizaria o tempo de carregamento e o consumo de banda dos usuários cooperativistas, muitos dos quais acessam de redes corporativas restritas ou conexões 4G.

Angular Router suporta nativamente carregamento sob demanda via `loadChildren()`. Cada feature é um NgModule independente com roteamento próprio.

## Decisão

Toda feature de negócio fica em **NgModule lazy** em `src/app/features/<feature>/` e é referenciada apenas no `app-routing.module.ts` via:

```ts
{
  path: 'cooperativa',
  loadChildren: () =>
    import('./features/cooperativa/cooperativa.module').then(m => m.CooperativaModule),
  canActivate: [AuthGuardService]
}
```

Módulos transversais (`core`, `shared`) **não** são lazy. Os componentes em `shared/` são importados pelos módulos que precisam deles, evitando inflar o bundle inicial.

## Alternativas consideradas

- **Tudo eager** — descartado por aumentar bundle inicial.
- **Standalone components com roteamento standalone** — adiada para evolução futura; manter NgModules garante consistência com versão atual do PrimeNG.
- **Micro-frontends (Module Federation)** — descartado por complexidade desproporcional ao tamanho do time.

## Consequências

**Positivas**
- Chunks por feature; Angular CLI gera nomes hashados.
- Tempo de carregamento inicial menor.
- Times conseguem evoluir features de forma isolada.
- Permite preloading estratégico via `PreloadAllModules` ou estratégia custom.

**Negativas**
- Cada feature precisa importar PrimeNG modules localmente → algum overhead de duplicação de imports nos `*.module.ts`.
- Mudanças em `shared/` exigem cuidado para não criar dependências circulares.

## Notas

- Lista de features lazy atual: `administracao`, `cooperativa`, `registro`, `relatorio`, `transferencia-uf`, `exportacao-dados`, `inicio`.
- Eventual migração para standalone components irá usar `loadComponent()` no lugar de `loadChildren()`.
