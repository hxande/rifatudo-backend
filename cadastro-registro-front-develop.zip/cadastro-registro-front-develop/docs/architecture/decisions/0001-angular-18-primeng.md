# ADR 0001 — Angular 18 com PrimeNG 17 como stack frontend

- **Status:** Aceito
- **Data:** 2026-05-15
- **Decisores:** Tech Lead Frontend OCB, Arquitetura SESCOOP

## Contexto

O ecossistema OCB precisa de um framework SPA maduro, com tipagem estrita, suporte de longo prazo e uma biblioteca de componentes corporativa. O time já mantinha outros frontends OCB em Angular, com bibliotecas reutilizadas via submódulo. Angular 18 é a major LTS atual com suporte oficial a standalone components, signals (opcional) e build moderno via esbuild.

PrimeNG 17 oferece componentes ricos (data tables com filtragem, formulários, tabs, dialogs, calendar), boa documentação em pt-BR e integração com tema customizável. O tema `lara-light-blue` foi adotado como base e estendido pelo SCSS interno `assets/omega/theme.scss`.

## Decisão

Adotar **Angular 18.2.13** com **TypeScript 5.4.5**, RxJS 7.4.0 e **PrimeNG 17.18.15 + PrimeFlex 3.3.0** como stack oficial do `cadastro-registro-front`.

## Alternativas consideradas

- **React + MUI** — descartada por divergência com o restante do ecossistema OCB.
- **Vue 3** — descartada por falta de massa crítica no time.
- **Angular Material** — descartada por menor cobertura de componentes corporativos e visual mais "Google-like".

## Consequências

**Positivas**
- Convergência com outros frontends OCB.
- Time já produtivo com Angular.
- PrimeNG cobre a maioria dos componentes corporativos necessários.
- Lazy-loading nativo + roteamento padronizado.

**Negativas**
- ⚠️ PrimeNG importado por NgModule (não standalone) infla bundle.
- Bundle ainda exige 4 GB heap em dev — ver [02-constraints](../02-constraints.md).
- Atualização major do Angular exige coordenação com todos os frontends OCB.

## Notas

- Migração futura para componentes standalone está prevista (ver [08-technical-debt](../08-technical-debt.md)).
- O time pode adotar signals gradualmente em features novas sem refactor amplo.
