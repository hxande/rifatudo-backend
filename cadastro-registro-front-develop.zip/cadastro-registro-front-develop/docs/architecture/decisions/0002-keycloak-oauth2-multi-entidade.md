# ADR 0002 — Keycloak OAuth2 com seleção multi-entidade

- **Status:** Aceito
- **Data:** 2026-05-15
- **Decisores:** Arquitetura SESCOOP, Segurança OCB

## Contexto

O SOUCOOP é usado por usuários que podem atuar em múltiplas entidades (uma pessoa pode ser responsável por mais de uma cooperativa, ou ser analista em mais de uma OCB Estadual). A autenticação precisa ser centralizada com o restante do ecossistema OCB (que já adota Keycloak corporativo), suportar SSO entre sistemas e expor roles utilizáveis em `CanActivate` no front e em `@PreAuthorize` no back.

## Decisão

Adotar **Keycloak OAuth2 com PKCE** como provedor único de autenticação, integrado via `keycloak-angular`/`keycloak-js`. A seleção de entidade é tratada como um passo pós-login obrigatório quando o usuário tem mais de uma associação ativa:

1. Login → token JWT.
2. `AuthGuardService` verifica autenticação e role.
3. Se múltiplas entidades → redirect para `/selecionar-entidade`.
4. Entidade escolhida é mantida em sessão e enviada em headers/contexto para as APIs.

Roles padrão:
- `CADASTRO_REGISTRO_USUARIO_ATIVO`
- `CADASTRO_REGISTRO_ADMINISTRADOR`

Roteamento por role definido em `AUTH_GUARD_ROUTE_MAPS` injetado via `appRoutesRoleMaps` no `app.module.ts`.

## Alternativas consideradas

- **Autenticação custom JWT** — descartada por reinventar Keycloak.
- **Cognito/Auth0** — descartado por exigir migração e contrato comercial novo.
- **Sem multi-entidade explícita (escolha via dropdown sempre)** — descartado por ser menos seguro e mais propenso a erro do usuário.

## Consequências

**Positivas**
- SSO real entre frontends OCB.
- Gestão centralizada de usuários/roles no Keycloak.
- `AuthHttpInterceptor` injeta Bearer automaticamente.
- Rotas públicas controladas declarativamente via `AcessoPublico.isRotaPublica()`.

**Negativas**
- ⚠️ Tokens armazenados conforme padrão `keycloak-js` (localStorage). Risco XSS — ver [LGPD](../../compliance/lgpd.md).
- Dependência forte do Keycloak corporativo: indisponibilidade do Keycloak = sistema fora do ar.
- Fluxo multi-entidade adiciona um passo no UX.

## Notas

- `keycloakConfigFilePath` é resolvido pelo `environment.ts` (dev vs prod).
- Refresh token gerido pelo adapter; `ng-idle` complementa controle de inatividade.
