# ADR 0006 — Suporte ao CNPJ alfanumérico

- **Status:** Aceito
- **Data:** 2026-06-19
- **Decisores:** Tech Lead Frontend OCB, Arquitetura SESCOOP

## Contexto

A Receita Federal definiu o novo formato de **CNPJ alfanumérico** (oito primeiras posições passam a aceitar letras e dígitos; dígitos verificadores calculados sobre o valor ASCII), com adoção prevista para o ecossistema. O SOUCOOP trata CNPJ em diversos pontos críticos — registro, manutenção de dados gerais, filiação superior, averbação, filiais, quadro social PJ e relatórios — e as máscaras/validações anteriores assumiam um CNPJ **puramente numérico**.

Em paralelo, a documentação anterior referenciava a classe `shared/validation/valida-campos.ts` (`ValidaCampos.validarCpf/validarCnpj`) como fonte única de validação. Essa classe não suportava o formato alfanumérico e foi **removida** durante o trabalho de adequação.

## Decisão

Adequar o frontend ao **CNPJ alfanumérico**:

1. As máscaras de CNPJ passam a aceitar caracteres `A–Z` e `0–9`, normalizando entrada com `toString().toUpperCase().replace(/[^A-Z0-9]+/g, '')` (ex.: `negocio.component.ts`, `manutencao-negocio-component.component.ts`).
2. A remoção de máscara e a validação migraram para o submódulo `public-includes` (`@utils`, ex.: `UtilityService` / `ValidadorCampo.removeMascaraCnpj()`) e para **serviços de validação por componente** (ex.: `shared/averbacao/validacao/validacao-averbacao.service.ts`, `shared/filial/validacao/validacao-filial.service.ts`).
3. A classe centralizada `shared/validation/valida-campos.ts` foi **removida**.
4. A máscara de CPF/CNPJ foi **padronizada** nas telas e relatórios para comportamento consistente.

Trabalho associado: tickets `SOU-1148` (correção CNPJ alfanumérico) e `ARQ-55` (tratamento/máscara alfanumérica), além da padronização de máscaras.

## Alternativas consideradas

- **Manter validação numérica e bloquear letras** — descartada: contraria a norma da Receita e quebraria registros futuros.
- **Manter `ValidaCampos` centralizada e apenas estendê-la** — descartada em favor de reuso da lógica já mantida no submódulo `public-includes`, compartilhada entre frontends OCB.

## Consequências

**Positivas**
- Conformidade com o novo padrão de CNPJ da Receita Federal.
- Reuso da validação/máscara via `public-includes`, evitando divergência entre frontends OCB.
- Máscaras uniformes em telas e relatórios.

**Negativas**
- ⚠️ A lógica de validação/remoção de máscara ficou **replicada em vários componentes** em vez de uma fonte única no app — risco de divergência futura (ver [08-technical-debt](../08-technical-debt.md), item F).
- Depende do submódulo `public-includes` estar atualizado (ver [ADR 0004](./0004-public-includes-submodule.md)).

## Notas

- Validações definitivas dos dígitos verificadores permanecem no backend; o front aplica máscara e checagem preliminar.
- Pendência: consolidar a validação de CPF/CNPJ em utilitário único e garantir máscara visual em todos os inputs.
