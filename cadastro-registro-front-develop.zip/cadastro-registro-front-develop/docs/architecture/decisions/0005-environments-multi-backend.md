# ADR 0005 — Configuração de ambientes com mapeamento granular por API

- **Status:** Aceito
- **Data:** 2026-05-15
- **Decisores:** Tech Lead Frontend, DevOps OCB

## Contexto

O SOUCOOP consome múltiplas APIs (cadastro-registro escrita, leitura, documentacao, localizacao, boleto, desempenho, gerencia-usuario). Em situações reais de desenvolvimento e debug, é comum:

- Apontar **uma API específica para local** enquanto o resto roda em hmlg.
- Validar comportamento misto (front local + backend hmlg + Keycloak prd, por exemplo).
- Trocar Keycloak entre dev e prod sem rebuild completo.

Um único par `apiBaseUrl` global não atende a esses cenários.

## Decisão

Os arquivos `environment.ts` expõem **três níveis** de configuração:

1. `keycloakConfigFilePath` — caminho relativo a `assets/keycloak/keycloak-<env>.json`. Permite swap de realm/issuer sem rebuild de código.
2. `backendEnv` — chave global (`local | hmlg | trt`) que serve como default para todas as APIs.
3. `apisEnv` — mapa granular por API, sobrescreve `backendEnv` quando presente. Estrutura típica:

```ts
apisEnv: {
  'cadastro-registro-api': 'hmlg',
  'cadastro-registro-leitura-api': 'local',
  'documentacao-api': 'hmlg',
  // ...
}
```

Os clients HTTP em `src/public/<api>/` consultam essa configuração para montar a URL base.

## Alternativas consideradas

- **Variáveis injetadas em runtime via `assets/config.json`** — descartado por exigir refactor amplo dos clients.
- **Apenas `backendEnv`** — descartado por não cobrir cenários de desenvolvimento mistos.
- **Variáveis de ambiente injetadas em build** — manteria flexibilidade mas perderia o cenário de troca rápida em dev.

## Consequências

**Positivas**
- Desenvolvedor consegue isolar uma API em local sem alterar nada além do `environment.ts`.
- Smoke tests cross-ambiente ficam viáveis.
- Mesma imagem de build pode ser repromovida entre hmlg e prd se o swap for via Keycloak config + ConfigMap.

**Negativas**
- ⚠️ Configuração espalhada em três níveis aumenta a chance de erro humano.
- Cada API nova exige atualização do `environment.ts` em todos os ambientes.
- Sem validação de schema do `apisEnv`.

## Notas

- Em produção, `environment.prod.ts` zera o `apisEnv` para garantir consistência.
- Documentação operacional do mapeamento por API vive em [`api/endpoints.md`](../../api/endpoints.md).
