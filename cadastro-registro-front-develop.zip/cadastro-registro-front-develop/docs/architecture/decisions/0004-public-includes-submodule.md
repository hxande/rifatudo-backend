# ADR 0004 — Reuso entre frontends OCB via submódulo `public-includes`

- **Status:** Aceito
- **Data:** 2026-05-15
- **Decisores:** Arquitetura OCB Frontend

## Contexto

Os frontends do ecossistema OCB compartilham vários ativos: serviço de autenticação Keycloak, componentes de UI corporativa (barra-topo, rodapé, modal de seleção de entidade), e clientes HTTP gerados a partir dos contratos das APIs. Duplicar esses ativos em cada frontend seria custoso e levaria a divergências sutis.

Não existe um pipeline de publicação interno (npm registry privado) consolidado para o time. Submódulos Git são a forma adotada historicamente para compartilhar bibliotecas entre projetos OCB.

## Decisão

Adotar o repositório **`public-includes`** como submódulo Git em `src/public/` em todos os frontends OCB, incluindo `cadastro-registro-front`. O submódulo contém:

- `auth/` — Keycloak, interceptors, `HttpStatusService`.
- `gui/` — componentes visuais compartilhados.
- Clients gerados para cada API (`cadastro-registro-api`, `cadastro-registro-leitura-api`, `documentacao-api`, `localizacao-api`, `boleto-api`, etc.).
- `utils/` — helpers cross-projeto.

Path aliases em `tsconfig.json` apontam para subpastas de `src/public/`:

```jsonc
"@auth/*": ["src/public/auth/*"],
"@gui/*": ["src/public/gui/*"],
"@cadastro-registro-api/*": ["src/public/cadastro-registro-api/*"],
"@cadastro-registro-leitura-api/*": ["src/public/cadastro-registro-leitura-api/*"],
"@documentacao-api/*": ["src/public/documentacao-api/*"],
"@localizacao-api/*": ["src/public/localizacao-api/*"],
"@utils/*": ["src/public/utils/*"]
```

## Alternativas consideradas

- **npm package privado** — descartado por falta de registry interno mantido.
- **Cópia manual entre projetos** — descartado por divergir rapidamente.
- **Monorepo Nx unificado** — descartado por exigir reestruturação grande.

## Consequências

**Positivas**
- Reuso real de código corporativo.
- Atualizações coordenadas entre frontends OCB.
- Aliases consistentes em todos os projetos.

**Negativas**
- ⚠️ Setup obrigatório: `git submodule init && git submodule update`. CI/CD que esquece esse passo quebra o build.
- ⚠️ Mudanças no submódulo afetam todos os frontends — exigem coordenação.
- Versionamento por commit hash, não por semver — pode causar regressões silenciosas.

## Notas

- Pipeline CI deve sempre executar `git submodule update --init --recursive` antes de `npm ci`.
- Migração futura para npm package interno foi sinalizada mas não priorizada.
- O arquivo `.gitmodules` documenta a URL e a branch do submódulo.
