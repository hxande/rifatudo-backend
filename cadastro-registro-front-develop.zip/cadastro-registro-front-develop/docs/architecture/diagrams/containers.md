# Diagrama C4 — Nível 2: Containers

```mermaid
flowchart TD
    Browser[Browser do usuário<br/>cooperativa / OCB]

    subgraph OpenShift_Cluster
        Route[OpenShift Route<br/>TLS]
        Nginx[Pod nginx<br/>serve SPA estático]

        subgraph APIs
            CRApi[cadastro-registro-api<br/>Spring Boot 3]
            CRLeitura[cadastro-registro-leitura-api<br/>Spring Boot 3]
            GU[gerencia-usuario-api]
            Doc[documentacao-api]
            Loc[localizacao-api]
            Boleto[boleto-api]
            Desem[desempenho-api]
        end

        KC[Keycloak<br/>OCB Realm]
        DB[(SQL Server<br/>CadastroRegistro)]
        DBLeit[(SQL Server<br/>Leitura ou réplica)]
    end

    Browser -->|HTTPS| Route
    Route --> Nginx
    Nginx -->|bundles, assets| Browser

    Browser -->|OAuth2 PKCE| KC
    Browser -->|XHR Bearer| CRApi
    Browser -->|XHR Bearer| CRLeitura
    Browser -->|XHR Bearer| GU
    Browser -->|XHR Bearer| Doc
    Browser -->|XHR Bearer| Loc
    Browser -->|XHR Bearer| Boleto
    Browser -->|XHR Bearer| Desem

    CRApi --> DB
    CRLeitura --> DBLeit
```

## Pontos importantes

| Componente | Responsabilidade |
|---|---|
| Browser | Executa o SPA Angular, mantém token JWT, dispara chamadas XHR |
| OpenShift Route | Terminação TLS, roteamento por hostname |
| Pod nginx | Serve `dist/cadastro-registro-front/` (HTML + JS hashado + assets) |
| Keycloak | Provedor único de identidade, gerencia sessões SSO |
| `cadastro-registro-api` | Escrita — comandos sobre cooperativa, processo de registro, anuário, governança |
| `cadastro-registro-leitura-api` | Consultas otimizadas (CQRS leve) |
| Outras APIs OCB | Capacidades específicas (documentos, localização, boleto, desempenho, usuários) |

## Comunicação

- **Browser ↔ APIs:** REST/JSON com `Authorization: Bearer <jwt>`.
- **Browser ↔ Keycloak:** OAuth2 PKCE, login, refresh, logout.
- **APIs entre si:** delegadas ao backend (uso de `keycloakRestTemplate` por convenção SESCOOP).
