# Diagrama C4 — Nível 3: Componentes (SOUCOOP Front)

```mermaid
flowchart TD
    subgraph SPA[SOUCOOP Front Angular 18]
        direction TB

        subgraph Core[core/]
            Layout[AppLayout / Topbar / Menu / Footer]
            Guards[AuthGuardService]
            Pipes[Pipes formatação]
            Sel[SelecionarEntidade]
            Usuario[Contexto Usuário]
        end

        subgraph Features[features/ - lazy]
            Adm[administracao]
            Coop[cooperativa]
            Reg[registro]
            Rel[relatorio]
            Tuf[transferencia-uf]
            Exp[exportacao-dados]
            Inicio[inicio]
        end

        subgraph Shared[shared/]
            ShComp[custom-accordion<br/>governanca<br/>filial<br/>averbacao<br/>validacao-dados<br/>boleto<br/>desempenho-lancamento-externo]
            ShVal[Validação CPF/CNPJ alfanumérico<br/>via @utils + serviços por componente]
            ShUtils[Utils]
        end

        subgraph Api[app/api/]
            ApiServices[32 api-*.service.ts]
            ApiModels[TOs]
            ApiMappers[mappers]
        end

        subgraph Public[src/public/ submodule]
            PubAuth[KeycloakService<br/>AuthHttpInterceptor<br/>MessageHttpInterceptor<br/>HttpStatusService]
            PubGui[barra-topo<br/>file-upload<br/>logo-cooperativa<br/>menu-superior<br/>rodape<br/>modal-selecionar-entidade<br/>page-header<br/>usuario-informacoes]
            PubClients[Clients HTTP gerados]
            PubUtils[utils]
        end
    end

    Layout --> PubGui
    Guards --> PubAuth
    Features --> Shared
    Features --> Api
    Features --> PubClients
    ApiServices --> PubAuth
    PubClients --> PubAuth

    PubAuth -.OAuth2.-> KC[(Keycloak)]
    ApiServices -.HTTP.-> BE[(APIs OCB)]
    PubClients -.HTTP.-> BE
```

## Fluxo de dependência

1. **`features/*`** consomem **`api/services/*`** e **`public/<api>/*`** para dados.
2. **`features/*`** importam componentes de **`shared/`** e **`public/gui/`** para UI.
3. **`core/`** é importado uma única vez no `AppModule`, monta layout e ativa guards.
4. **`public/auth/`** fornece interceptors registrados no `HTTP_INTERCEPTORS` provider do `AppModule`.

## Pontos críticos

- **Interceptors:** registrados globalmente; toda chamada HTTP passa por `AuthHttpInterceptor` (Bearer) e `MessageHttpInterceptor` (Toast em erros).
- **Lazy boundary:** o bundle inicial contém `core` + `app.module` + roteamento; cada feature carrega seu chunk sob demanda.
- **Multi-tenant:** `AuthGuardService` força passagem pela rota `/selecionar-entidade` quando aplicável.
- **Submódulo `src/public/`:** falha ao inicializar quebra praticamente tudo.
