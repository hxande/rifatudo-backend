# Diagrama C4 — Nível 1: Contexto

```mermaid
flowchart TD
    subgraph Atores
        UserCoop[Usuário Cooperativa]
        UserOCBUF[Analista OCB Estadual]
        UserOCBNac[Gestor OCB Nacional]
    end

    Front[SOUCOOP Front<br/>Angular 18 SPA]

    subgraph Identidade
        KC[Keycloak<br/>OAuth2 PKCE]
    end

    subgraph Backends_OCB
        CRApi[cadastro-registro-api<br/>escrita]
        CRLeitura[cadastro-registro-leitura-api<br/>consulta]
        GU[gerencia-usuario-api]
        Doc[documentacao-api]
        Loc[localizacao-api]
        Boleto[boleto-api]
        Desem[desempenho-api]
    end

    GDH[(GDH<br/>Gestão Desenvolvimento Humano)]

    UserCoop -->|HTTPS SPA| Front
    UserOCBUF -->|HTTPS SPA| Front
    UserOCBNac -->|HTTPS SPA| Front

    Front -->|OAuth2| KC
    Front -->|REST + Bearer| CRApi
    Front -->|REST + Bearer| CRLeitura
    Front -->|REST + Bearer| GU
    Front -->|REST + Bearer| Doc
    Front -->|REST + Bearer| Loc
    Front -->|REST + Bearer| Boleto
    Front -->|REST + Bearer| Desem

    CRApi -.evento assíncrono.-> GDH
```

## Notas

- Todas as chamadas HTTP partem **do browser do usuário**, não do pod nginx que serve o SPA.
- Tokens JWT são emitidos pelo Keycloak e injetados pelo `AuthHttpInterceptor` em cada chamada.
- GDH é consumido indiretamente: o backend `cadastro-registro-api` publica eventos consumidos pelo controlador GDH.
