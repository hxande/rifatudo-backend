# 3. Contexto e Escopo

## 3.1 Contexto de negócio

O SOUCOOP é o ponto de entrada digital para o ciclo de registro cooperativista no Brasil. Ele conecta atores das cooperativas (responsáveis, contadores), das OCB Estaduais (analistas) e da OCB Nacional (gestores) a um conjunto de APIs especializadas que materializam as regras de registro, anuário, governança e relatórios.

### Atores externos

| Ator | Papel | Como interage |
|---|---|---|
| Usuário Cooperativa | Mantém dados da própria cooperativa | Login Keycloak → seleciona entidade → executa fluxos de registro/anuário |
| Analista OCB Estadual | Valida processos e dados da UF | Login Keycloak → painel administrativo da UF |
| Gestor OCB Nacional | Consolida dados, parametriza, exporta | Login Keycloak → administração nacional |
| Sistema GDH | Recebe dados de capacitação | Integração indireta via backend |
| Sistema Gerência Usuário | Fornece dados de usuário/papéis | Consumido via Keycloak |

## 3.2 Sistemas externos consumidos

| Sistema | Função no SOUCOOP | Aliases |
|---|---|---|
| **Keycloak** | OAuth2 PKCE, RBAC, multi-realm | — |
| **cadastro-registro-api** | Escrita — processos, registros, manutenção | `@cadastro-registro-api/*` |
| **cadastro-registro-leitura-api** | Consultas otimizadas (CQRS leve) | `@cadastro-registro-leitura-api/*` |
| **gerencia-usuario-api** | Dados de usuários e entidades | (via public-includes) |
| **documentacao-api** | Upload e download de documentos | `@documentacao-api/*` |
| **localizacao-api** | UFs, municípios, endereços | `@localizacao-api/*` |
| **boleto-api** | Boletos da taxa de registro | (via public-includes) |
| **desempenho-api** | Lançamentos externos de desempenho | (via public-includes) |
| **GDH (controlador)** | Sincronização de capacitações | Indireta (backend orquestra) |

## 3.3 Diagrama de contexto

```mermaid
flowchart TD
    UserCoop[Usuário Cooperativa]
    UserOCB[Analista OCB]
    UserAdmin[Gestor Nacional]

    Front[SOUCOOP Front<br/>Angular 18]

    KC[Keycloak<br/>OAuth2]
    CRApi[cadastro-registro-api<br/>escrita]
    CRLeitura[cadastro-registro-leitura-api<br/>consulta]
    GU[gerencia-usuario-api]
    Doc[documentacao-api]
    Loc[localizacao-api]
    Boleto[boleto-api]
    Desem[desempenho-api]
    GDH[(GDH)]

    UserCoop --> Front
    UserOCB --> Front
    UserAdmin --> Front

    Front --> KC
    Front --> CRApi
    Front --> CRLeitura
    Front --> GU
    Front --> Doc
    Front --> Loc
    Front --> Boleto
    Front --> Desem
    CRApi -.evento.-> GDH
```

## 3.4 Fluxo de autenticação resumido

1. Usuário acessa rota protegida.
2. `AuthGuardService` (CanActivate) consulta `KeycloakService.isAuthenticated()`.
3. Se não autenticado → redirect login Keycloak (PKCE).
4. Token retorna → `AuthHttpInterceptor` injeta `Authorization: Bearer ...` em toda chamada HTTP.
5. Se usuário tem múltiplas entidades → redirect `/selecionar-entidade`.
6. Roles esperados: `CADASTRO_REGISTRO_USUARIO_ATIVO`, `CADASTRO_REGISTRO_ADMINISTRADOR`.
7. Rotas públicas (ex.: confirmação de e-mail) declaradas via `AcessoPublico.isRotaPublica()`.

## 3.5 Limites do sistema

- O front **não** persiste dados de negócio. Apenas cache transitório de UI (RxJS, sessionStorage para preferências leves).
- Tokens são geridos pelo Keycloak adapter (armazenamento padrão do `keycloak-js`).
- ⚠️ Não há orquestrador de consentimento LGPD client-side — ver [`compliance/lgpd.md`](../compliance/lgpd.md).
