# 7. Qualidade

## 7.1 Atributos priorizados

| Atributo | Cenário | Tática atual |
|---|---|---|
| **Segurança** | Usuário não autenticado tenta acessar `/registro` | `AuthGuardService` redireciona ao Keycloak |
| **Segurança** | Usuário sem role acessa `/administracao` | `AUTH_GUARD_ROUTE_MAPS` impede → 403 |
| **Manutenibilidade** | Adicionar nova entidade ao backend | Criar `api-<entity>.service.ts` + TO + feature module |
| **Performance** | Primeira carga | Lazy chunks por feature; bundle inicial enxuto |
| **Usabilidade** | Erro de validação em formulário | Mensagens inline + Toast pt-BR |
| **Disponibilidade** | Backend indisponível | Toast informa; UI degrada graciosamente |
| **Compatibilidade** | Cooperativa em UF diferente | Multi-entidade via `/selecionar-entidade` |

## 7.2 Testes

| Tipo | Ferramenta | Estado |
|---|---|---|
| Unitário | Karma + Jasmine | Cobertura via Istanbul (`test-coverage`) |
| Lint | ESLint + @angular-eslint | `lint`, `lint-fix`, `lint-changed` |
| E2E | placeholder (`npm run e2e`) | ⚠️ não há suíte ativa documentada |
| Qualidade estática | SonarQube via `sonar-scanner` | `npm run sonar` |
| Performance | Lighthouse | `npm run lighthouse` |
| Bundle | webpack-bundle-analyzer | `npm run analyze` |

## 7.3 Acessibilidade

- PrimeNG fornece ARIA básico em componentes.
- Labels semânticos esperados em todos os formulários.
- ⚠️ Sem auditoria formal WCAG documentada — meta AA não validada.

## 7.4 Internacionalização

- pt-BR único idioma.
- Mensagens hardcoded em templates; sem i18n Angular adotado.
- ⚠️ Mudança para outro idioma exigiria refactor amplo (não previsto).

## 7.5 Segurança aplicacional

| Mecanismo | Implementação |
|---|---|
| AuthN | Keycloak OAuth2 PKCE |
| AuthZ | Mapa de roles por rota via `AUTH_GUARD_ROUTE_MAPS` |
| Sanitização | Angular DomSanitizer padrão (templates) |
| CORS | Configurado nos backends |
| HTTPS | Terminação TLS no OpenShift Route |
| Token | Gerido pelo `keycloak-js` adapter |
| CSRF | Não aplicável (SPA com Bearer token) |
| XSS | Sanitização nativa Angular + ausência de `bypassSecurityTrust*` documentado |

⚠️ Tokens em localStorage pelo padrão Keycloak adapter — ver [LGPD](../compliance/lgpd.md).

## 7.6 Performance

- **Lazy-loading agressivo** — cada feature em chunk próprio.
- **Heap dev 4 GB** sinaliza bundle volumoso; produção é menor por tree-shake básico.
- ⚠️ PrimeNG importado por NgModule (não standalone) — bundle maior que ideal.
- `puppeteer` em dependência (21.5.2) infla `node_modules`; verificar se é runtime real ou tool de build.

## 7.7 Monitoramento

⚠️ Lacuna conhecida:
- Sem Sentry, Crashlytics ou similar.
- `console.log/error` espalhados em 15+ componentes (anti-pattern).
- Sem RUM (Real User Monitoring).
- Sem Analytics.

Recomendação: adotar Sentry + envio de Web Vitals para um sink central. Detalhado em [08-technical-debt](./08-technical-debt.md).

## 7.8 Métricas de qualidade alvo

| Métrica | Alvo | Atual |
|---|---|---|
| Cobertura unitária | ≥ 70% | A medir via `test-coverage` |
| SonarQube — bugs | 0 críticos | Pipeline gates |
| Lighthouse Performance | ≥ 70 | Não rastreado de forma contínua |
| Bundle inicial gz | < 500 KB | A validar com `analyze` |
| TTI 3G | < 5s | Não medido |

## 7.9 Resiliência

- Erros HTTP tratados pelo `MessageHttpInterceptor`.
- Re-tentativa não é aplicada de forma global; comandos sensíveis (POST) **não** são retentados.
- Idempotência delegada aos backends.
