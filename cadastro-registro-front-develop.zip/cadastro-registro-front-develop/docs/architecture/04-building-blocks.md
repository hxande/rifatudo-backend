# 4. Blocos de Construção

## 4.1 Visão geral de pacotes

```
src/
├── app/
│   ├── api/                       # Clients HTTP gerados/curados
│   │   ├── services/              # 32 api-*.service.ts (+5 espalhados em features/shared)
│   │   ├── models/                # TOs/DTOs tipados
│   │   └── mapper/                # Mapeadores entre TO e ViewModel
│   ├── core/                      # Camada transversal
│   │   ├── layout/                # barra-topo, menu, footer, app-shell
│   │   ├── guards/                # AuthGuardService, RoleGuard
│   │   ├── pipes/                 # pipes de formatação
│   │   ├── confirmacao-email/     # fluxo público
│   │   ├── forbidden/             # 403
│   │   ├── selecionar-entidade/   # rota multi-tenant
│   │   └── usuario/               # contexto do usuário logado
│   ├── features/                  # Feature modules lazy
│   │   ├── administracao/
│   │   ├── cooperativa/
│   │   ├── registro/
│   │   ├── relatorio/
│   │   ├── transferencia-uf/
│   │   ├── exportacao-dados/
│   │   └── inicio/
│   └── shared/                    # Componentes/validators reutilizáveis
│       ├── components/            # custom-accordion, governanca, filial,
│       │                          # averbacao, validacao-dados, boleto
│       ├── validacao/             # validação de CPF/CNPJ (alfanumérico) — ver nota 4.5
│       ├── guard/
│       └── utils/
└── public/                        # Submódulo public-includes
    ├── auth/                      # KeycloakService, interceptors, HttpStatusService
    ├── gui/                       # barra-topo, file-upload, modal-selecionar-entidade,
    │                              # page-header, rodape, usuario-informacoes
    ├── utils/                     # helpers compartilhados entre frontends OCB
    ├── cadastro-registro-api/     # cliente gerado (escrita)
    ├── cadastro-registro-leitura-api/ # cliente gerado (leitura)
    ├── documentacao-api/
    ├── localizacao-api/
    ├── boleto-api/
    └── ...
```

## 4.2 Camada `core/`

Responsabilidades transversais e estado global mínimo. Importada **uma única vez** no `AppModule`.

- **Layout:** `app.layout.component`, `app.topbar.component`, `app.menu.component`, `app.footer.component`.
- **Guards:**
  - `AuthGuardService` — `CanActivate` consultando `AUTH_GUARD_ROUTE_MAPS` injetado via `appRoutesRoleMaps` no `app.module.ts`.
  - Verifica autenticação + role + entidade selecionada.
- **Pipes:** formatação de CPF/CNPJ, datas, valores monetários.
- **Selecionar Entidade:** rota dedicada para multi-tenant.

## 4.3 Camada `api/`

Cada `api-<entity>.service.ts` encapsula chamadas HTTP a uma entidade específica. Exemplos:

| Service | Domínio |
|---|---|
| `api-cooperativa-leitura.service.ts` | Consultas de cooperativa |
| `api-dados-gerais.service.ts` | Dados gerais |
| `api-manutencao-dados-gerais.service.ts` | Manutenção de dados |
| `api-ramo.service.ts` | Ramos cooperativistas |
| `api-certificados.service.ts` | Certificados emitidos |
| `api-solicitacao.service.ts` | Solicitações |
| `api-taxa-registro.service.ts` | Taxa de registro |
| `api-pessoa-cnpj.service.ts` | Pessoa jurídica |
| `api-quadro-social-uf.service.ts` | Quadro social por UF |
| `api-sistema-vinculacao.service.ts` | Vínculos entre sistemas |
| `api-controle-anuario.service.ts` | Controle do anuário |
| `api-controle-atualizacao-cadastral.service.ts` | Atualização cadastral |
| `api-historico-processo-registro.service.ts` | Histórico de processos |
| `api-censo-anuario.service.ts` | Censo do anuário |
| `api-controlador-anuario-uf.service.ts` | Controlador do anuário por UF |
| `api-anuario-negocio-exportacao.service.ts` | Exportação do anuário |
| `api-tipo-solicitacao.service.ts` | Tipos de solicitação |

Outros 30+ clients vivem em `src/public/`.

## 4.4 Camada `features/`

Todas as features são **lazy-loaded** via `loadChildren()` no `app-routing.module.ts`. Ver [ADR 0003](./decisions/0003-lazy-loading-features.md).

| Feature | Responsabilidade resumida |
|---|---|
| `administracao` | Parametrização (ramos, cargos, órgãos, certificados, mandatos, critérios, controle anuário/portfolio, importação, validação em lote) |
| `cooperativa` | Visão e manutenção da cooperativa (dados gerais, anuário v2, quadro social, filiais, responsáveis, documentos, histórico, gráficos) |
| `registro` | Processo de registro completo (requerimento, passos, apontamentos, governança, negócio, filiadas, documentação, transferência UF) |
| `relatorio` | Geração com filtros, exportação Excel/PDF |
| `exportacao-dados` | Bulk export |
| `inicio` | Dashboard, estatísticas, atalhos |
| `transferencia-uf` | Mudança de jurisdição |

Detalhes em [`../modules/`](../modules/).

## 4.5 Camada `shared/`

Componentes e utilitários reutilizados em múltiplas features. Importados sob demanda por feature modules (não globais).

- **Components:** `custom-accordion`, `governanca`, `filial`, `averbacao`, `desempenho-lancamento-externo`, `validacao-dados`, `boleto`.
- **Validation:** validação de CPF/CNPJ (dígitos verificadores) e máscaras. A antiga classe `shared/validation/valida-campos.ts` foi **removida**; a validação/remoção de máscara passou a residir no submódulo `public-includes` (`@utils`, ex.: `UtilityService` / `ValidadorCampo.removeMascaraCnpj()`) e em serviços de validação por componente (ex.: `shared/averbacao/validacao/validacao-averbacao.service.ts`, `shared/filial/validacao/validacao-filial.service.ts`). As máscaras de CNPJ agora aceitam **formato alfanumérico** (`/[^A-Z0-9]+/g`) — ver [ADR 0006](./decisions/0006-cnpj-alfanumerico.md).
- **Utils:** helpers de data, string, conversão.

## 4.6 Submódulo `public/` (public-includes)

Reuso entre todos os frontends OCB. Contém:

- **`auth/`** — `KeycloakService`, `AuthHttpInterceptor`, `MessageHttpInterceptor`, `HttpStatusService`.
- **`gui/`** — `barra-topo`, `file-upload`, `logo-cooperativa`, `menu-superior`, `rodape`, `modal-selecionar-entidade`, `page-header`, `usuario-informacoes`.
- **Clients gerados** — `cadastro-registro-api`, `cadastro-registro-leitura-api`, `documentacao-api`, `localizacao-api`, `boleto-api`, etc.
- **`utils/`** — helpers cross-projeto.

Ver [ADR 0004](./decisions/0004-public-includes-submodule.md).

## 4.7 Interceptors

- **`AuthHttpInterceptor`** — injeta `Authorization: Bearer <token>` em chamadas para hosts conhecidos.
- **`MessageHttpInterceptor`** — captura 4xx/5xx, traduz para Toast PrimeNG via `MessageService`.

## 4.8 Diagramas

- [Containers](./diagrams/containers.md)
- [Componentes](./diagrams/components.md)
