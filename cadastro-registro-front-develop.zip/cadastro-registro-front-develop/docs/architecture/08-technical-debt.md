# 8. Riscos e Débitos Técnicos

## 8.1 Sumário executivo

| Severidade | Itens |
|---|---|
| Alta ⚠️ | 4 |
| Média | 5 |
| Baixa | 4 |

## 8.2 Débitos técnicos detalhados

### A. Observabilidade ausente ⚠️ Alta

- **Sintoma:** sem Sentry/Crashlytics/Analytics; `console.log/error` espalhados em 15+ componentes.
- **Impacto:** erros em produção invisíveis; sem métricas de uso.
- **Mitigação:** adotar Sentry SDK Angular, remover `console.*`, instrumentar Web Vitals.

### B. Dependências desatualizadas ⚠️ Alta

| Pacote | Atual | Recomendado | Notas |
|---|---|---|---|
| `@angular-eslint/*` | 14.4.0 | 19.x | Compatibilidade com Angular 18 OK em v18+, mas v14 está 5 majors atrás |
| `@angular/cdk` | 17.3.10 | 18.x | Core já em 18.2.13; CDK ainda 1 major atrás |
| `typescript` | 5.4.5 | 5.5+ | Compat Angular 18 (`tsconfig` já em `target: ES2022`) |
| `puppeteer` | 21.5.2 | 23.x | Avaliar necessidade real em runtime |

### C. PrimeNG sem tree-shake seletivo ⚠️ Alta

- Importação por NgModule infla bundle.
- **Mitigação:** migrar gradualmente para componentes standalone (Angular 18 suporta).

### D. Tokens em localStorage ⚠️ Alta (LGPD)

- Comportamento padrão do `keycloak-js`.
- **Mitigação:** avaliar `BearerOnly` + token em memória (sessionStorage) + revisão de threat model XSS. Ver [LGPD](../compliance/lgpd.md).

### E. Submódulo public-includes quebra CI esporadicamente — Média

- Falha frequente: pipeline esquece `git submodule update --init`.
- **Mitigação:** pre-step obrigatório no template do pipeline; documentar em `CONTRIBUTING`.

### F. Máscara de CPF/CNPJ — Parcialmente resolvido (2026-06)

- Em 2026-06 a **máscara de CPF/CNPJ foi padronizada nas telas e relatórios** e passou a aceitar o **CNPJ alfanumérico** (ver [ADR 0006](./decisions/0006-cnpj-alfanumerico.md)). A antiga classe `shared/validation/valida-campos.ts` foi removida; validação/remoção de máscara migrou para `@utils` (submódulo `public-includes`) e serviços de validação por componente.
- **Pendência residual:** confirmar cobertura de máscara visual em **todos** os inputs de quadro social/responsáveis e padronizar a fonte única de validação (hoje há lógica replicada em componentes).

### G. Sem consent manager LGPD — Média

- Não há banner de cookies/consentimento.
- **Mitigação:** avaliar necessidade (sistema interno autenticado pode ter requisitos diferentes); alinhar com DPO.

### H. TODOs e FIXMEs ativos — Média

19 ocorrências identificadas. Exemplos:
- `validacao-menu.service.ts` — "ver lógica de subperfis".
- `mantem-criterio-associacao` — "substituir pelo método correto".
- `ajuste-dados` — "implementar lógica" (valor hardcoded).
- `validacao-dados` — "pegar do servidor" (valor hardcoded).
- `geral.service.ts` — "buscar na sessão".

**Mitigação:** abrir issues rastreáveis no backlog.

### I. Sem suíte E2E ativa — Média

- Script `e2e` no `package.json`, mas sem documentação de framework atual.
- **Mitigação:** adotar Playwright ou Cypress; cobrir fluxos críticos (login, registro, anuário).

### J. `console.log/error` em produção — Baixa

- Logs vazam para o console do browser.
- **Mitigação:** ESLint rule `no-console: error` + serviço de logger central.

### K. Sem i18n — Baixa

- pt-BR único; mudança futura custosa.

### L. `ng-idle` hardcoded — Baixa

- Tempos de idle podem estar no código; idealmente em config.

### M. Acessibilidade não auditada — Baixa

- Meta WCAG AA não validada formalmente.

## 8.3 Roadmap sugerido

| Trimestre | Ação |
|---|---|
| Q1 | Sentry + remover `console.*` + ESLint rule |
| Q1 | Atualizar `@angular-eslint` para v19 |
| Q2 | Máscara visual CPF/CNPJ |
| Q2 | Atualizar `@angular/cdk` para v18 |
| Q3 | Migração incremental PrimeNG → standalone imports |
| Q3 | Suíte Playwright fluxos críticos |
| Q4 | Revisão LGPD (consent manager + token em memória) |

## 8.4 Riscos abertos

| Risco | Probabilidade | Impacto | Owner |
|---|---|---|---|
| Quebra de contrato com `cadastro-registro-api` | Média | Alto | Tech lead front + back |
| Atualização Angular major sem janela | Baixa | Alto | Tech lead |
| Vazamento de PII por token XSS | Baixa | Alto | DPO + tech lead |
| Submódulo desincronizado entre frontends OCB | Média | Médio | Time public-includes |
