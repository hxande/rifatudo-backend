# 1. Visão Geral e Objetivos

## 1.1 Propósito

O **cadastro-registro-front** (SOUCOOP) é a Single Page Application Angular que serve como interface oficial do ecossistema Sescoop/OCB para o ciclo de vida de registro de cooperativas brasileiras, incluindo:

- Registro inicial e renovação de cooperativas perante a OCB.
- Manutenção de dados cadastrais (dados gerais, governança, quadro social, filiais).
- Anuário cooperativista (declaração anual obrigatória).
- Transferência de jurisdição entre UFs.
- Relatórios analíticos e exportação de dados.
- Painel administrativo para parametrização (ramos, cargos, órgãos, certificados, critérios).

## 1.2 Stakeholders

| Stakeholder | Interesse |
|---|---|
| Cooperativas registradas | Manter dados, declarar anuário, acompanhar registro |
| OCB Estaduais | Analisar processos, validar dados, gerenciar registros da UF |
| OCB Nacional | Consolidar dados, gerar relatórios estratégicos, parametrizar sistema |
| Sescoop | Indicadores, integração com GDH (Gestão de Desenvolvimento Humano) |
| Operadores administrativos | Importações em lote, validações, controle de anuário |

## 1.3 Objetivos de qualidade

| Qualidade | Meta | Estratégia |
|---|---|---|
| Usabilidade | Operação por usuários não-técnicos | PrimeNG, mensagens pt-BR, validações imediatas |
| Segurança | Autenticação centralizada, RBAC | Keycloak OAuth2 + AuthGuard por rota |
| Manutenibilidade | Adição de features sem regressão | Lazy modules, services por recurso, path aliases |
| Performance percebida | TTI < 5s em rede 3G | Lazy-loading, code splitting, bundle analyzer |
| Compatibilidade | Integração com 6+ APIs do ecossistema | Submódulo `public-includes` com clients gerados |
| Acessibilidade | WCAG 2.1 AA (objetivo) | PrimeNG ARIA, labels semânticos |

## 1.4 Escopo

**Dentro do escopo do front:**
- Renderização de telas, validação client-side, orquestração de chamadas a APIs.
- Gestão de sessão (Keycloak), seleção de entidade ativa, controle de inatividade.
- Composição visual de dados oriundos das APIs de escrita e leitura.

**Fora do escopo:**
- Regras de negócio críticas (residem nos backends).
- Persistência (delegada às APIs).
- Geração de PDF/Excel pesada (executada via APIs de relatório; `puppeteer` é usado pontualmente para casos client-side).

## 1.5 Mapa de alto nível

```mermaid
flowchart TD
    User[Usuário Cooperativa/OCB] --> Front[SOUCOOP Front Angular 18]
    Front --> KC[Keycloak OAuth2]
    Front --> CRApi[cadastro-registro-api]
    Front --> CRLeitura[cadastro-registro-leitura-api]
    Front --> Outros[gerencia-usuario / documentacao / localizacao / boleto / desempenho / GDH]
```

Detalhamento completo em [`diagrams/context.md`](./diagrams/context.md).

## 1.6 Princípios arquiteturais

1. **Feature modules são a unidade de evolução** — cada feature é independente, lazy-loaded e isolada.
2. **Services por recurso** — não há "god service"; cada entidade tem `api-<entity>.service.ts`.
3. **Submódulo compartilhado** — `public-includes` mantém clients e UI cross-projeto consistentes.
4. **Configuração por ambiente** — `environment.ts` orquestra backend (`local|hmlg|trt`) e Keycloak.
5. **Interceptors transversais** — auth e mensagens não vazam para componentes.
