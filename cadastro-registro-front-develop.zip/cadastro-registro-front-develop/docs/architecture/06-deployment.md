# 6. Visão de Deployment

## 6.1 Ambientes

| Ambiente | Arquivo | Keycloak config | Backend padrão |
|---|---|---|---|
| Local / Hmlg (default) | `src/environments/environment.ts` | `assets/keycloak/keycloak-dev.json` | hmlg |
| Dev | `src/environments/environment.dev.ts` | dev | hmlg |
| Produção | `src/environments/environment.prod.ts` | `assets/keycloak/keycloak-prod.json` | prd |

Variáveis principais expostas pelo environment:
- `keycloakConfigFilePath` — caminho do JSON de configuração do Keycloak.
- `backendEnv` — `local | hmlg | trt`.
- `apisEnv` — mapa granular por API (permite apontar APIs para ambientes distintos).

## 6.2 Build

```bash
npm run build              # produção (configuration=production)
npm run analyze            # webpack-bundle-analyzer sobre stats.json
npm run purgecss           # remove CSS não utilizado
```

Saída: `dist/cadastro-registro-front/`. Arquivos hashados, lazy chunks por feature.

## 6.3 Containerização

Cada projeto OCB possui `Dockerfile` na raiz. O build padrão:

1. Stage 1 — `node:18-alpine` executa `npm ci` + `npm run build`.
2. Stage 2 — `nginx:alpine` serve `dist/` com `nginx.conf` parametrizado.
3. ⚠️ É necessário garantir `git submodule update --init` antes do build no CI.

## 6.4 OpenShift

- Deploy padrão SESCOOP/OCB.
- DNS interno por ambiente:
  - HMLG: `*.hmlg.svc`
  - PRD: `*.prd.svc`
- Configuração externa via **Spring Cloud Config Server** (backends) e ConfigMap (front).
- Roteamento via Routes do OpenShift com TLS terminado na borda.

## 6.5 Topologia de runtime

```mermaid
flowchart TD
    Browser[Browser do usuário]
    Route[OpenShift Route<br/>HTTPS]
    Nginx[Pod nginx<br/>SOUCOOP front]
    KC[Keycloak<br/>realm OCB]
    Apis[(APIs OCB<br/>cadastro-registro, leitura, etc)]

    Browser --> Route --> Nginx
    Nginx -. assets/SPA .-> Browser
    Browser -- OAuth2 --> KC
    Browser -- XHR Bearer --> Apis
```

Observação importante: as chamadas das APIs **partem do browser**, não do pod nginx. O nginx apenas serve o bundle estático.

## 6.6 Estratégias de release

- Branch `main`/`master` → ambiente de produção via pipeline.
- Branches `feature/*` → preview em hmlg sob demanda.
- Tags `vX.Y.Z` para versionamento semântico.

## 6.7 Pré-requisitos de CI

1. `git submodule update --init --recursive` antes do `npm ci`.
2. Cache de `node_modules` por hash de `package-lock.json`.
3. `npm run lint && npm run test-coverage && npm run build`.
4. `npm run sonar` em pipeline de qualidade.

⚠️ Falha frequente: pipeline esquece o submódulo e o build quebra com "Cannot find module '@auth/...'" ou similar. Ver [ADR 0004](./decisions/0004-public-includes-submodule.md).

## 6.8 Rollback

- Rollback via OpenShift (revert para revision anterior do DeploymentConfig).
- Front é stateless — rollback não requer migração.
- Compatibilidade com backend deve ser preservada (contratos de TOs).
