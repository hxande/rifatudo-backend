# 5. Visão de Runtime

## 5.1 Bootstrap da aplicação

1. `main.ts` carrega `AppModule`.
2. `APP_INITIALIZER` aguarda `KeycloakService.init()` resolvendo o `keycloak-<env>.json` apropriado.
3. Token JWT inicial obtido (login redirect ou silent SSO).
4. `appRoutesRoleMaps` configura `AUTH_GUARD_ROUTE_MAPS` consumido pelo `AuthGuardService`.
5. `AppLayoutComponent` monta shell (barra-topo, menu-superior, rodapé) e ativa `<router-outlet>`.

## 5.2 Login + seleção de entidade

```mermaid
flowchart TD
    A[Usuário acessa rota protegida] --> B[AuthGuardService.canActivate]
    B --> C{Autenticado?}
    C -- não --> D[Redirect Keycloak login PKCE]
    D --> E[Callback com code+token]
    E --> F[Token guardado pelo adapter]
    C -- sim --> G{Tem entidade selecionada?}
    G -- não --> H[Redirect /selecionar-entidade]
    H --> I[Usuário escolhe entidade]
    I --> J[Sessão atualizada]
    G -- sim --> K{Role requerida ok?}
    K -- não --> L[Redirect /forbidden]
    K -- sim --> M[Carrega feature module lazy]
```

## 5.3 Chamada HTTP típica a uma API

```mermaid
sequenceDiagram
    participant C as Componente
    participant S as api-*.service.ts
    participant AI as AuthHttpInterceptor
    participant MI as MessageHttpInterceptor
    participant API as Backend

    C->>S: salvar(to: CooperativaTO)
    S->>AI: HttpClient.post()
    AI->>AI: injeta Bearer token
    AI->>MI: forward
    MI->>API: POST /cooperativas
    API-->>MI: 200 OK
    MI-->>S: response
    S-->>C: Observable<CooperativaTO>
    Note over MI: Em 4xx/5xx, MessageService<br/>exibe Toast pt-BR
```

## 5.4 Fluxo de processo de registro (resumo)

1. Usuário acessa `/registro` → módulo lazy é carregado.
2. Requerimento criado via `api-solicitacao.service`.
3. Passos preenchidos (governança, negócio, filiadas, documentação) — cada passo persiste parcialmente via `api-manutencao-dados-gerais` e correlatos.
4. Documentos enviados via `documentacao-api` (upload multipart).
5. Taxa de registro emitida via `boleto-api`.
6. Submissão final dispara evento backend → GDH é notificado de forma assíncrona.

## 5.5 Fluxo de Anuário v2

1. Cooperativa loga no período habilitado por `api-controle-anuario`.
2. Tela dinâmica (`cooperativa/anuario-v2`) monta formulário a partir de metadados retornados pela API.
3. Campos numéricos usam `ng2-currency-mask`.
4. Persistência incremental; validação no envio.
5. Conclusão dispara cálculo no backend e disponibiliza exportações.

## 5.6 Sessão e expiração

- **`ng-idle` + `keepalive`** controlam inatividade.
- Quando o usuário fica idle além do limite, uma modal alerta e desloga via `KeycloakService.logout()`.
- Token é renovado silenciosamente pelo adapter Keycloak (refresh).
- ⚠️ Tokens são armazenados conforme padrão do `keycloak-js` (memória/localStorage). Ver [LGPD](../compliance/lgpd.md).

## 5.7 Geração de PDF/Relatórios

- Relatórios pesados → backend gera (JasperReports) e o front faz download via `file-saver`.
- Casos pontuais client-side usam **puppeteer** para captura de telas (uso restrito).
- Power BI embarcado via `powerbi-client-angular` quando o relatório é dashboard analítico.

## 5.8 Edição rica de texto

- **CKEditor 5** usado em campos longos de parametrização e textos institucionais.
- **Quill (ngx-quill)** em campos de apontamento e justificativas.

## 5.9 Erros e mensagens

- 4xx → Toast com mensagem do backend (pt-BR).
- 5xx → Toast genérico "Erro inesperado".
- 401 → `MessageHttpInterceptor` força logout via `KeycloakService`.
- 403 → redireciona para `/forbidden`.

⚠️ Não há captura centralizada para envio a um sistema de observabilidade (Sentry/Datadog). Ver [08-technical-debt](./08-technical-debt.md).
