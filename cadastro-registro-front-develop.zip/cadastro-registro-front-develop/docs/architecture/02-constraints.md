# 2. Restrições

## 2.1 Restrições técnicas

| Categoria | Restrição | Origem |
|---|---|---|
| Framework | Angular 18.2.13 | Padrão arquitetural OCB |
| Linguagem | TypeScript 5.4.5 (strict) | tsconfig.json |
| Reatividade | RxJS 7.4.0 (sem signals adotados ainda) | Compatibilidade com submódulo |
| UI Kit | PrimeNG 17 + PrimeFlex 3 | Padrão visual SESCOOP |
| Build | Angular CLI 18.2.20, Sass 1.51.0 | Toolchain oficial |
| Auth | Keycloak OAuth2 com PKCE | Integração obrigatória com Keycloak corporativo |
| Backend obrigatório | `cadastro-registro-api` + `cadastro-registro-leitura-api` | CQRS leve no domínio |
| Submódulo | `src/public/` = `public-includes` (Git submodule) | Reuso entre frontends OCB |
| Heap dev | 4 GB (`NODE_OPTIONS=--max_old_space_size=4096`) | Tamanho do bundle Angular + PrimeNG |
| Browsers alvo | Conforme `.browserslistrc` (default Angular) | Padrão Angular CLI |

## 2.2 Restrições organizacionais

| Restrição | Implicação |
|---|---|
| Identidade visual SESCOOP | Tema `lara-light-blue` + `assets/omega/theme.scss` custom |
| Comunicação em pt-BR | Todas as mensagens e labels |
| Convenção monorepo OCB | Sufixo `-front`, `-api`, `-leitura-api` |
| Path aliases padronizados | `@core/*`, `@shared/*`, `@<api>-api/*`, `@utils/*` |
| Versionamento de submódulo | Coordenado com demais frontends OCB |
| Pipeline OpenShift | Dockerfile + ConfigMap por ambiente |

## 2.3 Restrições regulatórias e de domínio

| Tema | Restrição |
|---|---|
| LGPD | Tratamento de CPF, nome, endereço, e-mail, telefone de pessoas físicas (representantes, quadro social) |
| Auditoria | Backend mantém Hibernate Envers; front deve preservar identidade do usuário no header Authorization |
| Multi-tenant | Um usuário pode atuar em N entidades; rota `/selecionar-entidade` obrigatória quando há múltiplas |
| Acessibilidade | Objetivo WCAG 2.1 AA (não auditado formalmente) |

## 2.4 Convenções de código

- **Nomenclatura de arquivos:** `kebab-case.ts`. Componentes terminam com `.component.ts`, services com `.service.ts`, TOs com `*TO.ts`, enums com `Enum*.ts`.
- **Classes:** PascalCase (`PessoaFisicaService`, `CooperativaTO`).
- **Imports:** sempre via path alias quando aplicável.
- **Estrutura de feature:** `feature/<nome>/<sub>/` com `*.component.ts/html/scss`, `*.module.ts`, `*-routing.module.ts`.
- **Idioma:** identificadores técnicos em inglês; domínio cooperativista em português.

## 2.5 Restrições de equipe

- Equipe de frontend OCB compartilhada entre múltiplos projetos.
- Mudanças em `public-includes` impactam todos os frontends — exigem coordenação.
- Revisão de PRs obrigatória para `master`/`main`.

## 2.6 Limites conhecidos

⚠️ **Dependências desatualizadas** — `@angular-eslint` v14 (atual v19), `@angular/cdk` v17 (core já em v18). Atualização planejada — ver [08-technical-debt](./08-technical-debt.md).

⚠️ **PrimeNG sem tree-shake seletivo** — importação por NgModule infla bundle. Migração futura para imports standalone reduzirá tamanho.

⚠️ **Sem build sob Bazel ou Nx** — monorepo OCB é por convenção, não por ferramenta.
