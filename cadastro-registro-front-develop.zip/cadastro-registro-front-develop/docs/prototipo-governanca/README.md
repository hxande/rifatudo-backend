# Protótipo — Redesign da aba de Governança

Protótipo vinculante do redesign da aba de Governança (Registro e Manutenção),
referência de design da feature **002-refatorar-governanca** (accordion por
conselho, salvamento independente por órgão, inclusão inline de membro,
pendências por conselho e botão "Avançar").

- `Governanca.dc.html` — protótipo navegável (abrir no navegador; usa `support.js` e `fonts/`)
- `uploads/*.png` — capturas de tela de referência

Especificação e regras de negócio: `specs/002-refatorar-governanca/` no
repositório de specs (spec.md, plan.md, regras-consolidadas-2026-07-06.md).
