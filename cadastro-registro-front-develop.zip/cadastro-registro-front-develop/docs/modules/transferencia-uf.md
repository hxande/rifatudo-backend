# Módulo `transferencia-uf`

Feature lazy-loaded que trata a **mudança de jurisdição** de uma cooperativa entre OCB Estaduais. É um subprocesso regulatório com regras próprias e envolve aprovação dupla (UF de origem e UF de destino).

## Localização

`src/app/features/transferencia-uf/`

## Capacidades

| Tela | Responsabilidade |
|---|---|
| Solicitação | Abertura do pedido de transferência |
| Acompanhamento | Status do processo (em análise origem, em análise destino, concluído) |
| Análise OCB origem | Validação da UF que está perdendo a cooperativa |
| Análise OCB destino | Validação da UF que está recebendo |
| Histórico | Trilha do processo |

## Serviços consumidos

- `api-solicitacao.service.ts`
- `api-tipo-solicitacao.service.ts`
- `api-historico-processo-registro.service.ts`
- `api-controle-atualizacao-cadastral.service.ts`

## Fluxo resumido

```mermaid
flowchart LR
    A[Cooperativa solicita] --> B[OCB origem analisa]
    B -->|aprovado| C[OCB destino analisa]
    B -->|rejeitado| Z[Encerrado]
    C -->|aprovado| D[Transferência efetivada]
    C -->|rejeitado| Z
```

## Componentes compartilhados

- `validacao-dados` para checagem antes do envio.
- Editor **Quill** para justificativas.
- PrimeNG `Steps` para indicar etapa atual.

## Particularidades

- Estado é colaborativo entre cooperativa, OCB origem e OCB destino — front precisa refletir mudanças rapidamente (refresh ao abrir tela).
- Não há push notifications; depende de revisita do usuário ou e-mail enviado pelo backend.
- Após efetivação, a cooperativa muda de UF e isso impacta queries de leitura.

## Riscos específicos

⚠️ Operação irreversível na prática (reverter exige nova transferência). Front deve exigir confirmação dupla em ações terminais.
⚠️ Conflito potencial: se cooperativa edita dados durante a transferência, regras de bloqueio precisam ser respeitadas no front (mensagens claras).
