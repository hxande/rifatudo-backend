# Módulo `cooperativa`

Feature lazy-loaded para visualização e manutenção da cooperativa logada. É o módulo mais usado pelos cooperativistas.

## Localização

`src/app/features/cooperativa/`

## Capacidades

| Tela | Responsabilidade |
|---|---|
| Listagem | Pesquisa de cooperativas (perfil OCB) |
| Dados gerais | Identificação, endereço, contatos, dados bancários |
| Anuário v2 | Formulário dinâmico do anuário cooperativista |
| Quadro social | Pessoas físicas e jurídicas associadas; controle de ativação/inativação de membros (membro novo não pode ser inativado) |
| Filiais | CRUD de filiais e endereços |
| Responsáveis | Representantes legais, contadores |
| Documentos | Upload/download via `documentacao-api` |
| Histórico | Linha do tempo de alterações e processos |
| Visão gráfica | Dashboards via Power BI embarcado |

## Serviços consumidos

- `api-cooperativa-leitura.service.ts`
- `api-dados-gerais.service.ts`
- `api-manutencao-dados-gerais.service.ts`
- `api-quadro-social-uf.service.ts`
- `api-historico-processo-registro.service.ts`
- `api-anuario-negocio-exportacao.service.ts`
- `api-pessoa-cnpj.service.ts`
- Clients de `public/documentacao-api/`, `public/localizacao-api/`.

## Componentes compartilhados

- `governanca`, `filial`, `averbacao` — formulários reutilizáveis.
- `custom-accordion` para seções de dados gerais.
- `validacao-dados` para verificação cruzada.
- `powerbi-client-angular` em **visão gráfica**.

## Particularidades

- **Anuário v2** monta o formulário a partir de metadados retornados pelo backend — não há campos hardcoded.
- Campos numéricos usam `ng2-currency-mask`.
- Máscara de CPF/CNPJ **padronizada** nas telas e relatórios (2026-06); as máscaras de CNPJ aceitam o novo formato **alfanumérico** da Receita Federal — ver [ADR 0006](../architecture/decisions/0006-cnpj-alfanumerico.md). Validação/remoção de máscara via `@utils` (submódulo `public-includes`) e serviços de validação por componente. Ver [LGPD](../compliance/lgpd.md).
- Documentos baixados via `file-saver`.

## Particularidades LGPD

- Quadro social trata **CPF, nome completo, endereço, e-mail, telefone** de pessoas físicas.
- Logs devem evitar PII; uso de `console.log` em produção é débito ativo.

## Riscos específicos

⚠️ Anuário v2 é crítico para o ciclo regulatório anual; indisponibilidade no período de declaração afeta a base inteira. Falhas no `api-controlador-anuario-uf` precisam de fallback claro.
