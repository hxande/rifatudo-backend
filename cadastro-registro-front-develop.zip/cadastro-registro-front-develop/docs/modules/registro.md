# Módulo `registro`

Feature lazy-loaded que materializa o **processo de registro** completo de uma cooperativa na OCB. É o fluxo mais longo do sistema e envolve múltiplos passos com persistência incremental.

## Localização

`src/app/features/registro/`

## Capacidades

| Etapa | Responsabilidade |
|---|---|
| Requerimento | Abertura do processo de registro |
| Passos | Wizard com etapas sequenciais |
| Apontamentos | Análise/observações de analistas OCB |
| Governança | Composição de órgãos e mandatos |
| Negócio | Atividades econômicas e ramos |
| Filiadas | Vinculação a federações/centrais |
| Documentação | Upload de documentos obrigatórios |
| Transferência UF | Subfluxo para mudança de jurisdição (ver módulo dedicado) |

## Serviços consumidos

- `api-solicitacao.service.ts`
- `api-tipo-solicitacao.service.ts`
- `api-taxa-registro.service.ts`
- `api-manutencao-dados-gerais.service.ts`
- `api-historico-processo-registro.service.ts`
- `api-sistema-vinculacao.service.ts`
- Clients de `public/documentacao-api/` (upload), `public/boleto-api/` (taxa de registro).

## Componentes compartilhados

- `governanca`, `filial`, `averbacao` — reaproveitados do módulo `cooperativa`.
- `boleto` para emissão da taxa.
- Editor rico **Quill** em apontamentos e justificativas.

## Fluxo resumido

```mermaid
flowchart LR
    A[Início Requerimento] --> B[Governança]
    B --> C[Negócio]
    C --> D[Filiadas]
    D --> E[Documentação]
    E --> F[Taxa Boleto]
    F --> G[Submissão]
    G --> H[Apontamentos<br/>análise OCB]
    H -->|Aprovado| I[Registro emitido]
    H -->|Pendência| B
```

## Particularidades

- Persistência **incremental** por passo — usuário pode abandonar e retomar.
- Apontamentos da OCB voltam para o cooperativista corrigir; cliclo pode ter múltiplas iterações.
- Emissão de taxa via integração com `boleto-api`.
- Após submissão, backend emite evento consumido pelo GDH.

## Riscos específicos

⚠️ Persistência incremental + multi-tab pode causar conflitos. Backend valida concorrência (Hibernate Envers + optimistic locking).
⚠️ Fluxo longo e crítico — falhas afetam diretamente a entrada de novas cooperativas no sistema OCB.
