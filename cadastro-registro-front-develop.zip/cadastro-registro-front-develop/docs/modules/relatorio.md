# Módulo `relatorio`

Feature lazy-loaded para geração de relatórios analíticos e exportações.

## Localização

`src/app/features/relatorio/`

## Capacidades

| Funcionalidade | Detalhe |
|---|---|
| Filtros dinâmicos | UF, ramo, período, situação, perfil de cooperativa |
| Pré-visualização | Tabela com paginação server-side |
| Exportação Excel | Via backend (Apache POI / similar) |
| Exportação PDF | Via backend (JasperReports) |
| Relatórios parametrizados | Templates configurados em `administracao` |
| Quadro Social por UF | Relatório gerencial de quadro social consolidado por UF (adicionado em 2026-06) |

## Serviços consumidos

- `api-cooperativa-leitura.service.ts`
- `api-censo-anuario.service.ts`
- `api-anuario-negocio-exportacao.service.ts`
- `api-quadro-social-uf.service.ts` (relatório Quadro Social por UF)
- Clients de leitura em `public/cadastro-registro-leitura-api/`.

## Componentes compartilhados

- PrimeNG `Table` com `lazy="true"` e paginação server-side.
- PrimeNG `Calendar`, `Dropdown`, `MultiSelect` para filtros.
- `file-saver` para download client-side de Excel/PDF retornado pelo backend.

## Particularidades

- Geração pesada **delegada ao backend** — front só dispara o request e faz download.
- Exportações grandes podem demorar; UI exibe `p-progressSpinner` enquanto aguarda.
- ⚠️ Sem cancelamento de request — usuário precisa esperar ou recarregar página.

## Riscos específicos

⚠️ Relatórios consultam massas grandes (todas as cooperativas do Brasil). Filtros bem aplicados são essenciais para performance — o front deve impor seleção mínima de UF/período.
⚠️ Sem cache no front; mesma consulta repetida bate no backend toda vez.
