# Módulo `administracao`

Feature lazy-loaded responsável por todas as parametrizações administrativas do SOUCOOP. Acesso restrito ao role `CADASTRO_REGISTRO_ADMINISTRADOR`.

## Localização

`src/app/features/administracao/`

## Capacidades

| Tela | Responsabilidade |
|---|---|
| Ramo cooperativista | CRUD de ramos (agropecuário, crédito, saúde, etc.) |
| Cargo | CRUD de cargos da governança |
| Órgão de governança | CRUD de órgãos (Conselho Administrativo, Fiscal, etc.) |
| Documento | Tipos de documento aceitos |
| Certificado | Modelos e parametrização de certificados |
| Mandato | Mandatos de governança |
| Critério de associação | Critérios para associação à OCB |
| Controle de anuário | Janela e habilitação do anuário por UF |
| Controle de portfólio | Vínculos de portfólio |
| Validação em lote | Operações de validação massiva sobre cooperativas |
| Importação anuário | Bulk import de dados anuais |
| Ajuste de dados | Correções pontuais administrativas |
| Regional | CRUD de Regional e Regional UE (`regional/`, `regional-ue/`) |
| Parâmetro de quadro social | Parametrização de quadro social e quadro social do cooperado |

## Serviços consumidos

- `api-ramo.service.ts`
- `api-controle-anuario.service.ts`
- `api-controlador-anuario-uf.service.ts`
- `api-certificados.service.ts`
- `api-tipo-solicitacao.service.ts`
- Clients de `src/public/cadastro-registro-api/` para CRUD de tabelas auxiliares.

## Componentes compartilhados utilizados

- `custom-accordion` para agrupar parametrizações.
- `validacao-dados` para fluxos de validação em lote.
- PrimeNG `Table`, `Dialog`, `Calendar`, `Dropdown`.

## Particularidades

- **Validação em lote** executa operações longas; UI mostra progresso via `p-progressBar`.
- **Importação anuário** usa `file-upload` do submódulo `public/gui/`.
- Algumas telas possuem TODOs ativos (ex.: `mantem-criterio-associacao` — "substituir pelo método correto"). Ver [08-technical-debt](../architecture/08-technical-debt.md).

## Acessibilidade e UX

- Mensagens de confirmação via `ConfirmationService` PrimeNG.
- Toasts pt-BR via `MessageService`.

## Riscos específicos

⚠️ Telas administrativas operam sobre **dados estruturais do sistema**. Erros têm impacto amplo. Auditoria backend (Hibernate Envers) é essencial — front deve sempre preservar identidade no header Authorization.
