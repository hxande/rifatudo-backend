# Padrões de Consumo de APIs

Este documento descreve **como o frontend consome** APIs do ecossistema OCB. Não substitui o Swagger de cada backend — ver `/swagger-ui.html` do respectivo serviço.

## 1. Configuração de hosts

Hosts são resolvidos por `environment.ts` em três níveis (ver [ADR 0005](../architecture/decisions/0005-environments-multi-backend.md)):

1. `backendEnv` — default global (`local | hmlg | trt`).
2. `apisEnv` — sobrescreve por API quando necessário.
3. Clients em `src/public/<api>/` consultam essa configuração para montar URL base.

## 2. Autenticação

Toda chamada HTTP passa pelo `AuthHttpInterceptor` (em `src/public/auth/`), que:

1. Recupera o token do `KeycloakService`.
2. Injeta `Authorization: Bearer <jwt>` em hosts conhecidos.
3. Não injeta em chamadas externas (assets, CDN).

Rotas públicas: `AcessoPublico.isRotaPublica(url)` controla quando o guard libera acesso (ex.: confirmação de e-mail).

## 3. Tratamento de erros

`MessageHttpInterceptor` captura respostas e:

- **4xx** → Toast com `error.message` ou `error.title` retornado pelo backend (formato `ProblemDetail` quando aplicável).
- **5xx** → Toast genérico "Erro inesperado".
- **401** → logout via `KeycloakService.logout()`.
- **403** → redirect para `/forbidden`.

## 4. Services por entidade

Padrão `api-<entity>.service.ts` em `src/app/api/services/`. Lista (32+ services):

```
api-anuario-negocio-exportacao.service.ts
api-cooperativa-leitura.service.ts
api-dados-gerais.service.ts
api-manutencao-dados-gerais.service.ts
api-certificados.service.ts
api-ramo.service.ts
api-solicitacao.service.ts
api-taxa-registro.service.ts
api-tipo-solicitacao.service.ts
api-pessoa-cnpj.service.ts
api-quadro-social-uf.service.ts
api-sistema-vinculacao.service.ts
api-controle-anuario.service.ts
api-controle-atualizacao-cadastral.service.ts
api-historico-processo-registro.service.ts
api-censo-anuario.service.ts
api-controlador-anuario-uf.service.ts
... (e demais)
```

Cada service:
- Recebe `HttpClient` por DI.
- Resolve URL base a partir do `environment` + nome da API.
- Retorna `Observable<TO>` ou `Observable<TO[]>`.
- TOs ficam em `src/app/api/models/` ou `src/public/<api>/model/`.

## 5. Convenções

| Tema | Convenção |
|---|---|
| Verbos | `listar`, `buscar`, `salvar`, `atualizar`, `remover` — espelham CRUD do backend |
| Filtros | TOs `*FiltroTO` com paginação `page` + `size` + `sort` |
| Datas | ISO 8601 string; conversão para `Date` via mapper |
| Paginação | Resposta padrão `Spring Page<T>` — `{ content, totalElements, totalPages, ... }` |
| Multipart | Upload de documentos via `FormData` no `documentacao-api` |
| Bulk | Endpoints `/lote/*` ou `/importar/*` em features administrativas |

## 6. Path aliases relevantes

```jsonc
"@cadastro-registro-api/*":           ["src/public/cadastro-registro-api/*"],
"@cadastro-registro-leitura-api/*":   ["src/public/cadastro-registro-leitura-api/*"],
"@documentacao-api/*":                ["src/public/documentacao-api/*"],
"@localizacao-api/*":                 ["src/public/localizacao-api/*"]
```

## 7. CQRS leve

O domínio adota separação:

- **Escrita:** `cadastro-registro-api` (comandos: salvar, atualizar, remover).
- **Leitura:** `cadastro-registro-leitura-api` (queries otimizadas, views materializadas, filtros pesados).

O front decide qual chamar baseado na natureza da operação.

## 8. Headers especiais

- `Authorization: Bearer <jwt>` — sempre.
- `Accept-Language: pt-BR` — implícito.
- Cabeçalhos de seleção de entidade quando aplicável (sigla UF, código entidade) — definidos pelos backends; clients gerados encapsulam.

## 9. Diagnóstico

- `HttpStatusService` em `src/public/auth/http/` mantém estado de saúde HTTP utilizado por telas administrativas.
- ⚠️ Sem trace ID propagado client-side (não há cabeçalho `X-Trace-Id` injetado). Recomendação: instrumentar em camada futura de observabilidade.

## 10. Versionamento

- Quebra de contrato no backend exige atualização coordenada do submódulo `public-includes`.
- Recomenda-se versionar TOs e marcar campos novos como opcionais para suportar rollback.
