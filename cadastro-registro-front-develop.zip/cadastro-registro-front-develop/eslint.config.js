import eslint from '@eslint/js';
import angular from 'angular-eslint';
import localRules from 'eslint-plugin-local-rules';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  {
    ignores: ['projects/**/*', 'src/public/**/*'],
  },
  {
    files: ['**/*.ts'],
    extends: [
      eslint.configs.recommended,
      ...tseslint.configs.recommended,
      ...angular.configs.tsRecommended,
    ],
    processor: angular.processInlineTemplates,
    languageOptions: {
      parserOptions: {
        project: ['tsconfig.json', 'e2e/tsconfig.json'],
        createDefaultProgram: true,
      },
    },
  },
  {
    files: ['**/*.html'],
    extends: [
      ...angular.configs.templateRecommended,
    ],
    plugins: {
      'local-rules': localRules,
    },
    rules: {
      '@angular-eslint/template/eqeqeq': 'off',
      '@angular-eslint/template/use-track-by-function': 'warn',
      '@angular-eslint/template/no-inline-styles': 'error',
      'local-rules/no-style-binding-on-restricted-tags': 'error',
    },
  },
);
