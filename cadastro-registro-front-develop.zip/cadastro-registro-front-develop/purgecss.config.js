module.exports = {
  content:["./dist/**/*.html","./dist/**/*.js"],
  css:["./dist/**/*.css"],
  defaultExtractor: (content) => content.match(/[A-Za-z0-9-_:/]+/g) || []
};
