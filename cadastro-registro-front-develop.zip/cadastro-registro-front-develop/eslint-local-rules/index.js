'use strict';

const { getTemplateParserServices } = require('@angular-eslint/utils');

const RESTRICTED_TAGS = new Set(['div', 'p', 'button', 'th']);

// Equivalente local à antiga @html-eslint/no-restricted-attrs (attrPatterns: [style], tagPatterns: div/p/button/th):
// proíbe o binding de propriedade [style] nessas tags, incentivando o uso de styleClass.
module.exports = {
  rules: {
    'no-style-binding-on-restricted-tags': {
      meta: {
        type: 'suggestion',
        docs: {
          description: 'Disallow [style] property bindings on <div>/<p>/<button>/<th>; use styleClass instead.',
          recommended: false,
        },
        schema: [],
        messages: {
          noStyleBinding: '<{{element}}> não deve usar [style]. Utilize styleClass.',
        },
      },
      create(context) {
        const parserServices = getTemplateParserServices(context);

        return {
          Element$1(node) {
            if (!RESTRICTED_TAGS.has(node.name)) return;

            const hasStyleBinding = node.inputs.some((input) => input.name === 'style');
            if (!hasStyleBinding) return;

            context.report({
              loc: parserServices.convertElementSourceSpanToLoc(context, node),
              messageId: 'noStyleBinding',
              data: { element: node.name },
            });
          },
        };
      },
    },
  },
};
