const dto = {
  data: [{
      nome: "homem",
      valor: 18,
      propriedades: {
        type: "numero", // number/text/double/
        mask: "cpf",
        componente: "input",
        mascara: "dinheiro",
        requerido: true,
      }
  },
    {
      nome: "homem",
      valor: 18,
      propriedades: {
        type: "numero", // number/text/double/
        mask: "cpf",
        componente:{
        componente: "table",
        hearders: ["fadfa"],
        rows: []
        },
        mascara: "dinheiro",
        requerido: true,
      }
  }

]

}




