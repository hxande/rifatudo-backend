@echo off
setlocal enableDelayedExpansion

set fileCount=0
set batchSize=0
set fileList=

for /f "eol=: delims=" %%F in ('git diff --name-only HEAD --diff-filter=ACMRTUXB -- *.ts') do (
  set /a fileCount+=1
  set /a batchSize+=1
  if .!fileList!==. (
    set fileList=%%F
  ) else (
    set fileList=!fileList! %%F
  )
  if !batchSize! GEQ 50 (
    echo Linting lote de !batchSize! arquivos...
    call npx tslint !fileList! || exit /b 1
    set batchSize=0
    set fileList=
  )
)

if !batchSize! GTR 0 (
  echo Linting !batchSize! arquivos...
  call npx tslint !fileList! || exit /b 1
)

if %fileCount% EQU 0 (
  echo Lint: Nenhum arquivo para verificar.
)

exit /b 0
