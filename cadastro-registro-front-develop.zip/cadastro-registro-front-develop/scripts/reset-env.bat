@echo off
setlocal enableDelayedExpansion

echo Resetando ambiente dev...

copy .\src\environments\environment.dev.ts .\src\environments\environment.ts

git add .\src\environments\environment.ts
