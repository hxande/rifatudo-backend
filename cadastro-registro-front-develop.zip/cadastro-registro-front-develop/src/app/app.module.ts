// Angular Imports
// App Imports
import { registerLocaleData } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import localePt from '@angular/common/locales/pt';
import { APP_INITIALIZER, ErrorHandler, LOCALE_ID, NgModule } from '@angular/core';
import { AUTH_GUARD_ROUTE_MAPS, KEYCLOAK_CLIENT_ID, KeyclokClientEnum } from '@auth/auth-guard/constants';
import { AuthHttpInterceptor } from '@auth/auth-interceptor';
import { AuthModule } from '@auth/auth.module';
import { AcessoPublico } from '@auth/keycloak-service/acesso-publico';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { BoletoApiModule } from '@boleto-api/boleto-api.module';
import { CadastroRegistroApiModule } from '@cadastro-registro-api/cadastro-registro-api.module';
import { CadastroRegistroLeituraApiModule } from '@cadastro-registro-leitura-api/cadastro-registro-leitura-api.module';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { GlobalErrorHandler } from '@core/global-error-handler';
import { MessageHttpInterceptor } from '@core/message-http-interceptor';
import { DocumentacaoApiModule } from '@documentacao-api/documentacao-api.module';
import { GerenciaUsuarioApiModule } from '@gerencia-usuario-api/gerencia-usuario-api.module';
import { LocalizacaoApiModule } from '@localizacao-api/localizacao-api.module';
import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { RelatorioApiModule } from '@relatorio-api/relatorio-api.module';
import { UploadApiModule } from '@upload-api/upload-api.module';
import { UtilsModule } from '@utils/utils.module';
import { ConfirmationService, MessageService } from 'primeng/api';
import { appRoutesRoleMaps } from './app-routes-role-maps';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { CustomSpinnerModule } from 'src/public/custom-spinner/custom-spinner.module';

registerLocaleData(localePt, 'pt-BR');

@NgModule({
  declarations: [AppComponent],
  imports: [
    AppRoutingModule,
    CoreModule,
    CustomSpinnerModule,
    UtilsModule.forRoot(),
    AuthModule.forRoot(),
    CadastroRegistroApiModule.forRoot(),
    GerenciaUsuarioApiModule.forRoot(),
    LocalizacaoApiModule.forRoot(),
    DocumentacaoApiModule.forRoot(),
    BoletoApiModule.forRoot(),
    UploadApiModule.forRoot(),
    CadastroRegistroLeituraApiModule.forRoot(),
    RelatorioApiModule.forRoot(),
    NgIdleKeepaliveModule.forRoot(),
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the application is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000',
    }),
  ],
  providers: [
    MessageHttpInterceptor,
    BreadcrumbService,
    ConfirmationService,
    MessageService,
    {
      provide: KEYCLOAK_CLIENT_ID,
      useValue: KeyclokClientEnum.CadastroRegistro,
    },
    {
      provide: AUTH_GUARD_ROUTE_MAPS,
      useValue: appRoutesRoleMaps,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: onAppInit,
      multi: true,
      deps: [KeycloakService],
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthHttpInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MessageHttpInterceptor,
      multi: true,
    },
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

export function onAppInit(keycloakService: KeycloakService): () => Promise<unknown> {
  return (): Promise<unknown> => {
    if (AcessoPublico.isRotaPublica()) {
      return null;
    } else {
      return keycloakService.initialize();
    }
  };
}
