import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoadingService {
  private _loading = new BehaviorSubject<boolean>(false);

  loading$ = this._loading.asObservable();

  setLoading(isLoading: boolean): void {
    this._loading.next(isLoading);
  }
}