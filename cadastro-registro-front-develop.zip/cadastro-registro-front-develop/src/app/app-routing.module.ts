import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConfirmacaoEmailComponent } from '@core/confirmacao-email/confirmacao-email.component';
import { ForbiddenComponent } from '@core/forbidden/forbidden.component';
import { SelecionarEntidadeComponent } from '@core/selecionar-entidade/selecionar-entidade.component';
import { UsuarioComponent } from '@core/usuario/usuario.component';

const appRoutes: Routes = [
  { path: 'inicio', loadChildren: () => import('./features/inicio/inicio.module').then((m) => m.InicioModule) },
  {
    path: 'cooperativa',
    loadChildren: () => import('./features/cooperativa/cooperativa.module').then((m) => m.CooperativaModule),
  },
  {
    path: 'administracao',
    loadChildren: () => import('./features/administracao/administracao.module').then((m) => m.AdministracaoModule),
  },
  {
    path: 'transferencia-uf',
    loadChildren: () => import('./features/transferencia-uf/transferencia-uf.module').then((m) => m.TransferenciaUfModule),
  },
  { path: 'registro', loadChildren: () => import('./features/registro/registro.module').then((m) => m.RegistroModule) },
  { path: 'confirmacao-email', component: ConfirmacaoEmailComponent },
  { path: 'usuarios', component: UsuarioComponent },
  { path: 'selecionar-entidade', component: SelecionarEntidadeComponent },
  { path: 'forbidden', component: ForbiddenComponent },

  { path: 'consulta-certificado-registro', redirectTo: '/registro/consulta-certificado'},
  { path: 'requerimento-registro', redirectTo: '/registro/requerimento'},
  { path: 'relatorio', loadChildren: () => import('./features/relatorio/relatorio.module').then((m) => m.RelatorioModule),}, 
  {
    path: 'exportacao-dados',
    loadChildren: () => import('./features/exportacao-dados/exportacao-dados.module').then((m) => m.ExportacaoDadosModule),
  },
  { path: '**', redirectTo: 'inicio' },
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule],
  providers: [],
})
export class AppRoutingModule {}
