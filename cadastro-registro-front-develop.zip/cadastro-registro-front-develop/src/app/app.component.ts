import { AfterViewInit, ChangeDetectorRef, Component, DestroyRef, inject, Inject, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AcessoPublico } from '@auth/keycloak-service/acesso-publico';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KEYCLOAK_CLIENT_ID, KeyclokClientEnum } from '@auth/auth-guard/constants';
import { HTTPStatus } from '@auth/http/http-status.service';
import { PrimeNGConfig } from 'primeng/api';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { LoadingService } from './services/loading-service';
import { combineLatest, filter } from 'rxjs';
import { SpinnerService } from '@utils/utility/spinner.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  loading = false;

  activeTopbarItem: Element;
  topbarMenuActive: boolean;
  topbarMenuClick: boolean;
  sidebarActive: boolean;
  topbarMenuButtonClick: boolean;
  isConsultaCertificadoRoute: boolean = false;
  constructor(private httpStatus: HTTPStatus,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private loadingService: LoadingService,
    private spinnerService: SpinnerService,
    private keycloakService: KeycloakService,
    private router: Router,
    @Inject(KEYCLOAK_CLIENT_ID) private clientId: KeyclokClientEnum,
    private config: PrimeNGConfig, private languageService: LanguageService,
  ) { }

  ngOnInit() {
    this.router.events
    .pipe(
      filter(event => event instanceof NavigationEnd),
      takeUntilDestroyed(this.destroyRef)
    )
    .subscribe((event: NavigationEnd) => {
      this.isConsultaCertificadoRoute = event.urlAfterRedirects === '/registro/consulta-certificado';
      this.changeDetectorRef.markForCheck();
    });
    combineLatest([
      this.loadingService.loading$,
      this.httpStatus.getHttpStatus()
    ])
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(([isLoadingFromService, isInFlight]) => {
      // Verifica se qualquer um dos observáveis está indicando que está carregando
      // this.loading = isLoadingFromService || isInFlight;

      if(isLoadingFromService || isInFlight){
         this.spinnerService.startLoading();
      }else{
        this.spinnerService.stopLoading();
      }
      this.changeDetectorRef.markForCheck();
    });


    this.verificarSituacaoRegistro();
    this.config.setTranslation({...this.languageService.pt,
      emptyMessage: "Nenhum registro encontrado.",
      emptyFilterMessage: "Nenhum registro encontrado."});
  }

  ngAfterViewInit(): void {
    document.addEventListener('click', (event) => {
      const menu = document.getElementById('menuUsuarioContainer');
      if (!menu.contains(event.target as Node)) {
        if (this.activeTopbarItem === menu) {
          this.activeTopbarItem = null;
        } else {
          this.activeTopbarItem = menu;
        }
      }
    });
  }

  verificarSituacaoRegistro() {
    if(this.keycloakService.getToken()) {
      this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          if (!coop.numeroRegistroOCB && coop.progressoMicro === ProgressoMicroEnum.PRE_CADASTRO_0_0) {
              this.router.navigate(['/registro/requerimento']);
          }
        }
        this.changeDetectorRef.markForCheck();
      });
    }
  }


  onTopbarMobileMenuButtonClick(event: Event) {
    this.topbarMenuButtonClick = true;
    this.topbarMenuActive = !this.topbarMenuActive;

    event.preventDefault();
  }

  onMenuButtonClick(event: Event) {
    this.sidebarActive = !this.sidebarActive;

    event.preventDefault();
  }

  onTopbarRootItemClick(event: Event, item: Element) {
    if (this.activeTopbarItem === item) {
      this.activeTopbarItem = null;
    } else {
      this.activeTopbarItem = item;
    }

    event.preventDefault();
  }

  onTopbarMenuClick(event: Event) {
    this.topbarMenuClick = true;
  }

  isAcessoPublico() {
    return AcessoPublico.isRotaPublica();
  }

  get hasApplicationRole(): boolean {
    return this.keycloakService.hasRole('CADASTRO_REGISTRO_USUARIO_ATIVO', this.clientId);
  }
}
