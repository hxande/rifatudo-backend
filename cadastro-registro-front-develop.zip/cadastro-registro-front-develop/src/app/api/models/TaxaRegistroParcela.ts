export interface TaxaRegistroParcela {
    id: number;
    numeroParcela: number;
    valor: number;
    desconto: number;
    juros: number;
    multa: number;
    valorFinal: number;
    valorPago: number;
    dataPagamento: string;
    dataVencimento: string;
    dataGeracao: string;
    dataRepasse: string;
    usuario: string;
    status: string;
}