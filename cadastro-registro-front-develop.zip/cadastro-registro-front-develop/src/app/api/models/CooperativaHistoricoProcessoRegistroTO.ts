export interface CooperativaHistoricoProcessoRegistroTO {
    id: number;
    dataAtualizacao: Date;
    acao: string;
    fase: string;
    usuario: string;
    cooperativaId: number;
}
