import { IServiceMessage } from '@utils/interfaces/IServiceMessage';

export interface CertificadoRegularidadeUnidadeEstadualTO {
  id: number;
  arquivo: string;
  uf: string;
  inAtiva: boolean;
}

// Ajuste para refletir corretamente a resposta da API
export interface ApiResponse<T> {
  messages: IServiceMessage[];
  data: T;
}