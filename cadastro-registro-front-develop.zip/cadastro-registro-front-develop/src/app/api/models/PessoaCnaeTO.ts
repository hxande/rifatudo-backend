import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { CnaeTO } from './CnaeTO';

export class PessoaCnaeTO {
    id: number;
    cnae: CnaeTO;
    pessoaJuridica: PessoaJuridica;
    primario: boolean;
}