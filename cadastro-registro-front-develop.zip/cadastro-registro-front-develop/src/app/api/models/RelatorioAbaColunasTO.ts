import { RelatorioColuna } from "./RelatorioColunasTO";

export class RelatorioAbaColunas {
    aba: string;
    colunas: RelatorioColuna[];
  }