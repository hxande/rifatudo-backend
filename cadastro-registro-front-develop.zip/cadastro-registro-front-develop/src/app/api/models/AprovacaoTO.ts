
export class AprovacaoTO {
    id: number;
    ano: number;
    dataAtualizacao: Date;
    idCooperativa: number;
}
