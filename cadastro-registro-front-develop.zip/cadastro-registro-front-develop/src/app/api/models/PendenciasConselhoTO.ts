/**
 * Pendências de um conselho/órgão para fins de submissão agregada da aba.
 *
 * Contrato HTTP interno do redesign (GET `/{cooperativaId}/pendencias`).
 * Alinhado ao motor de regras do backend: `coopPossui = false` não gera
 * pendência de mínimo.
 */
export class PendenciasConselhoTO {
  /** Identificador do órgão/conselho (Orgao.id). */
  idOrgao: number;
  /** Nome do órgão, para exibição. */
  nomeOrgao: string;
  /** Se a cooperativa possui este conselho. */
  coopPossui: boolean;
  /** Se as pendências deste conselho bloqueiam o "Avançar". */
  bloqueiaAvancar: boolean;
  /** Mensagens de pendência (pt-BR) necessárias para submeter. */
  pendencias: string[];
  estadoPreenchimento?: 'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null;
}
