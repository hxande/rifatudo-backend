export class Ramo {
    id: number;
    nome: string;
    detalhamento: string;
    imagem: string;
    ativo: boolean;
    excluido: boolean;
    segmentoUnico?: boolean;
}
