export interface CooperativaBuscaCnpjResult {
  id: number;
  nomeFantasia?: string;
  razaoSocial?: string;
  cnpj?: string;
  ufSigla?: string;
}
