import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { Arquivo } from '@upload-api/models/Arquivo';
import { Ramo } from './Ramo';

export class PessoaJuridicaBasicaTO {
    id: number;
    cnpj: string;
    razaoSocial: string;
    nomeFantasia: string;
    ufSigla: string;
    tipoPessoa: string;
    ramo: Ramo;
    telefone: string;
    email: string;
    endereco: Endereco;
    // Transient
    cnpjValidado = false;
    arquivos: Arquivo[];
    documentacaoJson: string;
    dataConstituicao?: string;
}
