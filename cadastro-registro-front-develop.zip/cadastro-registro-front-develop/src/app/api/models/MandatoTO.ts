import { Orgao } from "@cadastro-registro-api/models/Orgao";
import { UltimaAcaoTO } from "@cadastro-registro-api/models/UltimaAcaoTO";
import { Aprovacao } from "./Aprovacao";
import { MandatoMembro } from "./MandatoMembro";

export class MandatoTO {
    id: number;
    dataAssembleia: Date;
    orgao: Orgao;
    fimMandato: Date;
    anosDuracao: number;
    membrosMandato: number;
    vigente: boolean;
    aprovacao: Aprovacao;
    coopPossui: boolean;
    dataAssembleiaStr: string;
    listaMandatoMembro: MandatoMembro[];

    tamListaMembrosAtivos: number;
    tamMinLista: number;
    mostrarInativos: boolean;

    /**
     * Data de fim do contrato usada SOMENTE no desmarque da Diretoria
     * Contratada (coopPossui=false) com membros ativos — o backend desativa os
     * membros com esta data (RN-DC-02, feature 003).
     */
    dataFimContrato: Date | null;

    /** Última ação da trilha — presente apenas quando o backend liberar (perfil Nacional). */
    ultimaAcao?: UltimaAcaoTO;

}
