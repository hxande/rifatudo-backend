import { AreaContato } from "./AreaContato";
import { Pessoa } from "./Pessoa";


export class Contato {
    id: number;
    nomeResponsavel: string;
    telefone: string;
    celular: string;
    email: string;
    site: string;
    pessoa: Pessoa;
    areaContato: AreaContato;
    cargo: string;
}