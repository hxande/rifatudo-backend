import { TaxaRegistroParcela } from './TaxaRegistroParcela';

export interface TaxaRegistro {
    id: number;
    status: string;
    idCooperativa: number;
    valor: number;
    desconto: number;
    juros: number;
    multa: number;
    valorPago: number;
    valorTotal: number;
    listaParcelas: TaxaRegistroParcela[];
}