import { PessoaCnae } from '@cadastro-registro-api/models/PessoaCnae';
import { PessoaSegmProdServ } from '@cadastro-registro-api/models/PessoaSegmProdServ';
import { Faturamento } from '@cadastro-registro-api/models/Faturamento';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { Negocio } from '@cadastro-registro-api/models/Negocio';

export class NegocioTO {
    ramo: Ramo;
    segmentos: Segmento[];
    produtos: Produtoservico[];
    faturamento: number;

    // CNAE
    cnaePrimario: PessoaCnae;

    listaPessoaSegmProdServ: PessoaSegmProdServ[];
    faturamentoAtual:  Faturamento;

    filiadas: PessoaJuridicaBasicaTO[];


    tranformaNegocioEmTO(negocio: Negocio){

        const negocioTO = new NegocioTO();

        negocioTO.ramo = negocio.ramo;
        negocioTO.segmentos = negocio.segmentos;
        negocioTO.produtos = negocio.produtos;
        negocioTO.faturamento = negocio.faturamento;
        negocioTO.cnaePrimario = negocio.cnaePrimario;
        negocioTO.listaPessoaSegmProdServ = negocio.listaPessoaSegmProdServ;
        negocioTO.faturamentoAtual = negocio.faturamentoAtual;
        negocioTO.filiadas = negocio.filiadas;

        return negocioTO;
    }

}
