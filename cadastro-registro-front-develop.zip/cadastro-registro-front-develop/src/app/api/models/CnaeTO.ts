export class CnaeTO {
    codigo: string;
    descricao: string;
    ativo: boolean;
}