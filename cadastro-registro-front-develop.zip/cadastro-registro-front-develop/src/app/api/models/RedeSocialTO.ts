
export interface TipoRedeSocialItem {
    label: string;
    value: string;
}

export class RedeSocialTO {
    id: number;
    tipoRedeSocial: string;
    tipoRedeSocialItem: TipoRedeSocialItem;
    link: string;
}
