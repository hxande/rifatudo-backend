export interface AnuarioSalvarPayloadField {
    id: string;
    name: string;
    value: string | number | null | String[];
    idParametro?: number | string | null;
    idParametroAuxiliar?: number | string | null;
    parametroIntegracao?: unknown;
}

export interface AnuarioSalvarPayloadPanel {
    name: string;
    idQuadro: number | null;
    fields: AnuarioSalvarPayloadField[][];
}

export interface AnuarioSalvarPayloadTO {
    id: string;
    situacao: number;
    fields: AnuarioSalvarPayloadPanel[];
}
