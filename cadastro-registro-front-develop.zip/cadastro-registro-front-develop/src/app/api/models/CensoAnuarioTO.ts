export class CensoAnuarioTO {
    ano: number;
    idCooperativa: number;
    dataSubmissao: Date;
    usuario: string;
}