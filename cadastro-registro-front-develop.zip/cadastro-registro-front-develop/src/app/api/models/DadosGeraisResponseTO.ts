import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { RedeSocial } from '@cadastro-registro-api/models/RedeSocial';

export class DadosGeraisResponseTO {
    idCooperativa: number;
    categoria: Categoria;
    regidaPorLei: boolean;
    idSindicato: number;
    filiadaSindicato: boolean;
    enderecos: Endereco[];
    redesSociais: RedeSocial[];
    cooperativasVinculadas: CooperativaBasica[];
    quadroSocialAtual: QuadroSocial;
    pessoaJuridica: PessoaJuridica;
    quadroSocialManutencao: QuadroSocial;
}