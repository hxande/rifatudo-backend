export class SistemaVinculacaoCooperativaTO {
    id: number;
    idCooperativa: number;
    idSistemaVinculacao: number;
    siglaSistemaVinculacao: string;
    cnpj: string;
    nomeFantasia: string;
    ramo: string;
    grau: string;
    uf: string;
    excluido: boolean;
}