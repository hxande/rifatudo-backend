export class ControleAtualizacaoCadastralTO{
    id: number;
    uf: string;
    mostrarPopup: boolean;
    destacarAtualizacaoCadastral: boolean;
    textoPopup: string;
    permiteCooperativaPreencher: boolean;
    permiteCooperativaVisualizar: boolean;
    permiteEstadualPreencher: boolean;
    visualizarPeriodoAtualizacao: boolean;
} 