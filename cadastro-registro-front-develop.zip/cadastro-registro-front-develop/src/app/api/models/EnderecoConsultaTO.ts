import { Pessoa } from './Pessoa';
import { Municipio } from '../../../public/localizacao-api/models/Municipio';

export interface EnderecoConsultaTO {
    cep: string;
    pessoa: Pessoa;
    logradouro: string;
    complemento: string;
    bairro: string;
    municipio: Municipio;
}
