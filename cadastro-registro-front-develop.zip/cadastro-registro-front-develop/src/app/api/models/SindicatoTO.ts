export class RamoBasicoTO {
  id: number;
  nome: string;
  detalhamento?: string;
}

export class SindicatoTO {
  id: number;
  idPessoaJuridica: number;
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string;
  ufSede: string;
  ufsRepresentacao: string[] = [];
  ramos: RamoBasicoTO[] = [];
  ativo: boolean;
  oce: boolean;
  tipoPessoa: string;
}
