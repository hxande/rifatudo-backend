export interface NegocioExportacaoPaisId {
    negocioExportacaoId: number;
    paisId: number;
}

export interface NegocioExportacaoPais {
    id: NegocioExportacaoPaisId;
    nomePais: string;
}

export interface NegocioExportacao {
    id: number;
    exportacao: boolean;
    ano: number;
    modalidade: string;
    paises: NegocioExportacaoPais[];
}

export interface PaisTO {
    id: number;
    nome: string;
    brasil?: boolean;
    situacao?: boolean;
}

export interface NegocioExportacaoTO {
    cooperativaId: number;
    ano: number;
    exportacao: boolean;
    modalidade: string;
    paises: PaisTO[];
}
