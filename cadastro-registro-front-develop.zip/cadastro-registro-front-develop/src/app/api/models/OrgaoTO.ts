export class OrgaoTO {
    nome: string;
    vinculo?: string;
}
