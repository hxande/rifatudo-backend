/**
 * Uma ação da trilha completa de auditoria de governança do conselho.
 *
 * Contrato HTTP interno do redesign (GET
 * `/{cooperativaId}/conselho/{orgaoId}/trilha-acoes`). O backend só responde
 * para a unidade Nacional (403 para os demais perfis) — o front só exibe o
 * link quando `ultimaAcao` veio preenchida, que segue o mesmo gate.
 */
export class AcaoGovernancaTO {
  /** Id do mandato na época da ação; nulo quando o mandato foi excluído. */
  idMandato: number | null;
  /** Nome do enum de tipo de ação (ex.: ENCERRAMENTO_MANDATO). */
  tipo: string;
  /** Rótulo pt-BR da ação (ex.: "Mandato encerrado"). */
  rotulo: string;
  /** Login do usuário executor. */
  usuario: string;
  dataHora: string;
  /** Linha 1 = resumo; demais linhas = detalhe antes → depois. */
  descricao: string | null;
}
