import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { PessoaSegmProdServ } from '@cadastro-registro-api/models/PessoaSegmProdServ';
import { Faturamento } from '@cadastro-registro-api/models/Faturamento';
import { PessoaJuridicaBasicaTO } from './PessoaJuridicaBasicaTO';
import { Ramo } from '@cadastro-registro-api/models/Ramo';

export class AbaManutencaoSegmentacaoFiliaisTO {
    idCooperativa: number;
    ramo: Ramo;
    segmentos: Segmento[];
    produtos: Produtoservico[];
    faturamento: number;
    faturamentoAtual:  Faturamento;
    listaPessoaSegmProdServ: PessoaSegmProdServ[];
    filiadas: PessoaJuridicaBasicaTO[];
    aba: string;
}
