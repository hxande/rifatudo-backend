import { MandatoTO } from "./MandatoTO";

export class GovernancaTO {
    mandato: MandatoTO; //
}
