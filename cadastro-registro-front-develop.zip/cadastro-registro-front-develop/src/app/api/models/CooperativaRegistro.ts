import { EnumTipoAcao } from '@cadastro-registro-api/models/EnumTipoAcao';
import { RegistroEmail } from '@cadastro-registro-api/models/RegistroEmail';
import { Situacao } from '@cadastro-registro-api/models/Situacao';
import { CooperativaTO } from './CooperativaTO';
import { CooperativaSolicitacao } from './CooperativaSolicitacao';


export class CooperativaRegistro {
    id: number; // [SQ_PESSOA_REGISTRO]
    status: string; // [IN_STATUS_COOPERATIVA]
    situacao: Situacao; // [SQ_SITUACAO_COOPERATIVA]
    justificativaRegistro: string; // [TX_JUSTIFICATIVA_REGISTRO]
    dtAlteracao: Date; // [DT_ALTERACAO_SITUACAO_STATUS]
    loginAlteracaoSituacao: string; // [TX_LOGIN_USUARIO_ALTERACAO_SITUACAO_STATUS]
    cooperativa: CooperativaTO; // [SQ_COOPERATIVA]
    justificativaSolicitacaoInativacao: string;
    justificativaCancelada: string;
    justificativaInativada: string;
    justificativaIrregular: string;
    justificativaAtivacao: string;
    justificativaSolicitacaoAtivacao: string;
    justificativaSolicitacaoCancelamento: string;
    anexo: string;
    anexoNotificacao: string;
    cooperativaSolicitacao: CooperativaSolicitacao;
    solicitacaoInativacao: boolean;
    solicitacaoAtivacao: boolean;
    solicitacaoCancelamento: boolean;
    tipoAcao: EnumTipoAcao;
    registroEmail: RegistroEmail;
}
