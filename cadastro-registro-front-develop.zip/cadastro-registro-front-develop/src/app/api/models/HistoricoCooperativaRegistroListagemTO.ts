import { ComentarioDataTO } from './comentarioDataTO';
import { CooperativaRegistro } from './CooperativaRegistro';


export class HistoricoCooperativaRegistroListagemTO {
  cooperativaRegistro: CooperativaRegistro;
  cnpj: string;
  acao: string;
  situacao: string;
  regularidade: string;
  situacaoCooperativa: string;
  novaSituacao: string;
  justificativaUE: string;
  justificativaUN: string;
  subHistorico: ComentarioDataTO[];
}
