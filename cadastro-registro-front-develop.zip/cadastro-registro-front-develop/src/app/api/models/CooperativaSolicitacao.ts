import { Solicitacao } from '@cadastro-registro-api/models/Solicitacao';
import { CooperativaTO } from './CooperativaTO';

export class CooperativaSolicitacao {
  id: number;
  solicitacao: Solicitacao;
  outroMotivoDesc: string;
  regularidadeCooperativaSolicitacao: boolean;
  cooperativa: CooperativaTO;
  anexo: string;
  anexoNotificacao: string;
}
