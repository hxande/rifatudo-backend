export class CertificadoUnidadeEstadual {
  id: number;
  uf: string;
  arquivo: string; // api_upload > repositorio > chavePasta
  inAtiva: boolean;
}
