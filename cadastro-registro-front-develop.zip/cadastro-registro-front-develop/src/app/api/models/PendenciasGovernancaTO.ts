import { PendenciasConselhoTO } from './PendenciasConselhoTO';

/**
 * Pendências agregadas da aba de Governança de uma cooperativa.
 *
 * Contrato HTTP interno do redesign (GET `/{cooperativaId}/pendencias`).
 * `podeAvancar` é a decisão agregada do backend: só é `true` quando nenhum
 * conselho aplicável tem pendência. O front pode reespelhar a regra a partir
 * de `conselhos` para feedback imediato de UI.
 */
export class PendenciasGovernancaTO {
  /** Identificador da cooperativa. */
  idCooperativa: number;
  /** Decisão agregada de submissão. */
  podeAvancar: boolean;
  /** Pendências por conselho. */
  conselhos: PendenciasConselhoTO[];
  /**
   * Pendências da aba não associadas a um conselho específico (ex.: data de
   * constituição ausente). Também derrubam `podeAvancar`.
   */
  pendenciasGerais: string[];
  estadoPreenchimento?: 'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null;
}
