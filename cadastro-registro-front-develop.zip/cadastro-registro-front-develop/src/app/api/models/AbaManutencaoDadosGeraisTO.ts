import { EnderecoTO } from './EnderecoTO';
import { InformacaoAdicionalTO } from './InformacaoAdicionalTO';
import { PessoaJuridicaTO } from './PessoaJuridicaTO';
import { QuadroSocialTO } from './QuadroSocialTO';
import { RedeSocialTO } from './RedeSocialTO';

export class AbaManutencaoDadosGeraisTO {
    idCooperativa: number;
    pessoaJuridica: PessoaJuridicaTO;
    enderecos: EnderecoTO[];
    redesSociais: RedeSocialTO[];
    informacaoAdicional: InformacaoAdicionalTO;
    cooperativasVinculadas: number[];
    quadroSocialAtual: QuadroSocialTO;
    quadroSocialManutencao: QuadroSocialTO;
    aba: string;
}