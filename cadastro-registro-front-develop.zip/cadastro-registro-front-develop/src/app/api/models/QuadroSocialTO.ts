import { AprovacaoTO } from "./AprovacaoTO";
import { QuadroSocialParametroQuadroTO } from "./QuadroSocialParametroQuadroTO";
import { QuadroSocialParametroQuadroCooperadoTO } from "./QuadroSocialParametroQuadroCooperadoTO";


export class QuadroSocialTO {
    id: number;
    idPessoa: number;
    ano: number;
    cooperadosPF: number;
    cooperadosPJ: number;
    cooperadosTotal: number;
    empregadosHomens: number;
    empregadosMulheres: number;
    empregadosTotal: number;
    cooperadosHomens: number;
    cooperadosMulheres: number;
    cooperadosAtivos: number;
    aprovacao: AprovacaoTO;
    // Auxiliar
    apenasTotalPF: boolean;
    apenasTotalCooperados: boolean;
    apenasTotalEmpregados: boolean;

    parametroQuadros: QuadroSocialParametroQuadroTO[];
    parametroQuadrosCooperado: QuadroSocialParametroQuadroCooperadoTO[];

    //submodules teste teste
}
