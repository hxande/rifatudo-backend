import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { RedeSocial } from '@cadastro-registro-api/models/RedeSocial';

export class DadosGeraisTO {
    cooperativa: Cooperativa;
    enderecos: Endereco[];
    redesSociais: RedeSocial[];
    cooperativasVinculadas: CooperativaBasica[];
    quadroSocialAtual: QuadroSocial;
    quadroSocialManutencao: QuadroSocial;
}