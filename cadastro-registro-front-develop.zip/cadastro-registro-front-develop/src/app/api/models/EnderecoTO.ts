import { TipoEndereco } from "@cadastro-registro-api/models/TipoEndereco";
import { Uf } from "@localizacao-api/models/Uf";

export class EnderecoTO {
    id: number;
    bairro: string;
    idBairro: number;
    cep: string;
    enderecoReferencia: string;
    descricaoEndereco: string; 
    complemento: string;
    idEstado: number;
    idMunicipio: number;
    numero: string;
    enderecoPrincipal: boolean;
    idPessoa: number;
    tipoEnderecoId: number;
    idUf: number;
    correspondenciaDiferente: boolean;
}
