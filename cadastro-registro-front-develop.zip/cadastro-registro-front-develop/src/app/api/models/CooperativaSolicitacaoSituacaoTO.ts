import { NovaSituacaoEnum } from "./SituacaoCooperativaEnum";

export class CooperativaSolicitacaoSituacaoTO {
    idCooperativa: number;
    idSolicitacao: number;
    justificativa: string;
    situacaoCooperativa: NovaSituacaoEnum;
}