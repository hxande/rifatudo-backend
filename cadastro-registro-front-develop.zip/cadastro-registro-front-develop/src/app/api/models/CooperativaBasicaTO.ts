
export class CooperativaBasicaTO {
    id: number;
    cnpj: string;
    razaoSocial: string;
    nomeFantasia: string;
    ufSigla: string;
    dataRegistro: Date;
    numeroRegistro: string;
    situacao: Situacao;
    regularidade: string;
    nomeCooperativa: string;
}

export class Situacao {
    id: number;
    nome: string;
    ativo: boolean;
}
