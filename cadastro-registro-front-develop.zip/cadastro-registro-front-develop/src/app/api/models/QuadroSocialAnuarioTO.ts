import { QuadroSocialCooperadosDadosAdicionaisTO } from './QuadroSocialCooperadosDadosAdicionaisTO';
import { QuadroSocialEmpregadosDadosAdicionaisTO } from './QuadroSocialEmpregadosDadosAdicionaisTO';
import { QuadroSocialUFTO } from './QuadroSocialUFTO';

export class QuadroSocialAnuarioTO {
    id: number;
    idPessoaJuridica: number;
    ano: number;
    cooperadosPF: number;
    cooperadosPJ: number;
    cooperadosTotal: number;
    empregadosHomens: number;
    empregadosMulheres: number;
    empregadosTotal: number;
    cooperadosHomens: number;
    cooperadosMulheres: number;
    cooperadosAtivos: number;

    informaCooperadosUF: boolean;
    informaEmpregadosUF: boolean;

    listaQuadroSocialUFTO: QuadroSocialUFTO[];

    listaCooperadosDadosAdicionais: QuadroSocialCooperadosDadosAdicionaisTO[];
    listaEmpregadosDadosAdicionais: QuadroSocialEmpregadosDadosAdicionaisTO[];

}
