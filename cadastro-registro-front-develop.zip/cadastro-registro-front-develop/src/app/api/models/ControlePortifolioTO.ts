export class ControlePortifolioTO {
    id: number;
    informarCampos: boolean;
    uf: string;
}