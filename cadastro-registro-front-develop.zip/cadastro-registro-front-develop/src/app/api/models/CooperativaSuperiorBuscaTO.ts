import { CooperativaBasicaTO } from './CooperativaBasicaTO';

export interface CooperativaSuperiorBuscaTO {
    encontrada: boolean;
    vinculoPermitido: boolean;
    mensagem: string;
    ramoCooperativaAtual: string;
    ramoCooperativaEncontrada: string;
    cooperativa: CooperativaBasicaTO;
}
