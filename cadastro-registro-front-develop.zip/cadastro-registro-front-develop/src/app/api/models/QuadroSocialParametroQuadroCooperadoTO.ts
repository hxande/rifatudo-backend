export class QuadroSocialParametroQuadroCooperadoTO {
  idQuadroSocialParametroQuadroCooperado: {
    sqQuadroSocial: number;
    sqParametroQuadroSocial: number;

  };
  quantidade: number;
}
