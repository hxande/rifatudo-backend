import { CooperativaRegistro } from './CooperativaRegistro';

export class CooperativaRegistroTO {
    cooperativaRegistro: CooperativaRegistro;
    notificarPorEmail: boolean = false;
    jaNotificada: boolean = false;
}
