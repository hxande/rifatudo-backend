export class CooperativaInativacaoAtivacaoRequestTO {
    idCooperativa: number;
    justificativaAtivacao: string;
}