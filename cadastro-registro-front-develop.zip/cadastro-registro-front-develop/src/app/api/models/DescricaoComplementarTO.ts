export class DescricaoComplementarTO {
    descricao: string[];
    exibir: boolean;
    produtoServicoId: number;
    segmentoId: number;
    ativo: boolean;
}