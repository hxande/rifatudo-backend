import { EstruturaIntegracaoTo } from "@cadastro-registro-api/models/estrutura-integracao-to";
import { QuadroSocialAnuarioTO } from "./QuadroSocialAnuarioTO";
import { DadosSociaisFinanceirosDto } from "@cadastro-registro-api/models/dados-sociais-financeiros-dto";


export class ListDadosSociaisAnuarioTO {
    quadroSocialAnuarioTOList: QuadroSocialAnuarioTO[];
    dadosSociaisFinanceirosTO : DadosSociaisFinanceirosDto;
    listaDadosSociaisFinanceirosTO : EstruturaIntegracaoTo[];
}
