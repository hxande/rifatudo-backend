export class QuadroSocialParametroQuadroTO {
  idQuadroSocialParametroQuadro: {
    sqQuadroSocial: number;
    sqParametroQuadroSocial: number;

  };
  quantidade: number;
}
