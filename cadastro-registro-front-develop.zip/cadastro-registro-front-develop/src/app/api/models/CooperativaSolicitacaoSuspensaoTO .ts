import { NovaSituacaoEnum } from "./SituacaoCooperativaEnum";

export class CooperativaSolicitacaoSuspensaoTO {
    
	idCooperativa: number;
	idSolicitacao: number;
	justificativa: string;
	outroMotivoDesc: string;
	tipoDeSuspensao: string;
	anexo: string;
	jaNotificada: boolean;
	notificarPorEmail: boolean;
	anexoNotificacao: string;
	idMotivo: number;
	tipoAcaoSolicitacao: string;
	solicitacaoCancelamento: boolean;
	situacaoCooperativa: NovaSituacaoEnum;
	registroEmail: boolean;
}