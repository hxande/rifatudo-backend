import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { PessoaJuridicaBasicaTO } from './PessoaJuridicaBasicaTO';
import { Situacao } from '@cadastro-registro-api/models/Situacao';
import { CooperativaRegistro } from '@cadastro-registro-api/models/CooperativaRegistro';

export class CooperativaTO {
    id: number;
    status: string;
    numeroRegistroOCB: string;
    dataRegistro: Date;
    dataAtualizacao: Date;
    justificativaAtivacao: string;
    justificativaSolicitacaoCancelamento: string;
    justificativaSolicitacaoInativacao: string;
    justificativaSolicitacaoAtivacao: string;
    justificativaIrregular: string;
    justificativaCancelada: string;
    justificativaInativada: string;
    processoTransferencia: boolean;
    liquidacao: boolean;
    regidaPorLei: boolean;
    naoSubmeteu: boolean;
    solicitacaoAtivacao: boolean;
    solicitacaoInativacao: boolean;
    solicitacaoCancelamento: boolean;
    regularidadeCooperativa: string;
    progressoManutencaoMicro: string;
    progressoManutencaoMacro: string;
    progressoMacro: string;
    pessoaJuridica: PessoaJuridicaBasicaTO;
    categoria: Categoria;
    situacaoCooperativa: Situacao;
    usuarioSubmissao: string;
    cooperativaRegistro: CooperativaRegistro[];
}
