export class QuadroSocialEmpregadosDadosAdicionaisTO {
    idQuadroSocial: number;
    idParametroQuadroSocial: number;
    nomeParametroQuadroSocial: string;
    quantidade: number;
    obrigatorio: boolean;
}