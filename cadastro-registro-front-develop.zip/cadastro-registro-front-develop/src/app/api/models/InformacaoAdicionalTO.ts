
export class InformacaoAdicionalTO {
    regidaPorLei: boolean;
    liquidacao: boolean;
    categoriaId: number;
    idSindicato: number;
}
