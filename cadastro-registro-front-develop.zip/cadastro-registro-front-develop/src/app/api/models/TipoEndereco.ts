export class TipoEndereco {
       id: number;
       nome: string;
       enderecoPrincipal: boolean;
    enderecoCorrespondencia: boolean;
    ativo: boolean;
    ordem: number;
}
