import { NovaSituacaoEnum } from "./SituacaoCooperativaEnum";

export class CooperativaSolicitacaoCancelamentoTO {
    
	idCooperativa: number;
	idSolicitacao: number;
	justificativa: string;
	anexo: string;
	idMotivo: number;
	tipoAcaoSolicitacao: string;
	solicitacaoCancelamento: boolean
	situacaoCooperativa: NovaSituacaoEnum;
}