import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { CooperativaProcessoRegistroTO } from '../models/CooperativaProcessoRegistroTO';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class CooperativaLeituraService {
    private readonly URL_API = '/cadastro-registro-leitura-api/api/v1/cooperativa';

    constructor(private http: HttpClient) { }

    obterCooperativasEmProcessoRegistroListagem(options: { params: HttpParams }) : Observable<IServiceResponse<IPage<CooperativaProcessoRegistroTO>>> {
        return this.http.get<IServiceResponse<IPage<CooperativaProcessoRegistroTO>>>
            (`${this.URL_API}/processo-registro/listagem`, options);
    }

    buscarRelatorioArrayBuffer(relatorio: string, options: { params: HttpParams }): Observable<ArrayBuffer> {
        return this.http.get(`${this.URL_API}/processo-registro/relatorio/excel/${relatorio}`,
          { reportProgress: false, responseType: 'arraybuffer', params: options.params, headers: new HttpHeaders({ timeout: `${900000}` }) });
    }

    cooperativaProcessoAcompanhamentoRelatorio(options: { params: HttpParams }): Observable<ArrayBuffer> {
        return this.http
        .get(`${this.URL_API}/processo-registro/relatorio/acompanhamento/excel`, 
            { reportProgress: false, responseType: 'arraybuffer', params: options.params, headers: new HttpHeaders({ timeout: `${900000}` }) });
    }
}