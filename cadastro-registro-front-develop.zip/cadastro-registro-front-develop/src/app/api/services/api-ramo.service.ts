import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Ramo } from '../models/Ramo';
import { firstValueFrom } from 'rxjs';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';

@Injectable({
  providedIn: 'root',
})
export class ApiRamoService {
  constructor(private http: HttpClient) {}

  getRamo(id: number) {
    return firstValueFrom(this.http.get<Ramo>(`/cadastro-registro-leitura-api/api/v1/ramo/${id}`));
  }

  create(ramo: Ramo) {
    return firstValueFrom(
      this.http.post<IServiceResponse<Ramo>>(`/cadastro-registro-api/api/v1/ramo`, ramo, { reportProgress: false })
    );
  }

  update(ramo: Ramo) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Ramo>>(`/cadastro-registro-api/api/v1/ramo/${ramo.id}`, ramo, { reportProgress: false })
    );
  }

  getRamos() {
    return firstValueFrom(this.http.get<IServiceResponse<Ramo[]>>(`/cadastro-registro-api/api/v1/ramo`));
  }

  getRamosPage(options: { params: HttpParams }) {
    return firstValueFrom(
      this.http.get<IServiceResponse<IPage<Ramo>>>('/cadastro-registro-api/api/v1/ramo/filtro', options)
    );
  }

  desativa(id: number) {
    return firstValueFrom(this.http.delete<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/ramo/${id}`));
  }
}
