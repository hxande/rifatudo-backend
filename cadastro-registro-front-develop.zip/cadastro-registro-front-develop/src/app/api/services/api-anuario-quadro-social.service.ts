import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { QuadroSocialAnuarioTO } from '../models/QuadroSocialAnuarioTO';
import { AnuarioSalvarPayloadTO } from '../models/AnuarioSalvarPayloadTO';
import { TabDataInterface } from 'src/app/features/cooperativa/anuario/anuario-home/anuario-versao2/types/tabs.interface';

@Injectable({
    providedIn: 'root'
})
export class AnuarioQuadroSocialService {

    private readonly URL_API = '/cadastro-registro-api/api/v1/quadrosocial';
    private readonly URL_API_V2 = '/cadastro-registro-api/api/v2';

    constructor(private http: HttpClient){}

    obterQuadroSocialAnuario(idCooperativa: number, ano: number) : Observable<IServiceResponse<QuadroSocialAnuarioTO>> {
        return this.http.get<IServiceResponse<QuadroSocialAnuarioTO>>(`${this.URL_API}/obterQuadroSocialAnuario/${idCooperativa}/ano/${ano}`);
    }

    obterQuadroSocialAnuarioV2(idCooperativa: number, ano: number): Observable<TabDataInterface[]> {
        return this.http.get<TabDataInterface[]>(`${this.URL_API_V2}/cooperativa-anuario-abas/quadro-social/${idCooperativa}/ano/${ano}`);
    }

    salvarQuadroSocialAnuarioV2(idCooperativa: number, ano: number,listaQuadroSocialAnuario: any, isSubmit: boolean = false) : Observable<IServiceResponse<any>> {
        return this.http.post<IServiceResponse<void>>(`${this.URL_API_V2}/cooperativa-anuario-abas/quadro-social/${idCooperativa}/ano/${ano}?isSubmit=${isSubmit}`,listaQuadroSocialAnuario);
    }

    salvarPortifolioAnuarioV2(idCooperativa: number, ano: number,listaPortifolioAnuario: any, isSubmit: boolean = false) : Observable<IServiceResponse<any>> {
        return this.http.post<IServiceResponse<void>>(`${this.URL_API_V2}/cooperativa-anuario-abas/portifolio/${idCooperativa}/ano/${ano}?isSubmit=${isSubmit}`,listaPortifolioAnuario);
    }


    salvarNegocioAnuarioV2(idCooperativa: number, ano: number,listaNegocioAnuario: any, isSubmit: boolean = false) : Observable<IServiceResponse<any>> {
        return this.http.post<IServiceResponse<void>>(`${this.URL_API_V2}/cooperativa-anuario-abas/negocio/${idCooperativa}/ano/${ano}?isSubmit=${isSubmit}`,listaNegocioAnuario);
    }
    salvarDadosComplementaresAnuarioV2(idCooperativa: number, ano: number,listaNegocioAnuario: any, isSubmit: boolean = false) : Observable<IServiceResponse<any>> {
        return this.http.post<IServiceResponse<void>>(`${this.URL_API_V2}/cooperativa-anuario-abas/dados-complementares/${idCooperativa}/ano/${ano}?isSubmit=${isSubmit}`,listaNegocioAnuario);
    }

    salvarTributarioAnuarioV2(idCooperativa: number, ano: number,listaTributarioAnuario: any, isSubmit: boolean = false) : Observable<IServiceResponse<any>> {
        return this.http.post<IServiceResponse<void>>(`${this.URL_API_V2}/cooperativa-anuario-abas/contabil-tributario/${idCooperativa}/ano/${ano}?isSubmit=${isSubmit}`,listaTributarioAnuario);
    }


    salvarQuadroSocialAnuario(listaQuadroSocialAnuario: QuadroSocialAnuarioTO[]) : Observable<IServiceResponse<void>> {
        return this.http.post<IServiceResponse<void>>(`${this.URL_API}/salvarQuadroSocialAnuario`,listaQuadroSocialAnuario);
    }
}
