import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RelatorioAbaColunas } from '../models/RelatorioAbaColunasTO';
import { firstValueFrom } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class ApiRelatorioService {

  private readonly URL_API = '/cadastro-registro-leitura-api/api/v1/relatorios';
    constructor(private http: HttpClient) { }


     listarColunasRelatorio(relatorio: string, options: { params: HttpParams }) {
      return firstValueFrom( this.http.get<RelatorioAbaColunas[]>(`${this.URL_API}/colunas/${relatorio}`, options));
     }
    
    
}