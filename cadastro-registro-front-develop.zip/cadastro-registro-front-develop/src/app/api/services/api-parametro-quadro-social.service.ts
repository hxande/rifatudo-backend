import {Injectable} from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { ParametroQuadroSocialTO } from '../models/ParametroQuadroSocialTO';
import { ParametroQuadroSocial } from '@cadastro-registro-api/models/ParametroQuadroSocial';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';

@Injectable({
  providedIn: 'root'
})

export class ApiParametroQuadroSocialService {

  constructor(private http: HttpClient) {
  }

  getParametroQuadroSocialPorId(id: number) {
    return firstValueFrom(
      this.http.get<ParametroQuadroSocialTO>(`/cadastro-registro-api/api/v1/parametro-quadro-social/${id}`)
    );
  }

  getParametroQuadroSocialCooperadoPorId(id: number) {
    return firstValueFrom(
      this.http.get<ParametroQuadroSocialTO>(`/cadastro-registro-api/api/v1/parametro-quadro-social-cooperado/${id}`)
    );
  }

  getParametroQuadroSocialPaginado(options: { params: HttpParams }) {
    return firstValueFrom(
      this.http.get<IPage<ParametroQuadroSocialTO>>(`/cadastro-registro-api/api/v1/parametro-quadro-social/buscarPaginado`, options)
    );
  }
  getParametroQuadroSocialCooperadoPaginado(options: { params: HttpParams }) {
    return firstValueFrom(
      this.http.get<IPage<ParametroQuadroSocialTO>>(`/cadastro-registro-api/api/v1/parametro-quadro-social-cooperado/buscarPaginado`, options)
    );
  }
  salvarParametroQuadroSocial(parametroQuadroSocial: ParametroQuadroSocialTO) {
    return firstValueFrom(
      this.http.post<IServiceResponse<ParametroQuadroSocialTO>>(`/cadastro-registro-api/api/v1/parametro-quadro-social`, parametroQuadroSocial, { reportProgress: true })
    );
  }

  salvarParametroQuadroSocialCooperado(parametroQuadroSocial: ParametroQuadroSocialTO) {
    return firstValueFrom(
      this.http.post<IServiceResponse<ParametroQuadroSocialTO>>(`/cadastro-registro-api/api/v1/parametro-quadro-social-cooperado`, parametroQuadroSocial, { reportProgress: true })
    );
  }

  excluirParametroQuadroSocial(id: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/parametro-quadro-social/${id}`)
    );
  }

  excluirParametroQuadroSocialCooperado(id: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/parametro-quadro-social-cooperado/${id}`)
    );
  }

  habilitaControleParametroQuadroSocial(ativa: boolean) {
    return firstValueFrom(
      this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/controle-parametro-quadro-social/atualizar-controle-preenchimento`, ativa, { reportProgress: true })
    );
  }

  habilitaControleParametroQuadroSocialCooperado(ativa: boolean) {
    return firstValueFrom(
      this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/controle-parametro-quadro-social-cooperado/atualizar-controle-preenchimento`, ativa, { reportProgress: true })
    );
  }

  getControleParametroQuadroSocial() {
    return  firstValueFrom(
      this.http.get<IServiceResponse<boolean>>(`/cadastro-registro-api/api/v1/controle-parametro-quadro-social`, { reportProgress: true })
    );
  }

  getControleParametroQuadroSocialCooperado() {
    return  firstValueFrom(
      this.http.get<IServiceResponse<boolean>>(`/cadastro-registro-api/api/v1/controle-parametro-quadro-social-cooperado`, { reportProgress: true })
    );
  }

}
