import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CooperativaAnuarioAbaTO } from '../models/CooperativaAnuarioAbaTO';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { TabDataInterface, TabInterface } from 'src/app/features/cooperativa/anuario/anuario-home/anuario-versao2/types/tabs.interface';



@Injectable({
    providedIn: 'root'
})
export class ApiCooperativaAnuarioAbasService {

    private readonly URL_API = '/cadastro-registro-api/api/v1/cooperativa-anuario-abas';
    private readonly URL_API_V2 = '/cadastro-registro-api/api/v2/cooperativa-anuario-abas';

    constructor(private http: HttpClient) { }


    obterCooperativaAnuarioAbas(idCooperativa: number, anoCiclo: number): Observable<IServiceResponse<CooperativaAnuarioAbaTO[]>> {
        return this.http.get<IServiceResponse<CooperativaAnuarioAbaTO[]>>(`${this.URL_API}/${idCooperativa}/${anoCiclo}`);
    }

    obterCooperativaAnuarioAbasV2(idCooperativa: number, anoCiclo: number): Observable<IServiceResponse<TabInterface[]>> {
        return this.http.get<IServiceResponse<TabInterface[]>>(`${this.URL_API_V2}/${idCooperativa}/${anoCiclo}`);
    }

    obterDadosContabilTributarioV2(idCooperativa: number, ano: number) {
        return this.http.get<IServiceResponse<TabDataInterface[]>>(`${this.URL_API_V2}/contabil-tributario/${idCooperativa}/ano/${ano}`);
    }

    obterDadosNegociosV2(idCooperativa: number, ano: number) {
        return this.http.get<IServiceResponse<TabDataInterface[]>>(`${this.URL_API_V2}/negocios/${idCooperativa}/ano/${ano}`);
    }

    obterDadosComplementaresV2(idCooperativa: number, ano: number) {
       return this.http.get<IServiceResponse<TabDataInterface[]>>(`${this.URL_API_V2}/dados-complementares/${idCooperativa}/ano/${ano}`);
   }
}
