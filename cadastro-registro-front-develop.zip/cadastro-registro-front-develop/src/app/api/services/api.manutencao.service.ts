import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { AbaManutencaoDadosGeraisTO } from "../models/AbaManutencaoDadosGeraisTO";
import { firstValueFrom } from "rxjs";
import { IServiceResponse } from "@utils/interfaces/IServiceResponse";
import { Aba } from "../models/AbaEnum";
import { AbaManutencaoSegmentacaoFiliaisTO } from "../models/AbaManutencaoSegmentacaoFiliaisTO";

@Injectable({
  providedIn: 'root',
})
export class ApiManutencaoService {
  private readonly URL_API = '/cadastro-registro-api/api/v1/manutencao-cadastro';
  constructor(private http: HttpClient) {}

    dadosGerais(dadosGerais: AbaManutencaoDadosGeraisTO) {
      return firstValueFrom(
        this.http.put<IServiceResponse<boolean>>(`${this.URL_API}/${Aba.ABA_DADOS_GERAIS}`, dadosGerais, {
          reportProgress: false,
        })
      );
    }

    segmentacaoFiliais(negocio: AbaManutencaoSegmentacaoFiliaisTO) {
      return firstValueFrom(
        this.http.put<IServiceResponse<boolean>>(`${this.URL_API}/${Aba.ABA_SEGUIMENTOS_FILIAIS}`, negocio, {
          reportProgress: false,
        })
      );
    }
}