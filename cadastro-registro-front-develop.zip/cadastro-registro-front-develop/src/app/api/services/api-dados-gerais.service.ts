import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { DadosGerais } from '@cadastro-registro-api/models/DadosGerais';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { Municipio } from '@localizacao-api/public-api';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { DadosGeraisResponseTO } from '../models/DadosGeraisResponseTO';
import { CooperativaTO } from '../models/CooperativaTO';
import { CooperativaHistoricoProcessoRegistroTO } from '../models/CooperativaHistoricoProcessoRegistroTO';
import { CooperativaSuperiorBuscaTO } from '../models/CooperativaSuperiorBuscaTO';
import { CooperativaBasicaTO } from '../models/CooperativaBasicaTO';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiDadosGeraisService {

  constructor(private http: HttpClient) { }

  buscarCooperativas(busca: string, idCategoria: number) {
    return firstValueFrom( this.http
      .get<IServiceResponse<CooperativaBasica[]>>(
        `/cadastro-registro-api/api/v1/cooperativa/buscarCooperativasPorCategoria?busca=${busca}&idCategoria=${idCategoria}`
      )
      )
  }

  getCooperativa(id: number): Promise<IServiceResponse<Cooperativa>> {
    return firstValueFrom( this.http.get<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/${id}`))
  }

  getCooperativaApresentacao(id: number): Promise<IServiceResponse<CooperativaTO>> {
    return firstValueFrom(this.http.get<IServiceResponse<CooperativaTO>>(`/cadastro-registro-api/api/v1/cooperativa/apresentacao/${id}`));
  }

  getVinculacoes(idCooperativa: number) {
    return firstValueFrom( this.http
      .get<IServiceResponse<CooperativaBasica[]>>(`/cadastro-registro-api/api/v1/cooperativa/buscarCooperativasVinculadas/${idCooperativa}`)
      )
  }

  getEnderecos(idPessoa: number) {
    return firstValueFrom( this.http.get<IServiceResponse<Endereco[]>>(`/cadastro-registro-api/api/v1/endereco/filtro/enderecosPessoa/${idPessoa}`))
  }

  buscarMunicipioPorId(idMunicipio: number) {
    return firstValueFrom( this.http.get<Municipio>(`/localizacao-api/public/api/v1/municipios/${idMunicipio}`))
  }

  getCategorias() {
    return firstValueFrom( this.http.get<IServiceResponse<Categoria[]>>(`/cadastro-registro-api/api/v1/categoria`))
  }

  buscarQuadroSocialAtual(idCooperativa: number) {
    return firstValueFrom( this.http
      .get<IServiceResponse<QuadroSocial>>(`/cadastro-registro-api/api/v1/quadrosocial/buscarQuadroSocialAtual?idCooperativa=${idCooperativa}`)
      )
  }

  buscarDestinatarios(idCooperativa: number) {
    return firstValueFrom(
      this.http.get(
        `/cadastro-registro-api/api/v1/cooperativa/destinatarios/${idCooperativa}`, { responseType: 'text' })
    );
  }


  salvarDadosGerais(dadosGerais: DadosGeraisResponseTO) {
    return firstValueFrom( this.http
      .put<IServiceResponse<boolean>>(`/cadastro-registro-api/api/v1/dados-gerais`, dadosGerais, {
        reportProgress: false,
      })
      )
  }

  listarHistoricoProcessoRegistro(id): Promise<CooperativaHistoricoProcessoRegistroTO[]> {
    return firstValueFrom(this.http.get<CooperativaHistoricoProcessoRegistroTO[]>(`/cadastro-registro-api/api/v1/historico-processo-registro/cooperativa/${id}`));
  }

  getCooperativasSuperioresPorCnpjPai(idCooperativaFilha: number, cnpjPai: string): Promise<CooperativaSuperiorBuscaTO> {
    return firstValueFrom(this.http.get<CooperativaSuperiorBuscaTO>(`/cadastro-registro-api/api/v1/cooperativa/buscar-cooperativa-superior/${idCooperativaFilha}/${cnpjPai}`));
  }

  getCooperativaSuperiorVinculada(idCooperativaFilha: number): Promise<CooperativaBasicaTO[]> {
    return firstValueFrom(this.http.get<CooperativaBasicaTO[]>(`/cadastro-registro-api/api/v1/cooperativa/buscar-cooperativa-superior-vinculada/${idCooperativaFilha}`));
  }

  removerCooperativaSuperiorVinculada(idCooperativaFilha: number, idCooperativaPai: number): Promise<IServiceResponse<void>> {
    return firstValueFrom(this.http.delete<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa/remover-cooperativa-superior-vinculada/${idCooperativaFilha}/${idCooperativaPai}`));
  }

}
