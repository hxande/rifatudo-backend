import { HttpClient, HttpParams, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root',
})
export class ApiHistoricoProcessoRegistroService {

    private readonly URL_API = '/cadastro-registro-api/api/v1/relatorio/historico-processo-registro';

    constructor(private http: HttpClient) { }

    gerarRelatorio(uf: string, dataInicio?: string, dataFim?: string, status?: string[]): Observable<ArrayBuffer> {
        let params = new HttpParams();

        if (dataInicio) {
            params = params.set('dataInicio', dataInicio);
        }
        if (dataFim) {
            params = params.set('dataFim', dataFim);
        }
        if (status && status.length > 0) {
            status.forEach(s => {
                params = params.append('status', s);
            });
        }

        return this.http.get(`${this.URL_API}/${uf}`, {
            reportProgress: false,
            responseType: 'arraybuffer',
            params,
            headers: new HttpHeaders({ timeout: `${900000}` })
        });
    }
}