import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ValidacaoPrimeiroRegistro } from '@cadastro-registro-api/models/ValidacaoPrimeiroRegistro';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root',
  })
  export class ApiPessoaSegmentoProdutoServicoService {

    constructor(private http: HttpClient) {}


    validarAbaPortfolio(idCooperativa: number): Observable<IServiceResponse<ValidacaoPrimeiroRegistro>> {
        return this.http.get<IServiceResponse<ValidacaoPrimeiroRegistro>>(`/cadastro-registro-api/api/v1/pessoasegmentoprodutoservico/validar-segmento-produto-servico/${idCooperativa}`);
      }

  }