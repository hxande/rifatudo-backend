import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Solicitacao } from '@cadastro-registro-api/models/Solicitacao';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';
import { IPage } from '@utils/interfaces/IPage';
import { CooperativaSolicitacaoCancelamentoTO } from '../models/CooperativaSolicitacaoCancelamentoTO';
import { CooperativaSolicitacaoSuspensaoTO } from '../models/CooperativaSolicitacaoSuspensaoTO ';
import { CooperativaRegistro } from '../models/CooperativaRegistro';


@Injectable({
  providedIn: 'root',
})
export class ApiSolicitacaoService {

  constructor(private http: HttpClient) {}

  salvar(solicitacao: Solicitacao) {
      return firstValueFrom(
        this.http.post<IServiceResponse<Solicitacao>>(`/cadastro-registro-api/api/v1/solicitacao`, solicitacao, { reportProgress: false })
      );
    }

    listaPaginado(options: { params: HttpParams }) {
      return firstValueFrom(
        this.http.get<IServiceResponse<IPage<Solicitacao>>>('/cadastro-registro-api/api/v1/solicitacao/filtro', options)
      );
    }

    get(id: number) {
      return firstValueFrom(
        this.http.get<IServiceResponse<Solicitacao>>(`/cadastro-registro-api/api/v1/solicitacao/` + id, { reportProgress: false })
      );
    }

    alterar(solicitacao: Solicitacao) {
      return firstValueFrom(
        this.http.put<IServiceResponse<Solicitacao>>(`/cadastro-registro-api/api/v1/solicitacao/${solicitacao.id}`, solicitacao, {
          reportProgress: false,
        })
      );
    }

    alteraStatusSolicitacao(solicitacao: Solicitacao) {
      return firstValueFrom(
        this.http.put<IServiceResponse<Solicitacao>>(
          `/cadastro-registro-api/api/v1/solicitacao/alteraStatusSolicitacao/${solicitacao.id}`,
          solicitacao,
          { reportProgress: false }
        )
      );
    }

  getListaSolicitacoesAtivas() {
    return firstValueFrom(
      this.http.get<IServiceResponse<Solicitacao[]>>(
        `/cadastro-registro-api/api/v1/solicitacao/solicitacaoAtivas`,
        { reportProgress: false }
      )
    );
  }


  cancelaSolicitacaoDeCancelamento(id: number) {
      return firstValueFrom(
        this.http.put<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/cancelar/solicitacao-cancelamento/${id}`, { reportProgress: false })
      );
  }


  oeSolicitaCancelamento(cooperativaRegistro: CooperativaSolicitacaoCancelamentoTO){
      return firstValueFrom(
              this.http.put<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/cancelar/solicita-cancelamento-cooperativa`, cooperativaRegistro, { reportProgress: false })
      );
  }

   unCancela(cooperativaSolicitacaoTO: CooperativaSolicitacaoCancelamentoTO){
      return firstValueFrom(
              this.http.put<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/cancelar/cooperativa`, cooperativaSolicitacaoTO, { reportProgress: false })
      );
  }

   unAceitaCancelar(cooperativaSolicitacaoTO: CooperativaSolicitacaoCancelamentoTO){
      return firstValueFrom(
              this.http.put<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/cancelar/un-solicitacao-cancelamento`, cooperativaSolicitacaoTO, { reportProgress: false })
      );
  }
   unRecusaCancelar(cooperativaSolicitacaoTO: CooperativaSolicitacaoCancelamentoTO){
      return firstValueFrom(
              this.http.put<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/cancelar/un-recusa-cancelamento`, cooperativaSolicitacaoTO, { reportProgress: false })
      );
  }

   suspensao(cooperativaRegistro: CooperativaSolicitacaoSuspensaoTO){
      return firstValueFrom(
              this.http.put<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/suspender`, cooperativaRegistro, { reportProgress: false })
      );
  }

    getUltimoHistoricoSolicitacaoInativacao(idCooperativa: number) {
      return firstValueFrom(
        this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoSolicitacaoInativacao/${idCooperativa}`)
      );
    }

}
