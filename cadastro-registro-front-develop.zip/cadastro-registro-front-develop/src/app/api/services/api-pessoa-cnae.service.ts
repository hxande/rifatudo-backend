import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { PessoaCnaeTO } from '../models/PessoaCnaeTO';

@Injectable({
    providedIn: 'root'
})
export class PessoaCnaeService {
    
    private readonly URL_API = '/cadastro-registro-api/api/v1/pessoacnae';

    constructor(private http: HttpClient){}

    obterPessoaCane(idCooperativa: number) : Observable<PessoaCnaeTO[]> {
        return this.http.get<PessoaCnaeTO[]>(`${this.URL_API}/${idCooperativa}`);
    }
}