import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';
import { CooperativaRegistro } from '@cadastro-registro-api/models/CooperativaRegistro';

export interface ComunicacaoOrgaosRequest {
  idCooperativa: number;
  anexoProvaOrgaos: string;
  tipoAcaoSolicitacao: string;
  situacaoCooperativa: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApiComunicacaoOrgaosService {

  constructor(private http: HttpClient) { }

  comunicarOrgaos(payload: ComunicacaoOrgaosRequest) {
    return firstValueFrom(
      this.http.put<IServiceResponse<void>>(
        `/cadastro-registro-api/api/v1/cooperativa-situacao/suspender/comunicar-orgaos`,
        payload,
        { reportProgress: false }
      )
    );
  }
}
