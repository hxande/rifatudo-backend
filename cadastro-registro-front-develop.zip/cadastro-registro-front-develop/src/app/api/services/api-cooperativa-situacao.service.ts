import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { IServiceResponse } from "@utils/interfaces/IServiceResponse";
import { firstValueFrom } from "rxjs";
import { CooperativaSolicitacaoSituacaoTO } from "../models/CooperativaSolicitacaoSituacaoTO";
import { CooperativaTO } from "../models/CooperativaTO";
import { Cooperativa } from "@cadastro-registro-api/models/Cooperativa";
import { CooperativaRegistro } from "../models/CooperativaRegistro";
import { CooperativaRegistroTO } from "../models/CooperativaRegistroTO";
import { HistoricoCooperativaRegistroListagemTO } from "../models/HistoricoCooperativaRegistroListagemTO";
import { CooperativaSolicitacao } from "../models/CooperativaSolicitacao";
import { CooperativaRegistro as CR } from "@cadastro-registro-api/models/CooperativaRegistro";
import { ActivatedRoute } from "@angular/router";
import { KeycloakService } from "@auth/keycloak-service/keycloak.service";
import { ApiDadosGeraisService } from "./api-dados-gerais.service";
import { CooperativaSolicitacaoCancelamentoTO } from "../models/CooperativaSolicitacaoCancelamentoTO";
import { UsuarioKeycloak } from "@auth/keycloak-service/usuario-keycloak.class";
import { ComunicacaoOrgaosRequest } from "./api-comunicacao-orgaos.service";

@Injectable({
  providedIn: 'root'
})
export class ApiCooperativaSituacaoService {

  public static cooperativasApresentacaoSessao = new Map<string, CooperativaTO>();

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private keycloakService: KeycloakService,
    private apiDadosGeraisService: ApiDadosGeraisService
  ) { }

  alteraSituacaoCooperativa(cooperativaSolicitacaoSituacao: CooperativaSolicitacaoSituacaoTO) {
    return firstValueFrom(this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao`, cooperativaSolicitacaoSituacao, { reportProgress: false })
    );
  }

  solicitaAtivacaoSituacaoCooperativa(cooperativaSolicitacaoSituacao: CooperativaSolicitacaoSituacaoTO) {
    return firstValueFrom(this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/ativacao/solicitar`, cooperativaSolicitacaoSituacao, { reportProgress: false })
    );
  }

  aceitarSolicitacaoAtivacaoSituacaoCooperativa(cooperativaSolicitacaoSituacao: CooperativaSolicitacaoSituacaoTO) {
    return firstValueFrom(this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/ativacao/aceitar`, cooperativaSolicitacaoSituacao, { reportProgress: false })
    );
  }

  recusarSolicitacaoAtivacaoSituacaoCooperativa(cooperativaSolicitacaoSituacao: CooperativaSolicitacaoSituacaoTO) {
    return firstValueFrom(this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/ativacao/recusar`, cooperativaSolicitacaoSituacao, { reportProgress: false })
    );
  }

  cancelarSolicitacaoAtivacaoSituacaoCooperativa(cooperativaSolicitacaoSituacao: CooperativaSolicitacaoSituacaoTO) {
    return firstValueFrom(this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/ativacao/cancelar`, cooperativaSolicitacaoSituacao, { reportProgress: false })
    );
  }

  regularizarSituacaoCooperativa(cooperativaSolicitacaoSituacao: CooperativaSolicitacaoSituacaoTO) {
    return firstValueFrom(this.http.post<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/cooperativa-situacao/ativacao`, cooperativaSolicitacaoSituacao, { reportProgress: true })
    );
  }

  putCancelaSolicitacaoCancelamentoEnviada(cooperativa: CooperativaTO) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/cancelaSolicitacaoCancelamento/${cooperativa.id}`, cooperativa, { reportProgress: false })
    );
  }

  putRecusaSolicitacaoCancelamento(cooperativa: CooperativaTO) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/recusaSolicitacaoCancelamento/${cooperativa.id}`, cooperativa, { reportProgress: false })
    );
  }

  putSuspenderCooperativa(cooperativaRegistro: CR) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/suspenderCooperativa/${cooperativaRegistro.cooperativa.id}`, cooperativaRegistro, { reportProgress: false })
    );
  }

  consultaHistoricoCooperativaRegistroListagem(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<HistoricoCooperativaRegistroListagemTO[]>>(
        `/cadastro-registro-api/api/v1/cooperativa-registro/buscaHistoricoCooperativaRegistroListagem/${idCooperativa}`)
    );
  }

  getUltimoHistoricoSolicitacaoCancelamento(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoSolicitacaoCancelamento/${idCooperativa}`)
    );
  }

  getHistoricoCancelamento(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoCancelamento/${idCooperativa}`)
    );
  }

  putAceitaSolicitacaoCancelamentoRegistroCooperativa(cooperativaRegistro: CooperativaRegistro) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/aceitaSolicitacaoCancelamento/${cooperativaRegistro.cooperativa.id}`, cooperativaRegistro, { reportProgress: false })
    );
  }

  putCancelaRegistroCooperativa(cooperativaRegistro: CooperativaRegistro) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/cancelaRegistroCooperativa/${cooperativaRegistro.cooperativa.id}`, cooperativaRegistro, { reportProgress: false })
    );
  }

  putSolicitaCancelamentoCooperativa(cooperativaRegistro: CooperativaSolicitacaoCancelamentoTO) {
    return firstValueFrom(
      this.http.post<IServiceResponse<CooperativaSolicitacaoCancelamentoTO>>(`/cadastro-registro-api/api/v1/cooperativa/solicita-cancelamento-cooperativa`, cooperativaRegistro, { reportProgress: false })
    );
  }

  getUltimoHistoricoSolicitacaoInativacao(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoSolicitacaoInativacao/${idCooperativa}`)
    );
  }

  putRecusaSolicitacaoInativacao(cr: CooperativaTO) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/recusarSolicitacaoInativacao/${cr.id}`, cr, { reportProgress: false })
    );
  }

  putCancelaSolicitacaoInativacaoEnviada(id: number) {
    return firstValueFrom(this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/cancelaSolicitacaoInativacaoEnviada/${id}`, {}, { reportProgress: false }));
  }

  putSolicitaInativacaoCooperativa(cooperativaRegistro: CooperativaRegistroTO) {
    return firstValueFrom(
      this.http.put<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa/solicitaInativacaoCooperativa/${cooperativaRegistro.cooperativaRegistro.cooperativa.id}`, cooperativaRegistro, { reportProgress: false })
    );
  }

  putAceitaSolicitacaoInativacaoCooperativa(cr: CooperativaRegistro) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/aceitaSolicitacaoInativacao/${cr.cooperativa.id}`, cr, { reportProgress: false })
    );
  }

  getHistoricoInativacao(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoInativacao/${idCooperativa}`)
    );
  }

  getHistoricoSolicitacaoAtivacao(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoSolicitacaoAtivacao/${idCooperativa}`)
    );
  }

  putInativaCooperativa(cr: CooperativaRegistro) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/inativarCooperativa/${cr.cooperativa.id}`, cr, { reportProgress: false })
    );
  }

  getHistoricoSolicitacaoInativacaoApontamento(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaRegistro>>(`/cadastro-registro-api/api/v1/cooperativa-registro/buscaUltimoHistoricoApontamento/${idCooperativa}`)
    );
  }

  putComunicarOrgaos(payload: ComunicacaoOrgaosRequest) {
    return firstValueFrom(
      this.http.put<IServiceResponse<void>>(
        `/cadastro-registro-api/api/v1/cooperativa-situacao/suspender/comunicar-orgaos`,
        payload,
        { reportProgress: false }
      )
    );
  }

  buscaUltimaCooperativaSolicitacaoInativacao(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaSolicitacao>>(
        `/cadastro-registro-api/api/v1/cooperativasolicitacao/buscaUltimaCooperativaSolicitacaoInativacao/${idCooperativa}`,
        { reportProgress: false }
      )
    );
  }

  buscaUltimaCooperativaInativacao(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaSolicitacao>>(
        `/cadastro-registro-api/api/v1/cooperativasolicitacao/buscaUltimaCooperativaInativacao/${idCooperativa}`,
        { reportProgress: false }
      )
    );
  }

  async getCooperativaCadastroRegistroApresentacao() {
    const param = new URLSearchParams(window.location.search);
    let paramIdCooperativa = param.get('id_cooperativa');
    if (!paramIdCooperativa) {
      this.route.queryParams.subscribe((params) => {
        paramIdCooperativa = params['id_cooperativa'];
      });
    }

    const idCooperativa = parseInt(paramIdCooperativa as string, 10);

    let saida: CooperativaTO = null;

    await this.apiDadosGeraisService.getCooperativaApresentacao(idCooperativa).then((res) => {
      if (res && res.data) {
        saida = res.data;
      }
    });
    return saida;
  }
}
