import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';
import { TaxaRegistro } from '../models/TaxaRegistro';

@Injectable({
    providedIn: 'root',
})
export class ApiTaxaRegistroService {

    constructor(private http: HttpClient) { }

    getTaxaRegistro(idCooperativa: number): Promise<IServiceResponse<TaxaRegistro>> {
        return firstValueFrom(
            this.http.get<IServiceResponse<TaxaRegistro>>(
                `/cadastro-registro-api/api/v1/arrecadacao/taxa-registro/cooperativa/${idCooperativa}`,
                { reportProgress: false }
            )
        );
    }
}