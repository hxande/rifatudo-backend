import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TipoSolicitacao } from '@cadastro-registro-api/models/TipoSolicitacao';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class ApiTipoSolicitacaoService {

  constructor(private http: HttpClient) { }

  listaAtivos() {
    
    return this.http.get<IServiceResponse<TipoSolicitacao[]>>(`/cadastro-registro-api/api/v1/tipo_solicitacao`);
    
  }
}