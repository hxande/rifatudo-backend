import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EstruturaIntegracaoTo } from '@cadastro-registro-api/models/estrutura-integracao-to';
import { EstruturaPendenciaTO } from '@desempenho-api/models/EstruturaPendenciaTO';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiDesempenhoExternoService {
  constructor(private http: HttpClient) {}

  obter(chaveGrupoParametros: string, idCooperativa: number, ano: number) {
    return this.http
      .get<EstruturaIntegracaoTo[]>(`/desempenho-api/api/v1/lancamentos-externos/obter/${chaveGrupoParametros}/${idCooperativa}/12/${ano}`);
  }

  pendencias(chaveGrupoParametros: string, idCooperativa: number, ano: number): Observable<EstruturaPendenciaTO[]> {
    return this.http.get<EstruturaPendenciaTO[]>(`/desempenho-api/api/v1/lancamentos-externos/pendencia/${chaveGrupoParametros}/${idCooperativa}/12/${ano}`);
  }

  obterNegocio(idCooperativa: number, ano: number) {
    return this.http
      .get<EstruturaIntegracaoTo[]>(`/desempenho-api/api/v1/lancamentos-externos/obter-negocio/${idCooperativa}/12/${ano}`);
  }
}
