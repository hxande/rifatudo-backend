import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';
import { CooperativaHistoriCiclos } from '../models/CooperativaHistoricoCiclos';


@Injectable({
  providedIn: 'root',
})
export class ApiCooperativaHistoricoCiclos {

  private readonly URL_API = '/cadastro-registro-leitura-api/api/v1/cooperativa-status/documentos';
  constructor(private http: HttpClient) {}

  getListaCiclos(sqPessoa: number, ano: number) {
    return firstValueFrom(
      this.http.get<CooperativaHistoriCiclos>(`${this.URL_API}/${sqPessoa}/${ano}`, { reportProgress: false })
    );
  }

}
