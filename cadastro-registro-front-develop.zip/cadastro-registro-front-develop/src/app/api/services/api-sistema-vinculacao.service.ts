import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { SistemaVinculacaoTO } from '../models/SistemaVinculacaoTO';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
@Injectable({
    providedIn: 'root',
})
export class ApiSistemaVinculacaoService {
    constructor(private http: HttpClient) { }

    get(id: number) {
        return firstValueFrom(this.http.get<IServiceResponse<SistemaVinculacaoTO>>(`/cadastro-registro-api/api/v1/sistema-vinculacao/${id}`));
    }

    cadastrar(sistemaVinculacao: SistemaVinculacaoTO) {

        return this.http.post<IServiceResponse<SistemaVinculacaoTO>>(`/cadastro-registro-api/api/v1/sistema-vinculacao`, sistemaVinculacao, {
            reportProgress: false,
        });

    }

    altera(sistemaVinculacao: SistemaVinculacaoTO) {
         return this.http.put<IServiceResponse<SistemaVinculacaoTO>>(`/cadastro-registro-api/api/v1/sistema-vinculacao/${sistemaVinculacao.id}`, sistemaVinculacao, {
                reportProgress: false,
            });
     
    }

    
}