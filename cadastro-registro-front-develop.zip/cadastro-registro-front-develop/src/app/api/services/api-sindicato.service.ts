import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';

import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { PessoaJuridicaBasicaTO } from '../models/PessoaJuridicaBasicaTO';
import { SindicatoTO } from '../models/SindicatoTO';

@Injectable({
  providedIn: 'root',
})
export class ApiSindicatoService {
  constructor(private http: HttpClient) { }

  get(id: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<SindicatoTO>>(`/cadastro-registro-api/api/v1/sindicatos/${id}`)
    );
  }

  listaPaginado(options: { params: HttpParams }) {
    return firstValueFrom(
      this.http.get<IServiceResponse<IPage<SindicatoTO>>>('/cadastro-registro-api/api/v1/sindicatos', options)
    );
  }

  listaParaFiliacao(ufRepresentacao: string, idRamo: number) {
    let params = new HttpParams().set('ativo', 'true').set('size', '1000').set('sort', 'pessoaJuridica.razaoSocial');
    if (ufRepresentacao) {
      params = params.set('ufRepresentacao', ufRepresentacao);
    }
    if (idRamo != null) {
      params = params.set('idRamo', String(idRamo));
    }
    return firstValueFrom(
      this.http.get<IServiceResponse<IPage<SindicatoTO>>>('/cadastro-registro-api/api/v1/sindicatos', { params })
    );
  }

  inclui(sindicato: SindicatoTO) {
    return firstValueFrom(
      this.http.post<IServiceResponse<SindicatoTO>>(`/cadastro-registro-api/api/v1/sindicatos`, sindicato, {
        reportProgress: false,
      })
    );
  }

  altera(sindicato: SindicatoTO) {
    return firstValueFrom(
      this.http.put<IServiceResponse<SindicatoTO>>(
        `/cadastro-registro-api/api/v1/sindicatos/${sindicato.id}`,
        sindicato,
        { reportProgress: false }
      )
    );
  }

  desativa(id: number, valor: boolean) {
    return firstValueFrom(
      this.http.patch<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/sindicatos/${id}/ativo/${valor}`, null)
    );
  }
}
