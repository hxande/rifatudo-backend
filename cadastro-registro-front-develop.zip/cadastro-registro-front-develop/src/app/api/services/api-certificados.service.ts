import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { firstValueFrom } from "rxjs";
import { CertificadoRegularidadeUnidadeEstadualTO } from "../models/CertificadoRegularidadeUnidadeEstadualTO";


@Injectable({
  providedIn: 'root',
})
export class ApiCertificadosService {
  constructor(private http: HttpClient) {}

  
  getCertifiadoPorUf(uf: string) {
    return firstValueFrom(this.http.get<CertificadoRegularidadeUnidadeEstadualTO>(`/cadastro-registro-api/api/v1/certificadoRegularidadeUnidadeEstadual/${uf}`));
  }
  
}
