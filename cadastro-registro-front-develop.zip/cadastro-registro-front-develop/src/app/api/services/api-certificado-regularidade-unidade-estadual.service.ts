import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';

import { firstValueFrom } from 'rxjs';
import { CertificadoRegularidadeUnidadeEstadual } from '../models/CertificadoRegularidadeUnidadeEstadual';

@Injectable({
  providedIn: 'root',
})
export class ApiCertificadoRegularidadeUnidadeEstadualService {
  constructor(private http: HttpClient) {}

  listaCertificadoUnidadeEstadual() {
    return firstValueFrom(
      this.http.get<IServiceResponse<CertificadoRegularidadeUnidadeEstadual[]>>(
        '/cadastro-registro-api/api/v1/certificadoRegularidadeUnidadeEstadual',
      )
    );
  }

  salvarCertificadoUnidadeEstadual(
    listaCertificadoRegularidadeUnidadeEstadual: CertificadoRegularidadeUnidadeEstadual[],
  ) {
    return firstValueFrom(
      this.http.put<IServiceResponse<CertificadoRegularidadeUnidadeEstadual[]>>(
        '/cadastro-registro-api/api/v1/certificadoRegularidadeUnidadeEstadual',
        listaCertificadoRegularidadeUnidadeEstadual,
      )
    );
  }

  gerarCertificadoRegularidade(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CertificadoRegularidadeUnidadeEstadual[]>>(
        '/cadastro-registro-api/api/v1/certificadoRegularidadeUnidadeEstadual/pdf/' + idCooperativa,
      )
    );
  }
}
