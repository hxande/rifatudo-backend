import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class AtividadeCooperativaParticipacaoService {

    private readonly URL_API = '/cadastro-registro-leitura-api/api/v1/atividade-cooperativa-participacao';
    constructor(private http: HttpClient) { }


    gerarRelatorio(options: { params: HttpParams }): Observable<ArrayBuffer> {
        return this.http.get(`${this.URL_API}/relatorio/excel`,
          { reportProgress: false, responseType: 'arraybuffer', params: options.params, headers: new HttpHeaders({ timeout: `${900000}` }) });
      }
}