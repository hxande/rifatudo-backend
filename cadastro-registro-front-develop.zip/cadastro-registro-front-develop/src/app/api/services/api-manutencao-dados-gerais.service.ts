import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { QuadroSocialParametroQuadro } from '@cadastro-registro-api/models/QuadroSocialParametroQuadro';
import { Uf } from '@localizacao-api/models/Uf';
import { Municipio } from '@localizacao-api/public-api';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { DadosGeraisTO } from '../models/DadosGeraisTO';
import { EnderecoConsultaTO } from '../models/EnderecoConsultaTO';

@Injectable({
  providedIn: 'root',
})
export class ApiManutencaoDadosGeraisService {
  constructor(private http: HttpClient) {}

  getCooperativaPorCnpjSincronizada(id: string) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/buscaPorCnpj/${id}`)
    );
  }

  getCooperativa(id: number): Promise<IServiceResponse<Cooperativa>> {
    return firstValueFrom(
      this.http.get<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/${id}`)
    );
  }

  getEnderecos(idPessoa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Endereco[]>>(`/cadastro-registro-api/api/v1/endereco/filtro/enderecosPessoa/${idPessoa}`)
    );
  }

  getVinculacoes(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaBasica[]>>(`/cadastro-registro-api/api/v1/cooperativa/buscarCooperativasVinculadas/${idCooperativa}`)
    );
  }

  getCategorias() {
    return firstValueFrom(
      this.http.get<IServiceResponse<Categoria[]>>(`/cadastro-registro-api/api/v1/categoria`)
    );
  }

  buscarEndereco(cep: number) {
    return firstValueFrom(
      this.http.get<EnderecoConsultaTO>(`/localizacao-api/public/api/v1/enderecos/buscarPorCep/${cep}`)
    );
  }

  buscarCooperativas(busca: string, idCategoria: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaBasica[]>>(
        `/cadastro-registro-api/api/v1/cooperativa/buscarCooperativasPorCategoria/?busca=${busca}&idCategoria=${idCategoria}`
      )
    );
  }

  salvar(cooperativa: Cooperativa) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Cooperativa>>(`/cadastro-registro-api/api/v1/cooperativa/${cooperativa.id}`, cooperativa, { reportProgress: false })
    );
  }

  salvarDadosGerais(dadosGerais: DadosGeraisTO) {
    return firstValueFrom(
      this.http.put<IServiceResponse<boolean>>(`/cadastro-registro-api/api/v1/manutencao-dados-gerais/${dadosGerais.cooperativa.pessoaJuridica.id}`, dadosGerais, {
        reportProgress: false,
      })
    );
  }

  buscarMunicipioPorId(idMunicipio: number) {
    return firstValueFrom(
      this.http.get<Municipio>(`/localizacao-api/public/api/v1/municipios/${idMunicipio}`)
    );
  }

  buscarMunicipio(nome: number) {
    return firstValueFrom(
      this.http.get<Municipio[]>(`/localizacao-api/public/api/v1/municipios/buscarPorNome/?nome=${nome}`)
    );
  }

  buscarUfs() {
    return firstValueFrom(
      this.http.get<IPage<Uf>>(`/localizacao-api/public/api/v1/ufs`, this.getOptionsAllPage(`sigla,asc`))
    );
  }

  buscarMunicipiosByIdUf(idUf: number) {
    return firstValueFrom(
      this.http.get<IPage<Municipio>>(`/localizacao-api/public/api/v1/municipios/buscarPorIdUf?idUf=${idUf}`, this.getOptionsAllPage(`nome,asc`))
    );
  }

  getOptionsAllPage(order: string) {
    const options = {
      params: new HttpParams().set('page', '0').set('size', '9999').set('sort', order),
    };
    return options;
  }

  buscarQuadroParametrosPorQuadrosSociais(quadros: QuadroSocialParametroQuadro[]) {
    return firstValueFrom(
      this.http.post<QuadroSocialParametroQuadro[]>(`/cadastro-registro-api/api/v1/quadro-parametro/buscar-por-quadros`, quadros, { reportProgress: false })
    );
  }
}
