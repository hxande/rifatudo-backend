import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';

export enum TipoVinculoSolicitacaoEnum {
  FILIACAO_SUPERIOR = 'FILIACAO_SUPERIOR',
  GERENCIAR_FILIADA = 'GERENCIAR_FILIADA'
}

export enum StatusVinculoSolicitacaoEnum {
  AGUARDANDO_APROVACAO = 'AGUARDANDO_APROVACAO',
  APROVADO = 'APROVADO',
  REPROVADO = 'REPROVADO'
}

export interface CriarVinculoSolicitacaoRequest {
  idCooperativaSolicitante: number;
  idCooperativaIndicada: number;
  tipoVinculo: TipoVinculoSolicitacaoEnum;
}

export interface CooperativaVinculacaoSolicitacaoTO {
  id: number;

  idCooperativaSolicitante: number;
  cnpjSolicitante: string;
  nomeFantasiaSolicitante: string;
  ufSolicitante: string;

  idCooperativaIndicada: number;
  cnpjIndicada: string;
  nomeFantasiaIndicada: string;
  ufIndicada: string;

  tipoVinculo: TipoVinculoSolicitacaoEnum;
  status: StatusVinculoSolicitacaoEnum;
}

@Injectable({
  providedIn: 'root'
})
export class ApiVinculacaoCooperativaSolicitacaoService {

  private readonly URL_API = '/cadastro-registro-api/api/v1/vinculacaocooperativa-solicitacao';

  constructor(private http: HttpClient) {}

  criarSolicitacao(request: CriarVinculoSolicitacaoRequest) {
    return firstValueFrom(
      this.http.post<IServiceResponse<CooperativaVinculacaoSolicitacaoTO>>(
        `${this.URL_API}`,
        request,
        { reportProgress: false }
      )
    );
  }

  listarPorSolicitante(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaVinculacaoSolicitacaoTO[]>>(
        `${this.URL_API}/solicitante/${idCooperativa}`
      )
    );
  }

  listarPendentesParaAnalise(idCooperativaIndicada: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<CooperativaVinculacaoSolicitacaoTO[]>>(
        `${this.URL_API}/pendentes/${idCooperativaIndicada}`
      )
    );
  }

  aprovar(idSolicitacao: number) {
    return firstValueFrom(
      this.http.put<IServiceResponse<CooperativaVinculacaoSolicitacaoTO>>(
        `${this.URL_API}/${idSolicitacao}/aprovar`,
        null,
        { reportProgress: false }
      )
    );
  }

  reprovar(idSolicitacao: number) {
    return firstValueFrom(
      this.http.put<IServiceResponse<CooperativaVinculacaoSolicitacaoTO>>(
        `${this.URL_API}/${idSolicitacao}/reprovar`,
        null,
        { reportProgress: false }
      )
    );
  }

  deletar(idSolicitacao: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(
        `${this.URL_API}/${idSolicitacao}`
      )
    );
  }
}
