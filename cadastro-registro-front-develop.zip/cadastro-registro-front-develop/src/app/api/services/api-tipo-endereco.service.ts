import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';
import { TipoEndereco } from '../models/TipoEndereco';
import { IPage } from '@utils/interfaces/IPage';
@Injectable({
  providedIn: 'root',
})
export class ApiTipoEnderecoServiceV2 {
  constructor(private http: HttpClient) {}

  getTipoEndereco(id: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<TipoEndereco>>(`/cadastro-registro-api/api/v1/tipoendereco/${id}`)
    );
  }

  create(tipo: TipoEndereco) {
    return firstValueFrom(
      this.http.post<IServiceResponse<TipoEndereco>>(`/cadastro-registro-api/api/v1/tipoendereco`, tipo, { reportProgress: false })
    );
  }

  update(tipo: TipoEndereco) {
    return firstValueFrom(
      this.http.put<IServiceResponse<TipoEndereco>>(`/cadastro-registro-api/api/v1/tipoendereco/${tipo.id}`, tipo, { reportProgress: false })
    );
  }

  getTipos() {
    return firstValueFrom(
      this.http.get<IServiceResponse<TipoEndereco[]>>(`/cadastro-registro-api/api/v1/tipoendereco`)
    );
  }

  getTiposPage(options: { params: HttpParams }) {
    return firstValueFrom(
      this.http.get<IServiceResponse<IPage<TipoEndereco>>>('/cadastro-registro-api/api/v1/tipoendereco/filtro', options)
    );
  }

  exclui(id: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(`/cadastro-registro-api/api/v1/tipoendereco/${id}`)
    );
  }

  updatev2(tipo: TipoEndereco) {
    return firstValueFrom(
      this.http.put<IServiceResponse<TipoEndereco>>(`/cadastro-registro-api/api/v1/tipoendereco/update/${tipo.id}`, tipo, { reportProgress: false })
    );
  }
}
