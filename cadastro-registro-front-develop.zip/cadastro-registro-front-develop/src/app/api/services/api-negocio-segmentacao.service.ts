import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { NegocioTO } from '../models/NegocioTO';
import { firstValueFrom } from 'rxjs';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';

@Injectable({
  providedIn: 'root',
})
export class ApiNegocioSegmentacaoService {
  constructor(private http: HttpClient) {}

  salvarNegocio(negocio: NegocioTO, idCooperativa: Number ) {
    return firstValueFrom(
      this.http.post<IServiceResponse<boolean>>(`/cadastro-registro-api/api/v1/negocio/salva-segmentacao-filiais/${idCooperativa}`, negocio, { reportProgress: false })
    );
  }
}
