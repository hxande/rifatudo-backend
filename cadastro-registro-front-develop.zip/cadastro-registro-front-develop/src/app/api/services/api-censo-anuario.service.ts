import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CensoAnuarioTO } from '../models/CensoAnuarioTO';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { CensoAnuario } from '@cadastro-registro-api/models/CensoAnuario';
import { DadosIntegracaoTo } from '@cadastro-registro-api/models/dados-integracao-to';
import { DadosSociaisFinanceirosDto } from '@cadastro-registro-api/models/dados-sociais-financeiros-dto';
import { EstruturaIntegracaoSalvarTo } from '@cadastro-registro-api/models/estrutura-integracao-salvar-to';
import { EstruturaIntegracaoTo } from '@cadastro-registro-api/models/estrutura-integracao-to';
import { EstruturaGrupoTo } from '@cadastro-registro-api/models/estrutura-grupo-to';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { RetornoImportacao } from '@cadastro-registro-api/models/RetornoImportacao';
import { QuadroSocialAnuarioTO } from '../models/QuadroSocialAnuarioTO';
import { PessoaSegmProdServ } from '@cadastro-registro-api/models/PessoaSegmProdServ';
import { ListDadosSociaisAnuarioTO } from '../models/ListDadosSociaisAnuarioTO';

interface EstruturaIntegracaoSalvarNegocioTo {
  id: number;
  nome: string;
  parametros: EstruturaGrupoTo[];
}

@Injectable({
  providedIn: 'root'
})
export class ApiCensoAnuarioService {
  private readonly URL_API = '/cadastro-registro-api/api/v1/censo-anuario';
  constructor(private http: HttpClient) { }

  obterCensoAnuarioPorAnoAndIdCooperativa(ano: number, idCooperativa: number): Observable<IServiceResponse<CensoAnuarioTO>> {
    return this.http.get<IServiceResponse<CensoAnuarioTO>>(`${this.URL_API}/obter/${ano}/${idCooperativa}`);
  }

  create(censoAnuario: CensoAnuario): Observable<IServiceResponse<CensoAnuario>> {
    return this.http.post<IServiceResponse<CensoAnuario>>(this.URL_API, censoAnuario);
  }

  update(censoAnuario: CensoAnuario): Observable<IServiceResponse<CensoAnuario>> {
    return this.http.put<IServiceResponse<CensoAnuario>>(`${this.URL_API}/${censoAnuario.id}`, censoAnuario);
  }

  getByAnoAndCooperativaId(ano: number, cooperativaId: number): Observable<IServiceResponse<CensoAnuario>> {
    return this.http.get<IServiceResponse<CensoAnuario>>(`${this.URL_API}/${ano}/${cooperativaId}`);
  }

  salvarAbaDadosSociais(cooperativaId: number, ano: number,
    quadroSociais: QuadroSocial[]): Observable<IServiceResponse<void>> {

    const dadosSociaisFinanceiros = new DadosSociaisFinanceirosDto();
    dadosSociaisFinanceiros.quadrosSociais = quadroSociais;

    return this.http.post<IServiceResponse<void>>(`${this.URL_API}/salvar-aba-dados-sociais/${cooperativaId}/${ano}`, dadosSociaisFinanceiros);
  }

  salvarAbaQuadroSocial(cooperativaId: number, ano: number,
    quadroSociais: QuadroSocialAnuarioTO[]): Observable<IServiceResponse<void>> {

    return this.http.post<IServiceResponse<void>>(`${this.URL_API}/salvar-aba-quadro-social/${cooperativaId}/${ano}`, quadroSociais);
  }

  salvarAbaPortfolio(cooperativaId: number, ano: number, pessoaSegmProdServ: PessoaSegmProdServ[]): Observable<IServiceResponse<void>> {
    return this.http.post<IServiceResponse<void>>(`${this.URL_API}/salvar-aba-portfolio/${cooperativaId}/${ano}`, pessoaSegmProdServ);
  }

  salvarAbaDadosFinanceiros(cooperativaId: number, ano: number,
    estruturasSocialFinanceiro: EstruturaIntegracaoTo[]): Observable<IServiceResponse<void>> {

    const financeiro = new DadosIntegracaoTo();
    financeiro.idCooperativa = cooperativaId;
    financeiro.ano = ano;
    financeiro.socialFinanceiro = this.estruturasToJson(estruturasSocialFinanceiro);
    const dadosSociaisFinanceiros = new DadosSociaisFinanceirosDto();
    dadosSociaisFinanceiros.financeiro = financeiro;


    return this.http.post<IServiceResponse<void>>(`${this.URL_API}/salvar-aba-dados-financeiros/${cooperativaId}/${ano}`, dadosSociaisFinanceiros);


  }

  salvarDadosIntegracao(idCooperativa: number, ano: number,
    socialFinanceiro: EstruturaIntegracaoTo[],
    contabilTributarioFiscal: EstruturaIntegracaoTo[],
    negocio: EstruturaIntegracaoTo[]): Observable<IServiceResponse<RetornoImportacao>> {

    const dadosIntegracaoTo = new DadosIntegracaoTo();
    dadosIntegracaoTo.idCooperativa = idCooperativa;
    dadosIntegracaoTo.ano = ano;

    if (socialFinanceiro) {
      dadosIntegracaoTo.socialFinanceiro = this.estruturasToJson(socialFinanceiro);
    }
    if (contabilTributarioFiscal) {
      dadosIntegracaoTo.contabilTributarioFiscal = this.estruturasToJson(contabilTributarioFiscal);
    }
    if (negocio) {
      dadosIntegracaoTo.negocio = this.estruturasToJsonNegocio(negocio);
    }

    return this.http.post<IServiceResponse<RetornoImportacao>>(`${this.URL_API}/salvarIntegracao`, dadosIntegracaoTo, { reportProgress: false });
  }

  salvarDadosIntercooperacao(idCooperativa: number, ano: number,
    intercooperacao: EstruturaIntegracaoTo[]): Observable<IServiceResponse<RetornoImportacao>> {

    const dadosIntegracaoTo = new DadosIntegracaoTo();
    dadosIntegracaoTo.idCooperativa = idCooperativa;
    dadosIntegracaoTo.ano = ano;

    if (intercooperacao) {
      dadosIntegracaoTo.intercooperacao = this.estruturasToJson(intercooperacao);
    }

    return this.http.post<IServiceResponse<RetornoImportacao>>(`${this.URL_API}/salvar-aba-intercooperacao`, dadosIntegracaoTo, { reportProgress: false });
  }

  getFeatureToggleExibeAnuario(): Observable<IServiceResponse<boolean>> {
    return this.http.get<IServiceResponse<boolean>>(`${this.URL_API}/exibeAnuario`);
  }

  getCheckAnuarioAtualizado(cooperativaId: number): Observable<IServiceResponse<boolean>> {
    return this.http.get<IServiceResponse<boolean>>(`${this.URL_API}/status-atualizacao/${cooperativaId}`);
  }

  getStatusAtualizacaoAnuario(cooperativaId: number): Observable<IServiceResponse<string>> {
    return this.http.get<IServiceResponse<string>>(`${this.URL_API}/status-atualizacao-anuario/${cooperativaId}`);
  }

  private estruturasToJson(estruturas: EstruturaIntegracaoTo[]): string {
    const estruturasIntegracaoSalvarTo = this.mapEstruturasIntegracaoToEstruturasIntegracaoSalvar(estruturas);
    return JSON.stringify(estruturasIntegracaoSalvarTo);
  }

  private estruturasToJsonNegocio(estruturas: EstruturaIntegracaoTo[]): string {
    const estruturasIntegracaoSalvarTo = this.mapEstruturasIntegracaoToEstruturasIntegracaoSalvarNegocio(estruturas);
    return JSON.stringify(estruturasIntegracaoSalvarTo);
  }

  private mapEstruturasIntegracaoToEstruturasIntegracaoSalvar(estruturas: EstruturaIntegracaoTo[]): EstruturaIntegracaoSalvarTo[] {
    return estruturas.map((estrutura) => {
      let estruturaIntegracaoSalvarTo = new EstruturaIntegracaoSalvarTo();
      estruturaIntegracaoSalvarTo.id = estrutura.id;
      estruturaIntegracaoSalvarTo.nome = estrutura.nome;

      estrutura.grupos.forEach((grupo) => {
        estruturaIntegracaoSalvarTo.parametros.push(...grupo.parametros);
      });

      return estruturaIntegracaoSalvarTo;
    });
  }

  private mapEstruturasIntegracaoToEstruturasIntegracaoSalvarNegocio(estruturas: EstruturaIntegracaoTo[]): EstruturaIntegracaoSalvarNegocioTo[] {
    return estruturas.map((estrutura) => {
      const estruturaIntegracaoSalvarTo: EstruturaIntegracaoSalvarNegocioTo = {
        id: estrutura.id,
        nome: estrutura.nome,
        parametros: [],
      };

      estrutura.grupos.forEach((grupo) => {
        estruturaIntegracaoSalvarTo.parametros.push(grupo);
      });

      return estruturaIntegracaoSalvarTo;
    });
  }

  salvarAbaDadosSociaisV2(cooperativaId: number, ano: number,
    dadosSociais: ListDadosSociaisAnuarioTO): Observable<IServiceResponse<void>> {

    const financeiro = new DadosIntegracaoTo();
    financeiro.idCooperativa = cooperativaId;
    financeiro.ano = ano;
    financeiro.socialFinanceiro = this.estruturasToJson(dadosSociais.listaDadosSociaisFinanceirosTO);
    dadosSociais.dadosSociaisFinanceirosTO = new DadosSociaisFinanceirosDto();
    dadosSociais.dadosSociaisFinanceirosTO.financeiro = financeiro;

    return this.http.post<IServiceResponse<void>>(`${this.URL_API}/salvar-aba-dados-sociais/financeiro/${cooperativaId}/${ano}`, dadosSociais);
  }
}