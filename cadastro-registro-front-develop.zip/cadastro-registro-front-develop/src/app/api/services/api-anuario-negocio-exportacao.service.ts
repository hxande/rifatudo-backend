import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { NegocioExportacao, NegocioExportacaoTO } from '../models/NegocioExportacao';

@Injectable({
    providedIn: 'root'
})
export class AnuarioNegocioExportacaoService {

    private readonly URL_API = '/cadastro-registro-api/api/v1/negocioexportacao';

    constructor(private http: HttpClient) { }

    obterNegocioExportacaoAnuario(cooperativaId: number, ano: number): Observable<IServiceResponse<NegocioExportacao>> {
        return this.http.get<IServiceResponse<NegocioExportacao>>(`${this.URL_API}/${cooperativaId}/ano/${ano}`);
    }

    verificarPendencias(cooperativaId: number, ano: number): Observable<IServiceResponse<string[]>> {
        return this.http.get<IServiceResponse<string[]>>(`${this.URL_API}/${cooperativaId}/ano/${ano}/pendencias`);
    }

    salvarNegocioExportacaoAnuario(negocioExportacao: NegocioExportacaoTO): Observable<IServiceResponse<NegocioExportacao>> {
        return this.http.post<IServiceResponse<NegocioExportacao>>(`${this.URL_API}/`, negocioExportacao);
    }
}