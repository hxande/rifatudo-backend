import { Endereco } from "@cadastro-registro-api/models/Endereco";
import { EnderecoTO } from "../models/EnderecoTO";

export class EnderecoMapper {
  static toTO(endereco: Endereco): EnderecoTO {
    if (!endereco) return null;

    const to = new EnderecoTO();

    to.id = endereco.id;
    to.bairro = endereco.bairro;
    to.idBairro = endereco.idBairro;
    to.cep = endereco.cep;
    to.enderecoReferencia = endereco.enderecoReferencia;
    to.complemento = endereco.complemento;
    to.idEstado = endereco.idEstado;
    to.idMunicipio = endereco.idMunicipio;
    to.numero = endereco.numero;
    to.enderecoPrincipal = endereco.enderecoPrincipal;
    to.idPessoa = endereco.pessoa ? endereco.pessoa.id : null;
    to.tipoEnderecoId = endereco.tipoEndereco?.id ?? null;
    if (endereco.uf !== undefined && endereco.uf !== null) {
      to.idUf = endereco.uf.id;
    }
    to.correspondenciaDiferente = endereco.correspondenciaDiferente;

    return to;
  }

  static toTOList(enderecos: Endereco[]): EnderecoTO[] {
    if (!enderecos) return [];
    return enderecos.map(e => this.toTO(e));
  }
}
