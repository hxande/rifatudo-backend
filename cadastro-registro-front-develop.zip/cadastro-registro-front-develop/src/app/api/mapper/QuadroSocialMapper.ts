// QuadroSocialMapper.ts

import { QuadroSocial } from "@cadastro-registro-api/models/QuadroSocial";
import { Aprovacao } from "../models/Aprovacao";
import { AprovacaoTO } from "../models/AprovacaoTO";
import { QuadroSocialTO } from "../models/QuadroSocialTO";
import { QuadroSocialParametroQuadro } from "@cadastro-registro-api/models/QuadroSocialParametroQuadro";
import { QuadroSocialParametroQuadroCooperadoTO } from "../models/QuadroSocialParametroQuadroCooperadoTO";
import { QuadroSocialParametroQuadroCooperado } from "@cadastro-registro-api/models/QuadroSocialParametroQuadroCooperado";
import { QuadroSocialParametroQuadroTO } from "../models/QuadroSocialParametroQuadroTO";

export class QuadroSocialMapper {
  static toAprovacaoTO(src: Aprovacao): AprovacaoTO {
    if (!src) return null;
    const to = new AprovacaoTO();
    to.id = src.id;
    to.ano = src.ano;
    to.dataAtualizacao = src.dataAtualizacao;
    to.idCooperativa = src.cooperativa?.id;
    return to;
  }

  static toParametroTO(p: QuadroSocialParametroQuadro): QuadroSocialParametroQuadroTO {
    if (!p) return null;
    const to = new QuadroSocialParametroQuadroTO();
    Object.assign(to, p); // as estruturas são idênticas
    return to;
  }

  static toParametroCooperadoTO(p: QuadroSocialParametroQuadroCooperado): QuadroSocialParametroQuadroCooperadoTO {
    if (!p) return null;
    const to = new QuadroSocialParametroQuadroCooperadoTO();
    Object.assign(to, p); // as estruturas são idênticas
    return to;
  }

  static toTO(src: QuadroSocial): QuadroSocialTO {
    if (!src) return null;

    const to = new QuadroSocialTO();
    to.id                 = src.id;
    to.idPessoa           = src.pessoaJuridica ? src.pessoaJuridica.id : null;
    to.ano                = src.ano;
    to.cooperadosPF       = src.cooperadosPF;
    to.cooperadosPJ       = src.cooperadosPJ;
    to.cooperadosTotal    = src.cooperadosTotal;
    to.empregadosHomens   = src.empregadosHomens;
    to.empregadosMulheres = src.empregadosMulheres;
    to.empregadosTotal    = src.empregadosTotal;
    to.cooperadosHomens   = src.cooperadosHomens;
    to.cooperadosMulheres = src.cooperadosMulheres;
    to.cooperadosAtivos   = src.cooperadosAtivos;

    // auxiliares
    to.apenasTotalPF          = src.apenasTotalPF;
    to.apenasTotalCooperados  = src.apenasTotalCooperados;
    to.apenasTotalEmpregados  = src.apenasTotalEmpregados;

    // nested
    to.aprovacao               = this.toAprovacaoTO(src.aprovacao);
    to.parametroQuadros        = (src.parametroQuadros || []).map(this.toParametroTO);
    to.parametroQuadrosCooperado = (src.parametroQuadrosCooperado || []).map(this.toParametroCooperadoTO);

    return to;
  }

  static toTOList(list: QuadroSocial[]): QuadroSocialTO[] {
    return (list || []).map(q => this.toTO(q));
    }
}
