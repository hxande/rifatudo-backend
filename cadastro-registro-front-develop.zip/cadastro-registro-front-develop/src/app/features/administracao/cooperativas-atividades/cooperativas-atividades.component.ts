import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { TipoAtividade } from '@cadastro-registro-api/models/TipoAtividade';
import { ApiParticipacaoAtividadeService } from '@cadastro-registro-api/services/api-participacao-atividade.service';
import { ApiPeriodoAtualizacaoService } from '@cadastro-registro-api/services/api-periodo-atualizacao.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { Table } from 'primeng/table';
import { TipoAtividadeTO } from 'src/app/api/models/TipoAtividadeTO';
import { AtividadeCooperativaParticipacaoService } from 'src/app/api/services/api-atividade-cooperativa-participacao.service';
import { saveAs } from 'file-saver';
import { HttpParams } from '@angular/common/http';
import { UtilityService } from '@utils/utility/utility.service';
import { SelectItem } from 'primeng/api';
import { CooperativasParaAtividades } from '@cadastro-registro-api/models/CooperativasParaAtividades';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-cooperativas-atividades',
  templateUrl: './cooperativas-atividades.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./cooperativas-atividades.component.css']
})
export class CooperativasAtividadesComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private keycloakService: KeycloakService,
    private router: Router,
    private periodoService: ApiPeriodoAtualizacaoService,
    private participacaoService: ApiParticipacaoAtividadeService,
    private apiUFService: ApiUFService,
    private ramoService: ApiRamoService,
    private dadosGeraisService: ApiDadosGeraisService,
    private apiAtividadeCooperativaParticipacao: AtividadeCooperativaParticipacaoService,
    private utilityService: UtilityService,
  ) {
    if (!this.keycloakService.isUsuarioNacional && !this.keycloakService.isUsuarioEstadual) {
      this.router.navigate(['/inicio']);
    }
  }

  @ViewChild('tabela') tabela: Table;

  response: CooperativasParaAtividades[];
  listaFiltrada: CooperativasParaAtividades[];
  nrLinhasTabela = 20;
  tipoAtividade: TipoAtividadeTO;
  tiposAtividade: TipoAtividade[];
  anoAtividade: SelectItem;
  periodos: SelectItem[]= [];
  uf: Uf;
  listaUfs: Uf[] = [];
  ramos: Ramo[] =[];
  categorias: Categoria[] =[];
  situacoes: SelectItem[] = [];
  participacoes: SelectItem[] = [];
  alteracoes: CooperativasParaAtividades[] =[];
  salvandoAlteracoes = false;

  filtroRamos: unknown[];
  filtroSituacoes: unknown[];
  filtroSituacoesSK: unknown[];
  filtroCategorias: unknown[];
  filtroCnpjNome: string;
  filtroParticipa: boolean;
  filtroAnoRegistro: number;
  filtroUf: string;

  ngOnInit() {
    this.carregarTela();
    this.carregarUfs();
  }

  carregarTela() {
    this.periodoService.buscaTodosAnosSemParametro().then(r=> {
      this.periodos = r.data.map(ano => ({value: ano, label : ano}));
      this.changeDetectorRef.markForCheck();
    });

    this.participacaoService.buscaAtividades().then(r=>{
      this.tiposAtividade = r;
      this.changeDetectorRef.markForCheck();
    });

    this.ramoService.getRamos().then(r=>{
      this.ramos= r.data;
      this.changeDetectorRef.markForCheck();
    });

    this.dadosGeraisService.getCategorias().then(r=> {
      this.categorias = r.data;
      this.changeDetectorRef.markForCheck();
    });

    this.participacoes = [
      {label: 'Sim', value: true},
      {label: 'Não', value: false},
    ];

    this.situacoes = [
      { label: 'Regular', value: 'REGULAR' },
      { label: 'Irregular', value: 'IRREGULAR' },
      { label: 'Suspenso', value: 'SUSPENSO' },
      { label: 'Cancelada', value: 'CANCELADA' }
    ];

  }

  validarDesabilitarUf(){
    if(this.keycloakService.isUsuarioEstadual){
      return true;
    }else{
      return false;
    }
  }

  carregarUfs() {
    this.apiUFService.buscarUfs().then((response) => {
      this.listaUfs = (response as unknown as IPage<Uf>).content;
        this.uf = this.listaUfs.find(uf => {
          if(this.keycloakService.isUsuarioEstadual){
            return uf.sigla == this.keycloakService.getUF();
          }else{
            return null;
          }
        });
        this.changeDetectorRef.markForCheck();
    });
  }

  buscarCoops() {
    const ufSigla = this.uf?.sigla ?? null;
    let params = new HttpParams();
    if (ufSigla) {
      params = params.set('uf', ufSigla);
    }

    this.participacaoService.buscaCoops(this.anoAtividade.value, this.tipoAtividade.id, params).then(r=> {
      this.limparAlteracoes();
      this.response = r;
      this.listaFiltrada = this.response;
      this.changeDetectorRef.markForCheck();
    });
  }

  limparAlteracoes(){
    this.alteracoes = [];
  }

  onInputFiltroText(event, campo){
    const valor =(event.target as HTMLInputElement).value;
    this.tabela.filter(valor, campo, 'startsWith');
  }

  onInputCnpjNomeFantasia(event, campo){
    const valor =(event.target as HTMLInputElement).value;
    this.tabela.filter(valor, campo, 'contains');
  }


  onInputFiltroGlobal(event){
    const valor =(event.target as HTMLInputElement).value;
    this.tabela.filterGlobal(valor,'contains');
  }

  guardarElementosFiltrados(event){
    this.listaFiltrada = event.filteredValue;
  }

  alterarFiltrados(participacao: boolean){
    this.listaFiltrada.forEach(coopA => this.alterarParticipacao(coopA, participacao));
  }

  alterarParticipacao(coopParaAtividade: CooperativasParaAtividades, participacao: boolean){
    const index = this.alteracoes.findIndex(c => c.idCooperativa === coopParaAtividade.idCooperativa);
    // se idCoop não estava na lista, adiciona com participacao nova
    if(index === -1) {
      this.alteracoes = [
        ...this.alteracoes,
        {
          ...coopParaAtividade,
          participa: participacao
        }
      ];
    }
    // else atualiza participacao
    else {
      this.alteracoes = this.alteracoes.map((c, i) =>
        i === index ? { ...c, participa: participacao } : c
    );
    }

    this.changeDetectorRef.markForCheck();
  }

  salvarAlteracoes(){
    if (this.salvandoAlteracoes) {
      return;
    }
    this.salvandoAlteracoes = true;
    this.participacaoService.salvaAlteracoes(this.tipoAtividade.id, this.anoAtividade.value, this.alteracoes).then(r => {
      this.buscarCoops();
      this.alteracoes = [];
    }).finally(() => {
      this.salvandoAlteracoes = false;
      this.changeDetectorRef.markForCheck();
    });
  }


  filtrarColunaMulti( valores: unknown[],coluna: string){
    this.tabela.filter(valores,coluna,'in');
  }

  gerarRelatorio(){
    const options = {
      params: new HttpParams()
    };
    if (this.filtroSituacoes?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroSituacoes, options.params, 'situacoes');
    }

    if(this.filtroSituacoesSK?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroSituacoesSK, options.params, 'situacoesSK');
    }

    if(this.filtroRamos?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroRamos, options.params, 'ramos');
    }

    if(this.filtroCategorias?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroCategorias, options.params, 'categorias');
    }

    if(this.filtroParticipa){
      options.params = this.utilityService.setParamsBoolean(this.filtroParticipa, options.params, 'participa');
    }

    if(this.filtroCnpjNome){
      options.params = this.utilityService.carregaParamsString(this.filtroCnpjNome, options.params, 'nomeCnpj');
    }

    options.params = this.utilityService.carregaParamsString(this.tipoAtividade.id, options.params, 'tipoAtividade');
    options.params = this.utilityService.carregaParamsString(this.anoAtividade.value, options.params, 'anoAtividade');

    if (this.uf?.sigla) {
      options.params = this.utilityService.carregaParamsString(this.uf.sigla, options.params, 'uf');
    }

    this.apiAtividadeCooperativaParticipacao.gerarRelatorio(options)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => this.realizarDownloadRelatorio('Relatorio_Cooperativa_Atividades.xlsx', response));
  }

  private realizarDownloadRelatorio(nomeRelatorio: string, dados): void {
    const blob = new Blob([dados], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, nomeRelatorio);
  }

}


