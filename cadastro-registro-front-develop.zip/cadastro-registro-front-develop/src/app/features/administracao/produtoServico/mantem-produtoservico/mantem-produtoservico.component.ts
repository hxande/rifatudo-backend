import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { ApiProdutoservicoService } from '@cadastro-registro-api/services/api-produtoservico.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-mantem-produtoservico',
  templateUrl: './mantem-produtoservico.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-produtoservico.component.css']
})
export class MantemProdutoservicoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  produtoservico: Produtoservico;
  optionsDropdownRamo: Ramo[];
  optionsDropdownSegmento: Segmento[];

  @ViewChild('produtoservicoForm') produtoservicoForm: NgForm;
  constructor(
    private produtoservicoApi: ApiProdutoservicoService,
    private ramoAPI: ApiRamoService,
    private segmentoAPI: ApiSegmentoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.produtoservico = new Produtoservico();
    this.ramoAPI.getRamos().then(response => {
      this.optionsDropdownRamo = response.data;
      this.changeDetectorRef.markForCheck();
    });
    this.segmentoAPI.lista().then(response => {
      this.optionsDropdownSegmento = response.data;
      this.changeDetectorRef.markForCheck();
    });
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Produto e Serviço', routerLink: '/administracao/listagem-produto-servico' },
      { label: 'Cadastro de Produto e Serviço', routerLink: '/administracao/novo-produto-servico' }
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-produto-servico') {
      this.route.params.subscribe(params => {
        this.produtoservicoApi.get(params['id'])
          .then(res => {
            this.produtoservico = res.data;
            this.changeDetectorRef.markForCheck();
          });
      });
    } else {
      this.inicializarProdutoservico();
    }
  }

  inicializarProdutoservico() {
    this.produtoservico = new Produtoservico();
    this.produtoservico.ativo = true;
  }

  salvar(): void {
    if (this.produtoservicoForm.invalid) {
      return;
    }
    this.produtoservico.excluido = false;
    if (this.produtoservico.id) {
      this.produtoservicoApi.altera(this.produtoservico);
      this.changeDetectorRef.markForCheck();
    } else {
      this.produtoservicoApi.inclui(this.produtoservico)
        .then(() => {
          this.produtoservicoForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() => {
            this.inicializarProdutoservico();
            this.changeDetectorRef.markForCheck();
          }, 0);
          this.changeDetectorRef.markForCheck();
        });
    }
  }

}
