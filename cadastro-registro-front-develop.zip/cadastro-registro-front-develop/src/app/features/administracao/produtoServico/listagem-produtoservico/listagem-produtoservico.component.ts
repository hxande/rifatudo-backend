import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiProdutoservicoService } from '@cadastro-registro-api/services/api-produtoservico.service';
import { UtilityService } from '@utils/utility/utility.service';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-listagem-produtoservico',
  templateUrl: './listagem-produtoservico.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-produtoservico.component.css']
})
export class ListagemProdutoservicoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private produtoservicoApi: ApiProdutoservicoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Produto e Serviço', routerLink: '/administracao/listagem-produto-servico' },
      { label: 'Consulta de Produto e Serviço', routerLink: '/administracao/listagem-produto-servico' }
    ]);
  }

  responseProdutoservico: IServiceResponse<IPage<Produtoservico>>;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  filtroDescricao='';
  filtrodetalhamento='';
  filtroTipoPessoa='';
  filtroRamo='';
  filtroSegmento='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'ramo.nome', header: 'Ramo' },
      { field: 'segmento.nome', header: 'Segmento' },
      { field: 'descricao', header: 'Descrição' },
      { field: 'detalhamento', header: 'Detalhamento' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getProdutoservicos(pagina = 0, sortField = 'descricao', sortOrder = 1): Promise<IServiceResponse<IPage<Produtoservico>>> {
    sortField = sortField || 'descricao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.produtoservicoApi.listaPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroDescricao, options.params, 'descricao');
    options.params = this.utilityService.carregaParamsString(this.filtrodetalhamento, options.params, 'detalhamento');
    options.params = this.utilityService.carregaParamsString(this.filtroRamo, options.params, 'ramo');
    options.params = this.utilityService.carregaParamsString(this.filtroSegmento, options.params, 'segmento');
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getProdutoservicos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseProdutoservico => {
      this.responseProdutoservico = responseProdutoservico;
      this.changeDetectorRef.markForCheck();
    });
  }

  ativarProdutoservico(obj: Produtoservico){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      accept: () => {
        this.produtoservicoApi.desativa(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
