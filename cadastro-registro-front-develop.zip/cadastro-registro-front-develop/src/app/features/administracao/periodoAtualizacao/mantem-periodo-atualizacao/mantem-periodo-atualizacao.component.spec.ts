import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { MantemPeriodoAtualizacaoComponent } from './mantem-periodo-atualizacao.component';


describe('MantemPeriodoAtualizacaoComponent', () => {
  let component: MantemPeriodoAtualizacaoComponent;
  let fixture: ComponentFixture<MantemPeriodoAtualizacaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemPeriodoAtualizacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemPeriodoAtualizacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
