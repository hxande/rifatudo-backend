import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { PeriodoAtualizacao } from '@cadastro-registro-api/models/PeriodoAtualizacao';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { DateService } from '@shared/util/service/date.service';
import { DataUtils } from '@shared/utils/DataUtils';
import { ApiPeriodoAtualizacaoService } from '@cadastro-registro-api/services/api-periodo-atualizacao.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { MessageService, SelectItem } from 'primeng/api';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-mantem-periodo-atualizacao',
  templateUrl: './mantem-periodo-atualizacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-periodo-atualizacao.component.css']
})
export class MantemPeriodoAtualizacaoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  periodos: PeriodoAtualizacao[];
  optionsRamos: Ramo[];
  anoAtual: number;
  dataAtual = new Date();
  ano: number;
  anoReferencia: number;
  isAtualizar: boolean;
  exibirFormulario: boolean;
  dialogInformarCooperativas: boolean;
  ramoSelecionado: Ramo;
  dataInicio: Date;
  dataInicioAnuario: Date;
  dataFim: Date;
  dataFimAnuario: Date;
  dateService = new DateService;
  mostrarAnuario: boolean;

  informarValidado: boolean;
  msgValidacaoinformar: boolean;
  podeSalvar = false;
  dataUtils = new DataUtils;
  @ViewChild('periodoAtualizacaoForm') periodoAtualizacaoForm: NgForm;
  display: boolean;
  constructor(
    private periodoApi: ApiPeriodoAtualizacaoService,
    private ramoApi: ApiRamoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    public language: LanguageService,
    public keycloakService: KeycloakService,
    private apiManutencaoDadosGeraisService: ApiManutencaoDadosGeraisService,
    private messageService: MessageService,
  ) {
    this.periodos = new Array<PeriodoAtualizacao>();
    this.ano = (new Date()).getFullYear();
    this.anoAtual = this.dataAtual.getFullYear();
    this.anoReferencia = this.ano - 1;
    this.inicializarRamo();
    this.isAtualizar = false;
    this.exibirFormulario = true;
    this.dialogInformarCooperativas = false;
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Período de Atualização', routerLink: '/administracao/listagem-periodo-atualizacao' },
      { label: 'Cadastro de Período de Atualização', routerLink: '/administracao/novo-periodo-atualizacao' }
    ]);
    this.display = false;
    this.informarValidado = false;
    this.msgValidacaoinformar = false;
    this.mostrarAnuario = false;
    this.ramoSelecionado = new Ramo();

  }

  listaUf: SelectItem[] = [];;
  ufSelecionada: string;

  async ngOnInit() {
    await this.carregarListaUf();
    this.carregarTela();
  }

  atribuiUf() {
    this.carregarTela();
    this.validaCadastro();
  }

  carregarListaUf() {
    return new Promise<void>((resolve) => {
      this.listaUf = [];
      this.apiManutencaoDadosGeraisService.buscarUfs().then((res) => {
        if (res && res.content != null) {
          // Mapeia de forma limpa criando a estrutura correta de objetos
          this.listaUf = res.content.map(uf => ({ label: uf.sigla, value: uf.sigla }));

          if (this.keycloakService.isUsuarioEstadual) {
            this.ufSelecionada = this.keycloakService.getUF();
          }
        }
        resolve();
        this.changeDetectorRef.markForCheck();
      });
    });
  }

  carregarTela() {
    if (this.route.snapshot.url[0]?.path === 'editar-periodo-atualizacao') {
      this.route.params.subscribe(params => {
        this.ano = params['id'] ? Number(params['id']) : null;
        this.isAtualizar = this.ano < this.anoAtual;
        this.verificarSeExisteAno();
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.exibirFormulario = false;
      this.verificarSeExisteAno();
    }
  }

  carregaOptions() {
    const options = {
      params: new HttpParams()
    };
    if (this.ano != null) {
      options.params = options.params.set('ano', this.ano);
    }
    if (this.ufSelecionada != null && this.ufSelecionada !== '') {
      options.params = options.params.set('uf', this.ufSelecionada);
    }else if (this.keycloakService.isUsuarioNacional){
      options.params = options.params.set('uf', 'UN');
    }
    return options;
  }

  inicializar() {
    const periodo = new PeriodoAtualizacao();
    periodo.ramo = new Ramo();

    this.periodos = [periodo];
    this.mostrarAnuario = false;
  }

  validaCadastro() {
    this.anoReferencia = this.ano ? this.ano - 1 : null;
    let totalNaoValidos = 0;

    if (!this.ano) {
      totalNaoValidos++;
    }

    if (this.periodos && this.periodos.length > 0) {
      this.periodos.forEach(periodo => {
        if (
          !periodo.ramo ||
          !periodo.ramo.id ||
          !periodo.fimAttCadastral ||
          !periodo.inicioAttCadastral ||
          (this.mostrarAnuario && (!periodo.fimAttAnuario || !periodo.inicioAttAnuario))
        ) {
          totalNaoValidos += 1;
        }
      });
      this.podeSalvar = totalNaoValidos <= 0;
    } else {
      this.podeSalvar = false;
    }
  }

  salvar(): void {
    if (this.periodoAtualizacaoForm.invalid) {
      return;
    }
    if (this.ano) {
      this.periodos.forEach(periodo => {
        periodo.inicioAttCadastral = this.dateService.getDate(periodo.inicioAttCadastral);
        periodo.inicioAttAnuario = this.dateService.getDate(periodo.inicioAttAnuario);
        periodo.fimAttCadastral = this.dateService.getDate(periodo.fimAttCadastral);
        periodo.fimAttAnuario = this.dateService.getDate(periodo.fimAttAnuario);
        periodo.mostrarAnuario = this.mostrarAnuario;
        if(!this.ufSelecionada && this.keycloakService.isUsuarioNacional){
          this.ufSelecionada = 'UN';
        }
        periodo.uf = this.ufSelecionada;
      });

      this.periodoApi.salva(this.ufSelecionada, this.ano, this.periodos)
      .then(() => {
        setTimeout(() => {
          this.verificarSeExisteAno()
          this.changeDetectorRef.markForCheck();
        }, 0);
      });
    }
  }

  removerPeriodo(i: number) {
    this.periodos = this.periodos.filter((_periodo, index) => index !== i);
    this.validaCadastro();
  }

  inicializarRamo() {
    this.ramoApi.getRamos().then(res => {
      this.optionsRamos = res.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  adicionarPeriodo() {
    const periodo = new PeriodoAtualizacao();
    periodo.ramo = new Ramo();
    this.periodos = [
      ...this.periodos,
      periodo
    ];
    this.validaCadastro();
  }

  verificarSeExisteCiclo(ramo: Ramo, index: number) {
    if (this.periodos.filter(p => p.ramo.id === ramo.id).length > 1) {
      this.display = true;
      setTimeout(() => {
        this.periodos[index].ramo = null;
        this.validaCadastro();
        this.changeDetectorRef.markForCheck();
      }, 100);
      this.messageService.add({ severity: 'warn', detail: 'Você já cadastrou um ciclo para esse ramo.', life: 10000 });
    }
  }

  verificarSeExisteAno() {
    if (this.ano) {
      this.anoReferencia = this.ano - 1;
      const options = this.carregaOptions();
      this.periodoApi.getFiltroCiclo(options).then(res => {
        if (res.data.length) {
          this.periodos = res.data;
          this.mostrarAnuario = res.data[0].mostrarAnuario;
          for (const periodo of this.periodos) {
            periodo.ano = this.ano;
            periodo.inicioAttCadastral = new Date(periodo.inicioAttCadastral);
            if (periodo.inicioAttAnuario) {
              periodo.inicioAttAnuario = new Date(periodo.inicioAttAnuario);
            }
            periodo.fimAttCadastral = new Date(periodo.fimAttCadastral);
            if (periodo.fimAttAnuario) {
              periodo.fimAttAnuario = new Date(periodo.fimAttAnuario);
            }
          }
        } else {
          this.inicializar();
        }
        this.validaCadastro();
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  informarCooperaivas(){
    this.inicializarDialog();
    this.ramoSelecionado = new Ramo();
    this.dialogInformarCooperativas = true;
  }

  inicializarDialog(){
    this.msgValidacaoinformar = false;
    this.informarValidado = false;

    this.dataInicio = null;
    this.dataFim = null;
    this.dataInicioAnuario = null;
    this.dataFimAnuario = null;
  }

  cancelaInformarCooperativas(){
    this.dialogInformarCooperativas = false;
    this.ramoSelecionado = new Ramo();
    this.inicializarDialog();
  }

  confirmarInformarCooperativas(){

    this.periodoApi.informarCooperativasPorRamo(this.ramoSelecionado, this.ano);
    this.cancelaInformarCooperativas();
  }

  buscarDatas(ramoSelecionado: Ramo) {
    this.inicializarDialog();
    let existe = false;
    for (const periodo of this.periodos) {
      if(periodo.ramo.id === ramoSelecionado.id){
        this.dataInicio = periodo.inicioAttCadastral;
        this.dataInicioAnuario = periodo.inicioAttAnuario;
        this.dataFim = periodo.fimAttCadastral;
        this.dataFimAnuario = periodo.fimAttAnuario;
        existe = true;
      }
    }
    if(existe &&  this.dataInicio <= this.dataAtual && this.dataAtual <= this.dataFim){
      this.informarValidado = true;
    }else{
      this.msgValidacaoinformar = true;
    }
  }
}
