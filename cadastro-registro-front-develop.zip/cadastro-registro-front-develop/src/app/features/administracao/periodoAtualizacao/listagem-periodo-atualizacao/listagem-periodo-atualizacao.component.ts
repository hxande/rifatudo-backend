import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { ApiPeriodoAtualizacaoService } from '@cadastro-registro-api/services/api-periodo-atualizacao.service';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';

@Component({
  selector: 'app-listagem-periodo-atualizacao',
  templateUrl: './listagem-periodo-atualizacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-periodo-atualizacao.component.css']
})
export class ListagemPeriodoAtualizacaoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private apiPeriodo: ApiPeriodoAtualizacaoService,
    private breadCrumbPrimeNGService:BreadcrumbService,
    public keycloakService: KeycloakService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Período de Atualização', routerLink: '/administracao/listagem-periodo-atualizacao' },
      { label: 'Consulta de Períodos de Atualização', routerLink: '/administracao/listagem-periodo-atualizacao' }
    ]);
   }

   nrLinhasTabela = 10 ;
   private debouncer;
   private delay = 500;
   filtroAno=null;
   cols: { field: string, header: string }[];
   anos: IServiceResponse<IPage<number>>;
   @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'ano', header: 'Ano' }
    ];
  }
  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    if(this.filtroAno != null){
      options.params = options.params.set('ano', this.filtroAno + '');
    }

    return options;

  }

  getPeriodo(pagina = 0, sortField = 'ano', sortOrder = 1): Promise<IServiceResponse<IPage<number>>> {
    sortField = 'ano';
    let sort: string;
    sort = sortOrder === 1 ? 'desc' : 'asc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.apiPeriodo.buscaTodosAnos(options);
}

  visualizarBotaoNovoAno(){
    return this.keycloakService.isUsuarioNacional;
  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getPeriodo(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(response => {
      this.anos = response;
      this.changeDetectorRef.markForCheck();
    });
  }

}
