import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { UtilityService } from '@utils/utility/utility.service';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-listagem-segmento',
  templateUrl: './listagem-segmento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-segmento.component.css']
})
export class ListagemSegmentoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private segmentoApi: ApiSegmentoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Segmento', routerLink: '/administracao/listagem-segmento' },
      { label: 'Consulta de Segmento', routerLink: '/administracao/listagem-segmento' }
    ]);
   }

  responseSegmento: IServiceResponse<IPage<Segmento>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroNome='';
  filtrodetalhamento='';
  filtroTipoPessoa='';
  filtroRamo='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'ramo.nome', header: 'Ramo' },
      { field: 'nome', header: 'Nome' },
      { field: 'detalhamento', header: 'Detalhamento' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getSegmentos(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<Segmento>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.segmentoApi.listaPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    options.params = this.utilityService.carregaParamsString(this.filtrodetalhamento, options.params, 'detalhamento');
    options.params = this.utilityService.carregaParamsString(this.filtroRamo, options.params, 'ramo');
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getSegmentos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseSegmento => {
      this.responseSegmento = responseSegmento;
      this.changeDetectorRef.markForCheck();
    });
  }

  ativarSegmento(obj: Segmento){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      key: 'ativarSegmento',
      accept: () => {
        this.segmentoApi.desativa(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
