import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemSegmentoComponent } from './listagem-segmento.component';

describe('ListagemSegmentoComponent', () => {
  let component: ListagemSegmentoComponent;
  let fixture: ComponentFixture<ListagemSegmentoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemSegmentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemSegmentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
