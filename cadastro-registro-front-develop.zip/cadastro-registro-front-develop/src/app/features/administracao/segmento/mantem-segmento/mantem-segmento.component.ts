import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, OnInit, ViewChild, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';


@Component({
  selector: 'app-mantem-segmento',
  templateUrl: './mantem-segmento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-segmento.component.css']
})
export class MantemSegmentoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  segmento: Segmento;
  optionsDropdownRamo: Ramo[];

  @ViewChild('segmentoForm') segmentoForm: NgForm;
  constructor(
    private segmentoApi: ApiSegmentoService,
    private ramoAPI: ApiRamoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.segmento = new Segmento();
    this.ramoAPI.getRamos().then(response => {
      this.optionsDropdownRamo = response.data;
      this.changeDetectorRef.markForCheck();
    });
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Segmento', routerLink: '/administracao/listagem-segmento' },
      { label: 'Cadastro de Segmento', routerLink: '/administracao/novo-segmento' }
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-segmento') {
      this.route.params
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(params => {
          this.segmentoApi.get(params['id'])
            .then(res => {
              this.segmento = res.data;
              this.changeDetectorRef.markForCheck();
            });
        });
    } else {
      this.inicializarSegmento();
    }
  }

  inicializarSegmento() {
    this.segmento = new Segmento();
    this.segmento.ativo = true;
  }

  salvar(): void {
    if (this.segmentoForm.invalid) {
      return;
    }
    this.segmento.excluido = false;
    if (this.segmento.id) {
      this.segmentoApi.altera(this.segmento);
    } else {
      this.segmentoApi.inclui(this.segmento)
        .then(() => {
          this.segmentoForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() => {
            this.inicializarSegmento();
            this.changeDetectorRef.markForCheck();
          }, 0);
        });
    }
  }

}
