import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemSegmentoComponent } from './mantem-segmento.component';

describe('MantemSegmentoComponent', () => {
  let component: MantemSegmentoComponent;
  let fixture: ComponentFixture<MantemSegmentoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemSegmentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemSegmentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
