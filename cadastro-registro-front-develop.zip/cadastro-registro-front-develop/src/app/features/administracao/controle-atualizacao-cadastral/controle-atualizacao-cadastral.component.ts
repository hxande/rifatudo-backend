import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import DecoupledEditor from '@ckeditor/ckeditor5-build-decoupled-document';
import { EditorConfig } from '@ckeditor/ckeditor5-core';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ControleAtualizacaoCadastralTO } from 'src/app/api/models/ControleAtualizacaoCadastralTO';
import { NgForm } from '@angular/forms';
import { ApiControleAtualizacaoCadastralService } from 'src/app/api/services/api-controle-atualizacao-cadastral.service';
import { Router } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';


@Component({
  selector: 'app-controle-atualizacao-cadastral',
  templateUrl: './controle-atualizacao-cadastral.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./controle-atualizacao-cadastral.component.css']
})
export class ControleAtualizacaoCadastralComponent implements OnInit, AfterViewInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  public config;

  public editor = DecoupledEditor;

  uf: Uf;
  listaUfs: Uf[] = [];

  habilitaSelecaoUf = false;

  controleAtualizacaoCadastral: ControleAtualizacaoCadastralTO = new ControleAtualizacaoCadastralTO();
  controleAtualizacaoCadastralNacional: ControleAtualizacaoCadastralTO = new ControleAtualizacaoCadastralTO();
  private habilitarFormularioAtualizacao = true;

  @ViewChild('controleAtualizacaoCadastralForm') controleAtualizacaoCadastralForm: NgForm;
  constructor(
    private breadCrumbPrimeNGService: BreadcrumbService,
    private keycloakService: KeycloakService,
    private apiUFService: ApiUFService,
    private apiControleAtualizacaoCadastralService: ApiControleAtualizacaoCadastralService,
    private router: Router

  ) {
      this.habilitaSelecaoUf =  this.keycloakService.isUsuarioNacional;

      this.breadCrumbPrimeNGService.setItems([
        { label: 'Administração', routerLink: '/administracao/inicio' },
        { label: 'Controle Atualização Cadastral', routerLink: '/administracao/controle-atualizacao-cadastral' },
      ]);
    }


  ngOnInit() {
    this.inicializaRegistroVazio();
    this.inicializaControleNacionalVazio();
    this.carregaControleNacional();
    this.carregarUfs();
    this.config = {
      toolbar: {
        items: [
          'undo', 'redo',
          '|', 'bold', 'italic', 'underline', 'strikethrough',
          '|', 'link',
          '|', 'bulletedList', 'numberedList', 'outdent', 'indent',
          '|', 'alignment:left', 'alignment:right', 'alignment:center', 'alignment:justify'
        ],
        shouldNotGroupWhenFull: false
      }
    } as EditorConfig;
  }

  ngAfterViewInit(): void {
    this.aplicarEstadoFormulario();
    this.changeDetectorRef.markForCheck();
  }


  carregaControleNacional() {
    this.apiControleAtualizacaoCadastralService.obterControleAtualizacaoCadastralNacional()
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if (response?.data) {
        this.controleAtualizacaoCadastralNacional = response.data;
        this.habilitarFormularioAtualizacao = !!this.controleAtualizacaoCadastralNacional.permiteEstadualPreencher;
        this.aplicarEstadoFormulario();
      }
      this.changeDetectorRef.markForCheck();
    });
  }


  inicializaRegistroVazio() {
    this.controleAtualizacaoCadastral = new ControleAtualizacaoCadastralTO()
    this.controleAtualizacaoCadastral.mostrarPopup = false;
    this.controleAtualizacaoCadastral.textoPopup = '';
    this.controleAtualizacaoCadastral.permiteCooperativaPreencher = false;
    this.controleAtualizacaoCadastral.permiteCooperativaVisualizar = false;
    this.controleAtualizacaoCadastral.destacarAtualizacaoCadastral = false;
  }

  private inicializaControleNacionalVazio() {
    this.controleAtualizacaoCadastralNacional = new ControleAtualizacaoCadastralTO();
    this.controleAtualizacaoCadastralNacional.permiteEstadualPreencher = true;
    this.habilitarFormularioAtualizacao = true;
  }

  private aplicarEstadoFormulario() {
    if (!this.controleAtualizacaoCadastralForm?.form) {
      return;
    }

    if (this.habilitarFormularioAtualizacao) {
      this.controleAtualizacaoCadastralForm.form.enable();
    } else {
      this.controleAtualizacaoCadastralForm.form.disable();
    }
  }



  public onReady(editor: DecoupledEditor): void {
    const element = editor.ui.getEditableElement()!;
    const parent = element.parentElement!;
    parent.insertBefore(
      editor.ui.view.toolbar.element!,
      element
    );
  }

  buscarPorUf() {
    this.carregaControleNacional();
    const ufSigla = this.uf ? this.uf.sigla : null;
    this.apiControleAtualizacaoCadastralService.obterControleAtualizacaoCadastral(ufSigla)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if(response && response.data){
        this.controleAtualizacaoCadastral = response.data;
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarUfs() {
    this.apiUFService.buscarUfs().then((response)=>{
      this.listaUfs = (response as unknown as IPage<Uf>).content;
      if(!this.habilitaSelecaoUf){
        this.uf = this.listaUfs.find(uf => uf.sigla == this.keycloakService.getUF());

      }
      this.buscarPorUf();
      this.changeDetectorRef.markForCheck();
    });
  }

  desabilitarControleAtualizacaoCadastral(){
    this.uf = null;
    this.apiControleAtualizacaoCadastralService.desabilitarControleAtualizacaoCadastral(this.controleAtualizacaoCadastralNacional.permiteEstadualPreencher)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.habilitarFormularioAtualizacao = !!this.controleAtualizacaoCadastralNacional?.permiteEstadualPreencher;
      this.aplicarEstadoFormulario();
      this.buscarPorUf();
      this.changeDetectorRef.markForCheck();
    });
  }

  salvar(): void {
    this.controleAtualizacaoCadastral.uf = this.uf ? this.uf.sigla : null;
    this.controleAtualizacaoCadastral.permiteEstadualPreencher = true;
    this.apiControleAtualizacaoCadastralService.salvarControleAtualizacaoCadastral(this.controleAtualizacaoCadastral)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.controleAtualizacaoCadastral = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  voltar() {
    this.router.navigate(['/administracao']);
  }
}
