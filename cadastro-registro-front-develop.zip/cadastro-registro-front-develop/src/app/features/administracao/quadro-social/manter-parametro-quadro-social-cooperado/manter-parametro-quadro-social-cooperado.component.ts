import {ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';

import { ParametroQuadroSocialTO } from 'src/app/api/models/ParametroQuadroSocialTO';
import { ApiParametroQuadroSocialService } from 'src/app/api/services/api-parametro-quadro-social.service';


@Component({
  selector: 'app-manter-parametro-quadro-social-cooperado',
  templateUrl: './manter-parametro-quadro-social-cooperado.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./manter-parametro-quadro-social-cooperado.component.css']
})
export class ManterParametroQuadroSocialCooperadoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() parametroQuadroSocial: ParametroQuadroSocialTO | null = null;
  @Output() isCancelar = new EventEmitter<boolean>();

  @ViewChild('ParametroQuadroSocialForm') parametroQuadroSocialForm: NgForm;

  dataAtual = new Date();
  label = '';
  isEdicao = false;

  constructor(
    private parametroQuadroSocialService: ApiParametroQuadroSocialService
  ) {
  }

  ngOnInit() {
    this.carregarLabel();
  }

  carregarLabel() {
    if (this.parametroQuadroSocial.id) {
      this.label = 'Editar Parametro Cooperado';
      this.isEdicao = true;
    } else {
      this.label = 'Criar Parametro Cooperado';
      this.parametroQuadroSocial.ativo = true;
    }
  }

  criar() {
    if (this.parametroQuadroSocialForm.valid) {
      this.parametroQuadroSocialService.salvarParametroQuadroSocialCooperado(this.parametroQuadroSocial).then(x => {
        this.isCancelar.emit(true);
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  cancelar() {
    this.isCancelar.emit(false);
  }

}
