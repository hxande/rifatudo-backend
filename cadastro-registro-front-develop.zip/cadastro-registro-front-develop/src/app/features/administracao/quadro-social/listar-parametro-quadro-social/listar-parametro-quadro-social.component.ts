import {ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild} from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService, SelectItem } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import {Table} from 'primeng/table';
import {Router} from '@angular/router';
import { UtilityService } from '@utils/utility/utility.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ParametroQuadroSocial } from '@cadastro-registro-api/models/ParametroQuadroSocial';
import { IPage } from '@utils/interfaces/IPage';
import { ParametroQuadroSocialTO } from 'src/app/api/models/ParametroQuadroSocialTO';
import { ApiParametroQuadroSocialService } from 'src/app/api/services/api-parametro-quadro-social.service';

@Component({
  selector: 'app-listar-parametro-quadro-social',
  templateUrl: './listar-parametro-quadro-social.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listar-parametro-quadro-social.component.css']
})
export class ListarParametroQuadroSocialComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private parametroQuadroSocialService: ApiParametroQuadroSocialService,
    private utilityService: UtilityService,
    private keycloakService: KeycloakService,
    private router: Router,
    private confirmationService: ConfirmationService,
  ) {
    this.parametroQuadroSocial = new ParametroQuadroSocialTO();
    if (!this.keycloakService.isUsuarioNacional) {
      this.router.navigate(['/inicio']);
    }
  }

  @ViewChild('Dt') dt: Table;

  filtroId = '';
  filtroDescricao = '';
  filtroAtivo = null;
  filtroAtivoDropdown: SelectItem[] = [{label: 'Ativo', value: 'true'}, {label: 'Inativo', value: 'false'}];
  private debouncer;
  parametroQuadroSocial: ParametroQuadroSocialTO;
  response: IPage<ParametroQuadroSocial>;
  nrLinhasTabela = 20;
  isManterParametroQuadroSocial = false;
  cols: { field: string, header: string }[];
  excluindo = false;

  controleParametroQuadroSocial: boolean;

  ngOnInit() {
    this.cols = [
      {field: 'id', header: 'Código'},
      {field: 'descricaoParametro', header: 'Parâmetro'},
      {field: 'ativo', header: 'Situação'},
      {field: 'obrigatorio', header: 'Obrigatório'},
      {field: '', header: ''},
      {field: '', header: ''}
    ];

    this.carregarTela();
  }

  carregarTela() {
    this.listarParametroQuadroSocial();
    this.getControleParametroQuadroSocial();
  }

  getControleParametroQuadroSocial() {
    this.parametroQuadroSocialService.getControleParametroQuadroSocial().then((response) => {
      this.controleParametroQuadroSocial = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }
  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, 500);
  }

  listarParametroQuadroSocial() {
    this.getParametroQuadroSocial().then(situacoesCadastrais => {
      if (situacoesCadastrais) {
        this.response = situacoesCadastrais;

      }
      this.changeDetectorRef.markForCheck();
    });
  }

  getParametroQuadroSocial(pagina = 0, sortField = 'id', sortOrder = 1): Promise<IPage<ParametroQuadroSocial>> {
    sortField = sortField || 'id';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.parametroQuadroSocialService.getParametroQuadroSocialPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`),
      reportProgress: true,
    };

    options.params = this.utilityService.carregaParamsString(this.filtroAtivo, options.params, 'ativo');
    options.params = this.utilityService.carregaParamsString(this.filtroDescricao, options.params, 'descricao');
    options.params = this.utilityService.carregaParamsString(this.filtroId, options.params, 'id');

    return options;
  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getParametroQuadroSocial(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(response => {
      this.response = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  criarParametroQuadroSocial() {
    this.parametroQuadroSocial = new ParametroQuadroSocialTO();
    this.isManterParametroQuadroSocial = true;
  }

  editarParametroQuadroSocial(parametroQuadroSocial) {
    this.parametroQuadroSocialService.getParametroQuadroSocialPorId(parametroQuadroSocial.id).then(res => {
      this.parametroQuadroSocial = res;
      this.isManterParametroQuadroSocial = true;
      this.changeDetectorRef.markForCheck();
    });
  }

  excluirParametroQuadroSocial(parametroQuadroSocial, index) {
    if (this.excluindo) {
      return;
    }
    this.confirmationService.confirm({
      message: 'Deseja realmente excluir o parametro "' + parametroQuadroSocial.descricaoParametro + '" dos registros?',
      accept: () => {
        this.excluindo = true;
        this.parametroQuadroSocialService.excluirParametroQuadroSocial(parametroQuadroSocial.id).then(r => {
          if (r && r.messages && r.messages[0] && r.messages[0].type === 'ERROR') {
            return;
          }
          this.response = {
            ...this.response,
            content: this.response.content.filter((_, i) => i !== index)
          };
        }).finally(() => {
          this.excluindo = false;
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

  cancelar(event) {
    if (event) {
      this.listarParametroQuadroSocial();
    }
    this.isManterParametroQuadroSocial = false;
  }

  habilitaControleParametroQuadroSocial(){

    this.parametroQuadroSocialService.habilitaControleParametroQuadroSocial(this.controleParametroQuadroSocial).then((response) => {
      this.carregarTela();
    })
  }

}
