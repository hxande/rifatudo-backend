import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiOrgaoReguladorService } from '@cadastro-registro-api/services/api-orgao-regulador.service';
import { UtilityService } from '@utils/utility/utility.service';
import { OrgaoRegulador } from '@cadastro-registro-api/models/OrgaoRegulador';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-listagem-orgao-regulador',
  templateUrl: './listagem-orgao-regulador.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-orgao-regulador.component.css']
})
export class ListagemOrgaoReguladorComponent implements OnInit {
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private orgaoReguladorApi: ApiOrgaoReguladorService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Órgão Regulador', routerLink: '/administracao/listagem-orgao-regulador' },
      { label: 'Consulta de Órgão Regulador', routerLink: '/administracao/listagem-orgao-regulador' }
    ]);
   }

  responseOrgaoRegulador: IServiceResponse<IPage<OrgaoRegulador>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroSigla='';
  filtrodescricao='';
  filtrodetalhamento='';
  filtroTipoPessoa='';
  filtroRamo='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'ramo.nome', header: 'Ramo' },
      { field: 'sigla', header: 'Sigla' },
      { field: 'descricao', header: 'Descrição' },
      { field: 'detalhamento', header: 'Detalhamento' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getOrgaoReguladors(pagina = 0, sortField = 'sigla', sortOrder = 1): Promise<IServiceResponse<IPage<OrgaoRegulador>>> {
    sortField = sortField || 'sigla';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.orgaoReguladorApi.listaPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroSigla, options.params, 'sigla');
    options.params = this.utilityService.carregaParamsString(this.filtrodescricao, options.params, 'descricao');
    options.params = this.utilityService.carregaParamsString(this.filtrodetalhamento, options.params, 'detalhamento');
    options.params = this.utilityService.carregaParamsString(this.filtroRamo, options.params, 'ramo');
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getOrgaoReguladors(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseOrgaoRegulador => {
      this.responseOrgaoRegulador = responseOrgaoRegulador;
      this.changeDetectorRef.markForCheck();
    });
  }

  ativarOrgaoRegulador(obj: OrgaoRegulador){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      key: 'ativarOrgaoRegulador',
      accept: () => {
        this.orgaoReguladorApi.desativa(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
