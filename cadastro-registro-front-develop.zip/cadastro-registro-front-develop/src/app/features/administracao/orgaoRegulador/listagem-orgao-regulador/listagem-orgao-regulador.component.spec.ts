import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemOrgaoReguladorComponent } from './listagem-orgao-regulador.component';

describe('ListagemOrgaoReguladorComponent', () => {
  let component: ListagemOrgaoReguladorComponent;
  let fixture: ComponentFixture<ListagemOrgaoReguladorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemOrgaoReguladorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemOrgaoReguladorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
