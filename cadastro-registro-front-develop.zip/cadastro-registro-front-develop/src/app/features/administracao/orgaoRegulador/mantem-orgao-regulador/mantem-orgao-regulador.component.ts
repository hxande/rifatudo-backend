import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { OrgaoRegulador } from '@cadastro-registro-api/models/OrgaoRegulador';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { ApiOrgaoReguladorService } from '@cadastro-registro-api/services/api-orgao-regulador.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-mantem-orgao-regulador',
  templateUrl: './mantem-orgao-regulador.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-orgao-regulador.component.css']
})
export class MantemOrgaoReguladorComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  orgaoRegulador: OrgaoRegulador;
  optionsDropdownRamo: Ramo[];

  @ViewChild('orgaoReguladorForm') orgaoReguladorForm: NgForm;
  constructor(
    private orgaoReguladorApi: ApiOrgaoReguladorService,
    private ramoAPI: ApiRamoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.orgaoRegulador = new OrgaoRegulador();
    this.ramoAPI.getRamos().then(response => {
      this.optionsDropdownRamo = response.data;
      this.changeDetectorRef.markForCheck();
    });
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Órgão Regulador', routerLink: '/administracao/listagem-orgao-regulador' },
      { label: 'Cadastro de Órgão Regulador', routerLink: '/administracao/novo-orgao-regulador' }
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-orgao-regulador') {
      this.route.params.subscribe(params => {
        this.orgaoReguladorApi.get(params['id'])
          .then(res => {
            this.orgaoRegulador = res.data;
            this.changeDetectorRef.markForCheck();
          });
      });
    } else {
      this.inicializarOrgaoRegulador();
    }
  }

  inicializarOrgaoRegulador() {
    this.orgaoRegulador = new OrgaoRegulador();
    this.orgaoRegulador.ativo = true;
  }

  salvar(): void {
    if (this.orgaoReguladorForm.invalid) {
      return;
    }
    this.orgaoRegulador.excluido = false;
    if (this.orgaoRegulador.id) {
      this.orgaoReguladorApi.altera(this.orgaoRegulador);
      this.changeDetectorRef.markForCheck();
    } else {
      this.orgaoReguladorApi.inclui(this.orgaoRegulador)
        .then(() => {
          this.orgaoReguladorForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() => {
            this.inicializarOrgaoRegulador();
            this.changeDetectorRef.markForCheck();
          }, 0);
          this.changeDetectorRef.markForCheck();
        });
    }
  }

}
