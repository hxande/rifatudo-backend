import { ChangeDetectionStrategy, Component, OnInit, Input, inject, ChangeDetectorRef } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';

@Component({
  selector: 'app-aba-documento',
  templateUrl: './aba-documento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./aba-documento.component.css']
})
export class AbaDocumentoComponent implements OnInit {
  @Input() tituloTabela = 'Consulta de Documento';

  protected kcService = inject(KeycloakService);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  ngOnInit() {
  }

}
