import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Documento } from '@documentacao-api/models/Documento';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { Uf } from '@localizacao-api/models/Uf';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ConfirmationService } from 'primeng/api';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-mantem-documento',
  templateUrl: './mantem-documento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-documento.component.css']
})
export class MantemDocumentoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  documento: Documento = new Documento();
  podeModificarOsCampos = false;
  ufInvalido = false;
  abrangenciaDoc: string;
  ufSelecionada: Uf;
  ufs: Uf[] = [];

  @ViewChild('documentoForm') documentoForm: NgForm;
  constructor(
    private documentoApi: ApiDocumentoService,
    private route: ActivatedRoute,
    private ufService: ApiUFService,
    private keycloakService: KeycloakService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private confirmationService: ConfirmationService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Documento', routerLink: '/administracao/listagem-documento' },
      { label: 'Cadastro de Documento', routerLink: '/administracao/novo-documento' }
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-documento') {
      this.route.params.subscribe(params => {
        this.documentoApi.getDocumento(params['id'])
          .then(res => {
            this.documento = res.data;
            this.alternaOculta();
            this.checkAbrengenciaDoc();
            this.inicializaUF();
            this.mudaAbrangencia();
            this.changeDetectorRef.markForCheck();
          });
      });
    } else {
      this.inicializarDocumento();
    }
  }

  checkAbrengenciaDoc() {
    if (this.keycloakService.isUsuarioNacional) {
      this.abrangenciaDoc = this.documento.uf ? 'UE' : 'UN';
    } else if (this.keycloakService.isUsuarioEstadual) {
      this.abrangenciaDoc = 'UE';
    }
  }

  ocultaCampos() {
    if (this.keycloakService.isUsuarioNacional) {
      return false;
    }
    return true;
  }

  desabilitaCampos() {
    if (this.keycloakService.isUsuarioNacional && this.abrangenciaDoc === 'UE') {
      return true;
    }
    return false;
  }

  mudaAbrangencia() {
    if(this.abrangenciaDoc === 'UE') {
      this.inicializaDocUE();
    }
  }

  atribuiUf() {
    this.documento.uf = this.ufSelecionada.sigla;
  }

  inicializaDocUE() {
    this.documento.tipoPessoa = TipoPessoaEnum.PJ;
    this.documento.obrigatorioPosCadastro = false;
    this.documento.obrigatorioPreCadastro = false;
    this.documento.documentoExpira = false;
    this.documento.documentoFilial = false;
  }

  inicializaUF() {
    this.ufService.obterUfs().then(response => {
      this.ufs = response;
      if (this.documento.uf) {
        this.ufSelecionada = this.ufs.filter(uf => uf.sigla === this.documento.uf)[0];
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  naoSolicitarRegistro() {
    this.documento.obrigatorioPreCadastro = null;
  }

  inicializarDocumento() {
    this.documento.ativo = true;
    this.documento.documentoExpira = false;
    this.documento.obrigatorioPosCadastro = false;
    this.documento.obrigatorioPreCadastro = false;
    this.alternaOculta();
    this.checkAbrengenciaDoc();
    this.inicializaUF();
    this.mudaAbrangencia();
  }

  salvar(): void {
    if (this.documentoForm.invalid) {
      return;
    }

    this.documento.registroExcluido = false;

    if (this.documento.id) {
      this.confirmationService.confirm({
        message: 'Este documento pode estar sendo usado. Deseja confirmar a edição?',
        accept: () => {

          this.alternaOculta();

          this.documentoApi.updateDocumento(this.documento).then((resp => {
            this.documento = resp.data;
            this.alternaOculta();
            this.changeDetectorRef.markForCheck();
          }));
        }
      });
    } else {
      this.alternaOculta();
      this.documentoApi.createDocumento(this.documento)
        .then((resp) => {
          this.inicializarDocumento();
          this.alternaOculta();
          this.changeDetectorRef.markForCheck();

          /*
          const modulo: Modulo = new Modulo();
          modulo.quantidadeArquivos = 1;
          modulo.tamanhoLimiteArquivo = 50;
          modulo.sistema = 'CadastroRegistro';
          modulo.diretorio = '/hmlg-file-upload/cadastro-registro/documentacao/' + resp.data.id + '/';
          modulo.chave = 'CADASTRO_REGISTRO_DOCUMENTOS_' + resp.data.id;
          this.fileUploadService.createModulo(modulo);
          */

          this.documentoForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() =>
            this.inicializarDocumento(), 0);
        });
    }
  }

  alternaOculta() {
    this.documento.ocultaPreCadastro = !this.documento.ocultaPreCadastro;
    this.documento.ocultaPosCadastro = !this.documento.ocultaPosCadastro;
  }
}
