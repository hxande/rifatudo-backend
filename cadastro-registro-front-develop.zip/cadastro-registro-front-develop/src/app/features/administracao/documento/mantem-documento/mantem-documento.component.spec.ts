import { componentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { MantemDocumentoComponent } from './mantem-documento.component';

describe('MantemDocumentoComponent', () => {
  let component: MantemDocumentoComponent;
  let fixture: ComponentFixture<MantemDocumentoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemDocumentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemDocumentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
