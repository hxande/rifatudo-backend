import { Component, OnInit, ViewChild, Input, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';

import { HttpParams } from '@angular/common/http';
import { ConfirmationService, SelectItem, MessageService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { Documento } from '@documentacao-api/models/Documento';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { UtilityService } from '@utils/utility/utility.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-listagem-documento',
  templateUrl: './listagem-documento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-documento.component.css']
})
export class ListagemDocumentoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  responseDocumento: IServiceResponse<IPage<Documento>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroDescricao='';
  filtroDetalhamento='';
  filtroTipoPessoa='';
  filtroUF = '';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  tipoPessoaOpts: SelectItem[];
  @ViewChild('dt') dt: Table;
  @Input() tipo: string;

  constructor(
    private documentoApi: ApiDocumentoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private route: Router,
    private messageService: MessageService,
    public keycloakService: KeycloakService,
    private breadCrumbPrimeNGService:BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao' },
      { label: 'Consulta de Documento', routerLink: '/administracao/listagem-documento' }
    ]);

    this.tipoPessoaOpts = [
      { label: 'Pessoa jurídica', value: 'PJ' },
      { label: 'Pessoa física', value: 'PF' },
      { label: 'Pessoa jurídica / física', value: 'TD' }
    ];
   }

  ngOnInit() {
    this.cols = [

      { field: 'descricao', header: 'Descrição' },
      { field: 'detalhamentoDocumento', header: 'Detalhamento' },
      { field: 'tipoPessoa', header: 'Tipo de pessoa' },
      { field: 'posicaoTela', header: 'Posição na tela' },
      { field: 'ativo', header: 'Ativo' },
    ];

    if(this.keycloakService.isUsuarioNacional && this.tipo !== 'N') {
      this.cols.unshift({ field: 'uf', header: 'UF' });
    }
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getDocumentos(pagina = 0, sortField = 'descricao', sortOrder = 1): Promise<IServiceResponse<IPage<Documento>>> {
    sortField = sortField || 'descricao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.documentoApi.getDocumentsPage(options);
  }

  exportarTabela() {
    if (this.responseDocumento && this.responseDocumento.data) {
      const options = this.carregaOptions('0', this.responseDocumento.data.totalElements.toString(), '', 'asc');
      options.params = options.params.set('ativo', true + '');

      this.documentoApi.filtraDcoumentacaoRelatorio(options).then(response => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Documentos.xlsx');
        this.changeDetectorRef.markForCheck();
      }).catch(error => {
        if (error.status && error.status === 404) {
          this.messageService.add({ severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000 });
        } else {
          this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
        }
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não existem registros para serem exportados.', life: 100000 });
    }
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroDescricao, options.params, 'descricao');
    options.params = this.utilityService.carregaParamsString(this.filtroDetalhamento, options.params, 'detalhamentoDocumento');
    options.params = this.utilityService.carregaParamsString(this.filtroTipoPessoa, options.params, 'tipoPessoa');
    options.params = this.utilityService.carregaParamsString(this.filtroUF, options.params, 'uf');
    options.params = this.utilityService.carregaParamsString(this.filtroUF, options.params, 'uf');
    options.params = this.utilityService.carregaParamsString(this.tipo, options.params, 'tipo');

    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }

    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getDocumentos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseDocumento => {
      this.responseDocumento = responseDocumento;
      this.changeDetectorRef.markForCheck();
    });
  }

  novoDocumento() {
    if(this.keycloakService.isUsuarioNacional) {
      this.route.navigate(['administracao', 'novo-documento']);
    } else if(this.keycloakService.isUsuarioEstadual) {
      this.route.navigate(['administracao', 'novo-documento-ue']);
    }
  }

  editaDocumento(doc: Documento) {
    this.route.navigate( ['administracao', 'editar-documento', doc.id]);
  }

  desativarDocumento(obj: Documento){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      key: 'desativarDocumento',
      accept: () => {
        this.documentoApi.desativaDocumento(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();});
      }
    });
  }

}
