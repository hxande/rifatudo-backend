import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemDocumentoComponent } from './listagem-documento.component';

describe('ListagemDocumentoComponent', () => {
  let component: ListagemDocumentoComponent;
  let fixture: ComponentFixture<ListagemDocumentoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemDocumentoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemDocumentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
