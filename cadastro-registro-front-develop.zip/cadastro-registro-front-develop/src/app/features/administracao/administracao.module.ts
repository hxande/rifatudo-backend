import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {InicioAdministracaoComponent} from './inicio-administracao/inicio-administracao.component';
import {InicioAdministracaoUEComponent} from './inicio-administracao-ue/inicio-administracao-ue.component';
import {ListagemAreaContatoComponent} from './areaContato/listagem-area-contato/listagem-area-contato.component';
import { ListagemCriterioAssociacaoComponent } from './criterio-associacao/listagem-criterio-associacao/listagem-criterio-associacao.component';
import { MantemCriterioAssociacaoComponent } from './criterio-associacao/mantem-criterio-associacao/mantem-criterio-associacao.component';

import {MantemAreaContatoComponent} from './areaContato/mantem-area-contato/mantem-area-contato.component';
import {ListagemRamoComponent} from './ramo/listagem-ramo/listagem-ramo.component';
import {MantemRamoComponent} from './ramo/mantem-ramo/mantem-ramo.component';
import {ListagemOrgaoReguladorComponent} from './orgaoRegulador/listagem-orgao-regulador/listagem-orgao-regulador.component';
import { ListagemSindicatoCooperativaComponent } from './sindicato-cooperativa/listagem-sindicato-cooperativa/listagem-sindicato-cooperativa.component';
import { MantemSindicatoCooperativaComponent } from './sindicato-cooperativa/mantem-sindicato-cooperativa/mantem-sindicato-cooperativa.component';
import {MantemOrgaoReguladorComponent} from './orgaoRegulador/mantem-orgao-regulador/mantem-orgao-regulador.component';
import {ListagemSegmentoComponent} from './segmento/listagem-segmento/listagem-segmento.component';
import {MantemSegmentoComponent} from './segmento/mantem-segmento/mantem-segmento.component';
import {ListagemProdutoservicoComponent} from './produtoServico/listagem-produtoservico/listagem-produtoservico.component';
import {MantemProdutoservicoComponent} from './produtoServico/mantem-produtoservico/mantem-produtoservico.component';
import {ListagemTipoEnderecoComponent} from './tipoEndereco/listagem-tipo-endereco/listagem-tipo-endereco.component';
import {MantemTipoEnderecoComponent} from './tipoEndereco/mantem-tipo-endereco/mantem-tipo-endereco.component';
import {ListagemCargoComponent} from './cargo/listagem-cargo/listagem-cargo.component';
import {MantemCargoComponent} from './cargo/mantem-cargo/mantem-cargo.component';
import {ListagemSistemaVinculacaoComponent} from './sistemaVinculacao/listagem-sistema-vinculacao/listagem-sistema-vinculacao.component';
import {MantemSistemaVinculacaoComponent} from './sistemaVinculacao/mantem-sistema-vinculacao/mantem-sistema-vinculacao.component';
import {ListagemOrgaoComponent} from './orgao/listagem-orgao/listagem-orgao.component';
import {MantemOrgaoComponent} from './orgao/mantem-orgao/mantem-orgao.component';
import {ListagemPeriodoAtualizacaoComponent} from './periodoAtualizacao/listagem-periodo-atualizacao/listagem-periodo-atualizacao.component';
import {MantemPeriodoAtualizacaoComponent} from './periodoAtualizacao/mantem-periodo-atualizacao/mantem-periodo-atualizacao.component';
import {CertificadoUnidadeEstadualComponent} from './certificado-unidade-estadual/certificado-unidade-estadual.component';
import {ListarParametroQuadroSocialComponent} from './quadro-social/listar-parametro-quadro-social/listar-parametro-quadro-social.component';

import {ListagemComplementoAnuarioComponent} from './complemento-anuario/listagem-complemento-anuario/listagem-complemento-anuario.component';
import {MantemComplementoAnuarioComponent} from './complemento-anuario/mantem-complemento-anuario/mantem-complemento-anuario.component';
import {ListagemSolicitacaoComponent} from './solicitacao/listagem-solicitacao/listagem-solicitacao.component';
import {MantemSolicitacaoComponent} from './solicitacao/mantem-solicitacao/mantem-solicitacao.component';
import {ListagemUnidadeEstadualComponent} from './unidadeEstadual/listagem-unidade-estadual/listagem-unidade-estadual.component';
import {MantemUnidadeEstadualComponent} from './unidadeEstadual/mantem-unidade-estadual/mantem-unidade-estadual.component';
import {ListagemRegionalComponent} from './regional/listagem-regional/listagem-regional.component';
import {ListagemRegionalUEComponent} from './regional/listagem-regional-ue/listagem-regional-ue.component';
import {MantemRegionalComponent} from './regional/mantem-regional/mantem-regional.component';
import {MantemRegionalUEComponent} from './regional/mantem-regional-ue/mantem-regional-ue.component';
import {RecebeEmailComponent} from './recebeEmail/recebe-email.component';
import {ComplementoAnuarioRamoUrlComponent} from './complemento-anuario/complemento-anuario-ramo-url/complemento-anuario-ramo-url.component';
import {CertificadoRegistroUnidadeEstadualComponent} from './certificado-unidade-estadual/certificado-registro-unidade-estadual/certificado-registro-unidade-estadual.component';
import {CertificadoRegularidadeUnidadeEstadualComponent} from './certificado-unidade-estadual/certificado-regularidade-unidade-estadual/certificado-regularidade-unidade-estadual.component';
import {FileUploadComponentsModule} from '@gui/file-upload/file-upload.module';
import {AdministracaoRoutingModule} from './administracao-routing.module';
import {AbaDocumentoComponent} from './documento/aba-documento/aba-documento.component';
import {MantemDocumentoComponent} from './documento/mantem-documento/mantem-documento.component';
import {ButtonModule} from 'primeng/button';
import {CardModule} from 'primeng/card';
import {FormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {TableModule} from 'primeng/table';
import {CalendarModule} from 'primeng/calendar';
import {DropdownModule} from 'primeng/dropdown';
import {FieldsetModule} from 'primeng/fieldset';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {DialogModule} from 'primeng/dialog';
import {TooltipModule} from 'primeng/tooltip';
import {LogoCooperativaModule} from '@gui/logo-cooperativa/logo-cooperativa.module';
import {CheckboxModule} from 'primeng/checkbox';
import {InputMaskModule} from 'primeng/inputmask';
import {InputTextareaModule} from 'primeng/inputtextarea';
import {TriStateCheckboxModule} from 'primeng/tristatecheckbox';
import {ManterParametroQuadroSocialComponent} from './quadro-social/manter-parametro-quadro-social/manter-parametro-quadro-social.component';
import {TabViewModule} from 'primeng/tabview';
import {SpinnerModule} from 'primeng/spinner';
import {RadioButtonModule} from 'primeng/radiobutton';
import {InputSwitchModule} from 'primeng/inputswitch';
import {InputTextModule} from 'primeng/inputtext';
import {ListagemDocumentoComponent} from './documento/listagem-documento/listagem-documento.component';

import {PipesCustomizadosModule} from '@gui/pipe/pipes-customizados.module';
import {ModalSelecionarEntidadeModule} from '@gui/modal-selecionar-entidade/modal-selecionar-entidade.module';
import {ListagemControleEmailComponent} from './controle-envio-email/listagem-controle-email/listagem-controle-email.component';
import {MantemControleEmailComponent} from './controle-envio-email/manetem-controle-email/mantem-controle-email.component';
import {ControleAnuarioComponent} from './controle-anuario/controle-anuario.component';
import { CooperativasAtividadesComponent } from './cooperativas-atividades/cooperativas-atividades.component';
import {SharedModule} from '@shared/shared.module';
import {
  ListagemValidacaoEmLoteComponent
} from './validacao-em-lote/listagem-validacao-em-lote/listagem-validacao-em-lote.component';
import { PaginatorModule } from 'primeng/paginator';
import { ChipModule } from 'primeng/chip';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import {
  ListarParametroQuadroSocialCooperadoComponent
} from './quadro-social/listar-parametro-quadro-social-cooperado/listar-parametro-quadro-social-cooperado.component';
import {
  ManterParametroQuadroSocialCooperadoComponent
} from './quadro-social/manter-parametro-quadro-social-cooperado/manter-parametro-quadro-social-cooperado.component';
import { ListagemControleEmailEstadualComponent } from './controle-envio-email/listagem-controle-email-estadual/listagem-controle-email-estadual.component';
import { ControleAtualizacaoCadastralComponent } from './controle-atualizacao-cadastral/controle-atualizacao-cadastral.component';
import { ControlePortifolioComponent } from './controle-portifolio/controle-portifolio.component';
import { ListagemSistemaVinculacaoCooperativaComponent } from './sistema-vinculacao-cooperativa/listagem-sistema-vinculacao-cooperativa/listagem-sistema-vinculacao-cooperativa.component';



@NgModule({
  declarations: [
    InicioAdministracaoComponent,
    InicioAdministracaoUEComponent,
    ListagemAreaContatoComponent,
    ListagemCriterioAssociacaoComponent,
    ListagemValidacaoEmLoteComponent,
    MantemAreaContatoComponent,
    MantemCriterioAssociacaoComponent,
    ListagemRamoComponent,
    MantemRamoComponent,
    ListagemOrgaoReguladorComponent,
    ListagemSindicatoCooperativaComponent,
    MantemSindicatoCooperativaComponent,
    MantemOrgaoReguladorComponent,
    ListagemSegmentoComponent,
    MantemSegmentoComponent,
    ListagemProdutoservicoComponent,
    MantemProdutoservicoComponent,
    ListagemTipoEnderecoComponent,
    MantemTipoEnderecoComponent,
    ListagemCargoComponent,
    MantemCargoComponent,
    ListagemSistemaVinculacaoComponent,
    MantemSistemaVinculacaoComponent,
    ListagemOrgaoComponent,
    MantemOrgaoComponent,
    ListagemPeriodoAtualizacaoComponent,
    MantemPeriodoAtualizacaoComponent,
    CertificadoUnidadeEstadualComponent,
    ListarParametroQuadroSocialComponent,
    ListarParametroQuadroSocialCooperadoComponent,
    ListagemComplementoAnuarioComponent,
    MantemComplementoAnuarioComponent,
    ListagemSolicitacaoComponent,
    MantemSolicitacaoComponent,
    ListagemUnidadeEstadualComponent,
    MantemUnidadeEstadualComponent,
    ListagemRegionalComponent,
    ListagemRegionalUEComponent,
    MantemRegionalComponent,
    MantemRegionalUEComponent,
    RecebeEmailComponent,
    ComplementoAnuarioRamoUrlComponent,
    ManterParametroQuadroSocialComponent,
    ManterParametroQuadroSocialCooperadoComponent,
    CertificadoRegistroUnidadeEstadualComponent,
    CertificadoRegularidadeUnidadeEstadualComponent,
    AbaDocumentoComponent,
    MantemDocumentoComponent,
    ListagemDocumentoComponent,
    ListagemControleEmailComponent,
    MantemControleEmailComponent,
    ControleAnuarioComponent,
    CooperativasAtividadesComponent,
    ListagemControleEmailEstadualComponent,
    ControleAtualizacaoCadastralComponent,
    ControlePortifolioComponent,
    ListagemSistemaVinculacaoCooperativaComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    AdministracaoRoutingModule,
    ButtonModule,
    CardModule,
    TableModule,
    DropdownModule,
    FieldsetModule,
    CalendarModule,
    DialogModule,
    ConfirmDialogModule,
    TooltipModule,
    PipesCustomizadosModule,
    InputMaskModule,
    CheckboxModule,
    InputTextareaModule,
    TabViewModule,
    RadioButtonModule,
    SpinnerModule,
    TriStateCheckboxModule,
    InputTextModule,
    InputSwitchModule,
    ModalSelecionarEntidadeModule,
    LogoCooperativaModule,
    FileUploadComponentsModule,
    SharedModule,
    PaginatorModule,
    ChipModule,
    CKEditorModule
  ],
})
export class AdministracaoModule { }
