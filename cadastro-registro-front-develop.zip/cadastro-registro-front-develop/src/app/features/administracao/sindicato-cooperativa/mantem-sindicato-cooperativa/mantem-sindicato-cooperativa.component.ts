import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Uf } from '@localizacao-api/models/Uf';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { SindicatoTO } from 'src/app/api/models/SindicatoTO';
import { ApiSindicatoService } from 'src/app/api/services/api-sindicato.service';
import { MessageService } from 'primeng/api';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';

@Component({
  selector: 'app-mantem-sindicato-cooperativa',
  templateUrl: './mantem-sindicato-cooperativa.component.html',
  styleUrls: ['./mantem-sindicato-cooperativa.component.css']
})
export class MantemSindicatoCooperativaComponent implements OnInit {

  @Input()
  idSindicato: number = null;

  @Output()
  eventSalvar = new EventEmitter<void>();

  @Output()
  eventFecharModal = new EventEmitter<void>();

  @ViewChild('sindicatoForm') sindicatoForm: NgForm;

  sindicato: SindicatoTO = new SindicatoTO();
  idsRamosSelecionados: number[] = [];
  listaUfs: Uf[] = [];
  listaRamos: Ramo[] = [];
  edicao = false;
  dadosPessoaJuridicaBloqueados = false;
  salvando = false;

  constructor(
    private sindicatoApi: ApiSindicatoService,
    private ramoApi: ApiRamoService,
    private dadosGeraisApi: ApiManutencaoDadosGeraisService,
    private dadosGeraisPublicApi: ApiDadosGeraisService,
    private messageService: MessageService,
  ) { }

  ngOnInit() {
    this.dadosGeraisApi.buscarUfs().then(response => {
      this.listaUfs = response.content;
    });
    this.ramoApi.getRamos().then(response => {
      this.listaRamos = response.data;
    });
    if (this.idSindicato) {
      this.edicao = true;
      this.sindicatoApi.get(this.idSindicato).then(response => {
        this.sindicato = response.data;
        this.idsRamosSelecionados = (this.sindicato.ramos || []).map(ramo => ramo.id);
        this.dadosPessoaJuridicaBloqueados = this.sindicato.tipoPessoa !== 'O';
      });
    }
  }

  buscarPessoaJuridica() {
    if (this.edicao || !this.sindicato.cnpj || this.sindicato.cnpj.length < 14) {
      return;
    }
    this.dadosGeraisPublicApi.getPessoaJuridicaPorCnpjSincronizada(this.sindicato.cnpj)
      .then(pessoaJuridica => {
        this.sindicato.razaoSocial = pessoaJuridica.razaoSocial;
        this.sindicato.nomeFantasia = pessoaJuridica.nomeFantasia;
        this.sindicato.ufSede = pessoaJuridica.ufSigla;
        this.sindicato.tipoPessoa = pessoaJuridica.tipoPessoa;
        this.dadosPessoaJuridicaBloqueados = pessoaJuridica.tipoPessoa !== 'O';
        if (pessoaJuridica.tipoPessoa === 'E') {
          this.sindicato.ufsRepresentacao = pessoaJuridica.ufSigla ? [pessoaJuridica.ufSigla] : [];
          this.idsRamosSelecionados = this.listaRamos.map(ramo => ramo.id);
        }
      })
      .catch((err) => {
        if (err.status === 404) {
          this.messageService.clear();
          this.dadosPessoaJuridicaBloqueados = false;
        }
      });
  }

  formValido(): boolean {
    return this.sindicatoForm && this.sindicatoForm.form.valid
      && this.sindicato.ufsRepresentacao && this.sindicato.ufsRepresentacao.length > 0
      && this.idsRamosSelecionados && this.idsRamosSelecionados.length > 0;
  }

  salvar() {
    if (!this.formValido() || this.salvando) {
      return;
    }
    this.salvando = true;
    this.sindicato.ramos = this.listaRamos
      .filter(ramo => this.idsRamosSelecionados.includes(ramo.id))
      .map(ramo => ({ id: ramo.id, nome: ramo.nome }));

    const operacao = this.sindicato.id
      ? this.sindicatoApi.altera(this.sindicato)
      : this.sindicatoApi.inclui(this.sindicato);

    operacao
      .then(() => this.eventSalvar.emit())
      .finally(() => this.salvando = false);
  }

  cancelar() {
    this.eventFecharModal.emit();
  }

}
