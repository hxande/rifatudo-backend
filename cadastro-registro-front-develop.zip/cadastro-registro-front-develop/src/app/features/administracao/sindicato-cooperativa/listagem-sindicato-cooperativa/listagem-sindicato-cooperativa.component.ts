import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { UtilityService } from '@utils/utility/utility.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { SindicatoTO } from 'src/app/api/models/SindicatoTO';
import { ApiSindicatoService } from 'src/app/api/services/api-sindicato.service';

@Component({
  selector: 'app-listagem-sindicato-cooperativa',
  templateUrl: './listagem-sindicato-cooperativa.component.html',
  styleUrls: ['./listagem-sindicato-cooperativa.component.css']
})
export class ListagemSindicatoCooperativaComponent implements OnInit {

  constructor(
    private sindicatoApi: ApiSindicatoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService: BreadcrumbService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Sindicatos de Cooperativas', routerLink: '/administracao/listagem-sindicato-cooperativa' },
      { label: 'Consulta de Sindicatos de Cooperativas', routerLink: '/administracao/listagem-sindicato-cooperativa' }
    ]);
  }

  responseSindicato: IServiceResponse<IPage<SindicatoTO>>;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  filtroCnpj = '';
  filtroRazaoSocial = '';
  filtroNomeFantasia = '';
  filtroUf = '';
  filtroRamo = '';
  filtroAtivo = null;
  cols: { field: string, header: string, sort?: string }[];
  modalSindicato = false;
  idSindicatoSelecionado: number = null;
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'cnpj', header: 'CNPJ', sort: 'pessoaJuridica.cnpj' },
      { field: 'razaoSocial', header: 'Denominação / Razão Social', sort: 'pessoaJuridica.razaoSocial' },
      { field: 'nomeFantasia', header: 'Nome Fantasia', sort: 'pessoaJuridica.nomeFantasia' },
      { field: 'ufSede', header: 'UF', sort: 'pessoaJuridica.ufSigla' },
      { field: 'ramos', header: 'Ramos' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getSindicatos(pagina = 0, sortField = 'pessoaJuridica.razaoSocial', sortOrder = 1): Promise<IServiceResponse<IPage<SindicatoTO>>> {
    sortField = sortField || 'pessoaJuridica.razaoSocial';
    const sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.sindicatoApi.listaPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    const cnpjSemFormatacao = (this.filtroCnpj || '').replace(/[.\-/]/g, '');
    options.params = this.utilityService.carregaParamsString(cnpjSemFormatacao, options.params, 'cnpj');
    options.params = this.utilityService.carregaParamsString(this.filtroRazaoSocial, options.params, 'razaoSocial');
    options.params = this.utilityService.carregaParamsString(this.filtroNomeFantasia, options.params, 'nomeFantasia');
    options.params = this.utilityService.carregaParamsString(this.filtroUf, options.params, 'uf');
    options.params = this.utilityService.carregaParamsString(this.filtroRamo, options.params, 'ramo');
    if (this.filtroAtivo != null) {
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;
  }

  loadLazy(event: any) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getSindicatos(event.first / event.rows, event.sortField, event.sortOrder).then(responseSindicato => {
      this.responseSindicato = responseSindicato;
    });
  }

  nomesRamos(obj: SindicatoTO): string {
    return (obj.ramos || []).map(ramo => ramo.nome).join(', ');
  }

  novoSindicato() {
    this.idSindicatoSelecionado = null;
    this.modalSindicato = true;
  }

  editarSindicato(obj: SindicatoTO) {
    this.idSindicatoSelecionado = obj.id;
    this.modalSindicato = true;
  }

  fecharModal(atualizar: boolean) {
    this.modalSindicato = false;
    this.idSindicatoSelecionado = null;
    if (atualizar) {
      this.dt.reset();
    }
  }

  ativarSindicato(obj: SindicatoTO) {
    const mensagem = obj.ativo
      ? 'Deseja desativar o registro? As cooperativas filiadas a este sindicato serão desfiliadas.'
      : 'Deseja ativar o registro?';
    this.confirmationService.confirm({
      message: mensagem,
      key: 'ativarSindicato',
      accept: () => {
        this.sindicatoApi.desativa(obj.id, (obj.ativo ? false : true))
          .then(() => this.dt.reset());
      }
    });
  }

}
