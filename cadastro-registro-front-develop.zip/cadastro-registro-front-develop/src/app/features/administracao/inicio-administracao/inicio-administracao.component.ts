import {ChangeDetectionStrategy, Component, OnInit} from '@angular/core';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import {SubPerfisEnum} from '@auth/keycloak-service/sub-perfis.enum';
import {BreadcrumbService} from '@core/breadcrumb/breadcrumb.service';
import {Router} from '@angular/router';

interface LinkItem {
  label: string;
  routerLink: string[];
  icon: string;
  canShow?: boolean;
}

@Component({
  selector: 'app-inicio-administracao',
  templateUrl: './inicio-administracao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./inicio-administracao.component.css'],
})
export class InicioAdministracaoComponent implements OnInit {
  itemsLinksCoop: LinkItem[];
  itemsLinksUE: LinkItem[];
  itemsLinksSis: LinkItem[];

  constructor(public keycloakService: KeycloakService,
              private breadCrumbPrimeNGService: BreadcrumbService,
              private router: Router) {

    this.breadCrumbPrimeNGService.setItems([
      {label: 'Início', routerLink: '/inicio'},
      {label: 'Administração', routerLink: '/administracao/inicio'},
    ]);
  }

  ngOnInit() {
    if (this.keycloakService.isUsuarioEstadual) {
      this.router.navigate(['/administracao/inicio-ue']);
    }
    this.carregarTela();
  }

  carregarTela() {
    this.itemsLinksCoop = [
      {label: 'Documento', routerLink: ['../listagem-documento'], icon: 'fas fa-file'},
      {label: 'Ramo', routerLink: ['../listagem-ramo'], icon: 'fas fa-briefcase'},
      {label: 'Segmento', routerLink: ['../listagem-segmento'], icon: 'fas fa-table'},
      {label: 'Produto e Serviço', routerLink: ['../listagem-produto-servico'], icon: 'fas fa-funnel-dollar'},
      {label: 'Órgão', routerLink: ['../listagem-orgao'], icon: 'fas fa-users'},
      {label: 'Cargo', routerLink: ['../listagem-cargo'], icon: 'fas fa-user-tag'},
      {label: 'Tipo de Endereço', routerLink: ['../listagem-tipoEndereco'], icon: 'fas fa-map-marker-alt'},
      {label: 'Área de Contato', routerLink: ['../listagem-area-contato'], icon: 'fas fa-list-ul'},
      {label: 'Critério de Associação', routerLink: ['../listagem-criterio-associacao'], icon: 'fas fa-list-ul'},
    ];

    this.itemsLinksUE = [
      {label: 'Cadastro de Organização Estadual', routerLink: ['../listagem-unidade-estadual'], icon: 'fas fa-archway'},
      {
        label: 'Certificado Organização Estadual',
        routerLink: ['../certificado-unidade-estadual'],
        icon: 'fas fa-graduation-cap'
      },
      {label: 'Período de Atualização', routerLink: ['../listagem-periodo-atualizacao'], icon: 'fas fa-hourglass-half'},
      {
        label: 'Dados Complementares do Anuário',
        routerLink: ['../listagem-complemento-anuario'],
        icon: 'fas fa-book',
        canShow: this.canShowDadosComplementaresAnuario(),
      },

      {label: 'Controle de envio de e-mails para as cooperativas', routerLink: ['../listagem-controle-email-estadual'], icon: 'fas fa-envelope'},
      {label: 'Anuário', routerLink: ['../controle-anuario-uf'], icon: 'fas fa-bookmark'},
      {label: 'Atualização Cadastral', routerLink: ['../controle-atualizacao-cadastral'], icon: 'fas fa-bookmark'},
      {label: 'Participação em atividades', routerLink: ['../participacao-cooperativas-atividades'], icon: 'fas fa-list-alt'}
    ];

    this.itemsLinksSis = [
      {label: 'Órgão Regulador', routerLink: ['../listagem-orgao-regulador'], icon: 'fas fa-building'},
      {label: 'Sistema de Cooperativas', routerLink: ['../listagem-sistema-vinculacao'], icon: 'fas fa-sitemap'},
      {label: 'Sindicatos de Cooperativas', routerLink: ['../listagem-sindicato-cooperativa'], icon: 'fas fa-users'},

      {
        label: 'Motivos de suspensão e cancelamento',
        routerLink: ['../listagem-solicitacao'],
        icon: 'fas fa-ticket-alt'
      },
      {label: 'Aprovação de envio de e-mail', routerLink: ['../recebe-email'], icon: 'fas fa-at'},
      {label: 'Empregado - Parâmetro Quadro Social', routerLink: ['../parametro-quadro-social'], icon: 'fas fa-cog'},
      {label: 'Cooperado - Parâmetro Quadro Social', routerLink: ['../parametro-quadro-social-cooperado'], icon: 'fas fa-cog'},

      {label: 'Controle de envio de e-mail', routerLink: ['../listagem-controle-email'], icon: 'fas fa-envelope'},
      {label: 'Controle do Portifólio', routerLink: ['../controle-portifolio'], icon: 'fas fa-list-alt'}
    ];
  }

  private canShowDadosComplementaresAnuario() {
    return this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES);
  }
}
