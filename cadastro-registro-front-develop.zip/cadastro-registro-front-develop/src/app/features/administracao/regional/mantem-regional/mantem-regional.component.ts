import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { Municipio } from '@localizacao-api/models/Municipio';
import { Pais } from '@localizacao-api/models/Pais';
import { Regiao } from '@localizacao-api/models/Regiao';
import { Regional } from '@localizacao-api/models/Regional';
import { RegionalTO } from '@localizacao-api/models/RegionalTO';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { ApiRegionalService } from '@localizacao-api/services/api-regional.service';
import { TableLazyLoadEvent } from 'primeng/table';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiUFService } from '@localizacao-api/public-api';

@Component({
  selector: 'app-mantem-regional',
  templateUrl: './mantem-regional.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-regional.component.css']
})
export class MantemRegionalComponent implements OnInit {

  private changeDetectorRf = inject(ChangeDetectorRef);

  regionalTO: RegionalTO;
  municipio: Municipio;
  optionsDropdownUf: Uf[];
  optionsDropdownMunicipios: Municipio[];
  municipiosExcluidos: Municipio[];
  municipioPreenchido = false;

  @ViewChild('regionalForm') regionalForm: NgForm;
  constructor(
    private apiRegional: ApiRegionalService,
    private apiUF: ApiUFService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiDadosGerais: ApiDadosGeraisService,
  ) {
    this.regionalTO = new RegionalTO();
    this.regionalTO.municipios = new Array<Municipio>();
    this.regionalTO.regional = new Regional();
    this.regionalTO.regional.uf = new Uf();
    this.municipio = new Municipio();
    this.municipio.pais = new Pais();
    this.municipio.regiao = new Regiao();

    this.apiUF.buscarUfs().then((response) => {
      this.optionsDropdownUf = (response as unknown as IPage<Uf>).content;
      this.changeDetectorRf.markForCheck();
    });
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/administracao/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Regional', routerLink: '/administracao/listagem-regional' },
      { label: 'Cadastro de Regional', routerLink: '/administracao/novo-regional' }
    ]);
  }


  ngOnInit() {
    this.inicializar();
    if (this.route.snapshot.url[0]?.path === 'editar-regional') {
      this.route.params.subscribe(params => {
        this.apiRegional.getRegional(params['id'])
          .then(res => {
            this.regionalTO.regional = res;
            this.inicializaMunicipios();
            this.listaDropdownMunicipios();
          });
      });
    }
  }

  inicializar() {
    this.regionalTO = new  RegionalTO;
    this.regionalTO.regional = new Regional();
    this.regionalTO.regional.uf = new Uf();
    this.regionalTO.municipios = new Array<Municipio>();
    this.municipiosExcluidos = new Array<Municipio>();
  }

  salvar(): void {
    if (this.regionalForm.invalid) {
      return;
    }
    if (this.regionalTO.regional.id) {
      this.apiRegional.altera(this.regionalTO).then(() => {
        this.salvarMunicipios(this.regionalTO.regional);
        this.changeDetectorRf.markForCheck();
      });
    } else {
      this.apiRegional.inclui(this.regionalTO)
        .then((res) => {
          this.regionalTO = res.data;
          this.salvarMunicipios(this.regionalTO.regional);
          setTimeout(() =>{
            this.inicializar();
          }, 0);
          this.changeDetectorRf.markForCheck();
        });
    }
  }

  salvarMunicipios(r: Regional) {
    /*for(const m of this.regionalTO.municipios) {
      this.apiRegional.alteraMunicipioRegional(m.id, r.id);
    }*/
    for(const m of this.municipiosExcluidos) {
      this.apiRegional.removeMunicipioRegional(m.id);
    }
  }

  inicializaMunicipios() {
    this.apiRegional.buscaMunicipiosPorRegional(this.regionalTO.regional.id).then(response => {
      this.regionalTO.municipios = response;
      this.changeDetectorRf.markForCheck();
    });
  }

  listaDropdownMunicipios() {
    if(this.regionalTO.regional.uf){
      this.apiDadosGerais.buscarMunicipiosByIdUf(this.regionalTO.regional.uf.id).then(response =>{
        this.optionsDropdownMunicipios = response.content;
        this.changeDetectorRf.markForCheck();
      });
    }
  }

  loadLazy(event: TableLazyLoadEvent) {

  }

  adicionarMunicipio() {
    if(this.municipio) {

      this.municipio.regional = this.regionalTO.regional;
      this.regionalTO.municipios = [
        ...this.regionalTO.municipios,
        this.municipio
      ];
    }
  }

  liberaMunicipio(){
    if(this.municipio){
      this.municipioPreenchido = true;
    }
  }

  removerMunicipio(m: Municipio) {
    if(m.id){
      this.municipiosExcluidos = [
        ...this.municipiosExcluidos,
        { ...m, regional: undefined }
      ];

    }
    this.regionalTO.municipios = this.regionalTO.municipios.filter(mun => mun.id !== m.id);
  }

  isValido():boolean {
    if(this.regionalForm?.form?.invalid) {
      return false;
    }
    if(this.regionalTO.municipios.length === 0) {
      return false;
    }
    return true;
  }
}
