import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Municipio } from '@localizacao-api/models/Municipio';
import { Pais } from '@localizacao-api/models/Pais';
import { Regiao } from '@localizacao-api/models/Regiao';
import { Regional } from '@localizacao-api/models/Regional';
import { RegionalTO } from '@localizacao-api/models/RegionalTO';
import { Uf } from '@localizacao-api/models/Uf';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ApiRegionalService } from '@localizacao-api/services/api-regional.service';
import { TableLazyLoadEvent } from 'primeng/table';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-mantem-regional-ue',
  templateUrl: './mantem-regional-ue.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-regional-ue.component.css']
})
export class MantemRegionalUEComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  regionalTO: RegionalTO;
  municipio: Municipio;
  optionsDropdownUf: Uf[];
  optionsDropdownMunicipios: Municipio[];
  municipiosExcluidos: Municipio[];
  municipioPreenchido = false;

  @ViewChild('regionalForm') regionalForm: NgForm;
  constructor(
    private apiRegional: ApiRegionalService,
    private apiUf: ApiUFService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiDadosGerais: ApiDadosGeraisService,
    private keycloakService: KeycloakService,
  ) {
    this.regionalTO = new RegionalTO();
    this.regionalTO.municipios = new Array<Municipio>();
    this.regionalTO.regional = new Regional();
    this.regionalTO.regional.uf = new Uf();
    this.municipio = new Municipio();
    this.municipio.pais = new Pais();
    this.municipio.regiao = new Regiao();

    this.apiUf.buscarUfPelaSigla(this.keycloakService.getUF())
    .then(response => {
      this.optionsDropdownUf = new Array<Uf>(response);
      this.changeDetectorRef.markForCheck();
    });
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio-ue' },
      { label: 'Regional', routerLink: '/administracao/listagem-regional-ue' },
      { label: 'Cadastro de Regional', routerLink: '/administracao/novo-regional-ue' }
    ]);
  }


  ngOnInit() {
    this.inicializar();
    if (this.route.snapshot.url[0]?.path === 'editar-regional-ue') {
      this.route.params.subscribe(params => {
        this.apiRegional.getRegional(params['id'])
          .then(res => {
            this.regionalTO.regional = res;
            this.inicializaMunicipios();
            this.listaDropdownMunicipios();
            this.changeDetectorRef.markForCheck();
          });
      });
    }
  }

  inicializar() {
    this.regionalTO = new  RegionalTO;
    this.regionalTO.regional = new Regional();
    this.regionalTO.regional.uf = new Uf();
    this.regionalTO.municipios = new Array<Municipio>();
    this.municipiosExcluidos = new Array<Municipio>();
  }

  salvar(): void {
    if (this.regionalForm.invalid) {
      return;
    }
    if (this.regionalTO.regional.id) {
      this.apiRegional.altera(this.regionalTO).then(() => {
        this.salvarMunicipios(this.regionalTO.regional);
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.apiRegional.inclui(this.regionalTO)
        .then((res) => {
          this.regionalTO = res.data;
          this.salvarMunicipios(this.regionalTO.regional);
          setTimeout(() =>{
            this.inicializar();
            this.changeDetectorRef.markForCheck();
          }, 0);
        });
    }
  }

  salvarMunicipios(r: Regional) {
    /*for(const m of this.regionalTO.municipios) {
      this.apiRegional.alteraMunicipioRegional(m.id, r.id);
    }*/
    for(const m of this.municipiosExcluidos) {
      this.apiRegional.removeMunicipioRegional(m.id);
    }
  }

  inicializaMunicipios() {
    this.apiRegional.buscaMunicipiosPorRegional(this.regionalTO.regional.id)
    .then(response => {
      this.regionalTO.municipios = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  listaDropdownMunicipios() {
    if(this.regionalTO.regional.uf){
      this.apiDadosGerais.buscarMunicipiosByIdUf(this.regionalTO.regional.uf.id)
      .then(response =>{
        this.optionsDropdownMunicipios = response.content;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  loadLazy(event: TableLazyLoadEvent) {

  }

  adicionarMunicipio() {
    if(this.municipio) {

      const municipioSelecionado = {
        ...this.municipio,
        regional: this.regionalTO.regional
      };

      this.regionalTO.municipios = [
        ...this.regionalTO.municipios,
        municipioSelecionado
      ];
    }
  }

  liberaMunicipio(){
    if(this.municipio){
      this.municipioPreenchido = true;
    }
  }

  removerMunicipio(m: Municipio) {
    if(m.id){
      m.regional = null;
      this.municipiosExcluidos = [
        ...this.municipiosExcluidos,
        m
      ];
    }
    for(let i=0; i<this.regionalTO.municipios.length; i++) {
      if(this.regionalTO.municipios[i].id === m.id) {
        this.regionalTO.municipios = this.regionalTO.municipios
        .filter((_, index) => index !== i);
      }
    }
  }

  isValido():boolean {
    if(this.regionalForm.form.invalid) {
      return false;
    }
    if(this.regionalTO.municipios.length === 0) {
      return false;
    }
    return true;
  }
}
