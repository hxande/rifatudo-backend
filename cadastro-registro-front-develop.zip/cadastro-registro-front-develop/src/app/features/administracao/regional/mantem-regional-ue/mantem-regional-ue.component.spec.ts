import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemRegionalComponent } from './mantem-regional-ue.component';

describe('MantemRegionalComponent', () => {
  let component: MantemRegionalComponent;
  let fixture: ComponentFixture<MantemRegionalComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemRegionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemRegionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
