import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiRegionalService } from '@localizacao-api/services/api-regional.service';
import { Regional } from '@localizacao-api/models/Regional';
import { IPage } from '@utils/interfaces/IPage';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-listagem-regional',
  templateUrl: './listagem-regional.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-regional.component.css']
})
export class ListagemRegionalComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiRegional: ApiRegionalService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Regionais', routerLink: '/administracao/listagem-regional' },
      { label: 'Consulta de Regional', routerLink: '/administracao/listagem-regional' }
    ]);
   }

   response: IServiceResponse<IPage<Regional>>;
   nrLinhasTabela = 10 ;
   private debouncer;
   private delay = 500;
   filtroNome='';
   filtroUf='';
   cols: { field: string, header: string }[];
   @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'nome', header: 'Nome' },
      { field: 'uf', header: 'UF' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    options.params = this.utilityService.carregaParamsString(this.filtroUf, options.params, 'uf');
    return options;

  }

  getRegional(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<Regional>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.apiRegional.listaPaginado(options);
  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getRegional(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(response => {
      this.response = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  excluir(obj: Regional){
    this.confirmationService.confirm({
      message: 'Deseja excluir o registro?',
      key: 'excluirRegional',
      accept: () => {
        this.apiRegional.delete(obj.id)
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }
}
