import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { ApiUFService } from '@localizacao-api/public-api';
import { ControlePortifolioTO } from 'src/app/api/models/ControlePortifolioTO';
import { ApiControlePortifolioService } from 'src/app/api/services/api-controle-portifolio.service';

@Component({
  selector: 'app-controle-portifolio',
  templateUrl: './controle-portifolio.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./controle-portifolio.component.css']
})
export class ControlePortifolioComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @ViewChild('controlePortifolioForm') controlePortifolioForm: NgForm;


  habilitaSelecaoUf: boolean;
  habilitaControleNacional: boolean;
  controlePortifolioUfNacional: ControlePortifolioTO;
  controlePortifolio: ControlePortifolioTO;

  uf: Uf;
  listaUfs: Uf[] = [];

  constructor(private keycloakService: KeycloakService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiUFService: ApiUFService,
    private apiControlePortifolioService: ApiControlePortifolioService,
     private router: Router
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Controle do Portifólio', routerLink: '/administracao/controle-portifolio' },
    ]);
    this.habilitaSelecaoUf = this.keycloakService.isUsuarioNacional;
  }

  ngOnInit(): void {
    this.controlePortifolioUfNacional = new ControlePortifolioTO();
    this.controlePortifolio = new ControlePortifolioTO();
    this.carregarUfs();
    this.carregaControleNacional();
  }

  voltar() {
    this.router.navigate(['/administracao']);
  }

  salvar() {
    this.apiControlePortifolioService.salvarControlePortifolioUf(this.controlePortifolio)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.ngOnInit();
      this.changeDetectorRef.markForCheck();
    });
  }

  habilitarControleNacional(){
    this.apiControlePortifolioService.habilitaControlePortifolioNacional(this.habilitaControleNacional)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.ngOnInit();
      this.changeDetectorRef.markForCheck();
    });
  }

  buscarPorUf() {
    const ufSigla = this.uf ? this.uf.sigla : null;
    if(ufSigla){
      this.apiControlePortifolioService.getControlePortifolioUf(ufSigla)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(response => {
        if (response && response.data) {
          this.controlePortifolio = response.data;
        }
        this.changeDetectorRef.markForCheck();
      });
    }

  }

  desabilitarControlePortifolio() {
    this.controlePortifolioUfNacional.uf = null;
    this.apiControlePortifolioService.salvarControlePortifolioUf(this.controlePortifolioUfNacional)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.ngOnInit();
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarUfs() {
    this.apiUFService.buscarUfs().then((response) => {
      this.listaUfs = (response as unknown as IPage<Uf>).content;
      if (!this.habilitaSelecaoUf) {
        this.uf = this.listaUfs.find(uf => uf.sigla == this.keycloakService.getUF());

      }
      this.buscarPorUf();
      this.changeDetectorRef.markForCheck();
    });
  }

  carregaControleNacional() {
    this.apiControlePortifolioService.obterControlePortifolioUfNacional()
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if(response.data){
        this.controlePortifolioUfNacional = response.data;
        this.habilitaControleNacional = this.controlePortifolioUfNacional.informarCampos;
      }
      if(this.controlePortifolioUfNacional.informarCampos){
        this.controlePortifolioForm.form.disable();
      } else {
        this.controlePortifolioForm.form.enable();
      }
      this.changeDetectorRef.markForCheck();
    });
  }
}
