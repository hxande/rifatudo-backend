import {ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {ApiOrgaoReguladorService} from '@cadastro-registro-api/services/api-orgao-regulador.service';
import {ApiRamoService} from '@cadastro-registro-api/services/api-ramo.service';
import {BreadcrumbService} from '@core/breadcrumb/breadcrumb.service';
import {ApiControleDisparoEmailService} from '@cadastro-registro-api/services/api-controle-disparo-email.service';
import {ControleDisparoEmail} from '@cadastro-registro-api/models/ControleDisparoEmail';
import { firstValueFrom } from 'rxjs';
import DecoupledEditor from '@ckeditor/ckeditor5-build-decoupled-document';
import { EditorConfig } from '@ckeditor/ckeditor5-core';
import { TipoProcessoEmail } from '@cadastro-registro-api/models/TipoProcessoEmail';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-editar-controle-email',
  templateUrl: './mantem-controle-email.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-controle-email.component.css']
})
export class MantemControleEmailComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  tiposProcessos: TipoProcessoEmail[];

  controleDisparoEmail: ControleDisparoEmail;
  public config ;

  public editor = DecoupledEditor;

  @ViewChild('controleDisparoEmailForm') controleDisparoEmailForm: NgForm;
  constructor(
    private orgaoReguladorApi: ApiOrgaoReguladorService,
    private ramoAPI: ApiRamoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private controleDisparoEmailService: ApiControleDisparoEmailService,
    private router: Router

  ) {
    this.controleDisparoEmail = new ControleDisparoEmail();
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Controle Disparo E-mail /', routerLink: '/administracao/listagem-controle-email' },
      { label: 'Editar Disparo E-mail', routerLink: '/administracao/mantem-controle-email' }
    ]);
  }

  public onReady( editor: DecoupledEditor ): void {
    const element = editor.ui.getEditableElement()!;
    const parent = element.parentElement!;
    parent.insertBefore(
      editor.ui.view.toolbar.element!,
      element
    );
  }

  ngOnInit() {
    this.carregaTiposProcessoEmail();
    if (this.route.snapshot.url[0]?.path === 'editar-controle-email') {
      this.route.params
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        firstValueFrom(this.controleDisparoEmailService.get(params['id'])).then(res => {
          this.controleDisparoEmail = res.data;
          this.changeDetectorRef.markForCheck();
        });
      });
    }

    this.config={
      toolbar: {
        items: [
            'undo', 'redo',
            '|', 'bold', 'italic', 'underline', 'strikethrough',
            '|', 'link',
            '|', 'bulletedList', 'numberedList', 'outdent', 'indent',
            '|', 'alignment:left', 'alignment:right', 'alignment:center', 'alignment:justify'
        ],
        shouldNotGroupWhenFull: false
    }
    } as EditorConfig;
  }
  carregaTiposProcessoEmail() {
    this.controleDisparoEmailService.getTiposProcessos()
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.tiposProcessos = response.data;
      this.changeDetectorRef.markForCheck();
    })
  }

  salvar(): void {
    if (this.controleDisparoEmailForm.invalid) {
      return;
    }

    if (this.controleDisparoEmail.id) {
      this.controleDisparoEmailService.update(this.controleDisparoEmail)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe((() => {
        this.router.navigate(['/administracao/listagem-controle-email']);
        this.changeDetectorRef.markForCheck();
      }));
    }
  }
}
