import {ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild} from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import {Table} from 'primeng/table';
import {UtilityService} from '@utils/utility/utility.service';
import {IPage} from '@utils/interfaces/IPage';
import { ControleDisparoEmail } from "@cadastro-registro-api/models/ControleDisparoEmail";
import {ApiControleDisparoEmailService} from '@cadastro-registro-api/services/api-controle-disparo-email.service';
import {BreadcrumbService} from '@core/breadcrumb/breadcrumb.service';
import {IServiceResponse} from '@utils/interfaces/IServiceResponse';
import {Observable, firstValueFrom} from 'rxjs';

@Component({
  selector: 'app-listagem-controle-email',
  templateUrl: './listagem-controle-email.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-controle-email.component.css']
})
export class ListagemControleEmailComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService,
    private controleDisparoEmailService: ApiControleDisparoEmailService,

  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Controle de disparo de e-mail', routerLink: '/administracao/controle-disparo-email' },
      // { label: 'Consulta de disparos de email', routerLink: '/administracao/controle-disparo-email' }
    ]);
  }

  responseDisparoEmail: IServiceResponse<IPage<ControleDisparoEmail>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroId='';
  filtroDisparoEmail='';
  filtrodetalhamento='';
  filtroTipoPessoa='';
  filtroRamo='';
  filtroAtivo = null;
  filtroTextoDescricaoEmail='';
  filtroTipoProcesso = '';
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;


  ngOnInit() {
    this.cols = [
      { field: 'id', header: 'Id' },
      { field: 'pe.descricao', header: 'Processo' },
      { field: 'chaveEmail', header: 'Chave' },
      { field: 'textoDescricaoEmail', header: 'Descrição' },
      { field: 'textoEmail', header: 'Texto de e-mail' },
      { field: 'destinatarioEmail', header: 'Destinatário' },
      { field: 'ativo', header: 'Ativo' }

    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, 500);
  }

  getDisparosEmail(pagina = 0, sortField = 'id', sortOrder = 1): Observable<IServiceResponse<IPage<ControleDisparoEmail>>> {
    sortField = sortField || 'id';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.controleDisparoEmailService.getAll(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroId, options.params, 'id');
    options.params = this.utilityService.carregaParamsString(this.filtroDisparoEmail, options.params, 'disparoEmail');
    options.params = this.utilityService.carregaParamsString(this.filtroAtivo, options.params, 'ativo');
    options.params = this.utilityService.carregaParamsString(this.filtroTextoDescricaoEmail, options.params, 'textoDescricaoEmail');
    options.params = this.utilityService.carregaParamsString(this.filtroTipoPessoa, options.params, 'tipoPessoaEmail');
    options.params = this.utilityService.carregaParamsString(this.filtroTipoProcesso, options.params, 'tipoProcessoEmail');
    if (this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
      firstValueFrom(
        this.getDisparosEmail(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
      ).then(responseDisparoEmail => {
        this.responseDisparoEmail = responseDisparoEmail;
        this.changeDetectorRef.markForCheck();
      });
  }

  ativarDisparoEmail(obj: ControleDisparoEmail){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      key: 'ativarDisparoEmail',
      accept: () => {
        obj.ativo = !obj.ativo;
        firstValueFrom(this.controleDisparoEmailService.update(obj)).then(() => {
          this.dt.reset();
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

}
