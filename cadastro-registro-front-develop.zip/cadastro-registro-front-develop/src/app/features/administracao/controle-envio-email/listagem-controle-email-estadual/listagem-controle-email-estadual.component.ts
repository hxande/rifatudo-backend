import { HttpParams } from '@angular/common/http';
import { Component, DestroyRef, inject, OnInit, ViewChild, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { UtilityService } from '@utils/utility/utility.service';
import { ConfirmationService, SelectItem } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { ControleDisparoEmailEstadualTO } from 'src/app/api/models/ControleDisparoEmailEstadualTO';
import { ControleDisparoEmailEstadualService } from 'src/app/api/services/api-controle-disparo-email-estadual.service';

@Component({
  selector: 'app-listagem-controle-email-estadual',
  templateUrl: './listagem-controle-email-estadual.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-controle-email-estadual.component.css']
})
export class ListagemControleEmailEstadualComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @ViewChild('dt') dt: Table;
  cols: { field: string, header: string }[];

  listaUf: SelectItem[] = [];

  responseDisparoEmail: IServiceResponse<IPage<ControleDisparoEmailEstadualTO>>;
  nrLinhasTabela = 10;
  private debouncer;

  ultimoEventLoad: TableLazyLoadEvent;

  filtroUfs: string[];
  filtroTextoDescricaoEmail: string;
  filtroTipoProcesso: string;

  constructor(private breadCrumbPrimeNGService: BreadcrumbService,
    private apiControleDisparoEmailEstadual: ControleDisparoEmailEstadualService,
    private utilityService: UtilityService,
    private apiManutencaoDadosGeraisService: ApiManutencaoDadosGeraisService,
    public keycloakService: KeycloakService,
    private confirmationService: ConfirmationService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Controle de envio de e-mail para cooperativas', routerLink: '/administracao/controle-disparo-email-estadual' },
    ]);
  }

  ngOnInit(): void {
    this.carregarListaUf();
    if (this.keycloakService.isUsuarioEstadual) {
      this.cols = [
        { field: 'tpe.descricao', header: 'Processo' },
        { field: 'disparoEmail.textoDescricaoEmail', header: 'Descrição' },
        { field: 'disparoEmail.textoVariavelEmail', header: 'Texto de e-mail' },
        { field: 'envia', header: 'Habilitar/Desabilitar' }

      ];
    } else {
      this.cols = [
        { field: 'uf', header: 'UF' },
        { field: 'tpe.descricao', header: 'Processo' },
        { field: 'disparoEmail.textoDescricaoEmail', header: 'Descrição' },
        { field: 'disparoEmail.textoVariavelEmail', header: 'Texto de e-mail' },
        { field: 'envia', header: 'Habilitar/Desabilitar' }

      ];
    }
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, 500);
  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event != null){
      this.ultimoEventLoad = event;
    } else {
      event = this.ultimoEventLoad;
    }

    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getDisparoEmailEstadual(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.responseDisparoEmail = response;
      this.changeDetectorRef.markForCheck();
    })
  }

  getDisparoEmailEstadual(pagina = 0, sortField = 'uf', sortOrder = 1){
    sortField = sortField || 'uf';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.apiControleDisparoEmailEstadual.obterControleDisparoEmailEstadual(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroUfs, options.params, 'ufs');
    options.params = this.utilityService.carregaParamsString(this.filtroTextoDescricaoEmail, options.params, 'emailDescricao');
    options.params = this.utilityService.carregaParamsString(this.filtroTipoProcesso, options.params, 'tipoProcesso');
    return options;
  }

  carregarListaUf() {
    this.apiManutencaoDadosGeraisService.buscarUfs().then((res) => {
        if (res && res.content != null) {
            this.listaUf = res.content.map(uf => ({ label: uf.sigla, value: uf.sigla }));

            if (this.keycloakService.isUsuarioEstadual) {
                this.filtroUfs = [this.keycloakService.getUF()];
            }
        }
        this.loadLazy(this.dt.createLazyLoadMetadata());
        this.changeDetectorRef.markForCheck();
    });
  }

  atualizarDisparoEmail(disparoEmail: ControleDisparoEmailEstadualTO){
    let ativo = disparoEmail.ativo;

    this.confirmationService.confirm({
      message: 'Deseja '+(disparoEmail.ativo ? 'ativar' : 'desativar')+' o registro?',
      key: 'ativarDisparoEmailEstadual',
      accept: () => {
        this.apiControleDisparoEmailEstadual.atualizatControleDisparoEmailEstadual(disparoEmail)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(response => {
          this.changeDetectorRef.markForCheck();
        });
      },
      reject: () => {
        this.responseDisparoEmail = {
          ...this.responseDisparoEmail,
          data: {
            ...this.responseDisparoEmail.data,
            content: this.responseDisparoEmail.data.content.map(d =>
              d === disparoEmail ? { ...d, ativo: !ativo } : d
            )
          }
        };
        this.changeDetectorRef.markForCheck();
      }

    });
  }
}
