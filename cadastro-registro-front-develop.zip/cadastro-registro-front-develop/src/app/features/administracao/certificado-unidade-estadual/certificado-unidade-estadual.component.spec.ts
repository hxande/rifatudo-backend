import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificadoUnidadeEstadualComponent } from './certificado-unidade-estadual.component';

describe('CertificadoUnidadeEstadualComponent', () => {
  let component: CertificadoUnidadeEstadualComponent;
  let fixture: ComponentFixture<CertificadoUnidadeEstadualComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificadoUnidadeEstadualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificadoUnidadeEstadualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
