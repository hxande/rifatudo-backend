import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificadoRegularidadeUnidadeEstadualComponent } from './certificado-regularidade-unidade-estadual.component';

describe('CertificadoRegularidadeUnidadeEstadualComponent', () => {
  let component: CertificadoRegularidadeUnidadeEstadualComponent;
  let fixture: ComponentFixture<CertificadoRegularidadeUnidadeEstadualComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificadoRegularidadeUnidadeEstadualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificadoRegularidadeUnidadeEstadualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
