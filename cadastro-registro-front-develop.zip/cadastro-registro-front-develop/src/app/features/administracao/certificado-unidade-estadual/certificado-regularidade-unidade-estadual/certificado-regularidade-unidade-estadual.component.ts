import { Component, OnInit, Input, ViewChild, ChangeDetectorRef, DestroyRef, NgZone, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgForm } from '@angular/forms';
import { saveAs } from 'file-saver';

import { ApiUFService } from '@localizacao-api/services/api-uf.service';

import { Uf } from '@localizacao-api/models/Uf';

import { Repositorio } from '@upload-api/models/Repositorio';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiCertificadoRegularidadeUnidadeEstadualService } from 'src/app/api/services/api-certificado-regularidade-unidade-estadual.service';

import { CertificadoRegularidadeUnidadeEstadual } from 'src/app/api/models/CertificadoRegularidadeUnidadeEstadual';
import { CertificadoUnidadeEstadual } from 'src/app/api/models/CertificadoUnidadeEstadual';

@Component({
  selector: 'app-certificado-regularidade-unidade-estadual',
  templateUrl: './certificado-regularidade-unidade-estadual.component.html',
  styleUrls: ['./certificado-regularidade-unidade-estadual.component.css'],
})
export class CertificadoRegularidadeUnidadeEstadualComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);
  private readonly ngZone = inject(NgZone);
  private readonly destroyRef = inject(DestroyRef);

  constructor(
    private apiCertificadoRegularidadeUnidadeEstadualService: ApiCertificadoRegularidadeUnidadeEstadualService,
    private apiUf: ApiUFService,
    private breadCrumbPrimeNGService: BreadcrumbService
  ) {}

  chaveBackGround = 'CERTIFICADO_REGULARIDADE_BACKGROUND_UNIDADE_ESTADUAL';
  @Input()
  listaCertificadoRegularidadeUnidadeEstadual: CertificadoRegularidadeUnidadeEstadual[];
  @Input() listaUfs: Uf[];
  @ViewChild('certificadoRegularidadeUnidadeEstadualForm')
  certificadoUnidadeEstadualForm: NgForm;
  ngOnInit() {
    this.atualizaBreadCrumbPrimeNG();
    this.carregaTela();

    // Cada app-file-upload resolve seu próprio carregamento de forma assíncrona e
    // independente (ngOnInit interno). Como o AppComponent (raiz, OnPush) só chama
    // markForCheck() no início/fim do lote de requisições HTTP (ver message-http-interceptor.ts),
    // respostas individuais no meio do lote não disparam re-render. Detecta mudanças
    // localmente a cada estabilização da zona, independente da raiz.
    this.ngZone.onStable.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
      this.changeDetectorRef.detectChanges();
    });
  }

  carregaTela() {
    this.carregaCertificadosUnidadeEstadual();
  }

  carregaCertificadosUnidadeEstadual() {
    this.listaCertificadoRegularidadeUnidadeEstadual = new Array<CertificadoUnidadeEstadual>();

    this.apiCertificadoRegularidadeUnidadeEstadualService
      .listaCertificadoUnidadeEstadual()
      .then((response) => {
        if (response.data.length > 0) {
          this.listaCertificadoRegularidadeUnidadeEstadual = response.data.map(cert => ({
            ...cert,
            inAtiva: !!cert.inAtiva // Garante que seja um booleano
          }));
        } else {
          this.apiUf.obterUfs().then((responseUf) => {
            if (responseUf) {
              responseUf.forEach((uf) => {
                const certificado = new CertificadoUnidadeEstadual();
                certificado.uf = uf.sigla;
                certificado.inAtiva = true; // Define como ativo por padrão para novos certificados
                this.listaCertificadoRegularidadeUnidadeEstadual = [
                  ...this.listaCertificadoRegularidadeUnidadeEstadual,
                  certificado
                ];
              });
            }
            this.changeDetectorRef.markForCheck();
          });
        }
        this.changeDetectorRef.markForCheck();
      })
      .catch(error => {
        console.error("Erro ao carregar certificados:", error);
      });
  }


  atualizaBreadCrumbPrimeNG() {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração ', routerLink: '/administracao' },
      {
        label: 'Certificado Organização Estadual',
        routerLink: '/administracao/certificado-unidade-estadual',
      },
    ]);
  }

  onConcluirUploadCertificadoUnidadeEstadual(event: string, index: number) {
    this.listaCertificadoRegularidadeUnidadeEstadual = this.listaCertificadoRegularidadeUnidadeEstadual
      .map((item, i) =>
        i === index ? { ...item, arquivo: event } : item
      );
  }

  outExcluirUpload(event: Repositorio, index: number) {
    this.listaCertificadoRegularidadeUnidadeEstadual = this.listaCertificadoRegularidadeUnidadeEstadual
      .map((item, i) =>
        i === index ? { ...item, arquivo: null } : item
      ) as CertificadoRegularidadeUnidadeEstadual[];
  }

  salvarCertificadoUnidadeEstadual() {
    const certificadosParaSalvar = this.listaCertificadoRegularidadeUnidadeEstadual.map(cert => ({
      ...cert,
      inAtiva: !!cert.inAtiva  // Converte para 1 e 0 caso o banco espere BIT
    }));

    this.apiCertificadoRegularidadeUnidadeEstadualService
      .salvarCertificadoUnidadeEstadual(certificadosParaSalvar)
      .then(() => {
        // Após salvar, recarregar os dados para refletir corretamente
        this.apiCertificadoRegularidadeUnidadeEstadualService
          .listaCertificadoUnidadeEstadual()
          .then((resp) => {
            this.listaCertificadoRegularidadeUnidadeEstadual = resp.data.map(cert => ({
              ...cert,
              inAtiva: !!cert.inAtiva // Garante que os dados retornados do banco estejam normalizados
            }));
            this.changeDetectorRef.markForCheck();
          });
      })
      .catch(error => {
        console.error("Erro ao salvar certificados:", error);
      });
  }


  gerarCertificadoRegularidade(idCooperativa: number) {
    this.apiCertificadoRegularidadeUnidadeEstadualService
      .gerarCertificadoRegularidade(idCooperativa)
      .then((response) => {
        const byteCharacters = atob(response.data.toString());
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/pdf' });
        saveAs(blob, 'certificado_regularidade.pdf');
        this.changeDetectorRef.markForCheck();
      });
  }
}
