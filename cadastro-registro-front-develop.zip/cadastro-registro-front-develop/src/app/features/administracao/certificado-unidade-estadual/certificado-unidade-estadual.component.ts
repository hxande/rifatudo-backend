import { Component } from '@angular/core';
@Component({
  selector: 'app-certificado-unidade-estadual',
  templateUrl: './certificado-unidade-estadual.component.html',
  styleUrls: ['./certificado-unidade-estadual.component.css']
})
export class CertificadoUnidadeEstadualComponent{
constructor( ) {}
}
