import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificadoRegistroUnidadeEstadualComponent } from './certificado-registro-unidade-estadual.component';

describe('CertificadoRegistroUnidadeEstadualComponent', () => {
  let component: CertificadoRegistroUnidadeEstadualComponent;
  let fixture: ComponentFixture<CertificadoRegistroUnidadeEstadualComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificadoRegistroUnidadeEstadualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificadoRegistroUnidadeEstadualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
