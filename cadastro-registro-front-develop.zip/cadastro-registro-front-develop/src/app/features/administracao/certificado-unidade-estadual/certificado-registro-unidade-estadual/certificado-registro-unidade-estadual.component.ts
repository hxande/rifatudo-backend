import { Component, OnInit, Input, ViewChild, ChangeDetectorRef, DestroyRef, NgZone, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgForm } from '@angular/forms';
import { CertificadoUnidadeEstadual } from '@cadastro-registro-api/models/CertificadoUnidadeEstadual';
import { ApiCertificadoRegistroUnidadeEstadualService } from '@cadastro-registro-api/services/api-certificado-registro-unidade-estadual.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { Uf } from '@localizacao-api/models/Uf';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { Repositorio } from '@upload-api/models/Repositorio';

@Component({
  selector: 'app-certificado-registro-unidade-estadual',
  templateUrl: './certificado-registro-unidade-estadual.component.html',
  styleUrls: ['./certificado-registro-unidade-estadual.component.css']
})
export class CertificadoRegistroUnidadeEstadualComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);
  private readonly ngZone = inject(NgZone);
  private readonly destroyRef = inject(DestroyRef);

  constructor(
    private apiCertificadoUnidadeEstadual:ApiCertificadoRegistroUnidadeEstadualService,
    private apiUf: ApiUFService,
    private breadCrumbPrimeNGService:BreadcrumbService,
  ) {}
  chaveBackGround = 'CERTIFICADO_REGISTRO_BACKGROUND_UNIDADE_ESTADUAL';
  @Input() listaCertificadoUnidadeEstadual: CertificadoUnidadeEstadual[];
  @Input() listaUfs: Uf[];
  @ViewChild('certificadoUnidadeEstadualForm') certificadoUnidadeEstadualForm: NgForm;
  ngOnInit() {
    this.atualizaBreadCrumbPrimeNG();
    this.carregaTela();

    // Cada app-file-upload resolve seu próprio carregamento de forma assíncrona e
    // independente (ngOnInit interno). Como o AppComponent (raiz, OnPush) só chama
    // markForCheck() no início/fim do lote de requisições HTTP (ver message-http-interceptor.ts),
    // respostas individuais no meio do lote não disparam re-render. Detecta mudanças
    // localmente a cada estabilização da zona, independente da raiz.
    this.ngZone.onStable.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => {
      this.changeDetectorRef.detectChanges();
    });
  }

  carregaTela() {
    this.carregaCertificadosUnidadeEstadual();
  }

  carregaCertificadosUnidadeEstadual() {
    this.listaCertificadoUnidadeEstadual = new Array<CertificadoUnidadeEstadual>();
    this.apiCertificadoUnidadeEstadual.listaCertificadoUnidadeEstadual()
    .then(response=>{
      if(response.data.length > 0) {
        this.listaCertificadoUnidadeEstadual = response.data;
      } else {
        this.apiUf.obterUfs()
        .then(responseUf => {
          if(responseUf){
              responseUf.forEach(uf =>{
                const certificado = new CertificadoUnidadeEstadual();
                certificado.uf = uf.sigla;
                this.listaCertificadoUnidadeEstadual =[
                  ...this.listaCertificadoUnidadeEstadual,
                  certificado
                ];
              });
          }
          this.changeDetectorRef.markForCheck();
        });
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  atualizaBreadCrumbPrimeNG() {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Inicio / ', routerLink: '/' },
      { label: 'Administração ', routerLink: '/administracao' },
      { label: 'Certificado Organização Estadual', routerLink: '/administracao/certificado-unidade-estadual' },
    ]);
  }

  onConcluirUploadCertificadoUnidadeEstadual(event: string, index: number) {
    this.listaCertificadoUnidadeEstadual[index].arquivo = event;
  }

  outExcluirUpload(event: Repositorio, index: number ) {
    this.listaCertificadoUnidadeEstadual[index].arquivo = null;
  }

  salvarCertificadoUnidadeEstadual() {
    this.apiCertificadoUnidadeEstadual.salvarCertificadoUnidadeEstadual(this.listaCertificadoUnidadeEstadual)
    .then( response => {
        this.apiCertificadoUnidadeEstadual.listaCertificadoUnidadeEstadual()
        .then(resp => {
          this.listaCertificadoUnidadeEstadual = resp.data;
          this.changeDetectorRef.markForCheck();
        });
        this.changeDetectorRef.markForCheck();
    });
  }


}
