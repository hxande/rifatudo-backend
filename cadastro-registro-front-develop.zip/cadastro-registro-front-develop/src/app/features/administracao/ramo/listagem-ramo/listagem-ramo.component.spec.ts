import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemRamoComponent } from './listagem-ramo.component';

describe('ListagemRamoComponent', () => {
  let component: ListagemRamoComponent;
  let fixture: ComponentFixture<ListagemRamoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemRamoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemRamoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
