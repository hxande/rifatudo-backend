import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { UtilityService } from '@utils/utility/utility.service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-listagem-ramo',
  templateUrl: './listagem-ramo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-ramo.component.css']
})
export class ListagemRamoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private ramoApi: ApiRamoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Ramos', routerLink: '/administracao/listagem-ramo' },
      { label: 'Consulta de Ramo', routerLink: 'listagem-ramo' }
    ]);
   }

  response: IServiceResponse<IPage<Ramo>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroNome='';
  filtroDetalhamento='';
  filtroTipoPessoa='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [

      { field: 'nome', header: 'Nome' },
      { field: 'detalhamento', header: 'Detalhamento' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getRamos(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<Ramo>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.ramoApi.getRamosPage(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    options.params = this.utilityService.carregaParamsString(this.filtroDetalhamento, options.params, 'detalhamento');
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getRamos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseDocumento => {
      this.response = responseDocumento;
      this.changeDetectorRef.markForCheck();
    });
  }

  excluir(id){
    this.confirmationService.confirm({
      message: 'Deseja excluir o Ramo?',
      accept: () => {
        this.ramoApi.desativa(id)
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
