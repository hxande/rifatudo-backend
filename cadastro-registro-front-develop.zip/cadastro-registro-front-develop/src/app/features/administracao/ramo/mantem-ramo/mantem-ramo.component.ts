import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, OnInit, ViewChild, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { Ramo } from 'src/app/api/models/Ramo';
import { ApiRamoService } from 'src/app/api/services/api-ramo.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-mantem-ramo',
  templateUrl: './mantem-ramo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-ramo.component.css']
})
export class MantemRamoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  ramo: Ramo;
  @ViewChild('ramoForm') ramoForm: NgForm;

  constructor(
    private ramoApi: ApiRamoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: ' Ramos', routerLink: '/administracao/listagem-ramo' },
      { label: 'Cadastro de Ramo', routerLink: '/administracao/novo-ramo' }
    ]);
  }

  ngOnInit() {
    this.inicializarRamo();
    if (this.route.snapshot.url[0]?.path === 'editar-ramo') {
      this.route.params
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(params => {
          this.ramoApi.getRamo(params['id'])
            .then(res => {
              this.ramo = res;
              this.changeDetectorRef.markForCheck();
            });
        });
    }
  }

  inicializarRamo(){
    this.ramo = new Ramo();
    this.ramo.ativo = true;
    this.ramo.excluido = false;
    this.ramo.segmentoUnico = false;
  }

  salvar(): void {
    if (this.ramoForm.invalid) {
      return;
    }
    this.ramo.excluido = false;
    if (this.ramo.id) {
      this.ramoApi.update(this.ramo);
    } else {
      this.ramoApi.create(this.ramo)
        .then(() => {
          this.ramoForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() => {
            this.inicializarRamo();
            this.changeDetectorRef.markForCheck();
          }, 0);
        });
    }
  }
}
