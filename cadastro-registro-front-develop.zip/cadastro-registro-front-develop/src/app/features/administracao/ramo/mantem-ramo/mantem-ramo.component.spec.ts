import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemRamoComponent } from './mantem-ramo.component';

describe('MantemRamoComponent', () => {
  let component: MantemRamoComponent;
  let fixture: ComponentFixture<MantemRamoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemRamoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemRamoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
