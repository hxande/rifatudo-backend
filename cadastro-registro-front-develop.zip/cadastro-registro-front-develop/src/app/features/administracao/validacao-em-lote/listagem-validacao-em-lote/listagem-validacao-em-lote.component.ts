import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit } from '@angular/core';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ValidacaoEmLoteService } from '@cadastro-registro/services/api-validacao-em-lote-service';
import { ValidacaoEmLoteTO } from '@cadastro-registro/models/ValidacaoEmLoteTO';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiRamoService } from '@cadastro-registro/services/api-ramo.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro/services/api-manutencao-dados-gerais.service';
import { Router } from '@angular/router';
import { ApiCooperativaService } from '@cadastro-registro/services/api-cooperativa.service';
import { CooperativaFiltro } from './cooperativa-filtroTO';
import { ApiRelatorioPendencia } from 'src/app/api/services/api-relatorio-pendencia';
import { UtilityService } from '@utils/utility/utility.service';
import { finalize } from 'rxjs';
import { LoadingService } from 'src/app/services/loading-service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';


export enum StatusValidacao {
  VALIDADO = 'Sucesso',
  FALHA_VALIDACAO = 'Falha',
  PENDENTE_EXECUCAO = 'Pendente'
}


@Component({
  selector: 'app-listagem-validacao-em-lote',
  templateUrl: './listagem-validacao-em-lote.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-validacao-em-lote.component.css'],
})
export class ListagemValidacaoEmLoteComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  validacoes: ValidacaoEmLoteTO[] = [];
  selectedValidacoes: ValidacaoEmLoteTO[] = [];

  filtroNomeFantasiaCnpj: string = '';

  filtroRamo: number[] = [];
  filtroUf: string[] = [];
  filtroStatus: string[] = [];

  showProgressBar: boolean = false;
  progressValue: number = 0;

  ufsOpts: { label: string; value: string }[] = [];
  ramosOpts: { label: string; value: number }[] = [];
  statusOpts: { label: string; value: string }[] = Object.keys(StatusValidacao).map(key => ({
    label: StatusValidacao[key],
    value: key
  }));

  currentPage: number = 0;
  displayingRecordsInfo: string = '';

  displayDialog: boolean = false;
  displayWarningDialog: boolean = false;
  totalRecords: number;
  rowsPerPage: number = 10;

  sortField: string;
  sortOrder: number;



  onCheckboxChange(event, validacao: ValidacaoEmLoteTO) {
    if (event.checked)
      this.selectedValidacoes = [...this.selectedValidacoes, validacao];
    else
      this.selectedValidacoes = this.selectedValidacoes.filter(val => val !== validacao);
  }

  onStatusChange() {
    // Aqui você pode chamar loadValidacoes se necessário
  }

  getChipColor(valor: string): string {
    switch (valor) {
      case 'VALIDADO':
        return 'chip-verde';
      case 'FALHA_VALIDACAO':
        return 'chip-vermelho';
      case 'PENDENTE_EXECUCAO':
        return 'chip-laranja';
      default:
        return '';
    }
  }



  getDescricaoStatusValidacao(valor: string): string {
    switch (valor) {
      case 'VALIDADO':
        return StatusValidacao.VALIDADO;
      case 'FALHA_VALIDACAO':
        return StatusValidacao.FALHA_VALIDACAO;
      case 'PENDENTE_EXECUCAO':
        return StatusValidacao.PENDENTE_EXECUCAO;
      default:
        return StatusValidacao.PENDENTE_EXECUCAO;
    }
  }



  confirmValidation() {
    if (this.selectedValidacoes.length > 0) {
      this.displayDialog = true;
    } else {
      this.displayWarningDialog = true;

    }
  }
  onConfirm() {

    const selectedIds = this.selectedValidacoes.map(val => val.id.toString());
    const timePerItem = 3000; // 3 segundos por item
    const maxTotalTime = 150000; // Tempo máximo
    let totalTime = selectedIds.length * timePerItem; // Tempo total em milissegundos

    // Limitar o tempo total ao máximo definido
    totalTime = Math.min(totalTime, maxTotalTime);

    this.showProgressBar = true;
    this.progressValue = 0;

    const incrementInterval = 1000; // Atualiza a cada segundo
    const totalIncrements = totalTime / incrementInterval;
    let incrementValue = 100 / totalIncrements; // Valor de incremento para cada intervalo

    const interval = setInterval(() => {
      this.progressValue += incrementValue;

      // Arredondar para o inteiro mais próximo
      this.progressValue = Math.round(this.progressValue);

      if (this.progressValue >= 100) {
        clearInterval(interval);
        this.progressValue = 100; // Garante que a barra atinja 100%
      }
      this.changeDetectorRef.markForCheck();
    }, incrementInterval);

    this.validdacaoEmLoteService.submeterCadastroValidacaoEmLote(selectedIds)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (response) => {
          clearInterval(interval);
          this.progressValue = 100; // Define o progresso como 100%
          this.loadValidacoes(0, this.rowsPerPage);
          this.showProgressBar = false;
          this.changeDetectorRef.markForCheck();
        },
        error: (error) => {
          clearInterval(interval);
          console.error('Erro ao submeter validações:', error);
          this.showProgressBar = false;
        }
      });

    this.displayDialog = false;
  }


  onChangeFilter() {
    this.loadValidacoes(0, this.rowsPerPage, this.sortField, this.sortOrder,
      this.filtroStatus, this.filtroNomeFantasiaCnpj);
  }

  onChangeRelatorioErros() {
    const selectedIds = this.selectedValidacoes.map(val => val.id);

    if (selectedIds.length > 0) {
      this.loadingService.setLoading(true);
      this.apiRelatorioPendencia.gerarRelatorio(selectedIds)
        .pipe(
          finalize(() => {
            this.loadingService.setLoading(false);
          })
        )
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (response) => {
            if (response == null) {
              this.messageService.add({ severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000 });
            } else {
              const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'relatorio_erros_validacao.xlsx';
              a.click();

              window.URL.revokeObjectURL(url);
              this.showProgressBar = false;
            }
          },
          error: (err) => {
            console.error('Erro ao gerar relatório:', err);

            this.showProgressBar = false;
          }
        });
    } else {
      console.warn('Nenhum ID selecionado para o relatório.');
      this.messageService.add({ severity: 'warn', detail: 'Nenhum registro selecionado para o relatório.', life: 100000 });

    }
  }


  onSortChange(event) {
    if (this.sortField !== event.field || this.sortOrder !== event.order) {
      this.sortField = event.field;
      this.sortOrder = event.order;
      this.loadValidacoes(0, this.rowsPerPage, this.sortField, this.sortOrder);
    }
  }
  onReject() {
    this.displayDialog = false;
  }

  constructor(private http: HttpClient,
    private breadcrumbService: BreadcrumbService,
    private validdacaoEmLoteService: ValidacaoEmLoteService,
    public kcService: KeycloakService,
    private apiRamoService: ApiRamoService,
    private utilityService: UtilityService,
    private apiDadosGeraisService: ApiManutencaoDadosGeraisService,
    private router: Router,
    private apiRelatorioPendencia: ApiRelatorioPendencia,
    private cooperativaService: ApiCooperativaService,
    private confirmationService: ConfirmationService,
    public messageService: MessageService,
    private loadingService: LoadingService) {
    this.breadcrumbService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Organização Estadual', routerLink: '/administracao/listagem-validacao-em-lote' },
      { label: 'Validação em Lote ', routerLink: '/administracao/validacao-em-lote' }
    ]);
  }

  ngOnInit() {
    this.buscarUF();
    this.buscarRamos();
    this.loadValidacoes(0, this.rowsPerPage);
  }

  private isCnpj(valor: string): boolean {
    return this.limparNumeros(valor).length === 14;
  }

  private limparNumeros(valor: string): string {
    return valor.replace(/\D/g, '');
  }

  loadValidacoes(
    page: number,
    size: number,
    sortField?: string,
    sortOrder?: number,
    filtroStatus?: string[],
    nomeFantasiaParamCnpj?: string
  ) {

    const termo = (nomeFantasiaParamCnpj || this.filtroNomeFantasiaCnpj)?.trim();

    let nomeFantasia: string | undefined;
    let cnpj: string | undefined;

    if (termo) {
      if (this.isCnpj(termo)) {
        cnpj = this.limparNumeros(termo);
      } else {
        nomeFantasia = termo;
      }
    }

    const cooperativaFiltro: CooperativaFiltro = {
      ramos: this.filtroRamo,
      ufs: this.filtroUf,
      statusValidacaoLote: filtroStatus || this.filtroStatus,
      nomeFantasia,
      cnpj
    };

    this.validdacaoEmLoteService.getCooperativasValidacaoEmLote(
      page,
      size,
      sortField,
      sortOrder,
      cooperativaFiltro
    )
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {

      const pageData = response.data;

      this.validacoes = pageData.content;
      this.totalRecords = pageData.totalElements;
      this.rowsPerPage = pageData.size;
      this.currentPage = pageData.number;

      const startIndex = (this.currentPage * this.rowsPerPage) + 1;
      const itemsOnPage = pageData.content.length;
      const endIndex = (this.currentPage * this.rowsPerPage) + itemsOnPage;

      this.displayingRecordsInfo =
        `Exibindo ${startIndex} - ${endIndex} de ${this.totalRecords} resultado(s) encontrado(s).`;

      this.changeDetectorRef.markForCheck();
    });
  }

  buscarRamos() {
    this.apiRamoService.getRamos().then(response => {
      if (response && response.data) {
        this.ramosOpts = response.data.map(r => ({
          label: r.nome,
          value: r.id
        }));

        this.changeDetectorRef.markForCheck();
      }
    })
      .catch(e => console.error('error => ', e));
  }
  onSearchClick(cooperativaId: number) {
    this.cooperativaService.marcarComoVisualizada(cooperativaId);
    this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: cooperativaId } });
  }

  buscarUF() {
    if (this.ufsOpts.length === 0) {
      this.apiDadosGeraisService.buscarUfs().then((res) => {
        if (res && res.content != null) {
          this.ufsOpts = res.content.map(uf => ({
            label: uf.sigla,
            value: uf.sigla
          }));

        this.changeDetectorRef.markForCheck();
        }
      })
        .catch(e => console.error('error => ', e));
    }
  }

  paginate(event) {
    this.loadValidacoes(event.page, event.rows, this.sortField, this.sortOrder, this.filtroStatus, this.filtroNomeFantasiaCnpj);

  }

  getSituationClass(validacao: ValidacaoEmLoteTO): string {
    if (validacao.situacaoRegistro === 'IRREGULAR' || validacao.situacaoRegistro === 'SUSPENSO') {
      return 'text-red';
    }
    return '';
  }

}
