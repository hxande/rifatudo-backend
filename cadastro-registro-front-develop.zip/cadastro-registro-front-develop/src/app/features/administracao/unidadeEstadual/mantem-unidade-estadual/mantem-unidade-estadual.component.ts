import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { SelectItem, MessageService, ConfirmationService } from 'primeng/api';
import { UnidadeEstadual } from '@cadastro-registro-api/models/UnidadeEstadual';
import { Uf } from '@localizacao-api/models/Uf';
import { Municipio } from '@localizacao-api/models/Municipio';
import { ApiUnidadeEstadualService } from '@cadastro-registro-api/services/api-unidade-estadual.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ApiPessoaFisicaService } from '@cadastro-registro-api/services/api-pessoa-fisica.service';
import { ApiTipoEnderecoService } from '@cadastro-registro-api/services/api-tipo-endereco.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { ApiEnderecoService } from '@cadastro-registro-api/services/api-endereco.service';
import { ApiPresidenciaService } from '@cadastro-registro-api/services/api-presidencia.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiCooperativaLogoService } from '@cadastro-registro-api/services/api-cooperativa-logo.service';
import { PessoaImagem } from '@cadastro-registro-api/models/PessoaImagem';
import { EnumTipoEndereco } from '@cadastro-registro-api/models/EnumTipoEndereco';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { TipoEndereco } from '@cadastro-registro-api/models/TipoEndereco';
import { TipoUnidade } from '@cadastro-registro-api/models/TipoUnidade';
import { UnidadeEstadualPresidente } from '@cadastro-registro-api/models/UnidadeEstadualPresidente';
import { PessoaFisica } from '@cadastro-registro-api/models/PessoaFisica';
import { TipoRedeSocial } from '@cadastro-registro-api/models/TipoRedeSocial';
import { RedeSocial } from '@cadastro-registro-api/models/RedeSocial';
import { Genero } from '@gerencia-usuario-api/models/Genero';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import {Contato} from '@cadastro-registro-api/models/Contato';
import {AreaContato} from '@cadastro-registro-api/models/AreaContato';
import {forkJoin} from 'rxjs';
import {IServiceResponse} from '@utils/interfaces/IServiceResponse';
import {ApiAreaContatoService} from '@cadastro-registro-api/services/api-area-contato.service';
import {ApicontatoService} from '@cadastro-registro-api/services/api-contato.service';
import {Pessoa} from '@cadastro-registro-api/models/Pessoa';

@Component({
  selector: 'app-mantem-unidade-estadual',
  templateUrl: './mantem-unidade-estadual.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-unidade-estadual.component.css']
})
export class MantemUnidadeEstadualComponent implements OnInit {

  private changeDetectorRef = inject(ChangeDetectorRef);

  podeModificarLogo = true;
  responsePageAreaContato: AreaContato[];
  listaContatos: Contato[];
  contatosNaoSalvos = 0;


  id: number;
  unidadeEstadual = new UnidadeEstadual();
  listaUfs: Uf[] = [];
  listGenero: SelectItem[];
  listaTipoUnidade: SelectItem[];
  tiposRedesSociais: SelectItem[] = new TipoRedeSocial().tipoRedesSociais;
  listaMunicipios: Map<number, Municipio[]> = new Map<number, Municipio[]>();
  redesSociais: RedeSocial[] = null;
  unidadeLogotipo: PessoaImagem = new PessoaImagem();
  modalLogo = false;
  tipoEndereco = null;
  houveAlteracaoForm = false;
  salvando = false;


  @ViewChild('file') file;

  @ViewChild('unidadeEstadualForm') unidadeEstadualForm: NgForm;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiUnidadeEstadual: ApiUnidadeEstadualService,
    private dadosGeraisService: ApiDadosGeraisService,
    private apiPessoaJuridica: ApiPessoaJuridicaService,
    private apiPessoaFisica: ApiPessoaFisicaService,
    private apiTipoEndereco: ApiTipoEnderecoService,
    public language: LanguageService,
    public apiEndereco: ApiEnderecoService,
    public apiPresidencia: ApiPresidenciaService,
    public keycloakService: KeycloakService,
    public utility: UtilityService,
    private cooperativaLogoService: ApiCooperativaLogoService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private apiAreaContatoService: ApiAreaContatoService,
    private apicontatoService: ApicontatoService,
    private utilityService: UtilityService,

  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Organização Estadual', routerLink: '/administracao/listagem-unidade-estadual' },
      { label: 'Cadastro de Organização Estadual', routerLink: '/administracao/editar-unidade-estadual' }
    ]);
  }

  ngOnInit() {
    this.inicializar();

    this.tipoEndereco = this.apiTipoEndereco.getTipoEndereco(EnumTipoEndereco.ENDERECO_PRINCIPAL.valueOf());

    if (this.route.snapshot.url[0]?.path === 'editar-unidade-estadual') {
      this.route.params.subscribe(params => {
        this.apiPessoaJuridica.get(params['id']).then(res => {
          this.unidadeEstadual.pessoaJuridica = res.data ? res.data : new PessoaJuridica();
          this.unidadeEstadual.presidencia.pessoaJuridica = res.data ? res.data : new PessoaJuridica();
          this.redesSociais = this.unidadeEstadual.pessoaJuridica.redesSociais;
          // Transformando em itens na tela
          if (this.redesSociais) {
            this.redesSociais.forEach(rs => rs.tipoRedeSocialItem = { label: rs.tipoRedeSocial, value: rs.tipoRedeSocial });
          }

          // Carregando Redes Sociais em tela
          if (this.redesSociais && this.redesSociais.length === 0) {
            const rs = new RedeSocial();
            this.redesSociais = [
              ...this.redesSociais,
              rs
            ];
          }

          if (this.unidadeEstadual.pessoaJuridica.enderecos && this.unidadeEstadual.pessoaJuridica.enderecos.length > 0) {
            let index = 0;
            this.unidadeEstadual.pessoaJuridica.enderecos.forEach((end) => {
              if (end.idMunicipio) {
                this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {
                  end.municipio = resEnd;

                  // Adicionando UF
                  if (end.municipio != null && end.municipio.id) {
                    end.uf = end.municipio.uf;
                    this.buscarMunicipios(end.uf);
                  }
                });
              }
              // Sinalizando quem é o endereço principal
              if (end.tipoEndereco.enderecoPrincipal) {
                this.unidadeEstadual.pessoaJuridica.enderecos[0] = end;
              }
              index++;
            });
          } else {
            const endereco: Endereco = new Endereco();
            endereco.tipoEndereco = new TipoEndereco();
            endereco.tipoEndereco.id = EnumTipoEndereco.ENDERECO_PRINCIPAL.valueOf();
            this.unidadeEstadual.pessoaJuridica.enderecos = [
              ...this.unidadeEstadual.pessoaJuridica.enderecos,
              endereco
            ];
          }
          this.changeDetectorRef.markForCheck();
        });

        this.id = params['id'];
      });
    }

    // Logotipo da cooperativa
    this.unidadeLogotipo.idPessoa = this.id;
    this.listarUfs();
    this.listarGeneros();
    this.listarTipoUnidade();
    this.carregaPresidencia();
  }

  imagemLogo(imagemLogo){
    this.unidadeLogotipo.imagemLogo = imagemLogo;
  }

  listarGeneros() {
    const key = Object.keys(Genero);
    const value = Object.values(Genero);
    this.listGenero = key.map((x, i) => ({ label: value[i], value: x }));
  }

  listarTipoUnidade() {
    const key = Object.keys(TipoUnidade);
    const value = Object.values(TipoUnidade);
    this.listaTipoUnidade = key.map((x, i) => ({ label: value[i], value: x }));
  }

  inicializar() {
    this.unidadeEstadual.pessoaJuridica = new PessoaJuridica();
    this.unidadeEstadual.presidencia = new UnidadeEstadualPresidente();
    this.unidadeEstadual.presidencia.pessoaJuridica = this.unidadeEstadual.pessoaJuridica;
    this.unidadeEstadual.presidencia.pessoaFisica = new PessoaFisica();
    this.unidadeEstadual.pessoaJuridica.enderecos = new Array<Endereco>();
    this.unidadeEstadual.pessoaJuridica.enderecos[0] = new Endereco();
  }

  salvar(): void {
    if (this.unidadeEstadualForm.form.invalid || this.salvando) {
      return;
    }

    if (this.unidadeEstadual.pessoaJuridica.id) {
      this.unidadeEstadual.pessoaJuridica.redesSociais = new Array<RedeSocial>();
      for (const rede of this.redesSociais) {
        if (rede.tipoRedeSocial || rede.tipoRedeSocialItem) {
          rede.tipoRedeSocial = rede.tipoRedeSocialItem ? String(rede.tipoRedeSocialItem.value) : null;
          if (!rede.tipoRedeSocialItem) {
            const index = this.redesSociais.indexOf(rede);
            this.unidadeEstadual.pessoaJuridica.redesSociais = this.unidadeEstadual.pessoaJuridica.redesSociais.filter((_, i) => i !== index);
          } else {
            this.unidadeEstadual.pessoaJuridica.redesSociais = [
              ...this.unidadeEstadual.pessoaJuridica.redesSociais,
              rede
            ];
          }
        }
      }
      this.configuraListaContatos();
      this.unidadeEstadual.contatos = this.listaContatos;
      this.salvando = true;
      this.apiUnidadeEstadual.salvar(this.unidadeEstadual).then(response => {
        this.unidadeEstadual = response.data;
        this.ngOnInit();
        this.changeDetectorRef.markForCheck();
      }).finally(() => {
        this.salvando = false;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  selectMask(event: Event) {
    setTimeout(() => (event.target as HTMLInputElement).select(), 100);
  }

  procurarLocalizacao(event) {
    let busca = event?.value;
    const index = 0;
    if (busca) {
      busca = this.utility.retirarFormatacao(busca);
      this.dadosGeraisService.buscarEndereco(busca).subscribe((res) => {
        if (res != null && this.unidadeEstadual.pessoaJuridica.enderecos[index] != null) {
          const endereco = res;

          this.unidadeEstadual.pessoaJuridica.enderecos[index].pessoa = endereco.pessoa;
          this.unidadeEstadual.pessoaJuridica.enderecos[index].enderecoReferencia = endereco.logradouro;
          this.unidadeEstadual.pessoaJuridica.enderecos[index].complemento = endereco.complemento;
          this.unidadeEstadual.pessoaJuridica.enderecos[index].bairro = endereco.bairro;
          this.unidadeEstadual.pessoaJuridica.enderecos[index].municipio = endereco.municipio;
          if (endereco.municipio) {
            this.unidadeEstadual.pessoaJuridica.enderecos[index].idEstado = endereco.municipio.uf.id;


            this.unidadeEstadual.pessoaJuridica.enderecos[index].idMunicipio = endereco.municipio.id;
            this.unidadeEstadual.pessoaJuridica.enderecos[index].uf = endereco.municipio.uf;
            if (this.unidadeEstadual.pessoaJuridica.enderecos[index].uf) {
              this.buscarMunicipios(this.unidadeEstadual.pessoaJuridica.enderecos[index].uf);
            }
          }

        }
      });
    }
  }

  buscarMunicipios(uf: Uf, index?: number) {
    let saida = null;
    if (uf != null && uf.id) {
      if (index != null) {
        this.unidadeEstadual.pessoaJuridica.enderecos[index].municipio = undefined;
      }
      if (this.listaMunicipios[uf.id] == null || this.listaMunicipios[uf.id].length === 0) {
        this.dadosGeraisService.buscarMunicipiosByIdUf(uf.id).then((mun) => {
          if (mun && mun.content != null) {
            this.listaMunicipios.set(uf.id, mun.content);
            this.changeDetectorRef.markForCheck();
          }
        });
      }
      saida = this.listaMunicipios.get(uf.id);
    }
    this.changeDetectorRef.markForCheck();
    return saida;
  }

  obterMunicipiosFiltrados(uf: Uf) {
    let saida = null;
    if (uf != null && uf.id) {
      saida = this.listaMunicipios.get(uf.id);
    }
    return saida;
  }

  voltar() {
    if (this.keycloakService.isUsuarioEstadual) {
      this.router.navigate(['/administracao/inicio-ue']);
    } else {
      this.router.navigate(['/administracao/listagem-unidade-estadual']);
    }
  }

  adicionarRedeSocial() {
    const redeSocial = new RedeSocial();
    this.unidadeEstadual.pessoaJuridica.redesSociais = [
      ...this.unidadeEstadual.pessoaJuridica.redesSociais,
      redeSocial
    ];
  }

  removerRedeSocial(i: number) {
    this.unidadeEstadual.pessoaJuridica.redesSociais = this.unidadeEstadual.pessoaJuridica.redesSociais.filter((_, index) => index !== i);
  }

  listarUfs() {
    this.dadosGeraisService.buscarUfs().then((res) => {
      if (res && res.content != null) {
        this.listaUfs = res.content;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  private getListaAreaContato(): Promise<IServiceResponse<AreaContato[]>> {
    return this.apiAreaContatoService.listaAtivos();
  }

  carregaPresidencia() {
    this.apiPresidencia.buscaPorPjId(this.id).then(response => {
      if (response.data) {
        this.unidadeEstadual.presidencia = response.data;
        this.changeDetectorRef.markForCheck();
      }
    });
    this.getListaAreaContato().then((responsePage) => {
      this.responsePageAreaContato = responsePage.data;

      forkJoin(this.responsePageAreaContato.map((item) => this.apicontatoService.listaAreaPessoa(item.id, this.id))).subscribe({
        next: (resp) => {
          this.responsePageAreaContato = this.responsePageAreaContato.map((area, index) => ({
          ...area,
          contatos: resp[index].data.length === 0 ? [new Contato()] : resp[index].data
        }));
        this.changeDetectorRef.markForCheck();
        },
        complete: () => {
          this.desativaEventoForm();
        },
      });
    });
  }

  buscaCpf(cpf: string) {
    this.apiPessoaFisica.buscaPorCpf(this.utility.retirarFormatacao(cpf))
    .then(response => {
      if (response.data) {
        this.unidadeEstadual.presidencia.pessoaFisica = response.data;
      } else {
        this.unidadeEstadual.presidencia.pessoaFisica.id = null;
      }
      this.changeDetectorRef.markForCheck();
    });
  }


  fileChange(event) {
    const pattern = /image-|bmp|jpe?g|png/;
    const file: File = event.target.files[0];
    if (!file.type.match(pattern)) {
      this.messageService.add({ severity: 'warn', detail: 'Formato de arquivo inválido!', life: 10000 });
      return;
    }
    if (file.size > 3145728) {
      this.messageService.add({ severity: 'warn', detail: 'Tamanho superior ao permitido! <b>Máx. 3MB</b>', life: 10000 });
      return;
    }
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.unidadeEstadual = {
        ...this.unidadeEstadual,
        presidencia: { ...this.unidadeEstadual.presidencia, imagemAssinatura: myReader.result.toString() }
      };
      this.changeDetectorRef.markForCheck();
    };
    myReader.readAsDataURL(file);
  }

  onAddLogo() {
    this.file.nativeElement.click();
  }

  onEditLogo() {
    this.modalLogo = true;
  }

  excluirLogoCooperativa() {
    this.confirmationService.confirm({
      header: 'Remover',
      message: 'Tem certeza que deseja excluir esta imagem?',
      accept: () => {
        if (this.unidadeEstadual.presidencia && this.unidadeEstadual.presidencia.imagemAssinatura) {
          this.unidadeEstadual.presidencia.imagemAssinatura = null;
        }
      }
    });
  }

  private isUndefinedOrNull(val): boolean {
    return val === '' || val === null || val === undefined;
  }

  houveMudancaForm(): void {
    this.houveAlteracaoForm = true;
  }

  getAlteracaoForm(): boolean {
    return this.houveAlteracaoForm;
  }

  desativaEventoForm(): void {
    this.houveAlteracaoForm = false;
  }

  private formMarkAsPristine(): void {
    if (this.unidadeEstadualForm) {
      Object.keys(this.unidadeEstadualForm.controls).forEach((key) => {
        this.unidadeEstadualForm.controls[key].markAsPristine();
      });
      this.unidadeEstadualForm.form.markAsPristine();
    }
  }

  adicionarContato(idxArea: number): void {
    this.responsePageAreaContato = this.responsePageAreaContato.map((area, i) =>
      i === idxArea ? {
        ...area, contatos: [...area.contatos, new Contato()]
      } : area
    );
  }

  removerContato(idxArea: number, idxContato: number): void {
    this.responsePageAreaContato = this.responsePageAreaContato.map((area, i) =>
      i === idxArea ? { ...area, contatos: area.contatos.filter((_, j) => j !== idxContato) } : area
    );
    this.houveMudancaForm();
    if (this.unidadeEstadualForm.pristine) {
      this.unidadeEstadualForm.form.markAsDirty();
    }
  }

  private configuraListaContatos() {
    this.listaContatos = [];
    const arrPendencia: { nomeArea: string; qtd: number }[] = [];

    this.responsePageAreaContato.forEach((area) => {
      area.contatos.forEach((item) => {
        item.areaContato = new AreaContato();
        item.areaContato.id = area.id;
        item.areaContato.utilizaCargo = area.utilizaCargo;
        item.pessoa = new Pessoa();
        item.pessoa.id = this.id;
        item.telefone = this.utilityService.retirarFormatacaoTelefone(item.telefone);

        if (!this.isUndefinedOrNull(item.nomeResponsavel) || !this.isUndefinedOrNull(item.telefone) || !this.isUndefinedOrNull(item.email)) {
          this.listaContatos = [
            ...this.listaContatos,
            item
          ];
          this.contatosNaoSalvos++;
          if (arrPendencia.find((pendencia) => pendencia.nomeArea === area.nome)) {
            arrPendencia[arrPendencia.findIndex((pendencia) => pendencia.nomeArea === area.nome)].qtd++;
          } else {
            arrPendencia.push({ nomeArea: area.nome, qtd: 1 });
          }
        }
      });
    });
  }
}
