import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { TableLazyLoadEvent } from 'primeng/table';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiUnidadeEstadualService } from '@cadastro-registro-api/services/api-unidade-estadual.service';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { IPage } from '@utils/interfaces/IPage';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
    selector: 'app-listagem-unidade-estadual',
    templateUrl: './listagem-unidade-estadual.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./listagem-unidade-estadual.component.css'],
})
export class ListagemUnidadeEstadualComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

    constructor(
        private utilityService: UtilityService,
        private breadCrumbPrimeNGService: BreadcrumbService,
        private apiUnidadeEstadual: ApiUnidadeEstadualService
    ) {
        this.breadCrumbPrimeNGService.setItems([
          { label: 'Início ', routerLink: '/' },
          { label: 'Administração', routerLink: '/administracao/inicio' },
          { label: 'Organização Estadual', routerLink: '/administracao/listagem-unidade-estadual' },
          { label: 'Consulta de Organização Estadual', routerLink: '/administracao/listagem-unidade-estadual' },
        ]);
    }

    response: IServiceResponse<IPage<PessoaJuridica>>;
    nrLinhasTabela = 10;
    private debouncer;
    private delay = 500;
    filtroNomeFantasia = '';
    filtrocnpj = '';
    filtroUfSigla = '';
    cols: { field: string; header: string }[];
    @ViewChild('dt') dt: Table;

    ngOnInit() {
        this.cols = [
            { field: 'cnpj', header: 'CNPJ' },
            { field: 'nomeFantasia', header: 'Nome Fantasia' },
            { field: 'ufSigla', header: 'UF' },
        ];
    }

    onChangeFilter() {
        clearTimeout(this.debouncer);
        this.debouncer = setTimeout(() => {
            this.dt.reset();
        }, this.delay);
    }

    get(pagina = 0, sortField = 'nomeFantasia', sortOrder = 1): Promise<IServiceResponse<IPage<PessoaJuridica>>> {
        sortField = sortField || 'nomeFantasia';
        let sort: string;
        sort = sortOrder === 1 ? 'asc' : 'desc';
        const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
        return this.apiUnidadeEstadual.buscaUnidadeEstadual(options);
    }

    carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
        const options = {
            params: new HttpParams().set('page', pagina).set('size', nrLinhas).set('sort', `${sortField},${sortOrder}`),
        };
        options.params = this.utilityService.carregaParamsString(this.filtrocnpj, options.params, 'cnpj');
        options.params = this.utilityService.carregaParamsString(this.filtroUfSigla, options.params, 'ufSigla');
        options.params = this.utilityService.carregaParamsString(
            this.filtroNomeFantasia,
            options.params,
            'nomeFantasia'
        );

        return options;
    }

    loadLazy(event: TableLazyLoadEvent) {
        if (event.rows !== undefined) {
            this.nrLinhasTabela = event.rows;
        }
        this.get(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then((response) => {
            this.response = response;
            this.changeDetectorRef.markForCheck();
        });
    }
}
