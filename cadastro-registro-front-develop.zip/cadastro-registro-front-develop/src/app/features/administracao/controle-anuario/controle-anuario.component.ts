import {AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild} from '@angular/core';
import {NgForm} from '@angular/forms';
import { Router} from '@angular/router';
import {BreadcrumbService} from '@core/breadcrumb/breadcrumb.service';
import DecoupledEditor from '@ckeditor/ckeditor5-build-decoupled-document';
import { EditorConfig } from '@ckeditor/ckeditor5-core';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ControleAnuarioUFTO } from 'src/app/api/models/ControleAnurioUFTO';
import { ApiControleAnuarioUfService } from 'src/app/api/services/api-controle-anuario-uf.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';


@Component({
  selector: 'app-controle-anuario',
  templateUrl: './controle-anuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./controle-anuario.component.css']
})
export class ControleAnuarioComponent implements OnInit, AfterViewInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  public config ;

  public editor = DecoupledEditor;

  listaUfs: Uf[] = [];
  uf: Uf = null;

  habilitaSelecaoUf = false;

  controleAnuarioUf: ControleAnuarioUFTO = new ControleAnuarioUFTO();
  controleAnuarioUfNacional: ControleAnuarioUFTO = new ControleAnuarioUFTO();
  private habilitarFormularioAnuario = true;

  @ViewChild('controleAnuarioForm') controleAnuarioForm: NgForm;
  constructor(
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiControleAnuarioUfService: ApiControleAnuarioUfService,
    private router: Router,
    private keycloakService: KeycloakService,
    private apiUFService: ApiUFService
  ) {

    this.habilitaSelecaoUf =  this.keycloakService.isUsuarioNacional;

    this.breadCrumbPrimeNGService.setItems([
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Controle Anuário', routerLink: '/administracao/controle-anuario-uf' },
    ]);

  }

  ngOnInit() {
    this.inicializaRegistroVazio();
    this.inicializaControleNacionalVazio();
    this.carregaControleNacional();
    this.carregarUfs();
    this.config={
      toolbar: {
        items: [
            'undo', 'redo',
            '|', 'bold', 'italic', 'underline', 'strikethrough',
            '|', 'link',
            '|', 'bulletedList', 'numberedList', 'outdent', 'indent',
            '|', 'alignment:left', 'alignment:right', 'alignment:center', 'alignment:justify'
        ],
        shouldNotGroupWhenFull: false
    }
    } as EditorConfig;
  }

  ngAfterViewInit(): void {
    this.aplicarEstadoFormulario();
    this.changeDetectorRef.markForCheck();
  }

  carregaControleNacional() {
    this.apiControleAnuarioUfService.obterControleAnuarioUflNacional()
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if (response?.data) {
        this.controleAnuarioUfNacional = response.data;
        this.habilitarFormularioAnuario = !!this.controleAnuarioUfNacional.habilitarPreenchimentoAnuario;
        this.aplicarEstadoFormulario();
      }
      this.changeDetectorRef.markForCheck();
    });
  }


  inicializaRegistroVazio() {
    this.controleAnuarioUf = new ControleAnuarioUFTO()
    this.controleAnuarioUf.cooperativaPodePreencher = false
    this.controleAnuarioUf.cooperativaPodeVisualizar = false;
    this.controleAnuarioUf.destacarAnuario = false;
    this.controleAnuarioUf.mostrarpopup = false;
    this.controleAnuarioUf.visualizarPeriodoAtualizacao = false;
    this.controleAnuarioUf.textoPop = '';
    this.controleAnuarioUf.chaveAnuario = 'SESCOOP';

  }

  private inicializaControleNacionalVazio() {
    this.controleAnuarioUfNacional = new ControleAnuarioUFTO();
    this.controleAnuarioUfNacional.habilitarPreenchimentoAnuario = true;
    this.habilitarFormularioAnuario = true;
  }

  private aplicarEstadoFormulario() {
    if (!this.controleAnuarioForm?.form) {
      return;
    }

    if (this.habilitarFormularioAnuario) {
      this.controleAnuarioForm.form.enable();
    } else {
      this.controleAnuarioForm.form.disable();
    }
  }


  public onReady( editor: DecoupledEditor ): void {
    const element = editor.ui.getEditableElement()!;
    const parent = element.parentElement!;
    parent.insertBefore(
      editor.ui.view.toolbar.element!,
      element
    );
  }

  buscarPorUf(){
    this.carregaControleNacional();
    const ufSigla = this.uf ? this.uf.sigla : null;
    this.apiControleAnuarioUfService.obterControleAnuarioUf(ufSigla)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if(response && response.data){
        this.controleAnuarioUf = response.data;
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarUfs(){
    this.apiUFService.buscarUfs().then((response)=>{
      this.listaUfs = (response as unknown as IPage<Uf>).content;
      if(!this.habilitaSelecaoUf){
        this.uf = this.listaUfs.find(uf => uf.sigla == this.keycloakService.getUF());

      }
      this.buscarPorUf();
      this.changeDetectorRef.markForCheck();
    });
  }


  desabilitarControleAnuario(){
    this.uf = null;
    this.apiControleAnuarioUfService.desabilitarControleAnuarioUf(this.controleAnuarioUfNacional.habilitarPreenchimentoAnuario)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.habilitarFormularioAnuario = !!this.controleAnuarioUfNacional?.habilitarPreenchimentoAnuario;
      this.aplicarEstadoFormulario();
      this.buscarPorUf();
      this.changeDetectorRef.markForCheck();
    });
  }

  salvar(): void {
   this.controleAnuarioUf.uf = this.uf ? this.uf.sigla : null;
   this.controleAnuarioUf.habilitarPreenchimentoAnuario = true;
      this.apiControleAnuarioUfService.salvarControleAnuarioUf(this.controleAnuarioUf)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(response => {
        this.controleAnuarioUf = response.data;
        this.changeDetectorRef.markForCheck();
      });

  }

  voltar(){
      this.router.navigate(['/administracao']);
  }
}
