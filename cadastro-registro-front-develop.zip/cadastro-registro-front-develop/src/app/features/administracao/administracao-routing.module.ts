import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from '@auth/auth-guard/auth-guard.service';
import { ListagemAreaContatoComponent } from './areaContato/listagem-area-contato/listagem-area-contato.component';
import { ListagemCriterioAssociacaoComponent } from './criterio-associacao/listagem-criterio-associacao/listagem-criterio-associacao.component';
import { MantemAreaContatoComponent } from './areaContato/mantem-area-contato/mantem-area-contato.component';
import { ListagemCargoComponent } from './cargo/listagem-cargo/listagem-cargo.component';
import { MantemCargoComponent } from './cargo/mantem-cargo/mantem-cargo.component';
import { CertificadoUnidadeEstadualComponent } from './certificado-unidade-estadual/certificado-unidade-estadual.component';
import { ListagemComplementoAnuarioComponent } from './complemento-anuario/listagem-complemento-anuario/listagem-complemento-anuario.component';
import { MantemComplementoAnuarioComponent } from './complemento-anuario/mantem-complemento-anuario/mantem-complemento-anuario.component';
import { AbaDocumentoComponent } from './documento/aba-documento/aba-documento.component';
import { MantemDocumentoComponent } from './documento/mantem-documento/mantem-documento.component';
import { InicioAdministracaoUEComponent } from './inicio-administracao-ue/inicio-administracao-ue.component';
import { InicioAdministracaoComponent } from './inicio-administracao/inicio-administracao.component';
import { ListagemOrgaoComponent } from './orgao/listagem-orgao/listagem-orgao.component';
import { MantemOrgaoComponent } from './orgao/mantem-orgao/mantem-orgao.component';
import { ListagemOrgaoReguladorComponent } from './orgaoRegulador/listagem-orgao-regulador/listagem-orgao-regulador.component';
import { ListagemSindicatoCooperativaComponent } from './sindicato-cooperativa/listagem-sindicato-cooperativa/listagem-sindicato-cooperativa.component';
import { MantemOrgaoReguladorComponent } from './orgaoRegulador/mantem-orgao-regulador/mantem-orgao-regulador.component';
import { ListagemPeriodoAtualizacaoComponent } from './periodoAtualizacao/listagem-periodo-atualizacao/listagem-periodo-atualizacao.component';
import { MantemPeriodoAtualizacaoComponent } from './periodoAtualizacao/mantem-periodo-atualizacao/mantem-periodo-atualizacao.component';
import { ListagemProdutoservicoComponent } from './produtoServico/listagem-produtoservico/listagem-produtoservico.component';
import { MantemProdutoservicoComponent } from './produtoServico/mantem-produtoservico/mantem-produtoservico.component';
import { ListarParametroQuadroSocialComponent } from './quadro-social/listar-parametro-quadro-social/listar-parametro-quadro-social.component';
import { ListarParametroQuadroSocialCooperadoComponent} from './quadro-social/listar-parametro-quadro-social-cooperado/listar-parametro-quadro-social-cooperado.component';
import { ListagemRamoComponent } from './ramo/listagem-ramo/listagem-ramo.component';
import { MantemRamoComponent } from './ramo/mantem-ramo/mantem-ramo.component';
import { RecebeEmailComponent } from './recebeEmail/recebe-email.component';
import { ListagemRegionalUEComponent } from './regional/listagem-regional-ue/listagem-regional-ue.component';
import { ListagemRegionalComponent } from './regional/listagem-regional/listagem-regional.component';
import { MantemRegionalUEComponent } from './regional/mantem-regional-ue/mantem-regional-ue.component';
import { MantemRegionalComponent } from './regional/mantem-regional/mantem-regional.component';
import { ListagemSegmentoComponent } from './segmento/listagem-segmento/listagem-segmento.component';
import { MantemSegmentoComponent } from './segmento/mantem-segmento/mantem-segmento.component';
import { ListagemSistemaVinculacaoComponent } from './sistemaVinculacao/listagem-sistema-vinculacao/listagem-sistema-vinculacao.component';
import { MantemSistemaVinculacaoComponent } from './sistemaVinculacao/mantem-sistema-vinculacao/mantem-sistema-vinculacao.component';
import { ListagemSolicitacaoComponent } from './solicitacao/listagem-solicitacao/listagem-solicitacao.component';
import { MantemSolicitacaoComponent } from './solicitacao/mantem-solicitacao/mantem-solicitacao.component';
import { ListagemTipoEnderecoComponent } from './tipoEndereco/listagem-tipo-endereco/listagem-tipo-endereco.component';
import { MantemTipoEnderecoComponent } from './tipoEndereco/mantem-tipo-endereco/mantem-tipo-endereco.component';
import { ListagemUnidadeEstadualComponent } from './unidadeEstadual/listagem-unidade-estadual/listagem-unidade-estadual.component';
import { MantemUnidadeEstadualComponent } from './unidadeEstadual/mantem-unidade-estadual/mantem-unidade-estadual.component';
import {ListagemControleEmailComponent} from './controle-envio-email/listagem-controle-email/listagem-controle-email.component';
import {MantemControleEmailComponent} from './controle-envio-email/manetem-controle-email/mantem-controle-email.component';
import {ControleAnuarioComponent} from './controle-anuario/controle-anuario.component';
import { CooperativasAtividadesComponent } from './cooperativas-atividades/cooperativas-atividades.component';
import { ListagemValidacaoEmLoteComponent } from './validacao-em-lote/listagem-validacao-em-lote/listagem-validacao-em-lote.component';
import { ListagemControleEmailEstadualComponent } from './controle-envio-email/listagem-controle-email-estadual/listagem-controle-email-estadual.component';
import { AdministracaoInicioGuard } from '@shared/guard/administracao-inicio.guard';
import { ControleAtualizacaoCadastralComponent } from './controle-atualizacao-cadastral/controle-atualizacao-cadastral.component';
import { ControlePortifolioComponent } from './controle-portifolio/controle-portifolio.component';

const routes: Routes = [
    { path: 'inicio', component: InicioAdministracaoComponent, canActivate: [AuthGuardService, AdministracaoInicioGuard] },
    { path: 'inicio-ue', component: InicioAdministracaoUEComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-documento', component: AbaDocumentoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-documento', component: MantemDocumentoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-documento-ue', component: MantemDocumentoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-documento/:id', component: MantemDocumentoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-documento-ue', component: AbaDocumentoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-documento-ue/:id', component: MantemDocumentoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-area-contato', component: ListagemAreaContatoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-area-contato', component: MantemAreaContatoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-area-contato/:id', component: MantemAreaContatoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-ramo', component: ListagemRamoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-ramo', component: MantemRamoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-ramo/:id', component: MantemRamoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-orgao-regulador', component: ListagemOrgaoReguladorComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-sindicato-cooperativa', component: ListagemSindicatoCooperativaComponent, canActivate: [AuthGuardService] },
    { path: 'novo-orgao-regulador', component: MantemOrgaoReguladorComponent, canActivate: [AuthGuardService] },
    { path: 'editar-orgao-regulador/:id', component: MantemOrgaoReguladorComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-segmento', component: ListagemSegmentoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-segmento', component: MantemSegmentoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-segmento/:id', component: MantemSegmentoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-produto-servico', component: ListagemProdutoservicoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-produto-servico', component: MantemProdutoservicoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-produto-servico/:id', component: MantemProdutoservicoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-tipoEndereco', component: ListagemTipoEnderecoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-tipo', component: MantemTipoEnderecoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-tipo/:id', component: MantemTipoEnderecoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-cargo', component: ListagemCargoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-cargo', component: MantemCargoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-cargo/:id', component: MantemCargoComponent, canActivate: [AuthGuardService] },
    {
        path: 'listagem-sistema-vinculacao',
        component: ListagemSistemaVinculacaoComponent,
        canActivate: [AuthGuardService],
    },
    { path: 'novo-sistema-vinculacao', component: MantemSistemaVinculacaoComponent, canActivate: [AuthGuardService] },
    {
        path: 'editar-sistema-vinculacao/:id',
        component: MantemSistemaVinculacaoComponent,
        canActivate: [AuthGuardService],
    },
    { path: 'listagem-orgao', component: ListagemOrgaoComponent, canActivate: [AuthGuardService] },
    { path: 'novo-orgao', component: MantemOrgaoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-orgao/:id', component: MantemOrgaoComponent, canActivate: [AuthGuardService] },
    {
        path: 'listagem-periodo-atualizacao',
        component: ListagemPeriodoAtualizacaoComponent,
        canActivate: [AuthGuardService],
    },
    { path: 'novo-periodo-atualizacao', component: MantemPeriodoAtualizacaoComponent, canActivate: [AuthGuardService] },
    {
        path: 'editar-periodo-atualizacao/:id',
        component: MantemPeriodoAtualizacaoComponent,
        canActivate: [AuthGuardService],
    },
    {
        path: 'certificado-unidade-estadual',
        component: CertificadoUnidadeEstadualComponent,
        canActivate: [AuthGuardService],
    },
    {
        path: 'parametro-quadro-social',
        component: ListarParametroQuadroSocialComponent,
        canActivate: [AuthGuardService],
    },
    {
      path: 'parametro-quadro-social-cooperado',
      component: ListarParametroQuadroSocialCooperadoComponent,
      canActivate: [AuthGuardService],
    },
    {
        path: 'listagem-complemento-anuario',
        component: ListagemComplementoAnuarioComponent,
        canActivate: [AuthGuardService],
    },
    { path: 'complemento-anuario/:id', component: MantemComplementoAnuarioComponent, canActivate: [AuthGuardService] },
    { path: 'complemento-anuario-ue', component: MantemComplementoAnuarioComponent, canActivate: [AuthGuardService] },
    { path: 'novo-complemento-anuario', component: MantemComplementoAnuarioComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-solicitacao', component: ListagemSolicitacaoComponent, canActivate: [AuthGuardService] },
    { path: 'nova-solicitacao', component: MantemSolicitacaoComponent, canActivate: [AuthGuardService] },
    { path: 'editar-solicitacao/:id', component: MantemSolicitacaoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-unidade-estadual', component: ListagemUnidadeEstadualComponent, canActivate: [AuthGuardService] },
    { path: 'editar-unidade-estadual/:id', component: MantemUnidadeEstadualComponent, canActivate: [AuthGuardService] },
    { path: 'editar-unidade-estadual', component: MantemUnidadeEstadualComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-regional', component: ListagemRegionalComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-regional-ue', component: ListagemRegionalUEComponent, canActivate: [AuthGuardService] },
    { path: 'novo-regional', component: MantemRegionalComponent, canActivate: [AuthGuardService] },
    { path: 'editar-regional/:id', component: MantemRegionalComponent, canActivate: [AuthGuardService] },
    { path: 'novo-regional-ue', component: MantemRegionalUEComponent, canActivate: [AuthGuardService] },
    { path: 'editar-regional-ue/:id', component: MantemRegionalUEComponent, canActivate: [AuthGuardService] },
    { path: 'recebe-email', component: RecebeEmailComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-controle-email', component: ListagemControleEmailComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-controle-email-estadual', component: ListagemControleEmailEstadualComponent, canActivate: [AuthGuardService] },
    { path: 'editar-controle-email/:id', component: MantemControleEmailComponent, canActivate: [AuthGuardService] },
    
    
    { path: 'controle-atualizacao-cadastral', component: ControleAtualizacaoCadastralComponent, canActivate: [AuthGuardService] },
    
    { path: 'controle-anuario-uf', component: ControleAnuarioComponent, canActivate: [AuthGuardService] },
    {
        path: 'participacao-cooperativas-atividades',
        component: CooperativasAtividadesComponent,
        canActivate: [AuthGuardService],
    },
    {
        path: 'controle-portifolio',
        component: ControlePortifolioComponent,
        canActivate: [AuthGuardService],
    },
    { path: 'listagem-criterio-associacao', component: ListagemCriterioAssociacaoComponent, canActivate: [AuthGuardService] },
    { path: 'listagem-validacao-em-lote', component: ListagemValidacaoEmLoteComponent, canActivate: [AuthGuardService] },
    { path: '**', redirectTo: 'inicio' },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AdministracaoRoutingModule {}
