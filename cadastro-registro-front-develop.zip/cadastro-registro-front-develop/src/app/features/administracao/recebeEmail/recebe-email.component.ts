import { ChangeDetectionStrategy, Component, Injectable, OnInit } from '@angular/core';
import { RecebeEmail } from '@cadastro-registro-api/models/RecebeEmail';
import { ApiRecebeEmailService } from '@cadastro-registro-api/services/api-recebe-email.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';

@Component({
    selector: 'app-recebe-email',
    templateUrl: './recebe-email.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./recebe-email.component.css'],
})
@Injectable()
export class RecebeEmailComponent implements OnInit {
    kcService: KeycloakService;

    constructor(public keycloakService: KeycloakService, private recebeEmailService: ApiRecebeEmailService) {
        this.kcService = keycloakService;
    }

    optionRadio: boolean;
    dataAtual = new Date();
    recebeEmail: RecebeEmail = null;
    houveAlteracaoForm = false;

    ngOnInit() {
        this.carregaTela();
    }

    carregaTela() {
        this.recebeEmail = new RecebeEmail();
        this.recebeEmail.usuario = this.keycloakService.usuarioLogado.username;
        this.recebeEmail.email = this.keycloakService.usuarioLogado.email;
    }

    houveMudancaForm() {
        this.houveAlteracaoForm = true;
    }

    submeterEmail(optionRadio) {
        if (optionRadio) {
            this.recebeEmailService.aceitaEmail(this.recebeEmail);
        } else {
            this.recebeEmailService.recusaEmail(this.recebeEmail);
        }
    }
}
