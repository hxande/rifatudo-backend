import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RecebeEmailComponent } from '././recebe-email.component';


describe('ListagemPeriodoAtualizacaoComponent', () => {
  let component: RecebeEmailComponent;
  let fixture: ComponentFixture<RecebeEmailComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ RecebeEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecebeEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
