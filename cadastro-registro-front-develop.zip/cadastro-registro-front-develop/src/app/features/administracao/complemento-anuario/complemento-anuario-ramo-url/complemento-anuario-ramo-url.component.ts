import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, EventEmitter, inject, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { ControlContainer, NgForm } from '@angular/forms';
import { ComplementoAnuario } from '@cadastro-registro-api/models/ComplementoAnuario';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiComplementoAnuarioRamoUrlService } from '@cadastro-registro-api/services/api-complemento-anuario-ramo-url.service';
import { ComplementoAnuarioRamoUrl } from '@cadastro-registro-api/models/ComplementoAnuarioRamoUrl';
import { Observable, Subscription } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-complemento-anuario-ramo-url',
  templateUrl: './complemento-anuario-ramo-url.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./complemento-anuario-ramo-url.component.css'],
  viewProviders: [ { provide: ControlContainer, useExisting: NgForm } ]
})
export class ComplementoAnuarioRamoUrlComponent implements OnInit, OnDestroy {

  private  readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() complementoAnuario: ComplementoAnuario;
  @Input() complementoAnuarioCreated: Observable<void>;
  @Output() removedItem = new EventEmitter<void>();
  ramos: Ramo[];
  ramosOrigem: Ramo[];
  ramoSelected: Ramo;

  private complementoAnuarioCreatedSubscription: Subscription;

  private readonly destroyRef = inject(DestroyRef);

  constructor(private apiRamoService: ApiRamoService,
              private confirmationService: ConfirmationService,
              private apiComplementoAnuarioRamoUrlService: ApiComplementoAnuarioRamoUrlService) { }

  ngOnInit() {
    this.apiRamoService.getRamos().then(response => {
      this.ramos = response.data;
      this.ramosOrigem = Object.assign([], this.ramos);
      this.complementoAnuario.complementoAnuarioRamoUrls
        .forEach(complementoAnuarioRamoUrl => {
          const ramoFound = this.ramos.find(ramo => ramo.id === complementoAnuarioRamoUrl.ramoId);
          complementoAnuarioRamoUrl.ramoNome = ramoFound.nome;
          this.removeRamo(ramoFound);
        });
      this.changeDetectorRef.markForCheck();
    });
    this.complementoAnuarioCreatedSubscription = this.complementoAnuarioCreated
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(() => {
      this.ramos = Object.assign([], this.ramosOrigem);
      this.changeDetectorRef.markForCheck();
    });
  }

  addLink() {
    if (this.ramoSelected) {
      const complementoAnuarioRamoUrl = new ComplementoAnuarioRamoUrl();
      complementoAnuarioRamoUrl.ramoNome = this.ramoSelected.nome;
      complementoAnuarioRamoUrl.ramoId = this.ramoSelected.id;

      this.complementoAnuario.complementoAnuarioRamoUrls = [
        ...this.complementoAnuario.complementoAnuarioRamoUrls,
        complementoAnuarioRamoUrl
      ];

      this.removeRamo(this.ramoSelected);

      this.ramos = [ ...this.ramos ];

      this.ramoSelected = null;
    }
  }

  private removeRamo(ramo: Ramo) {
    const ramoSelectedIndexOf = this.ramos.indexOf(ramo);
    this.ramos = this.ramos.filter((_, index) => index !== ramoSelectedIndexOf);
  }

  remove(complementoAnuarioRamoUrl: ComplementoAnuarioRamoUrl): void {
    if (!!complementoAnuarioRamoUrl.id) {
      this.confirmationService.confirm({
        message: 'Deseja excluir o registro?',
        key: 'exlusaoLink',
        accept: () => {
          this.apiComplementoAnuarioRamoUrlService.delete(complementoAnuarioRamoUrl)
          .pipe(takeUntilDestroyed(this.destroyRef))
          .subscribe(() => {
            this.removeRamoUrlFromMemory(complementoAnuarioRamoUrl);
            this.changeDetectorRef.markForCheck();
          });
        }
      });
    } else {
      this.removeRamoUrlFromMemory(complementoAnuarioRamoUrl);
    }
  }

  private removeRamoUrlFromMemory(complementoAnuarioRamoUrl: ComplementoAnuarioRamoUrl): void {
    this.goBackRamo(complementoAnuarioRamoUrl.ramoId);
    this.removeRamoUrl(complementoAnuarioRamoUrl);
  }

  private goBackRamo(ramoId: number): void {
    const ramoFound = this.ramosOrigem.find(ramo => ramo.id === ramoId);
    if (ramoFound) {
      this.ramos = [
        ...this.ramos,
        ramoFound
        ];

      this.ramos.sort((ramoA, ramoB) => ramoA.nome < ramoB.nome ? -1 : 1);
      this.ramos = [ ...this.ramos ];
    }
  }

  private removeRamoUrl(complementoAnuarioRamoUrl: ComplementoAnuarioRamoUrl): void {
    const complementoAnuarioRamoUrlIndexOf = this.complementoAnuario.complementoAnuarioRamoUrls.indexOf(complementoAnuarioRamoUrl);
    this.complementoAnuario.complementoAnuarioRamoUrls = this.complementoAnuario.complementoAnuarioRamoUrls
      .filter((_, index) => index !== complementoAnuarioRamoUrlIndexOf);
    this.removedItem.emit();
  }

  ngOnDestroy(): void {
    this.complementoAnuarioCreatedSubscription.unsubscribe();
  }
}
