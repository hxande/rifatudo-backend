import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemComplementoAnuarioComponent } from './mantem-complemento-anuario.component';

describe('MantemComplementoAnuarioComponent', () => {
  let component: MantemComplementoAnuarioComponent;
  let fixture: ComponentFixture<MantemComplementoAnuarioComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemComplementoAnuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemComplementoAnuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
