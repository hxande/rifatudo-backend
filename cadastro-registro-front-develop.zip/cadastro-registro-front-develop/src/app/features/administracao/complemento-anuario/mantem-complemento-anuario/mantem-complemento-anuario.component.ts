import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { ComplementoAnuario } from '@cadastro-registro-api/models/ComplementoAnuario';
import { ComplementoAnuarioRamoUrl } from '@cadastro-registro-api/models/ComplementoAnuarioRamoUrl';
import { ApiComplementoAnuarioService } from '@cadastro-registro-api/services/api-complemento-anuario.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Uf } from '@localizacao-api/models/Uf';
import { Observable, Subscription, Subject, from } from 'rxjs';
import { mergeMap, tap } from 'rxjs/operators';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiUFService } from '@localizacao-api/public-api';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-mantem-complemento-anuario',
  templateUrl: './mantem-complemento-anuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-complemento-anuario.component.css']
})
export class MantemComplementoAnuarioComponent implements OnInit, OnDestroy {
  @ViewChild('form') form: NgForm;
  @Output() created = new Subject<void>();
  ufs: Uf[];
  ufSelected: Uf;
  complementoAnuario: ComplementoAnuario;
  loaded = false;

  private subscription: Subscription;
  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(private breadCrumbPrimeNGService: BreadcrumbService,
    private route: ActivatedRoute,
    private keycloakService: KeycloakService,
    private apiComplementoAnuarioService: ApiComplementoAnuarioService,
    private apiUf: ApiUFService) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: this.keycloakService.isUsuarioNacional ? '/administracao/inicio' : '/administracao/inicio-oe' },
      { label: 'Organização Estadual', routerLink: '' },
      { label: 'Cadastro de Dados Complementares do Anuário', routerLink: '' }
    ]);
  }

  ngOnInit() {
    this.subscription = this.searchUfs().pipe(
      tap<Uf[] | Uf>((response: Uf | Uf[] | IPage<Uf>) => this.ufs = Array.isArray((response as IPage<Uf>).content) ? (response as IPage<Uf>).content : new Array((response as IPage<Uf>).content as unknown as Uf)),
      mergeMap<Params, Observable<Params>>(() => this.route.params),
      mergeMap<ComplementoAnuario, Observable<IServiceResponse<ComplementoAnuario>> | Observable<ComplementoAnuario>>(
        params => this.findComplementoAnuarioByParams(params))
    ).subscribe(response => {
      this.loadComplementoAnuarioFromResponse(response);
      this.changeDetectorRef.markForCheck();
    });
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  private loadComplementoAnuarioFromResponse(response): void {
    if (response.hasOwnProperty('data')) {
      if (response.data != null) {
        this.complementoAnuario = response.data;
      } else {
        this.complementoAnuario = new ComplementoAnuario();
        this.complementoAnuario.uf = this.keycloakService.getUF();
      }
      if (this.keycloakService.isUsuarioEstadual) {
        this.apiUf.buscarUfPelaSigla(this.complementoAnuario.uf).then(response => {
          this.ufs = new Array<Uf>(response);
          this.ufSelected = this.ufs.find(uf => uf.sigla === this.complementoAnuario.uf);
          this.changeDetectorRef.markForCheck();
        });
      } else if(this.complementoAnuario != null) {
        this.ufSelected = this.ufs.find(uf => uf.sigla === this.complementoAnuario.uf);
      }
    } else if (response instanceof ComplementoAnuario) {
      this.complementoAnuario = response;
    }
    this.loaded = true;
  }

  private findComplementoAnuarioByParams(params: Params): Observable<IServiceResponse<ComplementoAnuario>> | Observable<ComplementoAnuario> {
    if (params['id']) {
      return this.apiComplementoAnuarioService.getById(params['id'] || this.keycloakService.getUF());
    } else if (this.keycloakService.isUsuarioEstadual) {
      return this.apiComplementoAnuarioService.getByUf(this.keycloakService.getUF());
    } else {
      return new Observable<ComplementoAnuario>(observer => observer.next(new ComplementoAnuario()));
    }
  }

  private searchUfs(): Observable<Uf[] | Uf> {
    if (this.keycloakService.isUsuarioEstadual) {
      return from(this.apiUf.buscarUfPelaSigla(this.keycloakService.getUF()));
    } else {
      return from(this.apiUf.buscarUfs());
    }
  }

  save(): void {
    if (this.isEditing()) {
      this.update();
    } else {
      this.create();
    }
  }

  private update(): void {
    this.complementoAnuario.uf = this.ufSelected.sigla;
    this.apiComplementoAnuarioService.update(this.complementoAnuario)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.complementoAnuario.texto = response.data.texto;
      this.complementoAnuario.url = response.data.url;
      this.complementoAnuario.complementoAnuarioRamoUrls.forEach(value => {
        const complementoAnuarioRamoUrl = response.data.complementoAnuarioRamoUrls.find(value1 => value1.ramoId === value.ramoId);
        if (!value.id) {
          value.complementoAnuarioId = complementoAnuarioRamoUrl.complementoAnuarioId;
          value.id = complementoAnuarioRamoUrl.id;
        }
      });
      this.changeDetectorRef.markForCheck();
    });
  }

  private create(): void {
    this.complementoAnuario.uf = this.ufSelected.sigla;
    this.apiComplementoAnuarioService.create(this.complementoAnuario)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if (this.keycloakService.isUsuarioNacional) {
        this.complementoAnuario = new ComplementoAnuario();
        this.complementoAnuario.complementoAnuarioRamoUrls = [];
        this.ufSelected = null;
        this.form.resetForm();
        this.created.next();
      } else {
        this.complementoAnuario.id = response.data.id;
        this.updateComplementoAnuarioRamosUrlsIds(response.data.complementoAnuarioRamoUrls);
      }
      this.changeDetectorRef.markForCheck();
    }, error => {
      if (this.keycloakService.isUsuarioNacional) {
        this.complementoAnuario.uf = null;
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  private updateComplementoAnuarioRamosUrlsIds(newComplementoAnuarioRamosUrls: ComplementoAnuarioRamoUrl[]): void {
    if (this.complementoAnuario.complementoAnuarioRamoUrls) {
      this.complementoAnuario.complementoAnuarioRamoUrls.forEach(complementoAnuarioRamoUrl => {
        const complementoAnuarioRamoUrlSaved = newComplementoAnuarioRamosUrls.find(value => value.ramoId === complementoAnuarioRamoUrl.ramoId);
        complementoAnuarioRamoUrl.id = complementoAnuarioRamoUrlSaved.id;
        complementoAnuarioRamoUrl.complementoAnuarioId = complementoAnuarioRamoUrlSaved.complementoAnuarioId;
      });
    }
  }

  isUsuarioNacional(): boolean {
    return this.keycloakService.isUsuarioNacional;
  }

  isEditing(): boolean {
    return !!this.complementoAnuario.id;
  }

  canDisableUf(): boolean {
    return this.keycloakService.isUsuarioEstadual || (this.keycloakService.isUsuarioNacional && this.isEditing());
  }

  removedItem() {
    if (this.complementoAnuario.complementoAnuarioRamoUrls && this.complementoAnuario.complementoAnuarioRamoUrls.length === 0) {
      this.form.form.markAsPristine();
    }
  }
}
