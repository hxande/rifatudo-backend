import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemComplementoAnuarioComponent } from './listagem-complemento-anuario.component';

describe('ListagemComplementoAnuarioComponent', () => {
  let component: ListagemComplementoAnuarioComponent;
  let fixture: ComponentFixture<ListagemComplementoAnuarioComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemComplementoAnuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemComplementoAnuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
