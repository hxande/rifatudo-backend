import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Observable } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ComplementoAnuario } from '@cadastro-registro-api/models/ComplementoAnuario';
import { ComplementoAnuarioListagemFiltro } from '@cadastro-registro-api/models/ComplementoAnuarioListagemFiltro';
import { ApiComplementoAnuarioService } from '@cadastro-registro-api/services/api-complemento-anuario.service';
import { UtilityService } from '@utils/utility/utility.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-listagem-complemento-anuario',
  templateUrl: './listagem-complemento-anuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-complemento-anuario.component.css'],
})
export class ListagemComplementoAnuarioComponent implements OnInit {
  @ViewChild('dt') dt: Table;
  cols: { field: string; header: string; width: string }[];
  nrLinhasTabela = 10;
  response: IServiceResponse<IPage<ComplementoAnuario>>;
  complementoAnuarioFiltro: ComplementoAnuarioListagemFiltro;
  private debouncer;
  private delay = 500;

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private breadCrumbPrimeNGService: BreadcrumbService,
    private confirmationService: ConfirmationService,
    private apiComplementoAnuarioService: ApiComplementoAnuarioService,
    private utilityService: UtilityService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Organização Estadual', routerLink: '/administracao' },
      { label: 'Consulta de Dados Complementares do Anuário', routerLink: '' },
    ]);
    this.complementoAnuarioFiltro = new ComplementoAnuarioListagemFiltro();
  }

  ngOnInit() {
    this.cols = [
      { field: 'uf', header: 'UF', width: '10%' },
      { field: 'texto', header: 'Texto', width: '100%' },
      { field: 'url', header: 'Link', width: '100%' },
    ];
  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getAll(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe((response) => {
      this.response = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  private getAll(page: number, sortField: string, sortOrder: number): Observable<IServiceResponse<IPage<ComplementoAnuario>>> {
    sortField = sortField || 'uf';
    const sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.assignOptions(page, sortField, sort);
    return this.apiComplementoAnuarioService.getAll(options);
  }

  private assignOptions(page: number, sortField: string, sort: string): { params: HttpParams } {
    const options = {
      params: new HttpParams().set('page', String(page)).set('size', String(this.nrLinhasTabela)).set('sort', `${sortField},${sort}`),
    };
    options.params = this.utilityService.carregaParamsString(this.complementoAnuarioFiltro.uf, options.params, 'uf');
    options.params = this.utilityService.carregaParamsString(this.complementoAnuarioFiltro.texto, options.params, 'texto');
    options.params = this.utilityService.carregaParamsString(this.complementoAnuarioFiltro.url, options.params, 'url');
    return options;
  }

  delete(complementoAnuario: ComplementoAnuario) {
    this.confirmationService.confirm({
      message: 'Deseja excluir o registro?',
      key: 'excluirComplemento',
      accept: () => {
        this.apiComplementoAnuarioService.delete(complementoAnuario)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(() => {
          this.dt.reset();
          this.changeDetectorRef.markForCheck();
        });
      },
    });
  }

  changeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }
}
