import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemCargoComponent } from './mantem-cargo.component';

describe('MantemCargoComponent', () => {
  let component: MantemCargoComponent;
  let fixture: ComponentFixture<MantemCargoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemCargoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemCargoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
