import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Cargo } from '@cadastro-registro-api/models/Cargo';
import { ApiCargoService } from '@cadastro-registro-api/services/api-cargo.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-mantem-cargo',
  templateUrl: './mantem-cargo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-cargo.component.css']
})
export class MantemCargoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cargo: Cargo;

  @ViewChild('cargoForm') cargoForm: NgForm;

  constructor(
    private cargoApi: ApiCargoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.cargo = new Cargo();

    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Cargo', routerLink: '/administracao/listagem-cargo' },
      { label: 'Cadastro de Cargo', routerLink: '/administracao/novo-cargo' }
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-cargo') {
      this.route.params
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        this.cargoApi.get(params['id'])
          .then(res => {
            this.cargo = res.data;
            this.changeDetectorRef.markForCheck();
          });
      });
    } else {
      this.inicializarCargo();
    }
  }

  inicializarCargo() {
    this.cargo = new Cargo();
    this.cargo.ativo = true;
  }

  salvar(): void {
    if (this.cargoForm.invalid) {
      return;
    }
    if (this.cargo.id) {
      this.cargoApi.altera(this.cargo);
    } else {
      this.cargoApi.inclui(this.cargo)
        .then(() => {
          this.cargoForm.reset();
          setTimeout(() => {
            this.inicializarCargo();
            this.changeDetectorRef.markForCheck();
          }, 0);
        });
    }
  }

}
