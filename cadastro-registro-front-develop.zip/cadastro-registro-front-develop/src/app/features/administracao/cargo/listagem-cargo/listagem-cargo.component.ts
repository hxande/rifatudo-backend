import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiCargoService } from '@cadastro-registro-api/services/api-cargo.service';
import { UtilityService } from '@utils/utility/utility.service';
import { Cargo } from '@cadastro-registro-api/models/Cargo';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-listagem-cargo',
  templateUrl: './listagem-cargo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-cargo.component.css']
})
export class ListagemCargoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private cargoApi: ApiCargoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Cargo', routerLink: '/administracao/listagem-cargo' },
      { label: 'Consulta de Cargo', routerLink: '/administracao/listagem-cargo' }
    ]);
   }

  responseCargo: IServiceResponse<IPage<Cargo>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroNome='';
  filtroDetalhamento='';
  filtroTipoPessoa='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'nome', header: 'Nome' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getCargos(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<Cargo>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.cargoApi.listaPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getCargos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseCargo => {
      this.responseCargo = responseCargo;
      this.changeDetectorRef.markForCheck();
    });
  }

  ativarCargo(obj: Cargo){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      key: 'ativarCargo',
      accept: () => {
        this.cargoApi.desativa(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
