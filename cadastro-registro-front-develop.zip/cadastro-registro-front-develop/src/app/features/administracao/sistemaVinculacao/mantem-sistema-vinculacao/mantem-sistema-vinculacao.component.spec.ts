import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemSistemaVinculacaoComponent } from './mantem-sistema-vinculacao.component';

describe('MantemSistemaVinculacaoComponent', () => {
  let component: MantemSistemaVinculacaoComponent;
  let fixture: ComponentFixture<MantemSistemaVinculacaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemSistemaVinculacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemSistemaVinculacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
