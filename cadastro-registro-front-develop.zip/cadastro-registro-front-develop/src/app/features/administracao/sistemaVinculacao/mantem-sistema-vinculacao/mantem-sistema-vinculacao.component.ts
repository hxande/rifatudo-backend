import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SistemaVinculacao } from '@cadastro-registro-api/models/SistemaVinculacao';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { SistemaVinculacaoCooperativaTO } from 'src/app/api/models/SistemaVinculacaoCooperativaTO';
import { SistemaVinculacaoTO } from 'src/app/api/models/SistemaVinculacaoTO';
import { ApiSistemaVinculacaoService } from 'src/app/api/services/api-sistema-vinculacao.service';


@Component({
  selector: 'app-mantem-sistema-vinculacao',
  templateUrl: './mantem-sistema-vinculacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-sistema-vinculacao.component.css']
})
export class MantemSistemaVinculacaoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  sistemaVinculacao: SistemaVinculacaoTO;

  @ViewChild('sistemaVinculacaoForm') sistemaVinculacaoForm: NgForm;
  constructor(
    private sistemaVinculacaoApi: ApiSistemaVinculacaoService,
    private route: ActivatedRoute,
      private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.inicializarSistemaVinculacao();
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Sistema de Cooperativas', routerLink: '/administracao/listagem-sistema-vinculacao' },
      { label: 'Cadastro de Sistema de Cooperativas', routerLink: '/administracao/novo-sistema-vinculacao' }
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-sistema-vinculacao') {
      this.route.params
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        this.sistemaVinculacaoApi.get(params['id'])
          .then(res => {
            this.sistemaVinculacao = res.data;
            this.changeDetectorRef.markForCheck();
          });
      });
    } else {
      this.inicializarSistemaVinculacao();
    }
  }

  inicializarSistemaVinculacao() {
    this.sistemaVinculacao = new SistemaVinculacaoTO();
    this.sistemaVinculacao.detalhamento = '';
    this.sistemaVinculacao.ativo = true;
    this.sistemaVinculacao.listaSistemaVinculacaoCooperativa = [];
  }

  salvar(): void {
    if (this.sistemaVinculacaoForm.invalid) {
      return;
    }
    if (this.sistemaVinculacao.id) {
      this.sistemaVinculacaoApi.altera(this.sistemaVinculacao)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(response => {
        this.sistemaVinculacao = response.data;
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.sistemaVinculacaoApi.cadastrar(this.sistemaVinculacao)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(() => {
          this.sistemaVinculacaoForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() => {
            this.inicializarSistemaVinculacao();
            this.changeDetectorRef.markForCheck();
          }, 0);
          this.changeDetectorRef.markForCheck();
        });
    }
  }

  adicionarCooperativa(event) {

    const listaAtual = this.sistemaVinculacao.listaSistemaVinculacaoCooperativa;
    if(!listaAtual.some(coop => coop.idCooperativa == event.idCooperativa)){
      this.sistemaVinculacao.listaSistemaVinculacaoCooperativa = [... listaAtual, event];
    }
  }

  removerCooperativa(event) {
    event.excluido = true;
    this.atualizarCooperativaLista(this.sistemaVinculacao.listaSistemaVinculacaoCooperativa,event);
  }

  atualizarCooperativaLista(list:SistemaVinculacaoCooperativaTO[], objeto: SistemaVinculacaoCooperativaTO){
    const index = list.findIndex(item => item.idCooperativa === objeto.idCooperativa);

    if (index !== -1) {
      list[index] = objeto;
    }
  }

}
