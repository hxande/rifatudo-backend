import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiSistemaVinculacaoService } from '@cadastro-registro-api/services/api-sistema-vinculacao.service';
import { UtilityService } from '@utils/utility/utility.service';
import { SistemaVinculacao } from '@cadastro-registro-api/models/SistemaVinculacao';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-listagem-sistema-vinculacao',
  templateUrl: './listagem-sistema-vinculacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-sistema-vinculacao.component.css']
})
export class ListagemSistemaVinculacaoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private sistemaVinculacaoApi: ApiSistemaVinculacaoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Sistema de Cooperativas', routerLink: '/administracao/listagem-sistema-vinculacao' },
      { label: 'Consulta de Sistema de Cooperativas', routerLink: '/administracao/listagem-sistema-vinculacao' }
    ]);
   }

  responseSistemaVinculacao: IServiceResponse<IPage<SistemaVinculacao>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroSigla='';
  filtrodescricao='';
  filtrodetalhamento='';
  filtroTipoPessoa='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'sigla', header: 'Sigla' },
      { field: 'descricao', header: 'Descrição' },
      { field: 'detalhamento', header: 'Detalhamento' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getSistemaVinculacaos(pagina = 0, sortField = 'sigla', sortOrder = 1): Promise<IServiceResponse<IPage<SistemaVinculacao>>> {
    sortField = sortField || 'sigla';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.sistemaVinculacaoApi.listaPaginado(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroSigla, options.params, 'sigla');
    options.params = this.utilityService.carregaParamsString(this.filtrodescricao, options.params, 'descricao');
    options.params = this.utilityService.carregaParamsString(this.filtrodetalhamento, options.params, 'detalhamento');
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getSistemaVinculacaos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseSistemaVinculacao => {
      this.responseSistemaVinculacao = responseSistemaVinculacao;
      this.changeDetectorRef.markForCheck();
    });
  }

  ativarSistemaVinculacao(obj: SistemaVinculacao){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      accept: () => {
        this.sistemaVinculacaoApi.desativa(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
