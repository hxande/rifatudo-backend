import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemSistemaVinculacaoComponent } from './listagem-sistema-vinculacao.component';

describe('ListagemSistemaVinculacaoComponent', () => {
  let component: ListagemSistemaVinculacaoComponent;
  let fixture: ComponentFixture<ListagemSistemaVinculacaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemSistemaVinculacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemSistemaVinculacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
