import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemTipoEnderecoComponent } from './mantem-tipo-endereco.component';

describe('MantemTipoEnderecoComponent', () => {
  let component: MantemTipoEnderecoComponent;
  let fixture: ComponentFixture<MantemTipoEnderecoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemTipoEnderecoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemTipoEnderecoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
