import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, OnInit, ViewChild, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TipoEndereco } from '@cadastro-registro-api/models/TipoEndereco';
import { ApiTipoEnderecoService } from '@cadastro-registro-api/services/api-tipo-endereco.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiTipoEnderecoServiceV2 } from 'src/app/api/services/api-tipo-endereco.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-mantem-tipo-endereco',
  templateUrl: './mantem-tipo-endereco.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-tipo-endereco.component.css']
})
export class MantemTipoEnderecoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  tipo: TipoEndereco= {
    id: null,
    nome: '',
    ativo: false,
    enderecoCorrespondencia: false,
    enderecoPrincipal: false,
    ordem:0

  }

  ativo: boolean = false;
  enderecoPrincipal: boolean = false;
  enderecoCorrespondencia: boolean = false;

   @ViewChild('tipoForm') tipoForm: NgForm;

  constructor(
    private tipoApi: ApiTipoEnderecoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private tipoApiV2: ApiTipoEnderecoServiceV2,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Tipo de Endereço', routerLink: '/administracao/listagem-tipoEndereco' },
      { label: 'Cadastro de Tipo de Endereço', routerLink: '/administracao/novo-tipo' },
    ]);
  }

  ngOnInit() {

    if (this.route.snapshot.url[0]?.path === 'editar-tipo') {
      this.route.params
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(params => {
          this.tipoApi.getTipoEndereco(params['id'])
            .then(res => {
              this.tipo = res.data
              this.ativo = res.data.ativo;
              this.enderecoPrincipal = res.data.enderecoPrincipal;
              this.enderecoCorrespondencia = res.data.enderecoCorrespondencia;
              this.changeDetectorRef.markForCheck();
            });
        });
    }else{
      this.inicializarTipo();
    }
  }

  inicializarTipo(){
    this.tipo = new TipoEndereco();
    this.tipo.ativo = true;
    this.tipo.enderecoCorrespondencia = false;
    this.tipo.enderecoPrincipal = false;
  }

  salvar(): void {

    // Atualiza os checkbox de acordo com o que foi marcado
    this.tipo.enderecoCorrespondencia = this.enderecoCorrespondencia;
    this.tipo.enderecoPrincipal = this.enderecoPrincipal;
    this.tipo.ativo = this.ativo;

    if (this.tipoForm.invalid) {
      return;
    }
    if (this.tipo.id) {
      this.tipoApiV2.updatev2(this.tipo);
    } else {
      this.tipoApi.create(this.tipo)
        .then(() => {
          this.tipoForm.reset();
          // Ajuste para que o checkbox reflita corretamente o estado atual da propriedade ATIVO
          setTimeout(() => {
            this.inicializarTipo();
            this.changeDetectorRef.markForCheck();
          }, 0);
        });
    }
  }

}
