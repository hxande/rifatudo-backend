import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiTipoEnderecoService } from '@cadastro-registro-api/services/api-tipo-endereco.service';
import { UtilityService } from '@utils/utility/utility.service';
import { TipoEndereco } from '@cadastro-registro-api/models/TipoEndereco';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-listagem-tipo-endereco',
  templateUrl: './listagem-tipo-endereco.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-tipo-endereco.component.css']
})
export class ListagemTipoEnderecoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private tipoApi: ApiTipoEnderecoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Tipo de Endereço', routerLink: '/administracao/listagem-tipoEndereco' },
      { label: 'Consulta de Tipo de Endereço', routerLink: '/administracao/listagem-tipoEndereco' },
    ]);
   }

  response: IServiceResponse<IPage<TipoEndereco>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroNome='';
  filtroPrincipal = true;
  filtroCorrespondencia = false;
  filtroOrdem: number;
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  filtroTabPrincipal = null;
  filtroTabCorrespondencia = null;
  excluindo = false;
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.filtroOrdem = null;
    this.cols = [
      { field: 'nome', header: 'Nome' },
      { field: 'enderecoPrincipal', header: 'Endereço principal' },
      { field: 'enderecoCorrespondencia', header: 'Endereço correspondência' },
      { field: 'ordem', header: 'Ordem' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getRamos(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<TipoEndereco>>> {
    sortField = sortField || 'ordem';
    let sort: string;
    sort = sortOrder === 1 ? 'desc' : 'asc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.tipoApi.getTiposPage(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
   if(this.filtroOrdem != null) {
      options.params = options.params.set('ordem', this.filtroOrdem + '');
    }
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }

    // Filtro endereço principal e correspondencia
    if(this.filtroTabPrincipal !== null){
      options.params = options.params.set('enderecoPrincipal', this.filtroTabPrincipal + '');
    }

    if(this.filtroTabCorrespondencia !== null){
      options.params = options.params.set('enderecoCorrespondencia', this.filtroTabCorrespondencia + '');
    }

    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getRamos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseDocumento => {
      this.response = responseDocumento;
      this.changeDetectorRef.markForCheck();
    });
  }

  excluir(id){
    if (this.excluindo) {
      return;
    }
    this.confirmationService.confirm({
      message: 'Deseja excluir o Tipo de Endereço?',
      accept: () => {
        this.excluindo = true;
        this.tipoApi.exclui(id)
          .then(() => {
            this.dt.reset();
          })
          .finally(() => {
            this.excluindo = false;
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
