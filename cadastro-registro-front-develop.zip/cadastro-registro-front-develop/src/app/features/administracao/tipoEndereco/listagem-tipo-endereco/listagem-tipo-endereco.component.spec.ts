import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemTipoEnderecoComponent } from './listagem-tipo-endereco.component';

describe('ListagemTipoEnderecoComponent', () => {
  let component: ListagemTipoEnderecoComponent;
  let fixture: ComponentFixture<ListagemTipoEnderecoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemTipoEnderecoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemTipoEnderecoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
