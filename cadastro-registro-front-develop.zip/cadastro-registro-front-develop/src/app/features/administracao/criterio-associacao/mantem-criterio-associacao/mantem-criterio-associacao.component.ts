import { ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiCriterioAssociacaoService } from '@cadastro-registro-api/services/api-criterio-associacao.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { CriterioAssociacaoTO } from '@cadastro-registro-api/models/CriterioAssociacaoTO';

@Component({
  selector: 'app-mantem-criterio-associacao',
  templateUrl: './mantem-criterio-associacao.component.html',
  styleUrls: ['./mantem-criterio-associacao.component.css']
})
export class MantemCriterioAssociacaoComponent implements OnInit {

  private changeDetectorRef = inject(ChangeDetectorRef);

  @Output()
  eventSalvar = new EventEmitter<void>();

  @Input()
  idRamo: number;

  @Input() set concluir(salvar: boolean) {
    if (salvar) {
      this.salvar();
    }
  }

  ramo: Ramo;
  optionsRamo: Ramo[] = [];
  criteriosAssociacao: CriterioAssociacaoTO[] = [];

  constructor(
    private ramoApi: ApiRamoService,
    private apiCriterioAssociacao: ApiCriterioAssociacaoService,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Critério Associação', routerLink: '/administracao/listagem-criterio-associacao' },
      { label: 'Cadastro de Critério de Associação' }
    ]);
  }

  ngOnInit() {
    if (this.idRamo) {
      this.setarRamo();
    } else {
      this.buscarTodosRamos();
    }
  }

  setarRamo() {
    this.ramoApi.getRamo(this.idRamo).then((response) => {
      this.ramo = response;
      // Sobrescreve o array garantindo que o ramo pré-selecionado seja a única/primeira opção
      this.optionsRamo = [this.ramo];
      this.buscarCriteriosPorRamo();
    });
  }

  buscarTodosRamos() {
    // TODO: Substituir pelo método correto da sua API que lista todos os ramos ativos
    // this.ramoApi.getRamos().then((response) => {
    //   this.optionsRamo = response;
    // });
  }

  buscarCriteriosPorRamo() {
    if (this.ramo && this.ramo.id) {
      this.apiCriterioAssociacao.getCriteriosAssociacaoPorRamo(this.ramo.id).subscribe(response => {
        this.criteriosAssociacao = response.data;
      });
    } else {
      this.criteriosAssociacao = [];
    }
  }

  salvar(): void {
    if (!this.ramo || !this.ramo.id) {
      return;
    }

    this.criteriosAssociacao.forEach(ca => ca.sqRamo = this.ramo.id);
    this.criteriosAssociacao = this.criteriosAssociacao.filter(ca => !(ca.excluido && ca.id === null));

    this.apiCriterioAssociacao.salvar(this.criteriosAssociacao).subscribe(response => {
      this.criteriosAssociacao = response.data;
      this.eventSalvar.emit();
    });
  }

  adicionarCriterio() {
    const ca = {} as CriterioAssociacaoTO;
    ca.ativo = true;
    ca.excluido = false;
    ca.id = null;
    this.criteriosAssociacao = [
      ...this.criteriosAssociacao,
      ca
    ];
  }

  excluirCriterio(criterio: CriterioAssociacaoTO) {
    criterio.excluido = true;
  }

}
