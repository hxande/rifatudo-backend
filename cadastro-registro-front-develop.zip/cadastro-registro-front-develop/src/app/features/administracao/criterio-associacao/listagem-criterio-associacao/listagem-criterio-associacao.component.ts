import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';

import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { UtilityService } from '@utils/utility/utility.service';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiCriterioAssociacaoService } from '@cadastro-registro-api/services/api-criterio-associacao.service';
import { CriterioAssociacaoRamoTO } from '@cadastro-registro-api/models/CriterioAssociacaoRamoTO';
import { Observable } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';



@Component({
  selector: 'app-listagem-criterio-associacao',
  templateUrl: './listagem-criterio-associacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-criterio-associacao.component.css']
})
export class ListagemCriterioAssociacaoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private ramoApi: ApiRamoService,
    private apiCriterioAssociacao: ApiCriterioAssociacaoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private  breadCrumbPrimeNGService:BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Critério de Associação', routerLink: '/administracao/listagem-criterio-associacao'}
    ]);
   }

  response: IServiceResponse<IPage<CriterioAssociacaoRamoTO>>;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  filtroNome='';
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ramoSelecionado: number;
  salvarCriterioAssociacao = false;
  modalCriterioAssociacao = false;

  ngOnInit() {
    this.cols = [
        { field: 'nome', header: 'Ramo' },
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getRamos(pagina = 0, sortField = 'nome', sortOrder = 1): Observable<IServiceResponse<IPage<CriterioAssociacaoRamoTO>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.apiCriterioAssociacao.getRamosCriterioAssociacao(options);

  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getRamos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.response = response;
      this.changeDetectorRef.markForCheck();
    });
  }


  editarCriterioAssociacao(idRamo: number){
    this.ramoSelecionado = idRamo;
    this.salvarCriterioAssociacao = false;
    this.modalCriterioAssociacao = true;
  }

  ativarDesativarTodos(ramo: CriterioAssociacaoRamoTO){
    this.confirmationService.confirm({
      message: `O(s) critério(s) de associação deste ramo (${ramo.nome}) será(ão) ${ramo.ativo ? 'inativado(s)' : 'ativado(s)'}. Deseja continuar?`,
      accept: () => {
        ramo.ativo = !ramo.ativo;
        this.apiCriterioAssociacao.ativarDesativarPorRamo(ramo)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(response => {
          this.onChangeFilter();
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }
}
