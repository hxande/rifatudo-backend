import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { TableLazyLoadEvent } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { Solicitacao } from '@cadastro-registro-api/models/Solicitacao';
import { TipoSolicitacao } from '@cadastro-registro-api/models/TipoSolicitacao';
import { ApiSolicitacaoService } from '@cadastro-registro-api/services/api-solicitacao.service';
import { UtilityService } from '@utils/utility/utility.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiTipoSolicitacaoService } from 'src/app/api/services/api-tipo-solicitacao.service';

@Component({
  selector: 'app-listagem-solicitacao',
  templateUrl: './listagem-solicitacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-solicitacao.component.css']
})
export class ListagemSolicitacaoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cols: { field: string, header: string }[];
  nrLinhasTabela = 10;
  filtroStatusSolicitacao = null;
  filtroMotivo = '';
  filtroTipoSolicitacao = '';
  responseSolicitacao: IServiceResponse<IPage<Solicitacao>>;
  listaTipoSolicitacao: TipoSolicitacao[];
  private debouncer;
  private delay = 500;
  @ViewChild('dt') dt: Table;

  constructor(
    private  breadCrumbPrimeNGService:BreadcrumbService,
    private apiSolicitacaoService:ApiSolicitacaoService,
    private apiTipoSolicitacao:ApiTipoSolicitacaoService,
    private utilityService: UtilityService,
  ) {

    this.breadCrumbPrimeNGService.setItems([
      { label: 'Administração ', routerLink: '/administracao/inicio' },
      { label: 'Solicitação', routerLink: '/administracao/listagem-solicitacao' }
    ]);

    this.cols = [
      { field: 'motivoSolicitacao', header: 'Motivo' },
      { field: 'tipoSolicitacao', header: 'Tipo de Solicitação' },
      { field: 'statusSolicitacao', header: 'Ativo' }
    ];
  }

  ngOnInit() {
    this.carregaTela();
  }

  carregaTela(){
    this.listaPaginado();
    this.carregaListaTipoSolicitacao();
    this.carregaListaTipoSolicitacao();
  }

  carregaListaTipoSolicitacao() {
    this.apiTipoSolicitacao.listaAtivos().subscribe( response => {
      if(response) {
        this.listaTipoSolicitacao = response.data;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  listaPaginado(pagina = 0, sortField = 'motivoSolicitacao', sortOrder = 1) {
    sortField = sortField || 'motivoSolicitacao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.apiSolicitacaoService.listaPaginado(options);
  }


  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroMotivo, options.params, 'motivoSolicitacao');
    options.params = this.utilityService.carregaParamsString(this.filtroTipoSolicitacao, options.params, 'tipoSolicitacao');
    options.params = this.utilityService.carregaParamsString(this.filtroStatusSolicitacao, options.params, 'statusSolicitacao');
    if(this.filtroStatusSolicitacao != null){
      options.params = options.params.set('ativo', this.filtroStatusSolicitacao + '');
    }
    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.listaPaginado(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(responseSolicitacao => {
      this.responseSolicitacao = responseSolicitacao;
      this.changeDetectorRef.markForCheck();
    });
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  alteraStatusSolicitacao(solicitacao:Solicitacao){
    this.apiSolicitacaoService.alteraStatusSolicitacao(solicitacao).then( resp => {
        if(resp){
          this.dt.reset();
          this.changeDetectorRef.markForCheck();
        }
    });
  }
}
