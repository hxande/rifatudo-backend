import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Solicitacao } from '@cadastro-registro-api/models/Solicitacao';
import { TipoSolicitacao } from '@cadastro-registro-api/models/TipoSolicitacao';
import { ApiSolicitacaoService } from '@cadastro-registro-api/services/api-solicitacao.service';
import { ApiTipoSolicitacaoService } from 'src/app/api/services/api-tipo-solicitacao.service';

@Component({
    selector: 'app-mantem-solicitacao',
    templateUrl: './mantem-solicitacao.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./mantem-solicitacao.component.css'],
})
export class MantemSolicitacaoComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);
    solicitacao: Solicitacao;
    listaTipoSolicitacao: TipoSolicitacao[];
    quantidadeCaracteresDigitados = 255;
    @ViewChild('solicitacaoForm') solicitacaoForm: NgForm;

    constructor(
        private apiSolicitacaoService: ApiSolicitacaoService,
        private apiTipoSolicitacao: ApiTipoSolicitacaoService,
        private route: ActivatedRoute
    ) {
        this.solicitacao = new Solicitacao();
        this.solicitacao.tipoSolicitacao = new TipoSolicitacao();
    }

    ngOnInit() {
        this.carregaTela();
    }

    carregaTela() {
        this.apiTipoSolicitacao.listaAtivos().subscribe((response) => {
            if (response) {
                this.listaTipoSolicitacao = response.data;
            }
            this.changeDetectorRef.markForCheck();
        });

        if (this.route.snapshot.url[0]?.path === 'editar-solicitacao') {
            this.route.params.subscribe((params) => {
                this.apiSolicitacaoService.get(params['id']).then((res) => {
                    this.solicitacao = res.data;
                    this.changeDetectorRef.markForCheck();
                });
            });
        } else {
            this.inicializarSolicitacao();
        }
    }

    inicializarSolicitacao() {
        this.solicitacao = new Solicitacao();
        this.solicitacao.statusSolicitacao = true;
    }

    salvar() {
        if (this.route.snapshot.url[0]?.path === 'editar-solicitacao') {
            this.apiSolicitacaoService.alterar(this.solicitacao).then((resp) => {
                this.carregaTela();
                this.changeDetectorRef.markForCheck();
            });
        } else {
            this.apiSolicitacaoService.salvar(this.solicitacao).then((resp) => {
                if (resp) {
                    this.inicializarSolicitacao();
                }
                this.changeDetectorRef.markForCheck();
            });
        }
    }

    contaQuantidadeCaracteres(quantidadeDigitados: string) {
        this.quantidadeCaracteresDigitados = 255 - quantidadeDigitados.length;
    }
}
