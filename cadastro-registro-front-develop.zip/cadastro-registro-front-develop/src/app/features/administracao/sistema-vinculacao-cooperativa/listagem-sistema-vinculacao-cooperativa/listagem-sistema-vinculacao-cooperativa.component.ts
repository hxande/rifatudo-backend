import { HttpParams } from '@angular/common/http';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { CooperativaListagemTO } from '@cadastro-registro-api/models/CooperativaListagemTO';
import { ApiCooperativaLeituraService } from '@cadastro-registro-leitura-api/services/api-cooperativa-leitura.service';
import { ApiCooperativaService } from '@cadastro-registro-leitura-api/services/api-cooperativa.service';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { UtilityService } from '@utils/utility/utility.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { SistemaVinculacaoCooperativaTO } from 'src/app/api/models/SistemaVinculacaoCooperativaTO';
import { SistemaVinculacaoTO } from 'src/app/api/models/SistemaVinculacaoTO';
import { saveAs } from 'file-saver';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-listagem-sistema-vinculacao-cooperativa',
  templateUrl: './listagem-sistema-vinculacao-cooperativa.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-sistema-vinculacao-cooperativa.component.css'],
})
export class ListagemSistemaVinculacaoCooperativaComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() sistemaVinculacao: SistemaVinculacaoTO;
  @Output() eventoAdicionarCoop = new EventEmitter<SistemaVinculacaoCooperativaTO>();
  @Output() eventoRemoverCoop = new EventEmitter<SistemaVinculacaoCooperativaTO>();

  @ViewChild('dt') dt: Table;

  public nrLinhasTabela = 10;

  listSistemaVinculacaoCooperativa: SistemaVinculacaoCooperativaTO[];

  cols = [];


  cooperativaSelecionada: CooperativaListagemTO;

  dlgIncluirCoop = false;
  ufSelecionada: string;

  ufs: Uf[];
  results: CooperativaListagemTO[];

  response: IServiceResponse<IPage<CooperativaListagemTO>>;

  constructor(private apiCooperativaService: ApiCooperativaService,
    private apiCooperativaLeituraService: ApiCooperativaLeituraService,
    private utilityService: UtilityService,
    private confirmationService: ConfirmationService,
    private cooperativaLeituraService: ApiCooperativaLeituraService,
    private messageService: MessageService
  ) { }

  ngOnInit(): void {
    this.cols = [

      { field: 'cooperativa.pessoaJuridica.cnpj', header: 'CNPJ' },
      { field: 'cooperativa.pessoaJuridica.nomeFantasia', header: 'Nome Fantasia' },
      { field: 'cooperativa.pessoaJuridica.ramo.nome', header: 'Ramo' },
      { field: 'cooperativa.categoria.descricao', header: 'Grau' },
      { field: 'cooperativa.pessoaJuridica.ufSigla', header: 'UF' },
    ];
  }


  search(event) {

    const options = {
      params: new HttpParams()
    }

    options.params = this.utilityService.carregaParamsString(event.query, options.params, 'textoLivre');

    this.apiCooperativaLeituraService.buscarCooperativasRegistradasListagem(options).subscribe(response => {
      this.results = response.data.content;
      this.results.forEach((entidade) => {
        entidade.cnpj = this.concatenarAtributo(entidade);
      });
      this.changeDetectorRef.markForCheck();
    });

  }

  concatenarAtributo(entidade): string {
    let label: string = '';
    if (entidade) {
      label = entidade.cnpj + ' - ';
      label = entidade.nomeFantasia ? (label += entidade.nomeFantasia) : (label += entidade.razaoSocial);
    }
    return label;
  }

  aoSelecionar(event) {
    if(event?.id){
      this.apiCooperativaService.get(event.id).then((response) => {
        const coop = response.data;
        let sistemaCoop = new SistemaVinculacaoCooperativaTO();
        sistemaCoop.idSistemaVinculacao = this.sistemaVinculacao.id;
        sistemaCoop.idCooperativa = coop.id;
        sistemaCoop.cnpj = coop.pessoaJuridica.cnpj;
        sistemaCoop.nomeFantasia = coop.pessoaJuridica.nomeFantasia;
        sistemaCoop.uf = coop.pessoaJuridica.ufSigla;
        sistemaCoop.grau = coop.categoria.descricao;
        sistemaCoop.ramo = coop.pessoaJuridica.ramo.nome;
        this.eventoAdicionarCoop.emit(sistemaCoop);
        this.dlgIncluirCoop = false;
        this.changeDetectorRef.markForCheck();
      });
    };
  }

  removerCooperativa(evento: SistemaVinculacaoCooperativaTO){
    this.confirmationService.confirm({

      header: 'Remover cooperativa?',
      message: 'A cooperativa será removida do sistema de cooperatidas.',
      accept: () => {
        evento.excluido = true;
        this.eventoRemoverCoop.emit(evento);
      }
    });

  }

  exportarRegistros(){
    this.exportarRelatorio('CADASTRO_SISTEMA_COOPERATIVAS','Cadastro_sistema_cooperativas.xlsx');
  }

  exportarRelatorio(relatorio: string, nomeArquivo: string): void {

    const listaSistemaVinculacao = this.sistemaVinculacao.listaSistemaVinculacaoCooperativa;

    if (listaSistemaVinculacao && listaSistemaVinculacao.length > 0) {
      firstValueFrom(this.cooperativaLeituraService.buscarRelatorioArrayBuffer(relatorio, this.montarOptionsExportacao()))
        .then(response => {
          this.realizarDownloadRelatorio(nomeArquivo, response)
          this.changeDetectorRef.markForCheck();
        });
    } else {
      this.messageService.add({
        severity: 'warn', detail: 'Não existem registros para serem exportados.',
        life: 100000
      });
    }
  }

  private realizarDownloadRelatorio(nomeRelatorio: string, dados): void {
    const blob = new Blob([dados], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, nomeRelatorio);
  }

  montarOptionsExportacao() {
    const options = this.carregaOptions('0', this.sistemaVinculacao.listaSistemaVinculacaoCooperativa.length.toString(), '', 'asc');
    options.params = options.params.set('idSistemaVinculacaoCoop', this.sistemaVinculacao.id + '');

    return options;
  }

  protected carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    if (sortField === 'cnpj' || sortField === 'nomeFantasia') {
      sortField = 'pessoaJuridica.' + sortField;
    }
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };

    return options;
  }

}
