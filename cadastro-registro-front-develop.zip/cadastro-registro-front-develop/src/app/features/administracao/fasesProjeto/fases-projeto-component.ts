import { Component, OnInit, OnDestroy } from '@angular/core';
import {MenuItem} from 'primeng/api';


@Component({
    selector: 'app-fases-projeto-component',
    templateUrl: './fases-projeto-component.html',
    styleUrls: ['./fases-projeto-component.scss']
})
export class FasesProjetoComponent implements OnInit, OnDestroy {

    items: MenuItem[];

    ngOnDestroy(): void {

    }

    ngOnInit(): void {
        this.items = [
            {
                label: 'Cadastro'
            },
            {
                label: 'Validação'
            },
            {
                label: 'Análise de conformidade legal'
            },
            {
                label: 'Visita Técnica'
            },
            {
                label: 'Parecer'
            },
            {
                label: 'Emissão do Certificado de Registro'
            }
        ];
    }
}
