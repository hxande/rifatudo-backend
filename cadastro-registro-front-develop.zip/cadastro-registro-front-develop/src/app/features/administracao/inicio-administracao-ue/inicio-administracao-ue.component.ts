import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

interface LinkItem {
  label: string;
  routerLink: string[];
  icon: string;
  canShow?: boolean;
}

@Component({
  selector: 'app-inicio-administracao-ue',
  templateUrl: './inicio-administracao-ue.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./inicio-administracao-ue.component.css'],
})
export class InicioAdministracaoUEComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);
  itemsLinksCoop: LinkItem[];
  itemsLinksUE: LinkItem[];
  itemsLinksArrecadacao: LinkItem[] = [];
  pessoaJuridica: PessoaJuridica;

  constructor(
    public keycloakService: KeycloakService,
    private dadosGeraisService: ApiDadosGeraisService,
    private breadCrumbPrimeNGService: BreadcrumbService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Administração', routerLink: '/administracao/inicio-ue' },
    ]);
  }

  ngOnInit() {
    this.dadosGeraisService.getPessoaJuridicaPorCnpjSincronizada(this.keycloakService.getEntidade()).then((resp) => {
      this.pessoaJuridica = resp;
      this.carregarTela();
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarTela() {
    this.itemsLinksCoop = [
      { label: 'Documento', routerLink: ['/administracao/listagem-documento-ue'], icon: 'fas fa-file' },
      { label: 'Área de Contato', routerLink: ['/administracao/listagem-area-contato'], icon: 'fas fa-list-ul' }
    ];

    this.itemsLinksUE = [
      { label: 'Cadastro de Organização Estadual',
        routerLink: ['/administracao/editar-unidade-estadual/' + this.pessoaJuridica.id],
        icon: 'fas fa-archway',
        canShow: this.isGestorUE()
      },
      {
        label: 'Dados Complementares do Anuário',
        routerLink: ['/administracao/complemento-anuario-ue'],
        icon: 'fas fa-book',
        canShow: this.isGestorUE(),
      },
      {
        label: 'Aprovação de envio de e-mail',
        routerLink: ['/administracao/recebe-email'],
        icon: 'fas fa-book',
        canShow: true,
      },
      {
        label: 'Período de Atualização',
        routerLink: ['../listagem-periodo-atualizacao'],
        icon: 'fas fa-hourglass-half',
        canShow: true,
      },

      {
        label: 'Controle de envio de e-mails para as cooperativas',
        routerLink: ['../listagem-controle-email-estadual'],
        icon: 'fas fa-envelope',
        canShow: this.isGestorUE()
      },
      {label: 'Anuário', routerLink: ['../controle-anuario-uf'], icon: 'fas fa-bookmark', canShow: true},
      {
        label: 'Atualização Cadastral',
        routerLink: ['../controle-atualizacao-cadastral'],
        icon: 'fas fa-bookmark',
        canShow: this.isGestorUE()
      },
      {label: 'Participação em atividades',
        routerLink: ['../participacao-cooperativas-atividades'],
        icon: 'fas fa-list-alt',
        canShow: this.isGestorUE()
      }
    ];

    this.itemsLinksArrecadacao = [];
  }

  private permissaoValidacaoEmlote(): boolean {
    const uf = this.keycloakService.getUF();
    return uf === "MG" || uf === "PR" || uf === "SP";
  }

  private isGestorUE(): boolean {
    return this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES);
  }
}
