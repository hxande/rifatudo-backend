import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Cargo } from '@cadastro-registro-api/models/Cargo';
import { Orgao } from '@cadastro-registro-api/models/Orgao';
import { OrgaoCargo } from '@cadastro-registro-api/models/OrgaoCargo';
import { OrgaoRamo } from '@cadastro-registro-api/models/OrgaoRamo';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { ApiCargoService } from '@cadastro-registro-api/services/api-cargo.service';
import { ApiOrgaoCargoService } from '@cadastro-registro-api/services/api-orgao-cargo.service';
import { ApiOrgaoRamoService } from '@cadastro-registro-api/services/api-orgao-ramo.service';
import { ApiOrgaoService } from '@cadastro-registro-api/services/api-orgao.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { SelectItem, MessageService } from 'primeng/api';

@Component({
  selector: 'app-mantem-orgao',
  templateUrl: './mantem-orgao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-orgao.component.css']
})
export class MantemOrgaoComponent implements OnInit {

  private changeDetectorRef = inject(ChangeDetectorRef);

  orgao: Orgao;
  vinculos: SelectItem[];
  campoInicioMandatos: SelectItem[];
  optionsCargos: Cargo[];
  optionsRamos: Ramo[];
  orgaosCargos: OrgaoCargo[];
  orgaosRamos: OrgaoRamo[];
  orgaosCargosExcluidos: OrgaoCargo[];
  orgaosRamosExcluidos: OrgaoRamo[];
  existeOrgaoCargo = false;
  todosRamos = false;
  @ViewChild('orgaoForm') orgaoForm: NgForm;

  constructor(
    private orgaoApi: ApiOrgaoService,
    private cargoApi: ApiCargoService,
    private orgaoCargoApi: ApiOrgaoCargoService,
    private orgaoRamoApi: ApiOrgaoRamoService,
    private ramoApi: ApiRamoService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private router: Router,
    private messageService: MessageService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Órgão', routerLink: '/administracao/listagem-orgao' },
      { label: 'Cadastro de Órgão', routerLink: '/administracao/novo-orgao' }
    ]);
    this.vinculos = [
      {label: 'Selecione um vínculo', value:null},
      {label: 'Estatutário Eletivo', value: 'ESTATUTÁRIO ELETIVO'},
      {label: 'Contratação', value: 'CONTRATAÇÃO'}
    ];
   }

  ngOnInit() {
    this.inicializarOrgao();
    this.inicializarCargo();
    this.inicializarRamo();
    if (this.route.snapshot.url[0]?.path === 'editar-orgao') {
      this.route.params.subscribe(params => {
        this.orgaoApi.getOrgao(params['id']).then(res => {

          this.orgao = res.data;

          this.changeDetectorRef.markForCheck();

          if(this.orgao.id){
            this.orgaoCargoApi.getPorOrgao(this.orgao.id).then(res2 => {
              this.orgaosCargos = res2.data;
              this.verificaListaOrgaoCargo();
              this.changeDetectorRef.markForCheck();
            });
          }

          this.atualizarMinimoMembros();
        });
      });
    }
  }

  atualizarMinimoMembros(){

    if(this.orgao.id){
      this.orgaoRamoApi.getPorOrgao(this.orgao.id).then(res3 => {
        this.orgaosRamos = res3.data;
        let minimoMembros = 0;
        for(const orgaoC of this.orgaosCargos){
          if(orgaoC.obrigatorio || orgaoC.diretoriaGdh){
            minimoMembros++;
          }
        }
        this.orgaosRamos = this.orgaosRamos.map(orgaoR =>
          orgaoR.minimoMembro < minimoMembros
            ? {...orgaoR, minimoMembro: minimoMembros}
            : orgaoR
        );
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  inicializaOrgaoRamo(){
    if(this.orgao.id){
      this.orgaoRamoApi.getPorOrgao(this.orgao.id).then(res3 => {
        this.orgaosRamos = res3.data;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  selecionaTodosRamos(){
    let existe = false;
    if(this.todosRamos){
      for( let i = 0; i < this.optionsRamos.length; i++){
        const orgaoRamo = this.criarOrgaoRamo();
        orgaoRamo.ramo = this.optionsRamos[i];
        for( let j = 0; j < this.orgaosRamos.length; j++){
          if(this.optionsRamos[i].id === this.orgaosRamos[j].ramo.id){
            existe = true;
          }
        }
        if(!existe){
          this.orgaosRamos = [...this.orgaosRamos, orgaoRamo];
        }
        existe = false;
      }
    }else{
      this.inicializaOrgaoRamo();
    }
  }

  verificaListaOrgaoCargo(){
    if(this.orgaosCargos.length > 0){
      this.existeOrgaoCargo = true;
    }else{
      this.existeOrgaoCargo = false;
    }

    this.changeDetectorRef.markForCheck();
  }
  inicializarCargo() {
    this.cargoApi.lista().then(res => {
      this.optionsCargos = res.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  inicializarRamo(){
    this.ramoApi.getRamos().then(res => {
      this.optionsRamos = res.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  removerOrgaoCargo(i: number) {
    if(this.orgaosCargos[i].id){
      this.orgaosCargosExcluidos = [
        ...this.orgaosCargosExcluidos,
        this.orgaosCargos[i]
      ];
    }
    this.orgaosCargos = this.orgaosCargos.filter((_, index) => index !== i);
    this.verificaListaOrgaoCargo();
  }

  removerOrgaoRamo(i: number) {
    if(this.orgaosRamos[i].id){
      this.orgaosRamosExcluidos = [
        ...this.orgaosRamosExcluidos,
        this.orgaosRamos[i]
    ];
    }
    this.orgaosRamos = this.orgaosRamos.filter((_, index) => index !== i);
  }

  adicionarOrgaoCargo() {
    const orgao = new OrgaoCargo();
    orgao.obrigatorio = false;
    orgao.diretoriaGdh = false;
    this.orgaosCargos = [
      ...this.orgaosCargos,
      orgao
    ];
    this.verificaListaOrgaoCargo();
  }

  adicionarOrgaoRamo() {
    const or = this.criarOrgaoRamo();
    this.orgaosRamos = [
      ...this.orgaosRamos,
      or
    ];
  }

  criarOrgaoRamo(): OrgaoRamo {
    const or = new OrgaoRamo();
    or.maximoAnos = 1;
    or.minimoMembro = 1;
    or.obrigatorio = false;
    or.obrigatorioLei12690 = false;
    or.obrigatorioLei12690Maior19 = false;
    or.obrigatorioLiquidacao = false;

    return or;
  }

  inicializarOrgao(){
    this.orgao = new Orgao();
    this.orgao.ativo = true;
    this.orgaosCargos = new Array<OrgaoCargo>();
    this.orgaosCargosExcluidos = new Array<OrgaoCargo>();
    this.orgaosRamos = new Array<OrgaoRamo>();
    this.orgaosRamosExcluidos = new Array<OrgaoRamo>();
  }

  salvar(): void {
    if (this.orgaoForm.invalid) {
      return;
    }
    if(!this.validalistaRamos() || !this.validaRamoListaOrgaoRamo()) {
      return;
    }
    // Salvando Orgao
    if (this.orgao.id) {
      this.orgaoApi.update(this.orgao).then(res => {
        this.salvarListaOrgaoCargo();
        this.salvarListaOrgaoRamo();
      });
    } else {
      this.orgaoApi.create(this.orgao).then( res => {
        this.orgao = res.data;
        this.salvarListaOrgaoCargo();
        this.salvarListaOrgaoRamo();
        this.router.navigate(['/administracao/listagem-orgao']);
      });
    }
  }

  validaRamoListaOrgaoRamo() {
    for( let i = 0; i < this.orgaosRamos.length; i++) {
      if(this.orgaosRamos[i].ramo == null) {
        this.messageService.add({ severity: 'warning', detail: 'Ramo é obrigatório.', life: 100000 });
        return false;
      }

      if(this.orgaosRamos[i].ordemExibicao == null) {
        this.messageService.add({ severity: 'warning', detail: 'Posição é obrigatória.', life: 100000 });
        return false;
      }
    }
    return true;
  }

  validalistaRamos() {
    if(this.orgaosRamos == null || this.orgaosRamos.length === 0) {
      this.messageService.add({ severity: 'warning', detail: 'Selecione pelo menos um ramo.', life: 100000 });
      return false;
    }
    return true;
  }
  salvarListaOrgaoCargo(){
    this.orgaosCargos = this.orgaosCargos.map(orgaoCargo => {
      return { ...orgaoCargo, orgao: this.orgao };
    });
    this.orgaosCargos.forEach(orgaoCargo => {
      if(orgaoCargo.id){
        this.orgaoCargoApi.update(orgaoCargo).then(resOrgaoCargo => {
          this.orgaosCargos = this.orgaosCargos.map(oc =>
            oc === orgaoCargo ? resOrgaoCargo.data : oc
          );
          this.changeDetectorRef.markForCheck();
        });
      }else{
        this.orgaoCargoApi.create(orgaoCargo).then(resOrgaoCargo => {
          this.orgaosCargos = this.orgaosCargos.map(oc =>
            oc === orgaoCargo ? resOrgaoCargo.data : oc
          );
          this.changeDetectorRef.markForCheck();
        });
      }

      return orgaoCargo;
    });

    // Excluindo lista de Orgao-Cargo
    for( let i = 0; i < this.orgaosCargosExcluidos.length; i++) {
      this.orgaoCargoApi.delete(this.orgaosCargosExcluidos[i].id);
    }
  }
  salvarListaOrgaoRamo(){
     // Salvando lista de Orgao-Ramo
     this.orgaosRamos = this.orgaosRamos.map(orgaoRamo => {

      const updated = { ...orgaoRamo, orgao: this.orgao };

      if(updated.id) {
        this.orgaoRamoApi.update(updated).then(resOrgaoRamo => {
          this.orgaosRamos = this.orgaosRamos.map(or =>
            or === updated ? resOrgaoRamo.data : or
          );
          this.changeDetectorRef.markForCheck();
        });
      }else {
        this.orgaoRamoApi.create(updated).then(resOrgaoRamo => {
          this.orgaosRamos = this.orgaosRamos.map(or =>
            or === updated ? resOrgaoRamo.data : or
          );
          this.changeDetectorRef.markForCheck();
        });
      }
      return updated;
    });

    // Excluindo lista de Orgao-Ramo
    for( let i = 0; i < this.orgaosRamosExcluidos.length; i++) {
      this.orgaoRamoApi.delete(this.orgaosRamosExcluidos[i].id);
    }
  }



}
