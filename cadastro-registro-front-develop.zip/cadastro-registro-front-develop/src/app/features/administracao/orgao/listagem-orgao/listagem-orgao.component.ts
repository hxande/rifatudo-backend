import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { ApiOrgaoService } from '@cadastro-registro-api/services/api-orgao.service';
import { UtilityService } from '@utils/utility/utility.service';
import { Orgao } from '@cadastro-registro-api/models/Orgao';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-listagem-orgao',
  templateUrl: './listagem-orgao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-orgao.component.css']
})
export class ListagemOrgaoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private orgaoApi: ApiOrgaoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService: BreadcrumbService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Órgão', routerLink: '/administracao/listagem-orgao' },
      { label: 'Consulta de Órgão', routerLink: '/administracao/listagem-orgao' }
    ]);
   }

  response: IServiceResponse<IPage<Orgao>>;
  nrLinhasTabela = 10 ;
  private debouncer;
  private delay = 500;
  filtroNome='';
  filtroCargoNome='';
  filtroVinculo='';
  filtroObrigaResponsavel = null;
  filtroObrigatorio = null;
  filtroAtivo = null;
  filtroNomeiaResponsavel = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'nome', header: 'Nome' },
      { field: 'vinculo', header: 'Vínculo' },
      // { field: 'obrigatorio', header: 'Obrigatório' },
      { field: 'nomeiaResponsavel', header: 'Pode nomear responsável' },
      { field: 'ativo', header: 'Ativo' }
    ];
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  getRamos(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<Orgao>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.orgaoApi.getOrgaosPage(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    options.params = this.utilityService.carregaParamsString(this.filtroVinculo, options.params, 'vinculo');

    // Ativo
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    // Obrigatório
    if(this.filtroObrigatorio != null){
      options.params = options.params.set('obrigatorio', this.filtroObrigatorio);
    }

    // Pode nomear
    if(this.filtroNomeiaResponsavel != null){
      options.params = options.params.set('nomeiaResponsavel', this.filtroNomeiaResponsavel + '');
     }


    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getRamos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(response => {
      this.response = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  desativar(orgao: Orgao){
    this.confirmationService.confirm({
      message: 'Deseja '+(orgao.ativo ? 'desativar' : 'ativar')+' o registro?',
      key: 'desativar',
      accept: () => {
        this.orgaoApi.desativa(orgao.id, (orgao.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }


}
