import { Injectable } from '@angular/core';
import { Mandato } from 'src/app/entities/Mandato';
import { HttpClient } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';

@Injectable({
    providedIn: 'root'
  })
export class ApiMandato {
    constructor(private http: HttpClient) { }

}






