import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';

import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { ApiAreaContatoService } from '@cadastro-registro-api/services/api-area-contato.service';
import { UtilityService } from '@utils/utility/utility.service';
import { AreaContato } from '@cadastro-registro-api/models/AreaContato';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';


@Component({
  selector: 'app-listagem-area-contato',
  templateUrl: './listagem-area-contato.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-area-contato.component.css']
})
export class ListagemAreaContatoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private areaContatoApi: ApiAreaContatoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService:BreadcrumbService,
    private keycloackService: KeycloakService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Área de Contato', routerLink: '/administracao/listagem-area-contato'},
      { label: 'Consulta de Área de Contato', routerLink: '/administracao/listagem-area-contato' }
    ]);
   }

  responseAreaContato: IServiceResponse<IPage<AreaContato>>;
  responseAreaContatoEstadual: IServiceResponse<IPage<AreaContato>>;
  nrLinhasTabela = 10;
  private debouncer: NodeJS.Timeout;
  private delay = 500;
  filtroNome='';
  filtroUf='';
  filtroTipoPessoa='';
  filtroUtilizaCargo = null;
  filtroAtivo = null;
  filtroObrigatorio = null;
  filtroPosicaoTela = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;
  colsEstadual: { field: string, header: string }[];
  @ViewChild('dt2') dt2: Table;
  isUsuarioNacional: boolean;
  isUsuarioEstadual: boolean;
  obrigatorio: boolean;
  uf: string;
  modalAtivarAreaContato = false;
  areaContatoSelecionada: AreaContato;

  ngOnInit() {
   this.isUsuarioEstadual = this.keycloackService.isUsuarioEstadual;
   this.isUsuarioNacional = this.keycloackService.isUsuarioNacional;
   this.uf = this.isUsuarioNacional ? null : this.keycloackService.usuarioLogado.uf;
    this.cols = [
        { field: 'nome', header: 'Descrição' },
        { field: 'utilizaCargo', header: 'Utiliza Cargo' },
        { field: 'ativo', header: 'Ativo' },
        { field: 'obrigatorio', header: 'Obrigatório' },
        { field: 'posicaoTela', header: 'Posição na tela' }
    ];
    if (this.isUsuarioEstadual) {
      this.colsEstadual = [
        { field: 'nome', header: 'Descrição' },
        { field: 'utilizaCargo', header: 'Utiliza Cargo' },
        { field: 'ativo', header: 'Ativo' }
      ];
    } else {
      this.colsEstadual = [
        { field: 'uf', header: 'UF' },
        { field: 'nome', header: 'Descrição' },
        { field: 'utilizaCargo', header: 'Utiliza Cargo' },
        { field: 'ativo', header: 'Ativo' },
        { field: 'obrigatorio', header: 'Obrigatório' },
        { field: 'posicaoTela', header: 'Posição na tela' }
      ];
    }

    this.changeDetectorRef.markForCheck();
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay);
  }

  onChangeFilterEstadual() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt2.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay);
  }

  getAreaContatos(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<AreaContato>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.areaContatoApi.listaPaginado(options);
  }

  getAreaContatosEstadual(pagina = 0, sortField = 'nome', sortOrder = 1): Promise<IServiceResponse<IPage<AreaContato>>> {
    sortField = sortField || 'nome';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptionsEstadual(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return options.params.has("uf") ? this.areaContatoApi.listaEstadualPaginado(options) : this.areaContatoApi.listaEstadualNacionalPaginado(options);
  }

  carregaOptionsEstadual(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const optionsEstadual = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    optionsEstadual.params = this.utilityService.carregaParamsString(this.filtroUf, optionsEstadual.params, 'uf');
    optionsEstadual.params = this.utilityService.carregaParamsString(this.filtroNome, optionsEstadual.params, 'nome');
    if(this.filtroUtilizaCargo != null){
      optionsEstadual.params = optionsEstadual.params.set('utilizaCargo', this.filtroUtilizaCargo + '');
    }
    if(this.filtroAtivo != null){
      optionsEstadual.params = optionsEstadual.params.set('ativo', this.filtroAtivo + '');
    }
    if(this.uf != null) {
      optionsEstadual.params = optionsEstadual.params.set('uf', this.uf + '');
    }
    if (this.filtroObrigatorio != null) {
      optionsEstadual.params = optionsEstadual.params.set('obrigatorio', this.filtroObrigatorio + '');
    }
    if (this.filtroPosicaoTela != null) {
      optionsEstadual.params = optionsEstadual.params.set('posicaoTela', this.filtroPosicaoTela + '');
    }

    return optionsEstadual;

  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNome, options.params, 'nome');
    if(this.filtroUtilizaCargo != null){
      options.params = options.params.set('utilizaCargo', this.filtroUtilizaCargo + '');
    }
    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }
    if (this.filtroObrigatorio != null) {
      options.params = options.params.set('obrigatorio', this.filtroObrigatorio + '');
    }
    if (this.filtroPosicaoTela != null) {
      options.params = options.params.set('posicaoTela', this.filtroPosicaoTela + '');
    }

    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getAreaContatos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .then(responseAreaContato => {
      this.responseAreaContato = responseAreaContato;
      this.changeDetectorRef.markForCheck();
    });
  }

  loadLazyEstadual(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getAreaContatosEstadual(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .then(responseAreaContatoEstadual => {
      this.responseAreaContatoEstadual = responseAreaContatoEstadual;
      this.changeDetectorRef.markForCheck();
    });
  }

  ativarAreaContato(obj: AreaContato){
    this.areaContatoSelecionada = obj;
    this.modalAtivarAreaContato = true;
    // this.confirmationService.confirm({
    //   message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
    //   key: 'ativarAreaContato',
    //   accept: () => {
    //     this.areaContatoApi.desativa(obj.id, (!obj.ativo))
    //       .then(() => this.dt.reset());
    //   }
    // });
  }

  confirmaAtivarAreaContato(){
    this.areaContatoSelecionada.ativo = !this.areaContatoSelecionada.ativo;
    this.areaContatoApi.altera(this.areaContatoSelecionada).then(() => {
      this.modalAtivarAreaContato = false;
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    })
  }
}
