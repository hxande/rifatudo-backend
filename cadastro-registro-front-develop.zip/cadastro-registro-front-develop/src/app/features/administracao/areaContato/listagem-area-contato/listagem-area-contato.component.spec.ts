import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemAreaContatoComponent } from './listagem-area-contato.component';

describe('ListagemAreaContatoComponent', () => {
  let component: ListagemAreaContatoComponent;
  let fixture: ComponentFixture<ListagemAreaContatoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemAreaContatoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemAreaContatoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
