import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemAreaContatoComponent } from './mantem-area-contato.component';

describe('MantemAreaContatoComponent', () => {
  let component: MantemAreaContatoComponent;
  let fixture: ComponentFixture<MantemAreaContatoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemAreaContatoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemAreaContatoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
