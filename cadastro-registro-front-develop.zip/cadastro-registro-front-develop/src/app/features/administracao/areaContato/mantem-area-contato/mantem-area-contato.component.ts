import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AreaContato } from '@cadastro-registro-api/models/AreaContato';
import { ApiAreaContatoService } from '@cadastro-registro-api/services/api-area-contato.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';


@Component({
  selector: 'app-mantem-area-contato',
  templateUrl: './mantem-area-contato.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mantem-area-contato.component.css'],
})
export class MantemAreaContatoComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  areaContato: AreaContato;

  @ViewChild('areaContatoForm') areaContatoForm: NgForm;

  constructor(
    private areaContatoApi: ApiAreaContatoService,
    private route: ActivatedRoute,
    private router: Router,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private keycloackService: KeycloakService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início ', routerLink: '/' },
      { label: 'Administração', routerLink: '/administracao/inicio' },
      { label: 'Área de Contato', routerLink: '/administracao/listagem-area-contato' },
      { label: 'Cadastro de Área de Contato', routerLink: '/administracao/novo-area-contato' },
    ]);
  }

  ngOnInit() {
    if (this.route.snapshot.url[0]?.path === 'editar-area-contato') {
      this.route.params
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        this.areaContatoApi.get(params['id'])
          .then(res => {
            this.areaContato = res.data;
            this.changeDetectorRef.markForCheck();
          });
      });
    } else {
      this.inicializarAreaContato();
    }
  }

  inicializarAreaContato() {
    this.areaContato = new AreaContato();
    this.areaContato.ativo = true;
    this.areaContato.utilizaCargo = false;
    this.areaContato.obrigatorio = false;
  }

  salvar(): void {

    if(!this.areaContato.id){
      this.areaContato.uf = this.keycloackService.isUsuarioNacional ? null : this.keycloackService.usuarioLogado.uf;
    }
    this.updateAreaContato();
    if (this.areaContato.id) {
      this.updateExistingAreaContato();
    } else {
      this.addNewAreaContato();
    }
  }

  private updateAreaContato() {
    this.areaContato.excluido = false;
    if (this.areaContatoForm.invalid) return;
  }

  private updateExistingAreaContato() {
    this.areaContatoApi.altera(this.areaContato)
      .then(() => {
        this.navigateToAreaContatoList();
        this.changeDetectorRef.markForCheck();
      });
  }

  private addNewAreaContato() {
    this.areaContatoApi.inclui(this.areaContato)
      .then(() => {
        this.areaContatoForm.reset();
        setTimeout(() => {
          this.inicializarAreaContato();
          this.changeDetectorRef.markForCheck();
        }, 0);
        this.navigateToAreaContatoList();
        this.changeDetectorRef.markForCheck();
      });
  }

  private navigateToAreaContatoList() {
    this.router.navigate(['/administracao/listagem-area-contato']);
  }
}
