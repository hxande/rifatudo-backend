import { Component, OnInit, Input, Output, EventEmitter, NgZone, AfterContentChecked, OnDestroy, ViewChild, DestroyRef, inject, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { EstruturaIntegracaoTo } from '@cadastro-registro-api/models/estrutura-integracao-to';
import { EstruturaGrupoTo } from '@cadastro-registro-api/models/estrutura-grupo-to';
import { Observable, Subject, Subscription } from 'rxjs';
import { ApiDesempenhoExternoService } from 'src/app/api/services/api-desempenho-lancamento-externo.service';
import { AnuarioDadosNegocioComponent } from '../anuario/anuario-dados-negocio/anuario-dados-negocio.component';
import { EnumTipoRamo } from '../EnumTipoRamo';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-desempenho-lancamento-externo',
  templateUrl: './desempenho-lancamento-externo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./desempenho-lancamento-externo.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class DesempenhoLancamentoExternoComponent implements OnInit, OnDestroy {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);
  private readonly destroyRef = inject(DestroyRef);

  @Input() chaveGrupoParametros: string;
  @Input() idCooperativa: number;
  @Input() ano: number;
  @Input() carregarDadosTela: Observable<void | number>;
  @Input() ramo: number;
  @Output() loadedData = new EventEmitter<EstruturaIntegracaoTo[]>();
  @ViewChild('formDadosNegocio') formDadosNegocio: NgForm;
  @ViewChild('anuarioDadosNegocioComponent') anuarioDadosNegocioComponent: AnuarioDadosNegocioComponent;

  estruturas: EstruturaIntegracaoTo[];
  ajudaSidebarVisivel = false;
  estruturaAberta = 0;
  grupoAberto = 0;
  exporta: boolean;
  opcoes: { label: string; value: boolean; icon: string }[];
  ramosExportacao = [EnumTipoRamo.AGROPECUARIO, EnumTipoRamo.TRABALHO_PRODUCAO_BENS_SERVICO];

  private carregarDadosTelaSubscription: Subscription;
  carregarDadosNegocioSoucoop = new Subject<void>();

  constructor(private apiDesempenhoExternoService: ApiDesempenhoExternoService) { }

  ngOnInit() {
    this.opcoes = [
      { label: 'Sim', value: true, icon: 'fa fa-check' },
      { label: 'Não', value: false, icon: 'fa fa-times' }
    ];
    this.carregarTela();
    this.carregarDadosTelaSubscription = this.carregarDadosTela?.subscribe(() => {
      this.carregarTela()
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarTela() {
    this.carregarDadosNegocioSoucoop.next();
    if (this.chaveGrupoParametros && this.idCooperativa && this.ano) {
      if (this.chaveGrupoParametros === "NEGOCIO") {

        this.apiDesempenhoExternoService.obterNegocio(this.idCooperativa, this.ano)
          .pipe(takeUntilDestroyed(this.destroyRef))
          .subscribe(estruturas => {

            const nomeExportacao = "Negócio - Exportação";
            const podeTerExportacao = this.ramosExportacao.includes(this.ramo);
            const indexExportacao = estruturas.findIndex((e: EstruturaIntegracaoTo) => e.nome === nomeExportacao);

            if (podeTerExportacao) {
              if (indexExportacao === -1) {
                estruturas = [
                  ...estruturas,
                  {
                  id: estruturas.length,
                  nome: nomeExportacao,
                  grupos: [],
                  preenchimentoObrigatorio: false
                }
              ];
              }
            } else {
              if (indexExportacao !== -1) {
                estruturas = estruturas.filter((_, index) => index !== indexExportacao);
              }
            }

            this.estruturas = estruturas;
            this.loadedData.emit(this.estruturas);
            this.changeDetectorRef.markForCheck();
          });

      } else {
        this.apiDesempenhoExternoService.obter(this.chaveGrupoParametros, this.idCooperativa, this.ano)
          .pipe(takeUntilDestroyed(this.destroyRef))
          .subscribe(grupo => {
            this.estruturas = grupo;
            this.loadedData.emit(this.estruturas);
            this.changeDetectorRef.markForCheck();
          });
      }
    }
  }


  ngOnDestroy(): void {
    this.carregarDadosTelaSubscription?.unsubscribe();
  }

  trocaAbas(e) {
    this.estruturaAberta = e.index;
  }

  salvarAnuarioDadosNegocio() {
    this.anuarioDadosNegocioComponent?.salvar();
  }

  onExportaChange(valor: boolean, estrutura: EstruturaIntegracaoTo) {
    estrutura.grupos?.forEach((grupo: EstruturaGrupoTo) => {
      if (Array.isArray(grupo.parametros)) {
        grupo.parametros.forEach((param) => param.podePreencher = valor);
      }
    });
    this.exporta = valor;
  }
}
