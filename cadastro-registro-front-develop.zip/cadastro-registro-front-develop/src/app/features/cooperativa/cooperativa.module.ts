
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CooperativaRoutingModule } from './cooperativa-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { AbaCooperativaComponent } from './aba-cooperativa/aba-cooperativa.component';
import { ConsultaFilialComponent } from './consulta-filial/consulta-filial.component';
import { ListagemCooperaitvaComponent } from './listagem-cooperativa/listagem-cooperativa.component';
import { ListagemCooperativaTransferenciaComponent } from './listagem-cooperativa-transferencia/listagem-cooperativa-transferencia.component';
import { ListagemFilialComponent } from './listagem-filial/listagem-filial.component';
import { MantemAnuarioComponent } from './anuario/mantem-anuario/mantem-anuario.component';
import { ListagemCooperativasAnuarioComponent } from './anuario/listagem-cooperativas-anuario/listagem-cooperativas-anuario.component';
import { AnuarioHomeComponent } from './anuario/anuario-home/anuario-home.component';
import { ComplementoAnuarioInfoComponent } from './anuario/anuario-home/complemento-anuario-info/complemento-anuario-info.component';
import { QuadroSocialRegistradasComponent } from './quadro-social-registradas/quadro-social-registradas.component';
import { DesempenhoLancamentoExternoParamsComponent } from '@shared/desempenho-lancamento-externo/desempenho-lancamento-externo-params/desempenho-lancamento-externo-params.component';
import { RelatorioAnuarioComponent } from './relatorio-anuario/relatorio-anuario.component';
import { AnuarioDadosSociaisComponent } from './anuario-dados-sociais/anuario-dados-sociais.component';
import { AjudaDadosSociaisComponent } from './anuario/anuario-home/abas-ajuda/ajuda-dados-sociais/ajuda-dados-sociais.component';
import { AjudaDadosFinanceirosComponent } from './anuario/anuario-home/abas-ajuda/ajuda-dados-financeiros/ajuda-dados-financeiros.component';
import { AjudaIntercooperacaoComponent } from './anuario/anuario-home/abas-ajuda/ajuda-intercooperacao/ajuda-intercooperacao.component';
import { AjudaContabilFiscalComponent } from './anuario/anuario-home/abas-ajuda/ajuda-contabil-fiscal/ajuda-contabil-fiscal.component';
import { AjudaNegocioComponent } from './anuario/anuario-home/abas-ajuda/ajuda-negocio/ajuda-negocio.component';
import { AjudaDinamicaComponent } from './anuario/anuario-home/abas-ajuda/ajuda-dinamica/ajuda-dinamica.component';
import { AriaLabelInputCustomDirective } from '@shared/diretivas/multi-custom.directive';
import { CooperativaComponent } from './cooperativa.component';
import { AvatarModule } from 'primeng/avatar';
import { TagModule } from 'primeng/tag';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { FileUploadModule } from 'primeng/fileupload';
import { SplitButtonModule } from 'primeng/splitbutton';
import { SolicitacaoSuspensaoComponent } from './solicitacao-suspensao/solicitacao-suspensao.component';
import { ApontarIrregularidadeComponent } from './apontar-irregularidade/apontar-irregularidade.component';
import { SolicitacaoRegularizacaoComponent } from './solicitacao-regularizacao/solicitacao.regularizacao.component';
import { SolicitacaoCancelamentoComponent } from './solicitacao-cancelamento/solicitacao-cancelamento.component';
import { SuspenderCooperativaComponent } from './suspender-cooperativa/suspender-cooperativa.component';
import { ModalComunicacaoOrgaosComponent } from './suspender-cooperativa/modal-comunicacao-orgaos/modal-comunicacao-orgaos.component';
import { AtivarCooperativaComponent } from './ativar-cooperativa/ativar-cooperativa.component';
import { CancelarRegistroComponent } from './cancelar-registro/cancelar-registro.component';
import { SolicitacaoSuspensaoAnaliseComponent } from './solicitacao-suspensao-analise/solicitacao-suspensao-analise.component';
import { ListagemResponsavelComponent } from './listagem-responsavel/listagem-responsavel.component';
import { AnuarioQuadroSocialComponent } from './anuario/anuario-quadro-social/anuario-quadro-social.component';
import { ListagemHistoricoCiclosComponent } from './listagem-historio-ciclos/listagem-historico-ciclos.component';
import { AnuarioDadosNegocioComponent } from './anuario/anuario-dados-negocio/anuario-dados-negocio.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AnuarioNovoComponent } from './anuario/anuario-home/anuario-versao2/anuario-novo/anuario-novo.component';
import { DynamicTabviewComponent } from './anuario/anuario-home/anuario-versao2/componentes/dynamic-tabview/dynamic-tabview.component';

import { DynamicAccordionComponent } from './anuario/anuario-home/anuario-versao2/componentes/dynamic-accordion/dynamic-accordion.component';
import { DynamicFieldComponent } from './anuario/anuario-home/anuario-versao2/componentes/dynamic-field/dynamic-field.component';
import { DynamicWrapperComponent } from './anuario/anuario-home/anuario-versao2/componentes/dynamic-wrapper/dynamic-wrapper.component';
import { InputNumberModule } from 'primeng/inputnumber';
import { ChipsModule } from 'primeng/chips';
import { ProgressStepComponent } from './anuario/anuario-home/anuario-versao2/componentes/progress-step/progress-step.component';
import { ProgressBarModule } from 'primeng/progressbar';

import { DividerModule } from 'primeng/divider';
import { MessageModule } from 'primeng/message';
import { MaskDirective } from './anuario/anuario-home/anuario-versao2/directivas/mask-directive';
import { DynamicAnuarioComponent } from './anuario/anuario-home/anuario-versao2/componentes/dynamic-anuario/dynamic-anuario.component';
import { TesteComponent } from './anuario/anuario-home/anuario-versao2/teste/teste.component';



@NgModule({
  declarations: [
    AbaCooperativaComponent,
    ConsultaFilialComponent,
    ListagemCooperaitvaComponent,
    ListagemCooperativaTransferenciaComponent,
    ListagemFilialComponent,
    MantemAnuarioComponent,
    ListagemCooperativasAnuarioComponent,
    AnuarioHomeComponent,
    AnuarioNovoComponent,
    ComplementoAnuarioInfoComponent,
    QuadroSocialRegistradasComponent,
    ListagemCooperativaTransferenciaComponent,
    DesempenhoLancamentoExternoParamsComponent,
    RelatorioAnuarioComponent,
    AnuarioDadosSociaisComponent,
    AjudaDadosSociaisComponent,
    AjudaDadosFinanceirosComponent,
    AjudaIntercooperacaoComponent,
    AjudaContabilFiscalComponent,
    AjudaNegocioComponent,
    AjudaDinamicaComponent,
    AriaLabelInputCustomDirective,
    CooperativaComponent,
    SolicitacaoSuspensaoComponent,
    ApontarIrregularidadeComponent,
    SolicitacaoRegularizacaoComponent,
    SolicitacaoCancelamentoComponent,
    SuspenderCooperativaComponent,
    ModalComunicacaoOrgaosComponent,
    AtivarCooperativaComponent,
    CancelarRegistroComponent,
    SolicitacaoSuspensaoAnaliseComponent,
    ListagemResponsavelComponent,
    AnuarioQuadroSocialComponent,
    AnuarioDadosNegocioComponent,
    ListagemHistoricoCiclosComponent,
    AnuarioNovoComponent,
    DynamicTabviewComponent,

    DynamicAccordionComponent,
    DynamicFieldComponent,
    DynamicWrapperComponent,
    ProgressStepComponent,
    MaskDirective,
    DynamicAnuarioComponent,
    TesteComponent
     ],
  exports: [
    QuadroSocialRegistradasComponent
  ],
    imports: [
        CommonModule,
        CooperativaRoutingModule,
        SharedModule,
        AvatarModule,
        TagModule,
        DropdownModule,
        ButtonModule,
        DialogModule,
        FileUploadModule,
        SplitButtonModule,
        TagModule,
        FormsModule,
        ReactiveFormsModule,
        InputNumberModule,
        ChipsModule,
        ProgressBarModule,
        DividerModule,
        MessageModule

    ]
})
export class CooperativaModule { }
