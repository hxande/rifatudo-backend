import { ChangeDetectorRef, inject } from '@angular/core';
import { MessageService, SelectItem } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { IPage } from '@utils/interfaces/IPage';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';
import { Usuario } from '@gerencia-usuario-api/models/Usuario';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { CooperativaLeituraService } from 'src/app/api/services/api-cooperativa-leitura.service';
import { CooperativaProcessoRegistroTO } from 'src/app/api/models/CooperativaProcessoRegistroTO';
import { firstValueFrom, Observable } from 'rxjs';

export abstract class ListagemProcessoRegistroComponentGeneric {

  protected readonly changeDetectorRef = inject(ChangeDetectorRef);

  public fases: SelectItem[];
  public response: IServiceResponse<IPage<CooperativaProcessoRegistroTO>>;
  public nrLinhasTabela = 10;
  public responsaveis: Usuario[];
  public modalVisivel: boolean;
  public filtrocnpj = '';
  public filtronomeFantasia = '';
  public filtroprocesso = '';
  public filtroramo: Ramo;
  public filtroRamos: Ramo[];
  public filtrodataAberturaProcesso = '';
  public filtroDataUltimaAnaliseUE = '';
  public filtroPrazoRegistro = '';
  public filtronomeUsuario = '';
  public filtroProgressoMacroOuMicro = '';
  public filtroFases: ProgressoMicroEnum[] = [];
  public filtroTextoLivre = '';
  public optionsDropdownRamo: Ramo[];
  public naoVisualizadas = false;
  public apontamento = false;
  public cols: { field: string, header: string, width: string, sortable: boolean, visible?: boolean }[];
  private cnpjCooperativa: string[] = [];
  private debouncer;
  private delay = 500;

  protected constructor(public cooperativaService: ApiCooperativaService,
                        public usuarioService: ApiUsuarioService,
                        public cooperativaLeituraService: CooperativaLeituraService,
                        public ramoApi: ApiRamoService,
                        public utilityService: UtilityService,
                        public router: Router,
                        public messageService: MessageService) {
    this.fases = [
      { label: 'Validação dos documentos', value: '2' },
      { label: 'Análise de conformidade legal', value: '3' },
      { label: 'Visita técnica', value: '4' },
      { label: 'Parecer', value: '5' },
      { label: 'Cadastro e envio de documentos', value: '1' },
      { label: 'Emissão do certificado de registro', value: '6' },
      { label: 'Deliberação sobre o recurso', value: ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3},
      { label: 'Pré Cadastro', value: '0' },
    ];
  }

  abstract getTable(): Table;
  abstract loadSpecificOptions(options: {params: HttpParams}): void;

  protected getCooperativas(pagina = 0, sortField, sortOrder = 1): Observable<IServiceResponse<IPage<CooperativaProcessoRegistroTO>>> {
    sortField = sortField || 'atualizacaoNaoVisualizada';

    let sort: string;

    if (sortField === 'atualizacaoNaoVisualizada') {
      sort = 'desc';
    } else {
      sort = sortOrder === 1 ? 'asc' : 'desc';
    }

    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);

    return this.cooperativaLeituraService.obterCooperativasEmProcessoRegistroListagem(options);
  }

  protected buscarRamos(): void {
    if(this.optionsDropdownRamo == undefined){
      this.ramoApi.getRamos().then(response => {
        if (response && response.data) {
          this.optionsDropdownRamo = response.data;
        }
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  protected carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    if (sortField === 'cnpj' || sortField === 'nomeFantasia') {
      sortField = 'pessoaJuridica.' + sortField;
    }
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroprocesso, options.params, 'processo');

    // este param (CNPJ ou Nome fantasia) é utilizado no cadastro-registro-leitura - Filtro para a tela
    options.params = this.utilityService.carregaParamsString(this.filtroTextoLivre, options.params, 'textoLivre');

    options.params = this.utilityService.carregaParamsString(this.filtroRamos ? this.filtroRamos.map(r => r.id) : '', options.params, 'ramos');

    if(this.filtroFases && this.filtroFases.length > 0){
      this.getFiltroFases(this.filtroFases,options);
    }
    options.params = this.utilityService.carregaParamsString(this.naoVisualizadas, options.params, 'naoVisualizada');
    options.params = this.utilityService.carregaParamsString(this.apontamento, options.params, 'apontamento');
    options.params = this.utilityService.carregaParamsString(this.filtronomeUsuario, options.params, 'nomeUsuario');
    options.params = this.utilityService.carregaParamsString(this.cnpjCooperativa, options.params, 'cnpjResponsavel');

    this.loadSpecificOptions(options);

    if (this.filtrodataAberturaProcesso) {
      const dataAberturaProcessoFormatted = this.filtrodataAberturaProcesso.split('/').reverse().join('-');
      if (this.isValidDate(dataAberturaProcessoFormatted)) {
        options.params = options.params.set('dataAberturaProcesso', dataAberturaProcessoFormatted);
      }
    }
    if (this.filtroDataUltimaAnaliseUE) {
      const dataUltimaAnaliseUEFormatted = this.filtroDataUltimaAnaliseUE.split('/').reverse().join('-');
      if (this.isValidDate(dataUltimaAnaliseUEFormatted)) {
        options.params = options.params.set('dataUltimaAnaliseUE', dataUltimaAnaliseUEFormatted);
      }
    }
    if (this.filtroPrazoRegistro) {
      const prazoRegistroFormatted = this.filtroPrazoRegistro.split('/').reverse().join('-');
      if (this.isValidDate(prazoRegistroFormatted)) {
        options.params = options.params.set('prazoRegistro', prazoRegistroFormatted);
      }
    }
    return options;
  }

  protected isValidDate(dt: string): boolean {
    return new Date(dt).toString() !== 'Invalid Date';
  }

  onChangeFilter(): void {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.getTable().reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay);
  }

  loadLazy(event: TableLazyLoadEvent): void {
    let nrLinhasTabela = 10;
    let pagina = 0;
    let sortOrder = 1;
    let sortField;
    if (event) {
      nrLinhasTabela = event.rows;
      pagina = event.first / event.rows;
      sortOrder = event.sortOrder;
      sortField = event.sortField;
    }
    this.nrLinhasTabela = nrLinhasTabela;
    this.response = undefined;
    this.getCooperativas(pagina, sortField, sortOrder).subscribe(resp => {
      this.response = resp;
      this.changeDetectorRef.markForCheck();
    });
  }

  onRowSelect(event) {
    this.cooperativaService.marcarComoVisualizada(event.data.id);
    this.router.navigate(['/registro/processo'], { queryParams: { id_cooperativa: event.data.id }, skipLocationChange: false });
  }

  verResponsaveis(cnpj: string): void {
    this.usuarioService.buscarResponsaveis(cnpj).then(res => {
      this.responsaveis = res.data;
      this.modalVisivel = true;
      this.changeDetectorRef.markForCheck();
    });
  }

  filtraPorResponsavel(): void {
    this.cnpjCooperativa = [];
    if (this.filtronomeUsuario) {
      this.usuarioService.buscaUsuarioPorNome(this.filtronomeUsuario).then(respUser => {
        const usuarios = respUser.data;
        this.cnpjCooperativa = usuarios.map(value => value.sqEntidade);
        this.getCooperativas(0, null, 1).subscribe(resp => {
          this.response = resp;
          this.changeDetectorRef.markForCheck();
        });
      });
    } else {
      this.onChangeFilter();
    }
  }

  hideModalResponsaveis(): void {
    this.cnpjCooperativa = [];
  }

  downloadRelatorioAcompahamento() {
    if (this.response && this.response.data) {
      const options = this.carregaOptions('0', this.response.data.totalElements.toString(), '', 'asc');
      options.params = options.params.set('ativo', true + '');

      firstValueFrom(this.cooperativaLeituraService.cooperativaProcessoAcompanhamentoRelatorio(options)).then(response => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Relatorio_acompanhamento.xlsx');
      }).catch(error => {
        if (error.status && error.status === 404) {
          this.messageService.add({ severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000 });
        } else {
          this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
        }
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não existem registros para serem exportados.', life: 100000 });
    }
  }

  exportarTabela() {
    if (this.response && this.response.data) {
      const options = this.carregaOptions('0', this.response.data.totalElements.toString(), '', 'asc');
      options.params = options.params.set('ativo', true + '');

      this.cooperativaService.filtrarCooperativasProcessoRegistroListagemExcel(options).then(response => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Processo_Registro.xlsx');
      }).catch(error => {
        if (error.status && error.status === 404) {
          this.messageService.add({ severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000 });
        } else {
          this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
        }
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não existem registros para serem exportados.', life: 100000 });
    }
  }

  protected exportarRelatorio(tipoRelatorio: string): void {
    this.cooperativaLeituraService
      .buscarRelatorioArrayBuffer(
        tipoRelatorio,
        this.carregaOptions('0', this.response.data.totalElements.toString(), '', 'asc')
      )
      .subscribe({
        next: (response) => this.realizarDownloadRelatorio('Processo_Registro.xlsx', response),
        error: () => {
          this.messageService.add({
            severity: 'error',
            detail: 'Erro ao exportar o relatório.',
            life: 10000
          });
        }
      });
  }
  

private realizarDownloadRelatorio(nomeRelatorio: string, dados): void {
    const blob = new Blob([dados], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, nomeRelatorio);
}

  protected getFiltroFases(filtroFases: ProgressoMicroEnum[], options: { params: HttpParams; }) :void {
    if(filtroFases && filtroFases.length > 0){
      const progressoMicro = ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3;
        var filterMacro = filtroFases.filter(f => f !== progressoMicro);
        var filterMicro = filtroFases.filter(f => f === progressoMicro);
        if(filterMacro && filterMacro.length > 0){
          options.params = this.utilityService.carregaParamsString(filterMacro, options.params, 'progressosMacros');
        }
        if(filterMicro && filterMicro.length > 0){
         options.params = this.utilityService.carregaParamsString(filterMicro[0], options.params, 'progressoMicro');
        }
    }
  }
}


