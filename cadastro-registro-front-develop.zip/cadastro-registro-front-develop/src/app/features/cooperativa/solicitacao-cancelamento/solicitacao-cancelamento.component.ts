import { ChangeDetectorRef, Component, OnInit, Input, Output, EventEmitter, inject } from "@angular/core";
import { Solicitacao } from "@cadastro-registro-api/models/Solicitacao";
import { Repositorio } from "@upload-api/models/Repositorio";
import { CooperativaTO } from "src/app/api/models/CooperativaTO";
import { CooperativaRegistro } from "src/app/api/models/CooperativaRegistro";
import { CooperativaSolicitacao } from "src/app/api/models/CooperativaSolicitacao";
import { CooperativaSolicitacaoCancelamentoTO } from "src/app/api/models/CooperativaSolicitacaoCancelamentoTO";
import { NovaSituacaoEnum } from "src/app/api/models/SituacaoCooperativaEnum";
import { ApiSolicitacaoService } from "src/app/api/services/api-solicitacao.service";

@Component({
    selector: 'app-solicitacao-cancelamento-component',
    templateUrl: './solicitacao-cancelamento.component.html',
    styleUrls: ['./solicitacao-cancelamento.component.css'],
})
export class SolicitacaoCancelamentoComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();

    cooperativaSolicitacaoCancelamentoTO = new CooperativaSolicitacaoCancelamentoTO();
    cooperativaRegistro = new CooperativaRegistro();
    justificativa: string;
    motivo: Solicitacao;
    listaMotivo: Solicitacao[];

    constructor(
        private apiSolicitacaoService: ApiSolicitacaoService
    ) {

    }

    ngOnInit(): void {
        this.carregarListaMotivo();
    }

    carregarListaMotivo() {
        this.apiSolicitacaoService.getListaSolicitacoesAtivas().then((response) => {
            if (response) {
                this.listaMotivo = response.data.filter((elem) => {
                    return elem.tipoSolicitacao.descricaoTipoSolicitacao.toLocaleUpperCase() === 'CANCELAMENTO';
                });
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    cancelar() {
        this.onFechar.emit();
    }

    confirmar() {
        this.cooperativaRegistro.cooperativa = this.cooperativa;
        this.cooperativaRegistro.cooperativa.justificativaSolicitacaoCancelamento = this.justificativa;
        this.cooperativaRegistro.justificativaSolicitacaoCancelamento = this.justificativa;
        this.cooperativaRegistro.cooperativaSolicitacao = new CooperativaSolicitacao();
        if (!!this.motivo) {
            this.cooperativaRegistro.cooperativaSolicitacao.solicitacao = this.motivo;
        }

        this.cooperativaSolicitacaoCancelamentoTO.anexo = this.cooperativaRegistro.anexo;
        this.cooperativaSolicitacaoCancelamentoTO.idCooperativa = this.cooperativa.id;
        this.cooperativaSolicitacaoCancelamentoTO.idSolicitacao = this.cooperativaRegistro.cooperativaSolicitacao.solicitacao.id;
        this.cooperativaSolicitacaoCancelamentoTO.justificativa = this.justificativa;
        this.cooperativaSolicitacaoCancelamentoTO.situacaoCooperativa = NovaSituacaoEnum.CANCELADA
        

        this.cooperativaSolicitacaoCancelamentoTO.tipoAcaoSolicitacao = "OE_SOLICITA";
        this.apiSolicitacaoService.oeSolicitaCancelamento(this.cooperativaSolicitacaoCancelamentoTO).then((coop) => {
            this.onConcluir.emit();
            this.changeDetectorRef.markForCheck();
        });
    }

    verificarRepositorioVazio(repositorio: Repositorio) {
        if (repositorio == null) {
            this.cooperativaRegistro.anexo = null;
        }
    }

}