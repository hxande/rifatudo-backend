import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-relatorio-anuario',
  templateUrl: './relatorio-anuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./relatorio-anuario.component.css']
})
export class RelatorioAnuarioComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() tituloTabela = 'Cooperativas Registradas';

  tabViewIndex = 0;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.fragment.subscribe(fragment => {
      if (fragment === 'filiais') {
        this.tabViewIndex = 1;
      }
      this.changeDetectorRef.markForCheck();
    });
  }

}
