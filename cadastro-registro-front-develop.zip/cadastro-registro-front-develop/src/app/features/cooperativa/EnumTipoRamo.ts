export enum EnumTipoRamo {
    AGROPECUARIO = 1,
    CREDITO = 3,
    SAUDE = 4,
    TRABALHO_PRODUCAO_BENS_SERVICO = 7
}
