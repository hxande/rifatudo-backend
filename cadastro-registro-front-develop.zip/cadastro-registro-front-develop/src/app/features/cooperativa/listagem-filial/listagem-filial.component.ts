import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, ViewChild } from '@angular/core';
import { saveAs } from 'file-saver';
import { MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { Router } from '@angular/router';
import { HttpParams } from '@angular/common/http';
import { ApiFilialService } from '@cadastro-registro-api/services/api-filial.services';
import { TablePagedHandler } from '@shared/table-paged-handler/table-paged-handler';
import {
  PessoaJuridicaFiliacaoListagemTo
} from '@cadastro-registro-leitura-api/models/pessoa-juridica-filiacao-listagem-to';
import {
  ApiPessoaJuridicaFiliacaoService
} from '@cadastro-registro-leitura-api/services/api-pessoa-juridica-filiacao-service';
import { ValidacaoCooperativa } from '../../registro/validacao/validacao-cooperativa.service';
import {SITUACOES_OPTS} from '@shared/constants/situacoes.constant';
import { AverbacaoComponent } from '@shared/averbacao/averbacao.component';
import { Observable } from 'rxjs';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';

@Component({
  selector: 'app-listagem-filial',
  templateUrl: './listagem-filial.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-filial.component.css']
})
export class ListagemFilialComponent implements AfterViewInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @ViewChild('table') table: Table;

  tableHandler: TablePagedHandler<PessoaJuridicaFiliacaoListagemTo>;
  situacoes = SITUACOES_OPTS;
  filtroSituacao = [];
  filtroNomeCnpjMatriz: string;
  showAverbacao: boolean = false

  constructor(
    private apiFilial: ApiFilialService,
    private messageService: MessageService,
    private router: Router,
    private apiPessoaJuridicaFiliacaoService: ApiPessoaJuridicaFiliacaoService,
    public validacaoCooperativa: ValidacaoCooperativa
  ) {
    this.tableHandler = new TablePagedHandler<PessoaJuridicaFiliacaoListagemTo>();
    this.tableHandler.columns = [
      { name: 'nomeFantasiaCnpjMatriz', title: 'Cooperativa', sortable: { fieldName: 'pessoaJuridicaMatriz.nomeFantasia' }, filterable: true },
      { name: 'situacaoMatriz', title: 'Situação Matriz', sortable: { fieldName: 'pessoaJuridicaMatriz.cooperativa.situacao.nome' }, filterable: true },
      { name: 'ufMatriz', title: 'UF Matriz', sortable: { fieldName: 'pessoaJuridicaMatriz.ufSigla' }, filterable: true },
      { name: 'cnpjFilial', title: 'CNPJ Filial', sortable: { fieldName: 'pessoaJuridicaFiliada.cnpj' }, filterable: true },
      { name: 'ufFilial', title: 'UF Filial', sortable: { fieldName: 'pessoaJuridicaFiliada.ufSigla' }, filterable: true },
      { name: 'nomeMunicipioFilial', title: 'Município Filial', sortable: false, filterable: true }
    ];

    this.tableHandler.fetchDataCallback = (options: { params: HttpParams }) => {
      // api-pessoa-juridica-filiacao-service.ts (public) importa por engano o TO de
      // cadastro-registro-api em vez do seu próprio (pessoa-juridica-filiacao-listagem-to.ts);
      // o shape real da resposta é o deste componente - cast documenta a divergência pré-existente.
      return this.apiPessoaJuridicaFiliacaoService.getAll(options) as unknown as
        Observable<IServiceResponse<IPage<PessoaJuridicaFiliacaoListagemTo>>>;
    };
  }

  ngAfterViewInit(): void {
    this.tableHandler.table = this.table;
  }

  abrirModalAverbacao(){
    this.showAverbacao = !this.showAverbacao;
  }

  exportarTabela() {
    if (this.tableHandler.data) {
      const options = this.tableHandler.getPagedOptions('0', this.tableHandler.totalRecords.toString(), '', 'asc');

      this.apiFilial.filtraFilialNaoPaginado(options).then(response => {
        const blob = new Blob([response], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        saveAs(blob, 'Cooperativas_Filiais.xlsx');
        this.changeDetectorRef.markForCheck();
      }).catch(error => {
        if (error.status && error.status === 404) {
          this.messageService.add({
            severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000
          });
        } else {
          this.messageService.add({
            severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000
          });
        }
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.messageService.add({severity: 'warn', detail: 'Não existem registros para serem exportados.', life: 100000});
    }
  }

  consultarFilial(id: number) {
    this.router.navigate(['/cooperativa/consulta-filial'], {
      queryParams: { id: id },
      skipLocationChange: false
    });
  }

  onSituacaoChange(situacaoMatrizArray: string) {
    this.tableHandler.filter[situacaoMatrizArray] = this.filtroSituacao.join();
    this.tableHandler.onChangeFilter();
  }

  onNomeFantasiaCnpjMatrizChange(nomeCnpj: string) {
    this.tableHandler.filter[nomeCnpj] = this.filtroNomeCnpjMatriz;
    this.tableHandler.onChangeFilter();
  }


  transformarNomeId(texto){
    return texto.replace(/[A-Z]/g, function(match) {
      return "-" + match.toLowerCase();
    });
  }

  CancelarModalFilial(){
    this.showAverbacao = false;
  }

}
