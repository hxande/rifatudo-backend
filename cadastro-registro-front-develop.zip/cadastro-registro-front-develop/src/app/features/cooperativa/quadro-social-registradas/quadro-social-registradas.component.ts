import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { ParametroQuadroSocial } from '@cadastro-registro-api/models/ParametroQuadroSocial';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { QuadroSocialParametroQuadro } from '@cadastro-registro-api/models/QuadroSocialParametroQuadro';
import { UtilityService } from '@utils/utility/utility.service';
import { ControlContainer, NgForm } from '@angular/forms';
import { HttpParams } from '@angular/common/http';
import { QuadroSocialService } from '@cadastro-registro-api/services/quadro-social.service';
import { HistoricoQuadroSocialComponent } from '@shared/historico-quadro-social/historico-quadro-social.component';
import { Observable, Subscription } from 'rxjs';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import { QuadroSocialParametroQuadroCooperado } from '@cadastro-registro/models/QuadroSocialParametroQuadroCooperado';
import { PermissaoCooperativa } from '../permissao/permissao.service';

@Component({
  selector: 'app-quadro-social-registradas',
  templateUrl: './quadro-social-registradas.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./quadro-social-registradas.component.css'],
  viewProviders: [ { provide: ControlContainer, useExisting: NgForm } ]
})
export class QuadroSocialRegistradasComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() carregarDadosTela: Observable<Cooperativa | number>;
  @Input() preenchimentoAnuario = false;
  @Output() aoEditarAgrupamento = new EventEmitter<CooperativaPendencia>();
  @ViewChild('historicoQuadroSocial') historicoQuadroSocial: HistoricoQuadroSocialComponent;

  idCooperativa: number;
  pendenciasEditadas: CooperativaPendencia[] = [];
  mapPendencias: Record<string, boolean> = {};
  houveAlteracaoForm = false;
  quadroSociais: QuadroSocial[] = [];
  podeModificarOsCampos = false;
  adicionarQuantidadeTotal = false;
  parametrosQuadroSocial: ParametroQuadroSocial[];
  parametrosQuadroSocialCooperado: ParametroQuadroSocial[];
  modalVisivel: boolean;
  cooperativa: Cooperativa;
  quadroSocialParametroQuadro: QuadroSocialParametroQuadro[];
  quadroSocialParametroQuadroCooperado: QuadroSocialParametroQuadroCooperado[];

  anoAnterior: number;
  anoAtual: number;

  private carregarDadosTelaSubscription: Subscription;

  constructor(
    private quadroSocialService: QuadroSocialService,
    private utilityService: UtilityService,
    private usuario: KeycloakService,
    private permissaoCooperativa: PermissaoCooperativa
  ) {
    this.anoAnterior = new Date().getFullYear() - 1;
    this.anoAtual =  new Date().getFullYear();
  }

  ngOnInit(): void {
    this.carregarDadosTelaSubscription = this.carregarDadosTela?.subscribe(cooperativa => this.resgatarCooperativa(cooperativa));
  }

  getNomeIdDadosAdicionais(index,sufix){
    return [
      'inp-fundamental-incompleto-'+sufix,
      'inp-medio-incompleto-'+sufix,
      'inp-superior-incompleto-'+sufix,
      'inp-superior-completo-'+sufix,
      'inp-pos-graduacao-'+sufix
    ][index]
  }

  atualizaLiberacaoCampo(pendencia): void {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas = [...this.pendenciasEditadas, pendencia];
    }
    this.mapPendencias = { ...this.mapPendencias, [pendencia.bloco]: false };
    this.houveAlteracaoForm = true;

    this.changeDetectorRef.markForCheck();
  }

  atualizarTotaisQuadroSocial(quadroSocialAtual: QuadroSocial): void {
    if (quadroSocialAtual != null) {
      const atualizado: QuadroSocial = { ...quadroSocialAtual };

      this.normalizarQuadroSocial(atualizado);

      if (!Number.isNaN(atualizado.cooperadosHomens) || !Number.isNaN(atualizado.cooperadosMulheres)) {
        atualizado.cooperadosPF = atualizado.cooperadosHomens + atualizado.cooperadosMulheres;
      } else {
        atualizado.cooperadosPF = null;
      }

      if (!Number.isNaN(atualizado.empregadosHomens) || !Number.isNaN(atualizado.empregadosMulheres)) {
        atualizado.empregadosTotal = atualizado.empregadosHomens + atualizado.empregadosMulheres;
      } else {
        atualizado.empregadosTotal = null;
      }

      if (!Number.isNaN(atualizado.cooperadosPF) || !Number.isNaN(atualizado.cooperadosPJ)) {
        atualizado.cooperadosTotal = atualizado.cooperadosPF + atualizado.cooperadosPJ;
      } else {
        atualizado.cooperadosTotal = null;
      }

      if (atualizado.cooperadosPF === 0) atualizado.cooperadosPF = null;
      if (atualizado.cooperadosTotal === 0) atualizado.cooperadosTotal = null;
      if (atualizado.empregadosTotal === 0) atualizado.empregadosTotal = null;

      this.quadroSociais = this.quadroSociais.map(qs =>
        qs === quadroSocialAtual ? atualizado : qs
      );
      this.changeDetectorRef.markForCheck()
    }
  }


  normalizarQuadroSocial(quadroSocialAtual: QuadroSocial): void {
    quadroSocialAtual.empregadosHomens = this.somenteNumeros(quadroSocialAtual.empregadosHomens);
    quadroSocialAtual.empregadosMulheres = this.somenteNumeros(quadroSocialAtual.empregadosMulheres);
    quadroSocialAtual.empregadosTotal = this.somenteNumeros(quadroSocialAtual.empregadosTotal);
    quadroSocialAtual.cooperadosHomens = this.somenteNumeros(quadroSocialAtual.cooperadosHomens);
    quadroSocialAtual.cooperadosMulheres = this.somenteNumeros(quadroSocialAtual.cooperadosMulheres);
    quadroSocialAtual.cooperadosAtivos = this.somenteNumeros(quadroSocialAtual.cooperadosAtivos);
  }

  somenteNumeros(valor): number {
    let saida = null;
    if (valor != null) {
      const valorInteiro = parseInt((String(valor)).replace(/\D+/g, ''), 10);
      if (!Number.isNaN(valorInteiro) && !isNaN(valorInteiro)) {
        if (valorInteiro > 99999999) {
          saida = 99999999;
        } else {
          saida = valorInteiro;
        }
      }
    }
    return saida;
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  limparCamposCooperadosQuadroSocial(quadroSocialAtual: QuadroSocial): void {
    if (quadroSocialAtual.apenasTotalPF) {
      quadroSocialAtual.cooperadosHomens = null;
      quadroSocialAtual.cooperadosMulheres = null;
    } else {
      quadroSocialAtual.cooperadosPF = null;
    }

    this.changeDetectorRef.markForCheck();
  }

  limparCamposTotalCooperadosQuadroSocial(quadroSocialAtual: QuadroSocial): void {
    if (quadroSocialAtual.apenasTotalCooperados) {
      quadroSocialAtual.cooperadosHomens = null;
      quadroSocialAtual.cooperadosMulheres = null;
      quadroSocialAtual.cooperadosPF = null;
      quadroSocialAtual.cooperadosPJ = null;

      quadroSocialAtual.apenasTotalPF = false;
    } else {
      quadroSocialAtual.cooperadosTotal = null;
      quadroSocialAtual.apenasTotalPF = false;
    }

    this.changeDetectorRef.markForCheck();
  }

  limparCamposEmpregadosQuadroSocial(quadroSocial: QuadroSocial): void {
    if (quadroSocial.apenasTotalEmpregados) {
      quadroSocial.empregadosHomens = null;
      quadroSocial.empregadosMulheres = null;
    } else {
      quadroSocial.empregadosTotal = null;
    }

    this.changeDetectorRef.markForCheck();
  }

  regraTotais(valor, total): number {
    let saida = null;
    if (valor != null) {
      let valorInteiro = parseInt((String(valor)).replace(/\D+/g, ''), 10);
      const valorTotal = parseInt((String(total)).replace(/\D+/g, ''), 10);
      if ((!Number.isNaN(valorInteiro) && !Number.isNaN(valorInteiro)) && (!Number.isNaN(valorTotal) && !Number.isNaN(valorTotal))) {
        if (valorInteiro > valorTotal) {
          valorInteiro = valorTotal;
        }
        saida = valorInteiro;

      }
    }
    return saida;
  }

  consultaHistoricoQuadroSocial(): void {
    this.modalVisivel = true;
    this.historicoQuadroSocial.buscaHistorico();
  }

  verificarLiberacaoCampos() {
    if (this.cooperativa) {
      this.quadroSocialService.podePreencherCadastroRegistro(this.cooperativa.id).then((res) => {
        if (res != null && res.data != null) {
          this.podeModificarOsCampos = res.data && this.permissaoCooperativa.permissaoAtualizarCadastro();
          this.changeDetectorRef.markForCheck();
        }
      });
    }
  }

  private atualizaPendenciaChaveManutencao(): void {
    this.quadroSocialService.obterUltimasPendenciasChaveManutencao(this.cooperativa.id).then(res => {
      this.mapPendencias = res.data as unknown as Record<string, boolean>;
      this.changeDetectorRef.markForCheck();
    });
  }

  private obterQuadrosSocialParametroQuadroCooperado(): void {
    const parametroQuadro: QuadroSocialParametroQuadroCooperado[] = [];

    this.quadroSociais.forEach(q => {
      parametroQuadro.push({
        idQuadroSocialParametroQuadroCooperado: {
          sqQuadroSocial: q.id,
          sqParametroQuadroSocial: null
        },
        quantidade: null
      });

      q.parametroQuadrosCooperado = this.parametrosQuadroSocialCooperado.map(p => ({
        idQuadroSocialParametroQuadroCooperado: {
          sqParametroQuadroSocial: p.id,
          sqQuadroSocial: q.id
        },
        quantidade: null
      }));
    });

    this.quadroSocialService.buscarQuadroParametrosPorQuadrosSociaisCooperado(parametroQuadro).then(r => {
      if (r) {
        // buscarQuadroParametrosPorQuadrosSociaisCooperado (public) está tipado como
        // IServiceResponse<any>, mas o backend retorna a lista diretamente, sem wrapper.
        this.quadroSocialParametroQuadroCooperado = (r as unknown as QuadroSocialParametroQuadroCooperado[]);
        this.quadroSociais.forEach(q => {
          q.parametroQuadrosCooperado.forEach(pq => {
            this.quadroSocialParametroQuadroCooperado.forEach(qsp => {
              if (pq.idQuadroSocialParametroQuadroCooperado.sqParametroQuadroSocial === qsp.idQuadroSocialParametroQuadroCooperado.sqParametroQuadroSocial &&
                pq.idQuadroSocialParametroQuadroCooperado.sqQuadroSocial === qsp.idQuadroSocialParametroQuadroCooperado.sqQuadroSocial) {
                pq.quantidade = qsp.quantidade;
              }
            });
          });
        });
        this.quadroSociais = [...this.quadroSociais];
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  private obterQuadrosSocialParametroQuadro(): void {
    const parametroQuadro: QuadroSocialParametroQuadro[] = [];

    this.quadroSociais.forEach(q => {
      parametroQuadro.push({
        idQuadroSocialParametroQuadro: {
          sqQuadroSocial: q.id,
          sqParametroQuadroSocial: null
        },
        quantidade: null
      });
      q.parametroQuadros = this.parametrosQuadroSocial.map(p => ({
        idQuadroSocialParametroQuadro: {
          sqParametroQuadroSocial: p.id,
          sqQuadroSocial: q.id
        },
        quantidade: null
      }));
    });

    this.quadroSocialService.buscarQuadroParametrosPorQuadrosSociais(parametroQuadro).then(r => {
      if (r) {
        // buscarQuadroParametrosPorQuadrosSociais (public) está tipado como IServiceResponse<any>,
        // mas o backend retorna a lista diretamente, sem wrapper.
        this.quadroSocialParametroQuadro = (r as unknown as QuadroSocialParametroQuadro[]);
        this.quadroSociais.forEach(q => {
          q.parametroQuadros.forEach(pq => {
            this.quadroSocialParametroQuadro.forEach(qsp => {
              if (pq.idQuadroSocialParametroQuadro.sqParametroQuadroSocial === qsp.idQuadroSocialParametroQuadro.sqParametroQuadroSocial &&
                pq.idQuadroSocialParametroQuadro.sqQuadroSocial === qsp.idQuadroSocialParametroQuadro.sqQuadroSocial) {
                pq.quantidade = qsp.quantidade;
              }
            });
          });
        });
        this.quadroSociais = [...this.quadroSociais];
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  private carregaOptionsParametro(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`),
      reportProgress: true,
    };

    options.params = this.utilityService.carregaParamsString(true, options.params, 'ativo');

    return options;
  }

  private obterParametrosAdicionais() {
    const options = this.carregaOptionsParametro('0', '999', 'id', 'asc');
    this.quadroSocialService.getParametroQuadroSocialPaginado(options).then(p => {
      if (p && p.content) {
        this.parametrosQuadroSocial = p.content;
        this.obterQuadrosSocialParametroQuadro();
        //this.obterQuadrosSocialParametroQuadroCooperado();
      }
    });

  }

  private obterParametrosAdicionaisCooperados() {
    const options = this.carregaOptionsParametro('0', '999', 'id', 'asc');

    this.quadroSocialService.getParametroQuadroSocialCooperadoPaginado(options).then(p => {
      if (p && p.content) {
        this.parametrosQuadroSocialCooperado = p.content;
        //this.obterQuadrosSocialParametroQuadro();
        this.obterQuadrosSocialParametroQuadroCooperado();
      }
    });
  }

  private atualizaBloqueoCamposQs(): void {
    if (this.quadroSociais) {
      this.quadroSociais.forEach(qs => {
        if (qs.id) {
          if (!qs.cooperadosMulheres && !qs.cooperadosHomens && qs.cooperadosPF) {
            qs.apenasTotalPF = true;
          }

          if (!qs.cooperadosMulheres && !qs.cooperadosHomens && !qs.cooperadosPF && !qs.cooperadosPJ && qs.cooperadosTotal) {
            qs.apenasTotalPF = false;
            qs.apenasTotalCooperados = true;
          }

          if (!qs.empregadosHomens && !qs.empregadosMulheres && qs.empregadosTotal) {
            qs.apenasTotalEmpregados = true;
          }
        }
      });
      this.quadroSociais = [...this.quadroSociais];
      this.changeDetectorRef.markForCheck();
    }
  }

  private resgatarCooperativa(cooperativa: Cooperativa | number) {
    if (typeof cooperativa === 'number') {
      this.idCooperativa = cooperativa;
      this.quadroSocialService.getCooperativa(this.idCooperativa).then((res) => {
        this.cooperativa = res.data;
        this.resgatarQuadroSocial();
      });
    } else {
      this.cooperativa = cooperativa;
      this.resgatarQuadroSocial();
    }
  }

  private resgatarQuadroSocial(): void {
    this.verificarLiberacaoCampos();
    this.atualizaPendenciaChaveManutencao();
    this.obterParametrosAdicionais();
    this.obterParametrosAdicionaisCooperados();

    const anoAtual = new Date().getFullYear();

    this.quadroSociais = this.cooperativa.quadrosSociais;

    const anoBase = anoAtual - 1;
    let quadroSocialAnoBase = null;
    this.quadroSociais.forEach((quadro) => {
      if (quadro.ano === anoBase) {
        quadroSocialAnoBase = quadro;
      }
    });

    if (!quadroSocialAnoBase) {
      quadroSocialAnoBase = new QuadroSocial();
      quadroSocialAnoBase.ano = anoBase;
      this.quadroSociais = [...this.quadroSociais, quadroSocialAnoBase];
    }

    if (this.quadroSociais.filter(qs => qs.ano === anoAtual).length === 0) {
      const quadroSocialAnoAtual = new QuadroSocial();
      if(quadroSocialAnoAtual.empregadosTotal == null) {
        Object.assign(quadroSocialAnoAtual, {
          ano: anoAtual,
          cooperadosPF: 0,
          cooperadosPJ: 0,
          cooperadosTotal: 0,
          empregadosHomens: 0,
          empregadosMulheres: 0,
          empregadosTotal: 0,
          cooperadosHomens: 0,
          cooperadosMulheres: 0,
          cooperadosAtivos: 0,
        });
      }
      this.quadroSociais = [...this.quadroSociais, quadroSocialAnoAtual];
    }

    this.atualizaBloqueoCamposQs();
  }


  get isNacional() {
    return this.usuario.isUsuarioNacional;
  }

  get isEstadual() {
    return this.usuario.isUsuarioEstadual;
  }

  camposDisponiveis(quadroSocial: QuadroSocial) {
    if (!this.isNacional && quadroSocial.ano === this.anoAnterior ) {
      return true;
    }
  }

}
