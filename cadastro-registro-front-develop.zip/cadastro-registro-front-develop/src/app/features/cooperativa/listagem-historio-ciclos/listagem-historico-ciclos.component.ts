import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, Input, OnInit } from '@angular/core';
import { Usuario } from '@gerencia-usuario-api/models/Usuario';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';
import { CooperativaHistoriCiclos } from 'src/app/api/models/CooperativaHistoricoCiclos';
import { ApiCooperativaHistoricoCiclos } from 'src/app/api/services/api-cooperativa.historico-ciclos';

@Component({
    selector: 'app-listagem-historico-ciclos-component',
    templateUrl: './listagem-historico-ciclos.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./listagem-historico-ciclos.component.css'],
  })
  export class ListagemHistoricoCiclosComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() sqPessoa: number;
    ciclos: CooperativaHistoriCiclos;
    dadosHistorico: { nome: string; status: string }[] = [];
    anos = [];
    anoSelecionado = new Date().getFullYear() -1 

    constructor(
      private apiCooperativaHistoricoCiclos: ApiCooperativaHistoricoCiclos
    ){

    }

    ngOnInit(): void {
      const currentYear = new Date().getFullYear() - 1;
      this.anos = Array.from({ length: 7 }, (_, i) => currentYear - i)
        .map(ano => ({
          label: `Ciclo ${ano + 1} (Ano calendário ${ano})`,
          value: ano
        }));
      this.buscarPorAno();
    }

    buscarPorAno() {
      this.dadosHistorico = null;
      this.apiCooperativaHistoricoCiclos.getListaCiclos(this.sqPessoa, this.anoSelecionado).then((res) => {
        this.ciclos = res;
        this.changeDetectorRef.markForCheck();
      });
    }

    capitalize(text: string): string {
      if (!text) return '';
      return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
    }

  }