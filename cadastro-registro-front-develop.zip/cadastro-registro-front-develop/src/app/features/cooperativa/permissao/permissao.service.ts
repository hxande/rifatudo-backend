import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
    providedIn: 'root',
})
export class PermissaoCooperativa {

    
    constructor(
        private keycloakService: KeycloakService,
    ) { }

    permissaoVisualizarCadastro(){
        return true;
    }

    permissaoExportarCertificadoRegistroERegularidade(){
        return true;
    }

    permissaoPreencherAnuarioCoop(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_ANA_DADOS) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.CO_GES);
        
    }

    permissaoSomenteConsulta(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_VIS);
    }

    permissaoAtualizarCadastro(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_ANA_DADOS) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.CO_GES);
    }

    permissaoTornarIrregular(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoTornarRegular(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoSolicitarRegularizacao(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoRegularizar(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES);
    }

    permissaoSolicitarCancelamento(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoCancelarRegistro(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES);
    }

    permissaoReverterCancelamento(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES);
    }

    permissaoSolicitarSuspensao(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoSuspender(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES);
    }

    permissaoSolicitarTransferenciaUF(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoIncluirObservacoesCertificadoRegularidade(){
        return this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UN_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_GES) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_ANA_DADOS) ||
               this.keycloakService.getSubPerfis().includes(SubPerfisEnum.UE_RESP_SITUACAO);
    }

    permissaoDocumentos(){
        return true;
    }

    permissaoHistoricoSituacao(){
        return this.keycloakService.isUsuarioNacional || this.keycloakService.isUsuarioEstadual;
    }
}