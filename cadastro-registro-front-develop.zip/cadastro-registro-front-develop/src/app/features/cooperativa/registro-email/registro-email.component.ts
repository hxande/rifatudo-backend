import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { CooperativaRegistro } from 'src/app/api/models/CooperativaRegistro';

@Component({
  selector: 'app-registro-email',
  templateUrl: './registro-email.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./registro-email.scss']
})
export class RegistroEmailComponent {

  @Input("registro")
  objCooperativaRegistroSolicitacaoInativacao: CooperativaRegistro;
  @Input("visible")
  modalRegistroEmail: boolean;
  @Output() fechaModal = new EventEmitter();

  constructor() { }

  fecharModal() {
    this.modalRegistroEmail = false;
    this.fechaModal.emit({ visible: false });
  }

  baixarPdf() {
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';

    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();

      const htmlFinal = `
        <html>
          <head>
            <meta charset="utf-8"/>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .meta { margin-bottom: 20px; font-size: 14px; }
              .meta div { margin: 4px 0; }
              hr { margin: 20px 0; }
            </style>
          </head>
          <body>
            <div class="meta">
              <div><b>Para:</b> ${this.objCooperativaRegistroSolicitacaoInativacao.registroEmail.para}</div>
              <div><b>Data de Envio:</b> ${new Date(this.objCooperativaRegistroSolicitacaoInativacao.registroEmail.dtEnvio).toLocaleString()}</div>
            </div>
            <hr/>
            ${this.objCooperativaRegistroSolicitacaoInativacao.registroEmail.corpo}
          </body>
        </html>
      `;

      doc.write(htmlFinal);
      doc.close();

      setTimeout(() => {
        iframe.contentWindow?.document.body.focus();
        iframe.contentWindow?.print();
        iframe.contentWindow?.close();
      }, 500);
    }
    this.fecharModal();
  }
}
