import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnuarioDadosSociaisComponent } from './anuario-dados-sociais.component';

describe('AnuarioDadosSociaisComponent', () => {
  let component: AnuarioDadosSociaisComponent;
  let fixture: ComponentFixture<AnuarioDadosSociaisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnuarioDadosSociaisComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnuarioDadosSociaisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
