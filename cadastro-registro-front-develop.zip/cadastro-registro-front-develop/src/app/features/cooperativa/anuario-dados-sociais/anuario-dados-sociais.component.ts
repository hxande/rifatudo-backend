import { Component, OnInit, ViewChild, Input, HostListener, ChangeDetectorRef, ChangeDetectionStrategy, inject } from '@angular/core';
import { saveAs } from 'file-saver';
import { SelectItem, MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { CacheService } from '@utils/cache/cache.service';
import { UtilityService } from '@utils/utility/utility.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { CooperativaListagemTO } from '@cadastro-registro-api/models/CooperativaListagemTO';
import { EnumCooperativaStatusManutencao } from '@cadastro-registro-api/models/EnumCooperativaStatusManutencao';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ValidacaoCooperativa } from '../../registro/validacao/validacao-cooperativa.service';
import { ApiCooperativaLeituraService } from '@cadastro-registro-leitura-api/services/api-cooperativa-leitura.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import {Observable} from 'rxjs';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { Ramo } from 'src/app/api/models/Ramo';

@Component({
  selector: 'app-anuario-dados-sociais',
  templateUrl: './anuario-dados-sociais.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./anuario-dados-sociais.component.css']
})
export class AnuarioDadosSociaisComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  private debouncer;
  private delay = 500;
  situacoes: SelectItem[];
  regularidade: SelectItem[];
  status: SelectItem[];
  filtroStatusManutencao = [];
  listaStatusManutencao: SelectItem[];
  listaStatusAnuario: SelectItem[];
  filtroStatusAnuario: SelectItem;
  listaUfs: SelectItem[];
  scrollHeight = '';
  response: IServiceResponse<IPage<CooperativaListagemTO>>;
  nrLinhasTabela = 10;
  modalVisivel: boolean;
  ufsOpts: { label: string; value: string }[] = [];
  ramosOpts: { label: string; value: Ramo }[] = [];
  segmentosOpts: { label: string; value: number }[] = [];
  listaSegmentos: Segmento[] = [];
  filtrocnpj = '';
  filtronomeFantasia = '';
  filtroRegistroOcb = '';
  filtroLivre = '';
  filtroDataAtualizacao = '';
  filtroUfDestino = '';
  filtroramo: Ramo[] = [];
  filtroSegmento: number[];
  filtroUf: string[];
  filtroSituacao = ['REGULAR', 'IRREGULAR'];
  filtroSolicitacaoUEPendente = false;
  filtroSolicitacaoUEInativa = false;
  filtroSolicitacaoUECancelada = false;
  naoVisualizadas: boolean;
  filtroAno: number;
  situacoesOpts: SelectItem[];
  filtroRegistradasAte: number;
  cols: { field: string, header: string, width: string }[];

  @Input() exibirExportacao = true;
  @Input() tituloTabela = 'Relatório do Anuário - Dados Sociais';
  @Input() linkBreadcumb = '/cooperativa/listagem';
  @Input() processoTransferencia = false;
  @ViewChild('dt') dt: Table;

  constructor(
    private cooperativaService: ApiCooperativaService,
    public cacheService: CacheService,
    private utilityService: UtilityService,
    private router: Router,
    public keycloakService: KeycloakService,
    private messageService: MessageService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private ramoApi: ApiRamoService,
    public language: LanguageService,
    private segmentoApi: ApiSegmentoService,
    private dadosGeraisService: ApiManutencaoDadosGeraisService,
    public validacaoCooperativa: ValidacaoCooperativa,
    private cooperativaLeituraService: ApiCooperativaLeituraService
  ) {
    if (window.screen.width < 1367) {
      this.scrollHeight = '400px';
    }

    this.atualizaBreadCumb(this.tituloTabela, this.linkBreadcumb);

    this.situacoes = [
      { label: 'Regular', value: 'REGULAR' },
      { label: 'Irregular', value: 'IRREGULAR' },
      { label: 'Suspenso', value: 'SUSPENSO' },
      { label: 'Cancelada', value: 'CANCELADA' },
    ];

    this.status = [
      { label: 'Atualizado', value: 'Atualizado' },
      { label: 'Desatualizado', value: 'Desatualizado' }
    ];
  }

  ngOnInit() {
    if (this.keycloakService.isUsuarioCooperativa) {
      this.router.navigate(['/inicio']);
    }

    if (this.processoTransferencia) {
      this.cols = [
        { field: 'TX_CNPJ', header: 'CNPJ', width: '120px' },
        { field: 'TX_NOME_FANTASIA', header: 'Nome fantasia', width: '270px' },
        { field: 'ST.SQ_ESTADO_DESTINO_SEDE', header: 'UF Destino', width: '155px' },
        { field: 'SC.TX_NOVA_SITUACAO_COOPERATIVA', header: 'Situação do registro', width: '146px' },
        { field: 'STATUS', header: 'Status da atualização cadastral', width: '140px' },
        { field: 'statusAtualizacaoAnuario', header: 'Status da atualização do anuário', width: '170px' },
        { field: 'CP.DT_ATUALIZACAO', header: 'Data de atualização', width: '140px' }
      ];
    } else {
      this.cols = [
        { field: 'pessoaJuridica.cnpj', header: 'CNPJ', width: '120px' },
        { field: 'pessoaJuridica.nomeFantasia', header: 'Nome fantasia', width: '270px' },
        { field: 'situacao.nome', header: 'Situação do registro', width: '146px' },
        { field: 'status', header: 'Status da atualização cadastral', width: '140px' },
        { field: 'statusAtualizacaoAnuario', header: 'Status da atualização do anuário', width: '170px' },
        { field: 'dataAtualizacao', header: 'Data de atualização', width: '140px' },
      ];
    }

    if (this.processoTransferencia) {
      this.breadCrumbPrimeNGService.setItems([
        { label: 'Início', routerLink: '/' },
        { label: 'Processo de Transferência', routerLink: '/cooperativa/listagem-transferencia' }
      ]);
    }
    this.buscarRamos();
    this.buscarUF();
    this.carregaListaStatusManutencao();
    this.carregarListaStatusAnuario();
    this.preencherAnoAtual();
  }

  @HostListener('window:resize')
  onResize() {
    if (window.screen.width < 1367) {
      this.scrollHeight = '400px';
    } else {
      this.scrollHeight = '1000px';
    }
  }

  atualizaBreadCumb(titulo, link) {
    link = this.router.url;
    if (this.router.url === '/cooperativa/listagem-transferencia') {
      titulo = 'Processo de Transferência';
    }
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/' },
      { label: titulo, routerLink: link }
    ]);

  }

  onChangeFilter(plusDelay: number) {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay + plusDelay);
  }

  preencherAnoAtual(){
    const dataAtual = new Date();
    this.filtroAno = dataAtual.getFullYear();
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    sortField = (sortField === '' || sortField === null || !sortField) ? ' CP.IN_SOLICITACAO_INATIVACAO DESC, CP.IN_ATUALIZACAO_NAO_VISUALIZADA ' : sortField;
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };

    let dataRegistro = null;

    if(this.filtroRegistradasAte){
      const d = new Date(this.filtroRegistradasAte);
      dataRegistro = `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()+1}`;
    }

    options.params = this.utilityService.carregaParamsString(this.filtroRegistroOcb, options.params, 'numeroRegistroOCB');
    options.params = this.utilityService.carregaParamsString(this.filtronomeFantasia, options.params, 'nomeFantasia');
    options.params = this.utilityService.carregaParamsString(this.filtrocnpj, options.params, 'cnpj');
    options.params = this.utilityService.carregaParamsString(this.filtroramo ? this.filtroramo.map(r => r.id) : '', options.params, 'ramos');
    options.params = this.utilityService.carregaParamsString(this.filtroUf ? this.filtroUf : '', options.params, 'ufs');
    options.params = this.utilityService.carregaParamsString(this.filtroLivre, options.params, 'pesquisaLivre');
    options.params = this.utilityService.carregaParamsString(this.filtroDataAtualizacao, options.params, 'dataAtualizacao');
    options.params = this.utilityService.carregaParamsString(this.filtroUfDestino, options.params, 'ufDestino');
    options.params = this.utilityService.carregaParamsString((this.filtroAno - 1), options.params, 'anoReferencia');
    options.params = this.utilityService.carregaParamsString(dataRegistro, options.params, 'dataRegistro');

    if (this.filtroSituacao?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroSituacao, options.params, 'situacaoCooperativa');
    }

    if (this.filtroStatusManutencao?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroStatusManutencao, options.params, 'cooperativaStatusManutencao');
    }
    if (this.filtroStatusAnuario) {
      options.params = this.utilityService.carregaParamsString(this.filtroStatusAnuario.value, options.params, 'statusAnuario');
    }

    if (this.filtroSolicitacaoUEPendente[0]) {
      options.params = this.utilityService.carregaParamsString(this.filtroSolicitacaoUEPendente[0], options.params, 'solicitacaoAtivacao');
    }
    if(this.filtroSolicitacaoUEInativa[0]){
      options.params = this.utilityService.carregaParamsString(this.filtroSolicitacaoUEInativa[0], options.params, 'solicitacaoInativacao');
    }
    if(this.filtroSolicitacaoUECancelada[0]){
      options.params = this.utilityService.carregaParamsString(this.filtroSolicitacaoUECancelada[0], options.params, 'solicitacaoCancelamento');
    }
    return options;

  }

  get isNacional() {
    return this.keycloakService.isUsuarioNacional;
  }

  getCooperativas(pagina = 0, sortField, sortOrder): Observable<IServiceResponse<IPage<CooperativaListagemTO>>> {
    if (this.processoTransferencia) {
      sortField = sortField || 'CP.IN_SOLICITACAO_INATIVACAO, CP.IN_ATUALIZACAO_NAO_VISUALIZADA';
    } else {
      sortField = sortField || 'situacao.ordenacaoListagem,solicitacaoInativacao,atualizacaoNaoVisualizada';
    }
    let sort;
    if (sortField === 'situacao.ordenacaoListagem.asc,solicitacaoInativacao,atualizacaoNaoVisualizada') {
      sort = 'desc';
    } else {
      sort = sortOrder === 1 ? 'asc' : 'desc';
    }
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);

    if (this.processoTransferencia) {
      return this.cooperativaService.filtrarCooperativaListagemPaginado(options);
    } else {
      return this.cooperativaLeituraService.buscarCooperativasRegistradasRelatorio(options);
    }
  }

  loadLazy(event) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.response = undefined;
    this.getCooperativas(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).subscribe(resp => {
      this.response = resp;
      this.changeDetectorRef.markForCheck();
    });
  }

  montarOptionsExportacao() {
    const options = this.carregaOptions('0', this.response.data.totalElements.toString(), '', 'asc');
    options.params = options.params.set('ativo', true + '');

    return options;
  }

  exportarRelatorio(relatorio: string, nomeArquivo: string): void {
    if (this.response && this.response.data) {
      this.cooperativaLeituraService
        .buscarRelatorio(relatorio, this.montarOptionsExportacao())
        .subscribe({
          next: (response) => {
            this.realizarDownloadRelatorio(nomeArquivo, response);
            this.changeDetectorRef.markForCheck();
          },
          error: () => {
            this.messageService.add({
              severity: 'error',
              detail: 'Erro ao exportar o relatório.',
              life: 10000
            });
            this.changeDetectorRef.markForCheck();
          }
        });
    } else {
      this.messageService.add({
        severity: 'warn',
        detail: 'Não existem registros para serem exportados.',
        life: 100000
      });
    }
  }


  private realizarDownloadRelatorio(nomeRelatorio: string,dados): void {
      const blob = new Blob([dados], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, nomeRelatorio);
  }

  onRowSelect(event) {
    this.cooperativaService.marcarComoVisualizada(event.data.id);
    this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: event.data.id }, skipLocationChange: false });
  }

  buscarRamos() {
    this.ramoApi.getRamos().then(response => {
      if (response && response.data) {
        this.ramosOpts = response.data.map(r => ({ label: r.nome, value: r }));
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  buscarUF() {
    this.dadosGeraisService.buscarUfs().then((res) => {
      if (res && res.content != null) {
        this.ufsOpts = res.content.map(uf => ({ label: uf.sigla, value: uf.sigla }));
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  carregaListaStatusManutencao() {
    this.listaStatusManutencao = [
      { label: 'Aguardando Ajustes', value: EnumCooperativaStatusManutencao.AGUARDANDO_AJUSTE.toString() },
      { label: 'Aguardando Análise', value: EnumCooperativaStatusManutencao.AGUARDANDO_ANALISE.toString() },
      { label: 'Aprovada', value: EnumCooperativaStatusManutencao.DADOS_ATUALIZADOS.toString() },
      { label: 'Desatualizada', value: EnumCooperativaStatusManutencao.DADOS_DESATUALIZADOS.toString() }
    ];
  }

  carregarListaStatusAnuario() {
    this.listaStatusAnuario = [
      { label: 'Atualizado', value: 'Atualizado'},
      { label: 'Desatualizado', value: 'Desatualizado' }
    ];
  }

  consultarSegmentos(): void {
    if (this.filtroramo && this.filtroramo.length && this.filtroramo.length > 0) {
      this.segmentosOpts = [];
      this.segmentoApi.buscaPorRamos(this.filtroramo).subscribe(response => {
        this.segmentosOpts = response.data.map(r => ({ label: r.nome, value: r.id }));
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.filtroSegmento = null;
      this.segmentosOpts = [];
    }
  }

}
