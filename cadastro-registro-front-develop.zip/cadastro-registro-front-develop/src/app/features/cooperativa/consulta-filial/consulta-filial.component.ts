import { AfterViewInit, ChangeDetectorRef, Component, DestroyRef, inject, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { ApiFilialService } from '@cadastro-registro-api/services/api-filial.services';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { DocumentacaoVO } from '@documentacao-api/models/DocumentacaoVO';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { FiliadaDadosMatrizDto } from '@cadastro-registro-api/models/filiada-dados-matriz-dto';
import { Table } from 'primeng/table';
import { TablePagedHandler } from '@shared/table-paged-handler/table-paged-handler';
import { HttpParams } from '@angular/common/http';
import { FiliadaListagemPorEstadoDto } from '@cadastro-registro-api/models/filiada-listagem-por-estado-dto';
import {
  ApiPessoaJuridicaFiliacaoService
} from '@cadastro-registro-leitura-api/services/api-pessoa-juridica-filiacao-service';
import { catchError } from 'rxjs/operators';
import { MessageService } from 'primeng/api';
import { EMPTY } from 'rxjs';
import { QuadroSocialUFTO } from 'src/app/api/models/QuadroSocialUFTO';
import { QuadroSocialUfService } from 'src/app/api/services/api-quadro-social-uf.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';


@Component({
  selector: 'app-consulta-filial',
  templateUrl: './consulta-filial.component.html',
  styleUrls: ['./consulta-filial.component.css']
})
export class ConsultaFilialComponent implements OnInit, AfterViewInit {
  @ViewChild('dtFiliais') dtFiliais: Table;

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  pessoaJuridicaBasica: PessoaJuridicaBasicaTO;
  documentacaoVO: DocumentacaoVO = null;
  podeModificarOsCampos = false;
  matriz: FiliadaDadosMatrizDto;
  listaQuadroSocialUf: QuadroSocialUFTO[] = [];

  filiaisHandler: TablePagedHandler<FiliadaListagemPorEstadoDto>;

  constructor(
    private route: ActivatedRoute,
    private apiFilial: ApiFilialService,
    private dadosGeraisService: ApiDadosGeraisService,
    private apiDocumentoService: ApiDocumentoService,
    private apiPessoaJuridicaFiliacaoService: ApiPessoaJuridicaFiliacaoService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private quadroSocialUfService: QuadroSocialUfService,
    private messageService: MessageService
  ) {
    this.filiaisHandler = new TablePagedHandler<FiliadaListagemPorEstadoDto>();
    this.filiaisHandler.fetchDataCallback = (options: { params: HttpParams }) => {
      return this.apiPessoaJuridicaFiliacaoService.getFiliaisDaMatrizNaUf(this.matriz.id, this.pessoaJuridicaBasica.ufSigla, options);
    };
    this.filiaisHandler.reportXlsName = 'Relatorio_Filiais_Por_Estado.xlsx';
    this.filiaisHandler.fetchExportXlsCallback = (options: { params: HttpParams }) => {
      return this.apiPessoaJuridicaFiliacaoService
        .getFiliaisDaMatrizNaUfXls(this.matriz.id, this.pessoaJuridicaBasica.ufSigla, options)
        .pipe(catchError(error => {
          if (error.status !== 404) {
            this.messageService.add({severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000});
          }
          return EMPTY;
        }));
    };
    this.filiaisHandler.columns = [
      { title: 'CNPJ', name: 'cnpj', sortable: { fieldName: 'pessoaJuridicaFiliada.cnpj' }, filterable: true },
      { title: 'Nome fantasia', name: 'nomeFantasia', sortable: { fieldName: 'pessoaJuridicaFiliada.nomeFantasia' }, filterable: true },
      { title: 'Município', name: 'nomeMunicipio', sortable: false, filterable: true },
      { title: 'Telefone', name: 'telefoneGeral', sortable: { fieldName: 'pessoaJuridicaFiliada.telefoneGeral' }, filterable: true },
      { title: 'E-mail', name: 'emailGeral', sortable: { fieldName: 'pessoaJuridicaFiliada.emailGeral' }, filterable: true }
    ];
  }

  ngOnInit() {
    const param = new URLSearchParams(window.location.search);
    let paramIdCooperativa = param.get('id');
    if (!paramIdCooperativa) {
      this.route.queryParams
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(params => {
        paramIdCooperativa = params['id'];
      });
    }
    this.apiFilial.get(parseInt(paramIdCooperativa, 10))
      .then(res => {
        this.pessoaJuridicaBasica = res.data;
        if (this.pessoaJuridicaBasica.endereco.idMunicipio) {
          this.dadosGeraisService.buscarMunicipioPorId(this.pessoaJuridicaBasica.endereco.idMunicipio).then(resp => {
            this.pessoaJuridicaBasica.endereco.municipio = resp;
            this.changeDetectorRef.markForCheck();
          });
        }
        this.apiFilial.getDadosMatriz(this.pessoaJuridicaBasica.cnpj)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(response => {
          this.matriz = response.data;
          this.filiaisHandler.lazyLoad(null);
          this.changeDetectorRef.markForCheck();
        });
        this.carregaDocumento();
        this.changeDetectorRef.markForCheck();
      });

    this.breadCrumbPrimeNGService.setItems([
      {label: 'Início', routerLink: '/'},
      {
        label: 'Cooperativas Registradas - Filiais',
        routerLink: '/cooperativa/listagem',
        fragment: 'filiais',
        preserveFragment: false
      },
      {label: 'Consulta Filial', routerLink: ''}
    ]);

    //nova busca de quadro de filial para filial especifica
    this.quadroSocialUfService.getDadosFilialNaUf(Number(param.get('id')))
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.listaQuadroSocialUf = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  ngAfterViewInit(): void {
    this.filiaisHandler.table = this.dtFiliais;
  }

  carregaDocumento() {
    this.apiDocumentoService.listaAtivosFilial(true, TipoPessoaEnum.PJ).then(responsePage => {
      if (this.pessoaJuridicaBasica) {
        this.apiDocumentoService.getDocumentacaoFilial(this.pessoaJuridicaBasica.id).then((res) => {
          if (res && res.data != null) {
            this.documentacaoVO = res.data;
          }
          this.changeDetectorRef.markForCheck();
        });
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  exportarFiliais(): void {
    this.filiaisHandler.exportToXls();
  }
}
