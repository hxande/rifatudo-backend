import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from '@auth/auth-guard/auth-guard.service';
import { AbaCooperativaComponent } from './aba-cooperativa/aba-cooperativa.component';
import { AnuarioHomeComponent } from './anuario/anuario-home/anuario-home.component';
import { ListagemCooperativasAnuarioComponent } from './anuario/listagem-cooperativas-anuario/listagem-cooperativas-anuario.component';
import { MantemAnuarioComponent } from './anuario/mantem-anuario/mantem-anuario.component';
import { ConsultaFilialComponent } from './consulta-filial/consulta-filial.component';
import { ListagemCooperativaTransferenciaComponent } from './listagem-cooperativa-transferencia/listagem-cooperativa-transferencia.component';
import { RelatorioAnuarioComponent } from './relatorio-anuario/relatorio-anuario.component';
import { CooperativaComponent } from './cooperativa.component';
import { AnuarioNovoComponent } from './anuario/anuario-home/anuario-versao2/anuario-novo/anuario-novo.component';

const routes: Routes = [
  { path: 'listagem', component: AbaCooperativaComponent, canActivate: [AuthGuardService] },
  { path: 'relatorio-anuario', component: RelatorioAnuarioComponent, canActivate: [AuthGuardService] },
  {
    path: 'detalhes',
    component: CooperativaComponent,
    canActivate: [AuthGuardService],
  },
  {
    path: 'listagem-transferencia',
    component: ListagemCooperativaTransferenciaComponent,
    canActivate: [AuthGuardService],
  },
  { path: 'anuario/:id', component: AnuarioNovoComponent, canActivate: [AuthGuardService] },
  { path: 'anuario-ue', component: AnuarioNovoComponent, canActivate: [AuthGuardService] },
  { path: 'consulta-filial', component: ConsultaFilialComponent, canActivate: [AuthGuardService] },
  { path: 'editar-anuario/:id', component: MantemAnuarioComponent, canActivate: [AuthGuardService] },
  { path: 'editar-anuario', component: MantemAnuarioComponent, canActivate: [AuthGuardService] },
  { path: 'listagem-anuario', component: ListagemCooperativasAnuarioComponent, canActivate: [AuthGuardService] },
  { path: 'transferencia-uf', component: ListagemCooperativaTransferenciaComponent, canActivate: [AuthGuardService] }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CooperativaRoutingModule {}
