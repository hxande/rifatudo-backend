import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, inject } from "@angular/core";
import { ApiCooperativaService } from "@cadastro-registro-api/services/api-cooperativa.service";
import { CooperativaTO } from "src/app/api/models/CooperativaTO";
import { CooperativaRegistro } from "src/app/api/models/CooperativaRegistro";
import { CooperativaSolicitacaoSituacaoTO } from "src/app/api/models/CooperativaSolicitacaoSituacaoTO";
import { NovaSituacaoEnum } from "src/app/api/models/SituacaoCooperativaEnum";
import { ApiCooperativaSituacaoService } from "src/app/api/services/api-cooperativa-situacao.service";

@Component({
    selector: 'app-solicitacao-regularizacao-component',
    templateUrl: './solicitacao-regularizacao.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./solicitacao-regularizacao.component.css'],
})
export class SolicitacaoRegularizacaoComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() idCooperativa: number;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();
    
    cooperativaRegistro = new CooperativaRegistro();
    cooperativaSolicitacaoSituacaoTO = new CooperativaSolicitacaoSituacaoTO();
    justificativa: string;

    constructor(private apiCooperativaService: ApiCooperativaService,
        private apiCooperativaSituacaoService: ApiCooperativaSituacaoService
    ) {

    }

    ngOnInit(): void {
        
    }

    cancelar(){
        this.onFechar.emit();
    }

    confirmar() {
        this.cooperativaSolicitacaoSituacaoTO.idCooperativa = this.idCooperativa;
        this.cooperativaSolicitacaoSituacaoTO.justificativa = this.justificativa;
        this.cooperativaSolicitacaoSituacaoTO.situacaoCooperativa = NovaSituacaoEnum.REGULAR;

        this.apiCooperativaSituacaoService.solicitaAtivacaoSituacaoCooperativa(this.cooperativaSolicitacaoSituacaoTO).then((response) => {
            this.onConcluir.emit();
            this.changeDetectorRef.markForCheck();
        });
    }

}