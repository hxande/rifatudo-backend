import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { Solicitacao } from '@cadastro-registro-api/models/Solicitacao';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { Repositorio } from '@upload-api/models/Repositorio';
import { ConfirmationService } from 'primeng/api';
import { CooperativaRegistro } from 'src/app/api/models/CooperativaRegistro';
import { CooperativaRegistroTO } from 'src/app/api/models/CooperativaRegistroTO';
import { CooperativaSolicitacao } from 'src/app/api/models/CooperativaSolicitacao';
import { CooperativaSolicitacaoSuspensaoTO } from 'src/app/api/models/CooperativaSolicitacaoSuspensaoTO ';
import { CooperativaTO } from 'src/app/api/models/CooperativaTO';
import { NovaSituacaoEnum } from 'src/app/api/models/SituacaoCooperativaEnum';
import { ApiSolicitacaoService } from 'src/app/api/services/api-solicitacao.service';

@Component({
    selector: 'app-solicitacao-suspensao-component',
    templateUrl: './solicitacao-suspensao.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./solicitacao-suspensao.component.css'],
})
export class SolicitacaoSuspensaoComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Input() concluirSolicitacao: boolean = false;

    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<CooperativaRegistroTO>();

    tipoSuspensao: 'IRREGULARIDADE' | 'ILEGALIDADE' = 'IRREGULARIDADE';
    formaNotificacao: 'FORA_SOUCOOP' | 'EMAIL_SOUCOOP' = 'FORA_SOUCOOP';

    listaSolicitacoesSuspensao: Solicitacao[];
    motivo: Solicitacao;
    complementoMotivo: string;
    destinatariosEmailMensagem: string;
    cooperativaRegistroTO = new  CooperativaRegistroTO();

    modalRegistroEmail = false;

    constructor(private apiCooperativaService: ApiCooperativaService,
        private apiSolicitacaoService: ApiSolicitacaoService,
        private confirmationService: ConfirmationService
    ) {

    }

    ngOnInit(): void {
        this.carregarSolicitacao();
        this.carregarDestinatariosEmail();
        this.carregarListaSolicitacao();
    }
    carregarDestinatariosEmail() {
        this.apiCooperativaService.buscarDestinatarios(this.cooperativa.id).then(res => {
            if (res) {
                this.destinatariosEmailMensagem = res.replace(/;/gi, '\n');
            }
            this.changeDetectorRef.markForCheck();
        });
    }
    carregarSolicitacao() {
        if(this.concluirSolicitacao){
            this.apiSolicitacaoService.getUltimoHistoricoSolicitacaoInativacao(this.cooperativa.id).then((cr) => {
                if (cr.data) {
                    this.cooperativaRegistroTO.cooperativaRegistro = cr.data;
                    this.cooperativaRegistroTO.jaNotificada = !!this.cooperativaRegistroTO.cooperativaRegistro.registroEmail;
                }
                this.changeDetectorRef.markForCheck();
            });
        } else {
            if(this.cooperativaRegistroTO === undefined || this.cooperativaRegistroTO === null){
                this.cooperativaRegistroTO = new CooperativaRegistroTO();
                this.cooperativaRegistroTO.cooperativaRegistro = new CooperativaRegistro();
            }

           
            this.cooperativaRegistroTO.cooperativaRegistro = new CooperativaRegistro();
            this.cooperativaRegistroTO.cooperativaRegistro.cooperativaSolicitacao = new CooperativaSolicitacao();
            this.cooperativaRegistroTO.cooperativaRegistro.cooperativa = this.cooperativa;
            this.cooperativaRegistroTO.cooperativaRegistro.cooperativaSolicitacao.cooperativa = this.cooperativa;

            this.cooperativaRegistroTO.notificarPorEmail = true;
            this.cooperativaRegistroTO.jaNotificada = false;
        }
    }


    carregarListaSolicitacao() {
        this.apiSolicitacaoService.getListaSolicitacoesAtivas().then((response) => {
            if (response) {
                this.listaSolicitacoesSuspensao = response.data.filter((elem) => {
                    return elem.tipoSolicitacao.descricaoTipoSolicitacao.toLocaleUpperCase() === 'SUSPENSÃO';
                });
            }
            this.changeDetectorRef.markForCheck();
        });
    }


    confirmarSolicitacaoInativacao() {
        
        if (this.formaNotificacao === 'EMAIL_SOUCOOP') {
            this.confirmationService.confirm({
                message: `A notificação será enviada para os seguintes e-mails da cooperativa: \n ${this.destinatariosEmailMensagem}`,
                header: 'Notificação',
                key: 'cdEmail',
                accept: () => {
                    this.confirmarSolicitacao();
                }
            });
        } else {
            this.confirmarSolicitacao();
        }
    }

    confirmarSolicitacao(){
        const cooperativaSolicitacaoSuspensao = new CooperativaSolicitacaoSuspensaoTO();
        cooperativaSolicitacaoSuspensao.idCooperativa = this.cooperativa.id;
        cooperativaSolicitacaoSuspensao.tipoAcaoSolicitacao = "OE_SOLICITA";
        cooperativaSolicitacaoSuspensao.justificativa = this.cooperativaRegistroTO.cooperativaRegistro.justificativaSolicitacaoInativacao;
        cooperativaSolicitacaoSuspensao.tipoDeSuspensao = this.tipoSuspensao;
        cooperativaSolicitacaoSuspensao.situacaoCooperativa = NovaSituacaoEnum.SUSPENSA;

        if(this.motivo != null){
            cooperativaSolicitacaoSuspensao.idMotivo = this.motivo.id;
        }

        if(this.formaNotificacao === 'EMAIL_SOUCOOP'){
           cooperativaSolicitacaoSuspensao.notificarPorEmail = true;
           cooperativaSolicitacaoSuspensao.jaNotificada = false;
        }

         if(this.formaNotificacao === 'FORA_SOUCOOP'){
           cooperativaSolicitacaoSuspensao.notificarPorEmail = false;
           cooperativaSolicitacaoSuspensao.jaNotificada = true;
           cooperativaSolicitacaoSuspensao.anexoNotificacao = this.cooperativaRegistroTO.cooperativaRegistro?.anexoNotificacao;
        }

        if (this.isFilled(this.complementoMotivo)) {
            cooperativaSolicitacaoSuspensao.outroMotivoDesc = this.complementoMotivo;
        }

        if(this.cooperativaRegistroTO.cooperativaRegistro?.anexoNotificacao !== null){
                cooperativaSolicitacaoSuspensao.anexoNotificacao = this.cooperativaRegistroTO.cooperativaRegistro?.anexoNotificacao;
        }

        this.apiSolicitacaoService.suspensao(cooperativaSolicitacaoSuspensao).then((coop) => {
            this.onConcluir.emit();
            this.changeDetectorRef.markForCheck();
        });
        //this.apiCooperativaService.putSolicitaInativacaoCooperativa(this.cooperativaRegistroTO).then(() => {
            //this.onConcluir.emit(this.cooperativaRegistroTO);
        //});
    }

    verificarRepositorioVazio(repositorio: Repositorio) {
        if (repositorio == null) {
            this.cooperativaRegistroTO.cooperativaRegistro.anexoNotificacao = null;
        }
    }

    atualizaNotificacaoEmail() {
        this.cooperativaRegistroTO.notificarPorEmail = !this.cooperativaRegistroTO.jaNotificada;
        if( !this.cooperativaRegistroTO.jaNotificada){
            this.cooperativaRegistroTO.cooperativaRegistro.anexoNotificacao = null;
        }

    }

    onTrocaNotificacao(): void {
    if (this.formaNotificacao === 'EMAIL_SOUCOOP') {
        // não exige anexo
        return;
    }
    // voltando para FORA_SOUCOOP mantém a regra de exigir anexo no botão
    }

    private isFilled(v: unknown): boolean {
        return v !== null && v !== undefined && String(v).trim() !== '';
    }

    isConfirmDisabled(): boolean {
    const motivoOk       = this.isFilled(this.motivo);
    const justificativa  = this.isFilled(this.cooperativaRegistroTO?.cooperativaRegistro?.justificativaSolicitacaoInativacao);
    const anexo          = this.isFilled(this.cooperativaRegistroTO?.cooperativaRegistro?.anexoNotificacao);

    if (this.tipoSuspensao === 'ILEGALIDADE') {
        // Ilegalidade: justificativa + anexo
        return !(motivoOk && justificativa && anexo);
    }

    if (this.tipoSuspensao === 'IRREGULARIDADE') {
        if (this.formaNotificacao === 'FORA_SOUCOOP') {
            if(this.cooperativaRegistroTO.jaNotificada){
                return !motivoOk
            }else{      
                return !(motivoOk && anexo);
            }
        }
        if (this.formaNotificacao === 'EMAIL_SOUCOOP') {
        // Irregularidade + notificar por e‑mail: só motivo
        return motivoOk;
        }
        // Sem forma de notificação escolhida ainda → desabilita
        return true;
    }

    // Tipo de suspensão não selecionado → desabilita
    return true;
    }

   
    fechar() {
        this.onFechar.emit();
    }
}
