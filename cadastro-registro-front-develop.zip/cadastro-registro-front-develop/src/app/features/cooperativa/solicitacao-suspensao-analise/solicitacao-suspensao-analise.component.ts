import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, inject } from "@angular/core";
import { Cooperativa } from "@cadastro-registro-api/models/Cooperativa";
import { Solicitacao } from "@cadastro-registro-api/models/Solicitacao";
import { ApiCooperativaService } from "@cadastro-registro-api/services/api-cooperativa.service";
import { CooperativaRegistro } from "src/app/api/models/CooperativaRegistro";
import { CooperativaRegistroTO } from "src/app/api/models/CooperativaRegistroTO";
import { CooperativaSolicitacaoSuspensaoTO } from "src/app/api/models/CooperativaSolicitacaoSuspensaoTO ";
import { CooperativaTO } from "src/app/api/models/CooperativaTO";
import { NovaSituacaoEnum } from "src/app/api/models/SituacaoCooperativaEnum";
import { ApiSolicitacaoService } from "src/app/api/services/api-solicitacao.service";

@Component({
    selector: 'app-solicitacao-suspensao-analise-component',
    templateUrl: './solicitacao-suspensao-analise.component.html',
    styleUrls: ['./solicitacao-suspensao-analise.component.css'],
})
export class SolicitacaoSuspensaoAnaliseComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();


    cooperativaRegistro = new CooperativaRegistro();
    justificativa: string;
    listaMotivo: Solicitacao[];

    modalRegistroEmail = false;
    aceitaSolicitacao: boolean;

    constructor(private apiCooperativaService: ApiCooperativaService,
        private apiSolicitacaoService: ApiSolicitacaoService,
    ){

    }

    ngOnInit(): void {
        this.carregarListaMotivo();
        this.apiSolicitacaoService.getUltimoHistoricoSolicitacaoInativacao(this.cooperativa.id)
        .then(response =>{
            this.cooperativaRegistro = response.data;
            this.changeDetectorRef.markForCheck();
        });
    }

    carregarListaMotivo() {
        this.apiSolicitacaoService.getListaSolicitacoesAtivas()
        .then((response) => {
            if (response) {
                this.listaMotivo = response.data.filter((elem) => {
                    return elem.tipoSolicitacao.descricaoTipoSolicitacao.toLocaleUpperCase() === 'SUSPENSÃO';
                });
                this.changeDetectorRef.markForCheck();
            }
        });
    }

    cancelar(){
        this.onFechar.emit();
    }

    confirmar() {
        const cooperativaSolicitacaoSuspensao = new CooperativaSolicitacaoSuspensaoTO();
        cooperativaSolicitacaoSuspensao.idCooperativa = this.cooperativa.id;
        cooperativaSolicitacaoSuspensao.justificativa = this.justificativa;
        cooperativaSolicitacaoSuspensao.idSolicitacao = this.cooperativaRegistro.cooperativaSolicitacao.id;
        cooperativaSolicitacaoSuspensao.idMotivo = this.cooperativaRegistro.cooperativaSolicitacao.solicitacao.id;
        cooperativaSolicitacaoSuspensao.anexo = this.cooperativaRegistro.anexo;
        cooperativaSolicitacaoSuspensao.anexoNotificacao = this.cooperativaRegistro.anexoNotificacao;
        cooperativaSolicitacaoSuspensao.situacaoCooperativa = NovaSituacaoEnum.SUSPENSA;
        cooperativaSolicitacaoSuspensao.registroEmail = this.cooperativaRegistro.registroEmail ? true : false;
        if(!this.aceitaSolicitacao){
            cooperativaSolicitacaoSuspensao.tipoAcaoSolicitacao = "UN_RECUSA_SUSPENDER";
            this.apiSolicitacaoService.suspensao(cooperativaSolicitacaoSuspensao)
            .then(() => {
                this.onConcluir.emit();
                this.changeDetectorRef.markForCheck();
            });
        } else {
            cooperativaSolicitacaoSuspensao.tipoAcaoSolicitacao = "UN_ACEITA_SUSPENDER";
            this.apiSolicitacaoService.suspensao(cooperativaSolicitacaoSuspensao).then(() => {
                this.onConcluir.emit();
                this.changeDetectorRef.markForCheck();
            });
        }
    }



}
