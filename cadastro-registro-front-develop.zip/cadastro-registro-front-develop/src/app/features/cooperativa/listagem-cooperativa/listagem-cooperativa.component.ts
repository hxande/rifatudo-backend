import { Component, OnInit, ViewChild, Input, HostListener, ElementRef, DestroyRef, inject, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { saveAs } from 'file-saver';
import { SelectItem, MessageService, MenuItem } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Router } from '@angular/router';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { CacheService } from '@utils/cache/cache.service';
import { UtilityService } from '@utils/utility/utility.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { EnumCooperativaStatusManutencao } from '@cadastro-registro-api/models/EnumCooperativaStatusManutencao';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ValidacaoCooperativa } from '../../registro/validacao/validacao-cooperativa.service';
import { ApiCooperativaLeituraService } from '@cadastro-registro-leitura-api/services/api-cooperativa-leitura.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import {finalize, Observable} from 'rxjs';
import {SITUACOES_OPTS} from '@shared/constants/situacoes.constant';
import { ApiPeriodoAtualizacaoService } from '@cadastro-registro-api/services/api-periodo-atualizacao.service';
import { CooperativaListagemTO } from '@cadastro-registro-api/models/CooperativaListagemTO';
import { LoadingService } from 'src/app/services/loading-service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-listagem-cooperativa',
  templateUrl: './listagem-cooperativa.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-cooperativa.component.css'],
})
export class ListagemCooperaitvaComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  loading = false;
  private debouncer;
  private delay = 500;
  situacoes: SelectItem[];
  regularidade: SelectItem[];
  status: SelectItem[];
  filtroStatusManutencao = [];
  listaStatusManutencao: SelectItem[];
  listaStatusAnuario: SelectItem[];
  filtroStatusAnuario: SelectItem;
  listaUfs: SelectItem[];
  listaSolicitacaoOE: SelectItem[];
  filtroSolicitacoesOE = [];
  scrollHeight = '';
  response: IServiceResponse<IPage<CooperativaListagemTO>>;
  nrLinhasTabela = 10;
  modalVisivel: boolean;
  ufsOpts: SelectItem[] = [];
  ramosOpts: SelectItem[] = [];
  segmentosOpts: SelectItem[] = [];
  listaSegmentos: Segmento[] = [];
  filtrocnpj = '';
  filtronomeFantasia = '';
  filtroLivre = '';
  filtroramo = [];
  filtroSegmento = [];
  filtroUf = [];
  filtroSituacao = SITUACOES_OPTS.map(opt => opt.value);
  anoReferencia = (new Date().getFullYear() -1 ).toString();
  isAnoCiclo = false;
  filtroTextoLivre: string;
  naoVisualizadas: boolean;
  filtrosSalvos: string;
  filtros: {
    filtroSolicitacoesOE?: string[];
    naoVisualizadas?: boolean;
    filtroSituacao?: string[];
    filtroStatusManutencao?: string[];
    filtroStatusAnuario?: SelectItem;
    filtroTextoLivre?: string;
    filtroramo?: string[];
    filtroUf?: string[];
  };
  exportarOptions: MenuItem[];
  ramoSelecionado: boolean = true;
  usuarioEstadual: boolean = false;
  cols: { field: string, header: string}[];

  @Input() exibirExportacao = true;
  @Input() tituloTabela = 'Cooperativas Registradas';
  @Input() linkBreadcumb = '/cooperativa/listagem';
  @Input() processoTransferencia = false;
  @ViewChild('dt') dt: Table;
  @ViewChild('btnAplicar', { static: false }) botao!: ElementRef<HTMLButtonElement>;

  constructor(
    private loadingService: LoadingService,
    private cooperativaService: ApiCooperativaService,
    public cacheService: CacheService,
    private utilityService: UtilityService,
    private router: Router,
    public keycloakService: KeycloakService,
    private messageService: MessageService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private ramoApi: ApiRamoService,
    private segmentoApi: ApiSegmentoService,
    private dadosGeraisService: ApiManutencaoDadosGeraisService,
    public validacaoCooperativa: ValidacaoCooperativa,
    private cooperativaLeituraService: ApiCooperativaLeituraService,
    private periodoService: ApiPeriodoAtualizacaoService
  ) {
    if (window.screen.width < 1367) {
      this.scrollHeight = '400px';
    }

    this.atualizaBreadCumb(this.tituloTabela, this.linkBreadcumb);

    this.situacoes = SITUACOES_OPTS;
    this.status = [
      { label: 'Atualizado', value: 'Atualizado' },
      { label: 'Desatualizado', value: 'Desatualizado' }
    ];
    this.listaSolicitacaoOE = [
      {label: 'Suspensão', value: 'solicitacaoInativacao' },
      {label: 'Regularização', value: 'solicitacaoAtivacao' },
      {label: 'Cancelamento', value: 'solicitacaoCancelamento'},
      {label: 'Não visualizadas', value: 'naoVisualizada' },
    ];
  }

  async ngOnInit() {

    this.exportarOptions = [
      {
        label: 'Exportar Solicitação',
        icon: 'pi pi-fw pi-download',
        command: () => this.exportarRegistradasSolicitacao()
      },
      {
        label: 'Status do Cadastro',
        icon: 'pi pi-fw pi-download',
        command: () => this.exportarRegistradas()
      },
      {
        label: 'Status do Anuário',
        icon: 'pi pi-fw pi-download',
        command: () => this.exportarRelatorioAnuarioSimplificado()
      }
    ];

    const promises = [
      this.buscarUF(),
      this.buscarRamos(),
      this.carregaListaStatusManutencao(),
      this.carregarListaStatusAnuario()
    ]

    await Promise.all(promises);

    this.filtrosSalvos = localStorage.getItem('filtrosCooperativas');

    if (this.keycloakService.isUsuarioCooperativa) {
      this.router.navigate(['/inicio']);
    }

    if (!this.processoTransferencia) {
      this.cols = [
        { field: 'pessoaJuridica.ufSigla', header: 'UF' },
        { field: 'pessoaJuridica.ramo.nome', header: 'Ramo' },
        { field: 'pessoaJuridica.nomeFantasia', header: 'Cooperativa' },
        { field: 'situacao.nome', header: 'Situação do registro ' },
        { field: 'status', header: 'Status do cadastro'},
        { field: 'statusAtualizacaoAnuario', header: 'Status do anuário'},
      ];
    }

      if (this.filtrosSalvos) {
        this.filtros = JSON.parse(this.filtrosSalvos);
        this.filtroSolicitacoesOE = this.filtros.filtroSolicitacoesOE || [];
        this.naoVisualizadas = this.filtros.naoVisualizadas || false;
        this.filtroSituacao = this.filtros.filtroSituacao || [];
        this.filtroStatusManutencao = this.filtros.filtroStatusManutencao || [];
        this.filtroStatusAnuario = this.filtros.filtroStatusAnuario || null;
        this.filtroTextoLivre = this.filtros.filtroTextoLivre || "";
        setTimeout(() => {
          this.loadLazy(null);
          this.changeDetectorRef.markForCheck();
        }, 600)
      } else {
        setTimeout(() => {
          this.loadLazy(null);
          this.changeDetectorRef.markForCheck();
        }, 600)
      }

      if(this.keycloakService.getTipo() == "E"){
        this.usuarioEstadual = true;
      } else {
        this.usuarioEstadual = false;
      }
  }

  aplicarFiltros() {
    const filtrosAtuais = {
      filtroSegmento: this.filtroSegmento,
      filtroUf: this.filtroUf,
      filtroSolicitacoesOE: this.filtroSolicitacoesOE,
      filtroramo: this.filtroramo,
      naoVisualizadas: this.naoVisualizadas,
      filtroSituacao: this.filtroSituacao,
      filtroStatusManutencao: this.filtroStatusManutencao,
      filtroStatusAnuario: this.filtroStatusAnuario ? this.filtroStatusAnuario : null,
      filtroTextoLivre: this.filtroTextoLivre
    };

    localStorage.setItem('filtrosCooperativas', JSON.stringify(filtrosAtuais));
    this.loadLazy(null);
  }

  limparFiltros() {
    localStorage.removeItem('filtrosCooperativas');
    this.filtroSegmento = [];
    this.filtroUf = [];
    this.filtroramo = [];
    this.filtroSolicitacoesOE = [];
    this.naoVisualizadas = false;
    this.filtroSituacao = [];
    this.filtroStatusManutencao = [];
    this.filtroStatusAnuario = null;
    this.filtroTextoLivre = "";
    this.ramoSelecionado = true;
    this.loadLazy(null);
  }

  @HostListener('window:resize')
  onResize() {
    if (window.screen.width < 1367) {
      this.scrollHeight = '400px';
    } else {
      this.scrollHeight = '1000px';
    }
  }

  atualizaBreadCumb(titulo, link) {
    link = this.router.url;
    if (this.router.url === '/cooperativa/listagem-transferencia') {
      titulo = 'Processo de Transferência';
    }
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/' },
      { label: titulo, routerLink: link }
    ]);

  }

  onChangeFilter(plusDelay: number) {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay + plusDelay);
  }


  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    //sortField = (sortField === '' || sortField === null || !sortField) ? 'situacao.nome,solicitacaoInativacao,atualizacaoNaoVisualizada' : sortField;
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
    };

    if (sortField && sortOrder) {
      options.params = options.params.append('sort', `${sortField},${sortOrder}`);
    }

    if(sortField === 'situacao.nome'){
      options.params = options.params.append('sort','pessoaJuridica.nomeFantasia,asc');
    }

    options.params = this.utilityService.carregaParamsString(this.filtroTextoLivre, options.params, 'textoLivre');
    options.params = this.utilityService.carregaParamsString(this.filtroramo ? this.filtroramo.map(r => r.id) : '', options.params, 'ramos');
    options.params = this.utilityService.carregaParamsString(this.filtroUf ? this.filtroUf : '', options.params, 'ufs');


    if(this.naoVisualizadas){
      options.params = this.utilityService.carregaParamsString(this.naoVisualizadas, options.params, 'naoVisualizada');
      options.params = options.params.set('sort',`${sortField},${sortOrder}`);
    }else{
      if(options.params.get('sort') != 'status,asc'){
        options.params = options.params.set('sort',`${sortField},${sortOrder}`);
      }
    }

    options.params = this.utilityService.carregaParamsString(this.filtroSegmento ? this.filtroSegmento : '', options.params, 'segmentos');

    if(this.isAnoCiclo){
      options.params = this.utilityService.carregaParamsString(this.anoReferencia, options.params, 'anoReferencia');
    }

    if (this.filtroSituacao?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroSituacao, options.params, 'situacaoCooperativa');
    }

    if (this.filtroStatusManutencao?.length > 0) {
      options.params = this.utilityService.carregaParamsString(this.filtroStatusManutencao, options.params, 'cooperativaStatusManutencao');
    }
    if (this.filtroStatusAnuario) {
      options.params = this.utilityService.carregaParamsString(this.filtroStatusAnuario.value, options.params, 'statusAnuario');
    }

    // Filtros solicitacoes da OE
    if(this.filtroSolicitacoesOE){
      this.filtroSolicitacoesOE.forEach(sol => {
        options.params = this.utilityService.carregaParamsString(true, options.params, sol);
      });
    }

     // Remove 'sort' se sortField for undefined ou null
    if (!sortField || sortField === 'null') {
      options.params = options.params.delete('sort');
    }

    return options;

  }

  get isNacional() {
    return this.keycloakService.isUsuarioNacional;
  }

  getCooperativas(pagina = 0, sortField, sortOrder): Observable<IServiceResponse<IPage<CooperativaListagemTO>>> {
    this.loadingService.setLoading(true);
    let sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.cooperativaLeituraService.buscarCooperativasRegistradasListagem(options).pipe(
      finalize(() => {
          this.loadingService.setLoading(false);
      })
    );
  }

  loadLazy(event: TableLazyLoadEvent) {
    if(event != null){
      if (event.rows !== undefined) {
        this.nrLinhasTabela = event.rows;
      }
      this.response = undefined;
      this.getCooperativas(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(resp => {
        this.response = resp;
        this.changeDetectorRef.markForCheck();
      });
    }else{
      this.getCooperativas(0, null, 1).pipe(takeUntilDestroyed(this.destroyRef)).subscribe(resp => {
        this.response = resp;
        this.changeDetectorRef.markForCheck();
      });
    }

  }

  montarOptionsExportacao() {
    const options = this.carregaOptions('0', this.response.data.totalElements.toString(), '', 'asc');
    options.params = options.params.set('ativo', true + '');

    return options;
  }



  exportarRegistradas() {
    this.isAnoCiclo = true;

    this.exportarRelatorio('REGISTRADAS', 'Cooperativas_registradas.xlsx');
  }


  exportarRegistradasSolicitacao() {
    this.isAnoCiclo = false;

    this.exportarRelatorio('SOLICITACAO', 'Solicitações_Suspensão_Cancelamento_regularização.xlsx');
  }

  exportarRelatorioAnuarioSimplificado() {
    this.isAnoCiclo = true;

    this.exportarRelatorio('ANUARIO_DADOS_FINANCEIROS_COMPLEMENTARES_SIMPLIFICADO', 'Anuario_Ciclo_Corrente_Simplificado.xlsx');
  }

  exportarRegistros(){
    this.exportarRelatorio('COOPERATIVA_SIMPLIFICADA','Cooperativas_registradas_simplificadas.xlsx');
  }


  exportarRelatorio(relatorio: string, nomeArquivo: string): void {
    if (this.response && this.response.data) {
      this.cooperativaLeituraService
        .buscarRelatorioArrayBuffer(relatorio, this.montarOptionsExportacao())
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe({
          next: (response) => this.realizarDownloadRelatorio(nomeArquivo, response),
          error: () => {
            this.messageService.add({
              severity: 'error',
              detail: 'Erro ao gerar o relatório.',
              life: 10000
            });
          }
        });
    } else {
      this.messageService.add({
        severity: 'warn',
        detail: 'Não existem registros para serem exportados.',
        life: 10000
      });
    }
  }

  private realizarDownloadRelatorio(nomeRelatorio: string, dados): void {
      const blob = new Blob([dados], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      saveAs(blob, nomeRelatorio);
  }

  onRowSelect(idCooperativa) {
    const filtrosAtuais = {
        filtroSegmento: this.filtroSegmento,
        filtroUf: this.filtroUf,
        filtroSolicitacoesOE: this.filtroSolicitacoesOE,
        filtroramo: this.filtroramo,
        filtroSituacao: this.filtroSituacao,
        filtroStatusManutencao: this.filtroStatusManutencao,
        filtroStatusAnuario: this.filtroStatusAnuario,
        naoVisualizadas: this.naoVisualizadas,
        filtroTextoLivre: this.filtroTextoLivre
    };

    localStorage.setItem('filtrosCooperativas', JSON.stringify(filtrosAtuais));
    this.cooperativaService.marcarComoVisualizada(idCooperativa);
    this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: idCooperativa }, skipLocationChange: false });
  }

  buscarRamos() {
    this.ramoApi.getRamos().then(response => {
      if (response && response.data) {
        this.ramosOpts = [];
        response.data.forEach(r => this.ramosOpts = [
          ...this.ramosOpts,
          { label: r.nome, value: r }
        ]);
      }
      this.changeDetectorRef.markForCheck();
    })
    .finally(() => {
      if(this.filtrosSalvos) {
        const ramosSalvos = this.filtros.filtroramo || [];
        this.filtroramo = ramosSalvos
          .map((ramoSalvo: any) => {
            const id = ramoSalvo && typeof ramoSalvo === 'object' ? ramoSalvo.id : ramoSalvo;
            return this.ramosOpts.find(opt => opt.value.id === id)?.value;
          })
          .filter(ramo => !!ramo);
      }
    })
    .catch(e => console.error('error => ',e));
  }

  buscarUF() {
    if(this.ufsOpts.length === 0 ){
      this.dadosGeraisService.buscarUfs().then((res) => {
        if (res && res.content != null) {
          res.content.forEach(uf => this.ufsOpts = [
            ...this.ufsOpts,
            { label: uf.sigla, value: uf.sigla }
          ]);
        }
        this.changeDetectorRef.markForCheck();
      })
      .finally(() => {
        if(this.filtrosSalvos) {
          this.filtroUf = this.filtros.filtroUf || [];
        }
      })
      .catch(e => console.error('error => ',e));
    }
  }

  carregaListaStatusManutencao() {
    this.listaStatusManutencao = [
      { label: 'Aguardando Análise', value: EnumCooperativaStatusManutencao.AGUARDANDO_ANALISE.toString() },
      { label: 'Em Preenchimento', value: EnumCooperativaStatusManutencao.EM_PREENCHIMENTO.toString() },
      { label: 'Aguardando Ajustes', value: EnumCooperativaStatusManutencao.AGUARDANDO_AJUSTE.toString() },
      { label: 'Aprovada', value: EnumCooperativaStatusManutencao.DADOS_ATUALIZADOS.toString() },
      { label: 'Desatualizada', value: EnumCooperativaStatusManutencao.DADOS_DESATUALIZADOS.toString() },
    ];
  }

  definirEstiloStatusCadastro(status: string): string {
    let result: string;
    switch (status) {
      case 'Aprovada': result = 'text-green-500 font-semibold'; break;
      case 'Desatualizada': result = 'text-orange-500 font-semibold'; break;
      case 'Em preenchimento': result = 'text-purple-500 font-semibold'; break;
      case 'Aguardando análise': result = 'text-cyan-500 font-semibold'; break;
      case 'Aguardando ajustes': result = 'text-purple-500 font-semibold'; break;
      default: result = 'text-cyan-500 font-semibold'; break;
    }
    return result;
  }

  definirEstiloStatusAnuario(status: string): string {
    let result: string;
    switch (status) {
      case 'Atualizado': result = 'text-green-500 font-semibold'; break;
      case 'Desatualizado': result = 'text-orange-500 font-semibold'; break;
      case 'Em preenchimento': result = 'text-purple-500 font-semibold'; break;
      default: result = 'text-cyan-500 font-semibold'; break;
    }
    return result;
  }

  carregarListaStatusAnuario() {
    this.listaStatusAnuario = [
      { label: 'Atualizado', value: 'Atualizado'},
      { label: 'Em preenchimento', value: 'Em preenchimento' },
      { label: 'Desatualizado', value: 'Desatualizado' }
    ];
  }

  consultarSegmentos(): void {

    this.ramoSelecionado = false;

    if (this.filtroramo && this.filtroramo.length && this.filtroramo.length > 0) {
      this.segmentoApi.buscaPorRamos(this.filtroramo)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(response => {
        response.data.forEach(segmento => this.segmentosOpts = [
          ...this.segmentosOpts,
          {label: segmento.nome, value: segmento.id }
        ]);
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.ramoSelecionado = true;
      this.segmentosOpts = [];
    }
  }

  @HostListener('document:keydown.enter')
  onEnterPress() {
    this.aplicarFiltros()
  }

}
