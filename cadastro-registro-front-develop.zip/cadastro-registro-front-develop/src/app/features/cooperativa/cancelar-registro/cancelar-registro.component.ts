import { ChangeDetectorRef, Component, OnInit, Input, Output, EventEmitter, inject } from "@angular/core";
import { Solicitacao } from "@cadastro-registro-api/models/Solicitacao";
import { ApiCooperativaService } from "@cadastro-registro-api/services/api-cooperativa.service";
import { Repositorio } from "@upload-api/models/Repositorio";
import { CooperativaTO } from "src/app/api/models/CooperativaTO";
import { CooperativaRegistro } from "src/app/api/models/CooperativaRegistro";
import { CooperativaSolicitacao } from "src/app/api/models/CooperativaSolicitacao";
import { ApiCooperativaSituacaoService } from "src/app/api/services/api-cooperativa-situacao.service";
import { CooperativaSolicitacaoCancelamentoTO } from "src/app/api/models/CooperativaSolicitacaoCancelamentoTO";
import { NovaSituacaoEnum } from "src/app/api/models/SituacaoCooperativaEnum";
import { ApiSolicitacaoService } from "src/app/api/services/api-solicitacao.service";

@Component({
    selector: 'app-cancelar-registro-component',
    templateUrl: './cancelar-registro.component.html',
    styleUrls: ['./cancelar-registro.component.css'],
})
export class CancelarRegistroComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();


    cooperativaRegistro = new CooperativaRegistro();
    justificativa: string;
    motivo: Solicitacao;
    listaMotivo: Solicitacao[];
    aceitarSolicitacao : boolean;

    constructor(
        private apiCooperativaService: ApiCooperativaService,
        private apiCooperativaSituacaoService: ApiCooperativaSituacaoService,
        private apiSolicitacaoService: ApiSolicitacaoService
    ){

    }

    ngOnInit(): void {
        if(this.cooperativa.solicitacaoCancelamento){
            this.carregarSolicitacaoCancelamento();
        } else {
            this.carregarListaMotivo();
        }
    }
    carregarSolicitacaoCancelamento() {
        this.apiCooperativaSituacaoService.getUltimoHistoricoSolicitacaoCancelamento(this.cooperativa.id).then((response) => {
            if (response.data) {
                this.cooperativaRegistro = response.data;

            }
            this.changeDetectorRef.markForCheck();
        });
    }

    carregarListaMotivo() {
        this.apiSolicitacaoService.getListaSolicitacoesAtivas().then((response) => {
            if (response) {
                this.listaMotivo = response.data.filter((elem) => {
                    return elem.tipoSolicitacao.descricaoTipoSolicitacao.toLocaleUpperCase() === 'CANCELAMENTO';
                });
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    cancelar(){
        this.onFechar.emit();
    }

    confirmar() {
        const cooperativaSolicitacaoTO = new CooperativaSolicitacaoCancelamentoTO();
        cooperativaSolicitacaoTO.justificativa = this.justificativa;
        cooperativaSolicitacaoTO.idCooperativa = this.cooperativa.id;
        cooperativaSolicitacaoTO.idMotivo = this.motivo.id;
        cooperativaSolicitacaoTO.anexo = this.cooperativaRegistro.anexo;
        cooperativaSolicitacaoTO.situacaoCooperativa = NovaSituacaoEnum.CANCELADA;

        if(this.cooperativaRegistro.solicitacaoCancelamento){
            cooperativaSolicitacaoTO.tipoAcaoSolicitacao = "UN_ACEITA_CANCELAMENTO";
             this.apiSolicitacaoService.unAceitaCancelar(cooperativaSolicitacaoTO).then((response) => {
            if (response) {
                this.onConcluir.emit();
            }
            this.changeDetectorRef.markForCheck();
        });
        }else{
            cooperativaSolicitacaoTO.tipoAcaoSolicitacao = "UN_CANCELAR";
             this.apiSolicitacaoService.unCancela(cooperativaSolicitacaoTO).then((response) => {
            if (response) {
                this.onConcluir.emit();
            }
            this.changeDetectorRef.markForCheck();
        });
        }
    }

    confirmarSolicitacao(){
        if(this.aceitarSolicitacao){
            const cooperativaSolicitacaoTO = new CooperativaSolicitacaoCancelamentoTO();
            cooperativaSolicitacaoTO.justificativa = this.justificativa;
            cooperativaSolicitacaoTO.idCooperativa = this.cooperativa.id;
            if(this.cooperativaRegistro.cooperativaSolicitacao.solicitacao?.motivoSolicitacao != null){
                cooperativaSolicitacaoTO.idMotivo =this.cooperativaRegistro.cooperativaSolicitacao.solicitacao.id;
            }
            cooperativaSolicitacaoTO.anexo = this.cooperativaRegistro.anexo;
            cooperativaSolicitacaoTO.situacaoCooperativa = NovaSituacaoEnum.CANCELADA;
            cooperativaSolicitacaoTO.solicitacaoCancelamento = true;
            cooperativaSolicitacaoTO.tipoAcaoSolicitacao = "UN_ACEITA_CANCELAMENTO";
            this.cooperativa.justificativaCancelada = this.justificativa;
            this.cooperativaRegistro.cooperativa = this.cooperativa;
            this.apiSolicitacaoService
                .unAceitaCancelar(cooperativaSolicitacaoTO)
                .then((response) => {
                    if (response) {
                        this.onConcluir.emit();
                    }
                    this.changeDetectorRef.markForCheck();
                });
        } else {
            const cooperativaSolicitacaoTO = new CooperativaSolicitacaoCancelamentoTO();
            cooperativaSolicitacaoTO.tipoAcaoSolicitacao = "UN_RECUSA_CANCELAMENTO";
            cooperativaSolicitacaoTO.justificativa = this.justificativa;
            cooperativaSolicitacaoTO.idCooperativa = this.cooperativa.id;
            cooperativaSolicitacaoTO.situacaoCooperativa = NovaSituacaoEnum.CANCELADA;
             this.apiSolicitacaoService.unRecusaCancelar(cooperativaSolicitacaoTO).then((response) => {
            if (response) {
                this.onConcluir.emit();
            }
            this.changeDetectorRef.markForCheck();
        });
        }
    }

    verificarRepositorioVazio(repositorio: Repositorio) {
        if (repositorio == null) {
            this.cooperativaRegistro.anexo = null;
        }
    }

}
