import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { MessageService, SelectItem } from 'primeng/api';
import { HttpParams } from '@angular/common/http';
import { Table } from 'primeng/table';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { Uf } from '@localizacao-api/models/Uf';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ProxyUrl } from '@auth/proxy-url/proxy-url.service';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { AnuarioTO } from '@cadastro-registro-api/models/AnuarioTO';
import { ApiAnuarioService } from '@cadastro-registro-api/services/api-anuario.service';
import { ValidacaoAnuario } from '../validacao/validacao-anuario.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-listagem-cooperativas-anuario',
  templateUrl: './listagem-cooperativas-anuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-cooperativas-anuario.component.css']
})
export class ListagemCooperativasAnuarioComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  situacoes: SelectItem[];
  itens_anuario: SelectItem[];
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  listaUfs: Uf[] = [];
  filtroUf: Uf;
  filtroCnpj = '';
  filtroNomeFantasia = '';
  filtroRamo: Ramo;
  filtroSituacao = '';
  filtroStatus = '';
  filtroAnuario = '';
  modalImportarAnuarios = false;
  urlImportacao = '';
  file: File;
  importacaoAnuarioRepositorio = '';
  response: IServiceResponse<IPage<AnuarioTO>>;
  cols: { field: string, header: string, width: string }[];
  @ViewChild('dt') dt: Table;
  mensagensValidacao = Array<{ summary: string; detail: string }>();
  sucesso: number;
  anuarios: AnuarioTO[] = [];
  anos: { label: number; value: number }[] = [];
  anoSelecionado: number;

  constructor(
    private keycloakService: KeycloakService,
    private dadosGeraisService: ApiManutencaoDadosGeraisService,
    private cooperativaService: ApiCooperativaService,
    private utilityService: UtilityService,
    private router: Router,
    private messageService: MessageService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private proxyUrl: ProxyUrl,
    private anuarioService: ApiAnuarioService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: 'inicio' },
      { label: 'Anuário/', routerLink: '/cooperativa/listagem-anuario' }
    ]);

    this.urlImportacao = this.proxyUrl.obterUrl('/cooperativas-importacao-api/api/v1/importacao/anuario/');


  }

  ngOnInit() {
    const year = new Date().getFullYear();
    this.anoSelecionado = year;
    this.anos = [
      ...Array.from({ length: 6 }, (_, index) => ({
        label: year - index,
        value: year - index
      }))
    ];
    if (!this.keycloakService.isUsuarioNacional) {
      this.router.navigate(['/']);
    }

    this.buscarUF();

    this.cols = [
      { field: 'TX_CNPJ', header: 'CNPJ', width: '170px' },
      { field: 'TX_NOME_FANTASIA', header: 'Nome fantasia', width: '280px' },
      { field: 'TX_NOVA_SITUACAO_COOPERATIVA', header: 'Situação do registro', width: '146px' },
      { field: 'SQ_RAMO', header: 'Ramo', width: '140px' },
      { field: 'NR_ANO', header: 'Anuário', width: '140px' },
    ];

    this.situacoes = [
      { label: 'Regular', value: 'REGULAR' },
      { label: 'Irregular', value: 'IRREGULAR' },
      { label: 'Suspenso', value: 'SUSPENSO' },
      { label: 'Cancelada', value: 'CANCELADA' }
    ];

    this.itens_anuario = [
      { label: 'Preenchido', value: 'PREENCHIDO' },
      { label: 'Não Preenchido', value: 'NAO_PREENCHIDO' }
    ];
  }

  get isNacional() {
    return this.keycloakService.isUsuarioNacional;
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  loadLazy(event) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.response = undefined;
    this.consultar(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then(resp => {
      resp.data.content.forEach((item) => {
        item.situacaoCooperativa = this.carregaSituacaoCooperativa(item.situacaoCooperativa);
      });
      this.response = resp;
      this.anuarios = resp.data.content;
      this.changeDetectorRef.markForCheck();
    });
  }

  onRowSelect(event) {
    this.cooperativaService.marcarComoVisualizada(event.data.idCooperativa);
    this.router.navigate(['/cooperativa/editar-anuario/' + event.data.idCooperativa]);
  }

  consultar(pagina = 0, sortField, sortOrder = 1) {
    sortField = sortField || 'TX_NOME_FANTASIA';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.anuarioService.filtrarPaginado(this.anoSelecionado, options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroNomeFantasia, options.params, 'nomeFantasia');
    options.params = this.utilityService.carregaParamsString(this.filtroCnpj, options.params, 'cnpj');
    options.params = this.utilityService.carregaParamsString(this.filtroRamo ? this.filtroRamo.nome : '', options.params, 'ramo');
    options.params = this.utilityService.carregaParamsString(this.filtroUf ? this.filtroUf.sigla : '', options.params, 'uf');
    options.params = this.utilityService.carregaParamsString(this.filtroSituacao, options.params, 'situacaoCooperativa');
    options.params = this.utilityService.carregaParamsString(this.filtroStatus, options.params, 'regularidadeCooperativa');
    options.params = this.utilityService.carregaParamsString(this.filtroAnuario, options.params, 'anuario');


    return options;
  }

  montarOptionsExportacao() {
    const options = this.carregaOptions('0', this.response.data.totalElements.toString(), 'nomeFantasia', 'desc');
    options.params = options.params.set('ativo', true + '');
    options.params = options.params.set('ano', this.anoSelecionado);
    return options;
  }

  exportarTabela() {
    if (this.response && this.response.data) {
      this.anuarioService.filtrarAnuarioListagemExcel(this.montarOptionsExportacao())
      .then(response => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Cooperativas_Anuarios.xlsx');
        this.changeDetectorRef.markForCheck();
      }).catch(error => {
        if (error.status && error.status === 404) {
          this.messageService.add({ severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000 });
        } else {
          this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
        }
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não existem registros para serem exportados.', life: 100000 });
    }
  }

  buscarUF() {
    this.dadosGeraisService.buscarUfs().then((res) => {
      if (res && res.content != null) {
        this.listaUfs = res.content;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  carregaSituacaoCooperativa(situacao: string) {
    switch (situacao) {
      case 'REGULAR':
        return 'Regular';
      case 'CANCELADA':
        return 'Cancelada';
      case 'IRREGULAR':
        return 'Iregular';
      default:
        return situacao;
    }
  }

  importarAnuarios() {
    this.modalImportarAnuarios = true;
  }

  onUpload(event) {
    this.file = event.file;
    const res = JSON.parse(event.xhr.responseText);
    this.mensagensValidacao = res.data.mensagensErro.map((msg: IServiceMessage) => ({
      summary: (msg.message.indexOf('<b>') === -1) ? '' : msg.message.substring((msg.message.indexOf('<b>') + 3), msg.message.indexOf('</b>')),
      detail: (msg.message.indexOf('<b>') === -1) ? msg.message : msg.message.substring((msg.message.indexOf('</b>') + 4))
    }));
    this.sucesso = res.data.sucesso;
  }


}
