import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoAnuario {
  constructor(
    private keycloakService: KeycloakService
  ){}


  podeVerAlterarAnuario() {
    if(
    (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA)
    )){
      return true;
    }

    return false;
  }
}
