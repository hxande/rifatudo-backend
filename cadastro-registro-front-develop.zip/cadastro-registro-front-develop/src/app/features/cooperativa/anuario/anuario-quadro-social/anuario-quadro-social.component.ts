import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, Input, OnInit } from '@angular/core';
import { QuadroSocialAnuarioTO } from 'src/app/api/models/QuadroSocialAnuarioTO'
import { AnuarioQuadroSocialService } from 'src/app/api/services/api-anuario-quadro-social.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { QuadroSocialUFTO } from 'src/app/api/models/QuadroSocialUFTO';
import { Observable, Subscription } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';



@Component({
    selector: 'app-anuario-quadro-social',
    templateUrl: './anuario-quadro-social.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./anuario-quadro-social.component.css']
})
export class AnuarioQuadroSocialComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);
    private readonly destroyRef = inject(DestroyRef);

    @Input() ano;
    @Input() idCooperativa;

    @Input() carregarDadosTela: Observable<number>;

    private carregarDadosTelaSubscription: Subscription;

    quadroSocialAnuario: QuadroSocialAnuarioTO;

    listaQuadroSocialAnuario: QuadroSocialAnuarioTO[];

    constructor(private apiAnuarioQuadroSocialService: AnuarioQuadroSocialService
    ) { }


    ngOnInit(): void {
        this.carregarDadosTelaSubscription = this.carregarDadosTela?.pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(() => {
          this.carregarQuadroSocial()
          this.changeDetectorRef.markForCheck();
        });
    }

    carregarQuadroSocial() {
        this.apiAnuarioQuadroSocialService.obterQuadroSocialAnuario(this.idCooperativa, this.ano)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(response => {
            this.quadroSocialAnuario = response.data;
            this.listaQuadroSocialAnuario = [];
            this.listaQuadroSocialAnuario = [
              ...this.listaQuadroSocialAnuario,
              this.quadroSocialAnuario
            ]
            this.changeDetectorRef.markForCheck();
        });
    }



    atualizaQuadroSocialUF(quadroSocial: QuadroSocialUFTO) {
        this.normalizarQuadroSocialUF(quadroSocial);

        if (!Number.isNaN(quadroSocial.cooperadosHomensUF) || !Number.isNaN(quadroSocial.cooperadosMulheresUF)) {
            quadroSocial.cooperadosPFUF = quadroSocial.cooperadosHomensUF + quadroSocial.cooperadosMulheresUF;
        } else {
            quadroSocial.cooperadosPFUF = null;
        }

        if (!Number.isNaN(quadroSocial.cooperadosPFUF) || !Number.isNaN(quadroSocial.cooperadosPJUF)) {
            quadroSocial.cooperadosTotalUF = quadroSocial.cooperadosPFUF + quadroSocial.cooperadosPJUF;;
        } else {
            quadroSocial.cooperadosTotalUF = null;
        }

        if (!Number.isNaN(quadroSocial.empregadosHomensUF) || !Number.isNaN(quadroSocial.empregadosMulheresUF)) {
            quadroSocial.empregadosTotalUF = quadroSocial.empregadosHomensUF + quadroSocial.empregadosMulheresUF;
        } else {
            quadroSocial.empregadosTotalUF = null;
        }

        if(quadroSocial.cooperadosHomensUF == null && quadroSocial.cooperadosMulheresUF == null){
            quadroSocial.cooperadosPFUF = null;
        }

        if(quadroSocial.cooperadosPFUF == null && quadroSocial.cooperadosPJUF == null){
            quadroSocial.cooperadosTotalUF = null;
        }

        if(quadroSocial.empregadosHomensUF == null && quadroSocial.empregadosMulheresUF == null){
            quadroSocial.empregadosTotalUF = null;
        }

        this.totalizaQuadroSocial();
    }

    changeDetalhaQuadroSocial(){
        if(this.quadroSocialAnuario.informaCooperadosUF == true || this.quadroSocialAnuario.informaEmpregadosUF == true){
            this.totalizaQuadroSocial();
        }
    }

    atualizaQuadroSocial(quadroSocial: QuadroSocialAnuarioTO) {
        this.normalizarQuadroSocial(quadroSocial);

        if (!Number.isNaN(quadroSocial.cooperadosHomens) || !Number.isNaN(quadroSocial.cooperadosMulheres)) {
            quadroSocial.cooperadosPF = quadroSocial.cooperadosHomens + quadroSocial.cooperadosMulheres;
        } else {
            quadroSocial.cooperadosPF = null;
        }

        if (!Number.isNaN(quadroSocial.cooperadosPF) || !Number.isNaN(quadroSocial.cooperadosPJ)) {
            quadroSocial.cooperadosTotal = quadroSocial.cooperadosPF + quadroSocial.cooperadosPJ;
        } else {
            quadroSocial.cooperadosTotal = null;
        }

        if (!Number.isNaN(quadroSocial.empregadosHomens) || !Number.isNaN(quadroSocial.empregadosMulheres)) {
            quadroSocial.empregadosTotal = quadroSocial.empregadosHomens + quadroSocial.empregadosMulheres;
        } else {
            quadroSocial.empregadosTotal = null;
        }

        if(quadroSocial.cooperadosHomens == null && quadroSocial.cooperadosMulheres == null){
            quadroSocial.cooperadosPF = null;
        }

        if(quadroSocial.cooperadosPF == null && quadroSocial.cooperadosPJ == null){
            quadroSocial.cooperadosTotal = null;
        }

        if(quadroSocial.empregadosHomens == null && quadroSocial.empregadosMulheres == null){
            quadroSocial.empregadosTotal = null;
        }
    }


    normalizarQuadroSocialUF(quadroSocial: QuadroSocialUFTO): void {
        quadroSocial.empregadosHomensUF = this.somenteNumeros(quadroSocial.empregadosHomensUF);
        quadroSocial.empregadosMulheresUF = this.somenteNumeros(quadroSocial.empregadosMulheresUF);
        quadroSocial.empregadosTotalUF = this.somenteNumeros(quadroSocial.empregadosTotalUF);
        quadroSocial.cooperadosHomensUF = this.somenteNumeros(quadroSocial.cooperadosHomensUF);
        quadroSocial.cooperadosMulheresUF = this.somenteNumeros(quadroSocial.cooperadosMulheresUF);
        quadroSocial.cooperadosAtivosUF = this.somenteNumeros(quadroSocial.cooperadosAtivosUF);
        quadroSocial.cooperadosPJUF = this.somenteNumeros(quadroSocial.cooperadosPJUF);
    }

    normalizarQuadroSocial(quadroSocial: QuadroSocialAnuarioTO): void {
        quadroSocial.empregadosHomens = this.somenteNumeros(quadroSocial.empregadosHomens);
        quadroSocial.empregadosMulheres = this.somenteNumeros(quadroSocial.empregadosMulheres);
        quadroSocial.empregadosTotal = this.somenteNumeros(quadroSocial.empregadosTotal);
        quadroSocial.cooperadosHomens = this.somenteNumeros(quadroSocial.cooperadosHomens);
        quadroSocial.cooperadosMulheres = this.somenteNumeros(quadroSocial.cooperadosMulheres);
        quadroSocial.cooperadosAtivos = this.somenteNumeros(quadroSocial.cooperadosAtivos);
        quadroSocial.cooperadosPJ = this.somenteNumeros(quadroSocial.cooperadosPJ);
    }

    totalizaQuadroSocial(){

            if(this.quadroSocialAnuario.informaCooperadosUF){
               this.quadroSocialAnuario.cooperadosAtivos = null;
               this.quadroSocialAnuario.cooperadosHomens = null;
               this.quadroSocialAnuario.cooperadosMulheres = null;
               this.quadroSocialAnuario.cooperadosPF = null;
               this.quadroSocialAnuario.cooperadosPJ = null;
               this.quadroSocialAnuario.cooperadosTotal = null;
            }

            if(this.quadroSocialAnuario.informaEmpregadosUF){
                this.quadroSocialAnuario.empregadosHomens = null;
                this.quadroSocialAnuario.empregadosMulheres = null;
                this.quadroSocialAnuario.empregadosTotal = null;
            }
            this.listaQuadroSocialAnuario[0].listaQuadroSocialUFTO.forEach(quadroSocialUf => {
                this.normalizarQuadroSocialUF(quadroSocialUf);
                if(this.quadroSocialAnuario.informaCooperadosUF){
                    this.quadroSocialAnuario.cooperadosAtivos = this.somarValor(this.quadroSocialAnuario.cooperadosAtivos,quadroSocialUf.cooperadosAtivosUF);
                    this.quadroSocialAnuario.cooperadosHomens = this.somarValor(this.quadroSocialAnuario.cooperadosHomens,quadroSocialUf.cooperadosHomensUF);
                    this.quadroSocialAnuario.cooperadosMulheres = this.somarValor(this.quadroSocialAnuario.cooperadosMulheres,quadroSocialUf.cooperadosMulheresUF);
                    this.quadroSocialAnuario.cooperadosPF = this.somarValor(this.quadroSocialAnuario.cooperadosPF,quadroSocialUf.cooperadosPFUF);
                    this.quadroSocialAnuario.cooperadosPJ = this.somarValor(this.quadroSocialAnuario.cooperadosPJ,quadroSocialUf.cooperadosPJUF);
                    this.quadroSocialAnuario.cooperadosTotal = this.somarValor(this.quadroSocialAnuario.cooperadosTotal,quadroSocialUf.cooperadosTotalUF);
                }
                if(this.quadroSocialAnuario.informaEmpregadosUF){
                    this.quadroSocialAnuario.empregadosHomens = this.somarValor(this.quadroSocialAnuario.empregadosHomens,quadroSocialUf.empregadosHomensUF);
                    this.quadroSocialAnuario.empregadosMulheres = this.somarValor(this.quadroSocialAnuario.empregadosMulheres,quadroSocialUf.empregadosMulheresUF);
                    this.quadroSocialAnuario.empregadosTotal = this.somarValor(this.quadroSocialAnuario.empregadosTotal,quadroSocialUf.empregadosTotalUF);
                }
            });

    }

    somarValor(valorAtual,valorASomar): number {
        if(valorAtual != null && valorASomar != null) {
            return valorAtual + valorASomar;
        } else if(valorAtual != null || valorASomar != null){
            return valorAtual ?? valorASomar;
        } else {
            return null;
        }
    }

    somenteNumeros(valor): number {
        let saida = null;
        if (valor != null) {
            const valorInteiro = parseInt((String(valor)).replace(/\D+/g, ''), 10);
            if (!Number.isNaN(valorInteiro) && !isNaN(valorInteiro)) {
                if (valorInteiro > 99999999) {
                    saida = 99999999;
                } else {
                    saida = valorInteiro;
                }
            }
        }
        return saida;
    }
}
