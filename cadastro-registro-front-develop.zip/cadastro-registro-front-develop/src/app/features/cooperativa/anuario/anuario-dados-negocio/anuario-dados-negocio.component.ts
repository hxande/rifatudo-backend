import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, EventEmitter, inject, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { ApiUFService, Pais } from '@localizacao-api/public-api';
import { AnuarioNegocioExportacaoService } from 'src/app/api/services/api-anuario-negocio-exportacao.service';
import { NegocioExportacaoPais } from 'src/app/api/models/NegocioExportacao';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
    selector: 'app-anuario-dados-negocio',
    templateUrl: './anuario-dados-negocio.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./anuario-dados-negocio.component.css']
})
export class AnuarioDadosNegocioComponent implements OnInit, OnDestroy {

    private readonly destroyRef = inject(DestroyRef);
    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() ano: number;
    @Input() idCooperativa: number;
    @Input() carregarDadosTela: Observable<void>;
    @Output() exportaChange = new EventEmitter<boolean>();

    form: FormGroup;
    opcoes: { label: string; value: boolean; icon: string }[] = [];
    listaModalidades: { nome: string; value: string }[] = [];
    listaPaises: Pais[] = [];

    private carregarDadosTelaSubscription: Subscription;
    carregando = false;

    constructor(
        private fb: FormBuilder,
        private anuarioNegocioExportacaoService: AnuarioNegocioExportacaoService,
        private apiUFService: ApiUFService
    ) { }

    async ngOnInit(): Promise<void> {
        this.inicializarOpcoes();
        this.inicializarModalidades();
        this.inicializarForm();
        await this.carregarPaises();
        this.carregarDados();

        this.form.get('exporta')?.valueChanges
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(value => {
            this.onExportaChange(value);
            this.changeDetectorRef.markForCheck();
        });

        if (this.carregarDadosTela) {
            this.carregarDadosTelaSubscription = this.carregarDadosTela.subscribe(() => {
                this.carregarDados();
                this.changeDetectorRef.markForCheck();
            });
        }
    }

    ngOnDestroy(): void {
        if (this.carregarDadosTelaSubscription) {
            this.carregarDadosTelaSubscription.unsubscribe();
        }
    }

    private inicializarOpcoes(): void {
        this.opcoes = [
            { label: 'Sim', value: true, icon: 'fa fa-check' },
            { label: 'Não', value: false, icon: 'fa fa-times' }
        ];
    }

    private inicializarModalidades(): void {
        this.listaModalidades = [
            { nome: 'Direta', value: 'DIRETA' },
            { nome: 'Indireta', value: 'INDIRETA' },
            { nome: 'Ambas', value: 'AMBAS' }
        ];
    }

    private inicializarForm(): void {
        this.form = this.fb.group({
            exporta: [null, Validators.required],
            modalidade: [{ value: null, disabled: true }],
            paises: [{ value: [], disabled: true }]
        });
    }

    private async carregarPaises(): Promise<void> {
        try {
            const resp = await this.apiUFService.obterPaises();
            this.listaPaises = resp.content;
        } catch (err) {
            console.error('Erro ao carregar países:', err);
        }
    }

    private carregarDados(): void {
        if (!this.idCooperativa || !this.ano) return;

        this.carregando = true;

        this.anuarioNegocioExportacaoService
            .obterNegocioExportacaoAnuario(this.idCooperativa, this.ano)
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: (resp) => {
                    const negocioExportacao = resp?.data;
                    if (negocioExportacao) {
                        this.form.patchValue({
                            exporta: negocioExportacao.exportacao,
                            modalidade: negocioExportacao.modalidade,
                            paises: this.listaPaises.filter(p =>
                                negocioExportacao.paises?.map((x: NegocioExportacaoPais) => x.id.paisId).includes(p.id)
                            )
                        });
                        this.onExportaChange(negocioExportacao.exportacao);
                    }
                    this.anuarioNegocioExportacaoService.verificarPendencias(this.idCooperativa, this.ano)
                        .pipe(takeUntilDestroyed(this.destroyRef))
                        .subscribe({
                            next: (resp) => {
                                this.changeDetectorRef.markForCheck();
                            }
                        })
                    this.changeDetectorRef.markForCheck();
                },
                error: (err) => console.error('Erro ao carregar negócio de exportação:', err),
                complete: () => {
                    this.carregando = false;
                    this.changeDetectorRef.markForCheck();
                }
            });
    }

    onExportaChange(value: boolean): void {
        const modalidadeControl = this.form.get('modalidade');
        const paisesControl = this.form.get('paises');

        this.exportaChange.emit(value);

        if (value === true) {
            modalidadeControl?.enable();
            paisesControl?.enable();
            // modalidadeControl?.setValidators(Validators.required);
            // paisesControl?.setValidators(Validators.required);
        } else {
            modalidadeControl?.reset();
            paisesControl?.reset();
            modalidadeControl?.disable();
            paisesControl?.disable();
            // modalidadeControl?.clearValidators();
            // paisesControl?.clearValidators();
        }

        modalidadeControl?.updateValueAndValidity();
        paisesControl?.updateValueAndValidity();
    }

    salvar(): void {
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            return;
        }

        const { exporta, modalidade, paises } = this.form.value;

        const negocioExportacao = {
            cooperativaId: this.idCooperativa,
            ano: this.ano,
            exportacao: exporta,
            modalidade: modalidade,
            paises: (paises || []).map((p: Pais) => ({
                id: p.id,
                nome: p.nome
            }))
        };

        this.anuarioNegocioExportacaoService
            .salvarNegocioExportacaoAnuario(negocioExportacao)
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe({
                next: ((resp) => {
                    this.changeDetectorRef.markForCheck();
                }),
                error: (err) => console.error('Erro ao salvar negócio exportação:', err)
            });
    }
}
