import { ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Anuario } from '@cadastro-registro-api/models/Anuario';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { PessoaImagem } from '@cadastro-registro-api/models/PessoaImagem';
import { ApiAnuarioService } from '@cadastro-registro-api/services/api-anuario.service';
import { ApiCooperativaLogoService } from '@cadastro-registro-api/services/api-cooperativa-logo.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ValidacaoAnuario } from '../validacao/validacao-anuario.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-mantem-anuario',
  templateUrl: './mantem-anuario.component.html',
  styleUrls: ['./mantem-anuario.component.css']
})
export class MantemAnuarioComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  idCooperativa: number;
  cooperativa: Cooperativa;
  anuario: Anuario;
  @ViewChild('anuarioForm') anuarioForm: NgForm;
  logotipo: PessoaImagem = new PessoaImagem();
  anos: { label: number, value: number }[] = [];
  anoSelecionado = 0;
  salvando = false;


  constructor(
    private apiAnuario: ApiAnuarioService,
    private keycloakService: KeycloakService,
    private route: ActivatedRoute,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private cooperativaLogoService: ApiCooperativaLogoService,
    private cooperativaService: ApiCooperativaService,
    public validacaoAnuario: ValidacaoAnuario,

  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Anuário', routerLink: '/cooperativa/editar-anuario' }
    ]);
  }

  imagemLogo(logo){
    this.logotipo.imagemLogo = logo.imagemLogo;
  }

  ngOnInit() {
    const year = new Date().getFullYear();
    this.anos = Array.from({ length: 6 }, (_, i) => {
      const ano = year - i;
      return { label: ano, value: ano };
    });

    this.anoSelecionado = year;
    this.route.params.subscribe(params => {
      if (params['id']) {
        this.idCooperativa = params['id'];

        this.cooperativaService.get(this.idCooperativa)
        .then(response => {
          this.cooperativa = response.data;
          this.changeDetectorRef.markForCheck();
        });

        this.apiAnuario.getList(this.idCooperativa)
          .then(res => {
            const anuarios = res.data;
            if (anuarios.length > 0) {
              for (const an of anuarios) {
                if (this.anuario == null) {
                  this.anuario = an;
                  this.anoSelecionado = this.anuario.ano;
                } else if (this.anuario.ano < an.ano) {
                  this.anuario = an;
                  this.anoSelecionado = this.anuario.ano;
                }
              }
            } else {
              this.anuario = new Anuario();
              this.anoSelecionado = year;
              this.anuario.ano = this.anoSelecionado;
              this.anuario.cooperativa = this.cooperativa;
            }
            this.changeDetectorRef.markForCheck();
          });

      } else {
        this.keycloakService.getPessoaJuridica().then(response => {
          this.idCooperativa = response.id;
          this.cooperativaService.get(this.idCooperativa).then(retorno => {
            this.cooperativa = retorno.data;
            this.changeDetectorRef.markForCheck();
          });
          // Logotipo da cooperativa
          this.logotipo.idPessoa = this.idCooperativa;

          this.apiAnuario.getList(this.idCooperativa)
            .then(res => {
              const anuarios = res.data;
              if (anuarios.length > 0) {
                for (const an of anuarios) {
                  if (this.anuario == null) {
                    this.anuario = an;
                    this.anoSelecionado = this.anuario.ano;
                  } else if (this.anuario.ano < an.ano) {
                    this.anuario = an;
                    this.anoSelecionado = this.anuario.ano;
                  }
                }
              } else {
                this.anuario = new Anuario();
                this.anoSelecionado = year;
                this.anuario.ano = this.anoSelecionado;
                this.anuario.cooperativa = this.cooperativa;
              }
              this.changeDetectorRef.markForCheck();
            });
        });


      }

    });

  }

  salvar(): void {
    if (this.anuarioForm.invalid || this.salvando) {
      return;
    }
    this.anuario.cooperativa = this.cooperativa;
    this.salvando = true;
    this.apiAnuario.create(this.anuario)
      .then(retorno => {
        this.anuario = retorno.data;
        this.changeDetectorRef.markForCheck();
      })
      .finally(() => {
        this.salvando = false;
        this.changeDetectorRef.markForCheck();
      });
  }

  isNacional(): boolean {
    return this.keycloakService.isUsuarioNacional;
  }

  consultarAnuario() {
    this.apiAnuario.getByAno(this.idCooperativa, this.anoSelecionado)
    .then(result => {
      if (!result.data) {
        this.anuario = new Anuario();
        this.anuario.cooperativa = this.cooperativa;
        this.anuario.ano = this.anoSelecionado;
      } else {
        this.anuario = result.data;
      }
      this.changeDetectorRef.markForCheck();
    });
  }

}
