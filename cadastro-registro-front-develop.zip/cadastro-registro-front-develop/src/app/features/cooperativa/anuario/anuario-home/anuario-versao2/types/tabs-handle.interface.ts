import { FormGroup } from "@angular/forms";
import { TabInterface } from "./tabs.interface";


export interface ITabHandler {
  montarDadosComponentes(): void;
  onFieldChange(fieldId: string, value: string | number | string[] | null, form: FormGroup, tab: TabInterface): void;
  salvarFormulario(tab: TabInterface, controlName: string, activeFormGroup: FormGroup): void;
}
