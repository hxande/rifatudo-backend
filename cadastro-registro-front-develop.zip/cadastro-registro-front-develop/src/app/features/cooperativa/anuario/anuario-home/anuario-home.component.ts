import { ChangeDetectionStrategy, Component, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';

@Component({
  selector: 'app-anuario-home',
  templateUrl: './anuario-home.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./anuario-home.component.css'],
})
export class AnuarioHomeComponent {

}
