# 🧩 Sistema de Formulário Dinâmico  
### Fluxo e Casos de Uso Detalhados

✨ **Este módulo implementa um sistema de formulários complexos** onde a estrutura (campos, agrupamentos, abas) é definida por **dados de configuração carregados dinamicamente**, em vez de código estático.

---

## 1. Interfaces de Definição de Dados (`tabs.interface.ts`)

Esta seção define o **contrato de dados** que todos os componentes consomem.

### 1.1. Estruturas de Status e Valores

| Interface/Enum | Propósito |
|----------------|------------|
| **StatusAccordion (Enum)** | Define os estados possíveis de um painel de acordeão (`PENDENTE`, `COMPLETO`, `PARCIAL`). |
| **ValueTabField (Interface)** | Estrutura para campos que contêm opções e um valor selecionado (ex: `select`, `radio`, `selectButton`). |

---

### 1.2. Definição da Estrutura

#### **TabField (O Componente Mais Básico)**

Define um **controle individual** do formulário.

**Exemplo de Caso de Uso:**  
Descrever como um campo de Input de Número com Máscara de Moeda deve se comportar.

```typescript
{
  id: 'valorFinanciado',
  type: 'input',
  label: 'Valor a Financiar',
  required: true,
  inputType: 'number', 
  hasMask: true,
  mask: 'currency', 
  siglaUnidade: 'R$',
  hasInfo: true,
  infoText: 'Valor máximo permitido de 1.000.000.'
}
```

---

#### **TabDataInterface (O Agrupador — Painel do Acordeão)**

Define um **grupo de campos dentro de uma aba**, renderizado pelo `DynamicAccordionComponent`.

**Exemplo de Caso de Uso:**  
Criar uma seção de *Dados Cadastrais* que contém campos de texto e um campo de acordeão aninhado.

```typescript
{
  id: 'secaoDadosBasicos',
  title: 'Informações Principais',
  fields: [
    {
      id: 'subForm',
      type: 'accordion',
      label: 'Detalhes Adicionais',
      accordions: [  ]
    }
  ]
}
```

---

#### **TabInterface (A Aba Principal)**

Define uma aba no `DynamicTabviewComponent`.

**Exemplo de Caso de Uso:**  
Configurar a aba **"Dados Sociais"** que carrega seus dados como uma lista de acordeões.

```typescript
{
  id: 'dados_sociais',
  title: 'Dados Sociais',
  tabPreenchida: false,
  content: {
    type: 'accordion',
    data: [  ]
  }
}
```

---

## 2. Componentes Principais e Fluxo de Renderização

O **fluxo de dados** segue de cima para baixo, com *events* de baixo para cima para comunicação.

---

### 🧠 A. `DynamicWrapperComponent` — *O Controller Central*

**Responsabilidade Principal:**  
Orquestração, busca de dados e gerenciamento do `FormGroup` mestre.

| Método/Ação | Fluxo de Dados | Caso de Uso Prático |
|--------------|----------------|----------------------|
| **init()** | Busca cooperativa e abas do backend. | Carrega o contexto do usuário e as abas disponíveis para o ano atual. |
| **carregarDadosAbaAtiva()** | Decide qual serviço chamar (ex: `apiAnuarioQuadroSocialService`) com base no `activeIndex`. | Alternar para a aba "Dados Sociais" e buscar os dados do quadro social. |
| **criarFormularioAba(tipoAba, dados)** | Usa `TabFactory` para montar o formulário dinâmico. | Transforma os dados brutos do servidor no formato esperado pelo `DynamicTabviewComponent`. |
| **onFieldAlterado(event)** | Propaga mudanças e atualiza o `FormGroup` mestre. | Um campo é alterado → o handler da aba executa lógica condicional. |

---

### 🗂️ B. `DynamicTabviewComponent` — *O Gerenciador de Abas*

**Responsabilidade Principal:**  
Estruturar o formulário com `FormGroups` aninhados por aba e gerenciar o status visual.

| Propriedade/Método | Função | Caso de Uso Prático |
|--------------------|--------|----------------------|
| `@Input() formGroup` | Recebe o `FormGroup` mestre do Wrapper. | Cria um `FormGroup` de controle para cada aba. |
| `getTabStatus(tab)` | Verifica se uma aba está completa. | Exibe ícone verde (`pi-check-circle`) na aba "Contábil Tributário" se válida. |
| `onTabChange(index)` | Emite o novo índice ativo. | O `DynamicWrapperComponent` usa para saber qual dado carregar em seguida. |

**🧩 Lógica Especial de Portfólio:**  
Calcula `totalSegmentosPortfolio` vs `segmentosCompletosPortfolio`, garantindo que a **barra de progresso** da aba "Portfólio" reflita corretamente o preenchimento.

---

### 📁 C. `DynamicAccordionComponent` — *O Agrupador de Controles*

**Responsabilidade Principal:**  
Criar `FormGroups` para cada painel (acordeão) e **vincular campos individuais**.

| Propriedade/Método | Função | Caso de Uso Prático |
|--------------------|--------|----------------------|
| `ngOnInit` | Itera sobre `accordionData` e cria `FormGroups` aninhados. | Cada painel de dados sociais cria um `FormGroup` dentro do grupo da aba. |
| `formGroupsMap` | Mapa de acesso rápido aos FormGroups filhos. | Usado no template: `<form [formGroup]="formGroupsMap[...]">`. |
| `panelStatus` | Monitora validade de cada painel. | Atualiza status de "Pendente" para "Completo" ao preencher campos. |

---

### 🧱 D. `DynamicFieldComponent` — *O Renderizador de Campo*

**Responsabilidade Principal:**  
Renderizar o controle Angular/PrimeNG e **emitir mudanças padronizadas**.

| Propriedade/Método | Função | Caso de Uso Prático |
|--------------------|--------|----------------------|
| `@Input() field`, `@Input() formGroup` | Recebe a definição e o grupo pai. | Garante renderização correta com `formControlName`. |
| `ngOnInit / valueChanges` | Assina mudanças e emite `fieldChanged`. | `{ fieldId: 'meu_campo_id', value: 'novo_valor' }`. |
| `onKeyDown / apenasNumeros` | Sanitiza entradas numéricas. | Bloqueia `e`, `+`, `-` em campos numéricos positivos. |

---

## 3. 🧭 Conclusão do Fluxo de Dados

O processo completo de **preenchimento e atualização** do formulário segue este caminho:

1. **Estrutura:**  
   `DynamicWrapperComponent` busca as `TabInterface` e as carrega em `tabs`.

2. **Renderização:**  
   `DynamicTabviewComponent` cria as abas e seus `FormGroups`.

3. **Detalhe:**  
   `DynamicAccordionComponent` cria painéis e campos (`TabField`).

4. **Interação:**  
   O usuário interage com os campos via `DynamicFieldComponent`.

5. **Feedback:**  
   `DynamicFieldComponent` → `DynamicWrapperComponent` → *Handler da aba* é notificado.

6. **Validação:**  
   A atualização do `FormGroup` propaga o status, refletindo nos ícones e painéis.

---

## 🧩 Benefício Arquitetural

> Este sistema **desacopla completamente** a estrutura do formulário (definida pelas interfaces e dados carregados) da **lógica de renderização e manipulação** (implementada nos componentes).  

Isso permite:
- Escalabilidade de novos formulários sem alterar código-fonte;
- Reutilização de componentes genéricos;
- Lógica condicional isolada por aba;
- Maior manutenibilidade e flexibilidade para novas regras de negócio.

---

# 🧠 Detalhamento: DynamicWrapperComponent (O Orquestrador)

O `DynamicWrapperComponent` é o **container de mais alto nível** para a funcionalidade do formulário dinâmico.  
Sua principal responsabilidade é **gerenciar o estado, buscar dados do backend e coordenar a montagem da estrutura do formulário** (o schema).

---

## 1. Responsabilidades e Propriedades Chave

| Propriedade | Tipo | Propósito |
|--------------|------|-----------|
| `tabs` | `TabInterface[]` | A lista de abas a serem exibidas; este array é atualizado dinamicamente. |
| `form` | `FormGroup` | O FormGroup mestre do Angular, criado em `init()`. Contém todos os sub-grupos de todas as abas. |
| `cooperativa` | `Cooperativa` | Dados de contexto da entidade (Cooperativa) sendo preenchida. |
| `activeIndex` | `number` | O índice da aba atualmente visível e ativa. |
| `activeHandler` | `ITabHandler` | A instância do Handler específica para a aba ativa (ex: `DadosSociaisHandler`), crucial para a lógica de negócio. |

---

## 2. Fluxo de Inicialização e Carregamento de Dados (`init()`)

O método `init()` executa a sequência de carregamento assíncrono que prepara a tela:

### 🔹 Etapas Principais

1. **`getDadosCooperativa()`**  
   Busca os dados da Cooperativa usando o ID da rota (`route.params['id']`) ou, se for um novo cadastro, busca a cooperativa logada via `KeycloakService`.  
   → Este é o **contexto principal**.

2. **`carregarCooperativaAnuarioAbas()`**  
   Busca a estrutura de abas registradas para o ano (ano anterior ao atual) no backend, usando `apiCooperativaAnuarioAbasService`.  
   Obtém também o **status inicial** (`abaPreenchida`).

3. **`carregarDadosAbaAtiva()`**  
   Aciona o carregamento dos dados e a montagem do formulário para a primeira aba (ou a aba ativa, se for um retorno).

4. **Inicializa o FormGroup Mestre:**  
   ```typescript
   this.form = this.fb.group({});
   ```

---

## 3. Orquestração por Aba (Montagem Dinâmica)

A lógica do Wrapper garante que a estrutura do formulário (`content.data`) seja carregada sob demanda (**Lazy Loading**).

### **`onTabChange(index)`**
Chamado quando o usuário muda de aba no `<app-dynamic-tabview>`:

- Atualiza `this.activeIndex`.
- Chama `carregarDadosAbaAtiva()`.

### **`carregarDadosAbaAtiva()` e `criarFormularioAba(tipoAba, dados)`**
- **Busca Específica:** O `switch` em `carregarDadosAbaAtiva()` chama o serviço de API correto (ex: `apiAnuarioQuadroSocialService`) para obter os dados brutos da aba.  
- **Criação do Handler:**  
  Chama `TabFactory.createHandler(tipoAba.key, dados)`, que instancia o manipulador de lógica específico (Handler).  
- **Montagem da Estrutura:**  
  Chama `handler.montarDadosComponentes()`, transformando os dados brutos no **schema `TabDataInterface[]`** que os componentes dinâmicos conseguem renderizar.  
- **Atualização do `tabs`:**  
  Atualiza o array imutavelmente (`[...this.tabs.slice(0, index), novaAba, ...]`), acionando o `DynamicTabviewComponent` para renderizar o conteúdo.

---

## 4. Reatividade e Lógica de Negócio

O Wrapper é o **único componente que possui a inteligência de negócio em tempo real**.

### **`onFieldAlterado(event)`**
Método de entrada para todas as mudanças de campo:

1. Recebe o evento (`fieldId`, `value`, `formGroup`) do `DynamicFieldComponent`.
2. Verifica se o `this.activeHandler` possui o método `onFieldChange`.
3. Se sim, delega a lógica ao Handler.

**Exemplo:**  
Se o campo **A** for marcado, o Handler usa o `event.formGroup` para **desabilitar o campo B** dentro do mesmo acordeão.

---

## 5. Finalização e Validação

### **`onSubmit()`**
Método de submissão do formulário:

1. Identifica o `FormGroup` aninhado da aba ativa (`this.form.get(controlName)`).  
2. Acessa os valores (`activeFormGroup.getRawValue()`) para montar o payload.  
3. Executa a verificação de validade (`activeFormGroup.invalid`).

### **`temErrosNoCampos()`**
Este método usa o `AnuarioValidacaoService` para verificar **a integridade do schema dinâmico**, não dos dados em si.  
Valida se o mock está bem formado (campos obrigatórios definidos, estrutura coerente, etc).

---

## 🧩 Conclusão

O `DynamicWrapperComponent` atua como **View Model e Controller**:
- Coordena o carregamento de dados e estrutura das abas;
- Orquestra os Handlers específicos;
- Mantém a sincronização entre Angular Forms, backend e lógica de negócio;
- Implementa o padrão **Handler/Factory** para modularidade e reutilização.

# 🖥️ Detalhamento: DynamicTabviewComponent (O Container de Abas)

O **DynamicTabviewComponent** é o componente de layout principal que usa o **p-tabView** (do PrimeNG) para estruturar o formulário em abas navegáveis.  
Sua principal responsabilidade é gerenciar o estado ativo da aba e organizar a hierarquia de **FormGroups** no nível da aba.

---

## 1. Propriedades e Conexões

Este componente é o elo de ligação entre o **orquestrador (Wrapper)** e o **renderizador de conteúdo (Accordion)**.

| Propriedade | Tipo | Fluxo | Responsabilidade |
|--------------|------|-------|------------------|
| `@Input() tabs` | `TabInterface[]` | De cima para baixo | A estrutura de abas a ser renderizada (carregada pelo Wrapper). |
| `@Input() formGroup` | `FormGroup` | De cima para baixo | O FormGroup mestre do `DynamicWrapperComponent`. |
| `@Output() tabChange` | `EventEmitter<number>` | De baixo para cima | Notifica o Wrapper quando a aba ativa muda, acionando o carregamento dos dados da nova aba. |
| `@Output() fieldChanged` | `EventEmitter<any>` | De baixo para cima | Repassa os eventos de mudança de campo do acordeão para o Wrapper. |

---

## 2. Gerenciamento da Estrutura do Formulário

O método `ngOnInit` é crucial para estabelecer a hierarquia de formulários.

### 🔧 Criação do Sub-FormGroup

Para cada **tab** no array `tabs`, o componente adiciona um novo **FormGroup aninhado** ao `formGroup` mestre.

- Ele usa `getSafeControlName(tab.id)` para gerar um nome de controle seguro  
  (ex: `DADOS_SOCIAIS → dados_sociais`).
- Ação executada:
  ```typescript
  this.formGroup.addControl(controlName, this.fb.group({}));
  ```

Essa estrutura **isola o estado de cada aba** dentro do formulário mestre, permitindo que cada aba tenha seus próprios controles e validações.

### 🧩 Acesso ao Sub-FormGroup

O método `getTabFormGroup(id: string)` permite que o template acesse e passe o sub-FormGroup correto para o `DynamicAccordionComponent` aninhado:

```html
[formGroup]="getTabFormGroup(tab.id)"
```

---

## 3. Gerenciamento do Status Visual e Progresso

O componente é responsável por exibir o **status de conclusão** e o **progresso** da aba.

| Função | Lógica | Utilização no Template |
|--------|--------|-------------------------|
| `isTabComplete(tab)` | Verifica se todos os `FormControls` dentro do `FormGroup` daquela aba (incluindo acordeões) estão válidos. | Define o ícone de status da aba (✔️ verde ou ⚠️ amarelo). |
| `getTabStatus(tab)` | Combina o status dinâmico (`isTabComplete`) com o status inicial vindo do backend (`abaStatusMap`). | Exibe o ícone de status no cabeçalho da aba. |
| `getValidAccordionCountForActiveTab()` | Conta quantos `FormGroups` de acordeão na aba ativa são válidos. | Atualiza o progresso visual (ex: **3 de 5 painéis completos**). |

### ⚙️ Lógica Especial do Portfólio

Há um tratamento diferenciado para a aba **"portifolio"**:  
O progresso não depende apenas da validade dos `FormControls`, mas também de um conjunto de **segmentos externos**.

- Método: `verificarStatusSegmentosPortfolio()`  
- A barra de progresso é calculada com a fórmula:  
  ```typescript
  progresso = segmentosCompletosPortfolio / totalSegmentosPortfolio;
  ```

---

## 4. Interação com o DynamicWrapperComponent

Quando o usuário **clica em uma aba**, o método `onTabChange(index)` é disparado.

### Fluxo de Evento:
1. O componente emite:
   ```typescript
   tabChange.emit(this.activeIndex);
   ```
2. O `DynamicWrapperComponent` escuta esse evento e chama `carregarDadosAbaAtiva()`.
3. O wrapper busca os dados da nova aba e os injeta na estrutura de `tabs` (via Handler).
4. O formulário e os acordeões da aba são montados dinamicamente com os novos dados.

---

## 🧠 Conclusão

O **DynamicTabviewComponent** atua como **camada de apresentação** do sistema de formulários dinâmicos, garantindo:

- Organização visual e estrutural das abas.  
- Sincronização entre a lógica do Wrapper e o conteúdo renderizado.  
- Gestão reativa de estado e progresso de preenchimento.  
- Isolamento completo entre os contextos de cada aba.

Em resumo, é o **núcleo de interface** que mantém a integridade e a reatividade do **FormGroup mestre**, garantindo uma experiência fluida e modular no fluxo do formulário.



# 🗂️ Detalhamento: DynamicAccordionComponent

O **DynamicAccordionComponent** atua como o **Gerenciador de Seções (Painéis)**.  
Sua principal responsabilidade é traduzir o array de configuração `TabDataInterface[]` em painéis de acordeão interativos, criando e monitorando um **FormGroup** específico para cada painel.

---

## 1. Propriedades e Fluxo de Dados (Inputs/Outputs)

| Propriedade | Tipo | Fluxo | Responsabilidade |
|--------------|------|-------|------------------|
| `@Input() accordionData` | `TabDataInterface[]` | De cima para baixo | A definição da estrutura de cada painel de acordeão e seus campos. |
| `@Input() formGroup` | `FormGroup` | De cima para baixo | O FormGroup da Aba que recebe o componente. Todos os FormGroups dos painéis serão criados dentro deste. |
| `@Output() fieldChanged` | `EventEmitter<any>` | De baixo para cima | Repassa o evento de mudança de qualquer campo filho para o DynamicWrapperComponent. |

---

## 2. Criação do Formulário (`ngOnInit`)

Este é o método mais crítico do componente. Ele garante que a estrutura do formulário Angular seja sincronizada com a estrutura dos dados dinâmicos.

### Passos:

1. **Iteração:**  
   O componente itera sobre cada item em `accordionData` (cada painel).

2. **Criação do FormGroup do Painel:**  
   Para cada painel, ele:
   - Sanitiza o `panel.id` (ex: `'Dados Pessoais' → 'dados_pessoais'`).
   - Verifica se o `formGroup` pai já tem um controle com esse nome.
   - Se não tiver, cria um novo `FormGroup` para o painel:  
     ```typescript
     const group = this.fb.group({});
     ```

3. **Criação dos FormControls:**  
   Para cada `field` dentro do painel:
   - Sanitiza o `field.id`.
   - Define os validadores (`Validators.required` se `field.required` for `true`).
   - Define o valor inicial (`field.value` ou `field.value.selected` para tipos com opções).
   - Adiciona o `FormControl` ao `FormGroup` do painel:
     ```typescript
     group.addControl(safeName, this.fb.control(initialValue, validators));
     ```

4. **Associação:**  
   Adiciona o `FormGroup` do painel ao `formGroup` principal recebido:
   ```typescript
   this.formGroup.addControl(controlName, group);
   ```

   Isso cria o aninhamento:  
   `FormGroup da Aba → FormGroup do Painel → FormControl do Campo`.

### 💡 Caso de Uso de Aninhamento

Se a aba tiver o ID `'social_financeiro'` e o painel tiver o ID `'despesas_anuais'`, o controle final no formulário mestre será acessível por:

```typescript
form.get('social_financeiro').get('despesas_anuais');
```

---

## 3. Gerenciamento de Status Visual

O componente é responsável por mostrar se um painel está **completo** ou **pendente**, garantindo feedback imediato ao usuário.

### Monitoramento:
Após criar o `FormGroup` do painel, ele assina o Observable `group.statusChanges`.

- Atualização do Mapa:  
  `this.panelStatus` é atualizado (`status === 'VALID'`).

### Exibição no Template:

- `getPanelSeverity(panelId)` → retorna `'success'` ou `'warning'` para o componente `<p-tag>`.
- `getPanelStatusText(panelId)` → retorna `'Completo'` ou `'Pendente'`.

Este monitoramento é vital, pois o FormGroup da aba pai (no `DynamicTabviewComponent`) só será considerado válido quando todos os FormGroups de seus painéis filhos estiverem válidos.

---

## 4. Renderização de Campos Filhos

O template utiliza um loop:
```html
*ngFor="let field of panel.fields"
```

Cada campo é renderizado dentro de um `div` com classes de coluna (ex: `md:col-6`) para layout responsivo, exceto para campos de largura total como `'divider'` ou `'section'`.

Cada campo é renderizado pelo componente `app-dynamic-field`, passando:

```html
[field]="field"
[formGroup]="formGroupsMap[panel.id]"
```

### Repasse de Evento

Quando o `app-dynamic-field` emite `fieldChanged`, o `DynamicAccordionComponent` apenas o repassa para o pai:

```typescript
fieldChanged.emit(event);
```

Permitindo que o Handler da aba execute a lógica de negócio.

---

## 🧩 Conclusão

O **DynamicAccordionComponent** é o ponto onde a **estrutura lógica dos acordeões** é traduzida para a **estrutura hierárquica dos FormGroups do Angular**, garantindo:

- Sincronização perfeita entre dados e estrutura de UI.  
- Validação reativa em todos os níveis.  
- Comunicação fluida entre componentes pais e filhos.






# 🧱 Detalhamento: DynamicFieldComponent

O **DynamicFieldComponent** é responsável por receber a definição de um único campo (via `TabField`) e **renderizar o controle de formulário Angular/PrimeNG apropriado**, garantindo o *binding* correto e aplicando lógicas específicas de **validação e sanitização**.

---

## 1. 🎯 Responsabilidades e Props (Inputs/Outputs)

Este componente atua como um *switch* de renderização, acionando o `FormGroup` pai em qualquer alteração.

| Propriedade | Tipo | Responsabilidade |
|-------------|------|------------------|
| `@Input() field` | `TabField` | Recebe toda a configuração do campo (tipo, rótulo, máscara, valor inicial, etc.). |
| `@Input() formGroup` | `FormGroup` | Recebe o `FormGroup` do Acordeão/Painel ao qual este campo pertence. |
| `@Output() fieldChanged` | `EventEmitter` | Emite um evento com o **ID e o novo valor** sempre que o controle é alterado, permitindo que o *Handler* da aba reaja. |

---

## 2. ⚙️ Fluxo de Inicialização (`ngOnInit`)

O componente **não cria o FormControl** (isso é feito pelo `DynamicAccordionComponent`), mas estabelece a comunicação imediata com o seu controlador.

**Etapas:**

1. **Obter Controle:**  
   Identifica e obtém o `FormControl` usando o nome sanitizado:  
   ```typescript
   getSafeControlName(this.field.id)
   ```

2. **Assinar Mudanças:**  
   Assina o `valueChanges` do controle.

3. **Emissão Imediata:**  
   A cada mudança de valor, emite o evento `fieldChanged` para o pai (`DynamicWrapperComponent`), garantindo que qualquer lógica de dependência ou cálculo possa ser executada em tempo real.

---

## 3. 🧩 Lógica de Renderização (`dynamic-field.component.html`)

O template utiliza:

```html
[ngSwitch]="field.type"
```
para decidir qual elemento de formulário nativo ou componente PrimeNG deve ser renderizado.

| `field.type` | Componente Renderizado | Observação |
|---------------|-------------------------|-------------|
| `'input'` | `<input pInputText>` | Implementa *template outlets* para prefixos/unidades (`field.siglaUnidade`). |
| `'textArea'` | `<textarea pInputTextarea>` | Campo de texto multilinha. |
| `'checkbox'` | `<p-checkbox>` | Checkbox binário. |
| `'radio'` | `<p-radioButton>` | Itera sobre `field.value.options` para renderizar as opções. |
| `'multCheckbox'` | `<p-multiSelect>` | Permite seleção de múltiplos valores. |
| `'select'` | `<p-dropdown>` | Lista dropdown de seleção única. |
| `'selectButton'` | `<p-selectButton>` | Botões de seleção visual (usa `field.value.options`). |
| `'tag'` | `<p-chips>` | Inserção de tags (valores como array de strings). |
| `'accordion'` | `<app-dynamic-accordion>` | Componente recursivo que renderiza um acordeão aninhado usando `getNestedFormGroup`. |
| `'divider'` | `<p-divider>` | Elemento de layout sem interação. |
| `'section'` | `<div>` | Agrupamento visual sem interação. |

**Nota:** Todos os controles usam  
```html
[formControlName]="getSafeControlName(field.id)"
```
para se ligarem ao `FormGroup` fornecido.

---

## 4. 🧼 Sanitização e Validação Específicas

O componente implementa métodos para tratar **comportamentos especiais**, principalmente para entradas numéricas.

### 🪄 A) Máscara e Unidade (`input`)

- **Máscara:**  
  Usa uma diretiva externa (`[appMask]`) para aplicar formatação (`'currency'`, `'meters'`, etc.) se `field.hasMask` for `true`.
- **Unidade:**  
  Se `field.siglaUnidade` estiver presente (ex: `'R$'`), a unidade é exibida como prefixo visual.

---

### 🔢 B) Validação de Números (`inputType: 'number'`)

A lógica de `onKeyDown` e `apenasNumeros` garante integridade dos campos numéricos.

| Método | Evento | Ação |
|---------|---------|------|
| `onKeyDown($event, 'number')` | `(keydown)` | Bloqueia caracteres como `'e'`, `'E'`, `'+'`, `'-'`, garantindo valores numéricos válidos. |
| `apenasNumeros($event, 'number')` | `(input)` | Sanitiza valores negativos. Se o usuário inserir `'-'`, o valor é resetado para `'0'`. |

---

## 🧠 Resumo

O **DynamicFieldComponent** é a ponte entre a **definição estrutural (`TabField`)** e a **interação do usuário**, garantindo que:

- As regras de exibição e formatação sejam aplicadas corretamente;  
- O comportamento reativo do formulário Angular seja preservado;  
- A lógica de sanitização e validação seja consistente em todos os campos.

---



# 📊 Detalhamento: ProgressStepComponent

## 1. Responsabilidade
A única responsabilidade deste componente é **calcular e exibir a porcentagem de conclusão** de uma seção ou aba com base em dois números fornecidos pelos seus componentes pais.

---

## 2. Propriedades (Inputs)

O componente depende de dois inputs para operar:

| Propriedade | Tipo | Valor Fornecido Por... | Propósito |
|--------------|------|------------------------|------------|
| `@Input() totalAccordion` | `number` | `DynamicTabviewComponent` (ou `DynamicWrapperComponent`) | Representa o número máximo de painéis de acordeão ou segmentos na aba atual. Este é o denominador do cálculo. |
| `@Input() totalAccordionValid` | `number` | `DynamicTabviewComponent` | Representa o número de painéis de acordeão ou segmentos que estão válidos/completos. Este é o numerador do cálculo. |

---

## 3. Lógica de Cálculo (Getter)

A lógica central do componente reside no getter `progressValue`, que calcula a porcentagem de conclusão.

```typescript
get progressValue(): number {
  return (this.totalAccordionValid / this.totalAccordion) * 100;
}
```

**Fluxo:**  
O `DynamicTabviewComponent` calcula o total de acordeões válidos (usando `getValidAccordionCountForActiveTab()`) e divide esse número pelo total de acordeões disponíveis (`tab.content.data.length`).

**Resultado:**  
O valor retornado (entre `0` e `100`) é ligado ao `[value]` do `<p-progressBar>`.

---

## 4. Template (`progress-step.component.html`)

O template tem uma estrutura simples de flexbox para alinhar a barra de progresso com o texto de contagem.

### **Barra de Progresso**
```html
<p-progressBar [value]="progressValue"></p-progressBar>
```
O PrimeNG renderiza a barra visualmente preenchida de acordo com o `progressValue`.

### **Texto de Contagem**
```html
<b>{{totalAccordionValid}}/{{totalAccordion}} seções</b>
```
Exibe a contagem absoluta de progresso, informando ao usuário quantos painéis estão completos versus o total.

---

## 5. Casos de Uso (Consumo)

O `ProgressStepComponent` é usado no `DynamicTabviewComponent` e seu uso é adaptado com base no tipo de aba:

| Aba | `totalAccordion` é... | `totalAccordionValid` é... |
|------|------------------------|-----------------------------|
| **Aba Padrão** (`dados_sociais`, etc.) | `tab.content.data.length` (Contagem total de painéis definidos). | `getValidAccordionCountForActiveTab()` (Contagem de painéis válidos). |
| **Aba Portfólio** | `totalSegmentosPortfolio` (Total de segmentos selecionados na aba). | `segmentosCompletosPortfolio` (Total de segmentos preenchidos com produto/serviço). |

---

## 🧩 Conclusão

Em resumo, o `ProgressStepComponent` é um **componente puramente de UI/Apresentação** que:
- Recebe números dos componentes pais;
- Calcula um percentual básico;
- Renderiza o status de conclusão da seção ativa com clareza visual.
