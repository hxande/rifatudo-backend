import { flattenFields, TabDataInterface, TabField, TabInterface } from '../../types/tabs.interface';
export class AnuarioValidacao {
  private static extrairPaineis(tabsOuPaineis: TabInterface[] | TabDataInterface[] | undefined | null): TabDataInterface[] {
    if (!Array.isArray(tabsOuPaineis) || tabsOuPaineis.length === 0) {
      return [];
    }

    const primeiro = tabsOuPaineis[0] as Partial<TabInterface>;
    if (primeiro && 'content' in primeiro) {
      return (tabsOuPaineis as TabInterface[]).reduce<TabDataInterface[]>((acc, tab) => {
        if (tab?.content?.data?.length) {
          acc.push(...tab.content.data);
        }
        return acc;
      }, []);
    }

    return tabsOuPaineis as TabDataInterface[];
  }

  static validarIdRequerido(fields: TabField[]): string[] {
    return fields.filter((field) => !field.id || field.id.trim() === '').map((field) => `Campo sem id definido: label [${field.label}]`);
  }

  static validarIcon(fields: TabField[]): string[] {
    return fields
      .filter((field) => field.hasIcon && (!field.icon || field.icon.trim() === ''))
      .map((field) => `Campo [${field.label}] com hasIcon=true, mas icone não foi definido.`);
  }

  static validarAccordion(fields: TabField[]): string[] {
    return fields
      .filter((field) => field.isAccordion && (!field.accordions || field.accordions.length === 0))
      .map((field) => `Campo [${field.label}] é um accordion mas não tem accordions definidos.`);
  }

  static validarMascara(fields: TabField[]): string[] {
    return fields
      .filter((field) => field.hasMask && (!field.mask || field.mask.trim() === ''))
      .map((field) => `Campo [${field.label}] com hasMask=true, mas mascara não foi definido.`);
  }

  static validarCamposObrigatorios(fields: TabField[]): string[] {
    return fields
      .filter((field) => field.required)
      .filter((field) => {
        const value = field.value;
        if (value === null || value === undefined) {
          return true;
        }
        if (typeof value === 'string' && value.trim() === '') {
          return true;
        }
        if (Array.isArray(value) && value.length === 0) {
          return true;
        }
        if (typeof value === 'object' && value.selected !== undefined) {
          const selectedValue = value.selected;
          if (selectedValue === null || selectedValue === undefined || selectedValue === '') {
            return true;
          }
        }
        return false;
      })
      .map((field) => `Campo obrigatório [${field.label}] com id [${field.id}] não preenchido.`);
  }

  static validarTipoMascara(fields: TabField[]): string[] {
    const validMasks = ['currency', 'currencyNegative', 'meters', 'kilograms', 'arroba'];
    return fields
      .filter((field) => field.hasMask && field.mask && !validMasks.includes(field.mask))
      .map((field) => `Campo [${field.label}] com id [${field.id}] tem máscara inválida: [${field.mask}]`);
  }

  static validarInputType(fields: TabField[]): string[] {
    const validTypes = ['text', 'number', 'data'];
    return fields
      .filter((field) => field.type === 'input' && field.inputType && !validTypes.includes(field.inputType))
      .map((field) => `Campo de entrada [${field.label}] com id [${field.id}] tem inputType inválido: [${field.inputType}]`);
  }

  static validarDuplicidadeIdsFields(fieldsInput: TabField[] | TabField[][], ids = new Set<string>(), duplicates: string[] = []): string[] {
    const fields = flattenFields(fieldsInput);
    fields.forEach((field) => {
      if (field.id) {
        if (ids.has(field.id)) {
          duplicates.push(`Id duplicado encontrado: [${field.id}] no campo [${field.label}]`);
        } else {
          ids.add(field.id);
        }
      }
      if (field.accordions && field.accordions.length) {
        field.accordions.forEach((acc) => {
          this.validarDuplicidadeIdsFields(acc.fields || [], ids, duplicates);
        });
      }
    });

    return duplicates;
  }

  static validarDuplicidadeIdsTabs(tabsOuPaineis: TabInterface[] | TabDataInterface[] | undefined | null): string[] {
    const duplicates: string[] = [];
    const paineis = this.extrairPaineis(tabsOuPaineis);

    paineis.forEach((painel) => {
      const linhas: TabField[][] = Array.isArray(painel.fields?.[0]) ? (painel.fields as TabField[][]) : painel.fields?.length ? [painel.fields as TabField[]] : [];
      linhas.forEach((linha) => {
        const ids = new Set<string>();
        this.validarDuplicidadeIdsFields(linha, ids, duplicates);
      });
    });

    return duplicates;
  }

  static validarFieldsRecursivamente(fieldsInput: TabField[] | TabField[][]): string[] {
    const fields = flattenFields(fieldsInput);
    let messages: string[] = [];

    messages.push(...this.validarIdRequerido(fields));
    messages.push(...this.validarIcon(fields));
    messages.push(...this.validarAccordion(fields));
    messages.push(...this.validarMascara(fields));
    messages.push(...this.validarTipoMascara(fields));
    messages.push(...this.validarInputType(fields));

    fields
      .filter((field) => field.accordions && field.accordions.length)
      .forEach((field) => {
        field.accordions?.forEach((accordionData) => {
          messages.push(...this.validarFieldsRecursivamente(accordionData.fields || []));
        });
      });

    return messages;
  }
static converterParaToLowerCase(paineis: TabDataInterface[]): TabDataInterface[] {
  return paineis.map(panel => ({
    ...panel,
    id: panel.id.toLowerCase(),
    fields: panel.fields
      ? flattenFields(panel.fields).map(field => ({
          ...field,
          id: field.id.toLowerCase()
        }))
      : panel.fields
  }));
}


  static iniciarValidacao(tabsOuPaineis: TabInterface[] | TabDataInterface[] | undefined | null): string[] {
    let resultados: string[] = [];
    const paineis = this.extrairPaineis(tabsOuPaineis);
    const idsDuplicados = this.validarDuplicidadeIdsTabs(paineis);

    if (idsDuplicados.length > 0) {
      return idsDuplicados;
    }

    paineis.forEach((painel) => {
      resultados.push(...this.validarFieldsRecursivamente(painel.fields || []));
    });

    return resultados;
  }
}
