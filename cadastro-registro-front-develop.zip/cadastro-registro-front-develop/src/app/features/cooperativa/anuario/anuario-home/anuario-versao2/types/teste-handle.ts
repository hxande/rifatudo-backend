import { FormGroup } from '@angular/forms';
import { TabBase } from './tab-base.abstract';
import { StatusAccordion, TabDataInterface, TabInterface } from './tabs.interface';

export class TesteHandler extends TabBase {
  salvarFormulario(tab: TabInterface, controlName: string, activeFormGroup: FormGroup) {
    throw new Error('Method not implemented.');
  }
  dadosTests: TabDataInterface[] = [];

  constructor(dados: TabDataInterface[]) {
    super();
    this.dadosTests = dados;

  }

 montarDadosComponentes(): TabDataInterface[] {

    return [
      {
        id: 'primeiroid',
        hasIcon: true,
        name:"",
        icon: 'pi pi-apple',
        hasInfo: true,
        infoText: 'Eu sou uma informacao',
        subTitle: 'Eu soy uno subtitle',
        title: 'I am title',
        fields: [
          {
            id: 'meuprimeirofield',
            type: 'input',
            value: 1,
            disable: false,
            inputType: 'number',
            placeHolder: 'place',
            required: true,
            visible: true,
          },
          {
            id: 'meusegundoofield',
            type: 'checkbox',
            label: 'meu check',
            value: null,
            inputType: 'number',
            placeHolder: 'place',
            required: true,
            visible: true,
          },
          {
            id: 'meusterceirofield',
            type: 'divider',
            value: '',
            visible: true,
          },
          {
            id: 'meusquartofield',
            type: 'multCheckbox',
             required: true,
            value: {
              options: [
                { label: 'Tecnologia', value: 'tech' },
                { label: 'Esportes', value: 'sports' },
                { label: 'Música', value: 'music' },
              ],
              selected: [],
            },
            visible: true,
          },
          {
            id: 'meusterceirofield6',
            type: 'radio',
             required: true,
            value: {
              options: [
                { label: 'Masculino', value: 'M' },
                { label: 'Feminino', value: 'F' },
                { label: 'Outro', value: 'O' },
              ],
              selected: [],
            },
            visible: true,
          },
          {
            id: 'meusterceirofield3',
            type: 'select',
             required: true,
            value: {
              options: [
                { label: 'Brasil', value: 'br' },
                { label: 'Argentina', value: 'ar' },
                { label: 'Estados Unidos', value: 'us' },
              ],
              selected: [],
            },
            visible: true,
          },
          {
            id: 'meusterceirofield2',
            type: 'selectButton',
             required: true,
              value: {
                options: [
                  {
                    label: 'Masculino',
                    value: 'M',
                  },
                  {
                    label: 'Feminino',
                    value: 'F',
                  },
                ],
               selected: [],
              },
            visible: true,
          },
             {
            id: 'meusterceirofield3',
            type: 'textArea',

            placeHolder: '',
             required: true,
            value: '',
            visible: true,
          },
        ],
      },
    ];
  }
  onFieldChange(fieldId: string, value: string | number | string[] | null, formGroup: FormGroup, tab: TabInterface): void {

  }
}
