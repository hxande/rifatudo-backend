import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnuarioHomeComponent } from './anuario-home.component';

describe('AnuarioHomeComponent', () => {
  let component: AnuarioHomeComponent;
  let fixture: ComponentFixture<AnuarioHomeComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AnuarioHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnuarioHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
