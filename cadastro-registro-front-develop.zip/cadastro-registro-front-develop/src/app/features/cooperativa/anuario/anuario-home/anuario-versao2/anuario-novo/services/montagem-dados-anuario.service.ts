import { Injectable } from '@angular/core';
import { TabDataInterface, TabField } from '../../types/tabs.interface';
import { QuadroSocialAnuarioTO } from 'src/app/api/models/QuadroSocialAnuarioTO';
import { QuadroSocialCooperadosDadosAdicionaisTO } from 'src/app/api/models/QuadroSocialCooperadosDadosAdicionaisTO';
import { QuadroSocialEmpregadosDadosAdicionaisTO } from 'src/app/api/models/QuadroSocialEmpregadosDadosAdicionaisTO';

@Injectable({
  providedIn: 'root',
})
export class MontagemDadosAnuarioService {
  private _dadosQuadrosSocialAnuario: QuadroSocialAnuarioTO;

  get dadosQuadrosSocialAnuario(): QuadroSocialAnuarioTO {
    return this._dadosQuadrosSocialAnuario;
  }

  montarDadosSocias(dado: QuadroSocialAnuarioTO): TabDataInterface[] {
    this._dadosQuadrosSocialAnuario = dado;
     return [
      this.criarAccordion(
        'quantidadeCooperados',
        'Quantidade de Cooperados',
        'aqui tem um subtitle caso queira',
        true,
        'pi pi-info-circle',
        true,
        'Esse é um informativo que pode ser mostrado.',
        () => this.qdteCooperados(dado)
      ),
      this.criarAccordion(
        'cooperadosAdicionais',
        'Cooperados - Dados Adicionais',
        'aqui tem um subtitle caso queira',
        true,
        'pi pi-info-circle',
        true,
        'Esse é um informativo que pode ser mostrado.',
        () => this.cooperadosDadosAdicionais(dado.listaCooperadosDadosAdicionais)
      ),
      this.criarAccordion(
        'quantidadeEmpregados',
        'Quantidade de Empregados',
        'aqui tem um subtitle caso queira',
        true,
        'pi pi-info-circle',
        true,
        'Esse é um informativo que pode ser mostrado.',
        () => this.qdteEmpregados(dado)
      ),
      this.criarAccordion(
        'empregadosAdicionais',
        'Empregados - Dados Adicionais',
        'aqui tem um subtitle caso queira',
        true,
        'pi pi-info-circle',
        true,
        'Esse é um informativo que pode ser mostrado.',
        () => this.empregadosDadosAdicionais(dado.listaEmpregadosDadosAdicionais)
      ),
    ] as TabDataInterface[];
  }

  private criarAccordion(
    id: string,
    titulo: string,
    subTitulo: string,
    hasIcon: boolean,
    icon: string,
    hasInfo: boolean,
    infoText: string,
    fnPreencherCampos: () => TabField[]
  ): TabDataInterface {
    return {
      id: id,
      title: titulo,
      subTitle: subTitulo,
      hasIcon: hasIcon,
      icon: icon,
      hasInfo: hasInfo,
      infoText: infoText,
      fields: fnPreencherCampos(),
    };
  }

  private cooperadosDadosAdicionais(cooperadosAdicionais: QuadroSocialCooperadosDadosAdicionaisTO[]): TabField[] {
    const dados = cooperadosAdicionais.map((cooperado) => {
      const id = 'cooperado' + this.formatarNomeParametro(cooperado.nomeParametroQuadroSocialCooperado);
      return this.montarInputNumber(id, cooperado.nomeParametroQuadroSocialCooperado, false, cooperado.quantidade, true);
    });

    return dados;
  }

  private empregadosDadosAdicionais(empregadoAdicionais: QuadroSocialEmpregadosDadosAdicionaisTO[]): TabField[] {
    const dados = empregadoAdicionais.map((empregado) => {
      const id = 'empregado' + this.formatarNomeParametro(empregado.nomeParametroQuadroSocial);
      return this.montarInputNumber(id, empregado.nomeParametroQuadroSocial, false, empregado.quantidade, true);
    });

    return dados;
  }

  private formatarNomeParametro(nome: string): string {
    const removerAcentos = (str: string) => str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const textoLimpo = removerAcentos(nome)
      .replace(/[\s/]+/g, ' ')
      .trim()
      .split(' ')
      .map((palavra) => palavra.charAt(0).toUpperCase() + palavra.slice(1).toLowerCase())
      .join('');

    return textoLimpo;
  }

  private montarInputNumber(id: string, label: string, required: boolean, value: number, visible: boolean, disabled = false): TabField {
    return {
      id: id,
      type: 'input',
      label: label,
      required: required,
      inputType: 'number',
      value: value,
      visible: visible,
      placeHolder: '',
      disable: disabled,
    };
  }

  qdteCooperados(dado: QuadroSocialAnuarioTO) {
    const itens = [
      this.montarInputNumber('qtdeHomensCooperados', 'Homens', true, dado.cooperadosHomens, true),
      this.montarInputNumber('qtdeMulheresCooperados', 'Mulheres', true, dado.cooperadosMulheres, true),
      this.montarInputNumber('pessoasFisicas', 'Pessoas físicas', false, dado.cooperadosPF, true, true),
      this.montarInputNumber('pessoasJuridica', 'Pessoas jurídicas', true, dado.cooperadosPJ, true),
      this.montarInputNumber('total', 'Total', false, dado.cooperadosTotal, true, true),
      {
        id: 'Ativos',
        type: 'input',
        label: 'Ativos',
        required: false,
        inputType: 'number',
        hasInfo: true,
        infoText: 'Participantes das atividades da cooperativa.',
        value: dado.cooperadosAtivos,
        visible: true,
        disable: false,
        placeHolder: '',
      },
    ] as TabField[];

    if (dado.listaQuadroSocialUFTO.length > 0)
      itens.unshift({
        id: 'preencherDadosDetalhadosCooperados',
        type: 'checkbox',
        label: 'Preencher dados detalhado',
        required: false,
        hasInfo: true,
        infoText: 'Preencher dados detalhados por UF?',
        value: null,
        visible: true,
        disable: false,
      });

    return itens;
  }

  montarFieldsDadosDetalhados(){

 const dados = this.dadosQuadrosSocialAnuario.listaQuadroSocialUFTO[0];

   const itens = [
      {
      id: 'ufCooperativo',
      type: 'input',
      label: 'UF',
      required: false,
      inputType: 'text',
      value: dados.uf,
      visible: true,
      placeHolder: '',
      disable: true,
    },
     this.montarInputNumber('cooperadosHomensUF', 'Homens', true, dados.cooperadosHomensUF, true),
      this.montarInputNumber('cooperadosMulheresUF', 'Mulheres', true, dados.cooperadosMulheresUF, true),
      this.montarInputNumber('cooperadosPFUF', 'Pessoas físicas', false, dados.cooperadosPFUF, true, true),
      this.montarInputNumber('cooperadosPJUF', 'Pessoas jurídicas', true, dados.cooperadosPJUF, true),
      this.montarInputNumber('totalUF', 'Total', false, dados.cooperadosTotalUF, true, true),
            {
        id: 'Ativos',
        type: 'input',
        label: 'Ativos',
        required: false,
        inputType: 'number',
        hasInfo: true,
        infoText: 'Participantes das atividades da cooperativa.',
        value: dados.cooperadosAtivosUF,
        visible: true,
        disable: false,
        placeHolder: '',
      },

    ] as TabField[];



return itens;

  }

  private qdteEmpregados(dado: QuadroSocialAnuarioTO) {
    return [
      this.montarInputNumber('qtdeHomensEmpregados', 'Homens', true, dado.empregadosHomens, true),
      this.montarInputNumber('qtdeMulheresEmpregados', 'Mulheres', true, dado.empregadosMulheres, true),
      this.montarInputNumber('total', 'Total', false, dado.empregadosTotal, true, true),
    ] as TabField[];
  }
}
