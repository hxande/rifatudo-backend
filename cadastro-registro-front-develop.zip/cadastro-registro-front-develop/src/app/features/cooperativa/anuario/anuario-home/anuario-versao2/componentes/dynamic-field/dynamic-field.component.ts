import { AfterViewChecked, AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, EventEmitter, Input, OnInit, Output, QueryList, ViewChildren, inject } from '@angular/core';
import { FieldChangedEvent, TabField, ValueTabField } from '../../types/tabs.interface';
import { FormGroup } from '@angular/forms';
import { SelectButtonChangeEvent } from 'primeng/selectbutton';

@Component({
  selector: 'app-dynamic-field',
  templateUrl: './dynamic-field.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./dynamic-field.component.css'],
})
export class DynamicFieldComponent implements OnInit, AfterViewChecked {
  // --- PROPRIEDADES E INPUTS/OUTPUTS ---

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() field!: TabField;
  @Input() formGroup!: FormGroup;

  @Output() fieldChanged = new EventEmitter<FieldChangedEvent>();
  @ViewChildren('inputField') inputRefs!: QueryList<ElementRef<HTMLInputElement>>;


  constructor() { }
  ngAfterViewChecked(): void {
    this.atualizarTodosPaddings()
  }

  ngOnInit(): void {
    const controlName = this.field.id;
    const control = this.formGroup.get(controlName);
    if (control) {
      control.valueChanges.subscribe((newValue) => {
        this.fieldChanged.emit({
          fieldId: this.field.id,
          value: newValue,
          formGroup: this.formGroup,
        });
        this.changeDetectorRef.markForCheck();
      });
    }
    this.formGroup.valueChanges.subscribe(() => {
      setTimeout(() => {
        this.atualizarTodosPaddings();
        this.changeDetectorRef.markForCheck();
      }, 0);
      this.changeDetectorRef.markForCheck();
    });
  }

  private atualizarTodosPaddings() {
    this.inputRefs?.forEach((inputRef) => {
      const input = inputRef.nativeElement;
      const spanWrapper = input.closest('.dynamic-padding');
      if (!spanWrapper) return;

      const iconElement = spanWrapper.querySelector('i.ruby');
      if (!iconElement?.textContent?.trim()) return;

      const iconWidth = iconElement.getBoundingClientRect().width;
      const padding = Math.ceil(iconWidth + 15);
      input.style.paddingLeft = `${padding}px`;
    });
  }

  getFieldOptions(field: TabField): { label: string; value: string | number }[] {
    return (field.value as ValueTabField)?.options || [];
  }

  getNestedFormGroup(label: string): FormGroup {
    const control = this.formGroup.get(label);
    return control as FormGroup;
  }

  // --- VALIDAÇÃO DE INPUT NUMÉRICO ---

  /**
   * Unifica a lógica de prevenção de teclas inválidas e sanitiza a entrada.
   * Usada no (keydown) e (input) para campos 'number'.
   */
  onKeyDown(event: KeyboardEvent, inputType: string): void {
    if (inputType !== 'number') return;

    const input = event.target as HTMLInputElement;

    // permite teclas de navegação
    if (['Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
      return;
    }

    // bloqueia se não for número
    if (!/^\d$/.test(event.key)) {
      event.preventDefault();
      return;
    }

    // limita para 10 dígitos
    if (input.value.length >= 10) {
      event.preventDefault();
    }
  }

  /**
   * Garante que o valor do input não seja negativo, resetando para '0' se começar com '-'.
   * Esta função deve ser chamada no (input) para garantir a sanitização após o keydown.
   */
  apenasNumeros(event: Event, inputType: string): void {
    if (inputType !== 'number') return;

    const input = event.target as HTMLInputElement;

    const controlName = input.getAttribute('formControlName');
    const control = controlName ? this.formGroup.get(controlName) : null;

    // Atualiza o valor do form control sem disparar outro evento (emitEvent: false)
    if (control) {
      control.setValue(input.value, { emitEvent: false });
    }
  }

  changeFieldSelect(event: SelectButtonChangeEvent, label: string) {
    const control = this.formGroup.get(label);
    control.setValue(event.value);
  }

  atualizarPaddingInput(event: Event) {
    const target = event.target as HTMLElement;
    const spanWrapper = target.closest('.dynamic-padding');
    if (!spanWrapper) return;

    const iconElement = spanWrapper.querySelector('i.ruby');
    if (!iconElement?.textContent?.trim()) return;

    const iconWidth = iconElement.getBoundingClientRect().width;
    const padding = Math.ceil(iconWidth + 15);

    target.style.paddingLeft = `${padding}px`;
  }

}
