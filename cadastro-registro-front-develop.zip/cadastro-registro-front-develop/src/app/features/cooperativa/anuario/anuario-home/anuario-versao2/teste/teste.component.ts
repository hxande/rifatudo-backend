import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { AnuarioDynamic } from '../types/anuario-dynamic';
import { FormBuilder } from '@angular/forms';
import { TipoAba } from '../types/tipo-aba';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-teste',
   template: `
    <app-dynamic-tabview
      *ngIf="form && tabs?.length"
      [tabs]="tabs"
      [formGroup]="form"
      (tabChange)="onTabChange($event)"
      (fieldChanged)="onFieldAlterado($event)"></app-dynamic-tabview>
    <button pButton type="button" label="Salvar" (click)="onSubmit()"></button>
  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./teste.component.css']
})
export class TesteComponent extends AnuarioDynamic implements OnInit {

  constructor(private fb: FormBuilder,  private apiManutencaoDadosGeraisService: ApiManutencaoDadosGeraisService, messageService: MessageService) {
    super(fb, messageService);
  }

  ngOnInit(): void {
    this.init()
  }


    init(): Promise<void> {
        this.criarAba('primeiraAbaID', 'Primeira Aba', true)
        this.criarAba('segundaAbaID', 'Segunda Aba', true)
        this.carregarDadosAbaAtiva(this.getIndiceTabAtiva());
      return ;
  }
  protected carregarDadosAbaAtiva(indexAbaAtiva: Number): Promise<void> {
       if(indexAbaAtiva === 0){
        const dados = [];
        this.criarFormularioAba(dados);
  }

    return;
  }


}
