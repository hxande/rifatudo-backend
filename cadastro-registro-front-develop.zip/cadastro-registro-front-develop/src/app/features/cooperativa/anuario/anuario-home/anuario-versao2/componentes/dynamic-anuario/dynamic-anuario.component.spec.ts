import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicAnuarioComponent } from './dynamic-anuario.component';

describe('DynamicAnuarioComponent', () => {
  let component: DynamicAnuarioComponent;
  let fixture: ComponentFixture<DynamicAnuarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicAnuarioComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DynamicAnuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
