import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ajuda-intercooperacao',
  templateUrl: './ajuda-intercooperacao.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['../ajuda-dados-sociais/ajuda-dados-sociais.component.css']
})
export class AjudaIntercooperacaoComponent implements OnInit {

 
  constructor() { }

  ngOnInit() {
    
  }

}
