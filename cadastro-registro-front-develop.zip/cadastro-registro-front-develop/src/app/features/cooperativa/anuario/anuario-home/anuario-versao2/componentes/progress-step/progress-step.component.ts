import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress-step',
  templateUrl: './progress-step.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./progress-step.component.css'],
})
export class ProgressStepComponent implements OnInit {


  @Input() totalAccordion = 0 ;
  @Input() totalAccordionValid = 0;

  get progressValue(): number {
    const value =  (this.totalAccordionValid  / this.totalAccordion) * 100;
    return Number(value.toFixed(1));
  }

  constructor() {}

  ngOnInit(): void {}
}
