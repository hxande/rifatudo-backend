import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ajuda-negocio',
  templateUrl: './ajuda-negocio.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['../ajuda-dados-sociais/ajuda-dados-sociais.component.css']
})
export class AjudaNegocioComponent implements OnInit {

 
  constructor() { }

  ngOnInit() {
    
  }

}
