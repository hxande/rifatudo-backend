// core/abstract/tab-base.ts
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ITabHandler } from './tabs-handle.interface';
import { TabDataInterface, TabField, TabInterface, ValueTabField } from './tabs.interface';
type ValuesMap = Record<string, Array<Record<string, unknown>>>;
type Field = {
  id: string;
  value: string | number | ValueTabField | null;
  type?: string | null; // divider | accordion | section | input | ...
  inputType?: 'text' | 'number' | string | null;

  idParametro?: number | string | null;
  idParametroAuxiliar?: number | string | null;
  parametroIntegracao?: unknown;
};

type Panel = {
  name: string;
  idQuadro: number | null;
  fields: Field[][];
};

type OutputField = {
  id: string;
  value: string | number | null;
  idParametro?: number | string | null;
  idParametroAuxiliar?: number | string | null;
  parametroIntegracao?: unknown;
};

type OutputPanel = {
  name: string;
  idQuadro: number | null;
  fields: OutputField[][];
};

const SKIP_TYPES = new Set(['divider', 'accordion', 'section']);

export abstract class TabBase implements ITabHandler {
  abstract salvarFormulario(tab: TabInterface, controlName: string, activeFormGroup: FormGroup);
  abstract montarDadosComponentes();
  abstract onFieldChange(fieldId: string, value: string | number | string[] | null, formGroup: FormGroup, tab: TabInterface): void;

  protected setValueSafe(form: FormGroup, controlId: string, value: unknown) {
    const control = form.get(controlId);
    if (control) control.setValue(value);
  }

  protected sumFields(formGroup: FormGroup, f1: string, f2: string, target: string) {
    const v1 = Number(formGroup.get(f1)?.value) || 0;
    const v2 = Number(formGroup.get(f2)?.value) || 0;
    const result = v1 + v2;
    formGroup.get(target)?.setValue(result);
  }

  protected removeControl(formGroup: FormGroup, controlName: string) {
    formGroup.removeControl(controlName);
  }

  protected removeControls(formGroup: FormGroup, controlNames: string[]) {
    controlNames.forEach((name) => formGroup.removeControl(name));
  }

  protected clearAllControls(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((control) => formGroup.removeControl(control));
  }

  protected addControl(formGroup: FormGroup, controlName: string, control: FormControl) {
    formGroup.addControl(controlName, control);
  }

  protected addControls(formGroup: FormGroup, controls: { name: string; control: FormControl }[]) {
    controls.forEach(({ name, control }) => formGroup.addControl(name, control));
  }

  protected createControlsFromFields(fields: TabField[]): { name: string; control: FormControl }[] {
    return fields.map((field) => {
      const safeName = field.id;
      const validators = field.required ? [Validators.required] : [];
      let initialValue: unknown = field.value;

      if ((field.type === 'multCheckbox' || field.type === 'selectButton' || field.type === 'select' || field.type === 'radio') && (field.value as ValueTabField)?.selected) {
        initialValue = (field.value as ValueTabField).selected;
      }

      const control = new FormControl({ value: initialValue, disabled: field.disable }, validators);
      return { name: safeName, control };
    });
  }

  protected criarAccordion(
    id: string,
    titulo: string,
    subTitulo: string,
    hasIcon: boolean,
    icon: string,
    hasInfo: boolean,
    infoText: string,
    fnPreencherCampos: () => TabField[]
  ): TabDataInterface {
    return {
      id: id,
      title: titulo,
      subTitle: subTitulo,
      hasIcon: hasIcon,
      icon: icon,
      hasInfo: hasInfo,
      infoText: infoText,
      fields: fnPreencherCampos(),
    };
  }

   protected gerarPayload(data, formGroup){
    data =  this.applyValuesToPanels(data, formGroup)
    const payload = this.buildPayloadFromPanels(data);
    return  payload
  }

  protected applyValuesToPanels<T extends { id: string; fields: Field[][] }>(panels: T[], valuesMap: ValuesMap): T[] {
    const SELECT_TYPES = new Set(['multCheckbox', 'selectButton', 'select', 'radio']);
    return panels.map((panel) => {
      const rowsValues = valuesMap[panel.id];


      if (!Array.isArray(rowsValues)) return panel;

      const nextFields = (panel.fields ?? []).map((rowFields, rowIndex) => {
        const rowValueObj = rowsValues[rowIndex] ?? {};

        return (rowFields ?? []).map((field: Field) => {
          if (!field?.id) return field;


          if (!(field.id in rowValueObj)) return field;

          const incoming = rowValueObj[field.id];


          if (SELECT_TYPES.has(field.type) && field.value && typeof field.value === 'object') {
            return {
              ...field,
              value: {
                ...field.value,
                selected: incoming,
              },
            };
          }

          // padrão: só seta value
          return {
            ...field,
            value: incoming,
          };
        });
      });

      return {
        ...panel,
        fields: nextFields,
      };
    });
  }

  protected toNumberBR(value: string | number | null | undefined): number | null {
    if (value === null || value === undefined || value === '') return null;
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;

    const s = String(value).trim();
    if (!s) return null;

    // remove espaços e separadores de milhar, resolve decimal
    // exemplos: "1.234,56" -> "1234.56", "1,234.56" -> "1234.56"
    const normalized = s
      .replace(/\s/g, '')
      .replace(/\.(?=\d{3}(\D|$))/g, '') // remove pontos de milhar (BR)
      .replace(/,(?=\d{1,2}$)/, '.'); // troca vírgula decimal por ponto

    const n = Number(normalized.replace(/,/g, '')); // fallback p/ "1,234.56"
    return Number.isFinite(n) ? n : null;
  }

  protected castValueByInputType(field: Field): string | number | null {
    const v = field.value as string | number | null;

    if (field.inputType === 'number') {
      return this.toNumberBR(v);
    }

    if (field.inputType === 'text') {
      if (v === null || v === undefined) return '';
      return String(v);
    }


    return v ?? null;
  }

  protected buildPayloadFromPanels(panels: Panel[]): OutputPanel[] {
    return (panels ?? []).map((panel) => {
      const nextFields: OutputField[][] = (panel.fields ?? [])
        .map((row) =>
          (row ?? [])
            .filter((f) => !SKIP_TYPES.has(String(f.type ?? '').toLowerCase()))
            .map((f) => ({
              id: f.id,
              value: this.castValueByInputType(f),
              idParametro: f.idParametro ?? null,
              idParametroAuxiliar: f.idParametroAuxiliar ?? null,
              parametroIntegracao: f.parametroIntegracao ?? null,
            }))
        )

        .filter((row) => row.length > 0);

      return {
        name: panel.name,
        idQuadro: panel.idQuadro ?? null,
        fields: nextFields,
      };
    });
  }
}
