import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, AfterViewInit, inject } from '@angular/core';
import { ComplementoAnuario } from '@cadastro-registro-api/models/ComplementoAnuario';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ApiComplementoAnuarioService } from '@cadastro-registro-api/services/api-complemento-anuario.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { Messages } from 'primeng/messages';

@Component({
  selector: 'app-complemento-anuario-info',
  templateUrl: './complemento-anuario-info.component.html',
  styleUrls: ['./complemento-anuario-info.component.css']
})
export class ComplementoAnuarioInfoComponent implements OnInit, AfterViewInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() cooperativa: Cooperativa;
  @Input() complementoAnuarioTexto:string;
  @Input() complementoAnuarioURL:string;
  complementoAnuario: ComplementoAnuario;
  cooperativaUnidadeEstadualId: number;
  @Input() podeSubmeterAnuario: boolean;
  @Output() podeSubmeterAnuarioChange = new EventEmitter<boolean>();
  @Input() isTabComplementarValid!: boolean;

  constructor(private apiPessoaJuridicaService: ApiPessoaJuridicaService,
              private apiComplementoAnuarioService: ApiComplementoAnuarioService) { }

  ngOnInit() {
    this.apiComplementoAnuarioService.getByUf(this.cooperativa.pessoaJuridica.ufSigla).subscribe(response => {
      this.complementoAnuario = response.data;
      this.changeDetectorRef.markForCheck();
    });
    this.apiPessoaJuridicaService.buscaUnidadeResponsavel(this.cooperativa.pessoaJuridica.ufSigla).then(response => {
      this.cooperativaUnidadeEstadualId = response.data.id;
      this.changeDetectorRef.markForCheck();
    });
  }

  ngAfterViewInit() {
    const elementoMensagem = document.querySelector('.msg-info');
    if (elementoMensagem) {
      elementoMensagem.textContent = "Necessário preencher o formulário do link abaixo!";
    }
  }

  getLink(): string {
    if (this.cooperativa && this.cooperativa.pessoaJuridica.ramo) {
      if (this.complementoAnuario.complementoAnuarioRamoUrls) {
        const complementoAnuarioRamoUrl = this.complementoAnuario.complementoAnuarioRamoUrls
          .find(value => value.ramoId === this.cooperativa.pessoaJuridica.ramo.id);
        if (complementoAnuarioRamoUrl) {
          return complementoAnuarioRamoUrl.url;
        }
      }
    }
    return this.complementoAnuario.url;
  }

  cliqueQuestionario() {
    this.isTabComplementarValid = true;
    this.podeSubmeterAnuarioChange.emit(true);
  }
}
