import { MontagemDadosAnuarioService } from './../../anuario-novo/services/montagem-dados-anuario.service';
import { AfterContentChecked, ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TabDataInterface, TabInterface } from '../../types/tabs.interface';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { firstValueFrom, map, Subscription, switchMap } from 'rxjs';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ApiCooperativaAnuarioAbasService } from 'src/app/api/services/api-cooperativa-anuario-abas.service';
import { AnuarioQuadroSocialService } from 'src/app/api/services/api-anuario-quadro-social.service';;
import { TipoAba } from '../../types/tipo-aba';
import { AnuarioDynamic } from '../../types/anuario-dynamic';
import { AnuarioValidacao } from '../../anuario-novo/services/validacao-anuario.service';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-dynamic-wrapper',
  templateUrl: './dynamic-wrapper.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./dynamic-wrapper.component.css'],
})
export class DynamicWrapperComponent extends AnuarioDynamic implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativa: Cooperativa;
  ano = new Date().getFullYear() - 1;
  dadosDetalhado:boolean = false;
  allData: unknown;
  salvarAbaDialog = false;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private cooperativaService: ApiCooperativaService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiCooperativaAnuarioAbasService: ApiCooperativaAnuarioAbasService,
    public keycloakService: KeycloakService,
    private apiAnuarioQuadroSocialService: AnuarioQuadroSocialService,
    private montagemDadosAnuarioService: MontagemDadosAnuarioService,
    messageService: MessageService,
  ) {
    super(fb, messageService);
  }

  ngOnInit() {
    this.init();
  }

  async init() {
    await this.getDadosCooperativa();
    await this.carregarCooperativaAnuarioAbas();
    await this.carregarDadosAbaAtiva(this.getIndiceTabAtiva());

    this.changeDetectorRef.markForCheck();
  }

   async carregarDadosAbaAtiva(indexAbaAtiva: Number): Promise<void> {
    switch (this.activeIndex) {
      case TipoAba.DADOS_SOCIAIS.index:
          this.carregarQuadroSocial();
        break;
      case TipoAba.PORTFOLIO.index:
        break;
      case TipoAba.NEGOCIO.index:
        // this.carregarNegocio();
        break;
      default:
        break;
    }
    this.changeDetectorRef.markForCheck();
    return;
  }

  async getDadosCooperativa() {
    const resposta = this.route.params.pipe(
      switchMap((params) => {
        if (params['id']) {
          return this.cooperativaService.get(params['id']).then((response) => ({ data: response.data, idExists: true }));
        } else {
          return this.apiCadastroRegistroService
            .getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
            .then((cooperativa) => ({ data: cooperativa, idExists: false }));
        }
      }),
      map(({ data, idExists }) => data)
    );

    this.cooperativa = await firstValueFrom(resposta);

    this.changeDetectorRef.markForCheck();
  }

  async carregarCooperativaAnuarioAbas() {

    let tabsAtual = (await firstValueFrom(this.apiCooperativaAnuarioAbasService.obterCooperativaAnuarioAbasV2(this.cooperativa.id, this.ano))).data;

    this.tabs  = tabsAtual;

    this.changeDetectorRef.markForCheck();
  }

  async carregarQuadroSocial() {
    const dados: TabDataInterface[] = await firstValueFrom(this.apiAnuarioQuadroSocialService.obterQuadroSocialAnuarioV2(this.cooperativa.id, this.ano));
    await this.criarFormularioAba(dados);

    this.changeDetectorRef.markForCheck();
  }

    protected onSubmit() {


    switch (this.activeIndex) {
      case TipoAba.DADOS_SOCIAIS.index:
          // this.carregarQuadroSocial();
        break;
      case TipoAba.PORTFOLIO.index:
        // this.salvarPortifolio();
        break;
      case TipoAba.NEGOCIO.index:
        // this.carregarNegocio();
        break;
      default:
        break;
    }

    const tab = this.tabs[this.activeIndex];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;

    if (activeFormGroup) {
      // Exemplo de validação
      if (activeFormGroup.invalid) {
        this.messageService.add({ severity: 'warn', detail: 'Formulário da aba ativa é inválido!', life: 10000 });
      }
    }
  }

  salvarPortifolio(){
    const tab = this.tabs[this.activeIndex];

    tab.content.data

  }

   validadaCancelado(): boolean {
    // return this.cooperativa.situacaoCooperativa.id != this.situacaoEnum.CANCELADA && !this.naoPodePreencherAnuario();
    return true;
  }

  naoPodePreencherAnuario() {
    // return (
    //   (!this.keycloakService.isUsuarioNacional && !this.controleAnuario.habilitarPreenchimentoAnuario) ||
    //   (this.keycloakService.isUsuarioCooperativa && !this.controleAnuario.cooperativaPodePreencher)
    // );
  }

    salvarContinuar(): void {
    // this.salvar(this.indexAbaAtiva).subscribe(() => {
    //   this.carregarCooperativaAnuarioAbas();
    //   this.resetFormOrigem();
    //   this.nextTab();
    //   this.carregarAbaAtiva();
    // });
    this.onSubmit();
  }

    public podeExibirBotaoSubmeterAnuario(): boolean {
    // return !this.podeSubmeterAnuario;
    return true;
  }

  submeterAnuario(): void {
      // if (!this.todasAsAbasValidadas) {
      //   this.messageService.add({
      //     severity: 'warn',
      //     detail: 'Os campos de preenchimento obrigatório não foram parametrizados. Favor entrar em contato com a Unidade Nacional do Sistema OCB.',
      //     life: 3000,
      //   });
      //   return;
      // }

      // const headerMessage = 'Confirmação da submissão do anuário';
      // const message =
      //   'A veracidade dos dados aqui inseridos são de inteira responsabilidade de quem está preenchendo. O Sistema OCB assegura que nenhuma informação individual será divulgada no Anuário do Cooperativismo Brasileiro.';

      // const submitAction = () => {
      //   const apiCall = this.censoAnuario.id
      //     ? this.apiCensoAnuarioService.update(this.censoAnuario)
      //     : this.apiCensoAnuarioService.create({
      //       ...this.censoAnuario,
      //       ano: this.ano,
      //       cooperativaId: this.cooperativa.id,
      //     } as CensoAnuario);

      //   apiCall.subscribe((response) => {
      //     this.censoAnuario.id = response.data.id;
      //     this.carregarStatusAtualizacaoAnuario();
      //     if (response.data) {
      //       this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: this.cooperativa.id } });
      //     } else {
      //       this.router.navigate(['/registro/manutencaoCadastro']);
      //     }
      //   });npm
      // };

      // this.confirmationService.confirm({
      //   header: headerMessage,
      //   message: message,
      //   accept: submitAction,
      // });
      this.onSubmit()
    }

    cancelarSalvarAba(){
      this.salvarAbaDialog = false;
    }
    naoSalvarAba(){}
    salvarAba(){}



    // nota: o binding de template usa (tabChange), mas DynamicTabviewComponent.tabChange nunca é emitido;
    // este handler está efetivamente inalcançável em runtime (comportamento pré-existente)
    onTabChange(rawEvent: unknown) {
      const event = rawEvent as { index: number; stopPropagation: () => void };
      const nextIndex = event.index;

    const tab = this.tabs[event.index];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;


    if(!activeFormGroup.pristine){
      event.stopPropagation();
      this.salvarAbaDialog = true;

      return;

    }else{
      this.salvarAbaDialog = false;
      super.onTabChange(event.index);

    }


  }


}
