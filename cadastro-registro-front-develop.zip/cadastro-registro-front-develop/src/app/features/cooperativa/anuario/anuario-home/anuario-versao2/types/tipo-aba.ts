export const TipoAba = Object.freeze({
  DADOS_SOCIAIS: { index: 0, label: 'Dados sociais', key: 'DADOS_SOCIAIS', id: 'dadosSociais' },
  PORTFOLIO: { index: 1, label: 'Portfólio', key: 'PORTFOLIO', id: 'portifolio' },
  CONTABIL_TRIBUTARIO: { index: 2, label: 'Detalhamento contábil, tributário e fiscal', key: 'CONTABIL_TRIBUTARIO', id: 'detalhamentoFinanceiro' },
  NEGOCIO: { index: 3, label: 'Negócio', key: 'NEGOCIO', id: 'negocio' },
  DADOS_COMPLEMENTARES: { index: 4, label: 'Dados Complementares', key: 'DADOS_COMPLEMENTARES', id: 'dadosComplementares' },
});
