import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FieldChangedEvent, TabDataInterface, TabInterface } from '../../types/tabs.interface';
import { ITabHandler } from '../../types/tabs-handle.interface';


@Component({
  selector: 'app-dynamic-anuario',
  template: `
  <app-dynamic-tabview
  *ngIf="form && tabs?.length"
  [tabs]="tabs"
  [formGroup]="form"
  (tabChange)="onTabChange($event)"
  (fieldChanged)="onFieldAlterado($event)"
  ></app-dynamic-tabview>
<button pButton type="button" label="Salvar" (click)="onSubmit()"></button>

  `,
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./dynamic-anuario.component.css']
})
export class DynamicAnuarioComponent implements OnInit {

  form: FormGroup;
  formBuilder: FormBuilder;
  tabs: TabInterface[] = [];
  activeHandler: ITabHandler;
  activeIndex = 0;

  constructor(fb?: FormBuilder) {
    this.formBuilder = fb;
    this.form = this.formBuilder ? this.formBuilder.group({}) : new FormGroup({});

    const abaPadrao = this.criarAba('aba_padrao', 'Aba Padrão', false);

    abaPadrao.content.data = [
      {
        id: 'accordion_padrao',
        title: 'Accordion Padrão',
        fields: [
          {
            id: 'campo_padrao',
            label: 'Campo Padrão',
            value: '',
            type: 'input',
             placeHolder: '',
             required: true,
            visible: true,
          },
        ],
      },
    ];
    this.tabs = [...this.tabs, abaPadrao];
  }
  ngOnInit(): void {

  }

  criarFormularioTab(tipoFormulario: { index: number }, dados: TabDataInterface[]) {


  }

  protected atualizarAba(tipoFormulario: { index: number }, novoData: TabDataInterface[]): void {
    const index = tipoFormulario.index;
    const novaAba = this.criarNovaAbaComDados(index, novoData);
    this.substituirAba(index, novaAba);
  }

  protected criarNovaAbaComDados(index: number, novoData: TabDataInterface[]): TabInterface {
    const abaAtual = this.tabs[index];
    return {
      ...abaAtual,
      content: {
        ...abaAtual.content,
        data: novoData,
      },
    };
  }

  protected substituirAba(index: number, novaAba: TabInterface): void {
    this.tabs = [...this.tabs.slice(0, index), novaAba, ...this.tabs.slice(index + 1)];
  }

  onFieldAlterado(event: FieldChangedEvent) {
    const aba = this.tabs[this.activeIndex];
    const abaHandler = this.activeHandler;
    if (abaHandler?.onFieldChange) {
      abaHandler.onFieldChange(event.fieldId, event.value, event.formGroup, aba);
    }
  }



  protected inicializarFormulario(): void {
    if (!this.form) this.form = this.formBuilder.group({});
  }

  criarAba(id: string, nome: string, abaPreenchida = false): TabInterface {
    return {
      id,
      title: nome,
      tabPreenchida: abaPreenchida,
      content: { type: 'accordion', data: [] },
    } as TabInterface;
  }

  limparAbas(): void {
    this.tabs = [];
    this.activeHandler = null;
    this.form.reset();
  }

  // nota: o binding de template usa (tabChange), mas DynamicTabviewComponent.tabChange nunca é emitido;
  // este handler está efetivamente inalcançável em runtime (comportamento pré-existente)
  onTabChange(index: unknown) {
    this.activeIndex = index as number;
    this.carregarDadosAbaAtiva();
  }

   onSubmit() {

     const tab = this.tabs[this.activeIndex];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;

    if (activeFormGroup) {


      // Exemplo de validação
      if (activeFormGroup.invalid) {
        console.warn('Formulário da aba ativa é inválido!');
      }
    }
  }

  async carregarDadosAbaAtiva() {}
}
