import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { FieldChangedEvent, flattenFields, TabDataInterface, TabField, ValueTabField } from '../../types/tabs.interface';
import { FormArray, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
const PENDENCIA_FORM = 'pendencia-form'
@Component({
  selector: 'app-dynamic-accordion',
  templateUrl: './dynamic-accordion.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./dynamic-accordion.component.css'],
})
export class DynamicAccordionComponent implements OnInit, OnChanges, OnDestroy {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() accordionData: TabDataInterface[] = [];
  @Input() formGroup!: FormGroup;
  @Output() fieldChanged = new EventEmitter<FieldChangedEvent>();

  panelStatus: { [panelId: string]: boolean } = {};
  formArraysMap: { [panelId: string]: FormArray } = {};
  subscriptions: Subscription[] = [];

  constructor(private fb: FormBuilder) {}

  onFieldChanged(event: FieldChangedEvent) {
    this.fieldChanged.emit(event);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }

  ngOnInit() {
    this.sincronizarAccordionData();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['accordionData'] && !changes['accordionData'].firstChange) {
      this.sincronizarAccordionData();
    }
  }

  private sincronizarAccordionData() {
    this.accordionData.forEach((panel) => {
      const panelId = panel.id;

      if (!this.formGroup.get(panelId)) {
        const rowsGroups = (panel.fields as TabField[][]).map((row: TabField[]) => {
          const rowGroup = this.fb.group({});

          row.forEach((field: TabField) => {
            if (field.visible == false) return;
            if (field.type == 'divider' || field.type == 'section') return;
            const validators = field.required ? [Validators.required] : [];

            let initialValue: string | number | string[] | null = field.value as string | number | null;
            if (
              (field.type === 'multCheckbox' || field.type === 'selectButton' || field.type === 'select' || field.type === 'radio') &&
              (field.value as ValueTabField)?.selected != null
            ) {
              initialValue = (field.value as ValueTabField).selected as string | number;
            }

            if (field.type === 'selectButton' && !(field.value as ValueTabField)?.selected) {
              initialValue = null;
            }

            if (field.type === 'multCheckbox') {
              initialValue = String((field.value as ValueTabField).selected)
                .split(',')
                .map((item) => item.trim())
                .filter((item) => item !== '');
            }

            if (field.type === 'input' && field.inputType === 'number' && field.hasMask == false) {
              const parsed = parseInt(String(field.value), 10);
              field.value = isNaN(parsed) ? null : parsed;
              initialValue = isNaN(parsed) ? null : parsed;
            }
            // TabField não possui 'disabled' (apenas 'disable'); fallback mantido por compatibilidade com dados legados
            const isDisabled = !!((field as unknown as { disabled?: boolean }).disabled ?? field.disable);

            rowGroup.addControl(field.id, this.fb.control({ value: initialValue, disabled: isDisabled }, validators));
          });

          return rowGroup;
        });

        const panelArray = this.fb.array(rowsGroups);

        this.formGroup.addControl(panelId, panelArray);

        this.formArraysMap[panelId] = panelArray;
        this.panelStatus[panelId] = this.isPanelValid(panelId);

        const sub = panelArray.statusChanges.subscribe(() => {
          this.panelStatus[panelId] = this.isPanelValid(panelId);
          this.changeDetectorRef.markForCheck();
        });
        this.subscriptions = [...this.subscriptions, sub];
      } else {
        this.formArraysMap[panelId] = this.formGroup.get(panelId) as FormArray;
        this.panelStatus[panelId] = this.isPanelValid(panelId);
      }

      this.syncPanelArray(panel, panelId);
    });
  }

  private syncPanelArray(panel: TabDataInterface, panelId: string) {
    const arr = this.formGroup.get(panelId) as FormArray;
    if (!arr) return;

    const rows = panel.fields as TabField[][];

    while (arr.length < rows.length) arr.push(this.fb.group({}));
    while (arr.length > rows.length) arr.removeAt(arr.length - 1);

    rows.forEach((rowFields: TabField[], rowIndex: number) => {
      const rowGroup = arr.at(rowIndex) as FormGroup;

      rowFields.forEach((field: TabField) => {
        if (field.visible == false) return;
        if (field?.type == 'divider' || field?.type == 'section') return;
        const validators = field.required ? [Validators.required] : [];

        let nextValue: string | number | string[] | null = field.value as string | number | null;
        if (
          (field.type === 'multCheckbox' || field.type === 'selectButton' || field.type === 'select' || field.type === 'radio') &&
          (field.value as ValueTabField)?.selected != null
        ) {
          nextValue = (field.value as ValueTabField).selected as string | number;
        }
        if (field.type === 'multCheckbox') {
          nextValue = String((field.value as ValueTabField).selected)
            .split(',')
            .map((item) => item.trim())
            .filter((item) => item !== '');
        }

        if (field.type === 'selectButton' && !(field.value as ValueTabField)?.selected) {
          nextValue = null;
        }

        if (field.type === 'input' && field.inputType === 'number' && field.hasMask == false) {
          const parsed = parseInt(String(field.value), 10);
          nextValue = isNaN(parsed) ? null : parsed;
        }

        // TabField não possui 'disabled' (apenas 'disable'); fallback mantido por compatibilidade com dados legados
        const isDisabled = !!((field as unknown as { disabled?: boolean }).disabled ?? field.disable);

        if (!rowGroup.get(field.id)) {
          rowGroup.addControl(field.id, this.fb.control({ value: nextValue, disabled: isDisabled }, validators));
          return;
        }

        const ctrl = rowGroup.get(field.id)!;
        ctrl.setValidators(validators);

        ctrl.patchValue(nextValue, { emitEvent: false });

        if (isDisabled) ctrl.disable({ emitEvent: false });
        else ctrl.enable({ emitEvent: false });

        ctrl.updateValueAndValidity({ emitEvent: false });
      });

      rowGroup.updateValueAndValidity({ emitEvent: false });

      rowGroup.markAsPristine({ onlySelf: true });
      rowGroup.markAsUntouched({ onlySelf: true });
      Object.values(rowGroup.controls).forEach((c) => {
        c.markAsPristine({ onlySelf: true });
        c.markAsUntouched({ onlySelf: true });
      });
    });
  }

  getPanelArray(panelId: string): FormArray {
    return this.formGroup.get(panelId) as FormArray;
  }

  getRowGroup(panelId: string, rowIndex: number): FormGroup {
    return this.getPanelArray(panelId).at(rowIndex) as FormGroup;
  }

  // accordionData sempre chega como fields: TabField[][] nesta hierarquia (confirmado pelo template original)
  getRows(panel: TabDataInterface): TabField[][] {
    return panel.fields as TabField[][];
  }

  private getPendenciaValidation(panelId: string): boolean | null {
    const panel = this.accordionData.find((p) => p.id === panelId);
    if (!panel) return null;
    const pendencias = flattenFields(panel.fields)
      .filter((f) => f?.id === PENDENCIA_FORM);
    if (pendencias.length === 0) return null;

    const hasNull = pendencias.some((f) => f.value != null);
    return !hasNull;
  }

  private isPanelValidByForm(panelId: string): boolean {
    const arr = this.formArraysMap[panelId];

    if (!arr || arr.length === 0) return false;

    return arr.controls.every((row) => {
      const g = row as FormGroup;
      return Object.values(g.controls).every((c) => {
        const value = c.value;

        if (Array.isArray(value)) {
          return c.disabled || value.length > 0;
        }
        return c.disabled || (c.value != undefined && c.value != null && c.value !== '');
      });
    });
  }


  private isPanelValid(panelId: string): boolean {
    const pendenciaValid = this.getPendenciaValidation(panelId);
    if (pendenciaValid !== null) return pendenciaValid;

    return this.isPanelValidByForm(panelId);
  }

  getPanelSeverity(panelId: string): 'success' | 'warning' {
    return this.isPanelValid(panelId) ? 'success' : 'warning';
  }

  getPanelStatusText(panelId: string): string {
    return this.isPanelValid(panelId) ? 'Completo' : 'Pendente';
  }

  getAccordionFieldClasses(fieldType: string): { [key: string]: boolean } {
    const isFullWidth = fieldType === 'divider' || fieldType === 'section' || fieldType === 'html';

    return {
      'md:col-6': !isFullWidth,
      'md:col-12': isFullWidth,
    };
  }
}
