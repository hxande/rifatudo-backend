import { StatusAccordion, TabInterface } from "../types/tabs.interface";


export const mockTabs: TabInterface[] = [
  {
    title: 'Informações Gerais',
    content: {
      type: 'accordion',
      data: [
        {
          title: 'Painel 1',
          subTitle: 'Dados básicos',
          hasIcon: true,
          icon: 'pi pi-info-circle',
          hasInfo: true,
          infoText: 'Este painel contém dados básicos.',
          status: StatusAccordion.PENDENTE,
          fields: [
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Digite seu nome',
              subTitle: '',
              label: 'Nome',
              value: 'João Silva',
              required: true,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: true,
              icon: 'pi pi-user',
              status: true,
              hasInfo: true,
              infoText: 'Informe seu nome completo',
              accordions: []
            },
            {
              type: 'checkbox',
              isAccordion: false,
              placeHolder: '',
              subTitle: '',
              label: 'Aceito termos',
              value: true,
              required: true,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'textArea',
              isAccordion: false,
              placeHolder: 'Digite uma descrição',
              subTitle: '',
              label: 'Descrição',
              value: 'Descrição inicial do usuário',
              required: false,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'select',
              isAccordion: false,
              placeHolder: 'Selecione uma opção',
              subTitle: '',
              label: 'País',
              value: {
                options: [
                  { label: 'Brasil', value: 'br' },
                  { label: 'Argentina', value: 'ar' },
                  { label: 'Estados Unidos', value: 'us' }
                ],
                selected: 'br'
              },
              required: true,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: true,
              icon: 'pi pi-globe',
              status: true,
              hasInfo: true,
              infoText: 'Selecione seu país de residência',
              accordions: []
            }
          ]
        },
        {
          title: 'Painel 2 - Accordion Aninhado',
          subTitle: '',
          hasIcon: false,
          icon: '',
          hasInfo: false,
          infoText: '',
          status: StatusAccordion.PARCIAL,
          fields: [
            {
              type: 'accordion',
              isAccordion: true,
              placeHolder: '',
              subTitle: '',
              label: '',
              value: null,
              required: false,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: false,
              hasInfo: false,
              infoText: '',
              accordions: [
                {
                  title: 'Sub-Painel 1',
                  subTitle: 'Conteúdo do sub painel',
                  hasIcon: true,
                  icon: 'pi pi-folder',
                  hasInfo: true,
                  infoText: 'Informações do sub painel',
                  status: StatusAccordion.COMPLETO,
                  fields: [
                    {
                      type: 'tag',
                      isAccordion: false,
                      placeHolder: 'Adicione tags',
                      subTitle: '',
                      label: 'Tags',
                      value: ['angular', 'primeng'],
                      required: false,
                      inputType: 'text',
                      hasMask: false,
                      mask: null,
                      hasIcon: false,
                      icon: '',
                      status: true,
                      hasInfo: false,
                      infoText: '',
                      accordions: []
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  },
  {
    title: 'Preferências',
    content: {
      type: 'accordion',
      data: [
        {
          title: 'Configurações Gerais',
          subTitle: '',
          hasIcon: false,
          icon: '',
          hasInfo: false,
          infoText: '',
          status: StatusAccordion.PENDENTE,
          fields: [
            {
              type: 'radio',
              isAccordion: false,
              placeHolder: '',
              subTitle: '',
              label: 'Gênero',
              value: {
                options: [
                  { label: 'Masculino', value: 'M' },
                  { label: 'Feminino', value: 'F' },
                  { label: 'Outro', value: 'O' }
                ],
                selected: 'M'
              },
              required: true,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'multCheckbox',
              isAccordion: false,
              placeHolder: '',
              subTitle: '',
              label: 'Interesses',
              value: {
                options: [
                  { label: 'Tecnologia', value: 'tech' },
                  { label: 'Esportes', value: 'sports' },
                  { label: 'Música', value: 'music' }
                ],
                selected: ['tech', 'music']
              },
              required: false,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: true,
              infoText: 'Selecione seus interesses',
              accordions: []
            },
            {
              type: 'divider',
              isAccordion: false,
              placeHolder: '',
              subTitle: '',
              label: '',
              value: null,
              required: false,
              inputType: 'text',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: false,
              hasInfo: false,
              infoText: '',
              accordions: []
            }
          ]
        }
      ]
    }
  }
];




export const mockTabs1: TabInterface[] = [
  {
    title: 'Dados Sociais',
    content: {
      type: 'accordion',
      data: [
        {
          title: 'Informações do Ano 2024',
          subTitle: 'Dados numéricos gerais',
          hasIcon: false,
          icon: '',
          hasInfo: false,
          infoText: '',
          status: StatusAccordion.PENDENTE,
          fields: [
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Ano',
              subTitle: '',
              label: 'Ano',
              value: 2024,
              required: true,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Cooperados Ativos',
              subTitle: '',
              label: 'Cooperados Ativos',
              value: null,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Cooperados Homens',
              subTitle: '',
              label: 'Cooperados Homens',
              value: 16,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Cooperados Mulheres',
              subTitle: '',
              label: 'Cooperados Mulheres',
              value: 15,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Cooperados PF',
              subTitle: '',
              label: 'Cooperados PF',
              value: 31,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Cooperados PJ',
              subTitle: '',
              label: 'Cooperados PJ',
              value: 0,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Cooperados Total',
              subTitle: '',
              label: 'Cooperados Total',
              value: 31,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Empregados Homens',
              subTitle: '',
              label: 'Empregados Homens',
              value: 0,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Empregados Mulheres',
              subTitle: '',
              label: 'Empregados Mulheres',
              value: 0,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            },
            {
              type: 'input',
              isAccordion: false,
              placeHolder: 'Empregados Total',
              subTitle: '',
              label: 'Empregados Total',
              value: 0,
              required: false,
              inputType: 'number',
              hasMask: false,
              mask: null,
              hasIcon: false,
              icon: '',
              status: true,
              hasInfo: false,
              infoText: '',
              accordions: []
            }
          ]
        }
      ]
    }
  }
];
