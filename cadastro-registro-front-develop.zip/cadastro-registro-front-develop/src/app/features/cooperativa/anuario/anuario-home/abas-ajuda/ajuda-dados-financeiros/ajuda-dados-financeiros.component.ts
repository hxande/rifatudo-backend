import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ajuda-dados-financeiros',
  templateUrl: './ajuda-dados-financeiros.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['../ajuda-dados-sociais/ajuda-dados-sociais.component.css']
})
export class AjudaDadosFinanceirosComponent implements OnInit {

 
  constructor() { }

  ngOnInit() {
    
  }

}
