import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ajuda-contabil-fiscal',
  templateUrl: './ajuda-contabil-fiscal.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['../ajuda-dados-sociais/ajuda-dados-sociais.component.css']
})
export class AjudaContabilFiscalComponent implements OnInit {

 
  constructor() { }

  ngOnInit() {
    
  }

}
