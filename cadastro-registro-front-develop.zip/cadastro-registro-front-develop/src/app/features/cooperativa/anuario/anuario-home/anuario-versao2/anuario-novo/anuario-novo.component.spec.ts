import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnuarioNovoComponent } from './anuario-novo.component';

describe('AnuarioNovoComponent', () => {
  let component: AnuarioNovoComponent;
  let fixture: ComponentFixture<AnuarioNovoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnuarioNovoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AnuarioNovoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
