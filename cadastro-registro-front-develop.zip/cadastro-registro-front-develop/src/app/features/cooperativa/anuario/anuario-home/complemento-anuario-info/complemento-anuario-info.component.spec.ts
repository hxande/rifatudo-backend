import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplementoAnuarioInfoComponent } from './complemento-anuario-info.component';

describe('ComplementoAnuarioInfoComponent', () => {
  let component: ComplementoAnuarioInfoComponent;
  let fixture: ComponentFixture<ComplementoAnuarioInfoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplementoAnuarioInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplementoAnuarioInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
