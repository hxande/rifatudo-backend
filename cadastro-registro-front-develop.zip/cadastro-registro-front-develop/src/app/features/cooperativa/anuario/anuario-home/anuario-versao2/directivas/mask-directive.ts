import {
  AfterViewInit,
  Directive,
  ElementRef,
  HostListener,
  Input,
} from '@angular/core';

@Directive({
  selector: '[appMask]',
})
export class MaskDirective implements AfterViewInit {
  @Input('appMask')
  maskType: 'currency' | 'currencyNegative' | 'meters' | 'kilograms' | 'arroba' | 'numeric' = 'numeric';

  @Input() precision: number = 2;

  private el: HTMLInputElement;

  constructor(private elementRef: ElementRef<HTMLInputElement>) {
    this.el = this.elementRef.nativeElement;
  }

  private getFormatter() {
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: this.precision,
      maximumFractionDigits: this.precision,
    });
  }

  // Aplicar máscara assim que o input estiver renderizado
  ngAfterViewInit(): void {
    // pequeno delay pra garantir que o Angular já colocou o valor inicial no input
    setTimeout(() => this.applyMask());
  }

  // Aplicar máscara em cada digitação
  @HostListener('input')
  onInput(): void {
    this.applyMask();
  }

  private applyMask(): void {
    let value = this.el.value || '';

    switch (this.maskType) {
      case 'currency':
        value = this.formatCurrency(value);
        break;
      case 'currencyNegative':
        value = this.formatCurrencyNegative(value);
        break;
      case 'meters':
        value = this.formatMeters(value);
        break;
      case 'kilograms':
        value = this.formatKilograms(value);
        break;
      case 'arroba':
        value = this.formatArroba(value);
        break;
      case 'numeric':
        value = value.replace(/\.[\d]*/g, '');
        break;
      default:
        break;
    }

    this.el.value = value;
  }

  // ====== FORMATOS ======

  // Currency:
  // - Entrada pode ser "2342.00", "3.00", "10.00" ou só dígitos
  // - Saída: "2.342,00", "3,00", "10,00" (sem "R$")
  private formatCurrency(value: string): string {
    // remove tudo que não for número
    let num = value.replace(/[^\d]/g, '');
    if (!num) return '';

    // "234200" -> 2342.00
    const n = parseInt(num, 10);
    const val = n / Math.pow(10, this.precision);

    return val.toLocaleString('pt-BR', {
      minimumFractionDigits: this.precision,
      maximumFractionDigits: this.precision,
    });
  }

  private formatCurrencyNegative(value: string): string {
    const sanitized = this.sanitizeRaw(value);
    const formatted = this.formatDigitsToPtBr(sanitized);
    return formatted;
  }

  private sanitizeRaw(value: string): string {
    const negative = value.trim().startsWith('-');
    const digits = value.replace(/\D/g, ''); // tira tudo que não for número
    if (!digits && negative) return '-';
    return negative ? `-${digits}` : digits;
  }

  /**
   * Converte dígitos para pt-BR com 2 casas.
   * Ex.: "9887987" -> "98.879,87"
   * Ex.: "-9887987" -> "-98.879,87"
   */
  private formatDigitsToPtBr(value: string): string {
    if (!value || value === '-') return value;
    const negative = value.startsWith('-');
    const digits = value.replace(/\D/g, '');

    if (!digits) return negative ? '-' : '';
    const numeric = Number(digits) / Math.pow(10, this.precision);
    const finalValue = negative ? -numeric : numeric;

    return this.getFormatter().format(finalValue);
  }

  private formatMeters(value: string): string {
    const num = value.replace(/[^\d]/g, '');
    if (!num) return '';
    return `${num} m`;
  }

  private formatKilograms(value: string): string {
    const num = value.replace(/[^\d]/g, '');
    if (!num) return '';
    return `${num} kg`;
  }

  private formatArroba(value: string): string {
    const num = value.replace(/[^\d]/g, '');
    if (!num) return '';
    return `${num} @`;
  }
}
