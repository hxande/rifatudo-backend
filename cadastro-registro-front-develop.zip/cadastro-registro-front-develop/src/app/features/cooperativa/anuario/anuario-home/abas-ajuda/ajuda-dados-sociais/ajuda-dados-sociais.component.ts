import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-ajuda-dados-sociais',
  templateUrl: './ajuda-dados-sociais.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./ajuda-dados-sociais.component.css']
})
export class AjudaDadosSociaisComponent implements OnInit {

 
  constructor() { }

  ngOnInit() {
    
  }

  navegarTutorial() {
    const link = document.createElement('a');
    document.body.appendChild(link);
    link.target = '_blank';
    link.setAttribute('visibility', 'hidden');
    link.href = 'https://www.capacita.coop.br/videos/anuariocoop-inserindo-seus-dados-no-soucoop';
    link.click();

}


}
