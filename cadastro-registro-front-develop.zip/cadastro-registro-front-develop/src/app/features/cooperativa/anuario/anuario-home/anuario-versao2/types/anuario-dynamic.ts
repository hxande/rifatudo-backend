import { AbstractControl, FormArray, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ITabHandler } from './tabs-handle.interface';
import { FieldChangedEvent, TabDataInterface, TabField, TabInterface, ValueTabField } from './tabs.interface';
import { AnuarioValidacao } from '../anuario-novo/services/validacao-anuario.service';
import { MessageService } from 'primeng/api';

const TAB_PORTFOLIO = 'tab-portfolio';
const TAB_COMPLEMENTAR = 'tab-dados-complementares';

type ValuesMap = Record<string, Array<Record<string, unknown>>>;
type Field = {
  id: string;
  name?: string;
  value: string | number | ValueTabField | null;
  type?: string | null; // divider | accordion | section | input | ...
  inputType?: 'text' | 'number' | string | null;
  hasMask: boolean;
  mask: string;
  quantidadeDeCasas?: number;

  idParametro?: number | string | null;
  idParametroAuxiliar?: number | string | null;
  parametroIntegracao?: unknown;
};

type Panel = {
  name: string;
  idQuadro: number | null;
  idQuadroAuxiliar: number | null;
  fields: Field[][];
};

type OutputField = {
  id: string;
  name: string;
  value: string | number | null | String[];
  idParametro?: number | string | null;
  idParametroAuxiliar?: number | string | null;
  parametroIntegracao?: unknown;
};

type OutputPanel = {
  name: string;
  idQuadro: number | null;
  fields: OutputField[][];
};

const SKIP_TYPES = new Set(['divider', 'accordion', 'section']);
const OPTION_TYPES = new Set(['radio', 'select', 'selectbutton', 'multcheckbox']);
const PENDENCIA_FORM = 'pendencia-form';

export abstract class AnuarioDynamic {
  form: FormGroup;
  formBuilder: FormBuilder;
  tabs: TabInterface[] = [];
  activeHandler: ITabHandler;
  activeIndex = 0;

  constructor(fb: FormBuilder, protected messageService?: MessageService) {
    this.formBuilder = fb;
    this.form = this.formBuilder ? this.formBuilder.group({}) : new FormGroup({});
  }

  abstract init(): Promise<void>;
  async criarFormularioAba(dados: TabDataInterface[] = []) {
    const temValidacao = AnuarioValidacao.iniciarValidacao(dados);
    if (temValidacao.length > 0) {
      console.warn('Inconsistências no schema dos campos do anuário:', temValidacao);
      temValidacao.forEach((mensagem) => {
        this.messageService?.add({ severity: 'warn', summary: 'Configuração da aba com inconsistência', detail: mensagem, life: 10000 });
      });
    }
    this.atualizarAba(this.activeIndex, dados);
  }

  protected atualizarAba(index: number, novoData: TabDataInterface[]): void {
    const novaAba = this.criarNovaAbaComDados(index, novoData);
    this.substituirAba(index, novaAba);
  }

  protected criarNovaAbaComDados(index: number, novoData: TabDataInterface[]): TabInterface {
    const abaAtual = this.tabs[index];
    return {
      ...abaAtual,
      content: {
        ...abaAtual.content,
        data: novoData,
      },
    };
  }

  protected substituirAba(index: number, novaAba: TabInterface): void {
    this.tabs = [...this.tabs.slice(0, index), novaAba, ...this.tabs.slice(index + 1)];
  }
  onFieldAlterado(event: FieldChangedEvent) {
    const aba = this.tabs[this.activeIndex];
    const abaHandler = this.activeHandler;
    if (abaHandler?.onFieldChange) {
      abaHandler.onFieldChange(event.fieldId, event.value, event.formGroup, aba);
    }
  }

  protected inicializarFormulario(): void {
    if (!this.form) this.form = this.formBuilder.group({});
  }

  criarAba(id: string, nome: string, abaPreenchida = false): TabInterface {
    const aba = {
      id,
      title: nome,
      tabPreenchida: abaPreenchida,
      content: { type: 'accordion', data: [] },
    } as TabInterface;
    this.tabs.push(aba);
    return aba;
  }

  limparAbas(): void {
    this.tabs = [];
    this.activeHandler = null;
    this.form.reset();
  }

  onTabChange(index: unknown) {
    this.activeIndex = index as number;
    this.carregarDadosAbaAtiva(this.activeIndex);
  }

  getIndiceTabAtiva() {
    return this.activeIndex;
  }

  getControlesAbaAtiva() {
    const tab = this.tabs[this.activeIndex];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;
    if (activeFormGroup) {
      return activeFormGroup.controls;
    }
  }

  getValoresAbaAtiva() {
    const tab = this.tabs[this.activeIndex];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;
    if (activeFormGroup) {
      return activeFormGroup.getRawValue();
    }
  }

  isTodasAbasCompletas(): boolean {
    return this.tabs.every((tab) => tab.situacao >= 0) && this.tabs.every((tab) => tab.temPendencia == false);
  }

  isPortfolioTab(tab: TabInterface): boolean {
    return tab?.id === TAB_PORTFOLIO;
  }

  isComplementaryTab(tab: TabInterface): boolean {
    return tab?.id === TAB_COMPLEMENTAR;
  }

  isStandardTab(tab: TabInterface): boolean {
    return !this.isPortfolioTab(tab) && !this.isComplementaryTab(tab);
  }

  getTabFormGroup(id: string): FormGroup {
    return this.form.get(id) as FormGroup;
  }

  getSituacaoPendencia(situacao: number): 'completo' | 'incompleto-invalid' | 'incompleto-vazio' {
    switch (situacao) {
      case 1:
        return 'completo';
      case -1:
        return 'incompleto-invalid';
      case 0:
        return 'incompleto-vazio';
      default:
        return 'incompleto-invalid';
    }
  }

  private validaInputPendencia(tab: TabInterface): boolean {
    return tab.content.data.some((item) => (item.fields as TabField[][]).some((field) => field.some((f) => f?.id === PENDENCIA_FORM && !!f?.value)));
  }

  protected atualizarStatusAba() {
    const tab = this.tabs[this.activeIndex];

    if (this.isStandardTab(tab)) {
      if (this.validaInputPendencia(tab)) {
        this.setSituacaoPendenciaTab(tab, 'incompleto-invalid');
        tab.temPendencia = true;
        return;
      }

      const tabGroup = this.getTabFormGroup(tab.id);
      // if (!tabGroup) return this.getSituacaoPendencia(tab.situacao);

      const keys = Object.keys(tabGroup.controls);
      // if (keys.length === 0) return this.getSituacaoPendencia(tab.situacao);

      let temObrigatorioInvalidoNaAba = false;
      let temOpcionalVazioNaAba = false;
      let todosAccordionsCompletos = true;

      for (const key of keys) {
        const ctrl = tabGroup.get(key);
        if (!ctrl || !(ctrl instanceof FormArray) || ctrl.length === 0) continue;

        let temObrigatorioInvalido = false;
        let temOpcionalVazio = false;
        let todosRowsCompletos = true;

        ctrl.controls.forEach((rowCtrl) => {
          if (rowCtrl.invalid) {
            temObrigatorioInvalido = true;
            return;
          }

          const valores = Object.values(rowCtrl.value || {});
          const temVazio = valores.some((v) => v === null || v === undefined || v === '');

          if (temVazio) temOpcionalVazio = true;
          todosRowsCompletos = todosRowsCompletos && !temVazio;
        });

        if (temObrigatorioInvalido) temObrigatorioInvalidoNaAba = true;
        if (temOpcionalVazio) temOpcionalVazioNaAba = true;
        todosAccordionsCompletos = todosAccordionsCompletos && todosRowsCompletos;
      }

      if (temObrigatorioInvalidoNaAba) {
        this.setSituacaoPendenciaTab(tab, 'incompleto-invalid');
        tab.temPendencia = true;
        return;
      }
      if (temOpcionalVazioNaAba) {
        this.setSituacaoPendenciaTab(tab, 'incompleto-vazio');
        tab.temPendencia = false;
        return;
      }
      if (todosAccordionsCompletos) {
        this.setSituacaoPendenciaTab(tab, 'completo');
        tab.temPendencia = false;
        return;
      }

      this.setSituacaoPendenciaTab(tab, 'incompleto-vazio');
    }
  }

  getTabByIndex(index: number): TabInterface {
    return this.tabs[index];
  }

  setSituacaoPendenciaTab(tab, status: string) {
    switch (status) {
      case 'completo':
        tab.situacao = 1;
        break;
      case 'incompleto-invalid':
        tab.situacao = -1;
        break;
      case 'incompleto-vazio':
        tab.situacao = 0;
        break;
      default:
        break;
    }
  }

  protected onSubmit() {
    const tab = this.tabs[this.activeIndex];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;

    if (activeFormGroup) {
      // Exemplo de validação
      if (activeFormGroup.invalid) {
        console.warn('Formulário da aba ativa é inválido!');
      }
    }
  }

  protected onSumitForm(tab: TabInterface, controlName: string, activeFormGroup: FormGroup) {
    this.activeHandler.salvarFormulario(tab, controlName, activeFormGroup);
  }

  protected abstract carregarDadosAbaAtiva(indexAbaAtiva: Number): Promise<void>;

  protected gerarPayload() {
    const tab = this.tabs[this.activeIndex];
    const controlName = tab.id;
    const activeFormGroup = this.form.get(controlName) as FormGroup;

    // content.data é tratado como painéis com fields aninhados (Field[][]) nesta etapa de montagem do payload
    let data = tab.content.data as unknown as (Panel & { id: string })[];
    const formGroup = activeFormGroup.getRawValue();

    data = this.applyValuesToPanels(data, formGroup);
    const payload = this.buildPayloadFromPanels(data, tab.id, tab.situacao);
    return payload;
  }

  protected applyValuesToPanels<T extends { id: string; fields: Field[][] }>(panels: T[], valuesMap: ValuesMap): T[] {
    const SELECT_TYPES = new Set(['multCheckbox', 'selectButton', 'select', 'radio']);
    return panels.map((panel) => {
      const rowsValues = valuesMap[panel.id];

      if (!Array.isArray(rowsValues)) return panel;

      const nextFields = (panel.fields ?? []).map((rowFields, rowIndex) => {
        const rowValueObj = rowsValues[rowIndex] ?? {};

        return (rowFields ?? []).map((field: Field) => {
          if (!field?.id) return field;

          if (!(field.id in rowValueObj)) return field;

          const incoming = rowValueObj[field.id];

          if (SELECT_TYPES.has(field.type) && field.value && typeof field.value === 'object') {
            return {
              ...field,
              value: {
                ...field.value,
                selected: incoming,
              },
            };
          }

          return {
            ...field,
            value: incoming,
          };
        });
      });

      return {
        ...panel,
        fields: nextFields,
      };
    });
  }

  protected toNumberBR(value: string | number | null | undefined): number | null {
    if (value === null || value === undefined || value === '') return null;
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;

    const s = String(value).trim();
    if (!s) return null;

    const normalized = s
      .replace(/\s/g, '')
      .replace(/\.(?=\d{3}(\D|$))/g, '') // remove pontos de milhar (BR)
      .replace(/,(?=\d{1,2}$)/, '.'); // troca vírgula decimal por ponto

    const n = Number(normalized.replace(/,/g, '')); // fallback p/ "1,234.56"
    return Number.isFinite(n) ? n : null;
  }

  unwrapOptionValue(field: Field): string | number | string[] | null {
    const t = String(field.type ?? '').toLowerCase();
    if (!OPTION_TYPES.has(t)) return field.value as string | number | null;
    if (field.value && typeof field.value === 'object' && 'selected' in field.value) {
      return (field.value as ValueTabField).selected as string | number | string[];
    }

    return field.value as string | number | null;
  }

  toNumberMask(value, decimalPlaces: number = 2) {
    if (value === null || value === undefined || value === '') return null;
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;

    const raw = String(value).trim();
    if (!raw) return null;
    const isNegative = raw.includes('-');

    // Se já tem ponto decimal (formato inglês), retorna como está
    if (raw.includes('.') && !raw.includes(',')) {
      return isNegative ? `-${raw.replace('-', '')}` : raw;
    }

    // Se tem vírgula (formato brasileiro), converte
    if (raw.includes(',')) {
      const digitsOnly = raw.replace(/\D/g, '');
      const padded = digitsOnly.padStart(decimalPlaces + 1, '0');
      const intPart = padded.slice(0, -decimalPlaces);
      const decPart = padded.slice(-decimalPlaces);
      const result = `${intPart}.${decPart}`;
      return isNegative ? `-${result}` : result;
    }

    // Se não tem separador decimal, assume que é um valor inteiro em centavos
    // (comportamento da máscara currency que multiplica por 100)
    const digitsOnly = raw.replace(/\D/g, '');
    if (!digitsOnly) return null;

    const padded = digitsOnly.padStart(decimalPlaces + 1, '0');
    const intPart = padded.slice(0, -decimalPlaces);
    const decPart = padded.slice(-decimalPlaces);

    const result = `${intPart}.${decPart}`;
    return isNegative ? `-${result}` : result;
  }

  protected castValueByInputType(field: Field): string | number | null | String[] {
    const raw = this.unwrapOptionValue(field);

    if (field.hasMask) {
      return this.toNumberMask(raw, field.quantidadeDeCasas || 2);
    }

    if (field.inputType === 'text') {
      if (raw === null || raw === undefined) return '';
      return String(raw);
    }

    if (field.type === 'multCheckbox') {
      if (raw === null || raw === undefined) return '';
      const valores = String(raw)
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean)
        .map(Number);

      return JSON.stringify(valores);
    }

    return raw ?? null;
  }

  protected buildPayloadFromPanels(panels: Panel[], id: string, situacao: number): { id: string; situacao: number; fields: OutputPanel[] } {
    const outputPanels: OutputPanel[] = (panels ?? [])
      .map((panel) => {
        const nextFields: OutputField[][] = (panel.fields ?? [])
          .map((row) =>
            (row ?? [])
              .filter((f) => !SKIP_TYPES.has(String(f.type ?? '').toLowerCase()))
              .map((f) => ({
                id: f.id,
                name: f.name,
                value: this.castValueByInputType(f),
                idParametro: f.idParametro ?? null,
                idParametroAuxiliar: f.idParametroAuxiliar ?? null,
                parametroIntegracao: f.parametroIntegracao ?? null,
              }))
          )
          .filter((row) => row.length > 0);

        return {
          name: panel.name,
          idQuadro: panel.idQuadro ?? null,
          idQuadroAuxiliar: panel.idQuadroAuxiliar ?? null,
          fields: nextFields,
        };
      })
      .filter((panel) => panel.fields.length > 0);

    return {
      id: id,
      situacao: situacao,
      fields: outputPanels,
    };
  }

  protected setValueSafe(form: FormGroup, controlId: string, value: unknown) {
    const control = form.get(controlId);
    if (control) control.setValue(value);
  }

  protected sumFields(formGroup: FormGroup, f1: string, f2: string, target: string) {
    const v1 = Number(formGroup.get(f1)?.value) || 0;
    const v2 = Number(formGroup.get(f2)?.value) || 0;
    const result = v1 + v2;
    formGroup.get(target)?.setValue(result);
  }

  protected removeControl(formGroup: FormGroup, controlName: string) {
    formGroup.removeControl(controlName);
  }

  protected removeControls(formGroup: FormGroup, controlNames: string[]) {
    controlNames.forEach((name) => formGroup.removeControl(name));
  }

  protected clearAllControls(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((control) => formGroup.removeControl(control));
  }

  protected addControl(formGroup: FormGroup, controlName: string, control: FormControl) {
    formGroup.addControl(controlName, control);
  }

  protected addControls(formGroup: FormGroup, controls: { name: string; control: FormControl }[]) {
    controls.forEach(({ name, control }) => formGroup.addControl(name, control));
  }

  protected clearValueField(field: TabField) {
    if (field.type === 'multCheckbox') {
      (field.value as ValueTabField).selected = '';
    } else if (field.type === 'selectButton') {
      (field.value as ValueTabField).selected = '';
    } else {
      field.value = null;
    }
  }

  protected createControlsFromFields(fields: TabField[]): { name: string; control: FormControl }[] {
    fields = fields.filter((field) => !SKIP_TYPES.has(String(field.type ?? '').toLowerCase()));
    return fields.map((field) => {
      const safeName = field.id;
      const validators = field.required ? [Validators.required] : [];
      let initialValue: unknown = field.value;

      if (field.type === 'multCheckbox' || field.type === 'selectButton' || field.type === 'select' || field.type === 'radio') {
        initialValue = (field.value as ValueTabField)?.selected ?? '';
      }

      if (field.type === 'multCheckbox') {
        initialValue = String((field.value as ValueTabField).selected)
          .split(',')
          .map((item) => item.trim())
          .filter((item) => item !== '');
      }

      const control = new FormControl({ value: initialValue, disabled: field.disable }, validators);
      return { name: safeName, control };
    });
  }

  protected criarAccordion(
    id: string,
    titulo: string,
    subTitulo: string,
    hasIcon: boolean,
    icon: string,
    hasInfo: boolean,
    infoText: string,
    fnPreencherCampos: () => TabField[]
  ): TabDataInterface {
    return {
      id: id,
      title: titulo,
      subTitle: subTitulo,
      hasIcon: hasIcon,
      icon: icon,
      hasInfo: hasInfo,
      infoText: infoText,
      fields: fnPreencherCampos(),
    };
  }
  protected removeAllValidators(form: FormGroup) {
    Object.keys(form.controls).forEach((key) => {
      const control = form.get(key);
      control?.clearValidators();
      control?.updateValueAndValidity({ emitEvent: false });
    });
  }

  addRequiredToAll(form: FormGroup) {
    Object.keys(form.controls).forEach((key) => {
      const control = form.get(key) as FormControl;

      const currentValidator = control.validator ? [control.validator] : [];
      const newValidators = [...currentValidator, Validators.required];

      control.setValidators(newValidators);
      control.updateValueAndValidity({ emitEvent: false });
    });
  }

  addRequiredRecursivo(control: AbstractControl) {
    if (control instanceof FormGroup || control instanceof FormArray) {
      Object.values(control.controls).forEach((child) => this.addRequiredRecursivo(child));
    } else {
      const currentValidator = control.validator ? [control.validator] : [];
      const newValidators = [...currentValidator, Validators.required];
      control.setValidators(newValidators);
      control.updateValueAndValidity({ emitEvent: false });
    }
  }

  addValidatorsToControl(form: FormGroup, controlName: string, validators: ValidatorFn | ValidatorFn[]): void {
    const control: AbstractControl | null = form.get(controlName);
    if (!control) {
      console.warn(`Control '${controlName}' não encontrado no form.`);
      return;
    }

    const validatorsArray = Array.isArray(validators) ? validators : [validators];

    const current = control.validator ? [control.validator] : [];
    const merged = [...current, ...validatorsArray];

    control.setValidators(merged);
    control.updateValueAndValidity({ emitEvent: false });
  }

  protected removeValidatorsFromControls(form: FormGroup, controlNames: string[]): void {
    controlNames.forEach((name) => {
      const control = form.get(name);
      if (control) {
        control.clearValidators();
        control.updateValueAndValidity({ emitEvent: false });
      } else {
        console.warn(`Control '${name}' não encontrado no form.`);
      }
    });
  }
}
