import { ChangeDetectionStrategy, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
interface AjudaItem {
  title: string;
  subtitle: string;
}

@Component({
  selector: 'app-ajuda-dinamica',
  templateUrl: './ajuda-dinamica.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['../ajuda-dados-sociais/ajuda-dados-sociais.component.css']
})
export class AjudaDinamicaComponent implements OnInit {

  @Input() ajudaItens: AjudaItem[] = [];
  activeIndex: number | null = null;

  constructor() { }

  ngOnInit() { }

  navegarTutorial() {
      const link = document.createElement('a');
      document.body.appendChild(link);
      link.target = '_blank';
      link.setAttribute('visibility', 'hidden');
      link.href = 'https://www.capacita.coop.br/videos/anuariocoop-inserindo-seus-dados-no-soucoop';
      link.click();
      document.body.removeChild(link); // Boa prática remover o elemento
  }
  public fecharTodos() {
    this.activeIndex = null;
  }
}