import { FormGroup } from '@angular/forms';

export enum StatusAccordion {
  PENDENTE,
  COMPLETO,
  PARCIAL,
}

export interface TabInterface {
  id: string,
  title: string;
  handler?: unknown;
  tabPreenchida?: boolean;
  temPendencia?: boolean;
  situacao?: 0 | 1 | -1,
  content?: {
    type?: 'accordion';
    data?: TabDataInterface[];
  };
}

export interface TabDataInterface {
  id: string,
  title?: string;
  subTitle?: string;
  hasIcon?: boolean;
  icon?: string;
  hasInfo?: boolean;
  infoText?: string;
  status?: StatusAccordion;
  idQuadro?: number;
  name?: string;
  fields?: TabField[] | TabField[][];
}

export interface TabField {
  id: string;
  idParametro?: number,
  type: 'input' | 'checkbox' | 'textArea' | 'radio' | 'multCheckbox' | 'select' | 'tag' | 'accordion' | 'divider' | 'section' | 'selectButton' | 'html';
  isAccordion?: boolean;
  placeHolder?: string;
  subTitle?: string;
  label?: string;
  value: string | number | ValueTabField | null;
  accordions?: TabDataInterface[];
  parametroIntegracao?: string;
  required?: boolean;
  inputType?: 'text' | 'number' | 'data';
  hasMask?: boolean;
  mask?: 'currency' | 'meters' | 'kilograms' | 'arroba' | 'numeric';
  hasIcon?: boolean;
  icon?: string;
  status?: boolean;
  hasInfo?: boolean;
  infoText?: string;
  readonly?: boolean;
  disable?: boolean;
  visible?: boolean;
  isAceitaNegativo?: boolean;
  siglaUnidade?: string;
  quantidadeDeCasas?: number;
}


export interface ValueTabField {
  options: { label: string, value: string | number }[],
  selected: string | number | string[]

}

export interface FieldChangedEvent {
  fieldId: string;
  value: string | number | string[] | null;
  formGroup: FormGroup;
}

// fields ora chega plano (TabField[]) ora em linhas (TabField[][]) dependendo da origem dos dados;
// normaliza para uma lista plana de campos.
export function flattenFields(fields: TabField[] | TabField[][] | undefined | null): TabField[] {
  if (!fields) return [];
  return (fields as (TabField | TabField[])[]).reduce<TabField[]>((acc, f) => acc.concat(Array.isArray(f) ? f : [f]), []);
}
