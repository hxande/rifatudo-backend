import { Component, Input, EventEmitter, OnInit, Output, ViewChild, Inject, AfterViewInit, ElementRef, inject, DestroyRef, ChangeDetectorRef } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Situacao } from '@cadastro-registro-api/models/Situacao';
import { PessoaImagem } from '@cadastro-registro-api/models/PessoaImagem';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { ApiCooperativaLogoService } from '@cadastro-registro-api/services/api-cooperativa-logo.service';
import { Usuario } from '@gerencia-usuario-api/models/Usuario';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';
import { ValidacaoLogo } from '@gui/logo-cooperativa/validacao/validacao-logo.service';
import { ApiMandatoMembro } from '@cadastro-registro-api/services/api-mandato-membro.service';
import { MandatoMembro } from '@cadastro-registro-api/models/MandatoMembro';
import { MandatoMembroTO } from '@cadastro-registro-api/models/MandatoMenbroTO';
import { Municipio } from '@localizacao-api/public-api';
import { DatePipe, formatDate } from '@angular/common';
import { saveAs } from 'file-saver';
import { StatusEnum } from '@cadastro-registro-api/models/StatusEnum';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';
import { KEYCLOAK_CLIENT_ID, KeyclokClientEnum } from '@auth/auth-guard/constants';
import { ApiMudancaUFService } from '@cadastro-registro-api/services/api-mudanca-uf.service';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { ObservacaoUeComponent } from '@shared/observacao-ue/observacao-ue.component';
import { ApiCooperativaObservacaoUeService } from '@cadastro-registro-api/services/api-cooperativa-observacao-ue.service';
import { ValidacaoInformacoesGerais } from '@shared/validacao/validacao-informacoes-gerais.service';
import { PermissaoCooperativa } from './permissao/permissao.service';
import { ValidacaoCooperativa } from '../registro/validacao/validacao-cooperativa.service';
import { CooperativaRegistro } from '@cadastro-registro-api/models/CooperativaRegistro';
import { SplitButton } from 'primeng/splitbutton';
import { CensoAnuarioTO } from 'src/app/api/models/CensoAnuarioTO';
import { ApiCensoAnuarioService } from 'src/app/api/services/api-censo-anuario.service';
import { FormStatusService } from '@gui/directive/service/form-status.service';
import { CooperativaDatamartTO } from '@cadastro-registro-api/models/CooperativaDatamartTO';
import { ControleAtualizacaoCadastralTO } from 'src/app/api/models/ControleAtualizacaoCadastralTO';
import { ApiControleAtualizacaoCadastralService } from 'src/app/api/services/api-controle-atualizacao-cadastral.service';
import { ControleAnuarioUFTO } from 'src/app/api/models/ControleAnurioUFTO';
import { ApiControleAnuarioUfService } from 'src/app/api/services/api-controle-anuario-uf.service';
import { ApiCertificadosService } from 'src/app/api/services/api-certificados.service';
import { CertificadoRegularidadeUnidadeEstadualTO } from 'src/app/api/models/CertificadoRegularidadeUnidadeEstadualTO';
import { SistemaVinculacaoCooperativaTO } from 'src/app/api/models/SistemaVinculacaoCooperativaTO';
import { ApiSistemaVinculacaoCooperativaService } from 'src/app/api/services/api-sistema-vinculacao-cooperativa.service';
import { ApiCooperativaSituacaoService } from 'src/app/api/services/api-cooperativa-situacao.service';
import { CooperativaSolicitacaoSituacaoTO } from 'src/app/api/models/CooperativaSolicitacaoSituacaoTO';
import { NovaSituacaoEnum } from 'src/app/api/models/SituacaoCooperativaEnum';
import { ApiSolicitacaoService } from 'src/app/api/services/api-solicitacao.service';
import { CooperativaTO } from 'src/app/api/models/CooperativaTO';
import { PessoaJuridicaBasicaTO } from 'src/app/api/models/PessoaJuridicaBasicaTO';
import { ApiDadosGeraisService } from 'src/app/api/services/api-dados-gerais.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { HistoricoCooperativaRegistroListagemTO } from 'src/app/api/models/HistoricoCooperativaRegistroListagemTO';
import { CooperativaSolicitacaoSuspensaoTO } from 'src/app/api/models/CooperativaSolicitacaoSuspensaoTO ';
import { ApiVinculacaoCooperativaSolicitacaoService, CooperativaVinculacaoSolicitacaoTO, } from '../../api/services/api-vinculacao-cooperativa-solicitacao.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-cooperativa',
  templateUrl: './cooperativa.component.html',
  styleUrls: ['./cooperativa.component.css'],
  providers: [ValidacaoLogo],
})
export class CooperativaComponent implements OnInit, AfterViewInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativa: CooperativaTO;
  ultimoSolicitacaoSuspensao: CooperativaRegistro;
  ultimoSolicitacaoCancelamento: CooperativaRegistro;
  ultimoSolicitacaoRegularizacao: CooperativaRegistro;
  mandatoMembro: MandatoMembro;
  mandatoMembroTO: MandatoMembroTO;
  responsaveis: Usuario[];
  cooperativaSolicitacaoSituacaoTO = new CooperativaSolicitacaoSituacaoTO();

  podeSolicitarTrocaUF = false;
  temPermissaoLeituraObservacaoUe = false;
  podeCancelarSolicitacao = false;
  solicitacaoEnviada: boolean;
  podeAprovar: boolean;
  labelBotaoMudancaUF = 'Solicitar transferência de UF';

  txMsgPrecisaRealizarAjustes: string;
  diasConcluirSolicitacaoSuspensao: number;

  modalObservacaoUe = false;
  modalMudancaUF = false;
  modalApontarIrregularidade = false;
  modalSolicitacaoRegularizacao = false;
  modalSolicitacaoCancelamento = false;
  modalSuspenderCooperativa = false;
  modalConcluirSolicitacaoSuspensao = false;
  modalSolicitacaoSuspensao = false;
  modalRegularizarCooperativa = false;
  modalCancelarRegistro = false;
  modalJustificativaIrregular = false;
  modalSolicitacaoSuspensaoAnalise = false;
  modalHistoricoSituacaoCoop = false;
  modalResponsaveis = false;
  modalHitoricoCiclos = false;
  modalComunicacao = false;

  mostrarMensagemConclusao = false;

  historicoCooperativaRegistroListagemTO: HistoricoCooperativaRegistroListagemTO[];

  tooltipInativacao: string;
  passou15diasNotificacaoSuspensao: boolean;

  cooperativaLogo: PessoaImagem = new PessoaImagem();
  selecionadoAcaoCooperativa: string;
  dtUltimaAprovacao: Date = null;
  strSituacaoPeriodoAtualizacao: string;
  txtSituacaoCooperativa = '';
  txClassSituacaoCooperativa = '';
  classIconCadastroCoop = '';
  classColorCadastroCoop = '';
  classIconAnuarioCoop = '';
  classColorAnuarioCoop = '';
  txIconRegularidadeCooperativa = '';
  txClassSituacaoEstado = '';
  txIconStatusRegularidadeCooperativa = '';
  podeModificarLogo = true;
  situacaoEnum = SituacaoEnum;
  certificadoRegularidade: CertificadoRegularidadeUnidadeEstadualTO;
  statusEnum = StatusEnum;
  quadroMsgPrecisaAtualizar: boolean;
  quadroMsgPrecisaAtualizarAposPeriodo: boolean;
  txMsgPrecisaAtualizarAposPeriodo: string;
  camposDesabilitados = false;
  anoInicio: string;
  anoReferencia: number;
  dataFim: string;
  anuarioAtualizado = false;
  statusAtualizacaoAnuario = '';
  lblgoCadastro = '';
  txtDataAutualizacaoCadastral = '';

  cols: {
    field: string,
    header: string,
    width: string
  }[];



  dataInicialLimiteAnuario = new Date('06/13/2022');

  @Input() podeModificar: boolean;
  @Output() dadosLogo = new EventEmitter<IServiceResponse<PessoaImagem>>();
  @Input() toolTip = 'Inserir Marca da cooperativa';
  @Output() travarCampos = new EventEmitter<boolean>();

  itemsOpcoes: MenuItem[];

  @ViewChild('file') file;
  @ViewChild('mantemObservacoesUe') mantemObservacoesUe: ObservacaoUeComponent;
  validacaoLogo: ValidacaoLogo;
  modalLogo: boolean;
  cooperativaId: number;
  messageService: MessageService;
  presidenteNome: string;
  municipio: Municipio;
  podeVisualizarCertificadoRegularidade: boolean = false;

  exibirBotaoSuspender = false;
  qtdCooperados: number;
  qtdEmpregados: number;
  isOpcoesVisiveis: boolean = false;

  podeVerResponsaveis = false;

  @ViewChild('splitButton') splitButton!: SplitButton;

  censoAnuarioTO: CensoAnuarioTO;
  cooperativaDatamartTO: CooperativaDatamartTO;
  usuarioAprovacao: string;
  usuarioSubmissao: Usuario;
  cooperativaMotivo: string;



  controleAnuarioUf: ControleAnuarioUFTO;
  botaoVisualizarAnuario = true;
  destacarAnuario = false;
  dialogControleAnuario = false;
  periodoAtualizacaoAnuario = true;

  controleAtualizacaoCadastral: ControleAtualizacaoCadastralTO;
  botaoVisualizarAtualizacaoCadastral = true;
  destacaAtualizacaoCadastral = false;
  dialogControleAtualizacaoCadastral = false;
  periodoAtualizacaoCadastral = true;

  listSistemaVinculacaoCooperativa: SistemaVinculacaoCooperativaTO[];
  listPendentesVinculo: CooperativaVinculacaoSolicitacaoTO[];
  processandoVinculo = false;
  modalIndicacaoDeFiliacao = false;

  constructor(
    private formStatusService: FormStatusService,
    private router: Router,
    private apiCooperativaService: ApiCooperativaService,
    private apiUsuarioService: ApiUsuarioService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    public validacaoInformacoesGerais: ValidacaoInformacoesGerais,
    public keycloakService: KeycloakService,
    private cooperativaLogoService: ApiCooperativaLogoService,
    private apiMandatoService: ApiMandatoMembro,
    private apiDadosGeraisService: ApiDadosGeraisService,
    private apiCensoAnuarioService: ApiCensoAnuarioService,
    public validacaoCooperativa: ValidacaoCooperativa,
    private apiCooperativaObservacaoService: ApiCooperativaObservacaoUeService,
    private apiMudancaUFService: ApiMudancaUFService,
    public permissaoCooperativa: PermissaoCooperativa,
    private confirmationService: ConfirmationService,
    private apiCensoAnuario: ApiCensoAnuarioService,
    private apiControleAnuarioAnuarioUfService: ApiControleAnuarioUfService,
    private apiControleAtualizacaoCadastralService: ApiControleAtualizacaoCadastralService,
    private apiCertifidadosService: ApiCertificadosService,
    private el: ElementRef,
    private apiSistemaVinculacaoCooperativa: ApiSistemaVinculacaoCooperativaService,
    private apiCooperativaSituacaoService: ApiCooperativaSituacaoService,
    private apiSolicitacao: ApiSolicitacaoService,
    private apiVinculacaoSolicitacaoService: ApiVinculacaoCooperativaSolicitacaoService,

    @Inject(KEYCLOAK_CLIENT_ID) private clientId: KeyclokClientEnum
  ) {
    this.cooperativa = new CooperativaTO();
    this.mandatoMembro = new MandatoMembro();
    this.mandatoMembroTO = new MandatoMembroTO();
    this.cooperativa.pessoaJuridica = new PessoaJuridicaBasicaTO();
    this.cooperativa.situacaoCooperativa = new Situacao();
    this.municipio = new Municipio();

    this.qtdCooperados = 0;
    this.qtdEmpregados = 0;
  }
  ngAfterViewInit(): void {
    setTimeout(() => {
      const splitButtonElement = this.el.nativeElement.querySelector('.p-splitbutton-menubutton');
      if (splitButtonElement)
        splitButtonElement.id = 'btn-selecione'
    }, 1000)

  }
  ngOnInit(): void {
    this.podeVerResponsaveis = this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional;
    this.txMsgPrecisaRealizarAjustes = 'A Organização Estadual solicitou ajustes na atualização da Cooperativa.';
    this.apiCooperativaService.buscarDiasConcluirSolicitacao().then(res => {
      this.diasConcluirSolicitacaoSuspensao = res;
      this.changeDetectorRef.markForCheck();
    });
    this.cols = [
      { field: 'cnpj', header: 'CNPJ', width: '100%' },
      { field: 'nomeFantasia', header: 'NOME FANTASIA', width: '100%' },
      { field: 'uf', header: 'UF', width: '10%' },
      { field: 'status', header: 'STATUS', width: '20%' }
    ];
    this.carregarTela();
  }

  openModalAnalise(): void {
    this.modalIndicacaoDeFiliacao = true;
  }

  confirmarAprovacao(solicitacao: CooperativaVinculacaoSolicitacaoTO): void {
    if (this.processandoVinculo) {
      return;
    }
    this.confirmationService.confirm({
      header: 'Confirmar aprovação',
      message: 'Tem certeza que deseja aprovar este vínculo?',
      acceptLabel: 'Sim, aprovar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.processandoVinculo = true;
        this.apiVinculacaoSolicitacaoService.aprovar(solicitacao.id).then(() => {
          this.carregarTela();
        }).finally(() => {
          this.processandoVinculo = false;
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

  confirmarReprovacao(solicitacao: CooperativaVinculacaoSolicitacaoTO): void {
    if (this.processandoVinculo) {
      return;
    }
    this.confirmationService.confirm({
      header: 'Confirmar reprovação',
      message: 'Tem certeza que deseja reprovar este vínculo?',
      acceptLabel: 'Sim, reprovar',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.processandoVinculo = true;
        this.apiVinculacaoSolicitacaoService.reprovar(solicitacao.id).then(() => {
          this.carregarTela();
        }).finally(() => {
          this.processandoVinculo = false;
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

  confirmarAprovarTodas(): void {
    if (this.processandoVinculo) {
      return;
    }
    this.confirmationService.confirm({
      header: 'Confirmar aprovação',
      message: 'Tem certeza que deseja aprovar todas as solicitações pendentes?',
      acceptLabel: 'Sim, aprovar todas',
      rejectLabel: 'Cancelar',
      accept: () => {
        this.processandoVinculo = true;
        Promise.all(
          (this.listPendentesVinculo || []).map((item) =>
            this.apiVinculacaoSolicitacaoService.aprovar(item.id)
          )
        ).then(() => {
          this.modalIndicacaoDeFiliacao = false;
          this.carregarTela();
        }).finally(() => {
          this.processandoVinculo = false;
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

  verificarStatusSuspensao(event?: string): void {
    if (event) {
      this.carregarHistoricos();
      this.mostrarMensagemConclusao = false;
      return;
    }
    if (this.cooperativa && this.cooperativa.situacaoCooperativa) {
      const situacaoId = this.cooperativa.situacaoCooperativa.id;

      const possuiAcaoSuspensao = this.cooperativa.cooperativaRegistro?.some(
        (r: CooperativaRegistro) => r.tipoAcao === 'UE_COMUNICA_ORGAOS_SUSPENSAO'
      );
      this.mostrarMensagemConclusao = situacaoId === 2 && !possuiAcaoSuspensao;
    }
  }

  abrirModalConclusao(): void {
    this.modalComunicacao = true;
  }

  aoConcluirComunicacao($event: string): void {
    this.modalComunicacao = false;
    this.verificarStatusSuspensao($event);
  }

  carregarTela() {
    this.apiCadastroRegistroService.obterCooperativaDatamart().then((res) => {
      if (res) {
        this.qtdCooperados = res.totalCooperados;
        this.qtdEmpregados = res.totalEmpregados;
        this.changeDetectorRef.markForCheck();
      }
    });
    this.apiCooperativaSituacaoService.getCooperativaCadastroRegistroApresentacao().then((coop) => {
      this.setCooperativa(coop);
      this.validarVisualizacaoCertificado(coop)

      //this.cooperativaMotivo = this.getMotivoSuspensao(coop);
      this.apiVinculacaoSolicitacaoService.listarPendentesParaAnalise(coop.id).then((response) => {
        this.listPendentesVinculo = response.data;
        this.changeDetectorRef.markForCheck();
      });

    });
  }

  getMotivoSituacaoIrregular(cooperativa: CooperativaTO): string | null {
    if (!cooperativa || !Array.isArray(cooperativa.cooperativaRegistro)) return null;

    const statusIrregulares = ['REGULAR', 'IRREGULAR', 'SUSPENSO', 'CANCELADA'];
    const acoesPermitidas = [
      'UE_APONTA_IRREGULARIDADE',
      'UN_INATIVA_COOPERATIVA',
      'UN_CANCELA_COOPERATIVA',
      'UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA',
      'UN_INATIVA_COOPERATIVA_CANCELADA',
      'UN_ACEITA_SOLICITACAO_CANCELAMENTO_ATIVA',
      'UN_ACEITA_SOLICITACAO_INATIVACAO',
      'UN_ACEITA_SOLICITACAO_CANCELAMENTO',
      'UN_ACEITA_SOLICITACAO_SUSPENSAO',
      'UN_APONTA_IRREGULARIDADE',
      'UN_SUSPENDE_COOPERATIVA',
      'UN_CANCELA_COOPERATIVA_IRREGULAR',
      'UN_APONTA_IRREGULARIDADE',
      'UN_CANCELA_COOPERATIVA_REGULAR'
    ];


    const registrosFiltrados = cooperativa.cooperativaRegistro.filter((registro: CooperativaRegistro) => {
      const tipoAcao = registro?.tipoAcao;
      const situacaoNome = registro?.situacao?.nome;

      const situacaoValida = statusIrregulares.includes(situacaoNome);
      const acaoValida = !tipoAcao || acoesPermitidas.includes(tipoAcao); // Se não tiver tipo, deixa passar

      return situacaoValida && acaoValida;
    });

    if (!registrosFiltrados.length) return null;

    const registroMaisRecente = [...registrosFiltrados]
      .sort((a, b) =>
        new Date(b?.dtAlteracao ?? 0).getTime() - new Date(a?.dtAlteracao ?? 0).getTime()
        || Number(b?.id ?? -Infinity) - Number(a?.id ?? -Infinity)
      )[0];


    const motivo = registroMaisRecente?.cooperativaSolicitacao?.solicitacao?.motivoSolicitacao || null;

    if (
      registroMaisRecente?.situacao?.nome === 'CANCELADA' &&
      (!motivo || motivo.trim() === '')
    ) {
      return ' Cadastro Baixado Na Receita Federal';
    }

    return motivo;
  }




  deveExibirMotivoSituacao(cooperativa: CooperativaTO): boolean {
    if (!cooperativa?.situacaoCooperativa?.id) return false;
    const situacao = cooperativa.situacaoCooperativa.id;
    return situacao !== this.situacaoEnum.REGULAR;
  }



  podeCancelarMudancaoUF(idCoop) {
    this.apiMudancaUFService.podeCancelar(idCoop).then((response) => {
      this.podeCancelarSolicitacao = response.data;
      this.travarCampos.emit(this.podeCancelarSolicitacao);
      this.changeDetectorRef.markForCheck();
    });
  }

  podeSolicitarMudancaUF(idCoop) {
    this.apiMudancaUFService.podeSolicitarMudancaUF(idCoop).then((response) => {
      this.podeSolicitarTrocaUF = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarResponsaveis(cooperativa: CooperativaTO) {
    this.apiUsuarioService.buscarResponsaveis(cooperativa.pessoaJuridica.cnpj).then((res) => {
      this.responsaveis = res.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  carregarItemsBotaoOpcoes() {
    return this.itemsOpcoes = [
      {
        label: 'Tornar irregular', id: 'a-tonar-irregular', icon: 'pi pi-angle-right', command: () => {
          this.modalApontarIrregularidade = true;
        }, visible: this.permissaoCooperativa.permissaoTornarIrregular() && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.REGULAR
      },
      {
        label: 'Tornar regular', id: 'a-tonar-regular', icon: 'pi pi-angle-right', command: () => {
          this.tornarCooperativaRegular();
        },
        visible: this.permissaoCooperativa.permissaoTornarRegular() && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.IRREGULAR
      },
      {
        label: 'Solicitar regularização', id: 'a-solicitar-regularizacao', icon: 'pi pi-angle-right', command: () => {
          this.modalSolicitacaoRegularizacao = true;
        },
        visible: this.permissaoCooperativa.permissaoSolicitarRegularizacao() && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.IRREGULAR_SUSPENSA
      },
      {
        label: 'Regularizar', id: 'a-regularizar', icon: 'pi pi-angle-right', command: () => {
          this.modalRegularizarCooperativa = true;
        },
        visible: this.permissaoCooperativa.permissaoRegularizar() && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.IRREGULAR_SUSPENSA
      },
      {
        label: 'Solicitar cancelamento', id: 'a-solicitar-cancelamento', icon: 'pi pi-angle-right', command: () => {
          this.modalSolicitacaoCancelamento = true;
        }, visible: this.permissaoCooperativa.permissaoSolicitarCancelamento() && this.cooperativa.situacaoCooperativa.id !== SituacaoEnum.CANCELADA && !this.cooperativa.solicitacaoCancelamento
      },
      {
        label: 'Cancelar registro', id: 'a-cancelar-registro', icon: 'pi pi-angle-right', command: () => {
          this.modalCancelarRegistro = true;
        }, visible: this.permissaoCooperativa.permissaoCancelarRegistro() && this.cooperativa.situacaoCooperativa.id !== SituacaoEnum.CANCELADA
      },
      {
        label: 'Reverter cancelamento', id: 'a-reverter-cancelamento', icon: 'pi pi-angle-right', command: () => {
          this.modalRegularizarCooperativa = true;
        }, visible: this.keycloakService.isUsuarioNacional && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.CANCELADA
      },
      {
        label: 'Solicitar suspensão', id: 'a-solicitar-suspensao', icon: 'pi pi-angle-right', command: () => {
          this.modalSolicitacaoSuspensao = true;
        }, visible: this.permissaoCooperativa.permissaoSolicitarSuspensao() && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.IRREGULAR
      },
      {
        label: 'Suspender', id: 'a-suspender', icon: 'pi pi-angle-right', command: () => {
          this.modalSuspenderCooperativa = true;
        }, visible: this.permissaoCooperativa.permissaoSuspender() && this.cooperativa.situacaoCooperativa.id === SituacaoEnum.IRREGULAR
      },
      { label: this.getLabelMudancaUf(), id: 'a-' + this.formatarId(this.getLabelMudancaUf()), icon: 'pi pi-angle-right', command: () => this.abrirMudancaUF(), visible: this.permissaoCooperativa.permissaoSolicitarTransferenciaUF() },
      { label: 'Incluir observações no certificado de regularidade', id: "a-incluir-observacao-certificado", icon: 'pi pi-angle-right', command: () => this.exibeModalObservacaoUe(), visible: this.permissaoCooperativa.permissaoIncluirObservacoesCertificadoRegularidade() },
      { label: 'Documentos', id: "a-documentos", icon: 'pi pi-angle-right', command: () => this.goDocumentos() },
      { separator: true, visible: this.permissaoCooperativa.permissaoHistoricoSituacao() },
      { label: 'Histórico situação', id: "a-historico-situacao", icon: 'pi pi-angle-right', command: () => this.modalHistoricoSituacaoCoop = true, visible: this.permissaoCooperativa.permissaoHistoricoSituacao() }
    ];

  }

  tornarCooperativaRegular() {
    this.confirmationService.confirm({
      key: 'cdTornarRegular',
      header: 'Regularizar cooperativa?',
      message: 'A cooperativa se tornará regular e voltará a ter acesso ao certificado de registro e de regularidade.',
      accept: () => {
        const cp = new Cooperativa();
        cp.id = this.cooperativa.id;

        this.cooperativaSolicitacaoSituacaoTO = new CooperativaSolicitacaoSituacaoTO();
        this.cooperativaSolicitacaoSituacaoTO.idCooperativa = this.cooperativa.id;
        this.cooperativaSolicitacaoSituacaoTO.situacaoCooperativa = NovaSituacaoEnum.REGULAR;

        this.apiCooperativaSituacaoService.regularizarSituacaoCooperativa(this.cooperativaSolicitacaoSituacaoTO).then((response) => {
          this.apiCooperativaSituacaoService.getCooperativaCadastroRegistroApresentacao()
            .then((cooper) => {
              this.setCooperativa(cooper);
              this.changeDetectorRef.markForCheck();
            });
        });
      },
    });
  }

  exibeModalObservacaoUe() {
    this.modalObservacaoUe = true;
    this.mantemObservacoesUe.consultar(this.cooperativa.id);
  }

  abrirMudancaUF() {
    this.modalMudancaUF = true;
  }

  goDocumentos() {
    this.router.navigate(['/registro/documentos'], {
      queryParams: { id_cooperativa: this.cooperativa.id },
      skipLocationChange: false,
    });
  }



  imagemLogo(imagemLogo) {
    this.cooperativaLogo = imagemLogo.data;
    this.dadosLogo.emit(imagemLogo);
  }

  podeInserirLogotipo() {
    return (
      (typeof this.cooperativaLogo === 'undefined' || typeof this.cooperativaLogo.imagemLogo === 'undefined') &&
      this.podeModificar &&
      this.validacaoLogo.podeVerBotaoAlterarLogo()
    );
  }

  formatarId(texto) {
    return texto.replace(/\s+/g, '-').toLowerCase();
  }

  setCooperativa(obj: CooperativaTO) {
    this.cooperativa = obj;
    this.solicitacaoEnviada = this.cooperativa.processoTransferencia
    this.obterSistemaVinculacao();
    this.obterLogotipoCooperativa(this.cooperativa.id);
    this.carregarResponsaveis(this.cooperativa);
    this.carregarStatusAtualizacaoAnuario();
    this.carregarCensoAnuario();
    this.carregarUsuarioSubmissao();
    this.carregarControleAnuario();
    this.carregarControleAtualizacaoCadastral();
    this.verificarStatusSuspensao();
    this.lblgoCadastro = this.permissaoCooperativa.permissaoAtualizarCadastro() ? 'Atualização Cadastral' : 'Visualizar Cadastro';
    this.apiMandatoService.obterPresidente(obj.id).then((resposta) => {
      const presidente = resposta.data.find(
        obj => obj.cargo === 'PRESIDENTE'
      );

      if (presidente) {
        this.presidenteNome = presidente.pessoaFisica.nome;
        this.mandatoMembroTO = presidente;
      }
      this.changeDetectorRef.markForCheck();
    });

    this.periodoDeAtualizacao();
    this.verificaPermissaoLeituraObservacaoUe(this.cooperativa.id);

    if (this.validacaoInformacoesGerais.podeVerBotaoSolicitarMudancaEndereco()) {
      this.podeSolicitarMudancaUF(this.cooperativa.id);
      this.podeAprovarMudancaUF(this.cooperativa.id);
      this.podeCancelarMudancaoUF(this.cooperativa.id);
    }

    this.apiDadosGeraisService.buscarMunicipioPorId(this.cooperativa.pessoaJuridica.endereco.idMunicipio).then((resEnd) => {
      this.municipio = resEnd
      this.changeDetectorRef.markForCheck();
    });

    this.apiCooperativaService.getUltimoHistoricoSolicitacaoInativacao(this.cooperativa.id).then(response => {
      this.ultimoSolicitacaoSuspensao = response.data;
      if (this.ultimoSolicitacaoSuspensao) {
        this.verificaDataParaInativacao(this.ultimoSolicitacaoSuspensao);
      }
      this.changeDetectorRef.markForCheck();
    });

    this.apiCooperativaService.getUltimoHistoricoSolicitacaoCancelamento(this.cooperativa.id).then(response => {
      this.ultimoSolicitacaoCancelamento = response.data;
      this.changeDetectorRef.markForCheck();
    });

    this.apiCooperativaService.getHistoricoSolicitacaoAtivacao(this.cooperativa.id).then(response => {
      this.ultimoSolicitacaoRegularizacao = response.data;
      this.changeDetectorRef.markForCheck();
    });

    this.carregarHistoricos();

    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/' },
      {
        label: 'Cooperativas Registradas',
        routerLink: '/cooperativa/listagem',
      },
      { label: 'Cooperativa' },
    ]);

    this.validarBotoesAcoes();
  }
  obterSistemaVinculacao() {
    this.listSistemaVinculacaoCooperativa = [];
    this.apiSistemaVinculacaoCooperativa.getPorCooperativa(this.cooperativa.id)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      if (response.data) {
        this.listSistemaVinculacaoCooperativa = response.data;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  carregarControleAnuario() {
    this.apiControleAnuarioAnuarioUfService.getControleAnuarioUf(this.cooperativa.pessoaJuridica.ufSigla)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.controleAnuarioUf = response.data;
      this.destacarAnuario = this.controleAnuarioUf.destacarAnuario;
      if (this.keycloakService.isUsuarioCooperativa) {
        this.botaoVisualizarAnuario = this.controleAnuarioUf.cooperativaPodeVisualizar;
        this.periodoAtualizacaoAnuario = this.controleAnuarioUf.visualizarPeriodoAtualizacao;
      }
      this.changeDetectorRef.markForCheck();
    });
  }
  carregarControleAtualizacaoCadastral() {
    this.apiControleAtualizacaoCadastralService.getControleAtualizacaoCadastral(this.cooperativa.pessoaJuridica.ufSigla)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.controleAtualizacaoCadastral = response.data;
      this.destacaAtualizacaoCadastral = this.controleAtualizacaoCadastral.destacarAtualizacaoCadastral;
      if (this.keycloakService.isUsuarioCooperativa) {
        this.botaoVisualizarAtualizacaoCadastral = this.controleAtualizacaoCadastral.permiteCooperativaVisualizar;
        this.periodoAtualizacaoCadastral = this.controleAtualizacaoCadastral.visualizarPeriodoAtualizacao;
      }
      this.changeDetectorRef.markForCheck();
    });
  }
  carregarUsuarioSubmissao() {
    if (this.cooperativa.usuarioSubmissao) {
      this.apiCooperativaService.getObjetoUsuario(this.cooperativa.usuarioSubmissao).then((response) => {
        this.usuarioSubmissao = response.data
        this.changeDetectorRef.markForCheck();
      });
    }
  }
  carregarCensoAnuario() {
    const ano = new Date().getFullYear() - 1;
    this.apiCensoAnuario.obterCensoAnuarioPorAnoAndIdCooperativa(ano, this.cooperativa.id)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.censoAnuarioTO = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  validarBotoesAcoes() {
    this.itemsOpcoes = this.carregarItemsBotaoOpcoes();
  }


  verificaPermissaoLeituraObservacaoUe(idCooperativa) {
    this.apiCooperativaObservacaoService
      .temPermissaoDeLeitura(idCooperativa)
      .then((resultado) => {
        this.temPermissaoLeituraObservacaoUe = resultado.data
        this.changeDetectorRef.markForCheck();
      })
      .catch(() => {
        this.temPermissaoLeituraObservacaoUe = false;
        this.changeDetectorRef.markForCheck();
      });
  }

  obterLogotipoCooperativa(idCooperativa) {
    this.cooperativaLogo.idPessoa = idCooperativa;
    this.cooperativaLogoService.getCooperativaHasLogo(idCooperativa).then((response) => {
      if (response.data) {
        this.cooperativaLogoService.getLogotipoCooperativa(idCooperativa).then((res) => {
          if (res) {
            this.cooperativaLogo = res.data;
            this.changeDetectorRef.markForCheck();
          }
        });
      }
    });
  }

  onAddLogo() {
    this.file.nativeElement.click();
  }

  fileChange(event) {
    const pattern = /image-|bmp|jpe?g|png/;
    const file: File = event.target.files[0];
    if (!file.type.match(pattern)) {
      this.messageService.add({ severity: 'warn', detail: 'Formato de arquivo inválido!', life: 10000 });
      return;
    }
    if (file.size > 3145728) {
      this.messageService.add({ severity: 'warn', detail: 'Tamanho superior ao permitido! <b>Máx. 3MB</b>', life: 10000 });
      return;
    }
    const myReader: FileReader = new FileReader();
    myReader.onloadend = (e) => {
      this.cooperativaLogo.imagemLogo = myReader.result.toString();
      this.salvarLogotipoCooperativa();
    };
    myReader.readAsDataURL(file);
  }

  salvarLogotipoCooperativa() {
    if (this.cooperativaLogo && this.cooperativaLogo.imagemLogo) {
      this.cooperativaLogoService.salvarLogotipoCooperativa(this.cooperativaLogo).then((response) => {
        this.cooperativaLogo = response.data;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  onEditLogo() {
    this.modalLogo = true;
  }

  excluirLogoCooperativa() {
    this.confirmationService.confirm({
      header: 'Remover',
      message: 'Tem certeza que deseja excluir esta imagem?',
      accept: () => {
        if (this.cooperativaLogo && this.cooperativaLogo.imagemLogo) {
          this.cooperativaLogoService.getCooperativaHasLogo(this.cooperativaLogo.idPessoa).then((res) => {
            if (res.data) {
              this.cooperativaLogoService.excluirLogotipoCooperativa(this.cooperativaLogo.idPessoa).then((response) => {
                if (response) {
                  this.cooperativaLogo = new PessoaImagem();
                  this.cooperativaLogo.idPessoa = this.cooperativaId;
                } else {
                  this.messageService.add({ severity: 'warn', detail: 'Não foi possível excluir o arquivo', life: 10000 });
                }
                this.changeDetectorRef.markForCheck();
              });
            } else {
              this.cooperativaLogo = new PessoaImagem();
              this.cooperativaLogo.idPessoa = this.cooperativaId;
              this.changeDetectorRef.markForCheck();
            }
          });
        }
      },
    });
  }

  periodoDeAtualizacao() {
    this.apiCooperativaService.getPeriodoAtualizacao(this.cooperativa.id).then((response) => {
      if (response.data) {
        const retorno = response.data;
        const datePipe = new DatePipe('en-US');
        this.txtSituacaoCooperativa =
          datePipe.transform(retorno.inicioAttAnuario, 'dd/MM/yyyy') +
          ' até ' +
          datePipe.transform(retorno.fimAttAnuario, 'dd/MM/yyyy');
        this.txtDataAutualizacaoCadastral =
          datePipe.transform(retorno.inicioAttCadastral, 'dd/MM/yyyy') +
          ' até ' +
          datePipe.transform(retorno.fimAttCadastral, 'dd/MM/yyyy');
        this.dtUltimaAprovacao = retorno.dataAprovacao;
        this.usuarioAprovacao = retorno.usuarioAprovacao;

        if (response.data.cooperativa.regularidadeCooperativa === this.statusEnum.IRREGULAR) {
          this.txClassSituacaoCooperativa = this.txClassSituacaoEstado = 'text-green-500 font-medium';
          this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa =
            'fas fas fa-exclamation-circle text-green-500';
        }
        // Estado Atualizado ou Desatualizado
        // pi-check-square pi-info-circle
        this.strSituacaoPeriodoAtualizacao = this.cooperativa.status;
        this.carregarStatusCadastroCoop(this.cooperativa);

        // Desatualizada
        if (retorno.situacao === 'DP' || retorno.situacao === 'DAP' || retorno.situacao === 'D') {
          this.txClassSituacaoCooperativa = this.txClassSituacaoEstado = 'ui-g-12 text-orange-500 font-medium';
          this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa =
            'fas fas fa-exclamation-circle text-orange-500';


          if (retorno.situacao === 'DP') {
            this.quadroMsgPrecisaAtualizar = true;
            this.anoInicio = datePipe.transform(retorno.inicioAttCadastral, 'yyyy');
            this.anoReferencia = +this.anoInicio - 1;
            this.dataFim = datePipe.transform(retorno.fimAttCadastral, 'dd/MM/yyyy');
          }

          if (retorno.situacao === 'DAP') {
            this.quadroMsgPrecisaAtualizarAposPeriodo = true;
            this.txMsgPrecisaAtualizarAposPeriodo =
              'A sua Cooperativa está com o registro irregular por não ter atualizado o' +
              ' cadastro dentro da data limite. Atualize seu cadastro para garantir a regularidade e ter acesso aos certificados.';
          }

          if (retorno.situacao === 'D') {
            this.quadroMsgPrecisaAtualizarAposPeriodo = true;
            this.txMsgPrecisaAtualizarAposPeriodo =
              'A sua Cooperativa está com o registro irregular por não ter atualizado o' +
              ' cadastro dentro da data limite. Atualize seu cadastro para garantir a regularidade e ter acesso aos certificados.';
          }

          if (
            retorno.cooperativa.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10 &&
            retorno.cooperativa.progressoManutencaoMicro ===
            ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1
          ) {
            this.quadroMsgPrecisaAtualizar = false;
          }
        }

        // Atualizada

        if (response.data.cooperativa.regularidadeCooperativa === this.statusEnum.REGULAR) {
          if (retorno.situacao === 'AP') {
            // pi-check-circle pi-info-circle
            this.classIconCadastroCoop = 'pi-check-circle text-green-500'
            this.txClassSituacaoCooperativa = this.txClassSituacaoEstado =
              'text-green-500 font-medium';
            this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa =
              'fas fas fa-exclamation-circle text-green-500 ';
            this.quadroMsgPrecisaAtualizar = true;
            this.anoInicio = datePipe.transform(retorno.inicioAttCadastral, 'yyyy');
            this.anoReferencia = +this.anoInicio - 1;
            this.dataFim = datePipe.transform(retorno.fimAttCadastral, 'dd/MM/yyyy');
          } else if (retorno.situacao === 'A') {
            this.txClassSituacaoCooperativa = this.txClassSituacaoEstado = 'text-green-500 font-medium';
            this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa =
              'fas fa-check-circle text-yellow-500 ';
          }
        }
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  carregarStatusCadastroCoop(coop: CooperativaTO) {
    switch (coop.status) {
      case 'Aprovada': {
        this.classIconCadastroCoop = 'pi-check-square';
        this.classColorCadastroCoop = 'text-green-500';
      }
        break;
      case 'Desatualizada': {
        this.classIconCadastroCoop = 'pi-info-circle';
        this.classColorCadastroCoop = 'text-orange-500';
      }
        break;
      case 'Em preenchimento': {
        this.classIconCadastroCoop = 'pi-info-circle';
        this.classColorCadastroCoop = 'text-purple-500';
      }
        break;
      case 'Aguardando ajustes': {
        this.classIconCadastroCoop = 'pi-info-circle';
        this.classColorCadastroCoop = 'text-purple-500';
      }
        break;
      case 'Aguardando análise': {
        this.classIconCadastroCoop = 'pi-info-circle';
        this.classColorCadastroCoop = 'text-cyan-500';
      }
        break;
    }

  }

  carregarStatusAtualizacaoAnuario(): void {
    this.apiCensoAnuarioService.getStatusAtualizacaoAnuario(this.cooperativa.id)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.statusAtualizacaoAnuario = response.data;
      this.statusAnuarioCoop(this.statusAtualizacaoAnuario);
      this.changeDetectorRef.markForCheck();
    });
    this.apiCensoAnuarioService.getCheckAnuarioAtualizado(this.cooperativa.id)
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.anuarioAtualizado = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  statusAnuarioCoop(value: string) {
    switch (value) {
      case 'Atualizado': {
        this.classIconAnuarioCoop = 'pi-check-square';
        this.classColorAnuarioCoop = 'text-green-500';
      }
        break;
      case 'Desatualizado': {
        this.classIconAnuarioCoop = 'pi-info-circle';
        this.classColorAnuarioCoop = 'text-orange-500';
      }
        break;
      case 'Em preenchimento': {
        this.classIconAnuarioCoop = 'pi-info-circle';
        this.classColorAnuarioCoop = 'text-purple-500';
      }
        break;
    }
  }

  validarVisualizacaoCertificado(coop: CooperativaTO) {
    if (coop.pessoaJuridica.ufSigla != null) {
      this.apiCertifidadosService.getCertifiadoPorUf(coop.pessoaJuridica.ufSigla).then((response) => {
        if (response != null) {
          this.podeVisualizarCertificadoRegularidade = response?.inAtiva;
          this.changeDetectorRef.markForCheck();
        }
      })
    }

  }

  visualizarCertificadoRegitro() {
    this.apiCooperativaService.getPdfCertificadoRegitroParam(this.cooperativa.id).then((response) => {
      const byteCharacters = atob(response.data.toString());
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      saveAs(blob, 'certificado.pdf');
    });
  }

  visualizarCertificadoRegularidade() {
    this.apiCooperativaService.getPdfCertificadoRegularidadeParam(this.cooperativa.id).then((response) => {
      const byteCharacters = atob(response.data.toString());
      const byteNumbers = new Array(byteCharacters.length);

      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      saveAs(blob, 'certificadoRegularidade.pdf');
    });
  }

  podeSalvarAnuario() {
    const dataHoje = new Date();
    const dataFinalLimiteAnuario = new Date('07/08/2022');
    return this.keycloakService.isUsuarioCooperativa &&
      ((dataHoje.getTime() > this.dataInicialLimiteAnuario.getTime()) && (dataHoje.getTime() < dataFinalLimiteAnuario.getTime()));
  }


  get isEstadualOuNacional() {
    return this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional;
  }

  podeVerMenuAnuarioSubPerfil(): boolean {
    return (
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    );
  }

  fecharDialogControleAnuario() {
    this.dialogControleAnuario = false;
  }

  verificarPopUpAnuario() {
    if (!this.controleAnuarioUf.mostrarpopup) {
      return this.visualizarAnuario();
    } else {
      this.dialogControleAnuario = true;
    }
  }

  verificaPopUpAtualizacaoCadastral() {
    if (!this.controleAtualizacaoCadastral.mostrarPopup) {
      return this.visualizarCadastro();
    } else {
      this.dialogControleAtualizacaoCadastral = true;
    }
  }

  visualizarAnuario(): void {
    if (this.cooperativa.situacaoCooperativa.id == this.situacaoEnum.CANCELADA
      || this.naoPodePreencherAnuario()
    ) {
      this.formStatusService.stateFormEmitValue(true, ['desabilitar'])
    }

    if (this.keycloakService.isUsuarioCooperativa) {
      if (!this.podeSalvarAnuario()) {
        this.router.navigate(['/cooperativa/anuario-ue']);
      }
    } else {
      this.router.navigate(['/cooperativa/anuario', this.cooperativa.id]);
    }
  }

  naoPodePreencherAtualizacaoCadastral() {
    return (!this.keycloakService.isUsuarioNacional
      && !this.controleAtualizacaoCadastral.permiteEstadualPreencher)
      || (this.keycloakService.isUsuarioCooperativa && !this.controleAtualizacaoCadastral.permiteCooperativaPreencher);
  }

  naoPodePreencherAnuario() {
    return (!this.keycloakService.isUsuarioNacional
      && !this.controleAnuarioUf.habilitarPreenchimentoAnuario)
      || (this.keycloakService.isUsuarioCooperativa && !this.controleAnuarioUf.cooperativaPodePreencher);
  }

  visualizarCadastro() {

    if (this.cooperativa.situacaoCooperativa.id == this.situacaoEnum.CANCELADA
      || this.naoPodePreencherAtualizacaoCadastral()) {
      this.formStatusService.stateFormEmitValue(true, ['desabilitar'])
    }
    if (
      this.cooperativa.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10 ||
      (!this.cooperativa.progressoManutencaoMacro && !this.cooperativa.progressoMacro)
    ) {
      this.router.navigate(['/registro/manutencaoCadastro'], {
        queryParams: { id_cooperativa: this.cooperativa.id, visualizar: false },
        skipLocationChange: false,
      });
    } else {
      this.router.navigate(['/registro/cadastro'], {
        queryParams: { id_cooperativa: this.cooperativa.id },
        skipLocationChange: false,
      });
    }
  }


  podeAprovarMudancaUF(idCoop) {
    this.apiMudancaUFService.podeConsultarAprovacao(idCoop).then((response) => {
      this.podeAprovar = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  getLabelMudancaUf() {
    if (!this.solicitacaoEnviada) {
      return 'Solicitar transferência de UF';
    } else if (this.podeAprovar && this.solicitacaoEnviada) {
      return 'Dar parecer mudança de UF';
    } else if (this.solicitacaoEnviada && !this.podeAprovar) {
      return 'Acompanhar mudança de UF';
    }


  }

  goAtualizarDadosManutencao() {
    this.router.navigate(['/registro/manutencaoCadastro'], {
      queryParams: { id_cooperativa: this.cooperativa.id },
      skipLocationChange: false,
    });
  }

  private verificaDataParaInativacao(cooperativaRegistro: CooperativaRegistro) {
    const today = new Date();
    let date = JSON.parse(JSON.stringify(cooperativaRegistro.dtAlteracao));
    date = new Date(date);
    date.setDate(date.getDate() + this.diasConcluirSolicitacaoSuspensao);

    if (today >= date) {
      this.passou15diasNotificacaoSuspensao = true;
      this.tooltipInativacao = '';
    } else {
      this.passou15diasNotificacaoSuspensao = false;
      if (!cooperativaRegistro.anexoNotificacao) {
        this.tooltipInativacao = 'A inativação da cooperativa ficará disponível a partir do dia ' + formatDate(date, 'dd-MM-yyyy', 'pt_BR');
      }
    }
  }

  abriModalConcluirSolicitacaoSuspensao() {
    this.modalSolicitacaoSuspensao = false;
    this.modalConcluirSolicitacaoSuspensao = true;
  }

  abrirModalSolicitacaoSuspensao() {
    this.modalConcluirSolicitacaoSuspensao = false;
    this.modalSolicitacaoSuspensao = true;
  }

  cancelarSolicitacaoDeCancelamentoEnviada() {
    this.apiSolicitacao.cancelaSolicitacaoDeCancelamento(this.cooperativa.id).then((response) => {
      this.carregarTela();
    });
  }

  cancelarSolicitacaoDeInativacaoEnviada() {
    let solicitaSuspencao = new CooperativaSolicitacaoSuspensaoTO();
    solicitaSuspencao.idCooperativa = this.cooperativa.id;
    solicitaSuspencao.situacaoCooperativa = NovaSituacaoEnum.SUSPENSA;
    solicitaSuspencao.tipoAcaoSolicitacao = "OE_CANCELA_SOLICITACAO";
    this.apiSolicitacao.suspensao(solicitaSuspencao).then((response) => {
      if (response) {
        this.carregarTela();
      }
    });
  }

  /** cancela uma solicitação de ativação */
  cancelarSolicitacaoAtivacao() {
    let cooperativaAtivacvao = new CooperativaSolicitacaoSituacaoTO();
    cooperativaAtivacvao.idCooperativa = this.cooperativa.id;
    cooperativaAtivacvao.situacaoCooperativa = NovaSituacaoEnum.REGULAR;


    this.apiCooperativaSituacaoService.cancelarSolicitacaoAtivacaoSituacaoCooperativa(cooperativaAtivacvao).then((coop) => {
      this.carregarTela();
    });
  }

  concluirApontamentoIrregularidade() {
    this.modalApontarIrregularidade = false;
    this.carregarTela()
  }

  carregarHistoricos() {
    this.apiCooperativaSituacaoService.consultaHistoricoCooperativaRegistroListagem(this.cooperativa.id).then((hist) => {
      if (hist.data) {
        this.historicoCooperativaRegistroListagemTO = hist.data;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  verificaControleAnuario() {
    // Verificar se o controle geral esta habilitado,
    return true
    // // Para perfil cooperativa , so habilitar visualizacao do botao se existir parametrizacao por UF
    // if(this.keycloakService.isUsuarioCooperativa &&
    //   this.controleAnuarioUf.cooperativaPodeVisualizar &&
    //   this.controleAnuario.preencherAnuario.includes('E') /**/
    // )
  }
}
