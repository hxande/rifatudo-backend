import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, Input, OnInit } from '@angular/core';
import { Usuario } from '@gerencia-usuario-api/models/Usuario';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';

@Component({
    selector: 'app-listagem-responsavel-component',
    templateUrl: './listagem-responsavel.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./listagem-responsavel.component.css'],
  })
  export class ListagemResponsavelComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cnpj: string;
    responsaveis: Usuario[];

    constructor(private apiUsuarioService: ApiUsuarioService){

    }

    ngOnInit(): void {
        this.apiUsuarioService.buscarResponsaveis(this.cnpj).then((res) => {
            this.responsaveis = res.data;
            this.changeDetectorRef.markForCheck();
          });
    }

  }