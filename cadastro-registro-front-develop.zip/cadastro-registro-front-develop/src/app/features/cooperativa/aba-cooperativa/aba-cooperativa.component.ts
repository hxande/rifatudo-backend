import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, Input, OnInit, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-aba-cooperativa',
  templateUrl: './aba-cooperativa.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./aba-cooperativa.component.css']
})
export class AbaCooperativaComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() tituloTabela = 'Cooperativas Registradas';

  tabViewIndex = 0;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.fragment
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(fragment => {
        if (fragment === 'filiais') {
          this.tabViewIndex = 1;
        }
        this.changeDetectorRef.markForCheck();
      });
  }

}
