import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { Solicitacao } from '@cadastro-registro-api/models/Solicitacao';
import { CooperativaTO } from 'src/app/api/models/CooperativaTO';
import { CooperativaRegistro } from 'src/app/api/models/CooperativaRegistro';
import { CooperativaSolicitacao } from 'src/app/api/models/CooperativaSolicitacao';
import { CooperativaSolicitacaoSituacaoTO } from 'src/app/api/models/CooperativaSolicitacaoSituacaoTO';
import { NovaSituacaoEnum } from 'src/app/api/models/SituacaoCooperativaEnum';
import { ApiCooperativaSituacaoService } from 'src/app/api/services/api-cooperativa-situacao.service';
import { ApiSolicitacaoService } from 'src/app/api/services/api-solicitacao.service';

@Component({
    selector: 'app-apontar-irregularidade-component',
    templateUrl: './apontar-irregularidade.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./apontar-irregularidade.component.css'],
})
export class ApontarIrregularidadeComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();

    cooperativaRegistro = new CooperativaRegistro();
    cooperativaSolicitacaoSituacaoTO = new CooperativaSolicitacaoSituacaoTO();

    motivo: Solicitacao;
    listaMotivo: Solicitacao[];
    justificativa: string;
    salvando = false;

    constructor(private apiSolicitacaoService: ApiSolicitacaoService,
        private apiSituacaoCooperativa: ApiCooperativaSituacaoService,
    ) { }

    ngOnInit(): void {
        this.carregarListaMotivo();
    }

    carregarListaMotivo() {
        this.apiSolicitacaoService.getListaSolicitacoesAtivas().then((response) => {
            if (response) {
                this.listaMotivo = response.data.filter((elem) => {
                    return elem.tipoSolicitacao.descricaoTipoSolicitacao.toLocaleUpperCase() === 'SUSPENSÃO';
                });
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    cancelar() {
        this.onFechar.emit();
    }

    confirmar() {
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        const cooperativaRegistro = this.cooperativaRegistro;
        cooperativaRegistro.cooperativa = this.cooperativa;
        cooperativaRegistro.justificativaIrregular = this.justificativa;
        cooperativaRegistro.cooperativaSolicitacao = new CooperativaSolicitacao();
        cooperativaRegistro.cooperativaSolicitacao.cooperativa = this.cooperativa;

        if (!!this.motivo) {
            cooperativaRegistro.cooperativaSolicitacao.solicitacao = this.motivo;
        }

        this.cooperativaSolicitacaoSituacaoTO.idCooperativa = this.cooperativa.id;
        this.cooperativaSolicitacaoSituacaoTO.justificativa = this.justificativa;
        this.cooperativaSolicitacaoSituacaoTO.idSolicitacao = this.motivo.id;
        this.cooperativaSolicitacaoSituacaoTO.situacaoCooperativa = NovaSituacaoEnum.IRREGULAR;

        this.apiSituacaoCooperativa.alteraSituacaoCooperativa(this.cooperativaSolicitacaoSituacaoTO).then((response) => {
            this.onConcluir.emit();
        }).finally(() => {
            this.salvando = false;
            this.changeDetectorRef.markForCheck();
        });

    }
}