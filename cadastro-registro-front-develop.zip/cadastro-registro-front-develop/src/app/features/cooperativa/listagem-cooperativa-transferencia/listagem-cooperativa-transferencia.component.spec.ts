import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemCooperativaTransferenciaComponent } from './listagem-cooperativa-transferencia.component';

describe('ListagemCooperativaTransferenciaComponent', () => {
  let component: ListagemCooperativaTransferenciaComponent;
  let fixture: ComponentFixture<ListagemCooperativaTransferenciaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemCooperativaTransferenciaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemCooperativaTransferenciaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
