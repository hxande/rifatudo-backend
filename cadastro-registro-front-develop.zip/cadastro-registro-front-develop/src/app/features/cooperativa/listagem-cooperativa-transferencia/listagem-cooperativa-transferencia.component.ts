import { ChangeDetectionStrategy, Component, OnInit, ViewChild } from '@angular/core';
import { ListagemCooperaitvaComponent } from '../listagem-cooperativa/listagem-cooperativa.component';

@Component({
  selector: 'app-listagem-cooperativa-transferencia',
  templateUrl: './listagem-cooperativa-transferencia.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-cooperativa-transferencia.component.css']
})
export class ListagemCooperativaTransferenciaComponent implements OnInit {

  constructor() {}

  @ViewChild('listagemCoop')
  listagemCoop: ListagemCooperaitvaComponent;

  ngOnInit(){}

}
