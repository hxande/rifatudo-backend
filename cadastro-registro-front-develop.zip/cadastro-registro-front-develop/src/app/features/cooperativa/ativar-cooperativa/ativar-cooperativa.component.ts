import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { CooperativaTO } from 'src/app/api/models/CooperativaTO';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { CooperativaSolicitacaoSituacaoTO } from 'src/app/api/models/CooperativaSolicitacaoSituacaoTO';
import { NovaSituacaoEnum } from 'src/app/api/models/SituacaoCooperativaEnum';
import { ApiCooperativaSituacaoService } from 'src/app/api/services/api-cooperativa-situacao.service';


@Component({
    selector: 'app-ativar-cooperativa-component',
    templateUrl: './ativar-cooperativa.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./ativar-cooperativa.component.css'],
})
export class AtivarCooperativaComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();

    justificativa: string;
    aceitaSolicitacao: boolean;
    salvando = false;

    constructor(
        private apiCooperativaService: ApiCooperativaSituacaoService
    ) {

    }

    ngOnInit(): void {

    }


    cancelar() {
        this.onFechar.emit();
    }

    confirmar() {
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        let cooperativaAtivacvao = new CooperativaSolicitacaoSituacaoTO();

        cooperativaAtivacvao.idCooperativa = this.cooperativa.id;
        cooperativaAtivacvao.justificativa = this.justificativa;
        cooperativaAtivacvao.situacaoCooperativa = NovaSituacaoEnum.REGULAR;

        this.apiCooperativaService.alteraSituacaoCooperativa(cooperativaAtivacvao).then((response) => {
            this.onConcluir.emit();
        }).finally(() => {
            this.salvando = false;
            this.changeDetectorRef.markForCheck();
        });
    }

    confirmarSolicitacao() {
        if (this.salvando) {
            return;
        }
        this.salvando = true;

        let cooperativaAtivacvao = new CooperativaSolicitacaoSituacaoTO();

        cooperativaAtivacvao.idCooperativa = this.cooperativa.id;
        cooperativaAtivacvao.justificativa = this.justificativa;
        cooperativaAtivacvao.situacaoCooperativa = NovaSituacaoEnum.REGULAR;

        if (this.aceitaSolicitacao) {
            this.apiCooperativaService.aceitarSolicitacaoAtivacaoSituacaoCooperativa(cooperativaAtivacvao).then(() => {
                this.onConcluir.emit();
            }).finally(() => {
                this.salvando = false;
                this.changeDetectorRef.markForCheck();
            });
        } else {
            this.apiCooperativaService.recusarSolicitacaoAtivacaoSituacaoCooperativa(cooperativaAtivacvao).then(() => {
                this.onConcluir.emit();
            }).finally(() => {
                this.salvando = false;
                this.changeDetectorRef.markForCheck();
            });
        }
    }
}