import { Component, Input, Output, EventEmitter, OnInit, ChangeDetectorRef, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiComunicacaoOrgaosService } from 'src/app/api/services/api-comunicacao-orgaos.service';
import { Repositorio } from '@upload-api/models/Repositorio';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-modal-comunicacao-orgaos',
  templateUrl: './modal-comunicacao-orgaos.component.html',
  styleUrls: ['./modal-comunicacao-orgaos.component.css']
})
export class ModalComunicacaoOrgaosComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() idCooperativa: number;
  @Input() nomeCooperativa: string;
  @Input() situacaoCooperativa: string = 'SUSPENSA';
  @Input() visible = false;
  @Output() onVisibleChange = new EventEmitter<boolean>();
  @Output() onConcluir = new EventEmitter<string>();

  formulario: FormGroup;
  arquivoSelecionado: File | null = null;
  carregandoUpload = false;
  carregandoSubmissao = false;
  fileIdUpload: string | null = null;
  erroArquivo: string | null = null;
  showModeloModal = false;

  constructor(
    private fb: FormBuilder,
    private apiComunicacaoOrgaosService: ApiComunicacaoOrgaosService,
    private messageService: MessageService
  ) {
    this.formulario = this.fb.group({
      arquivo: ['', Validators.required]
    });
  }

  ngOnInit(): void {
  }

  fechar(): void {
    this.visible = false;
    this.onVisibleChange.emit(false);
    this.resetForm();
  }

  resetForm(): void {
    this.formulario.reset();
    this.arquivoSelecionado = null;
    this.fileIdUpload = null;
    this.erroArquivo = null;
    this.carregandoUpload = false;
    this.carregandoSubmissao = false;
  }

  onArquivoSelecionado(chaveRepositorio: string): void {
    if (chaveRepositorio) {
      this.fileIdUpload = chaveRepositorio;
      this.erroArquivo = null;
      this.messageService.add({
        severity: 'success',
        summary: 'Sucesso',
        detail: 'Arquivo enviado com sucesso!',
        life: 3000
      });
    }
  }

  onArquivoRemovido(repositorio: Repositorio): void {
    if (repositorio == null) {
      this.fileIdUpload = null;
      this.erroArquivo = null;
    }
  }

  concluirProcedimento(): void {
    if (!this.fileIdUpload) {
      this.erroArquivo = 'Arquivo não foi carregado. Tente fazer upload novamente.';
      return;
    }

    this.carregandoSubmissao = true;

    this.apiComunicacaoOrgaosService.comunicarOrgaos({
      idCooperativa: this.idCooperativa,
      anexoProvaOrgaos: this.fileIdUpload,
      tipoAcaoSolicitacao: 'OE_COMUNICA_ORGAOS_SUSPENSAO',
      situacaoCooperativa: this.situacaoCooperativa
    }).then(
      (resposta) => {
        this.carregandoSubmissao = false;
        this.messageService.add({
          severity: 'success',
          summary: 'Sucesso',
          detail: 'Órgãos competentes comunicados com sucesso!',
          life: 5000
        });
        setTimeout(() => {
          this.onConcluir.emit(resposta.messages[0].message);
          this.fechar();
          this.changeDetectorRef.markForCheck();
        }, 1500);
        this.changeDetectorRef.markForCheck();
      },
      (erro) => {
        this.carregandoSubmissao = false;
        let mensagemErro = 'Erro ao comunicar órgãos. Tente novamente.';

        if (erro.error && erro.error.message) {
          mensagemErro = erro.error.message;
        }

        this.erroArquivo = mensagemErro;
        this.messageService.add({
          severity: 'error',
          summary: 'Erro',
          detail: mensagemErro,
          life: 5000
        });
        console.error('Erro na conclusão:', erro);
        this.changeDetectorRef.markForCheck();
      }
    );
  }

  abrirModeloModal(): void {
    this.showModeloModal = true;
  }

  fecharModeloModal(): void {
    this.showModeloModal = false;
  }

  podeConcluir(): boolean {
    return this.fileIdUpload !== null && !this.carregandoSubmissao;
  }
}

