import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, inject } from "@angular/core";
import { Solicitacao } from "@cadastro-registro-api/models/Solicitacao";
import { ApiSolicitacaoService } from "@cadastro-registro-api/services/api-solicitacao.service";
import { Repositorio } from "@upload-api/models/Repositorio";
import { CooperativaTO } from "src/app/api/models/CooperativaTO";
import { CooperativaRegistro } from "src/app/api/models/CooperativaRegistro";
import { CooperativaRegistro as CR } from "@cadastro-registro-api/models/CooperativaRegistro";
import { CooperativaSolicitacao } from "src/app/api/models/CooperativaSolicitacao";
import { CooperativaSolicitacao as CS} from "@cadastro-registro-api/models/CooperativaSolicitacao";
import { ApiCooperativaSituacaoService } from "src/app/api/services/api-cooperativa-situacao.service";
import { Cooperativa } from "@cadastro-registro-api/models/Cooperativa";

@Component({
    selector: 'app-suspender-cooperativa-component',
    templateUrl: './suspender-cooperativa.component.html',
    styleUrls: ['./suspender-cooperativa.component.css'],
})
export class SuspenderCooperativaComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() cooperativa: CooperativaTO;
    @Output() onFechar = new EventEmitter<void>();
    @Output() onConcluir = new EventEmitter<void>();


    cooperativaRegistro = new CooperativaRegistro();
    justificativa: string;
    motivo: Solicitacao;
    complementoMotivo: string;
    listaMotivo: Solicitacao[];
    salvando = false;

    constructor(
        private apiSolicitacaoService: ApiSolicitacaoService,
        private apiCooperativaSituacaoService: ApiCooperativaSituacaoService
    ) {

    }

    ngOnInit(): void {
        this.carregarListaMotivo();
    }

    carregarListaMotivo() {
        this.apiSolicitacaoService.getListaSolicitacoesAtivas()
        .then((response) => {
            if (response) {
                this.listaMotivo = response.data.filter((elem) => {
                    return elem.tipoSolicitacao.descricaoTipoSolicitacao.toLocaleUpperCase() === 'SUSPENSÃO';
                });
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    cancelar() {
        this.onFechar.emit();
    }

    confirmar() {
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        let cooperativa = new Cooperativa();
        cooperativa.id = this.cooperativa.id;
        cooperativa.justificativaInativada = this.justificativa;
        let cooperativaRegistro = new CR();
        cooperativaRegistro.justificativaInativada = this.justificativa;
        cooperativaRegistro.cooperativa = cooperativa;
        cooperativaRegistro.cooperativaSolicitacao = new CS();
        cooperativaRegistro.cooperativaSolicitacao.anexo = this.cooperativaRegistro.anexo;
        if (!!this.motivo) {
            cooperativaRegistro.cooperativaSolicitacao.solicitacao = this.motivo;
            cooperativaRegistro.cooperativaSolicitacao.outroMotivoDesc = this.complementoMotivo;
        }
        this.apiCooperativaSituacaoService.putSuspenderCooperativa(cooperativaRegistro)
        .then((response) => {
            this.onConcluir.emit();
        })
        .finally(() => {
            this.salvando = false;
            this.changeDetectorRef.markForCheck();
        });
    }

    verificarRepositorioVazio(repositorio: Repositorio) {
        if (repositorio == null) {
            this.cooperativaRegistro.anexo = null;
        }
    }

}
