import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ProxyUrl } from '@auth/proxy-url/proxy-url.service';
import { UsuarioView } from '@gerencia-usuario-api/models/UsuarioView.model';
import { Uf } from '@localizacao-api/models/Uf';
import { NomeApiEnum } from '@auth/proxy-url/NomeApiEnum';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-exportacao-dados',
  templateUrl: 'exportacao-dados.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['exportacao-dados.component.scss']
})
export class ExportacaoDadosComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  urlSoucoop = '/cadastro-registro-leitura-api/public/api/v1/cooperativa-formulario/';

  isUsuarioNacional;
  url = '';
  ufs: Uf[] = [];
  ufsSelecionadas;
  ufSelecionada;
  informacoes: { label: string; value: string;} [] = [];
  usuariosList: UsuarioView[] = [];

  permiteSelecionarUfs = false;

  dado = {} as {
    informacao: string;
  };
  

  token: string;

  constructor(public proxyUrl: ProxyUrl,
              private ufService: ApiUFService,
              private ramoApi: ApiRamoService,
              private keycloakService: KeycloakService,
              private breadCrumbPrimeNGService: BreadcrumbService,
              private messageService: MessageService) {
          this.breadCrumbPrimeNGService.setItems([
            { label: 'Início', routerLink: 'inicio' },
            { label: 'Exportação de dados', routerLink: '/exportacao-dados' }
          ]);
  }

  ngOnInit(): void {
    this.getUfs();
    this.limparUrl();
    this.inicializarTipoInformacao();

    this.isUsuarioNacional = this.keycloakService.isUsuarioNacional;
  }

  inicializarTipoInformacao() {
    this.informacoes = [{label: 'Dados gerais',value: 'dados-gerais'},
                        {label: 'Governança',value: 'governanca'},
                        {label: 'Segmentação e filiais',value: 'negocio'},
                        {label: 'Contatos',value: 'contatos'},
                        {label: 'Anuário',value: 'anuario'}
                      ];
    
  }



  podeVisualizarPagina() {
    return this.keycloakService.isUsuarioEstadualGestor || this.keycloakService.isUsuarioNacional && this.keycloakService.isUsuarioNacionalAdmin;
  }

  onChange() {
    var params = [];

    

    const tokenParam = this.token ? `token=${this.token}` : '';
    if(tokenParam){
      params.push(tokenParam);
    }

    const ufsParam = this.ufsSelecionadas ? `ufs=${this.ufsSelecionadas.join()}` : '';
    if(ufsParam){
      params.push(ufsParam);
    }
  
    const queryParam = params ? params.join('&') : '';
                      
    this.url = this.proxyUrl.obterUrl(this.urlSoucoop , NomeApiEnum.cadastro_registro_leitura_api) ;
    this.url += (this.dado.informacao ? this.dado.informacao : '');
    this.url += `${queryParam ? ('?' + queryParam) : ''}`;
  }



  limparUrl() {
    this.ufsSelecionadas = null;
    this.token = '';
    this.dado.informacao = '';
    this.url = this.proxyUrl.obterUrl(this.urlSoucoop, NomeApiEnum.cadastro_registro_leitura_api);
  }

  getUfs() {
    this.ufSelecionada = new Uf();
    this.ufService.obterUfs().then((response) => {
      this.ufs = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  copiarURL(inputElement) {
    inputElement.select();
    document.execCommand('copy');
    inputElement.setSelectionRange(0, 0);
    this.messageService.add({severity:'success', summary:'Mensagem', detail:'URL copiada'});
  }

}
