import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '@shared/shared.module';
import { TableModule } from 'primeng/table';
import { ExportacaoDadosComponent} from './exportacao-dados.component';
import {InputTextModule} from 'primeng/inputtext';
import {InputTextareaModule} from 'primeng/inputtextarea';


import { ExportacaoDadosRoutingModule } from './exportacao-dados-routing.module';


@NgModule({
    declarations: [
      ExportacaoDadosComponent,
    ],
    imports: [
      CommonModule,
      SharedModule,
      TableModule,
      ExportacaoDadosRoutingModule,
      InputTextModule,
      InputTextareaModule

    ]
  })
export class ExportacaoDadosModule { }
