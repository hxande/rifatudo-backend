import { Router } from '@angular/router';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { AppComponent } from 'src/app/app.component';
import { PowerBICooperativasRegistradasEmbededToken } from '@relatorio-api/models/PowerBICooperativasRegistradasEmbededToken';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { RelatorioGraficoService } from '@relatorio-api/services/relatorio-grafico.service';
import { ValidacaoCooperativa } from '../../registro/validacao/validacao-cooperativa.service';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { IReportEmbedConfiguration, models } from 'powerbi-client';
@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./inicio.component.scss']
})
export class InicioComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  loading = false;
  powerBICooperativasRegistradasEmbededToken: PowerBICooperativasRegistradasEmbededToken;
  paineis: PowerBICooperativasRegistradasEmbededToken[];


  embedConfig: IReportEmbedConfiguration;
  reportClass = 'powerbi-container';


  constructor(
    private router: Router,
    public app: AppComponent,
    public keycloakService: KeycloakService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private relatorioGraficoService: RelatorioGraficoService,
    public validacaoCooperativa: ValidacaoCooperativa
  ) {
    this.breadCrumbPrimeNGService.setItems([]);
    this.powerBICooperativasRegistradasEmbededToken = null;
  }

  ngOnInit() {
    if (this.keycloakService.isUsuarioCooperativa) {
      this.redirecionaCooperativa();
    } else {
      this.carregaPainelBI();
    }
  }

  private redirecionaCooperativa() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop.numeroRegistroOCB) {
        return this.router.navigate(['/cooperativa/detalhes'], {
          queryParams: {id_cooperativa: coop.id},
          skipLocationChange: false
        });
      }

      if (coop.progressoMicro === ProgressoMicroEnum.PRE_CADASTRO_0_0) {
        return this.router.navigate(['/registro/requerimento']);
      }

      if (coop.progressoMacro === ProgressoMacroEnum.CADASTRO_INICIADO_1) {
        return this.router.navigateByUrl('/registro/cadastro');
      }

      if (coop.progressoMacro === ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2 &&
        coop.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2) {
        return this.router.navigateByUrl('/registro/cadastro');
      }

      if (coop.progressoMacro === ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3 &&
        coop.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2) {
        return this.router.navigateByUrl('/registro/processo-cooperativa');
      }

      // Cooperativa registrada
      if (coop.situacaoCooperativa.id !== SituacaoEnum.NAOREGISTRADA) {
        // manutenção
        if (coop.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10) {
          if (coop.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1) {
            return this.router.navigate(['/cooperativa/detalhes'], {
              queryParams: {id_cooperativa: coop.id},
              skipLocationChange: false
            });
          } else if (coop.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2) {
            return this.router.navigate(['/registro/manutencaoCadastro'], {
              queryParams: {id_cooperativa: coop.id},
              skipLocationChange: false
            });
          }
        }
        return this.router.navigate(['/cooperativa/detalhes'], {
          queryParams: {id_cooperativa: coop.id},
          skipLocationChange: false
        });
      }
      return this.router.navigateByUrl('/registro/processo-cooperativa');
    }).then(() => {
      this.changeDetectorRef.markForCheck();
    });
  }

  private carregaPainelBI() {
    this.relatorioGraficoService.obterPaineisPorServico('SOUCOOP_PAINEL_INICIAL', null).then(response => {
      if (Array.isArray(response)) {
        this.paineis = response;
      } else {
        this.paineis = [];
      }

      if (this.paineis.length > 0) {
        this.carregarPainel(this.paineis[0]);
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  private carregarPainel(painel: PowerBICooperativasRegistradasEmbededToken) {
    if (painel) {
      this.relatorioGraficoService.carregarPainel(painel.id, this.paineis.length > 1).then(response => {
        if (response) {
          this.powerBICooperativasRegistradasEmbededToken = response;
        }
         this.setEmbedConfig();
         this.changeDetectorRef.markForCheck();
      });
    } else {
      this.powerBICooperativasRegistradasEmbededToken = null;
    }
  }
setEmbedConfig() {
    this.embedConfig = {
      type: 'report',
      id: this.powerBICooperativasRegistradasEmbededToken?.embededReportId,
      embedUrl: this.powerBICooperativasRegistradasEmbededToken?.embededUrl,
      accessToken: this.powerBICooperativasRegistradasEmbededToken?.token,
      tokenType: models.TokenType.Embed,
      settings: {
        panes: {
          filters: { visible: false },
          pageNavigation: { visible: true },
        },
      },
    };
  }

  handlePowerBIEvent(event: unknown): void {
  }

}
