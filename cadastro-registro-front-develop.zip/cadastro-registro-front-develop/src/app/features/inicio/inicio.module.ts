import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InicioComponent } from './inicio/inicio.component';
import { InicioRoutingModule } from './inicio-routing.module';
import { SharedModule } from '../../shared/shared.module';
import { PowerBIEmbedModule } from 'powerbi-client-angular';

@NgModule({
  declarations: [InicioComponent],
  imports: [CommonModule, SharedModule, InicioRoutingModule, PowerBIEmbedModule],
})
export class InicioModule {}
