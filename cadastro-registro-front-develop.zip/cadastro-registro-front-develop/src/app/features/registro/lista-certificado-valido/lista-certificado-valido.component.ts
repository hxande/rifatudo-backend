import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild, Input, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IPage } from '@utils/interfaces/IPage';
import { Router } from '@angular/router';
import { saveAs } from 'file-saver';
import { UtilityService } from '@utils/utility/utility.service';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { Usuario } from '@gerencia-usuario-api/models/Usuario';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service'
import { FormBuilder, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-lista-certificado-valido',
  templateUrl: './lista-certificado-valido.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./lista-certificado-valido.component.css']
})
export class ListaCertificadoValidoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  filters = {
    cnpj: '',
    nomeFantasia: '',
    registro: '',
    uf: '',
  };

  ufs = [
    { label: 'Todos', value: null },
    { label: 'AC', value: 'AC' },
    { label: 'AL', value: 'AL' },
    { label: 'AM', value: 'AM' },
    { label: 'AP', value: 'AP' },
    { label: 'BA', value: 'BA' },
    { label: 'CE', value: 'CE' },
    { label: 'DF', value: 'DF' },
    { label: 'ES', value: 'ES' },
    { label: 'GO', value: 'GO' },
    { label: 'MA', value: 'MA' },
    { label: 'MG', value: 'MG' },
    { label: 'MS', value: 'MS' },
    { label: 'MT', value: 'MT' },
    { label: 'PA', value: 'PA' },
    { label: 'PB', value: 'PB' },
    { label: 'PE', value: 'PE' },
    { label: 'PI', value: 'PI' },
    { label: 'PR', value: 'PR' },
    { label: 'RJ', value: 'RJ' },
    { label: 'RN', value: 'RN' },
    { label: 'RO', value: 'RO' },
    { label: 'RR', value: 'RR' },
    { label: 'RS', value: 'RS' },
    { label: 'SC', value: 'SC' },
    { label: 'SE', value: 'SE' },
    { label: 'SP', value: 'SP' },
    { label: 'TO', value: 'TO' },
  ];
  fases: SelectItem[];
  response: IPage<CooperativaBasica>;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  responsaveis: Usuario[];
  modalVisivel: boolean;
  @Input() arquivado = false;
  filtronomeFantasia = '';
  filtroprocesso = '';
  filtroramo: Ramo;
  filtrodataAberturaProcesso = '';
  filtrodataUltimaSubmissao = '';
  filtronomeUsuario = '';
  filtrotelefoneUsuario = '';
  filtroTexto= '';
  filtroProgressoMacro = '';
  filtroSelecionado = 'pj.cnpj';
  naoVisualizadas = false;
  dlgInfoPendencia = false;
  buscaFiltro = false;
  nomesFantasiaBusca = [];
  cols: { field: string, header: string, width: string, sortable: boolean }[];
  @ViewChild('dt') dt: Table;
  constructor(
    private cooperativaService: ApiCooperativaService,
    private utilityService: UtilityService,
    private router: Router,
    private breadCrumbPrimeNGService:BreadcrumbService
  ) {
    this.fases = [
      { label: '0 - Pré Cadastro', value: ProgressoMacroEnum.PRE_CADASTRO_0.toString() },
      { label: '1 - Cadastro e envio de documentos', value: ProgressoMacroEnum.CADASTRO_INICIADO_1.toString() },
      { label: '2 - Validação dos documentos', value: ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2.toString() },
      { label: '3 - Análise de conformidade legal', value: ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3.toString() },
      { label: '4 - Visita técnica', value: ProgressoMacroEnum.VISITA_TECNICA_4.toString() },
      { label: '5 - Parecer', value: ProgressoMacroEnum.PARECER_5.toString() },
      { label: '6 - Emissão do certificado de registro', value: ProgressoMacroEnum.EMISSAO_CERTIFICADO_6.toString() },
    ];

  }



  ngOnInit() {
    this.cols = [
      { field: 'pj.cnpj', header: 'CNPJ', width: '100px', sortable: true },
      { field: 'pj.nomeFantasia', header: 'Nome Fantasia', width: '200px', sortable: true },
      { field: 'situacaoCooperativa.id', header: 'Situação de registro', width: '100px', sortable: true },
      { field: 'numeroRegistroOCB', header: 'Dados do registro', width: '200px', sortable: true },
      { field: 'pj.ufSigla', header: 'UF', width: '140px', sortable: true },
      { field: 'CP.SQ_COOPERATIVA', header: 'Certificados', width: '200px', sortable: true },
    ];
    this.atualizaBreadCrumbPrimeNG();
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay);
  }

  getCooperativas(pagina = 0,sortField = 'pj.cnpj', sortOrder = 1): Promise<IPage<CooperativaBasica>> {
    sortField = sortField || 'pj.cnpj';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.cooperativaService.getCooperativasPaginadoRegistradasPublic(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField:string, sortOrder:string) {
    const indexPagina = (!pagina || pagina == 'NaN') ? 0 : pagina;
    const options = {
      params: new HttpParams()
        .set('page', indexPagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
        .set('cnpj', this.filters.cnpj)
        .set('uf', this.filters.uf)
        .set('nomeFantasia', this.filters.nomeFantasia)
        .set('processo', this.filters.registro)
    };
    return options;

  }

  async loadLazy(event: TableLazyLoadEvent) {
    if(event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.response = undefined;
    if(event.sortField == 'cnpj'){event.sortField = 'pj.cnpj'}
    this.getCooperativas(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .then(resp => {
      this.response = resp;
      this.changeDetectorRef.markForCheck();
    });
  }

  async filtra(event: Event) {
    // filtra é chamado tanto pelo clique do botão "Pesquisar" (MouseEvent) quanto
    // poderia futuramente vir de um TableLazyLoadEvent; loadLazy já trata os campos como opcionais.
    await this.loadLazy(event as unknown as TableLazyLoadEvent);
    this.buscaFiltro = true;
  }

  exibirResponsavel(usuario: Usuario[]) {
    this.modalVisivel = true;
    this.responsaveis = usuario;
  }

  onRowSelect(event) {
    this.cooperativaService.marcarComoVisualizada(event.data.id);
    this.router.navigate(['/registro/processo'], { queryParams: { id_cooperativa: event.data.id }, skipLocationChange: false });
  }

  abrirDlgPendencia() {
    this.dlgInfoPendencia = true;
  }

  atualizaBreadCrumbPrimeNG() {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/' },
      { label: 'Processo de Registro', routerLink: '/registro/listagem' },
      { label: 'Cooperativa' },
    ]);
  }


  selectMask(event: Event) {
    setTimeout(() => {
      (event.target as HTMLInputElement).select()
      this.changeDetectorRef.markForCheck();
    }, 100);
  }

  visualizarCertificadoRegitro(idCooperativa: number) {
    this.cooperativaService.getPdfCertificadoRegitroParamPublic(idCooperativa)
    .then(response => {
      const byteCharacters = atob(response.data.toString());
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      saveAs(blob, 'certificado.pdf');
      this.changeDetectorRef.markForCheck();
    });
  }

  visualizarCertificadoRegularidade(idCooperativa: number) {
    this.cooperativaService.getPdfCertificadoRegularidadeParamPublic(idCooperativa)
    .then(response => {
      const byteCharacters = atob(response.data.toString());
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      saveAs(blob, 'certificado_regularidade.pdf');
      this.changeDetectorRef.markForCheck();
    });
  }
  procurarNomesFantasia(event) {
    if (this.filters.nomeFantasia != null) {
      this.cooperativaService.buscarCooperativasAutoComplete(event.query)
      .then((res) => {
        this.nomesFantasiaBusca = res;
        this.changeDetectorRef.markForCheck();
      });
    }
  }
}
