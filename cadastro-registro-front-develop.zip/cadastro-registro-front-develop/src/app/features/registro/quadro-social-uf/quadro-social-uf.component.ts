import { Component, OnInit, Input, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { QuadroSocialAnuarioTO } from 'src/app/api/models/QuadroSocialAnuarioTO';
import { AnuarioQuadroSocialService } from 'src/app/api/services/api-anuario-quadro-social.service';

@Component({
    selector: 'app-quadro-social-uf',
    templateUrl: './quadro-social-uf.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./quadro-social-uf.component.css'],
})
export class QuadroSocialUfComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() ano;
    @Input() idCooperativa;
    @Input() uf;

    quadroSocialAnuario :QuadroSocialAnuarioTO;

    constructor(
        private apiAnuarioQuadroSocialService: AnuarioQuadroSocialService,
    ){}

    ngOnInit(): void {
        this.apiAnuarioQuadroSocialService.obterQuadroSocialAnuario(this.idCooperativa, this.ano)
        .subscribe(response => {
            this.quadroSocialAnuario = response.data;
            this.changeDetectorRef.markForCheck();
        });
    }

}
