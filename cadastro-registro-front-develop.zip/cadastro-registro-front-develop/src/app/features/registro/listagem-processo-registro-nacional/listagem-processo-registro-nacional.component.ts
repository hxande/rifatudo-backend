import { ChangeDetectionStrategy, Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { ValidacaoCooperativa } from '../validacao/validacao-cooperativa.service';
import { Uf } from '@localizacao-api/models/Uf';
import { UtilityService } from '@utils/utility/utility.service';
import { CacheService } from '@utils/cache/cache.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';
import { ListagemProcessoRegistroComponentGeneric } from '../../cooperativa/listagem-processo-registro-component-generic';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { CooperativaLeituraService } from 'src/app/api/services/api-cooperativa-leitura.service';

@Component({
  selector: 'app-listagem-processo-registro-nacional',
  templateUrl: './listagem-processo-registro-nacional.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-processo-registro-nacional.component.css']
})
export class ListagemProcessoRegistroNacionalComponent extends ListagemProcessoRegistroComponentGeneric implements OnInit {

  @Input() arquivado = false;
  @Input() preCadastro = false;
  @Input() emAndamento = false;
  @ViewChild('dt') dt: Table;
  filtroUf: Uf;
  filtroprocesso = '';
  filtroDataAtualizacao = '';
  listaUfs: Uf[];

  constructor(
    public cooperativaService: ApiCooperativaService,
    public usuarioService: ApiUsuarioService,
    public cooperativaLeituraService: CooperativaLeituraService,
    public utilityService: UtilityService,
    public cacheService: CacheService,
    public router: Router,
    private breadcrumbService: BreadcrumbService,
    public messageService: MessageService,
    public ramoApi: ApiRamoService,
    private dadosGeraisService: ApiManutencaoDadosGeraisService,
    public validacaoCooperativa: ValidacaoCooperativa
  ) {
    super(cooperativaService, usuarioService, cooperativaLeituraService, ramoApi, utilityService, router, messageService);
    this.breadcrumbService.setItems([
      { label: 'Início', routerLink: 'inicio' },
      { label: 'Processo de Registro', routerLink: '/registro/listagem' }
    ]);
  }

  ngOnInit() {
    if(this.emAndamento){
      this.fases = this.fases.filter(fase => fase.value !== '0');
    }
    this.cols = [
      { field: 'pessoaJuridica.ufSigla', header: 'UF', width: '5%', sortable: true, visible: true },
      { field: 'id', header: 'Nº do processo', width: '89px', sortable: true, visible: true },
      { field: 'pessoaJuridica.ramo.nome', header: 'Ramo', width: '100px', sortable: true, visible: true },
      { field: 'pessoaJuridica.nomeFantasia', header: 'Cooperativa', width: '180px', sortable: true, visible: true },
      { field: 'progressoMacro' , header: 'Fase do processo', width: '100px', sortable: true, visible: !this.preCadastro},
      { field: 'dataUltimaAnaliseUE' , header: 'Data de aprovação dos dados', width: '107px', sortable: true, visible: !this.preCadastro},
      { field: 'dataPrazoRegistro', header: 'Prazo para conclusão do processo', width: '107px', sortable: true, visible: !this.preCadastro },
      { field: 'nomeUsuario', header: 'Responsável', width: '120px', sortable: false, visible: !this.preCadastro },
    ];
    if(this.dt){
      this.loadLazy(this.dt.createLazyLoadMetadata());
    }
  }

  getTable(): Table {
    return this.dt;
  }

  onRowSelect(idCooperativa) {
    this.cooperativaService.marcarComoVisualizada(idCooperativa);
    this.router.navigate(['/registro/processo'], { queryParams: { id_cooperativa: idCooperativa }, skipLocationChange: false });
  }

  loadSpecificOptions(options: {params: HttpParams}): void {
    options.params = this.utilityService.carregaParamsString(this.filtroUf ? this.filtroUf.sigla : '', options.params, 'uf');
    options.params = this.utilityService.carregaParamsString(this.arquivado, options.params, 'arquivado');
    options.params = this.utilityService.carregaParamsString(this.filtroDataAtualizacao, options.params, 'dataAtualizacao');
    if(this.preCadastro){
      options.params = this.utilityService.carregaParamsString('0', options.params, 'progressosMacros');
    }
    if(this.emAndamento){
      if(!this.filtroFases || this.filtroFases.length == 0){
        const fases = this.fases.map((fase) => fase.value);
        this.getFiltroFases(fases,options);
      }
    }
  }

  buscarUF() {
    if(this.listaUfs === undefined){
      this.dadosGeraisService.buscarUfs().then((res) => {
        if (res && res.content != null) {
          this.listaUfs = res.content;
          this.changeDetectorRef.markForCheck();
        }
      });
    }
  }

  exportarTabelaNacional(){
    
    if(!this.preCadastro) {
      this.exportarRelatorio('PROCESSO_REGISTRO_SIMPLIFICADO');
    } else {
      this.exportarRelatorio('PROCESSO_REGISTRO_PRE_CADASTRO');
    }
    
  }
}
