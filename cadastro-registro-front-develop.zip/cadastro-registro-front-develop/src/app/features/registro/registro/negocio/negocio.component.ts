import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, EventEmitter, inject, Input, OnInit, Output, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { NgForm } from '@angular/forms';

import { Table } from 'primeng/table';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { OptionDropDown } from './OptionDropdown';
import { saveAs } from 'file-saver';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { SelectItem } from 'primeng/api';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { Cnae } from '@cadastro-registro-api/models/Cnae';
import { FilialComponentComponent } from '@shared/filial/filial-component.component';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { ApiNegocioService } from '@cadastro-registro-api/services/api-negocio.service';
import { ApiProdutoservicoService } from '@cadastro-registro-api/services/api-produtoservico.service';
import { ApiCnaeService } from '@cadastro-registro-api/services/api-cnae.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { GeralService } from '@auth/geral.service';
import { ApiPessoaDocumentoService } from '@documentacao-api/services/api-pessoa-documento.service';
import { Negocio } from '@cadastro-registro-api/models/Negocio';
import { PessoaDocumento } from '@documentacao-api/models/PessoaDocumento';
import { ApiFilialService } from '@cadastro-registro-api/services/api-filial.services';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ValidacaoNegocioRegistro } from '@shared/registro/negocio/validacao/validacao-negocio-registro.service';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { AjusteDadosComponent } from '@shared/validacaoDados/ajuste-dados-component';
import { ValidacaoMarcacaoUtil } from '@shared/validacaoDados/validacao/validacao-marcacao.util';
import { MessageService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { CheckboxChangeEvent } from 'primeng/checkbox';
import { MultiSelectChangeEvent } from 'primeng/multiselect';
import { Faturamento } from '@cadastro-registro-api/models/Faturamento';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { HttpParams } from '@angular/common/http';
import { PessoaSegmProdServ } from '@cadastro-registro-api/models/PessoaSegmProdServ';
import { PessoaCnae } from '@cadastro-registro-api/models/PessoaCnae';
import { DocumentoFilialComponent } from '../../documento-filial/documento-filial.component';
import { Messages } from '@shared/mensagens/Messages';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { ControleAbasRegistroEnum } from '@cadastro-registro-api/models/ControleAbasRegistroEnum';
import { ApiControleAbasRegistroService } from '@cadastro-registro-api/services/api-controle-abas-registro.service';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { ApiNegocioSegmentacaoService } from 'src/app/api/services/api-negocio-segmentacao.service';
import { NegocioTO } from 'src/app/api/models/NegocioTO';
import { Ramo } from 'src/app/api/models/Ramo';
import { ApiRamoService } from 'src/app/api/services/api-ramo.service';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
    selector: 'app-negocio-component',
    templateUrl: './negocio.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./negocio.component.css'],
})
export class NegocioComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @ViewChild('negocioForm') negocioForm: NgForm;
    @ViewChild('filialComponent') filialComponent: FilialComponentComponent;
    @ViewChild('documentoFilialComponent') documentoFilialComponent: DocumentoFilialComponent;
    @ViewChild('dtFilial') dtFilial: Table;
    @ViewChildren(AjusteDadosComponent) ajusteDadosComponentes: QueryList<AjusteDadosComponent>;
    @Output() evtSalvarDados = new EventEmitter<boolean>();
    @Output() evtFimSalvarDados = new EventEmitter<number>();
    @Output() evtErroSalvar = new EventEmitter<boolean>();
    @Input() exibirErros = true;
    @Input() cooperativaManutencao: CooperativaManutencao;

    nomePessoaJuridica: string;
    optionsDropdownRamo: Ramo[];
    optionsDrobdownSegmento: Segmento[];
    optionsDrobdownProduto: Produtoservico[];
    optionsListaUfs: SelectItem[];

    listaProdutosServicos: Produtoservico[][];
    listaPessoaSegmProdServ: PessoaSegmProdServ[];
    listaCooperativasFiliacao: PessoaJuridicaBasicaTO[];
    cooperativa: Cooperativa;
    aprovacoes: CooperativaPendencia[] = [];
    tabelaCooperativas: PessoaJuridicaBasicaTO[];

    optionsDrobdownCnaes: Cnae[];
    optionsDropDownSubclasses: Cnae[];
    optionsDropDownSubclassesCnaePrincipal: Cnae[];
    optionDropDown: OptionDropDown<Cnae>;
    listaProdutosAux: string[];
    faturamentoLabel = 'Faturamento anual';
    campoDescricaoComplementar: boolean;
    exportacoesDireta = false;
    negocio: Negocio;
    houveAlteracaoForm = false;
    salvando = false;
    textoFaturamento: string;
    modalAdicionarFilial = false;
    modalAnexarDocumento = false;
    mensagensValidacao = Array<Messages>();
    pessoaDocumento: PessoaDocumento[];
    totalElementos = 0;
    pendenciasEditadas: CooperativaPendencia[] = [];
    nrLinhas = 10;
    mapPendencias: Record<string, boolean> = {};
    filtrocnpj = '';
    filtronomeFantasia = '';
    filtroUf: '';
    filtroTelefone = '';
    filtroEmail = '';
    nrLinhasTabela = 10;
    private debouncer;
    private delay = 500;
    response: IServiceResponse<IPage<PessoaJuridicaBasicaTO>>;
    cols: { field: string; header: string; width: string }[];
    cooperativaTemp: Cooperativa;

    ramo: Ramo;

    display: boolean = false;

    constructor(
        private segmentoApi: ApiSegmentoService,
        private negocioApi: ApiNegocioService,
        private apiProdutoservicoService: ApiProdutoservicoService,
        private cnaeApi: ApiCnaeService,
        private dadosGeraisService: ApiDadosGeraisService,
        private apiCadastroRegistroService: ApiCadastroRegistroService,
        public keycloakService: KeycloakService,
        private geralService: GeralService,
        private messageService: MessageService,
        private pessoaDocumentoApi: ApiPessoaDocumentoService,
        private uploadApi: ApiFileUploadService,
        private filialApi: ApiFilialService,
        private apiValidacaoDadosService: ApiValidacaoDadosService,
        private utilityService: UtilityService,
        private apiPj: ApiPessoaJuridicaService,
        public validacaoNegocio: ValidacaoNegocioRegistro,
        public validacaoDados: ValidacaoDados,
        private apiControleAbas: ApiControleAbasRegistroService,
        private negocioSegmentacaoApi: ApiNegocioSegmentacaoService,
        private ramoApi: ApiRamoService
    ) {}

    podeModificarOsCampos = false;

    verificarLiberacaoCampos(id: number) {
        this.apiCadastroRegistroService.podePreencherCadastroRegistroBasico(id).then((res) => {
            if (res != null && res.data != null) {
                this.desativaEventoForm();
                this.podeModificarOsCampos = res.data;
                this.changeDetectorRef.markForCheck();
            }
        });
    }

    ngOnInit() {
        this.listaProdutosServicos = new Array<Produtoservico[]>();
        this.optionsDrobdownSegmento = new Array<Segmento>();
        this.negocio = new Negocio();
        this.negocio.cnaePrimario = new PessoaCnae();
        // this.negocio.cnaeSecundarios = new Array<PessoaCnae>();
        this.negocio.segmentos = new Array<Segmento>();
        this.negocio.faturamentoAtual = new Faturamento();
        this.negocio.produtos = new Array<Produtoservico>();
        // this.listaCnaeSecundarioAux = new Array<PessoaCnae>();
        this.listaProdutosAux = new Array<string>();
        this.listaPessoaSegmProdServ = new Array<PessoaSegmProdServ>();
        this.optionsDropDownSubclasses = [];
        this.optionDropDown = new OptionDropDown();
        this.optionsDropDownSubclassesCnaePrincipal = [];
        this.cols = [
            { field: 'pessoaJuridicaFiliada.cnpj', header: 'CNPJ', width: '170px' },
            { field: 'pessoaJuridicaFiliada.nomeFantasia', header: 'Nome fantasia', width: '280px' },
            { field: 'pessoaJuridicaFiliada.ufSigla', header: 'UF', width: '155px' },
            { field: 'pessoaJuridicaFiliada.telefoneGeral', header: 'Telefone', width: '146px' },
            { field: 'pessoaJuridicaFiliada.emailGeral', header: 'E-mail', width: '120px' },
            { field: 'ataDaAssembleia', header: 'Ata da Assembleia', width: '140px' },
            { field: 'acoes', header: 'Ações', width: '120px' },
        ];

        this.carregarTela();
    }

    public desativaEventoForm() {
        this.houveAlteracaoForm = false;
    }

    public getAlteracaoForm() {
        let alteracao = false;
        for (const ap of this.aprovacoes) {
            if (ap.houveAlteracao) {
                alteracao = true;
            }
        }
        return this.houveAlteracaoForm || alteracao;
    }

    salvarNegocio(abaDestino: number) {
        if (this.salvando) {
            return;
        }
        let pendenciaPreenchumentoTela = false;
        this.aprovacoes.forEach((elem) => {
            if (elem.visualizado === true) {
                pendenciaPreenchumentoTela = true;
            }
        });

        if (pendenciaPreenchumentoTela) {
            this.messageService.add({
                severity: 'warn',
                detail: 'Preencha corretamente as orientações para ajuste!',
                life: 10000,
            });
            return;
        }

        if (this.pendenciasEditadas.length > 0) {
            this.apiValidacaoDadosService.editarAgrupamento(this.pendenciasEditadas).then((res) => {
                this.pendenciasEditadas = res.data;
            });
        }

        this.houveAlteracaoForm = true;
        this.geralService.salvarPendencia(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);

        this.negocio.cooperativa = this.cooperativa;
        this.negocio.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ;
        this.negocio.filiadas = this.listaCooperativasFiliacao;

        const aba = {
          id: null,
          cooperativa: { id: Number(this.cooperativa.id) },
          dataEnvio: null,
          aba: ControleAbasRegistroEnum.SEGMENTACAO_FILIAIS,
          enviada: true
        };

        let negocioTO = new NegocioTO();

        this.apiControleAbas.save(aba)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe();
        this.salvando = true;
        this.negocioSegmentacaoApi.salvarNegocio(negocioTO.tranformaNegocioEmTO(this.negocio), this.cooperativa.id)
            .then(() => {
                this.houveAlteracaoForm = false;

                ValidacaoMarcacaoUtil.notificarSalvoComPendencias(this.messageService, this.ajusteDadosComponentes);

                for (const ap of this.aprovacoes) {
                    if (ap.houveAlteracao) {
                        ap.houveAlteracao = false;
                    }
                }

                this.carregarTela();
                window.scroll(0, 0);

                this.evtFimSalvarDados.emit(abaDestino);
            })
            .catch(() => {
                this.evtErroSalvar.emit(true);
            })
            .finally(() => {
                this.salvando = false;
                this.changeDetectorRef.markForCheck();
            });
    }

    carregarTela() {
        this.carregarCooperativa();
        this.carregarUfs();
        this.buscarCnaes();
        this.desativaEventoForm();
    }

    carregarUfs() {
      this.dadosGeraisService.buscarUfs().then((res) => {
          if (res && res.content != null) {
              this.optionsListaUfs = res.content.map(uf => ({ label: uf.sigla, value: uf.sigla }));
              this.changeDetectorRef.markForCheck();
          }
      });
    }

    atualizarMensagensTela() {
        // @@ SOUC-367: Não trás os erros de validação quando existem campos não preenchidos
      this.apiCadastroRegistroService.validarNegocio(this.cooperativaTemp.id).then((res) => {
          if (res && res.data) {
              this.mensagensValidacao = [];

              const dadosValidacao = res.data;

              if (!dadosValidacao.validado) {
                  this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
                      summary:
                          msg.message.indexOf('<b>') === -1
                              ? ''
                              : msg.message.substring(msg.message.indexOf('<b>') + 3, msg.message.indexOf('</b>')),
                      detail:
                          msg.message.indexOf('<b>') === -1
                              ? msg.message
                              : msg.message.substring(msg.message.indexOf('</b>') + 4),
                  }));
              }
              this.changeDetectorRef.markForCheck();
          }
      });
    }

    atualizarProdutos(produto: Produtoservico, pessoaSegmProdServ: PessoaSegmProdServ, check: CheckboxChangeEvent) {
      this.houveAlteracaoForm = true;

      var produtoId = check?.checked?.find(element => element == produto.id);

      if (check != null && check.checked.length > 0 && produtoId != null) {
          if(produtoId != null){
              if (produto.segmento.id === pessoaSegmProdServ.segmento.id) {
                  this.criaPessoaComProdServ(produto);
              }
          }
      } else {
          this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter(item =>
            !(item.segmento.id === produto.segmento.id &&
              item.produtoServico &&
              item.produtoServico.id === produto.id)
          );
      }
    }

    temDescricaoComplementar(produto: Produtoservico) {
        if (this.listaPessoaSegmProdServ) {
            for (const lista of this.listaPessoaSegmProdServ) {
                if (lista.produtoServico) {
                    if (lista.produtoServico.id === produto.id) {
                        if (lista.produtoServico.descricaoComplementar) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    carregarCooperativa() {
        this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
            if (coop) {
                this.cooperativaTemp = coop;
                this.verificarLiberacaoCampos(coop.id);
                this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla).then((pj) => {
                    this.nomePessoaJuridica = pj.data.nomeFantasia;
                    this.changeDetectorRef.markForCheck();
                });
                this.dadosGeraisService.getCooperativa(coop.id).then((res) => {
                    if (res == null || res.data.id == null) {
                        this.desativaEventoForm();
                        this.cooperativaNaoEncontrada();
                    } else {
                        this.cooperativa = res.data;

                        // atualiza ramo caso altere na aba Dados Gerais
                        if (coop.pessoaJuridica && coop.pessoaJuridica.ramo) {
                            this.cooperativa.pessoaJuridica.ramo = coop.pessoaJuridica.ramo;
                        }
                        this.carregaNegocio(coop);
                        this.atualizaPendenciaChave(coop);
                        this.changeDetectorRef.markForCheck();
                    }
                });
            }
        });
    }

    private carregaNegocio(coop: Cooperativa) {
        this.negocioApi.getNegocio(coop.id).then((res) => {
            if (res == null) {
                this.cooperativaNaoEncontrada();
            } else {
                this.negocio = res.data;

                if (!this.negocio.cnaePrimario) {
                    this.negocio.cnaePrimario = new PessoaCnae();
                }

                if (this.negocio.faturamentoAtual.faturamentoExportacao) {
                    this.exportacoesDireta = true;
                }

                if (
                    this.negocio.listaPessoaSegmProdServ.length !== 0 ||
                    !this.negocio.cnaePrimario ||
                    // this.negocio.cnaeSecundarios.length !== 0 ||
                    !this.negocio.faturamento
                ) {
                    this.atualizarMensagensTela();
                    this.evtSalvarDados.emit(false);
                }

                this.listaProdutosAux = new Array<string>();

                if (this.negocio.produtos) {
                    this.negocio.produtos.forEach((prod) => {
                        this.listaProdutosAux = [...this.listaProdutosAux, '' + prod.id];
                    });
                }

                if (this.negocio.listaPessoaSegmProdServ) {
                    this.listaPessoaSegmProdServ = Object.assign([], this.negocio.listaPessoaSegmProdServ);
                }

                if (this.negocio.filiadas) {
                    this.listaCooperativasFiliacao = Object.assign([], this.negocio.filiadas);

                    this.buscarFiliaisPorMatriz(this.cooperativa.pessoaJuridica.cnpj, '0');
                }

                this.buscarSegmentos();
                this.buscarRamo();

                if (this.negocio.segmentos && this.cooperativa.pessoaJuridica.ramo) {
                    this.negocio.segmentos = this.negocio.segmentos.filter((segmento) => segmento.ativo);
                    this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter((pessoaSeg) => this.negocio.segmentos.some((segmento) => segmento.id === pessoaSeg.segmento.id));
                    this.negocio.segmentos.forEach((segmento) => {
                        if (!this.listaProdutosServicos[segmento.id + 'string']) {
                            this.apiProdutoservicoService
                                .buscaPorRamoSegmento(segmento.id, this.cooperativa.pessoaJuridica.ramo.id)
                                .then((ramoSeg) => {
                                    if (ramoSeg && ramoSeg.data) {
                                        this.listaProdutosServicos[segmento.id + 'string'] = ramoSeg.data;
                                        this.changeDetectorRef.markForCheck();
                                    }
                                });
                        }
                    });
                }
                this.changeDetectorRef.markForCheck();
            }
        });
    }

    downloadArquivo(event) {
        const file = event;
        this.uploadApi
            .getArquivoDownload(event.chaveArquivo)
            .then((data) => {
                const thefile = new Blob([data], { type: event.mimeType });

                const url = window.URL.createObjectURL(thefile);

                const link = document.createElement('a');
                link.href = url;
                link.download = event.nome;
                link.dispatchEvent(new MouseEvent('click'));
            })
            .catch((err) => {
                this.messageService.add({ severity: 'error', detail: 'Ocorreu um erro.', life: 10000 });
            });
    }

    buscarCnaes() {
        this.cnaeApi.lista().then((response) => {
            if (response && response.data) {
                this.desativaEventoForm();
                this.optionsDrobdownCnaes = response.data;
                this.changeDetectorRef.markForCheck();
            }
        });
    }

    buscarSegmentos() {
        if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
            this.segmentoApi.buscaPorRamo(this.cooperativa.pessoaJuridica.ramo.id).then((response) => {
                if (response && response.data) {
                    this.desativaEventoForm();
                    this.optionsDrobdownSegmento = response.data;
                    console.log(this.optionsDrobdownSegmento);
                    this.faturamentoLabel = this.negocio.ramo.nome === 'CRÉDITO' ? 'Total de ativos' : 'Faturamento';
                    if (this.negocio.ramo.nome === 'CRÉDITO') {
                        this.textoFaturamento = 'Insira o total de ativos da Cooperativa';
                    } else {
                        this.textoFaturamento =
                            'Insira neste campo os ingressos e receitas brutas da cooperativa, decorrente da venda de ' +
                            'mercadorias ou da prestação de serviços. Se a cooperativa realizou alguma exportação no ano, ' +
                            'insira separadamente no campo Valor Exportações Diretas. No caso de cooperativas do ramo ' +
                            'crédito, inserir o total de ativos da cooperativa apurado ao final do último exercício.';
                    }
                    this.changeDetectorRef.markForCheck();
                }
            });
        }

        if (!this.cooperativa.pessoaJuridica.ramo || !this.cooperativa.pessoaJuridica.ramo.id) {
            this.optionsDrobdownSegmento = [];
            this.optionsDrobdownProduto = [];
            this.negocio.segmentos = [];
            this.listaProdutosServicos = [];
            this.listaProdutosAux = [];
        }
    }

    validandoPreenchimentoCnpjFilial(cnpjFilial: string) {
        if (this.cooperativa && this.cooperativa.pessoaJuridica) {
            const cnpjFormatado = this.cooperativa.pessoaJuridica.cnpj.replace(
                /^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/,
                '$1.$2.$3/$4-$5'
            );
            const prefixoCnpj = cnpjFormatado.substring(0, cnpjFormatado.length - 7);

            if (
                !cnpjFilial ||
                cnpjFilial.length < 10 ||
                cnpjFilial.substring(0, cnpjFilial.length - 7) !== prefixoCnpj
            ) {
                cnpjFilial = prefixoCnpj;
            }
        }

        return cnpjFilial;
    }

    adicionarFiliacao() {
        this.modalAdicionarFilial = true;

        if (!this.negocio.filiadas) {
            this.negocio.filiadas = [];
            this.listaCooperativasFiliacao = [];
        }
    }

    editarFilial(filial: PessoaJuridicaBasicaTO) {
        if (this.listaCooperativasFiliacao.length > 0) {
            this.listaCooperativasFiliacao.forEach((filialLista) => {
                if (filialLista.cnpj === filial.cnpj) {
                    this.filialComponent.editarFilial(filialLista);
                }
            });
        }
        this.modalAdicionarFilial = true;
    }

    anexarDocumento(filial: PessoaJuridicaBasicaTO) {
        this.documentoFilialComponent.anexarDocumento(filial);
        this.modalAnexarDocumento = true;
    }

    AdicionarFilial(pessoaJuridicaTO: PessoaJuridicaBasicaTO) {
        let filialExiste = false;

        this.listaCooperativasFiliacao.forEach((filial) => {
            if (filial.cnpj === pessoaJuridicaTO.cnpj) {
                this.copiarFilialTOParaObjeto(filial, pessoaJuridicaTO);
                filialExiste = true;
            }
        });

        this.tabelaCooperativas.forEach((filial) => {
            if (filial.cnpj === pessoaJuridicaTO.cnpj) {
                this.copiarFilialTOParaObjeto(filial, pessoaJuridicaTO);
                filialExiste = true;
            }
        });

        if (!filialExiste) {
          this.listaCooperativasFiliacao = [...this.listaCooperativasFiliacao, pessoaJuridicaTO];
          this.tabelaCooperativas = [...this.tabelaCooperativas, pessoaJuridicaTO];
        }

        this.tabelaCooperativas.forEach((elemento) => {
            this.listaCooperativasFiliacao.forEach((elementoLista) => {
                if (elemento.cnpj === elementoLista.cnpj) {
                    elemento.endereco = elementoLista.endereco;
                }
            });
        });
    }

    private copiarFilialTOParaObjeto(filial, pessoaJuridicaTO) {
        filial.id = pessoaJuridicaTO.id;
        filial.cnpj = pessoaJuridicaTO.cnpj;
        filial.cnpjValidado = true;
        filial.email = pessoaJuridicaTO.email;
        filial.nomeFantasia = pessoaJuridicaTO.nomeFantasia;
        filial.ramo = pessoaJuridicaTO.ramo;
        filial.razaoSocial = pessoaJuridicaTO.razaoSocial;
        filial.telefone = pessoaJuridicaTO.telefone;
        filial.ufSigla = pessoaJuridicaTO.ufSigla;
        filial.tipoPessoa = pessoaJuridicaTO.tipoPessoa;
        filial.endereco = pessoaJuridicaTO.endereco;

        filial.arquivos = pessoaJuridicaTO.arquivos;
    }

    AdicionarDocumentoFilial(pessoaJuridicaTO: PessoaJuridicaBasicaTO) {
        this.listaCooperativasFiliacao.forEach((filial) => {
            if (filial.id === pessoaJuridicaTO.id) {
                filial.arquivos = pessoaJuridicaTO.arquivos;
            }
        });

        this.tabelaCooperativas.forEach((filial) => {
            this.pessoaDocumentoApi.getPorIdPessoaFilial(filial.id).then((pesDoc) => {
                if (pesDoc.data) {
                    filial.arquivos = [];
                    const repositorios: string[] = [];
                    pesDoc.data.forEach((obj) => {
                        obj.pessoaDocumentoAnexo.forEach((_obj) => {
                            repositorios.push(_obj.uploadAnexo);
                        });
                    });

                    this.uploadApi.consultaArquivosNaoPaginado(repositorios).then((responseDocumento) => {
                        filial.arquivos = responseDocumento.content;
                    });
                }
            });
        });
    }

    CancelarModalFilial() {
        this.modalAdicionarFilial = false;
    }

    CancelarModalDocumentoFilial() {
        this.modalAnexarDocumento = false;
    }

    removerFilial(filial: PessoaJuridicaBasicaTO) {
      this.listaCooperativasFiliacao = this.listaCooperativasFiliacao.filter(c => c !== filial);
      this.tabelaCooperativas = this.tabelaCooperativas.filter(c => c !== filial);
    }


    possuiSegmento(segmento: Segmento) {
        let indice = -1;
        this.listaPessoaSegmProdServ.forEach((pessoaSeg) => {
            if (segmento.id === pessoaSeg.segmento.id) {
                indice = this.listaPessoaSegmProdServ.indexOf(pessoaSeg);
            }
        });
        return indice;
    }

    atualizaLiberacaoCampo(pendencia) {
        if (!this.pendenciasEditadas.includes(pendencia)) {
            this.pendenciasEditadas = [...this.pendenciasEditadas, pendencia];
        }
        this.mapPendencias = { ...this.mapPendencias, [pendencia.bloco]: false };
        this.houveAlteracaoForm = true;
        this.changeDetectorRef.markForCheck();
    }

    private atualizaPendenciaChave(coop: Cooperativa) {
        this.apiValidacaoDadosService.obterUltimasPendenciasChave(coop.id).then((res) => {
            this.mapPendencias = res.data as unknown as Record<string, boolean>;
            this.changeDetectorRef.markForCheck();
        });
    }

    atualizarListagemProdutos(event: MultiSelectChangeEvent) {
        const segmento = event.itemValue;
        const selecionados = event.value;
        const segContem = selecionados.filter((seg) => seg.id === segmento.id)[0];
        if (segmento) {
            if (!segContem) {
                this.listaProdutosServicos[segmento.id + 'string'] = null;
                this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter(
                  pessoaSeg => pessoaSeg.segmento.id !== segmento.id
                );

                if (selecionados && selecionados.length === 0) {
                    this.listaPessoaSegmProdServ = [];
                }
            } else {
                // insere
                this.criaPessoaComSeg(segmento);

                if (!this.listaProdutosServicos[segmento.id + 'string']) {
                    this.apiProdutoservicoService
                        .buscaPorRamoSegmento(segmento.id, this.cooperativa.pessoaJuridica.ramo.id)
                        .then((res) => {
                            if (res && res.data) {
                                this.listaProdutosServicos[segmento.id + 'string'] = res.data;
                                this.changeDetectorRef.markForCheck();
                            }
                        });
                }
            }
        }
    }

    exportarNegocio() {
        this.negocioApi
            .exportarRelatorioSegmento(this.cooperativaTemp.id)
            .then((response) => {
                const blob = new Blob([response], {
                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                });
                saveAs(blob, 'Negocio_Segmentos.xlsx');
            })
            .catch((error) => {
                if (error.status && error.status === 404) {
                    this.messageService.add({
                        severity: 'warn',
                        detail: 'Nenhum registro de negócio encontrado',
                        life: 100000,
                    });
                } else {
                    this.messageService.add({
                        severity: 'error',
                        detail: 'Problemas ao gerar relatório',
                        life: 100000,
                    });
                }
            });
    }

    criaPessoaComProdServ(prod: Produtoservico) {
        const pessoaSegProdServ = new PessoaSegmProdServ();
        pessoaSegProdServ.pessoaJuridica = this.cooperativa.pessoaJuridica;
        pessoaSegProdServ.segmento = prod.segmento;
        pessoaSegProdServ.produtoServico = prod;
        this.listaPessoaSegmProdServ = [...this.listaPessoaSegmProdServ, pessoaSegProdServ];
    }

    criaPessoaComSeg(seg: Segmento) {
        const possuiSeg = this.possuiSegmento(seg);
        if (possuiSeg !== -1) {
          this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter((_, i) => i !== possuiSeg);
        }

        const pessoaSegProdServ = new PessoaSegmProdServ();
        pessoaSegProdServ.pessoaJuridica = this.cooperativa.pessoaJuridica;
        pessoaSegProdServ.segmento = seg;

        this.listaPessoaSegmProdServ = [...this.listaPessoaSegmProdServ, pessoaSegProdServ];
    }

    cooperativaNaoEncontrada() {
        this.messageService.add({ severity: 'error', detail: 'Cooperativa não encontrada! [SAINDO]', life: 10000 });
    }

    listaVazia(id: number) {
        if (this.listaProdutosServicos[id + 'string']) {
            return this.listaProdutosServicos[id + 'string'].length <= 0;
        }
        return false;
    }

    limparCampoExportacao() {
        this.negocio.faturamentoAtual.faturamentoExportacao = null;
    }

    houveMudancaForm() {
        this.houveAlteracaoForm = true;
    }

    erroSalvar() {
        this.evtErroSalvar.emit(true);
    }

    carregaOptions(pagina: string, nrLinhas: string) {
        const options = {
            params: new HttpParams().set('page', pagina).set('size', nrLinhas),
        };
        return options;
    }

    onLazyLoad(event) {
        if (this.negocio.filiadas.length > 0) {
            this.nrLinhas = event.rows;
            if (event.rows !== undefined) {
                this.nrLinhasTabela = event.rows;
            }
            this.response = undefined;
            this.get(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then((resp) => {
                this.tabelaCooperativas = resp.data.content;
                this.changeDetectorRef.markForCheck();
            });
        }
    }

    private buscarFiliaisPorMatriz(cnpj, page) {
        const options = this.carregaOptions(page, this.nrLinhas.toString());
        this.filialApi.filtraFilialPaginadoPelaMatriz(options, cnpj).then((coope) => {
            this.totalElementos = coope.data.totalElements;
            this.tabelaCooperativas = Object.assign([], coope.data.content);
            // Carregando arquivos
            if (coope.data.content !== undefined && coope.data.content !== undefined) {
                coope.data.content.forEach((filial) => {
                    this.pessoaDocumentoApi.getPorIdPessoaFilial(filial.id).then((pesDoc) => {
                        if (pesDoc.data) {
                            filial.arquivos = [];
                            const repositorios: string[] = [];
                            pesDoc.data.forEach((obj) => {
                                obj.pessoaDocumentoAnexo.forEach((_obj) => {
                                    repositorios.push(_obj.uploadAnexo);
                                });
                            });

                            this.uploadApi.consultaArquivosNaoPaginado(repositorios).then((responseDocumento) => {
                              filial.arquivos = responseDocumento.content;
                              this.changeDetectorRef.markForCheck();
                            });
                        }
                    });
                });
            }

            // Carrega CEP para tabela
            this.tabelaCooperativas.forEach((elemento) => {
                this.listaCooperativasFiliacao.forEach((elementoLista) => {
                    if (elemento.cnpj === elementoLista.cnpj) {
                        elemento.endereco = elementoLista.endereco;
                    }
                });
            });
            this.changeDetectorRef.markForCheck();
        });
    }

    somenteNumeros(numero) {
        if (numero !== undefined) {
          return numero.toString().toUpperCase().replace(/[^A-Z0-9]+/g, '');
        }
    }

    onChangeFilter() {
        clearTimeout(this.debouncer);
        this.debouncer = setTimeout(() => {
            this.dtFilial.reset();
        }, this.delay);
    }

    loadLazy(event: TableLazyLoadEvent) {
        if (event.rows !== undefined) {
            this.nrLinhasTabela = event.rows;
        }
        this.response = undefined;
        this.get(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then((resp) => {
            this.tabelaCooperativas = resp.data.content;
            this.changeDetectorRef.markForCheck();
        });
    }

    get(pagina = 0, sortField, sortOrder = 1): Promise<IServiceResponse<IPage<PessoaJuridicaBasicaTO>>> {
        sortField = sortField || 'pessoaJuridicaFiliada.nomeFantasia';
        let sort: string;
        sort = sortOrder === 1 ? 'desc' : 'asc';
        const options = this.carregaOptionsPaginado(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
        return this.filialApi.filtraFilialPaginadoPelaMatriz(options, this.cooperativa.pessoaJuridica.cnpj);
    }

    carregaOptionsPaginado(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
        const options = {
            params: new HttpParams().set('page', pagina).set('size', nrLinhas).set('sort', `${sortField},${sortOrder}`),
        };
        options.params = this.utilityService.carregaParamsString(
            this.filtronomeFantasia,
            options.params,
            'nomeFantasia'
        );
        options.params = this.utilityService.carregaParamsString(this.filtrocnpj, options.params, 'cnpj');
        options.params = this.utilityService.carregaParamsString(this.filtroUf, options.params, 'ufSigla');
        options.params = this.utilityService.carregaParamsString(this.filtroTelefone, options.params, 'telefone');
        options.params = this.utilityService.carregaParamsString(this.filtroEmail, options.params, 'email');

        return options;
    }

    validaAjustesDados(): boolean {
        if (this.cooperativaTemp) {
            return this.validacaoDados.validaAjustesDados(this.cooperativaTemp.progressoMacro);
        }
        return false;
    }

    getQtdSegmentos(): number {
        if (this.isSegmentoUnico()) {
            return 1;
        }

        return this.optionsDrobdownSegmento.length;
    }

    isSegmentoUnico(): boolean {
        if (this.ramo != null && this.ramo.segmentoUnico != null && this.ramo.segmentoUnico) {
            return true;
        } else {
            return false;
        }
    }

    buscarRamo(){
        if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
            this.ramoApi.getRamo(this.cooperativa.pessoaJuridica.ramo.id)
            .then(res => {
            this.ramo = res;
            this.changeDetectorRef.markForCheck();
            });
        }
    }

    mostraModalCnae() {
        this.display = true;
    }

    cancelarCnae(event) {
        this.display = false;
    }

}
