export class OptionDropDown<T> {
  valores: Map<string, T[]> = new Map();


  getLista(chave: string) {
    return this.valores.get(chave);
  }
}
