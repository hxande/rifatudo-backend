import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { PessoaImagem } from '@cadastro-registro-api/models/PessoaImagem';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { RedeSocial } from '@cadastro-registro-api/models/RedeSocial';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { GeralService } from '@auth/geral.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { UtilityService } from '@utils/utility/utility.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { DateService } from '@shared/util/service/date.service';
import { DataUtils } from '@shared/utils/DataUtils';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { ConfirmationService, MessageService, SelectItem } from 'primeng/api';
import { AjusteDadosComponent } from '@shared/validacaoDados/ajuste-dados-component';
import { ValidacaoMarcacaoUtil } from '@shared/validacaoDados/validacao/validacao-marcacao.util';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { DadosGerais } from '@cadastro-registro-api/models/DadosGerais';
import { Pessoa } from '@cadastro-registro-api/models/Pessoa';
import { ApiControleAbasRegistroService } from '@cadastro-registro-api/services/api-controle-abas-registro.service';
import { ControleAbasRegistroEnum } from '@cadastro-registro-api/models/ControleAbasRegistroEnum';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { StringUtil } from '@shared/utils/StringUtil';
import { ApiDadosGeraisService } from 'src/app/api/services/api-dados-gerais.service';
import { DadosGeraisResponseTO } from 'src/app/api/models/DadosGeraisResponseTO';
import { ApiSindicatoService } from 'src/app/api/services/api-sindicato.service';
import { SindicatoTO } from 'src/app/api/models/SindicatoTO';

@Component({
  selector: 'app-dados-gerais-component',
  templateUrl: './dados-gerais-component.html',
  styleUrls: ['./dados-gerais-component.scss'],
})
export class DadosGeraisComponent implements OnInit, OnDestroy {
  @ViewChild('dadosGeraisForm') dadosGeraisForm: NgForm;
  @ViewChild('ajusteDados') ajusteDadosForm: AjusteDadosComponent;
  @ViewChildren(AjusteDadosComponent) ajusteDadosComponentes: QueryList<AjusteDadosComponent>;
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtMudarRamo = new EventEmitter<Ramo>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  @Output() evtAtualizaDocumentos = new EventEmitter<boolean>();
  @Input() exibirErros = true;
  @Input() cooperativaManutencao: CooperativaManutencao;

  atualizaAbaDocumentoFlag = false;
  cooperativaTemp: Cooperativa;
  nomePessoaJuridica: string;
  aprovacoes: CooperativaPendencia[] = [];
  mapPendencias: Map<string, boolean> = new Map();
  cooperativa: Cooperativa = null;
  enderecos: Endereco[] = null;
  redesSociais: RedeSocial[] = null;
  indexEnderecoPrincipal: number = null;

  categorias: Categoria[] = [];
  cooperativasVinculadas: number[] = [];
  cooperativasVinculadas2: CooperativaBasica[] = [];
  cooperativasBusca: CooperativaBasica[] = [];
  quadroSocialAtual: QuadroSocial = new QuadroSocial();
  dataAtual = new Date();
  optionsDropdownRamo: Ramo[];
  optionsDropdownSindicato: SindicatoTO[] = [];
  filiadaSindicato: boolean = null;
  sindicatoSelecionado: SindicatoTO = null;
  dateService = new DateService();
  podeModificarOsCampos = false;
  podeExcluir = false;
  mensagensValidacao = Array<{ summary: string; detail: string }>();
  cooperativaLogotipo: PessoaImagem = new PessoaImagem();
  dataUtils = new DataUtils();
  pendenciasEditadas = [];
  houveAlteracaoForm = false;
  houveAlteracaoaCooperadosPF = false;
  houveAlteracaoaCooperadosPJ = false;
  salvando = false;
  houveAlteracaoaEmpregadosHomem = false;
  houveAlteracaoaEmpregadosMulher = false;
  houveAlteracaoaHomensCooperados = false;
  houveAlteracaoaMulheresCooperados = false;
  checked = false;

  constructor(
    private ramoApi: ApiRamoService,
    private dadosGeraisService: ApiDadosGeraisService,
    private apiValidacaoDados: ApiValidacaoDadosService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    public language: LanguageService,
    public keycloakService: KeycloakService,
    private utilityService: UtilityService,
    private geralService: GeralService,
    private apiPj: ApiPessoaJuridicaService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    public validacaoDados: ValidacaoDados,
    private apiControleAbas: ApiControleAbasRegistroService,
    private apiSindicato: ApiSindicatoService
  ) {}

  ngOnInit(): void {
    this.carregarTela();
  }

  verificarMudancaRamo(ramo: Ramo) {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false).then((coop) => {
      if (coop) {
        const idRamo = ramo ? ramo.id : null;

        // Validando aba "DADOS GERAIS"
        this.apiCadastroRegistroService.verificarMudancaRamo(coop.id, idRamo).then((res) => {
          if (res && res.data) {
            const ramoComDados = res.data;

            this.confirmationService.confirm({
              message: 'Existem dados de Governaça/Negócio no ramo ' + ramoComDados.nome + ' que serão perdidos, deseja continuar a operação?',
              key: 'alterarRamo',
              reject: () => {
                this.cooperativa.pessoaJuridica.ramo = ramoComDados;
              },
            });
          }
        });
      }
    });
  }

  atualizarMensagensTela() {
    // Validando aba "DADOS GERAIS"
    this.apiCadastroRegistroService.validarDadosGerais(this.cooperativaTemp.id).then((res) => {
      this.mensagensValidacao = [];
      this.desativaEventoForm();
      if (res && res.data) {
        const dadosValidacao = res.data;
        if (!dadosValidacao.validado) {
          if (dadosValidacao.mensagens) {
            this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
              summary: msg.message.indexOf('<b>') === -1 ? '' : msg.message.substring(msg.message.indexOf('<b>') + 3, msg.message.indexOf('</b>')),
              detail: msg.message.indexOf('<b>') === -1 ? msg.message : msg.message.substring(msg.message.indexOf('</b>') + 4),
            }));
          }
        }
      }
    });
  }

  verificarLiberacaoCampos(id: number) {
    this.apiCadastroRegistroService.podePreencherCadastroRegistroBasico(id).then((res) => {
      if (res != null && res.data != null) {
        this.podeModificarOsCampos = res.data;
      }
    });
  }

  mudaRamo(event) {
    this.verificarMudancaRamo(event.value);
    if (!event.value) {
      this.filiadaSindicato = null;
      this.sindicatoSelecionado = null;
      this.optionsDropdownSindicato = [];
    } else if (this.filiadaSindicato) {
      this.buscarSindicatos();
    }
  }

  carregarFiliacaoSindical() {
    const idSindicato = (this.cooperativa as any).idSindicato;
    this.filiadaSindicato = (this.cooperativa as any).filiacaoSindical;
    this.sindicatoSelecionado = null;
    if (this.filiadaSindicato != null) {
      this.buscarSindicatos(idSindicato);
    }
  }

  aoMudarFiliacaoSindical() {
    this.houveMudancaForm();
    if (this.filiadaSindicato) {
      this.buscarSindicatos();
    } else {
      this.sindicatoSelecionado = null;
    }
  }

  buscarSindicatos(idSindicatoSelecionado?: number) {
    const pessoaJuridica = this.cooperativa ? this.cooperativa.pessoaJuridica : null;
    const uf = pessoaJuridica ? pessoaJuridica.ufSigla : null;
    const idRamo = pessoaJuridica && pessoaJuridica.ramo ? pessoaJuridica.ramo.id : null;
    this.apiSindicato.listaParaFiliacao(uf, idRamo).then((res) => {
      this.optionsDropdownSindicato = res && res.data ? res.data.content : [];
      const idSelecionado = idSindicatoSelecionado != null
        ? idSindicatoSelecionado
        : this.sindicatoSelecionado ? this.sindicatoSelecionado.id : null;
      this.sindicatoSelecionado = idSelecionado != null
        ? this.optionsDropdownSindicato.find((s) => s.id === idSelecionado) || null
        : null;
    });
  }

  public desativaEventoForm() {
    this.houveAlteracaoForm = false;
    this.houveAlteracaoaCooperadosPF = false;
    this.houveAlteracaoaCooperadosPJ = false;
    this.houveAlteracaoaEmpregadosHomem = false;
    this.houveAlteracaoaEmpregadosMulher = false;
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  houveMudancaHomensCooperados() {
    this.houveAlteracaoaHomensCooperados = true;
  }

  houveMudancaMulheresCooperados() {
    this.houveAlteracaoaMulheresCooperados = true;
  }

  houveMudancaCooperadosPF() {
    this.houveAlteracaoaCooperadosPF = true;
  }

  houveMudancaCooperadosPJ() {
    this.houveAlteracaoaCooperadosPJ = true;
  }

  houveMudancaEmpregadosHomens() {
    this.houveAlteracaoaEmpregadosHomem = true;
  }

  houveMudancaEmpregadosMulheres() {
    this.houveAlteracaoaEmpregadosMulher = true;
  }

  public getAlteracaoForm() {
    let alteracao = false;
    for (const ap of this.aprovacoes) {
      if (ap.houveAlteracao) {
        alteracao = true;
      }
    }
    return this.houveAlteracaoForm || alteracao;
  }


  verificarGrauCooperativa(recarregar: boolean) {
    if (this.cooperativa != null && this.cooperativa.categoria != null) {
      if (!(typeof this.cooperativa.categoria.minimoCooperativa === 'number')) {
        this.cooperativa.categoria.minimoCooperativa = 0;
      }

      if (recarregar) {
        this.cooperativasVinculadas = [];
        this.cooperativasVinculadas2 = [];
      }

      for (let i = this.cooperativasVinculadas.length; i < this.cooperativa.categoria.minimoCooperativa; i++) {
        this.cooperativasVinculadas.push(null);
        this.cooperativasVinculadas2.push(null);
      }
    }
  }

  obterEnderecoPrincipal() {
    return this.indexEnderecoPrincipal != null ? this.enderecos[this.indexEnderecoPrincipal] : null;
  }

  verificarCooperativa(cv: CooperativaBasica, i: number) {
    if (!cv || !cv.id) {
      this.cooperativasVinculadas[i] = null;
      this.cooperativasVinculadas2[i] = null;
    }
  }

  removerCooperativaVinculada(i: number) {
    if (
      this.cooperativa != null &&
      this.cooperativa.categoria != null &&
      typeof this.cooperativa.categoria.minimoCooperativa === 'number' &&
      this.cooperativa.categoria.minimoCooperativa > 0
    ) {
      if (this.cooperativasVinculadas.length > this.cooperativa.categoria.minimoCooperativa) {
        this.cooperativasVinculadas.splice(i, 1);
        this.cooperativasVinculadas2.splice(i, 1);
      }
    }

    if (this.cooperativasVinculadas.length <= this.cooperativa.categoria.minimoCooperativa) {
      this.podeExcluir = false;
    }
  }

  adicionarCooperativaVinculada() {
    this.cooperativasVinculadas.push(null);
    this.cooperativasVinculadas2.push(null);

    if (this.cooperativasVinculadas.length > this.cooperativa.categoria.minimoCooperativa) {
      this.podeExcluir = true;
    }
  }

  buscarRamos() {
    this.ramoApi.getRamos().then((response) => {
      if (response && response.data) {
        this.optionsDropdownRamo = response.data;
      }
    });
  }

  carregarTela() {
    this.cooperativasVinculadas = [];
    this.cooperativasVinculadas2 = [];

    this.cooperativa = new Cooperativa();
    this.cooperativa.pessoaJuridica = new PessoaJuridica();

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false).then((coop) => {
      if (coop) {
        this.cooperativaTemp = coop;
        this.dadosGeraisService.getCooperativa(coop.id).then((res) => {
          if (res == null || res.data.id == null) {
            this.cooperativaNaoEncontrada();
          } else {
            this.cooperativa = res.data;

            this.apiPj.buscaUnidadeResponsavel(this.cooperativa.pessoaJuridica.ufSigla).then((pj) => {
              this.nomePessoaJuridica = pj.data.nomeFantasia;
            });

            if (this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.dataConstituicao) {
              this.cooperativa.pessoaJuridica.dataConstituicao = this.dateService.getDate(this.cooperativa.pessoaJuridica.dataConstituicao);
            }

            this.carregarFiliacaoSindical();

            // ---------------- Vinculações --------------------------------------
            this.dadosGeraisService.getVinculacoes(coop.id).then((resVinc) => {
              if (resVinc && resVinc.data != null && resVinc.data.length > 0) {
                const dados = resVinc.data.filter((x) => x != null); // Tirar itens nulos da listagem

                this.cooperativasVinculadas2 = dados;
                this.cooperativasVinculadas = new Array<number>(this.cooperativasVinculadas2.length);
              }

              this.verificarGrauCooperativa(false);
            });

            // Redes Sociais
            this.redesSociais = this.cooperativa.pessoaJuridica.redesSociais;


            // Atualizando Aba
            this.evtAtualizaDocumentos.emit(this.atualizaAbaDocumentoFlag);

            this.evtSalvarDados.emit(false);
            this.atualizarMensagensTela();

            this.atualizaPendenciaChave(coop);
          }
        });

        this.dadosGeraisService.getEnderecos(coop.id).then((res) => {
          if (res && res.data != null) {
            this.enderecos = res.data;

            let index = 0;
            this.enderecos.forEach((end) => {
              if (end.idMunicipio) {
                this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {
                  end.municipio = resEnd;

                  // Adicionando UF
                  if (end.municipio != null && end.municipio.id) {
                    end.uf = end.municipio.uf;

                  }
                });
              }

              // Sinalizando quem é o endereço principal
              if (end.tipoEndereco.enderecoPrincipal) {
                this.indexEnderecoPrincipal = index;
              }

              index++;
            });
          }
        });

        // Categorias
        this.dadosGeraisService.getCategorias().then((res) => {
          if (res && res.data != null) {
            this.categorias = res.data;
          }
        });


        // Quadro Social Atual
        this.dadosGeraisService.buscarQuadroSocialAtual(coop.id).then((res) => {
          if (res && res.data != null) {
            this.quadroSocialAtual = res.data;
          }
        });

        // Logotipo da cooperativa
        this.cooperativaLogotipo.idPessoa = coop.id;
      }
    });

    // Verificando campos
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      this.verificarLiberacaoCampos(coop.id);
    });
    this.buscarRamos();
    if (this.ajusteDadosForm) {
      this.ajusteDadosForm.carregarAprovacao();
    }
  }

  private atualizaPendenciaChave(coop: Cooperativa) {
    this.apiValidacaoDados.obterUltimasPendenciasChave(coop.id).then((res) => {
      this.mapPendencias = res.data;
    });
  }

  ngOnDestroy(): void {}

  limparCamposCooperadosQuadroSocial() {
    if (this.quadroSocialAtual.apenasTotalPF) {
      this.quadroSocialAtual.cooperadosHomens = null;
      this.quadroSocialAtual.cooperadosMulheres = null;
    } else {
      this.quadroSocialAtual.cooperadosPF = null;
    }
  }

  limparCamposTotalCooperadosQuadroSocial() {
    if (this.quadroSocialAtual.apenasTotalCooperados) {
      this.quadroSocialAtual.cooperadosHomens = null;
      this.quadroSocialAtual.cooperadosMulheres = null;
      this.quadroSocialAtual.cooperadosPF = null;
      this.quadroSocialAtual.cooperadosPJ = null;

      this.quadroSocialAtual.apenasTotalPF = false;
    } else {
      this.quadroSocialAtual.cooperadosTotal = null;

      this.quadroSocialAtual.apenasTotalPF = false;
    }
  }

  limparCamposEmpregadosQuadroSocial() {
    if (this.quadroSocialAtual.apenasTotalEmpregados) {
      this.quadroSocialAtual.empregadosHomens = null;
      this.quadroSocialAtual.empregadosMulheres = null;
    } else {
      this.quadroSocialAtual.empregadosTotal = null;
    }
  }

  atualizarTotaisQuadroSocial() {
    if (this.quadroSocialAtual != null) {
      this.normalizarQuadroSocial();

      if (!this.quadroSocialAtual.apenasTotalPF) {
        if (typeof this.quadroSocialAtual.cooperadosHomens === 'number' || typeof this.quadroSocialAtual.cooperadosMulheres === 'number') {
          this.quadroSocialAtual.cooperadosPF = this.quadroSocialAtual.cooperadosHomens + this.quadroSocialAtual.cooperadosMulheres;
        } else {
          this.quadroSocialAtual.cooperadosPF = null;
        }
      }

      if (!this.quadroSocialAtual.apenasTotalCooperados) {
        if (typeof this.quadroSocialAtual.cooperadosPF === 'number' || typeof this.quadroSocialAtual.cooperadosPJ === 'number') {
          this.quadroSocialAtual.cooperadosTotal = this.quadroSocialAtual.cooperadosPF + this.quadroSocialAtual.cooperadosPJ;
        } else {
          this.quadroSocialAtual.cooperadosTotal = null;
        }
      }

      if (!this.quadroSocialAtual.apenasTotalEmpregados) {
        if (typeof this.quadroSocialAtual.empregadosHomens === 'number' || typeof this.quadroSocialAtual.empregadosMulheres === 'number') {
          this.quadroSocialAtual.empregadosTotal = this.quadroSocialAtual.empregadosHomens + this.quadroSocialAtual.empregadosMulheres;
        } else {
          this.quadroSocialAtual.empregadosTotal = null;
        }
      }
    }
  }

  normalizarQuadroSocial() {
    this.quadroSocialAtual.cooperadosHomens = this.somenteNumeros(this.quadroSocialAtual.cooperadosHomens);
    this.quadroSocialAtual.cooperadosMulheres = this.somenteNumeros(this.quadroSocialAtual.cooperadosMulheres);
    this.quadroSocialAtual.cooperadosPF = this.somenteNumeros(this.quadroSocialAtual.cooperadosPF);
    this.quadroSocialAtual.cooperadosPJ = this.somenteNumeros(this.quadroSocialAtual.cooperadosPJ);
    this.quadroSocialAtual.empregadosHomens = this.somenteNumeros(this.quadroSocialAtual.empregadosHomens);
    this.quadroSocialAtual.empregadosMulheres = this.somenteNumeros(this.quadroSocialAtual.empregadosMulheres);
    this.quadroSocialAtual.empregadosTotal = this.somenteNumeros(this.quadroSocialAtual.empregadosTotal);
  }

  formatarNire(nire) {
    this.cooperativa.pessoaJuridica.nire = this.somenteNumeros(nire);
  }

  somenteNumeros(valor) {
    let saida = null;
    if (valor != null) {
      const valorInteiro = parseInt(String(valor).replace(/\D+/g, ''), 10);
      if (typeof valorInteiro === 'number' && !isNaN(valorInteiro)) {
        saida = valorInteiro;
      }
    }
    return saida;
  }


  varrerListagemVinculacao() {
    if (this.cooperativasVinculadas2 != null) {
      for (let i = 0; i < this.cooperativasVinculadas2.length; i++) {
        if (this.cooperativasVinculadas2[i] != null && !this.cooperativasVinculadas2[i].id) {
          this.cooperativasVinculadas2[i] = null;
        }
      }
    }
  }

  atualizarCooperativa(cv: CooperativaBasica, i: number) {
    this.cooperativasVinculadas2[i] = cv;
  }

  cooperativaNaoEncontrada() {
    this.messageService.add({ severity: 'error', detail: 'Cooperativa não encontrada! [SAINDO]', life: 10000 });
  }

  salvarDadosGerais(abaDestino: number) {
    if (this.salvando) {
      return false;
    }
    this.varrerListagemVinculacao();
    this.houveAlteracaoForm = true;
    let pendenciaPreenchumentoTela = false;
    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchumentoTela = true;
      }
    });
    if (pendenciaPreenchumentoTela) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Preencha corretamente as orientações para ajuste!',
        life: 10000,
      });
      return false;
    }

    if (this.filiadaSindicato === true && !this.sindicatoSelecionado) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Selecione o sindicato ao qual a cooperativa é filiada.',
        life: 10000,
      });
      return false;
    }

    if (this.cooperativa && this.cooperativa.id) {
      const dadosGerais = new DadosGeraisResponseTO();
      dadosGerais.idCooperativa = this.cooperativa.id;
      dadosGerais.categoria = this.cooperativa.categoria;
      dadosGerais.regidaPorLei = this.cooperativa.regidaPorLei;
      dadosGerais.filiadaSindicato = this.filiadaSindicato;
      dadosGerais.idSindicato = this.filiadaSindicato && this.sindicatoSelecionado ? this.sindicatoSelecionado.id : null;
      dadosGerais.pessoaJuridica = this.cooperativa.pessoaJuridica;

      if (this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.dataConstituicao) {
        dadosGerais.pessoaJuridica.dataConstituicao = this.dateService.getDate(this.cooperativa.pessoaJuridica.dataConstituicao);
      }
      dadosGerais.pessoaJuridica.telefoneGeral = this.utilityService.retirarFormatacaoTelefone(
        dadosGerais.pessoaJuridica.telefoneGeral
      );

      dadosGerais.cooperativasVinculadas = this.cooperativasVinculadas2;
      dadosGerais.enderecos = this.enderecos;

      if (this.quadroSocialAtual) {
        this.quadroSocialAtual.cooperadosPF =
          !this.quadroSocialAtual.cooperadosPF && this.houveAlteracaoaCooperadosPF ? 0 : this.quadroSocialAtual.cooperadosPF;
        this.quadroSocialAtual.cooperadosPJ =
          !this.quadroSocialAtual.cooperadosPJ && this.houveAlteracaoaCooperadosPJ ? 0 : this.quadroSocialAtual.cooperadosPJ;
      }

      dadosGerais.quadroSocialAtual = this.quadroSocialAtual;

      dadosGerais.redesSociais = this.redesSociais.filter(rs => rs.link && rs.tipoRedeSocial);

      this.geralService.salvarPendencia(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);

      // Atualizando endereços
      if (dadosGerais.enderecos != null) {
        dadosGerais.enderecos.forEach((end) => {
          const pessoa = new Pessoa();
          pessoa.id = this.cooperativa.pessoaJuridica.id;
          end.pessoa = pessoa;

          if (end.municipio) {
            end.idMunicipio = end.municipio.id;
          } else {
            end.idMunicipio = null;
          }

          if (end.uf) {
            end.idEstado = end.uf.id;
          } else {
            end.idEstado = null;
          }

          end.cep = this.utilityService.retirarFormatacao(end.cep);
        });
      }

      if (this.pendenciasEditadas.length > 0) {
        this.apiValidacaoDados.editarAgrupamento(this.pendenciasEditadas).then((res) => {
          this.pendenciasEditadas = res.data;
        });
      }

      const aba = {
        id: null,
        cooperativa: { id: Number(this.cooperativa.id) },
        dataEnvio: null,
        aba: ControleAbasRegistroEnum.DADOOS_GERAIS,
        enviada: true
      };

      this.apiControleAbas.save(aba).subscribe();
      this.salvando = true;
      this.dadosGeraisService
        .salvarDadosGerais(dadosGerais)
        .then(() => {
          this.desativaEventoForm();

          ValidacaoMarcacaoUtil.notificarSalvoComPendencias(this.messageService, this.ajusteDadosComponentes);

          for (const ap of this.aprovacoes) {
            if (ap.houveAlteracao) {
              ap.houveAlteracao = false;
            }
          }

          this.carregarTela();

          window.scroll(0, 0);

          // Ir para a proxima pagina
          this.evtFimSalvarDados.emit(abaDestino);
        })
        .catch(() => {
          this.evtErroSalvar.emit(true);
        })
        .finally(() => {
          this.salvando = false;
        });
    } else {
      this.messageService.add({ severity: 'error', detail: 'Pessoa Jurídica inválida', life: 10000 });
    }
  }

  procurarCooperativas(event) {
    const query = this.normalizarBuscaCooperativa(event.query);

    if (this.cooperativa != null && this.cooperativa.categoria != null) {
      this.dadosGeraisService.buscarCooperativas(query, this.cooperativa.categoria.id).then((res) => {
        this.cooperativasBusca = res.data.filter((coop) => coop.id !== this.cooperativa.id);
      });
    }
  }

  private normalizarBuscaCooperativa(valor: string): string {
    if (!valor) {
      return '';
    }

    return valor
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[.\-/\s]/g, '')
      .trim();
  }


  atualizaLiberacaoCampo(pendencia) {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas.push(pendencia);
    }
    this.mapPendencias[pendencia.bloco] = false;
    this.houveAlteracaoForm = true;
  }

  selectMask(event: Event) {
    setTimeout(() => (event.target as HTMLInputElement).select(), 100);
  }

  collapsedFieldSetEndereco(endereco: Endereco) {
    return false;
  }

  toggleableEndereco(endereco: Endereco) {
    if (endereco) {
      return false;
    }
  }

  limpaEndereco(endereco: Endereco) {
    if (endereco) {
      this.enderecos.forEach((end) => {
        if (endereco.tipoEndereco.id === end.tipoEndereco.id) {
          end.cep = null;
          end.idEstado = null;
          end.idMunicipio = null;
          end.enderecoReferencia = null;
          end.numero = null;
          end.bairro = null;
          end.municipio = null;
          end.uf = null;
          end.complemento = null;
        }
      });
    }
  }

  validaAjustesDados() {
    if (this.cooperativaTemp) {
      return this.validacaoDados.validaAjustesDados(this.cooperativaTemp.progressoMacro);
    }
    return false;
  }

  atualizaAbaDocumento() {
    this.atualizaAbaDocumentoFlag = true;
  }

  setCorrespondenciaDiferente(correspondenciaDiferente: boolean){
    this.enderecos.forEach(e => e.correspondenciaDiferente = correspondenciaDiferente);
  }

  formatarId(nomeId){
    const semAcento:string = StringUtil.limparTexto(nomeId)
    return semAcento.toLowerCase().split(' ').join('-')
  }

}
