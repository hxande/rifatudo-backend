import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {LanguageService} from '@shared/languages/calendar-primeng/language-calendar';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import { LazyLoadEvent } from 'primeng/api';
import { PessoaCnaeService } from 'src/app/api/services/api-pessoa-cnae.service';
import { PessoaCnaeTO } from 'src/app/api/models/PessoaCnaeTO';
import { HttpParams } from '@angular/common/http';
import { IPage } from '@utils/interfaces/IPage';
import { Page } from 'page';



@Component({
  selector: 'app-cnae-component',
  templateUrl: './cnae-component.html',
  styleUrls: ['./cnae-component.scss'],
})
export class CnaeComponent implements OnInit {

  @Input() idCooperativa : number;
  @Input() display : boolean;

  @Output() isCancelar = new EventEmitter<boolean>();

  cols: { field: string, header: string }[];
  listPessoaCnae: PessoaCnaeTO[] = [];
  
  constructor(
    public language: LanguageService,
    public keycloakService: KeycloakService,
    public pessoaCnaeService: PessoaCnaeService  
  ) {
  }

  ngOnInit() {
    this.cols = [
      { field: 'id', header: 'Código' },
      { field: 'descricao', header: 'Descrição da atividade econômica' },
      { field: 'primario', header: 'Classificação' }
    ];

    this.carregarTela();
  }

  carregarTela(){
    this.pessoaCnaeService.obterPessoaCane(this.idCooperativa).subscribe(response => {
      this.listPessoaCnae = response;
    });
  }

  cancelar(){
    this.isCancelar.emit(true);
  }
}
