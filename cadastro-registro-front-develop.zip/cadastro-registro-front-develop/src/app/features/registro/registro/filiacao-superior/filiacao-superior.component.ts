import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';

@Component({
  selector: 'app-filiacao-superior',
  templateUrl: './filiacao-superior.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./filiacao-superior.scss']
})
export class FiliacaoSuperiorComponent {

  @Input('registro')
  cooperativa: Cooperativa;

  @Input('visible')
  modalFiliadas: boolean;

  @Input('vinculadas')
  cooperativasVinculadas2: CooperativaBasica[] = [];

  @Output()
  fechaModal = new EventEmitter();

  closeModal(): void {
    this.fechaModal.emit(this.cooperativasVinculadas2);
  }

  carregaVinculadas(): void {
    // vazio mesmo
    // ou remove o onShow do html
  }
}
