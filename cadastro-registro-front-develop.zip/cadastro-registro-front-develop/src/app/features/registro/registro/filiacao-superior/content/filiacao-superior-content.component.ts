import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { ConfirmationService, MessageService } from 'primeng/api';
import { ApiDadosGeraisService } from 'src/app/api/services/api-dados-gerais.service';
import {
  ApiVinculacaoCooperativaSolicitacaoService,
  TipoVinculoSolicitacaoEnum,
} from 'src/app/api/services/api-vinculacao-cooperativa-solicitacao.service';

interface CooperativaSuperiorItem {
  id: number;
  cnpj: string;
  razaoSocial: string;
  nomeFantasia: string;
  ufSigla: string;
  statusFiliacao?: string;
  possuiVinculoEfetivado?: boolean;
  idSolicitacao?: number;
}

@Component({
  selector: 'app-filiacao-superior-content',
  templateUrl: './filiacao-superior-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./filiacao-superior-content.scss'],
})
export class FiliacaoSuperiorContentComponent implements OnInit, OnChanges {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input('registro')
  cooperativa: Cooperativa;

  @Input('isAba')
  isAbaModal: boolean;

  @Input('visible')
  visible: boolean;

  @Input('vinculadas')
  cooperativasVinculadas2: CooperativaBasica[] = [];

  @Output()
  fechaModal = new EventEmitter();

  cnpjPai: string;

  visibleMessageNotFound = false;
  possuiVinculoEfetivado = false;
  houveAlteracaoForm = false;

  cooperativaSuperiorSelecionada: CooperativaSuperiorItem = null;
  solicitacaoPendente: CooperativaSuperiorItem = null;

  cooperativasSuperioresSelecionadas: CooperativaSuperiorItem[] = [];
  cooperativasSuperioresEncontradas: CooperativaSuperiorItem[] = [];
  cooperativasVinculadas: number[] = [];

  mensagemCooperativaNaoEncontrada: string;

  constructor(
    private dadosGeraisService: ApiDadosGeraisService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private vinculacaoSolicitacaoService: ApiVinculacaoCooperativaSolicitacaoService,
  ) {
  }

  ngOnChanges(changes: SimpleChanges): void {

    if (changes.visible && changes.visible.currentValue === true) {
      this.carregarEstadoInicialFiliacao();
    }

  }

  ngOnInit(): void {
    this.carregaVinculadas();
    this.carregarEstadoInicialFiliacao();
  }

  get somenteLeitura(): boolean {
    return this.cooperativa?.status?.toLowerCase() === 'aprovada' ||
      this.cooperativa?.situacaoCooperativa?.nome?.toLowerCase() === 'cancelada';
  }

  confirmarRemocaoCooperativaSuperior(cooperativa: CooperativaSuperiorItem): void {

    if (this.somenteLeitura) {
      return;
    }

    const mensagem = cooperativa.possuiVinculoEfetivado
      ? 'Esta ação irá remover o vínculo de filiação superior já aprovado. Deseja continuar?'
      : cooperativa.idSolicitacao
        ? 'Esta ação irá remover a solicitação aguardando aprovação. Deseja continuar?'
        : 'Deseja remover esta cooperativa da lista?';

    this.confirmationService.confirm({
      header: 'Confirmar remoção',
      icon: 'pi pi-exclamation-triangle',
      message: mensagem,
      acceptLabel: 'Sim, remover',
      rejectLabel: 'Cancelar',
      acceptButtonStyleClass: 'p-button-danger p-button-sm',
      rejectButtonStyleClass: 'p-button-outlined p-button-sm',
      accept: () => this.removerCooperativaSuperior(cooperativa),
    });
  }

  private removerCooperativaSuperior(cooperativa: CooperativaSuperiorItem): void {

    if (cooperativa.idSolicitacao) {
      this.vinculacaoSolicitacaoService.deletar(cooperativa.idSolicitacao).then(() => {
        this.removerDaLista(cooperativa);
        this.messageService.add({ severity: 'success', detail: 'Solicitação removida com sucesso.', life: 4000 });
        this.changeDetectorRef.markForCheck();
      });
      return;
    }

    if (cooperativa.possuiVinculoEfetivado) {
      this.dadosGeraisService
        .removerCooperativaSuperiorVinculada(this.cooperativa.id, cooperativa.id)
        .then(() => {
          this.removerDaLista(cooperativa);
          this.messageService.add({ severity: 'success', detail: 'Vínculo removido com sucesso.', life: 4000 });
          this.changeDetectorRef.markForCheck();
        });
      return;
    }

    this.removerDaLista(cooperativa);
  }

  private removerDaLista(cooperativa: CooperativaSuperiorItem): void {
    this.cooperativasSuperioresSelecionadas =
      this.cooperativasSuperioresSelecionadas.filter((item) => item.id !== cooperativa.id);
  }

  salvar(): void {

    if (this.somenteLeitura) {
      return;
    }
    if (!this.podeSalvar) {
      return;
    }

    const novas = this.cooperativasSuperioresSelecionadas
      .filter((item) => item.statusFiliacao === 'NOVO');

    Promise.all(novas.map((item) =>
      this.vinculacaoSolicitacaoService.criarSolicitacao({
        idCooperativaSolicitante: this.cooperativa.id,
        idCooperativaIndicada: item.id,
        tipoVinculo: TipoVinculoSolicitacaoEnum.FILIACAO_SUPERIOR
      })
    )).then(() => {
      this.messageService.add({
        severity: 'success',
        detail: 'Solicitações de filiação superior enviadas para aprovação.',
        life: 4000
      });

      this.closeModal();
    });
  }

  private carregarEstadoInicialFiliacao(): void {

    if (!this.cooperativa?.id) return;

    this.cooperativasSuperioresSelecionadas = [];
    this.cooperativasSuperioresEncontradas = [];

    this.dadosGeraisService.getCooperativaSuperiorVinculada(this.cooperativa.id)
      .then((res) => {

        const efetivadas = (res || []).map((item) => ({
          ...item,
          statusFiliacao: 'APROVADO',
          possuiVinculoEfetivado: true,
        }));

        this.cooperativasSuperioresSelecionadas = efetivadas;

        this.changeDetectorRef.markForCheck();

        return this.vinculacaoSolicitacaoService.listarPorSolicitante(this.cooperativa.id);
      })
      .then((response) => {
        const pendentes = (response?.data || [])
          .filter((x) =>
            x.tipoVinculo === TipoVinculoSolicitacaoEnum.FILIACAO_SUPERIOR &&
            x.status === 'AGUARDANDO_APROVACAO',
          )
          .map((x) => ({
            id: x.idCooperativaIndicada,
            idSolicitacao: x.id,
            nomeFantasia: x.nomeFantasiaIndicada,
            razaoSocial: '',
            cnpj: x.cnpjIndicada,
            ufSigla: x.ufIndicada,
            statusFiliacao: x.status,
            possuiVinculoEfetivado: false,
          }));

        this.cooperativasSuperioresSelecionadas = [
          ...this.cooperativasSuperioresSelecionadas,
          ...pendentes.filter((p) => !this.existeCooperativaNaLista(p)),
        ];

        this.changeDetectorRef.markForCheck();
      });
  }

  carregaVinculadas(): void {

    if (
      this.cooperativa != null &&
      this.cooperativa.id != null &&
      (this.cooperativasVinculadas2 == null ||
        this.cooperativasVinculadas2.length === 0)
    ) {

      this.dadosGeraisService
        .getVinculacoes(this.cooperativa.id)
        .then((resVinc) => {

          if (
            resVinc &&
            resVinc.data != null &&
            resVinc.data.length > 0
          ) {

            const dados = resVinc.data.filter((x) => x != null);

            this.cooperativasVinculadas2 = dados;

            this.cooperativasVinculadas =
              new Array<number>(this.cooperativasVinculadas2.length);
          }

          this.verificarGrauCooperativa(false);
        });
    }
  }

  verificarGrauCooperativa(recarregar: boolean): void {

    if (
      this.cooperativa != null &&
      this.cooperativa.categoria != null
    ) {

      if (!(typeof this.cooperativa.categoria.minimoCooperativa === 'number')) {
        this.cooperativa = {
          ...this.cooperativa,
          categoria: { ...this.cooperativa.categoria, minimoCooperativa: 0 }
        };
      }

      if (recarregar) {
        this.cooperativasVinculadas = [];
        this.cooperativasVinculadas2 = [];
      }
    }
  }

  getCooperativasSuperioresPorCnpjPai(): void {
    if (!this.cnpjPai?.trim() || !this.cooperativa?.id) {
      return;
    }

    const cnpjNotMask = this.removerMascaraCnpj(this.cnpjPai);

    this.visibleMessageNotFound = false;
    this.mensagemCooperativaNaoEncontrada = null;
    this.cooperativasSuperioresEncontradas = [];

    this.dadosGeraisService
      .getCooperativasSuperioresPorCnpjPai(
        this.cooperativa.id,
        cnpjNotMask
      )
      .then((res) => {
        if (!res?.encontrada || !res?.vinculoPermitido) {
          this.visibleMessageNotFound = true;
          this.mensagemCooperativaNaoEncontrada =
            res?.mensagem ||
            'Nenhuma cooperativa foi encontrada para o CNPJ informado.';

          this.changeDetectorRef.detectChanges();

          setTimeout(() => {
            this.visibleMessageNotFound = false;
            this.changeDetectorRef.detectChanges();
          }, 9000);

          return;
        }

        const cooperativa = res.cooperativa;

        if (this.existeCooperativaNaLista(cooperativa)) {
          this.messageService.add({
            severity: 'warn',
            detail: 'Cooperativa já consta na lista.',
            life: 4000
          });
          return;
        }

        this.cooperativasSuperioresEncontradas = [cooperativa];

        this.changeDetectorRef.detectChanges();
      });
  }

  confirmarCooperativaSuperior(cooperativa: CooperativaSuperiorItem): void {
    if (this.somenteLeitura) {
      return;
    }
    if (this.existeCooperativaNaLista(cooperativa)) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Cooperativa já consta na lista.',
        life: 4000,
      });
      return;
    }

    this.cooperativasSuperioresSelecionadas = [
      ...this.cooperativasSuperioresSelecionadas,
      { ...cooperativa, statusFiliacao: 'NOVO', possuiVinculoEfetivado: false }
    ];

    this.cooperativasSuperioresEncontradas =
      this.cooperativasSuperioresEncontradas.filter((item) => item.id !== cooperativa.id);

    this.cnpjPai = null;
  }

  private existeCooperativaNaLista(cooperativa: CooperativaSuperiorItem): boolean {
    return this.cooperativasSuperioresSelecionadas
      .some((item) => item.id === cooperativa.id);
  }

  getStatusLabel(cooperativa: CooperativaSuperiorItem): string {
    if (cooperativa.statusFiliacao === 'NOVO') return 'Pronto para enviar';
    if (cooperativa.statusFiliacao === 'AGUARDANDO_APROVACAO') return 'Aguardando aprovação';
    if (cooperativa.statusFiliacao === 'APROVADO') return 'Aprovado';
    return cooperativa.statusFiliacao || '-';
  }

  getStatusClass(cooperativa: CooperativaSuperiorItem): string {
    if (cooperativa.statusFiliacao === 'NOVO') {
      return 'status-chip status-chip-novo';
    }

    if (cooperativa.statusFiliacao === 'AGUARDANDO_APROVACAO') {
      return 'status-chip status-chip-pendente';
    }

    if (cooperativa.statusFiliacao === 'APROVADO') {
      return 'status-chip status-chip-aprovado';
    }

    return 'status-chip status-chip-default';
  }

  get podeSalvar(): boolean {
    return this.cooperativasSuperioresSelecionadas
      .some((item) => item.statusFiliacao === 'NOVO');
  }

  getStatusIcon(cooperativa: CooperativaSuperiorItem): string {
    if (cooperativa.statusFiliacao === 'NOVO') {
      return 'pi pi-send';
    }

    if (cooperativa.statusFiliacao === 'AGUARDANDO_APROVACAO') {
      return 'pi pi-clock';
    }

    if (cooperativa.statusFiliacao === 'APROVADO') {
      return 'pi pi-check-circle';
    }

    return 'pi pi-info-circle';
  }

  removerMascaraCnpj(cnpj: string): string {

    if (!cnpj?.trim()) {
      return '';
    }

    return cnpj.replace(/[.\-\/]/g, '');
  }

  closeModal(): void {
    this.fechaModal.emit(this.cooperativasVinculadas2);
    this.cooperativasSuperioresEncontradas = [];
    this.cnpjPai = null;
  }

}
