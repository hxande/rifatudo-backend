import { Component, HostListener, OnDestroy, OnInit, ViewChild, Inject, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AppComponent } from 'src/app/app.component';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { ContatoComponent } from '../contato/contato-component';
import { DadosGeraisComponent } from '../dadosGerais/dados-gerais-component';
import { GovernancaSharedComponent } from '../../governanca-shared/governanca-shared.component';
import { NegocioComponent } from '../negocio/negocio.component';
import { DocumentosComponent } from '../documentos/documentos-component';
import { DOCUMENT } from '@angular/common';
import { TabView } from 'primeng/tabview';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { ValidacaoCadastroRegistro } from '@shared/registro/cadastroRegistro/validacao/validacao-cadastro-registro.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ValidacaoProcessoRegistro } from '@shared/validacao/validacao-processo-registro.service';
import { Parecer } from '@cadastro-registro-api/models/Parecer';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { Messages } from '@shared/mensagens/Messages';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApiControleAbasRegistroService } from '@cadastro-registro-api/services/api-controle-abas-registro.service';
import { ControleAbaRegistroTO } from '@cadastro-registro-api/models/ControleAbaRegistroTO';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { CooperativaManutencaoStatus } from '@shared/cooperativa-manutencao/cooperativa-manutencao-status';
import { ComponenteComAlteracoesPendentes } from '@shared/guard/alteracoes-pendentes.guard';
import { ApiGovernancaService } from '../../governanca-shared/service/api-governanca.service';

type EtapaRegistro = 'nenhuma' | 'inicial';
enum EnumAbaRegistro {
  Documentos = 0,
  DadosGerais,
  Governanca,
  SegmentacaoEFiliais,
  Contatos,
  Submeter,
}

@Component({
  selector: 'app-cadastro-registro-component',
  templateUrl: './cadastro-registro-component.html',
  styleUrls: ['./cadastro-registro-component.scss'],
})
export class CadastroRegistroComponent implements OnInit, OnDestroy, ComponenteComAlteracoesPendentes {
  cooperativaManutencao: CooperativaManutencao;

  estadoPreenchimentoGovernanca: 'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null = null;

  /** Resolve a navegação suspensa pelo guard de saída (AlteracoesPendentesGuard). */
  private resolverSaidaPagina: ((podeSair: boolean) => void) | null = null;

  private readonly abaSubmeter = 5;

  @ViewChild('dadosGerais') dadosGeraisForm: DadosGeraisComponent;
  @ViewChild('negocioForm') negocioForm: NegocioComponent;
  // O tipo legado GovernancaComponent foi removido — o #governanca do
  // template sempre foi o app-governanca-shared; o tipo agora reflete isso.
  @ViewChild('governanca') governancaForm: GovernancaSharedComponent;
  @ViewChild('contato') contatoForm: ContatoComponent;
  @ViewChild('onglets') onglets: TabView;
  @ViewChild('documentos') documentosForm: DocumentosComponent;
  @ViewChild('file') file;

  classeTopoDadosGerais: string;
  classeTopoDadosGeraisVerificacao: string;
  classeTopoDadosGeraisQuantidade: string;

  classeTopoGovernanca: string;
  classeTopoGovernancaVerificacao: string;
  classeTopoGovernancaQuantidade: string;

  classeTopoContatos: string;
  classeTopoContatosVerificacao: string;
  classeTopoContatosQuantidade: string;

  classeTopoDocumentos: string;
  classeTopoDocumentosVerificacao: string;
  classeTopoDocumentosQuantidade: string;

  classeTopoNegocio: string;
  classeTopoNegocioVerificacao: string;
  classeTopoNegocioQuantidade: string;

  classeTopoSubmeter: string;
  classeTopoSubmeterVerificacao: string;
  classeTopoSubmeterQuantidade: string;

  abaPreenchidaDadosGerais = false;
  abaPreenchidaGovernanca = false;
  abaPreenchidaNegocio = false;
  abaPreenchidaDocumento = false;

  bloquearNegocio = false;

  idCooperativa: string;

  public index = 0;
  public abaOrigem = 0;
  public abaDestino = 0;

  private classeFixaIcone = 'ui-tabview-right-icon ng-star-inserted ';
  cooperativa: Cooperativa;

  // Dados (Preenchimento)
  podeSubmeter = false;
  submeterValidado = false;
  salvandoAba = false;
  mensagensSubmeter: { summary: string; detail: string }[] = [];

  // Sobre Pendências
  pendenciasValidas = false;
  podeProgredir = false;

  mostrarSubmeter = false;
  mostrarAjustes = false;
  mostrarConformidade = false;
  mostrarVisitaTecnica = false;
  mostrarDeliberacao = false;

  progressoMacroEnum = ProgressoMacroEnum;
  dialogoSalvarAba = false;
  dialogConfLegal = false;
  podeModificarOsCampos = false;

  podeModificarLogo = true;
  statusCooperativa: string;
  submeterExibir = false;
  submeterPendencias = false;
  nomePessoaJuridica: string;
  listaMensagemDocumentacao = Array<Messages>();
  etapaInicial: EtapaRegistro = 'nenhuma';
  enumAba = EnumAbaRegistro;
  abaVisitada: {} = {};

  abasSalvasControle: ControleAbaRegistroTO[] = [];
  abasSalvas: Set<string> = new Set<string>();

  abrirAbaAjuda = false;

  governancaValidada = false;

  anoReferencia: number;
  anoAtualizacaoDados: number;
  exibeMensagemAtualizacao = true;
  anoCicloAtual = new Date().getFullYear();
  bloqueiaSubmeterAjustesValidarDados = false;

  constructor(
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private messageService: MessageService,
    public app: AppComponent,
    public breadCrumbPrimeNGService: BreadcrumbService,
    private router: Router,
    public keycloakService: KeycloakService,
    private confirmationService: ConfirmationService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private route: ActivatedRoute,
    @Inject(DOCUMENT) private document: Document,
    public validacaoCadastroRegistro: ValidacaoCadastroRegistro,
    private apiCooperativaService: ApiCooperativaService,
    private apiPj: ApiPessoaJuridicaService,
    private apiControleAbas: ApiControleAbasRegistroService,
    public validacaoProcessoRegistro: ValidacaoProcessoRegistro,
    private cdr: ChangeDetectorRef,
    private apiGovernancaService: ApiGovernancaService
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: 'inicio' },
      { label: 'Cadastro', routerLink: '/registro/cadastro' },
    ]);
  }

  ngOnInit() {
    this.abaVisitada[EnumAbaRegistro.Documentos] = false;
    this.abaVisitada[EnumAbaRegistro.Governanca] = false;
    this.abaVisitada[EnumAbaRegistro.SegmentacaoEFiliais] = false;
    this.abaVisitada[EnumAbaRegistro.DadosGerais] = false;
    this.abaVisitada[EnumAbaRegistro.Contatos] = false;

    const sub = this.route.queryParamMap.subscribe((params) => {
      this.etapaInicial = (params.get('etapa') as EtapaRegistro) || 'nenhuma';
    });

    sub.unsubscribe();

    this.document.body.scrollTop = 0;

    this.route.queryParams.subscribe((params) => {
      this.idCooperativa = params['id_cooperativa'];
      if (this.idCooperativa) {
        this.obterAbasSalvas(Number(this.idCooperativa));
      }
    });

    if (this.keycloakService.isUsuarioCooperativa || this.idCooperativa) {
      this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          this.cooperativa = coop;

          this.apiPj.buscaUnidadeResponsavel(this.cooperativa.pessoaJuridica.ufSigla).then((pj) => {
            this.nomePessoaJuridica = pj.data.nomeFantasia;
          });

          this.cooperativa.parecer = this.cooperativa.parecer == null ? new Parecer() : this.cooperativa.parecer;
          if (ProgressoMacroEnum.MANUTENCAO_10 === coop.progressoManutencaoMacro) {
            return this.router.navigateByUrl('/registro/manutencaoCadastro');
          }
          if (coop.progressoMicro !== ProgressoMicroEnum.PRE_CADASTRO_0_0 && !coop.arquivado) {
            this.carregarTela(coop);
          }
        }
      });
    }
  }

  arquivoConformidadeLocal: string = null;

  onUploadConformidade(chave: string) {
    this.arquivoConformidadeLocal = chave;
    if (this.cooperativa?.parecer) {
      this.cooperativa.parecer.arquivoConformidade = chave;
    }
  }

  carregarTela(coopJaCarregada?: Cooperativa) {
    const carregamento = coopJaCarregada
      ? Promise.resolve(coopJaCarregada)
      : this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado);
    carregamento.then((coop) => {
      this.cooperativa = coop;
      this.cooperativa.parecer = this.cooperativa.parecer ?? new Parecer();

      if (!this.cooperativa.parecer.arquivoConformidade && this.arquivoConformidadeLocal) {
        this.cooperativa.parecer.arquivoConformidade = this.arquivoConformidadeLocal;
      }

      this.verificarLiberacaoCampos();
      this.getAnoAtualizacao();
      this.atualizarCooperativaManutencaoPendencias();
    });
  }

  atualizarAbaSubmeter(mostrarMensagens: boolean = false) {
    if (this.cooperativa) {
      this.mensagensSubmeter = [];
      this.apiCadastroRegistroService.validarSubmeterIgnoreCiclo(this.cooperativa.id, false).then((res) => {
        if (res && res.data) {
          const dadosValidacao = res.data;
          this.podeSubmeter = dadosValidacao.validado;

          if (!dadosValidacao.validado && dadosValidacao.mensagens && dadosValidacao.mensagens.length > 0) {
            this.mensagensSubmeter = dadosValidacao.mensagens.map((msg: IServiceMessage) => {
              const idxB = msg.message.indexOf('<b>');
              const idxBEnd = msg.message.indexOf('</b>');
              return {
                summary: idxB === -1 || idxBEnd === -1 ? '' : msg.message.substring(idxB + 3, idxBEnd),
                detail: idxB === -1 || idxBEnd === -1 ? msg.message : msg.message.substring(idxBEnd + 4),
              };
            });
          }

          this.apiCooperativaService.getStatus(this.cooperativa.id).then((reStatus) => {
            if (reStatus && reStatus.data) {
              this.statusCooperativa = reStatus.data;
            }
            if (
              dadosValidacao.validado &&
              (this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2 ||
                this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2 ||
                this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_CADASTRO_1_1)
            ) {
              // this.classeTopoSubmeter = this.classeFixaIcone + ' material-icons color-text-green ml-1 check_circle';
              // } else {
              this.classeTopoSubmeter = this.classeFixaIcone + ' material-icons color-text-red  ml-1 warning';
              this.submeterExibir = true;
            } else {
              this.submeterExibir = false;
            }
          });
        }

        // Caso tenha pendências
        this.atualizarVerificacaoSubmeterPendencias();
      });
    }
  }

  atualizarVerificacaoSubmeterPendencias() {
    if (this.cooperativa) {
      this.apiValidacaoDadosService.obterPendenciasAbas(this.cooperativa.id).then((validacaoPendencia) => {
        if (validacaoPendencia && validacaoPendencia.data != null) {
          const pendencias = validacaoPendencia.data;
          this.podeProgredir = pendencias.podeProgredir;

          if (
            pendencias.validado &&
            (this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1 ||
              this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1)
          ) {
            //this.classeTopoSubmeter = this.classeFixaIcone + ' material-icons color-text-red  ml-1 warning';
            this.submeterPendencias = true;
          } else {
            this.submeterPendencias = false;
          }
        }

        // PREENCHIMENTO
        if (
          this.cooperativa.progressoMicro === ProgressoMicroEnum.PRE_CADASTRO_0_0 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_CADASTRO_1_1 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2
        ) {
          this.mostrarSubmeter = true;
          this.mostrarAjustes = false;
          this.mostrarConformidade = false;
          this.mostrarVisitaTecnica = false;
          this.mostrarDeliberacao = false;
        }

        // AJUSTES
        if (this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1) {
          this.mostrarAjustes = true;
          this.mostrarSubmeter = false;
          this.mostrarConformidade = false;
          this.mostrarVisitaTecnica = false;
          this.mostrarDeliberacao = false;
        }

        // CONFORMIDADE
        if (this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1) {
          this.mostrarConformidade = true;
          this.mostrarAjustes = false;
          this.mostrarSubmeter = false;
          this.mostrarVisitaTecnica = false;
          this.mostrarDeliberacao = false;
        }
        // VISITA TECNICA
        if (
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_PROPOSTA_DATA_4_1 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ACEITE_DATA_VISITA_4_2 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.VISITA_TECNICA_MARCADA_4_3
        ) {
          this.mostrarVisitaTecnica = true;
          this.mostrarAjustes = false;
          this.mostrarSubmeter = false;
          this.mostrarConformidade = false;
          this.mostrarDeliberacao = false;
        }
        // DELIBERAÇÃO
        if (
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.REGISTROS_INDEFERIDOS_OCE_5_2 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3 ||
          this.cooperativa.progressoMicro === ProgressoMicroEnum.EMISSAO_COM_APONTAMENTOS_6_2
        ) {
          this.mostrarDeliberacao = true;
          this.mostrarAjustes = false;
          this.mostrarSubmeter = false;
          this.mostrarConformidade = false;
          this.mostrarVisitaTecnica = false;
        }
      });
    }
  }

  openModalConfLegal() {
    this.dialogConfLegal = true;
  }

  deferirCoformidade() {
    this.fecharDialogCiente();
    if (this.cooperativa) {
      const arquivo = this.cooperativa.parecer?.arquivoConformidade ?? this.arquivoConformidadeLocal;
      this.apiValidacaoDadosService.finalizarConformidade(this.cooperativa.id, arquivo, true).then((res) => {
        this.router.navigate(['/registro/processo'], {
          queryParams: { id_cooperativa: this.cooperativa.id },
          skipLocationChange: false,
        });
      });
    }
  }

  exibirMensagens(mensagens: IServiceMessage[], titulo: string = null) {
    if (mensagens) {
      this.messageService.clear();
      mensagens.forEach((mens) => {
        this.messageService.add({ severity: 'warn', summary: titulo, detail: mens.message, life: 10000 });
      });
    }
  }

  indeferirCoformidade() {
    if (this.cooperativa) {
      const arquivo = this.cooperativa.parecer?.arquivoConformidade ?? this.arquivoConformidadeLocal;
      this.apiValidacaoDadosService.finalizarConformidade(this.cooperativa.id, arquivo, false).then((res) => {
        this.router.navigate(['/registro/processo'], {
          queryParams: { id_cooperativa: this.cooperativa.id },
          skipLocationChange: false,
        });
      });
    }
  }

  submeterCadastro() {
    this.confirmationService.confirm({
      message: 'As informações e documentos inseridos no sistema não poderão mais ser alterados e serão recebidos para análise.',
      key: 'submeterCadastro',
      accept: () => {
        this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
          if (coop) {
            this.apiCadastroRegistroService.submeterCadastro(coop.id).then((res) => {
              if (res != null) {
                if (res.data) {
                  if (this.keycloakService.isUsuarioCooperativa && !coop.cadastroSemUsuario) {
                    this.router.navigate(['/registro/requerimento-concluido']);
                  }
                  if (this.keycloakService.isUsuarioNacional || this.keycloakService.isUsuarioEstadual || coop.cadastroSemUsuario) {
                    this.router.navigate(['/registro/processo'], {
                      queryParams: { id_cooperativa: coop.id },
                    });
                  } else {
                    this.router.navigate(['/registro/requerimento-concluido']);
                  }
                } else {
                  this.router.navigate(['/registro/cadastro']);
                }
              }
            });
          }
        });
      },
    });
  }

  public change(index: number): void {
    if (this.cooperativa?.id) {
      this.obterAbasSalvas(this.cooperativa.id);
    }
    // Não permite voltar (a não ser clicando explicitamente na aba)
    if (index >= this.index || index === undefined) {
      this.index = index;
      this.atualizarForms(index);
      this.abaDestino = index;
    }
  }

  ngOnDestroy(): void {}

  fecharDialogo() {
    this.dialogoSalvarAba = false;
  }

  fecharDialogCiente() {
    this.dialogConfLegal = false;
  }

  salvarAba() {
    if (this.salvandoAba) {
      return;
    }
    this.salvandoAba = true;
    if (this.dadosGeraisForm) {
      if (this.dadosGeraisForm.getAlteracaoForm()) {
        this.dadosGeraisForm.desativaEventoForm();
        this.dadosGeraisForm.salvarDadosGerais(this.abaOrigem);
      }
    }

    if (this.negocioForm) {
      if (this.negocioForm.getAlteracaoForm()) {
        this.negocioForm.desativaEventoForm();
        this.negocioForm.salvarNegocio(this.abaOrigem);
      }
    }

    if (this.governancaForm) {
      if (this.governancaForm.getAlteracaoForm()) {
        this.governancaForm.desativaEventoForm();
        this.governancaForm.salvar(this.abaOrigem);
      }
    }

    if (this.contatoForm) {
      if (this.contatoForm.getAlteracaoForm()) {
        this.contatoForm.desativaEventoForm();
        this.contatoForm.salvar(this.abaOrigem);
      }
    }

    if (this.documentosForm) {
      if (this.documentosForm.getAlteracaoForm()) {
        this.documentosForm.desativaEventoForm();
        this.documentosForm.salvar(this.abaOrigem);
      }
    }

    this.dialogoSalvarAba = false;
    this.atualizarAbaSubmeter();
    this.resolverSaida(true);

    // Cooldown para impedir duplo-clique disparando as mesmas gravações novamente
    // (as chamadas acima são fire-and-forget, sem uma promise unificada para aguardar).
    // erroSalvar() já reseta a flag mais cedo em caso de erro.
    setTimeout(() => {
      this.salvandoAba = false;
    }, 1500);
  }

  naoSalvaAba() {
    this.salvandoAba = false;
    if (this.dadosGeraisForm) {
      this.dadosGeraisForm.desativaEventoForm();
      this.dadosGeraisForm.carregarTela();
    }

    if (this.negocioForm) {
      this.negocioForm.desativaEventoForm();
      this.negocioForm.carregarTela();
    }

    if (this.governancaForm) {
      this.governancaForm.desativaEventoForm();
      this.governancaForm.carregaTela();
    }

    if (this.contatoForm) {
      this.contatoForm.desativaEventoForm();
      this.contatoForm.carregarTela();
    }

    if (this.documentosForm) {
      this.documentosForm.desativaEventoForm();
      this.documentosForm.carregaDocumento();
    }

    this.dialogoSalvarAba = false;
    this.index = this.abaDestino;
    this.resolverSaida(true);
  }

  mudandoAba(event, idxNovo) {
    if (event) {
      event.stopPropagation();
    }

    if (this.index !== idxNovo) {
      this.abaOrigem = this.index;
      //this.abaOrigem = this.abaDestino;
      //this.index = idxNovo;
      //this.abaDestino = this.index;

      if (this.podeModificarOsCampos) {
        this.controlaDialogoSalvarAba();
      }

      if (!this.dialogoSalvarAba) {
        this.index = idxNovo;
      } else {
        this.abaDestino = idxNovo;
      }

      this.carregarTela();
      if ((idxNovo === 3 && this.negocioForm) || (idxNovo === 4 && this.contatoForm)) {
        this.atualizarForms(idxNovo);
      }

      this.atualizarAbaSubmeter();
    }
  }

  mudouAba(event) {
    this.abaVisitada[this.abaOrigem] = true;
    this.abaOrigem = this.abaDestino;
    this.index = event.index;
    this.abaDestino = this.index;
  }

  podeSair(): boolean | Promise<boolean> {
    if (this.index === this.abaSubmeter || !this.podeModificarOsCampos || !this.possuiAlteracoesOuEdicaoAberta()) {
      return true;
    }
    this.dialogoSalvarAba = true;
    return new Promise<boolean>((resolve) => {
      this.resolverSaidaPagina = resolve;
    });
  }

  private possuiAlteracoesOuEdicaoAberta(): boolean {
    return this.possuiAlteracoes() || !!this.governancaForm?.algumaEdicaoAtiva();
  }

  private resolverSaida(podeSair: boolean) {
    if (this.resolverSaidaPagina) {
      const resolve = this.resolverSaidaPagina;
      this.resolverSaidaPagina = null;
      resolve(podeSair);
    }
  }


  aoOcultarDialogoSalvarAba() {
    this.resolverSaida(false);
  }


  @HostListener('window:beforeunload', ['$event'])
  avisarSaidaNavegador(event: BeforeUnloadEvent) {
    if (this.podeModificarOsCampos && this.possuiAlteracoesOuEdicaoAberta()) {
      event.preventDefault();
      event.returnValue = true;
    }
  }

  possuiAlteracoes() {
    let possuiAlteracao = false;
    if (this.documentosForm) {
      if (this.documentosForm.getAlteracaoForm()) {
        possuiAlteracao = true;
      }
    }
    if (this.dadosGeraisForm) {
      if (this.dadosGeraisForm.getAlteracaoForm()) {
        possuiAlteracao = true;
      }
    }
    if (this.negocioForm) {
      if (this.negocioForm.getAlteracaoForm()) {
        possuiAlteracao = true;
      }
    }
    if (this.governancaForm) {
      if (this.governancaForm.getAlteracaoForm()) {
        possuiAlteracao = true;
      }
    }
    if (this.contatoForm) {
      if (this.contatoForm.getAlteracaoForm()) {
        possuiAlteracao = true;
      }
    }

    return possuiAlteracao;
  }

  atualizarForms(index: number) {
    if (index === 0 && this.documentosForm) {
      this.documentosForm.carregaDocumento();
    }
    if (index === 1 && this.dadosGeraisForm) {
      this.dadosGeraisForm.carregarTela();
    }
    if (index === 2 && this.governancaForm) {
      this.governancaForm.carregaTela();
    }
    if (index === 3 && this.negocioForm) {
      this.negocioForm.carregarTela();
    }
    if (index === 4 && this.contatoForm) {
      this.contatoForm.carregarTela();
    }
    if (index === 5) {
      this.atualizarAbaSubmeter();
    }
  }

  cancelaSalvarAba() {
    this.abaDestino = this.abaOrigem;
    this.dialogoSalvarAba = false;
    this.resolverSaida(false);
  }

  erroSalvar($event: boolean) {
    if (this.salvandoAba) {
      this.index = this.abaOrigem;
      this.salvandoAba = false;
    } else {
      this.abaDestino = this.index;
    }
  }

  controlaDialogoSalvarAba() {
    if (this.dadosGeraisForm) {
      if (this.dadosGeraisForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.documentosForm) {
      if (this.documentosForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.governancaForm) {
      if (this.governancaForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.negocioForm) {
      if (this.negocioForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.contatoForm) {
      if (this.contatoForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }
  }

  onSalvarDadosGerais(event) {
    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarNegocio(event) {
    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarGovernancia(event) {
    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarContato(event) {
    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarDocumentos(event) {
    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  submeterCadastroValidacao() {
    if (this.cooperativa) {
      this.apiValidacaoDadosService
        .finalizarAjustes(this.cooperativa.id, this.cooperativa.parecer != null ? this.cooperativa.parecer.arquivoConformidade : null)
        .then((res) => {
          this.router.navigate(['/registro/processo'], {
            queryParams: { id_cooperativa: this.cooperativa.id },
            skipLocationChange: false,
          });
        });
    }
  }

  verificarLiberacaoCampos() {
    if (this.cooperativa) {
      this.apiCadastroRegistroService.podePreencherCadastroRegistroBasico(this.cooperativa.id).then((res) => {
        if (res != null && res.data != null) {
          this.podeModificarOsCampos = res.data;
        }
      });
    }
  }

  private obterAbasSalvas(idCooperativa: number): void {
    this.apiControleAbas.obterControleAbasRegistroPorCooperativa(Number(idCooperativa)).subscribe((resp) => {
      if (resp.data) {
        this.abasSalvasControle = resp.data;
      }
      this.abasSalvas = new Set<string>(this.abasSalvasControle.filter((a) => a.aba).map((aba) => aba.aba));
    });
  }

  navegarTutorial() {
    const link = document.createElement('a');
    document.body.appendChild(link);
    link.target = '_blank';
    link.setAttribute('visibility', 'hidden');
    link.href = 'https://www.capacita.coop.br/videos/soucoop-atualizacao-cadastral-na-pratica';
    link.click();
  }

  atualizarCooperativaManutencaoPendencias() {
    if (this.cooperativa) {
      this.buscarEstadoPreenchimentoGovernanca();
      this.apiValidacaoDadosService.obterCooperativaManutencaoAbas(this.cooperativa.id, this.anoCicloAtual).then((pendencias) => {
        this.cooperativaManutencao = pendencias;
        if (
          pendencias &&
          (pendencias.abaDocumentos === CooperativaManutencaoStatus.SALVO_PENDENCIAS ||
            pendencias.abaDadosGerais === CooperativaManutencaoStatus.SALVO_PENDENCIAS ||
            pendencias.abaGovernanca === CooperativaManutencaoStatus.SALVO_PENDENCIAS ||
            pendencias.abaSegmentacaoFilial === CooperativaManutencaoStatus.SALVO_PENDENCIAS ||
            pendencias.abaContatos === CooperativaManutencaoStatus.SALVO_PENDENCIAS ||
            pendencias.abaSubmeter === CooperativaManutencaoStatus.SALVO_PENDENCIAS)
        ) {
          this.bloqueiaSubmeterAjustesValidarDados = true;
        } else if (
          pendencias && // validar se for cooperativa e tiver ajustes não habilitar o botão - this.keycloakService.isUsuarioCooperativa == true
          (pendencias.abaDocumentos === CooperativaManutencaoStatus.AJUSTES ||
            pendencias.abaDadosGerais === CooperativaManutencaoStatus.AJUSTES ||
            pendencias.abaGovernanca === CooperativaManutencaoStatus.AJUSTES ||
            pendencias.abaSegmentacaoFilial === CooperativaManutencaoStatus.AJUSTES ||
            pendencias.abaContatos === CooperativaManutencaoStatus.AJUSTES ||
            pendencias.abaSubmeter === CooperativaManutencaoStatus.AJUSTES)
        ) {
          this.bloqueiaSubmeterAjustesValidarDados = false;
        }
      });
    }
  }

  recarregarStatusAbas(): void {
    this.atualizarCooperativaManutencaoPendencias();
  }

  private buscarEstadoPreenchimentoGovernanca(): Promise<void> {
    if (!this.cooperativa) {
      return Promise.resolve();
    }
    return this.apiGovernancaService
      .buscarPendencias(this.cooperativa.id)
      .then((res) => {
        this.estadoPreenchimentoGovernanca = res?.data?.estadoPreenchimento ?? null;
        this.cdr.markForCheck();
      })
      .catch(() => {
        this.estadoPreenchimentoGovernanca = null;
      });
  }

  getAnoAtualizacao() {
    if (this.cooperativa.pessoaJuridica.ramo.id) {
      this.apiCooperativaService.buscaUltimoCadastroPeriodoAtualizacaoPorRamo(this.cooperativa.pessoaJuridica.ramo.id).then((response) => {
        if (response['data']) {
          this.anoAtualizacaoDados = response['data'].ano ? response['data'].ano : new Date().getFullYear();
        } else {
          this.anoAtualizacaoDados = new Date().getFullYear();
        }
        this.anoReferencia = +this.anoAtualizacaoDados - 1;
        this.getUltimaAprovacaoCooperativa();
      });
    }
  }

  getUltimaAprovacaoCooperativa() {
    if (this.cooperativa.id && this.keycloakService.isUsuarioCooperativa) {
      this.apiCooperativaService.buscaUltimaAprovacaoCooperativa(this.cooperativa.id).then((response) => {
        if (response.data) {
          if (response.data.ano === this.anoAtualizacaoDados) {
            this.exibeMensagemAtualizacao = false;
          } else {
            this.exibeMensagemAtualizacao = true;
          }
        } else {
          this.exibeMensagemAtualizacao = true;
        }
      });
    } else {
      this.exibeMensagemAtualizacao = false;
    }
  }
}
