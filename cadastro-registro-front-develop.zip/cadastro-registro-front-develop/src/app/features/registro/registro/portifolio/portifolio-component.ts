import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Cooperativa} from '@cadastro-registro-api/models/Cooperativa';
import {LanguageService} from '@shared/languages/calendar-primeng/language-calendar';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import {ValidacaoDados} from '@shared/validacaoDados/validacao/validacao-dados.service';
import {ValidacaoGovernancaRegistro} from '@shared/registro/governanca/validacao/validacao-governanca-registro.service';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { PessoaSegmProdServ } from '@cadastro-registro-api/models/PessoaSegmProdServ';
import { ApiProdutoservicoService } from '@cadastro-registro-api/services/api-produtoservico.service';;
import { ApiManutencaoNegocioService } from '../../manutencao/negocio/service/api-manutencao-negocio.service';
import { MessageService } from 'primeng/api';
import {saveAs} from 'file-saver';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { Negocio } from '@cadastro-registro-api/models/Negocio';
import { DescricaoComplementarTO } from 'src/app/api/models/DescricaoComplementarTO';
import { ControlePortifolioTO } from 'src/app/api/models/ControlePortifolioTO';
import { ApiControlePortifolioService } from 'src/app/api/services/api-controle-portifolio.service';
import { ApiRamoService } from 'src/app/api/services/api-ramo.service';
import { Ramo } from 'src/app/api/models/Ramo';



@Component({
  selector: 'app-portifolio-component',
  templateUrl: './portifolio-component.html',
  styleUrls: ['./portifolio-component.scss'],
})
export class PortifolioComponent implements OnInit {

  @Input() cooperativa : Cooperativa;
  @Input() somenteLeitura = false;

  private RAMOS_SEGMENTO_UNICO = ['TRABALHO, PRODUÇÃO DE BENS E SERVIÇOS', 'CRÉDITO'];
  listaSegmento: Segmento[];
  listaProdutoServico: Map<Segmento,PessoaSegmProdServ[]>;
  listaPessoaSegmProdServ: PessoaSegmProdServ[];
  listaSegmentoSelecionado: Segmento[];
  quantidadeSegmentos: number;
  negocio: Negocio;
  listaProdutoServicoSelecionado: Produtoservico[] = [];
  listaPessoaSegmProdSevNova: PessoaSegmProdServ[];
  listaDescricao: DescricaoComplementarTO[] = [];
  descricaoComplementar: string;
  @Output() listaMudou = new EventEmitter<Produtoservico[] | PessoaSegmProdServ[]>();
  novaTag: string = '';
  novaTagMap: { [key: string]: string } = {};

  controlePortifolio = new ControlePortifolioTO();
  ramo: Ramo;
  display: boolean = false;

  constructor(
    public language: LanguageService,
    public keycloakService: KeycloakService,
    public validacaoDados: ValidacaoDados,
    public validacaoGovernanca: ValidacaoGovernancaRegistro,
    private apiProdutoservicoService: ApiProdutoservicoService,
    private negocioApi: ApiManutencaoNegocioService,
    private messageService: MessageService,
    private segmentoApi: ApiSegmentoService,
    private apiControlePortifolio: ApiControlePortifolioService,
    private ramoApi: ApiRamoService
  ) {
  }

  ngOnInit() {
    this.init();
  }

  async init() {
    this.listaSegmento = new Array<Segmento>();
    await this.buscarRamo();
    await this.buscarSegmentos();
    await this.buscarListaProdutoServico();
    await this.carregarControlePortifolio();
  }

  buscarRamo(){
    if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
      this.ramoApi.getRamo(this.cooperativa.pessoaJuridica.ramo.id)
      .then(res => {
        this.ramo = res;
        this.quantidadeSegmentos = this.getQtdSegmentos();
      });
    }
  }

  buscarSegmentos() {
    if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
      this.segmentoApi.buscaPorRamo(this.cooperativa.pessoaJuridica.ramo.id).then((response) => {
        if (response && response.data) {
          this.listaSegmento = response.data;
          this.atualizaLstaProdutoServico();
        }
      });
    }
  }

  getQtdSegmentos(): number {
    if (this.ramo != null && this.ramo.segmentoUnico != null && this.ramo.segmentoUnico) {
      return 1;
    } else {
      return this.listaSegmento.length;
    }
  }

  atualizaLstaProdutoServico() {
    this.listaPessoaSegmProdServ = [];
    this.listaProdutoServico = new Map();
    if (this.listaSegmentoSelecionado) {
      this.listaSegmentoSelecionado.forEach(segmento => {
        this.apiProdutoservicoService.buscaPorRamoSegmento(segmento.id, this.cooperativa.pessoaJuridica.ramo.id).then(res => {
          if (res?.data) {
            this.listaProdutoServico.set(segmento, this.monstaListaPessoaSegmProdServ(segmento, res.data));
          }
          this.validaListaListaPessoaSegmProdSevNova();
        });

        const prodServ = new PessoaSegmProdServ();
        prodServ.pessoaJuridica = this.cooperativa.pessoaJuridica;
        prodServ.segmento = segmento;
        this.listaPessoaSegmProdServ.push(prodServ);

      });
    }

    if (this.listaPessoaSegmProdSevNova?.length > 0) {
      this.listaPessoaSegmProdSevNova = this.listaPessoaSegmProdSevNova.filter(psps =>
        this.listaSegmentoSelecionado.some(ss => ss.id === psps.segmento.id)
      );
    }
    this.listaMudou.emit(this.listaPessoaSegmProdSevNova);
  }

  emitirMudanca(){
    this.listaMudou.emit(this.listaPessoaSegmProdSevNova);
  }
  exportarNegocio() {
    this.negocioApi
      .exportarRelatorioSegmento(this.cooperativa.id)
      .then((response) => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Negocio_Segmentos.xlsx');
      })
      .catch((error) => {
        if (error.status && error.status === 404) {
          this.messageService.add({ severity: 'warn', detail: 'Nenhum registro de negócio encontrado', life: 100000 });
        } else {
          this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
        }
      });
  }

  buscarListaProdutoServico() {
    this.negocioApi.getNegocio(this.cooperativa.id).then((res) => {

      // getNegocio devolve NegocioTO (subconjunto de Negocio)
      this.negocio = res.data as unknown as Negocio;

      this.listaSegmentoSelecionado = this.negocio.segmentos.filter(n=> n.ramo.id === this.cooperativa.pessoaJuridica.ramo.id && n.ativo);

      this.quantidadeSegmentos = this.getQtdSegmentos();

      this.listaPessoaSegmProdServ = this.negocio.listaPessoaSegmProdServ.filter(l =>
        this.listaSegmentoSelecionado.some(seg => seg.id === l.segmento.id)
      );

      this.listaPessoaSegmProdSevNova = [...this.listaPessoaSegmProdServ];

      this.listaProdutoServicoSelecionado = this.negocio.produtos.filter(produto =>
        produto.segmento && this.listaSegmentoSelecionado.some(seg => seg.id === produto.segmento.id)
    );

    this.listaSegmentoSelecionado.forEach((segmento) => {
          if (!this.listaProdutoServico.has(segmento)) {
              this.apiProdutoservicoService.buscaPorRamoSegmento(segmento.id, this.cooperativa.pessoaJuridica.ramo.id).then((ramoSeg) => {
                  if (ramoSeg && ramoSeg.data) {
                      const produtosProcessados = this.monstaListaPessoaSegmProdServ(segmento, ramoSeg.data);
                      this.listaProdutoServico.set(segmento, produtosProcessados);
                  }
              });
          }
      });

    });

    this.montarListaDescricao();

  }


  montarListaDescricao() {
    this.listaDescricao = [];
    this.listaPessoaSegmProdSevNova?.forEach(element => {
      const descricaoTO = new DescricaoComplementarTO();
      descricaoTO.produtoServicoId = element.produtoServico?.id;
      descricaoTO.segmentoId = element.segmento?.id;
      descricaoTO.exibir = !!element?.produtoServico?.descricaoComplementar;
      descricaoTO.descricao = element.descricaoComplementar?.split(',') || [];
      this.listaDescricao.push(descricaoTO);
    });
  }

  validarTag(event: { value: string }, pessoa: PessoaSegmProdServ): void {
    const novaTag = event.value.trim();
    const tags = (pessoa.descricaoComplementar || '').split(',').map(t => t.trim()).filter(Boolean);

    if (novaTag.length > 20) {
      this.messageService.add({ severity: 'warn', summary: 'Limite de caracteres', detail: 'Cada tag pode ter no máximo 20 caracteres' });
      return;
    }

    if (tags.includes(novaTag)) {
      this.messageService.add({ severity: 'info', detail: 'Tag já adicionada.' });
      return;
    }

    if (tags.length >= 10) {
      this.messageService.add({ severity: 'warn', detail: 'Máximo de 10 tags.' });
      return;
    }

    tags.push(novaTag);
    pessoa.descricaoComplementar = tags.join(',');
    this.houveEscritaTexto(pessoa);
  }


  atualizaSegmentosProdutosServicos(){


    let listaAuxiliar = this.listaPessoaSegmProdSevNova;

    this.listaPessoaSegmProdSevNova = [];

    this.listaProdutoServicoSelecionado.forEach(produtoServico => {
      const adiciona = this.listaSegmentoSelecionado.find(segmento => segmento.id == produtoServico.segmento.id);
      if(adiciona){
        let pessoaSegmProdServ = null;
        pessoaSegmProdServ = this.criaPessoaSegmProdServ(produtoServico, produtoServico.segmento);
        this.listaPessoaSegmProdSevNova.push(pessoaSegmProdServ);
      }
    });

    this.listaSegmentoSelecionado.forEach(segmento => {
      const listSegmentoExiste = this.listaPessoaSegmProdSevNova.filter(pessoaSegmProdServ => pessoaSegmProdServ.segmento.id == segmento.id);
      if(listSegmentoExiste.length == 0){
        const pessoaSegm = this.criaPessoaSegmProdServ(null, segmento);
        this.listaPessoaSegmProdSevNova.push(pessoaSegm);
      }
    });


    let houveEscrita = false;
    listaAuxiliar.forEach(produto => {
      if(produto.produtoServico != null){
        houveEscrita = true;
        this.houveEscritaTexto(produto);
      }
    });
    // houveEscritaTexto() já reconstrói a lista internamente; só precisa reconstruir
    // aqui se o loop não chamou houveEscritaTexto() nenhuma vez.
    if (!houveEscrita) {
      this.montarListaDescricao();
    }
    this.listaMudou.emit(this.listaProdutoServicoSelecionado)
  }

  criaPessoaSegmProdServDescricao(produtoServico?: Produtoservico, segmento?: Segmento, descricao?: string){

    let existe = this.existeNaListaNova(produtoServico, segmento, descricao);

    if(this.listaPessoaSegmProdSevNova != null && existe && descricao != null){
      return this.criaPessoaSegmProdServ(produtoServico, segmento, descricao);
    } else {
      return this.criaPessoaSegmProdServ(produtoServico, segmento);
    }
  }

  existeNaListaNova(produtoServico?: Produtoservico, segmento?: Segmento, descricao?: string){
    return this.listaPessoaSegmProdSevNova.some(element => element.produtoServico?.id == produtoServico?.id && element.segmento?.id == segmento.id);
  }

  houveEscritaTexto(pessoaSegmentoAtual?: PessoaSegmProdServ){

    const existe = this.existeNaListaNova(pessoaSegmentoAtual.produtoServico, pessoaSegmentoAtual.segmento, pessoaSegmentoAtual.descricaoComplementar);

    if (
      this.listaPessoaSegmProdSevNova != null &&
      this.listaPessoaSegmProdSevNova.length !== 0 &&
      existe
    ) {
      const produtoSemDescricao = this.listaPessoaSegmProdSevNova.find(
        (element) =>
          element.segmento.id === pessoaSegmentoAtual.produtoServico.segmento.id &&
          element.produtoServico.id === pessoaSegmentoAtual.produtoServico.id
      );

      produtoSemDescricao.descricaoComplementar = pessoaSegmentoAtual?.descricaoComplementar;
    }

    this.montarListaDescricao();
  }

  criaPessoaSegmProdServ(produtoServico?: Produtoservico, segmento?: Segmento, descricao?: string): PessoaSegmProdServ {
    const pessoaSegmProdServ = new PessoaSegmProdServ();
    pessoaSegmProdServ.pessoaJuridica = this.cooperativa.pessoaJuridica;
    pessoaSegmProdServ.segmento = segmento;
    pessoaSegmProdServ.produtoServico = produtoServico;
    pessoaSegmProdServ.descricaoComplementar = descricao || '';
    return pessoaSegmProdServ;
  }

  monstaListaPessoaSegmProdServ(segmento: Segmento, produtos: Produtoservico[]): PessoaSegmProdServ[] {
    let listaSegmentoCompleto: PessoaSegmProdServ[] = [];

    produtos.forEach(element => {
      let pessoaSegmentoComplto = new PessoaSegmProdServ();
      pessoaSegmentoComplto.produtoServico = element;
      pessoaSegmentoComplto.segmento = segmento;
      pessoaSegmentoComplto.descricaoComplementar = this.montaDescricaoComplementar(element);
      listaSegmentoCompleto.push(pessoaSegmentoComplto);
    });

    return listaSegmentoCompleto;
  }

  montaDescricaoComplementar(element: Produtoservico): string{

    let descricao = null;

    if(element != null && element.descricaoComplementar && this.listaPessoaSegmProdServ != null){
      this.listaPessoaSegmProdServ.forEach(pessoaSegmentCompleta => {
        if(pessoaSegmentCompleta.produtoServico != null && pessoaSegmentCompleta.produtoServico.id == element.id){
          descricao = pessoaSegmentCompleta.descricaoComplementar;
        }
      });
    }

    return descricao;
  }

  validaExibicaoDescricao(pessoaSegmenAtual?: PessoaSegmProdServ){
    if(pessoaSegmenAtual.produtoServico.descricao == "Outros produtos lácteos"){

    }

    this.montarListaDescricao();

    if(pessoaSegmenAtual != null && this.listaDescricao != null){
      const produto = this.listaDescricao.find(element => element.produtoServicoId == pessoaSegmenAtual.produtoServico.id && element.segmentoId == pessoaSegmenAtual.segmento.id);
      return produto?.exibir;
    } else {
      return false;
    }
  }

  validaProdutoDescricao(produtoServico?: Produtoservico): boolean{
    const existe = this.listaPessoaSegmProdServ.some(element =>
      element.segmento.id == produtoServico.segmento.id
      && element.produtoServico != null
      && element.produtoServico.id == produtoServico.id
      && produtoServico.descricaoComplementar
      && element.descricaoComplementar != null
    );

    if(existe){
      return true;
    } else {
      return false;
    }
  }

  validaListaListaPessoaSegmProdSevNova() {
    if (this.listaDescricao != null) {
      this.listaDescricao.forEach(descricao => {
        this.listaProdutoServico.forEach((valor, chave) => {
          if (descricao.segmentoId == chave.id && descricao.descricao != null) {
            const item = valor.find(v => v.produtoServico.id == descricao.produtoServicoId);
            if (item) {
              item.descricaoComplementar = descricao.descricao.join(',');
            }
          }
        });
      });
    }
    this.atualizaSegmentosProdutosServicos();
  }


  carregarControlePortifolio() {
    this.apiControlePortifolio.obterControlePortifolioUfNacional().subscribe(response => {
      this.controlePortifolio = response.data;
      if(this.controlePortifolio && !this.controlePortifolio.informarCampos){
        this.apiControlePortifolio.getControlePortifolioUf(this.cooperativa.pessoaJuridica.ufSigla).subscribe(responseUf => {
          if(responseUf && responseUf.data){
            this.controlePortifolio = responseUf.data;
          }
        });
      }
    });
  }

  adicionarTag(pessoa: PessoaSegmProdServ) {
    const key = pessoa.produtoServico?.id;
    const tag = this.novaTagMap[key]?.trim();

    if (!tag || tag.length === 0) return;

    if (tag.length > 20) {
      this.messageService.add({ severity: 'warn', detail: 'Tag deve ter no máximo 20 caracteres.' });
      return;
    }

    const tags = pessoa.descricaoComplementar?.split(',').map(t => t.trim()).filter(t => t) || [];

    if (tags.length >= 20) {
      this.messageService.add({ severity: 'warn', detail: 'Máximo de 20 tags.' });
      return;
    }

    if (tags.includes(tag)) {
      this.messageService.add({ severity: 'warn', detail: 'Tag já adicionada.' });
      return;
    }

    tags.push(tag);
    pessoa.descricaoComplementar = tags.join(',');
    this.novaTagMap[key] = '';
    this.houveEscritaTexto(pessoa);
    this.listaMudou.emit(this.listaPessoaSegmProdSevNova);
  }


  isLimiteTags(pessoa: PessoaSegmProdServ): boolean {
    if (!pessoa.descricaoComplementar) return false;

    const tags = pessoa.descricaoComplementar
      .split(',')
      .map(tag => tag.trim())
      .filter(tag => tag.length > 0);

    return tags.length >= 20;
  }

  verificaVirgula(event: KeyboardEvent, pessoa: PessoaSegmProdServ) {
    if (event.key === ',') {
      event.preventDefault();
      this.adicionarTag(pessoa);
    }
  }

  removerTag(index: number, pessoa: PessoaSegmProdServ) {
    const tags = pessoa.descricaoComplementar?.split(',').filter(tag => tag.trim().length > 0) || [];

    tags.splice(index, 1); // remove a tag

    // Atualiza a string concatenada ou zera
    pessoa.descricaoComplementar = tags.length > 0 ? tags.join(',') : null;

    this.houveEscritaTexto(pessoa);

    this.listaMudou.emit(this.listaPessoaSegmProdSevNova);
  }

}
