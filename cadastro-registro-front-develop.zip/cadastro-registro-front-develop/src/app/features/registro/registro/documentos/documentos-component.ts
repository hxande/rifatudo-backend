import { Component, OnDestroy, OnInit, QueryList, ViewChild, ViewChildren, Output, EventEmitter, Input } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { MessageService } from 'primeng/api';
import { NgForm } from '@angular/forms';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { GeralService } from '@auth/geral.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ValidacaoDocumento } from '@shared/registro/documentos/validacao/validacao-documento.service';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { AjusteDadosComponent } from '@shared/validacaoDados/ajuste-dados-component';
import { ValidacaoMarcacaoUtil } from '@shared/validacaoDados/validacao/validacao-marcacao.util';
import { Documento } from '@documentacao-api/models/Documento';
import { DocumentacaoVO } from '@documentacao-api/models/DocumentacaoVO';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { DocumentoVO } from '@documentacao-api/models/DocumentoVO';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { FileUploadComponent } from '@gui/file-upload/file-upload/file-upload.component';
import { Repositorio } from '@upload-api/models/Repositorio';
import { ControleAbasRegistroEnum } from '@cadastro-registro-api/models/ControleAbasRegistroEnum';
import { ApiControleAbasRegistroService } from '@cadastro-registro-api/services/api-controle-abas-registro.service';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';

@Component({
  selector: 'app-documentos-component',
  templateUrl: './documentos-component.html',
  styleUrls: ['./documentos-component.scss']
})
export class DocumentosComponent implements OnInit, OnDestroy {


  constructor(private apiDocumentoService: ApiDocumentoService,
    public keycloakService: KeycloakService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private geralService: GeralService,
    private messageService: MessageService,
    private apiPj: ApiPessoaJuridicaService,
    public validacaoDocumento: ValidacaoDocumento,
    public validacaoDados: ValidacaoDados,
    private apiControleAbas: ApiControleAbasRegistroService
  ) { }

  @ViewChild('fileup') fileup: FileUploadComponent;
  @ViewChild('documentosForm') documentosForm: NgForm;
  @ViewChild('ajusteDados') ajusteDadosForm: AjusteDadosComponent;
  @ViewChildren(AjusteDadosComponent) ajusteDadosComponentes: QueryList<AjusteDadosComponent>;
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  @Input() cooperativaManutencao: CooperativaManutencao;
  responsePageDocumentos: IServiceResponse<Documento[]>;
  // documentoAtuais: Documento[];
  documentacaoVO: DocumentacaoVO = null;
  cooperativa: Cooperativa = null;
  mensagensValidacao = Array<{ summary: string; detail: string }>();
  podeModificarOsCampos = false;
  aprovacoes: CooperativaPendencia[] = [];
  houveAlteracaoForm = false;
  cooperativaTemp: Cooperativa;
  salvando = false;
  mapPendencias: Map<string, boolean> = new Map();
  pendenciasEditadas = [];
  nomePessoaJuridica: string;

  ngOnDestroy(): void {

  }

  ngOnInit(): void {
    this.verificarLiberacaoCampos();
    if (this.ajusteDadosForm) {
      this.ajusteDadosForm.carregarAprovacao();
    }
  }

  atualizarMensagensTela() {
    if (this.cooperativaTemp) {

      this.apiCadastroRegistroService.validarDocumentos(this.cooperativaTemp.id).then((res) => {
        this.mensagensValidacao = [];

        if (res && res.data) {
          const dadosValidacao = res.data;
          if (!dadosValidacao.validado) {
            this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
              summary: (msg.message.indexOf('<b>') === -1) ? '' : msg.message.substring((msg.message.indexOf('<b>') + 3), msg.message.indexOf('</b>')),
              detail: (msg.message.indexOf('<b>') === -1) ? msg.message : msg.message.substring((msg.message.indexOf('</b>') + 4))
            }));
          }
        }
      });
    }
  }

  outCarregarArquivos(repositorio: Repositorio, doc: DocumentoVO) {
    // this.atualizarMensagensTela();
  }

  onConcluirUpload(chaveRepositorio: string) {
    this.houveMudancaForm();
  }

  public desativaEventoForm() {
    this.houveAlteracaoForm = false;
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  public getAlteracaoForm() {
    let alteracao = false;
    for (const ap of this.aprovacoes) {
      if (ap.houveAlteracao) {
        alteracao = true;
      }
    }
    return this.houveAlteracaoForm || alteracao;
  }


  carregaDocumento() {
    // Atualizando Aba
    this.evtSalvarDados.emit(false);
    if (this.cooperativaTemp) {

      this.apiDocumentoService.getDocumentacaoPorIdPessoa(this.cooperativaTemp.pessoaJuridica.id, false).then((res) => {

        if (res && res.data != null) {
          this.documentacaoVO = res.data;

          this.atualizarMensagensTela();
        }
      });
    }
  }

  getLista(): Promise<IServiceResponse<Documento[]>> {
    return this.apiDocumentoService.listaAtivos(true, TipoPessoaEnum.PJ);
  }

  salvar(abaDestino: number) {
    if (this.salvando) {
      return;
    }
    let pendenciaPreenchumentoTela = false;
    this.aprovacoes.forEach(elem => {
      if (elem.visualizado === true) {
        pendenciaPreenchumentoTela = true;
      }
    });

    if (pendenciaPreenchumentoTela) {
      this.messageService.add({ severity: 'warn', detail: 'Preencha corretamente as orientações para ajuste!', life: 10000 });
      return;
    }

    const aba = {
      id: null,
      cooperativa: { id: Number(this.cooperativaTemp.id) },
      dataEnvio: null,
      aba: ControleAbasRegistroEnum.DOCUMENTOS,
      enviada: true
    };

    this.apiControleAbas.save(aba).subscribe();

    this.houveAlteracaoForm = true;
    this.salvando = true;
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {

        this.geralService.salvarPendencia(
          this.aprovacoes,
          [() => this.evtSalvarDados.emit(true)]
        );

        if (this.pendenciasEditadas.length > 0) {
          this.apiValidacaoDadosService.editarAgrupamento(this.pendenciasEditadas).then(res => {
            this.pendenciasEditadas = res.data;
          });
        }
        this.apiDocumentoService.salvarDocumentacao(this.documentacaoVO).then((res) => {

          // Marcar como Validado
          // this.apiValidacaoDadosService.marcarComoValidado(coop.id, 'DOCUMENTOS');

          // Atualizando Aba
          this.evtSalvarDados.emit(true);
          this.desativaEventoForm();

          ValidacaoMarcacaoUtil.notificarSalvoComPendencias(this.messageService, this.ajusteDadosComponentes);

          for (const ap of this.aprovacoes) {
            if (ap.houveAlteracao) {
              ap.houveAlteracao = false;
            }
          }

          this.atualizarMensagensTela();

          window.scroll(0, 0);
          this.evtFimSalvarDados.emit(abaDestino);

        }).catch(() => {
          this.evtErroSalvar.emit(true);
        }).finally(() => {
          this.salvando = false;
        });
      } else {
        this.salvando = false;
      }
    });

  }

  verificarLiberacaoCampos() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {

        this.cooperativaTemp = coop;
        this.atualizaPendenciaChave(coop);
        this.apiPj.buscaUnidadeResponsavel(this.cooperativaTemp.pessoaJuridica.ufSigla).then(pj =>{
          this.nomePessoaJuridica = pj.data.nomeFantasia;
        });
        this.apiCadastroRegistroService.podePreencherCadastroRegistroBasico(coop.id).then((res) => {

          if (res != null && res.data != null) {
            this.podeModificarOsCampos = res.data;
          }

          // Carregando Documentos
          this.carregaDocumento();
          this.atualizaPendenciaChave(coop);
        });
      }
    });
  }

  atualizaPendenciaChave(coop) {
    this.apiValidacaoDadosService.obterUltimasPendenciasChave(coop.id).then(res => {
      this.mapPendencias = res.data;
    });
  }

  atualizaLiberacaoCampo(pendencia) {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas.push(pendencia);
    }
    const chave = pendencia.bloco + '_' + pendencia.identificadorAuxiliar;
    this.mapPendencias[chave] = false;
    this.houveAlteracaoForm = true;
  }

  validaAjustesDados(): boolean {
    if (this.cooperativaTemp) {
        return this.validacaoDados.validaAjustesDados(this.cooperativaTemp.progressoMacro);
    }
    return false;
}

}
