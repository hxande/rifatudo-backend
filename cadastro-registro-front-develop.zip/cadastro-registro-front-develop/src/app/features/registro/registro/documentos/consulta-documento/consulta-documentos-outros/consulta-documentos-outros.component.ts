import { Component, OnInit, ViewChild, Input, ChangeDetectorRef, inject } from '@angular/core';
import { Table } from 'primeng/table';
import { MessageService, ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { DocumentoVO } from '@documentacao-api/models/DocumentoVO';
import { PessoaDocumento } from '@documentacao-api/models/PessoaDocumento';
import { PessoaDocumentoAnexo } from '@documentacao-api/models/PessoaDocumentoAnexo';
import { IPage } from '@utils/interfaces/IPage';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiPessoaDocumentoService } from '@documentacao-api/services/api-pessoa-documento.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ValidacaoDocumento } from '@shared/registro/documentos/validacao/validacao-documento.service';
import { ApiPeriodoAtualizacaoService } from '@cadastro-registro-api/services/api-periodo-atualizacao.service';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { Arquivo } from '@upload-api/models/Arquivo';
import { FileUploadComponent } from '@gui/file-upload/file-upload/file-upload.component';

interface AnoOption {
  label: string;
  value: number;
  ano?: number;
  anoArquivo?: number;
}

@Component({
  selector: 'app-consulta-documentos-outros',
  templateUrl: './consulta-documentos-outros.component.html',
  styleUrls: ['./consulta-documentos-outros.component.css'],
})
export class ConsultaDocumentosOutrosComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @ViewChild('dt') dt: Table;
  @ViewChild('fileupNovoDocumento') fileupNovoDocumento: FileUploadComponent;
  @Input() cooperativa: Cooperativa;
  modalNovoUotrosDocumentos = false;
  documentoVO: DocumentoVO;
  pessoaDocumento: PessoaDocumento[];
  pessoaDocumentoAnexo: PessoaDocumentoAnexo;
  responseDocumento: IPage<Arquivo>;
  nrLinhasTabela = 10;
  totalElementos = 0;
  numeroElementos = 0;
  elementoInicial = 0;
  repositorios: string[] = [];
  cols: { field: string; header: string }[];
  chaveRepositorio = '';
  ano: AnoOption;
  anoArquivo: AnoOption;
  tipoDocumento = '';
  optionsAnos: AnoOption[];
  annoCadastro: number;
  optionsAnosUpload: AnoOption[];
  descricaoDocumento = '';

  constructor(
    private uploadApi: ApiFileUploadService,
    public keycloakService: KeycloakService,
    private documentoApi: ApiPessoaDocumentoService,
    private utilityService: UtilityService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private messageService: MessageService,
    private router: Router,
    private confirmationService: ConfirmationService,
    public validacaoDocumento: ValidacaoDocumento,
    private apiPeriodo: ApiPeriodoAtualizacaoService
  ) {
    this.documentoVO = new DocumentoVO();
  }

  ngOnInit() {
    this.cols = [
      { field: 'download', header: 'Download' },
      { field: 'nomeOriginal', header: 'Nome do documento' },
      { field: 'dataHoraCriacao', header: 'Data de inclusão' },
      { field: 'tamanho', header: 'Tamanho' },
    ];
    this.carregaTabela();
  }

  carregaTabela() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
    .then((coop) => {
      if (coop) {
        this.responseDocumento = null;
        this.cooperativa = coop;
        this.montarTabelaOutrosDocumentos(coop.id);
      }
      this.changeDetectorRef.markForCheck();
    });

    this.popularAnosUpload();
  }

  textoParaData(texto) {
    let m = texto.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
    // eslint-disable-next-line radix
    m = m.slice(1, 4).map(v => parseInt(v));
    return new Date(m[2], m[1] - 1, m[0]);
  }

  popularAnosUpload() {
    this.apiPeriodo.buscaTodosAnosSemParametro().then((response) => {

      const dataAnoD = this.textoParaData(this.cooperativa.pessoaJuridica.dataConstituicaoStr);
      this.annoCadastro = dataAnoD.getFullYear();

      const anosCiclos = response.data
        .filter((ano) => ano >= this.annoCadastro)
        .map(ano => ({
          label: 'Ciclo ' + ano + ' (Ano calendário ' + (ano - 1) + ')',
          anoArquivo: ano - 1,
          value: ano,
        }));

      this.optionsAnosUpload = anosCiclos;
      this.changeDetectorRef.markForCheck();
    });
  }

  montarTabelaOutrosDocumentos(idCoop) {
    this.documentoApi.getPorIdPessoaDocumentoOutros(idCoop).then((response) => {
      this.pessoaDocumento = response.data;
      this.preencheRepositorio();
      this.getDocumentos().then((responseDocumento) => {
        this.responseDocumento = responseDocumento;
        this.preencheElementosTabela();
        this.preencherAnos();
        this.preencheArquivoDados();
        this.changeDetectorRef.markForCheck();
      });
    });
  }

  openModalNovoUotrosDocumentos() {
    this.modalNovoUotrosDocumentos = true;
  }

  excluirNovoArquivo(fileupNovoDocumento: FileUploadComponent) {}

  podeGravarNovoDocumento() {
    if (!this.documentoVO.upload) {
      return false;
    }
    if (!this.anoArquivo || !this.anoArquivo.value) {
      return false;
    }
    if (!this.descricaoDocumento) {
      return false;
    }
    return true;
  }

  salvar() {
    this.documentoVO.idPessoa = this.cooperativa.id;
    this.documentoVO.ano = this.anoArquivo.value;
    this.documentoVO.descricao = this.descricaoDocumento;

    this.documentoApi
      .incluirDocumentoOutros(this.documentoVO)
      .then((response) => {
        if (response.data) {
          this.documentoVO = new DocumentoVO();
          this.carregaTabela();
          this.modalNovoUotrosDocumentos = false;
          this.resetFileUpload(this.fileupNovoDocumento, this.chaveRepositorio);
          this.anoArquivo = null;
          this.descricaoDocumento = '';
          this.changeDetectorRef.markForCheck();
        }
      })
      .catch((err) => {
      });
  }

  fecharModalNovoDocumento() {
    this.documentoVO = new DocumentoVO();
    this.resetFileUpload(this.fileupNovoDocumento, this.chaveRepositorio);
    this.modalNovoUotrosDocumentos = false;
    this.anoArquivo = null;
    this.descricaoDocumento = '';
  }

  getDocumentos(pagina = 0, sortField = 'dataHoraCriacao', sortOrder = 1): Promise<IPage<Arquivo>> {
    sortField = sortField || 'dataHoraCriacao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.uploadApi.consultaArquivosFiltro(this.repositorios, options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams().set('page', pagina).set('size', nrLinhas).set('sort', `${sortField},${sortOrder}`),
    };

    options.params = this.utilityService.carregaParamsString(null, options.params, 'buscaLivre');
    return options;
  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getDocumentos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .then((responseDocumento) => {
      this.responseDocumento = responseDocumento;
      this.preencheElementosTabela();

      this.preencheArquivoDados();
      this.changeDetectorRef.markForCheck();
    });
  }

  preencherAnos() {
    this.optionsAnos = [];
    this.pessoaDocumento.forEach((ano) => {
      if (!this.optionsAnos.length || (this.optionsAnos.length && this.optionsAnos.filter((a) => new Date(ano.ano).getFullYear() === a.value).length === 0)) {
        const label = 'Ciclo ' + ano.ano + ' (Ano calendário ' + (ano.ano - 1) + ')';
        this.optionsAnos = [
          ...this.optionsAnos,
          {
          label,
          ano: ano.ano - 1,
          value: ano.ano,
          }
      ];
      }
    });

    this.optionsAnos.sort((a, b) => {
      if (a.value > b.value) {
        return 1;
      }
      if (a.value < b.value) {
        return -1;
      }
      return 0;
    });

    // Retirar os anos duplicados da combo de anos
    const anosFiltrados = this.optionsAnos.reduce((accumalator, current) => {
      if (!accumalator.some((item) => item.value === current.value)) {
        accumalator = [...accumalator, current];
      }
      return accumalator;
    }, []);
    this.optionsAnos = anosFiltrados;
  }

  findDescricaoDocumento(obj): string {
    let descricao = '';
    this.pessoaDocumento.forEach((p) => {
      p.pessoaDocumentoAnexo.forEach((pd) => {
        if (pd.uploadAnexo === obj.chaveRepositorio) {
          descricao = pd.descricaoDocumento;
          return;
        }
      });
    });

    return descricao;
  }

  findAno(obj): number {
    let ano = 0;
    this.pessoaDocumento.forEach((p) => {
      p.pessoaDocumentoAnexo.forEach((pd) => {
        if (pd.uploadAnexo === obj.chaveRepositorio) {
          ano = p.ano - 1;
          return;
        }
      });
    });

    return ano;
  }

  preencheElementosTabela() {
    this.totalElementos = this.responseDocumento ? this.responseDocumento.totalElements : 0;
    this.numeroElementos = this.responseDocumento
      ? this.responseDocumento.numberOfElements + (this.responseDocumento.pageable.offset ? this.responseDocumento.pageable.offset : 0)
      : 0;
    this.elementoInicial = this.numeroElementos !== 0 ? this.responseDocumento.pageable.offset + 1 : 0;
  }

  findDescricao(obj): string {
    let tipo = '';
    this.pessoaDocumento.forEach((p) => {
      p.pessoaDocumentoAnexo.forEach((pd) => {
        if (pd.uploadAnexo === obj.chaveRepositorio) {
          tipo = p.documento.descricao;
          return;
        }
      });
    });

    return tipo;
  }

  preencheRepositorio() {
    this.repositorios = [];
    this.pessoaDocumento.forEach((obj) => {
      obj.pessoaDocumentoAnexo.forEach((_obj) => {
        this.repositorios = [...this.repositorios, _obj.uploadAnexo];
      });
    });
  }

  excluirArquivo(arquivo: Arquivo) {
    this.confirmationService.confirm({
      message: 'Deseja mesmo apagar este arquivo?',
      accept: () => {
        this.uploadApi.getArquivoPelaChave(arquivo.chaveArquivo).then((responseArquivo) => {
          this.documentoApi.excluiDocumentoOutros(responseArquivo.repositorio.chavePasta)
          .then((response) => {
            this.uploadApi.deleteRepositorio(responseArquivo.repositorio.chavePasta)
            .then((res) => {
              this.carregaTabela();
              this.changeDetectorRef.markForCheck();
            });
          });
        });
      },
    });

    this.anoArquivo = null;
    this.descricaoDocumento = '';
  }

  onRowSelect(event) {
    const file = event;
    this.uploadApi
      .getArquivoDownload(event.chaveArquivo)
      .then((data) => {
        const thefile = new Blob([data], { type: event.mimeType });

        const url = window.URL.createObjectURL(thefile);

        const link = document.createElement('a');
        link.href = url;
        link.download = event.nome;
        link.dispatchEvent(new MouseEvent('click'));
        this.changeDetectorRef.markForCheck();
      })
      .catch((err) => {
        this.messageService.add({ severity: 'error', detail: 'Ocorreu um erro.', life: 10000 });
        this.changeDetectorRef.markForCheck();
      });
  }

  voltar() {
    if (this.cooperativa.situacaoCooperativa.id === 4) {
      return this.router.navigate(['/registro/processo'], { queryParams: { id_cooperativa: this.cooperativa.id }, skipLocationChange: true });
    }
    return this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: this.cooperativa.id }, skipLocationChange: false });
  }

  onConcluirUpload(event) {
    this.documentoVO.upload = event;
  }

  /* reseta o file upload */
  resetFileUpload(fileUpload: FileUploadComponent, chaveRepositorio: string) {
    if (fileUpload) {
      fileUpload.reset();
      fileUpload.chaveRepositorio = chaveRepositorio;
      fileUpload.podeFazerUpload = true;
    }
  }

  buscaDocumentos() {
    if (this.ano) {
      this.documentoApi.getPorIdAnoPessoaDocumentoOutros(this.cooperativa.id, this.ano.value)
      .then((respPessoaDoc) => {
        this.repositorios = [];
        this.pessoaDocumento = respPessoaDoc.data;

        this.preencherDocumentos();
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.montarTabelaOutrosDocumentos(this.cooperativa.id);
    }
  }

  preencherDocumentos() {
    this.preencheRepositorio();

    this.getDocumentos().then((respDoc) => {
      this.responseDocumento = respDoc;
      this.preencheElementosTabela();

      this.preencheArquivoDados();
      this.changeDetectorRef.markForCheck();
    });
  }

  preencheArquivoDados(){
    Object.assign(
      this.responseDocumento.content,
      this.responseDocumento.content.map((obj) => ({
        nome: obj.nome,
        tamanho: obj.tamanho,
        dataHoraCriacao: obj.dataHoraCriacao,
        chaveArquivo: obj.chaveArquivo,
        chaveRepositorio: obj.chaveRepositorio,
        usuarioLogado: obj.usuarioLogado,
        ano: this.findAno(obj),
        descricaoDocumento: this.findDescricaoDocumento(obj),
        tipo: this.findDescricao(obj),
      }))
    );
  }
}
