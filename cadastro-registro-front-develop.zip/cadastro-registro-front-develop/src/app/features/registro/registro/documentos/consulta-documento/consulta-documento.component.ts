import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';

import { HttpParams } from '@angular/common/http';
import { ConfirmationService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { UtilityService } from '@utils/utility/utility.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Documento } from '@documentacao-api/models/Documento';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-consulta-documento',
  templateUrl: './consulta-documento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConsultaDocumentoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private documentoApi: ApiDocumentoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private keycloakService: KeycloakService,
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/inicio' },
      { label: 'Documento/', routerLink: 'inicio' },
      { label: 'Consulta de Documento', routerLink: '/regsitro/documento' }
    ]);
   }

  responseDocumento: IServiceResponse<IPage<Documento>>;
  nrLinhasTabela = 20 ;
  private debouncer;
  private delay = 500;
  filtroDescricao='';
  filtroDetalhamento='';
  filtroTipoPessoa='';
  filtroAtivo = null;
  cols: { field: string, header: string }[];
  @ViewChild('dt') dt: Table;
  isUEouOcb: boolean;
  podeModificarLogo = false;

  ngOnInit() {
    this.cols = [

      { field: 'descricao', header: 'Descrição' },
      { field: 'detalhamentoDocumento', header: 'Detalhamento' },
      { field: 'tipoPessoa', header: 'Tipo de pessoa' },
      { field: 'posicaoTela', header: 'Posição na tela' },
      { field: 'ativo', header: 'Ativo' }
    ];

    if(this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional){
     this.isUEouOcb = true;
    }
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay);
  }

  getDocumentos(pagina = 0, sortField = 'descricao', sortOrder = 1): Promise<IServiceResponse<IPage<Documento>>> {
    sortField = sortField || 'descricao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.documentoApi.getDocumentsPage(options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`)
    };
    options.params = this.utilityService.carregaParamsString(this.filtroDescricao, options.params, 'descricao');
    options.params = this.utilityService.carregaParamsString(this.filtroDetalhamento, options.params, 'detalhamentoDocumento');

    if(this.filtroAtivo != null){
      options.params = options.params.set('ativo', this.filtroAtivo + '');
    }

    return options;

  }

  loadLazy(event: TableLazyLoadEvent) {
    this.getDocumentos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .then(responseDocumento => {
      this.responseDocumento = responseDocumento;
      this.changeDetectorRef.markForCheck();
    });
  }

  desativarDocumento(obj: Documento){
    this.confirmationService.confirm({
      message: 'Deseja '+(obj.ativo ? 'desativar' : 'ativar')+' o registro?',
      accept: () => {
        this.documentoApi.desativaDocumento(obj.id, (obj.ativo ? false : true))
          .then(() => {
            this.dt.reset();
            this.changeDetectorRef.markForCheck();
          });
      }
    });
  }

}
