import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild, Input, inject } from '@angular/core';

import { HttpParams } from '@angular/common/http';
import { ConfirmationService, MessageService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { Router } from '@angular/router';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiParecerService } from '@cadastro-registro-api/services/api-parecer.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { IPage } from '@utils/interfaces/IPage';
import { PeriodoAtualizacao } from '@cadastro-registro-api/models/PeriodoAtualizacao';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { Documento } from '@documentacao-api/models/Documento';
import { ParecerDocumentoTO } from '@cadastro-registro-api/models/ParecerDocumentoTO';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { Arquivo } from '@upload-api/models/Arquivo';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-consulta-documento-ocb',
  templateUrl: './consulta-documento-ocb.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConsultaDocumentoOcbComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);
  constructor(
    private documentoApi: ApiDocumentoService,
    private confirmationService: ConfirmationService,
    private utilityService: UtilityService,
    private parecerApi: ApiParecerService,
    private uploadApi: ApiFileUploadService,
    private messageService: MessageService,
    private keycloakService: KeycloakService,
    private router: Router,
    private breadCrumbPrimeNGService: BreadcrumbService
  ) {}
  responseDocumento: IPage<Arquivo>;
  pessoaDocumento: ParecerDocumentoTO[];
  repositorios: string[] = [];
  optionsCiclos: PeriodoAtualizacao[];
  ano: PeriodoAtualizacao;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  filtroDescricao = '';
  filtroDetalhamento = '';
  filtroTipoPessoa = '';
  filtroAtivo = null;
  totalElementos = 0;
  numeroElementos = 0;
  elementoInicial = 0;
  buscaLivre = '';
  tipoDocumento = '';
  cols: { field: string; header: string }[];
  @ViewChild('dt') dt: Table;
  @Input() cooperativa: Cooperativa;

  ngOnInit() {
    this.cols = [
      { field: 'download', header: 'Download' },
      { field: 'tipo', header: 'Tipo de documento' },
      { field: 'nome', header: 'Nome do documento' },
      { field: 'data', header: 'Data de inclusão' },
      { field: 'tamanho', header: 'Tamanho' },
    ];
    this.obterDocumento(this.cooperativa.id);
    if (this.cooperativa.dataRegistro) {
      this.breadCrumbPrimeNGService.setItems([
        { label: 'Início', routerLink: '/' },
        { label: 'Cooperativas Registradas', routerLink: '/cooperativa/listagem' },
        {
          label: 'Cooperativa',
          command: (onclick) => {
            this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: this.cooperativa.id } });
          },
        },
        { label: 'Documentos' },
      ]);
    } else {
      this.breadCrumbPrimeNGService.setItems([
        { label: 'Início', routerLink: '/' },
        { label: 'Processo de Registro', routerLink: '/registro/listagem' },
        { label: 'Documentos' },
      ]);
    }
  }

  obterDocumento(coop: number) {
    const options = {
      params: new HttpParams().set('tipoDocumento', this.tipoDocumento),
    };

    this.parecerApi.getDocumentosPorPessoa(coop, options).then((response) => {
      this.repositorios = [];
      this.pessoaDocumento = [];
      this.responseDocumento = null;

      this.pessoaDocumento = response.data;
      this.preencheRepositorio();

      this.getDocumentos().then((responseDocumento) => {
        this.responseDocumento = responseDocumento;
        this.preencheElementosTabela();

        this.preencheArquivoDados();
        this.changeDetectorRef.markForCheck();
      });
      this.changeDetectorRef.markForCheck();
    });
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
    }, this.delay);
  }

  buscaDocumentos() {
    this.obterDocumento(this.cooperativa.id);
  }

  preencheRepositorio() {
    this.repositorios = this.pessoaDocumento.map(obj => obj.upDocumento);
  }

  getDocumentos(pagina = 0, sortField = 'dataHoraCriacao', sortOrder = 1): Promise<IPage<Arquivo>> {
    sortField = sortField || 'dataHoraCriacao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.uploadApi.consultaArquivosFiltro(this.repositorios, options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams().set('page', pagina).set('size', nrLinhas).set('sort', `${sortField},${sortOrder}`),
    };
    options.params = this.utilityService.carregaParamsString(this.buscaLivre, options.params, 'buscaLivre');
    return options;
  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getDocumentos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then((responseDocumento) => {
      this.responseDocumento = responseDocumento;
      this.preencheElementosTabela();
      this.preencheArquivoDados();
      this.changeDetectorRef.markForCheck();
    });
  }

  preencheElementosTabela() {
    this.totalElementos = this.responseDocumento ? this.responseDocumento.totalElements : 0;
    this.numeroElementos = this.responseDocumento
      ? this.responseDocumento.numberOfElements + (this.responseDocumento.pageable.offset ? this.responseDocumento.pageable.offset : 0)
      : 0;
    this.elementoInicial = this.numeroElementos !== 0 ? this.responseDocumento.pageable.offset + 1 : 0;
  }

  desativarDocumento(obj: Documento) {
    this.confirmationService.confirm({
      message: 'Deseja ' + (obj.ativo ? 'desativar' : 'ativar') + ' o registro?',
      accept: () => {
        this.documentoApi.desativaDocumento(obj.id, obj.ativo ? false : true).then(() => this.dt.reset());
      },
    });
  }

  onRowSelect(event) {
    const file = event;
    this.uploadApi
      .getArquivoDownload(event.chaveArquivo)
      .then((data) => {
        const thefile = new Blob([data], { type: event.mimeType });

        const url = window.URL.createObjectURL(thefile);

        const link = document.createElement('a');
        link.href = url;
        link.download = event.nome;
        link.dispatchEvent(new MouseEvent('click'));
      })
      .catch((err) => {
        this.messageService.add({ severity: 'error', detail: 'Ocorreu um erro.', life: 10000 });
      });
  }

  voltar() {
    if (this.cooperativa.situacaoCooperativa.id === 4) {
      return this.router.navigate(['/registro/processo'], { queryParams: { id_cooperativa: this.cooperativa.id }, skipLocationChange: true });
    }
    return this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: this.cooperativa.id }, skipLocationChange: false });
  }

  get isEstadualOuNacional() {
    return this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional;
  }

  preencheArquivoDados(){

    this.responseDocumento = {
      ...this.responseDocumento,
      content: this.responseDocumento.content.map((obj) => ({
        ...obj,
        nome: obj.nome,
        tamanho: obj.tamanho,
        dataHoraCriacao: obj.dataHoraCriacao,
        chaveArquivo: obj.chaveArquivo,
        chaveRepositorio: obj.chaveRepositorio,
        usuarioLogado: obj.usuarioLogado,
        tipo: this.pessoaDocumento.find((p) =>
          p.upDocumento === obj.chaveRepositorio)?.tipoDocumento,
      }))
    };
  }

}
