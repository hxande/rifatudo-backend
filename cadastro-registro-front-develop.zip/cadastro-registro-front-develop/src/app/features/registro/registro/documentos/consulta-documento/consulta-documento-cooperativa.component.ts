import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { TableLazyLoadEvent } from 'primeng/table';
import { Table } from 'primeng/table';
import { Router } from '@angular/router';
import { ApiPessoaDocumentoService } from '@documentacao-api/services/api-pessoa-documento.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { UtilityService } from '@utils/utility/utility.service';
import { IPage } from '@utils/interfaces/IPage';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { Documento } from '@documentacao-api/models/Documento';
import { PessoaDocumento } from '@documentacao-api/models/PessoaDocumento';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { Arquivo } from '@upload-api/models/Arquivo';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

interface AnoOption {
  ano: string;
  value: number;
}

@Component({
  selector: 'app-consulta-documento-cooperativa',
  templateUrl: './consulta-documento-cooperativa.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ConsultaDocumentoCooperativaComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private uploadApi: ApiFileUploadService,
    private messageService: MessageService,
    private documentoApi: ApiPessoaDocumentoService,
    private utilityService: UtilityService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private keycloakService: KeycloakService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private router: Router
  ) {}

  responseDocumento: IPage<Arquivo>;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  filtroDescricao = '';
  filtroDetalhamento = '';
  filtroTipoPessoa = '';
  filtroAtivo = null;
  cooperativa: Cooperativa = null;
  tipoDocumentoArray: Documento[] = [];
  pessoaDocumento: PessoaDocumento[];
  repositorios: string[] = [];
  cols: { field: string; header: string }[];
  optionsAnos: AnoOption[];
  ano: AnoOption;
  totalElementos = 0;
  numeroElementos = 0;
  elementoInicial = 0;
  buscaLivre = '';
  tipoDocumento = '';
  @ViewChild('dt') dt: Table;

  ngOnInit() {
    this.cols = [
      { field: 'download', header: 'Download' },
      { field: 'tipo', header: 'Tipo de documento' },
      { field: 'nomeOriginal', header: 'Nome do documento' },
      { field: 'dataHoraCriacao', header: 'Data de inclusão' },
      { field: 'tamanho', header: 'Tamanho' },
    ];

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
    .then((coop) => {
      if (coop) {
        if (coop.dataRegistro) {
          this.breadCrumbPrimeNGService.setItems([
            { label: 'Início', routerLink: '/' },
            { label: 'Cooperativas Registradas', routerLink: '/cooperativa/listagem' },
            {
              label: 'Cooperativa',
              command: (onclick) => {
                this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: coop.id } });
              },
            },
            { label: 'Documentos' },
          ]);
        } else {
          this.breadCrumbPrimeNGService.setItems([
            { label: 'Início', routerLink: '/' },
            { label: 'Processo de Registro', routerLink: '/cooperativa/listagem' },
            {
              label: 'Cooperativa',
              command: (onclick) => {
                this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: coop.id } });
              },
            },
            { label: 'Documentos' },
          ]);
        }

        this.cooperativa = coop;
        this.documentoApi.getPorIdPessoa(coop.id).then((response) => {
          this.pessoaDocumento = response.data;
          this.preencheRepositorio();
          this.getDocumentos().then((responseDocumento) => {
            this.responseDocumento = responseDocumento;
            this.preencheElementosTabela();
            this.preencherAnos();
            this.preencheArquivoDados();
            this.changeDetectorRef.markForCheck();
          });
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

  preencherAnos() {
    this.optionsAnos = [];
    this.pessoaDocumento.forEach((ano) => {
      if (
        !this.optionsAnos.length ||
        (this.optionsAnos.length && this.optionsAnos.filter((a) => ano.ano === a.value).length === 0)
      ) {
        this.optionsAnos = [...this.optionsAnos, {
          ano: `Ciclo ${ano.ano} (Ano calendário ${ano.ano - 1})`,
          value: ano.ano,
        }];
      }
    });

    this.optionsAnos.sort((a, b) => {
      if (a.value > b.value) {
        return 1;
      }
      if (a.value < b.value) {
        return -1;
      }
      return 0;
    });
  }

  findDescricao(obj): string {
    let tipo = '';
    this.pessoaDocumento.forEach((p) => {
      p.pessoaDocumentoAnexo.forEach((pd) => {
        if (pd.uploadAnexo === obj.chaveRepositorio) {
          tipo = p.documento.descricao;
          return;
        }
      });
    });

    return tipo;
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dt.reset();
      this.changeDetectorRef.markForCheck();
    }, this.delay);
  }

  buscaDocumentos() {
    if(this.ano && this.tipoDocumento.trim()==""){
      this.documentoApi.getDocumentoPorAnoDocObrigatorio(this.cooperativa.id, this.ano.value)
      .then((respPessoaDoc) => {
          this.repositorios = [];
          this.pessoaDocumento = respPessoaDoc.data;
          this.preencheRepositorio();
          this.getDocumentos().then((respDoc) => {
            this.responseDocumento = respDoc;
            this.preencheElementosTabela();
            this.preencheArquivoDados();
            this.changeDetectorRef.markForCheck();
          });
        });
    }else if (this.ano) {
      this.documentoApi.getDocumentoPorAnoETipo(this.cooperativa.id, this.ano.value, this.tipoDocumento.trim())
      .then((respPessoaDoc) => {
      //this.documentoApi.getDocumentoPorAnoETipo(this.cooperativa.id, this.ano.value, 'teste').then((respPessoaDoc) => {
        this.repositorios = [];
        this.pessoaDocumento = respPessoaDoc.data;
        this.preencheRepositorio();

        this.getDocumentos()
        .then((respDoc) => {
          this.responseDocumento = respDoc;
          this.preencheElementosTabela();
          this.preencheArquivoDados();
          this.changeDetectorRef.markForCheck();
        });
      });
    } else if (this.tipoDocumento.trim()) {
      this.documentoApi.getDocumentoPorTipo(this.cooperativa.id, this.tipoDocumento.trim())
      .then((response) => {
        this.repositorios = [];
        this.pessoaDocumento = response.data;
        this.preencheRepositorio();

        this.getDocumentos().then((responseDocumento) => {
          this.responseDocumento = responseDocumento;
          this.preencheElementosTabela();
          this.preencheArquivoDados();
          this.changeDetectorRef.markForCheck();
        });
      });
    } else {
      this.documentoApi.getPorIdPessoa(this.cooperativa.id)
      .then((response) => {
        this.pessoaDocumento = response.data;
        this.preencheRepositorio();

        this.getDocumentos().then((responseDocumento) => {
          this.responseDocumento = responseDocumento;
          this.preencheElementosTabela();
          this.preencheArquivoDados();
          this.changeDetectorRef.markForCheck();
        });
      });
    }
  }

  preencheRepositorio() {
    this.pessoaDocumento.forEach((obj) => {
      obj.pessoaDocumentoAnexo.forEach((_obj) => {
        this.repositorios = [...this.repositorios, _obj.uploadAnexo];
      });
    });
  }

  preencheElementosTabela() {
    this.totalElementos = this.responseDocumento ? this.responseDocumento.totalElements : 0;
    this.numeroElementos = this.responseDocumento
      ? this.responseDocumento.numberOfElements + (this.responseDocumento.pageable.offset ? this.responseDocumento.pageable.offset : 0)
      : 0;
    this.elementoInicial = this.numeroElementos !== 0 ? this.responseDocumento.pageable.offset + 1 : 0;
  }

  getDocumentos(pagina = 0, sortField = 'dataHoraCriacao', sortOrder = 1): Promise<IPage<Arquivo>> {
    sortField = sortField || 'dataHoraCriacao';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.uploadApi.consultaArquivosFiltro(this.repositorios, options);
  }

  carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams().set('page', pagina).set('size', nrLinhas).set('sort', `${sortField},${sortOrder}`),
    };

    options.params = this.utilityService.carregaParamsString(this.buscaLivre, options.params, 'buscaLivre');
    return options;
  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.getDocumentos(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
    .then((responseDocumento) => {
      this.responseDocumento = responseDocumento;
      this.preencheElementosTabela();
      this.preencheArquivoDados();
      this.changeDetectorRef.markForCheck();
    });
  }

  onRowSelect(event) {
    const file = event;
    this.uploadApi
      .getArquivoDownload(event.chaveArquivo)
      .then((data) => {
        const thefile = new Blob([data], { type: event.mimeType });

        const url = window.URL.createObjectURL(thefile);

        const link = document.createElement('a');
        link.href = url;
        link.download = event.nome;
        link.dispatchEvent(new MouseEvent('click'));
        this.changeDetectorRef.markForCheck();
      })
      .catch((err) => {
        this.messageService.add({ severity: 'error', detail: 'Ocorreu um erro.', life: 10000 });
        this.changeDetectorRef.markForCheck();
      });
  }

  preencheArquivoDados(){
    Object.assign(
      this.responseDocumento.content,
      this.responseDocumento.content.map((obj) => ({
        nome: obj.nome,
        tamanho: obj.tamanho,
        dataHoraCriacao: obj.dataHoraCriacao,
        chaveArquivo: obj.chaveArquivo,
        chaveRepositorio: obj.chaveRepositorio,
        usuarioLogado: obj.usuarioLogado,
        tipo: this.findDescricao(obj),
      }))
    );
  }
}
