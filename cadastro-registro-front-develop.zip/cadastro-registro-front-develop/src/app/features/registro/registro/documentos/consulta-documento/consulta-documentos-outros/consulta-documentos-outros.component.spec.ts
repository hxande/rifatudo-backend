import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaDocumentosOutrosComponent } from './consulta-documentos-outros.component';

describe('ConsultaDocumentosOutrosComponent', () => {
  let component: ConsultaDocumentosOutrosComponent;
  let fixture: ComponentFixture<ConsultaDocumentosOutrosComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaDocumentosOutrosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaDocumentosOutrosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
