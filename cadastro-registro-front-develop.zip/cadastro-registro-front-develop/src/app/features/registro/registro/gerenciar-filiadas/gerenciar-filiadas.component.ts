import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { ApiDadosGeraisService } from '../../../../api/services/api-dados-gerais.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-gerenciar-filiadas',
  templateUrl: './gerenciar-filiadas.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./gerenciar-filiadas.scss']
})
export class GerenciarFiliadasComponent {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input('registro')
  cooperativa: Cooperativa;

  @Input('visible')
  modalFiliadas: boolean;

  @Input('vinculadas')
  cooperativasVinculadas2: CooperativaBasica[] = [];

  @Output()
  fechaModal = new EventEmitter();

  cooperativasVinculadas: number[] = [];

  constructor(
    private dadosGeraisService: ApiDadosGeraisService
  ) {
  }

  closeModal(): void {
    this.fechaModal.emit(this.cooperativasVinculadas2);
  }

  onShowModal(): void {
    this.carregaVinculadas();
  }

  carregaVinculadas(): void {
    if (
      this.cooperativa != null &&
      this.cooperativa.id != null &&
      (this.cooperativasVinculadas2 == null || this.cooperativasVinculadas2.length === 0)
    ) {
      this.dadosGeraisService.getVinculacoes(this.cooperativa.id)
      .then((response) => {
        if (response && response.data != null && response.data.length > 0) {
          this.cooperativasVinculadas2 = response.data.filter((x) => x != null);
          this.cooperativasVinculadas = new Array<number>(this.cooperativasVinculadas2.length);
        }
        this.verificarGrauCooperativa(false);
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  verificarGrauCooperativa(recarregar: boolean): void {
    if (this.cooperativa != null && this.cooperativa.categoria != null) {

      if (!(typeof this.cooperativa.categoria.minimoCooperativa === 'number')) {
        this.cooperativa.categoria.minimoCooperativa = 0;
      }

      if (recarregar) {
        this.cooperativasVinculadas = [];
        this.cooperativasVinculadas2 = [];
      }

    }
  }
}
