import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  inject,
  Input,
  OnInit,
  Output
} from '@angular/core';

import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';

import { ApiDadosGeraisService } from 'src/app/api/services/api-dados-gerais.service';

import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-gerenciar-filiadas-content',
  templateUrl: './gerenciar-filiadas-content.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./gerenciar-filiadas-content.scss']
})
export class GerenciarFiliadasContentComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input('registro')
  cooperativa: Cooperativa;

  @Input('isAba')
  isAbaModal: boolean;

  @Input('vinculadas')
  cooperativasVinculadas2: CooperativaBasica[] = [];

  @Output()
  fechaModal = new EventEmitter();

  cooperativasVinculadas: number[] = [];

  cooperativaSelecionada: CooperativaBasica | null;

  houveAlteracaoForm = false;

  cooperativasBusca: CooperativaBasica[] = [];

  cols: {
    field: string,
    header: string,
    width: string
  }[];

  constructor(
    private dadosGeraisService: ApiDadosGeraisService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {

    this.cols = [
      { field: 'cnpj', header: 'CNPJ', width: '100%' },
      { field: 'nomeFantasia', header: 'Nome Fantasia', width: '100%' },
      { field: 'ufSigla', header: 'UF', width: '10%' }
    ];

    this.carregaVinculadas();
  }

  carregaVinculadas(): void {

    if (
      this.cooperativa != null &&
      this.cooperativa.id != null &&
      (
        this.cooperativasVinculadas2 == null ||
        this.cooperativasVinculadas2.length === 0
      )
    ) {
      this.dadosGeraisService
        .getVinculacoes(this.cooperativa.id)
        .then((resVinc) => {
          if (
            resVinc &&
            resVinc.data != null &&
            resVinc.data.length > 0
          ) {

            const dados =
              resVinc.data.filter((x) => x != null);

            this.cooperativasVinculadas2 = dados;

          }

          this.verificarGrauCooperativa(false);
          this.changeDetectorRef.markForCheck();
        });
    }
  }

  get somenteLeitura(): boolean {
    return this.cooperativa?.status?.toLowerCase() === 'aprovada' ||
      this.cooperativa?.situacaoCooperativa?.nome?.toLowerCase() === 'cancelada';
  }

  verificarGrauCooperativa(recarregar: boolean): void {

    if (
      this.cooperativa != null &&
      this.cooperativa.categoria != null
    ) {

      if (
        !(typeof this.cooperativa.categoria.minimoCooperativa === 'number')
      ) {
        this.cooperativa = {
          ...this.cooperativa,
          categoria: { ...this.cooperativa.categoria, minimoCooperativa: 0 }
        };
      }

      if (recarregar) {

        this.cooperativasVinculadas2 = [];
      }
    }
  }

  adicionarCnpjFiliada(): void {
    const cooperativaSelecionada = this.cooperativaSelecionada;

    if (!cooperativaSelecionada?.id) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Selecione uma cooperativa antes de adicionar.',
        life: 4000
      });
      return;
    }

    if (!this.validaCoopExisteNaLista()) {
      return;
    }

    const cooperativa = {
      ...cooperativaSelecionada,
      status: 'AGUARDANDO_APROVACAO',
    };

    this.cooperativasVinculadas2 = [
      ...this.cooperativasVinculadas2,
      cooperativa,
    ];

    this.cooperativaSelecionada = null;
  }

  procurarCooperativas(event): void {
    const idCategoria = this.getCategoriaFiliadaEsperada();

    if (!this.cooperativa?.id || !idCategoria) {
      this.cooperativasBusca = [];
      return;
    }

    this.dadosGeraisService
      .buscarCooperativas(event.query, idCategoria)
      .then((res) => {
        this.cooperativasBusca = (res.data || [])
          .filter((coop) => coop.id !== this.cooperativa.id);
        this.changeDetectorRef.markForCheck();
      });
  }

  removerFiliada(obj: CooperativaBasica): void {

    const novaLista =
      this.cooperativasVinculadas2.filter(
        item => item !== obj
      );

    this.cooperativasVinculadas2 = novaLista;
  }

  validaConfederacaoFederacao(): void {

    this.fechaModal.emit(this.cooperativasVinculadas2);

    if (
      this.cooperativasVinculadas2 != null &&
      this.cooperativasVinculadas2.length < 3
    ) {

      this.messageService.add({
        severity: 'error',
        detail: 'Para Confederação ou Central/Federação deve ser inserido ao menos 3 filiadas',
        life: 1000
      });
    }
  }

  validaCoopExisteNaLista(): boolean {
    if (
      this.cooperativaSelecionada &&
      this.cooperativasVinculadas2?.some(
        element => element.id === this.cooperativaSelecionada.id
      )
    ) {

      this.cooperativaSelecionada = null;

      this.messageService.add({
        severity: 'warn',
        detail: 'Cooperativa já consta na lista.',
        life: 1000
      });

      return false;
    }

    return true;
  }

  closeModal(): void {
    this.fechaModal.emit(this.cooperativasVinculadas2);
  }

  salvar(): void {
    if (!this.cooperativasVinculadas2 ||
      this.cooperativasVinculadas2.length < 3) {
      this.messageService.add({
        severity: 'error',
        detail: 'Para Confederação ou Central/Federação devem ser inseridas ao menos 3 filiadas.',
        life: 4000
      });
      return;
    }

    this.closeModal();
    this.changeDetectorRef.markForCheck();
  }

  private getCategoriaFiliadaEsperada(): number {
    const categoriaAtual = this.cooperativa?.categoria?.id;

    if (categoriaAtual === 2) {
      return 1; // Central/Federação gerencia Singulares
    }

    if (categoriaAtual === 3) {
      return 2; // Confederação gerencia Centrais/Federações
    }

    return null;
  }


}
