import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { MessageService } from 'primeng/api';
import { TabViewChangeEvent } from 'primeng/tabview';
import { ApiDadosGeraisService } from 'src/app/api/services/api-dados-gerais.service';

@Component({
  selector: 'app-central-gerenciar-filiadas',
  templateUrl: './central-gerenciar-filiadas.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./central-gerenciar-filiadas.scss'],
})
export class CentralGerenciarFiliadasComponent implements OnInit, OnChanges {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input('registro')
  cooperativa: Cooperativa;

  @Input('visible')
  modalFiliadas: boolean;

  @Input('vinculadas')
  cooperativasVinculadas2: CooperativaBasica[] = [];

  parameterAba: boolean = true;

  /**
   * 0 = Gerenciar Filiadas
   * 1 = Filiação Superior
   */
  @Input()
  abaInicial = 0;

  @Output()
  fechaModal = new EventEmitter<CooperativaBasica[]>();

  cooperativasVinculadas: number[] = [];
  tabViewIndex = 0;

  constructor(
    private dadosGeraisService: ApiDadosGeraisService,
    private messageService: MessageService,
  ) {
  }

  ngOnInit(): void {
    this.tabViewIndex = this.abaInicial || 0;
  }

  ngOnChanges(changes: SimpleChanges): void {

    if (changes.abaInicial && changes.abaInicial.currentValue !== undefined) {
      this.tabViewIndex = changes.abaInicial.currentValue;
    }

    if (changes.visible && changes.visible.currentValue === true) {
      this.tabViewIndex = this.abaInicial || 0;
    }

  }

  get somenteLeitura(): boolean {
    return this.cooperativa?.status?.toLowerCase() === 'aprovada';
  }

  onShowModal(): void {
    this.tabViewIndex = this.abaInicial || 0;
    this.carregaVinculadas();
  }

  onHideModal(): void {
    this.validaConfederacaoFederacao();
  }

  onChangeTab(event: TabViewChangeEvent): void {
    this.tabViewIndex = event.index;
  }

  carregaVinculadas(): void {
    if (
      this.cooperativa != null &&
      this.cooperativa.id != null &&
      (this.cooperativasVinculadas2 == null || this.cooperativasVinculadas2.length === 0)
    ) {
      this.dadosGeraisService.getVinculacoes(this.cooperativa.id)
      .then((response) => {
        if (response && response.data != null && response.data.length > 0) {
          this.cooperativasVinculadas2 = response.data.filter((x) => x != null);
          this.cooperativasVinculadas = new Array<number>(this.cooperativasVinculadas2.length);
        }
        this.verificarGrauCooperativa(false);
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  verificarGrauCooperativa(recarregar: boolean): void {
    if (this.cooperativa != null && this.cooperativa.categoria != null) {

      if (!(typeof this.cooperativa.categoria.minimoCooperativa === 'number')) {
        this.cooperativa.categoria.minimoCooperativa = 0;
      }

      if (recarregar) {
        this.cooperativasVinculadas = [];
        this.cooperativasVinculadas2 = [];
      }

    }
  }

  validaConfederacaoFederacao(): void {

    this.fechaModal.emit(this.cooperativasVinculadas2);

    if (this.somenteLeitura) {
      return;
    }

    if (this.cooperativa?.situacaoCooperativa?.nome?.toLowerCase() === 'cancelada') {
      return;
    }

    if (
      this.tabViewIndex === 0 &&
      this.cooperativasVinculadas2 != null &&
      this.cooperativasVinculadas2.length < 3
    ) {
      this.messageService.add({
        severity: 'error',
        detail: 'Para Confederação ou Central/Federação deve ser inserido ao menos 3 filiadas',
        life: 1000,
      });
    }

  }

  closeModal(vinculadas?: CooperativaBasica[]): void {

    if (vinculadas) {
      this.cooperativasVinculadas2 = vinculadas;
    }

    this.fechaModal.emit(this.cooperativasVinculadas2);

  }

}
