import { AfterContentInit, AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { CooperativaRegistro } from '@cadastro-registro-api/models/CooperativaRegistro';
import { LazyLoadEvent, MessageService } from 'primeng/api';
import { ApiDadosGeraisService } from 'src/app/api/services/api-dados-gerais.service';

@Component({
  selector: 'app-filiadas',
  templateUrl: './filiadas.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./filiadas.scss']
})
export class FiliadasComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input("registro")
  cooperativa: Cooperativa;
  @Input ("visible")
  modalFiliadas: boolean;
  @Output()
  fechaModal = new EventEmitter();
  @Input("vinculadas")
  cooperativasVinculadas2: CooperativaBasica[] = [];

  cooperativasVinculadas: number[] = [];
  cooperativaSelecionada: CooperativaBasica;
  houveAlteracaoForm = false;
  cooperativasBusca: CooperativaBasica[] = [];
  cols: { field: string, header: string, width: string}[];

  constructor(
    private dadosGeraisService: ApiDadosGeraisService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {
    this.cols = [
      { field: 'cnpj', header: 'CNPJ', width: '100%' },
      { field: 'nomeFantasia', header: 'Nome Fantasia', width: '100%'},
      { field: 'uf', header: 'UF' ,  width: '10%' }
    ];


  }

  carregaVinculadas(){
    // ---------------- Vinculações só busca ao abrir o modal --------------------------------------
   if(this.cooperativa != null && this.cooperativa.id != null
      && (this.cooperativasVinculadas2 == null || this.cooperativasVinculadas2.length == 0) ){

      this.dadosGeraisService.getVinculacoes(this.cooperativa.id)
      .then((resVinc) => {
        if (resVinc && resVinc.data != null && resVinc.data.length > 0) {
          const dados = resVinc.data.filter((x) => x != null); // Tirar itens nulos da listagem

          this.cooperativasVinculadas2 = dados;
          this.cooperativasVinculadas = new Array<number>(this.cooperativasVinculadas2.length);
        }
        this.verificarGrauCooperativa(false);
        this.changeDetectorRef.markForCheck();
      });
    }

  }

  verificarGrauCooperativa(recarregar: boolean) {
    if (this.cooperativa != null && this.cooperativa.categoria != null) {
      if (!(typeof this.cooperativa.categoria.minimoCooperativa === 'number')) {
        this.cooperativa.categoria.minimoCooperativa = 0;
      }

      if(recarregar){
        this.cooperativasVinculadas = [];
        this.cooperativasVinculadas2 = [];
      }
    }
  }

  adicionarCnpjFiliada(){
    if(this.validaCoopExisteNaLista()){
      if(this.cooperativaSelecionada != null && this.cooperativaSelecionada.id != null){
        this.cooperativasVinculadas2 = [
          ...this.cooperativasVinculadas2,
          this.cooperativaSelecionada
        ];
        this.cooperativaSelecionada = null;
      }
    }
  }

  procurarCooperativas(event) {
    const query = event.query;
    if (this.cooperativa != null && this.cooperativa.categoria != null) {
      this.dadosGeraisService.buscarCooperativas(event.query, this.cooperativa.categoria.id)
      .then((res) => {
        if(res.data && res.data.length > 0){
          this.cooperativasBusca = res.data.filter((coop) => coop.id !== this.cooperativa.id);
        } else {
          this.cooperativasBusca = [];
          this.cooperativaSelecionada = null;
        }
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  removerFiliada(obj: CooperativaBasica){
    const novaLista = this.cooperativasVinculadas2.filter(item => item !== obj);
    this.cooperativasVinculadas2 = novaLista;
  }

  validaConfederacaoFederacao(){
    this.fechaModal.emit(this.cooperativasVinculadas2);

    if(this.cooperativasVinculadas2 != null && this.cooperativasVinculadas2.length < 3){
      this.messageService.add({severity: 'error', detail: 'Para Confederação ou Central/Federação deve ser inserido ao menos 3 filiadas', life: 1000});
    }
  }

  validaCoopExisteNaLista(){
    if(this.cooperativasVinculadas2 && this.cooperativasVinculadas2.find( element => element.id === this.cooperativaSelecionada.id) != null){
      this.cooperativaSelecionada = null;
      this.messageService.add({severity: 'warn', detail: 'Cooperativa já consta na lista.', life: 1000});
      return false;
    } else {
      return true;
    }
  }
}
