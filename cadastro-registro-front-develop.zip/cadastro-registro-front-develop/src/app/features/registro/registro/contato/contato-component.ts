
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiAreaContatoService } from '@cadastro-registro-api/services/api-area-contato.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ValidacaoContato } from '@shared/registro/contato/validacao/validacao-contato.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { AreaContato } from '@cadastro-registro-api/models/AreaContato';
import { Contato } from '@cadastro-registro-api/models/Contato';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { Pessoa } from '@cadastro-registro-api/models/Pessoa';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { ApiControleAbasRegistroService } from '@cadastro-registro-api/services/api-controle-abas-registro.service';
import { ControleAbasRegistroEnum } from '@cadastro-registro-api/models/ControleAbasRegistroEnum';
import { forkJoin } from 'rxjs';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { PermissaoCooperativa } from 'src/app/features/cooperativa/permissao/permissao.service';
import { StringUtil } from '@shared/utils/StringUtil';
import { ApicontatoService } from 'src/app/api/services/api-contatos-service';
import { ContatoTO } from 'src/app/api/models/ContatoTO';


@Component({
  selector: 'app-contato-component',
  templateUrl: './contato-component.html',
  styleUrls: ['./contato-component.scss'],
})
export class ContatoComponent implements OnInit {
  @ViewChild('contatosForm') contatosForm: NgForm;
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  @Input() exibirErros = true;
  @Output() successEvent = new EventEmitter<IServiceMessage[]>();

  @Input() cooperativaManutencao: CooperativaManutencao;
  @Input() isManutencao = false;

  nomePessoaJuridica: string;
  listAreaContato: AreaContato[];
  listaContatos: Contato[];
  listaContatosTO: ContatoTO[]
  // mensagensValidacao = new Array<Messages>();
  mensagem: IServiceMessage;
  contatosNaoSalvos = 0;
  houveAlteracaoForm = false;
  salvando = false;
  objCooperativa: Cooperativa;
  situacaoEnum = SituacaoEnum;
  cols: { field: string; header: string }[];
  contatoObrigatorio : boolean;
  podeModificarCampos: boolean;

  constructor(
    private apiAreaContatoService: ApiAreaContatoService,
    private apiContatoService: ApicontatoService,
    public keycloakService: KeycloakService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    public utilityService: UtilityService,
    public validacaoContato: ValidacaoContato,
    private apiPj: ApiPessoaJuridicaService,
    private apiControleAbas: ApiControleAbasRegistroService,
    private permissaoCooperativa: PermissaoCooperativa
  ) {}

  ngOnInit(): void {
    this.carregarTela();
    this.cols = [
      { field: 'cpf', header: 'CPF' },
      { field: 'nome', header: 'Nome completo' },
      { field: 'genero', header: 'Sexo' },
      { field: 'cargo', header: 'Cargo' },
      { field: 'responsavelLegal', header: 'Representante legal' },
    ];
  }

  adicionarContato(idxArea: number): void {
    this.listAreaContato[idxArea].contatos.push(new Contato());
  }

  removerContato(idxArea: number, idxContato: number): void {
    this.listAreaContato[idxArea].contatos.splice(idxContato, 1);
    this.houveMudancaForm();
    if (this.contatosForm.pristine) {
      this.contatosForm.form.markAsDirty();
    }
  }

  private getListAreaContatoAtiva() {
    return this.apiAreaContatoService.getListAreaContatoPorUf(this.objCooperativa.pessoaJuridica.ufSigla);
  }

  private getListAreaContatoCooperativa() {
    return this.apiContatoService.getListAreaContatoPorPessoa(this.objCooperativa.id);
  }

  private atribuiContatoArea(){
    this.listAreaContato.forEach(ac => {
      ac.contatos = [];

      this.listaContatos.forEach(c =>  {
        if(c.areaContato.id === ac.id){
          ac.contatos.push(c);
        }
      });
      if(ac.contatos.length === 0){
        ac.contatos.push(new Contato());
      }
    });
  }

  carregarTela(): void {
    this.podeModificarCampos = this.permissaoCooperativa.permissaoAtualizarCadastro();
    this.formMarkAsPristine();
    this.desativaEventoForm();
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false).then((coop) => {
      if (coop) {
        this.objCooperativa = coop;
        this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla).then((pj) => {
          this.nomePessoaJuridica = pj.data.nomeFantasia;
        });

        forkJoin(// as of RxJS 6.5+ we can use a dictionary of sources
        {
          listAreaContato: this.getListAreaContatoAtiva(),
          listContato: this.getListAreaContatoCooperativa()
        }).subscribe(response => {
          this.listAreaContato = response.listAreaContato.data;
          this.listaContatos = response.listContato.data;
          this.atribuiContatoArea();
        });

      }
    });
  }

  salvar(abaDestino: number) {
    if (this.salvando) {
      return;
    }
    this.salvando = true;
    this.houveAlteracaoForm = true;

    if (!this.isManutencao) {
      abaDestino = 5;
    }

    this.formMarkAsPristine();

    const aba = {
      id: null,
      cooperativa: { id: Number(this.objCooperativa.id) },
      dataEnvio: null,
      aba: ControleAbasRegistroEnum.CONTATOS,
      enviada: true
    };

    this.apiControleAbas.save(aba).subscribe();

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.listaContatos = [];
        this.listaContatosTO = []; // <-- Inicializa corretamente
        const arrPendencia: { nomeArea: string; qtd: number }[] = [];

        this.listAreaContato.forEach((area) => {
          area.contatos.forEach((item) => {
            item.areaContato = new AreaContato();
            item.areaContato.id = area.id;
            item.areaContato.utilizaCargo = area.utilizaCargo;
            item.areaContato.obrigatorio = area.obrigatorio;

            item.pessoa = new Pessoa();
            item.pessoa.id = coop.id;

            item.telefone = this.utilityService.retirarFormatacaoTelefone(item.telefone);

            if (item.areaContato.obrigatorio) {
              this.contatoObrigatorio = item.areaContato.obrigatorio;
            }

            const preenchido = !this.isUndefinedOrNull(item.nomeResponsavel)
              || !this.isUndefinedOrNull(item.telefone)
              || !this.isUndefinedOrNull(item.email)
              || this.contatoObrigatorio;

            if (preenchido) {
              this.listaContatos.push(item);
              this.contatosNaoSalvos++;

              const index = arrPendencia.findIndex(p => p.nomeArea === area.nome);
              if (index >= 0) {
                arrPendencia[index].qtd++;
              } else {
                arrPendencia.push({ nomeArea: area.nome, qtd: 1 });
              }
            }
          });
        });

        this.listaContatos.forEach(contato => {
          const to = new ContatoTO();
          to.id = contato.id;
          to.cargo = contato.cargo;
          to.celular = contato.celular;
          to.nomeResponsavel = contato.nomeResponsavel;
          to.site = contato.site;
          to.email = contato.email;
          to.telefone = contato.telefone;
          to.idPessoa = contato.pessoa?.id ?? coop.id;
          to.idAreaContato = contato.areaContato?.id;
          this.listaContatosTO.push(to);
        });

        this.apiContatoService
          .salvaLista(this.listaContatosTO, coop.id)
          .then(resp => {
            this.houveAlteracaoForm = false;
            window.scroll(0, 0);

            this.evtFimSalvarDados.emit(abaDestino);
            this.evtSalvarDados.emit(true);
            this.successEvent.emit(resp.messages);

            this.listaContatosTO = []; // limpa corretamente
            this.carregarTela();
          })
          .catch(() => {
            this.evtErroSalvar.emit(true);
          })
          .finally(() => {
            this.salvando = false;
          });
      } else {
        this.salvando = false;
      }
    });
  }


  private isUndefinedOrNull(val): boolean {
    return val === '' || val === null || val === undefined;
  }

  houveMudancaForm(): void {
    this.houveAlteracaoForm = true;
  }

  getAlteracaoForm(): boolean {
    return this.houveAlteracaoForm;
  }

  desativaEventoForm(): void {
    this.houveAlteracaoForm = false;
  }

  selectMask(event: Event): void {
    setTimeout(() => (event.target as HTMLInputElement).select(), 100);
  }

  private formMarkAsPristine(): void {
    if (this.contatosForm) {
      Object.keys(this.contatosForm.controls).forEach((key) => {
        this.contatosForm.controls[key].markAsPristine();
      });
      this.contatosForm.form.markAsPristine();
    }
  }

  formatarId(nome){
    const semAcento =  StringUtil.limparTexto(nome.toLowerCase())
    let palavras = semAcento.split(' ')
    if(palavras.length > 1){
      palavras = palavras.filter(p => p.length > 2)
    }
    const [primeiro, segundo] = palavras

    return [primeiro, segundo].join('-')
  }


   /*isInvalidForm(): boolean {
     if (this.contatosForm) {
       const valids = Object.keys(this.contatosForm.controls).map(key => {
         const formGroup = this.contatosForm.controls[key];
         return (formGroup.dirty && formGroup.valid) || formGroup.pristine;
       });
       const valid = valids.reduce((acc, currentValue) => acc && currentValue);
       this.campoVazio = !valid;
       return !valid;
     }
     return true;
   }*/

  atribuirContatoObrigatorio(obrigatorio: boolean) {
    this.contatoObrigatorio = obrigatorio;
    return '';
  }
}
