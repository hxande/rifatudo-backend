import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AbaProcessoRegistroComponent } from './aba-processo-registro/aba-processo-registro.component';
import { ListagemProcessoRegistroComponent } from './listagem-processo-registro/listagem-processo-registro.component';
import { ListagemProcessoRegistroNacionalComponent } from './listagem-processo-registro-nacional/listagem-processo-registro-nacional.component';
import { PassosProcessoRegistroComponent } from './passos-processo-registro/passos-processo-registro.component';
import { PendenciaRegistroComponent } from './pendencia-registro/pendencia-registro.component';
import { ProcessoRegistroComponent } from './processo-registro/processo-registro-component';
import { CadastroRegistroComponent } from './registro/cadastroRegistro/cadastro-registro-component';
import { ContatoComponent } from './registro/contato/contato-component';
import { DadosGeraisComponent } from './registro/dadosGerais/dados-gerais-component';
import { DocumentosComponent } from './registro/documentos/documentos-component';
import { NegocioComponent } from './registro/negocio/negocio.component';
import { RegistroArquivadoComponent } from './registro-arquivado/registro-arquivado.component';
import { RequerimentoRegistroConcluidoComponent } from './requerimentoRegistro/requerimento-registro-concluido.component';
import { RequerimentoRegistroComponent } from './requerimentoRegistro/requerimento-registro.component';
import { SharedModule } from '@shared/shared.module';
import { RegistroRoutingModule } from './registro-routing.module';
import { DocumentoFilialComponent } from './documento-filial/documento-filial.component';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { FieldsetModule } from 'primeng/fieldset';
import { StepsModule } from 'primeng/steps';
import { CalendarModule } from 'primeng/calendar';
import { ManutencaoCadastroRegistroComponent } from './manutencao/cadastro-registro/manutencao-cadastro-registro-component';
import { ManutencaoDadosGeraisComponent } from './manutencao/dadosGerais/manutencao-dados-gerais-component';
import { ManutencaoDocumentacaoComponent } from './manutencao/documentacao/manutencao-documentacao.component';
import { ManutencaoNegocioComponentComponent } from './manutencao/negocio/manutencao-negocio-component.component';
import { HistoricoGovernancaComponent } from './manutencao/governanca/historico-governanca/historico-governanca.component';
import { ProcessoRegistroCooperativaComponent } from './processo-registro/processo-registro-cooperativa-component';
import { ConsultaDocumentoComponent } from './registro/documentos/consulta-documento/consulta-documento.component';
import { ConsultaDocumentoCooperativaComponent } from './registro/documentos/consulta-documento/consulta-documento-cooperativa.component';
import { ConsultaDocumentoOcbComponent } from './registro/documentos/consulta-documento/consulta-documento-ocb.component';
import { ConsultaDocumentosOutrosComponent } from './registro/documentos/consulta-documento/consulta-documentos-outros/consulta-documentos-outros.component';
import { ListaCertificadoValidoComponent } from './lista-certificado-valido/lista-certificado-valido.component';
import { GovernancaSharedComponent } from './governanca-shared/governanca-shared.component';
import { TrilhaAcoesGovernancaComponent } from './governanca-shared/trilha-acoes/trilha-acoes-governanca.component';
import { HistoricoApontamentoComponent } from './processo-registro/historico-apontamento/historico-apontamento.component';
import {SidebarModule} from 'primeng/sidebar';
import { PrimeNgUtilsModule } from '@gui/primeng/utils/primeng-utils.module';
import { RedeSocialComponent } from './rede-social/rede-social.component';
import { QuadroSocialUfComponent } from './quadro-social-uf/quadro-social-uf.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FiliadasComponent } from './registro/filiadas/filiadas.component';
import { CooperativaModule } from '../cooperativa/cooperativa.module';
import { FiliacaoSuperiorComponent } from './registro/filiacao-superior/filiacao-superior.component';
import { GerenciarFiliadasComponent } from './registro/gerenciar-filiadas/gerenciar-filiadas.component';
import { CentralGerenciarFiliadasComponent } from './registro/central-gerenciar-filiadas/central-gerenciar-filiadas.component';
import { FiliacaoSuperiorContentComponent } from './registro/filiacao-superior/content/filiacao-superior-content.component';
import { GerenciarFiliadasContentComponent } from './registro/gerenciar-filiadas/content/gerenciar-filiadas-content.component';
// Redesign 2026-07-06: o accordion por conselho foi incorporado ao próprio
// GovernancaSharedComponent — os componentes aditivos foram removidos.


@NgModule({
  declarations: [
    AbaProcessoRegistroComponent,
    ListagemProcessoRegistroComponent,
    ListagemProcessoRegistroNacionalComponent,
    PassosProcessoRegistroComponent,
    PendenciaRegistroComponent,
    ProcessoRegistroComponent,
    HistoricoApontamentoComponent,
    CadastroRegistroComponent,
    ContatoComponent,
    DadosGeraisComponent,
    DocumentosComponent,
    NegocioComponent,
    RegistroArquivadoComponent,
    RequerimentoRegistroConcluidoComponent,
    RequerimentoRegistroComponent,
    DocumentoFilialComponent,
    ManutencaoCadastroRegistroComponent,
    ManutencaoDadosGeraisComponent,
    ManutencaoDocumentacaoComponent,
    ManutencaoNegocioComponentComponent,
    HistoricoGovernancaComponent,
    ProcessoRegistroCooperativaComponent,
    ConsultaDocumentoComponent,
    ConsultaDocumentoCooperativaComponent,
    ConsultaDocumentoOcbComponent,
    ConsultaDocumentosOutrosComponent,
    RequerimentoRegistroComponent,
    RequerimentoRegistroConcluidoComponent,
    RegistroArquivadoComponent,
    ListaCertificadoValidoComponent,
    GovernancaSharedComponent,
    TrilhaAcoesGovernancaComponent,
    RedeSocialComponent,
    QuadroSocialUfComponent,
    FiliadasComponent,
    FiliacaoSuperiorComponent,
    FiliacaoSuperiorContentComponent,
    GerenciarFiliadasComponent,
    GerenciarFiliadasContentComponent,
    CentralGerenciarFiliadasComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RegistroRoutingModule,
    CurrencyMaskModule,
    StepsModule,
    FieldsetModule,
    CalendarModule,
    CooperativaModule,
    SidebarModule,
    PrimeNgUtilsModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class RegistroModule { }
