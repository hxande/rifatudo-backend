import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';

@Component({
  selector: 'app-registro-arquivado',
  templateUrl: './registro-arquivado.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./registro-arquivado.component.css']
})
export class RegistroArquivadoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativa = new Cooperativa();
  pessoaJuridica = new PessoaJuridica();

  constructor(private apiCadastroRegistroService: ApiCadastroRegistroService,
    private keycloakService: KeycloakService,
    private apiPj: ApiPessoaJuridicaService) {

  }

  ngOnInit() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.cooperativa = coop;
        this.apiPj.buscaUnidadeResponsavel(this.cooperativa.pessoaJuridica.ufSigla).then(pj => {
          this.pessoaJuridica = pj.data;
          this.changeDetectorRef.markForCheck();
        });
      }
      this.changeDetectorRef.markForCheck();
    });
  }
}
