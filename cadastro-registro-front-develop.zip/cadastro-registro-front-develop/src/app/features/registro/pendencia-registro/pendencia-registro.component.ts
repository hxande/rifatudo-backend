import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiPendenciaRegistroService } from '@gerencia-usuario-api/services/api-pendencia-registro.service';

@Component({
  selector: 'app-pendencia-registro',
  templateUrl: './pendencia-registro.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./pendencia-registro.component.css']
})
export class PendenciaRegistroComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  status: string;
  error: boolean;
  cadastroRealizado: boolean;

  constructor(private apiPendenciaRegistroService: ApiPendenciaRegistroService,
    private keycloakService: KeycloakService) { }

  ngOnInit() {

    this.status = 'Registrando pendência...';

    const msgAguardando = 'Caro usuário, seu cadastro foi realizado com sucesso. ' +
      'Vamos analisar sua solicitação e assim que for aprovada você receberá um e-mail de confirmação.';
    const msgError = 'Não foi possível enviar solicitação de ativação de registro, tente mais tarde.';

    this.apiPendenciaRegistroService.criar()
      .then(() => {
        this.status = msgAguardando;
        this.cadastroRealizado = true;
        this.changeDetectorRef.markForCheck();
      })
      .catch(reason => {
        try {
          if (reason.status !== 400) {
            this.error = reason.status;
          }
          this.status = reason.error.messages[0].message;
        } catch {
          this.status = msgError;
        }
        this.changeDetectorRef.markForCheck();
      });
  }

  logout(): void {
    this.keycloakService.logout();
  }

}
