import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Uf } from '@localizacao-api/models/Uf';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ValidacaoCooperativa } from '../validacao/validacao-cooperativa.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { MessageService } from 'primeng/api';
import { ValidadorCampo } from '@utils/utility/validador-campo';

@Component({
  selector: 'app-aba-processo-registro',
  templateUrl: './aba-processo-registro.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./aba-processo-registro.component.scss']
})
export class AbaProcessoRegistroComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private keycloakService: KeycloakService,
    private router: Router,
    private ufService: ApiUFService,
    private apiCooperativaService: ApiCooperativaService,
    private pessoaJuridicaService: ApiPessoaJuridicaService,
    public breadCrumbPrimeNGService: BreadcrumbService,
    public validacaoCooperativa: ValidacaoCooperativa,
    private messageService: MessageService,
  ) { }

  tipoUsuario;
  cadastroCoop = false;
  ufSelecionada;
  ufs: Uf[];
  cnpjInvalido: boolean;
  ufInvalido = false;
  cnpjEntidade: string;
  razaoSocialNaoPreenchida = false;
  cooperativaBanco: PessoaJuridica;
  razaoSocial: string;
  entidadeExiste = false;
  naturezaInvalida = false;
  formCadastro = true;
  travaCampos = false;
  salvando = false;


  get desabilitarSalvar(): boolean {
    return this.salvando ||
      !this.cnpjEntidade ||
      this.cnpjInvalido ||
      this.entidadeExiste ||
      this.naturezaInvalida ||
      !this.razaoSocial ||
      !this.ufSelecionada ||
      !this.ufSelecionada.sigla;
  }

  ngOnInit() {
    this.tipoUsuario = this.keycloakService.getTipo();
    if (this.tipoUsuario === 'C') {
      return this.router.navigateByUrl('/registro/processo-cooperativa');
    }
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: 'inicio' },
      { label: 'Processo de Registro', routerLink: '/registro/listagem' }
    ]);
    this.inicializaUF();
  }

  buscarEntidadeExistente() {
    if (this.cnpjEntidade && this.validaCnpj()) {
      this.buscaPorCnpj(this.cnpjEntidade);
    }
  }

  async buscaPorCnpj(cnpjEntidade) {
    const cnpjEntidadeSemMascara = ValidadorCampo.removeMascaraCnpj(cnpjEntidade);

    try {
      const response = await this.pessoaJuridicaService.buscaPorCnpjCoop(cnpjEntidadeSemMascara, 'C', 'cadastro-registro');

      if (response.data) {
        this.cooperativaBanco = response.data;
        this.naturezaInvalida = !this.permiteCadastro(this.cooperativaBanco);

        if (!this.naturezaInvalida) {
          const indexUf = this.ufs.findIndex(uf => uf.sigla === this.cooperativaBanco.ufSigla);
          this.ufSelecionada = this.ufs[indexUf];
          this.razaoSocial = this.cooperativaBanco.razaoSocial;

          if (this.cooperativaBanco.nomeFantasia === null) {
            this.cooperativaBanco.nomeFantasia = this.cooperativaBanco.razaoSocial;
          }
          this.travaCampos = true;
        } else {
          this.razaoSocial = '';
          this.travaCampos = false;
        }
      } else {
        this.messageService.add({ severity: 'warn', detail: 'Não localizado na Receita Federal', life: 100000 });
        this.razaoSocial = '';
        this.travaCampos = false;
        this.cooperativaBanco = new PessoaJuridica();
        this.naturezaInvalida = false;
      }
    } catch (error) {
      console.error('Erro ao buscar CNPJ:', error);
    } finally {
      this.changeDetectorRef.markForCheck();
    }
  }

  permiteCadastro(pj: PessoaJuridica): boolean {
    return pj.tipoPessoa === 'C' || (pj.tipoPessoa === 'O' && pj.naturezaJuridica?.id === 2143);
  }

  removeMascaraCnpj(cnpjEntidade) {
    let cnpjEntidadeSemMascara = '';
    if (cnpjEntidade) {
      cnpjEntidadeSemMascara = cnpjEntidade.replace(/[^\d]+/g, '');
    }
    return cnpjEntidadeSemMascara;
  }

  validaCnpj() {
    this.cnpjInvalido = !ValidadorCampo.validaCnpj(this.cnpjEntidade);
    return !this.cnpjInvalido;
  }

  analisarCadastro(cooperativa: CooperativaBasica) {
    this.router.navigate(['/registro/cadastro'], { queryParams: { id_cooperativa: cooperativa.id }, skipLocationChange: false });
  }

  validaRazaoSocial() {
    const validaRazao = ValidadorCampo.validaCampoVazio(this.razaoSocial);
    this.razaoSocialNaoPreenchida = !validaRazao;
    return validaRazao ? true : false;
  }

  validaUF() {
    if (this.ufSelecionada.sigla === '') {
      this.ufInvalido = true;
      return false;
    }
    this.ufInvalido = false;
    return true;
  }

  salvar() {
    const cnpjValido = this.validaCnpj();
    const razaoValido = this.validaRazaoSocial();
    const ufValido = this.validaUF();

    if (!cnpjValido || !ufValido || !razaoValido || this.entidadeExiste || this.naturezaInvalida) {
      return;
    }

    const coperativaBasica = new CooperativaBasica();
    coperativaBasica.razaoSocial = this.razaoSocial;
    //ajuste
    //coperativaBasica.nomeFantasia = this.cooperativaBanco && this.cooperativaBanco.nomeFantasia ? this.cooperativaBanco.nomeFantasia : this.razaoSocial;
    coperativaBasica.cnpj = this.cnpjEntidade;
    coperativaBasica.ufSigla = this.ufSelecionada.sigla;

    this.salvando = true;
    this.apiCooperativaService.cadastraCooperativaSemUsuario(coperativaBasica)
    .then(resp => {
      const cooperativa = resp.data;
      this.analisarCadastro(cooperativa);
    })
    .finally(() => {
      this.salvando = false;
      this.changeDetectorRef.markForCheck();
    });
  }

  inicializaUF() {
    this.ufSelecionada = new Uf();
    this.ufSelecionada.sigla = this.keycloakService.getTipo() === 'N' ? '' : this.keycloakService.getUF();
    this.ufService.obterUfs().then(response => {
      this.ufs = response;
      this.changeDetectorRef.markForCheck();
    });
  }

  cadastraCooperativa() {
    this.cadastroCoop = true;
  }

}
