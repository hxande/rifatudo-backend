import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from '@auth/auth-guard/auth-guard.service';
import { AbaProcessoRegistroComponent } from './aba-processo-registro/aba-processo-registro.component';
import { ListaCertificadoValidoComponent } from './lista-certificado-valido/lista-certificado-valido.component';
import { ListagemProcessoRegistroNacionalComponent } from './listagem-processo-registro-nacional/listagem-processo-registro-nacional.component';
import { ManutencaoCadastroRegistroComponent } from './manutencao/cadastro-registro/manutencao-cadastro-registro-component';
import { PendenciaRegistroComponent } from './pendencia-registro/pendencia-registro.component';
import { ProcessoRegistroComponent } from './processo-registro/processo-registro-component';
import { ProcessoRegistroCooperativaComponent } from './processo-registro/processo-registro-cooperativa-component';
import { RegistroArquivadoComponent } from './registro-arquivado/registro-arquivado.component';
import { CadastroRegistroComponent } from './registro/cadastroRegistro/cadastro-registro-component';
import { ConsultaDocumentoComponent } from './registro/documentos/consulta-documento/consulta-documento.component';
import { RequerimentoRegistroConcluidoComponent } from './requerimentoRegistro/requerimento-registro-concluido.component';
import { RequerimentoRegistroComponent } from './requerimentoRegistro/requerimento-registro.component';
import { ProcessoRegistroGuard } from '@shared/guard/processo-registro.guard';
import { ProcessoRegistroCooperativaGuard } from '@shared/guard/processo-registro-cooperativa.guard';
import { AlteracoesPendentesGuard } from '@shared/guard/alteracoes-pendentes.guard';


const routes: Routes = [
  { path: 'listagem', component: AbaProcessoRegistroComponent, canActivate: [AuthGuardService] },
  { path: 'cadastro', component: CadastroRegistroComponent, canActivate: [AuthGuardService], canDeactivate: [AlteracoesPendentesGuard] },
  { path: 'documentos', component: ConsultaDocumentoComponent, canActivate: [AuthGuardService] },
  {
    path: 'manutencaoCadastro',
    component: ManutencaoCadastroRegistroComponent,
    canActivate: [AuthGuardService],
    canDeactivate: [AlteracoesPendentesGuard],
  },
  { path: 'processo', component: ProcessoRegistroComponent, canActivate: [AuthGuardService,ProcessoRegistroGuard] },
  {
    path: 'processo-cooperativa',
    component: ProcessoRegistroCooperativaComponent,
    canActivate: [AuthGuardService, ProcessoRegistroCooperativaGuard],
  },
  { path: 'requerimento', component: RequerimentoRegistroComponent, canActivate: [AuthGuardService] },
  {
    path: 'requerimento-concluido',
    component: RequerimentoRegistroConcluidoComponent,
    canActivate: [AuthGuardService],
  },
  { path: 'arquivado', component: RegistroArquivadoComponent, canActivate: [AuthGuardService] },
  {
    path: 'listagem-processo-registro-nacional',
    component: ListagemProcessoRegistroNacionalComponent,
    canActivate: [AuthGuardService],
  },
  { path: 'registrapendencia', component: PendenciaRegistroComponent },
  { path: 'consulta-certificado', component: ListaCertificadoValidoComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RegistroRoutingModule {}
