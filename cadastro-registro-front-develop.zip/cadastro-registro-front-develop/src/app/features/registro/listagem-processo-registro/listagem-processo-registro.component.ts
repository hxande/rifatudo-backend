import { HttpParams } from '@angular/common/http';
import { ChangeDetectionStrategy, Component, Input, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { Table } from 'primeng/table';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { CacheService } from '@utils/cache/cache.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ValidacaoCooperativa } from '../validacao/validacao-cooperativa.service';
import { ListagemProcessoRegistroComponentGeneric } from '../../cooperativa/listagem-processo-registro-component-generic';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { CooperativaLeituraService } from 'src/app/api/services/api-cooperativa-leitura.service';

type colsType = { field: string; header: string; width: string; sortable: boolean; visible: boolean };
@Component({
  selector: 'app-listagem-processo-registro',
  templateUrl: './listagem-processo-registro.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./listagem-processo-registro.component.css'],
})
export class ListagemProcessoRegistroComponent extends ListagemProcessoRegistroComponentGeneric implements OnInit {

  @Input() arquivado = false;
  @Input() preCadastro = false;
  @Input() emAndamento = false;
  @ViewChild('dt') dt: Table;
  filtrotelefoneUsuario = '';
  filtroLivre = '';
  cols: colsType[] = [];

  constructor(
    public cooperativaService: ApiCooperativaService,
    public usuarioService: ApiUsuarioService,
    public cooperativaLeituraService: CooperativaLeituraService,
    public utilityService: UtilityService,
    public cacheService: CacheService,
    public router: Router,
    private breadcrumbService: BreadcrumbService,
    public messageService: MessageService,
    public ramoApi: ApiRamoService,
    public validacaoCooperativa: ValidacaoCooperativa
  ) {
    super(cooperativaService, usuarioService, cooperativaLeituraService, ramoApi, utilityService, router, messageService);
    this.breadcrumbService.setItems([
      { label: 'Início', routerLink: '/' },
      { label: 'Processo de Registro', routerLink: '/registro/listagem' },
      { label: 'Cooperativa' },
    ]);
  }

  getTable(): Table {
    return this.dt;
  }

  onRowSelect(idCooperativa) {
    this.cooperativaService.marcarComoVisualizada(idCooperativa);
    this.router.navigate(['/registro/processo'], { queryParams: { id_cooperativa: idCooperativa }, skipLocationChange: false });
  }

  ngOnInit() {
    if(this.emAndamento){
      this.fases = this.fases.filter(fase => fase.value !== '0');
    }
    this.cols = [
      { field: 'id', header: 'Nº do processo', width: '89px', sortable: true , visible: true },
      { field: 'pessoaJuridica.ramo.nome', header: 'Ramo', width: '100px', sortable: true , visible: true },
      { field: 'pessoaJuridica.nomeFantasia', header: 'Cooperativa', width: '180px', sortable: true , visible: true},
      { field: 'progressoMacro' , header: 'Fase do processo', width: '100px', sortable: true , visible: !this.preCadastro},
      { field: 'dataUltimaAnaliseUE' , header: 'Data de aprovação dos dados', width: '107px', sortable: true,visible: !this.preCadastro},
      { field: 'dataPrazoRegistro', header: 'Prazo para conclusão do processo', width: '107px', sortable: true,visible: !this.preCadastro },
      { field: 'responsavel', header: 'Responsável', width: '120px', sortable: false,visible: !this.preCadastro },
    ];
    if(this.dt){
      this.loadLazy(this.dt.createLazyLoadMetadata());
    }
    // this.buscarRamos();
  }

  loadSpecificOptions(options: {params: HttpParams}): void {
    options.params = this.utilityService.carregaParamsString(this.filtrotelefoneUsuario, options.params, 'telefoneUsuario');
    options.params = this.utilityService.carregaParamsString(this.filtroLivre, options.params, 'pesquisaLivre');
    options.params = this.utilityService.carregaParamsString(this.arquivado, options.params, 'arquivado');
    if(this.preCadastro){
      options.params = this.utilityService.carregaParamsString('0', options.params, 'progressosMacros');
    }
    if(this.emAndamento){
      if(!this.filtroFases || this.filtroFases.length == 0){
        const fases = this.fases.map((fase) => fase.value);
        this.getFiltroFases(fases,options);
      }
    }
  }

  selectMask(event: Event) {
    setTimeout(() => (event.target as HTMLInputElement).select(), 100);
  }


  exportarTabelaEstadual(){
    if(!this.preCadastro) {
      this.exportarRelatorio('PROCESSO_REGISTRO_SIMPLIFICADO');
    } else {
      this.exportarRelatorio('PROCESSO_REGISTRO_PRE_CADASTRO');
    }

  }
}
