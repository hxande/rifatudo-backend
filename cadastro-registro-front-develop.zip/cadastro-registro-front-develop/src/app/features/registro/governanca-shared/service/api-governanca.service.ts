import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Governanca } from '@cadastro-registro-api/models/Governanca';
import { MandatoMembro } from '@cadastro-registro-api/models/MandatoMembro';
import { AcaoGovernancaTO } from 'src/app/api/models/AcaoGovernancaTO';
import { MandatoTO } from 'src/app/api/models/MandatoTO';
import { PendenciasGovernancaTO } from 'src/app/api/models/PendenciasGovernancaTO';

/**
 * Serviço local de Governança (Registro + Manutenção).
 *
 * Substitui o cliente compartilhado de `src/public` (submódulo) para que o
 * contrato HTTP interno do redesign — salvar-por-conselho — possa evoluir sem
 * alterar o submódulo, que é consumido por outros projetos.
 * Os GET de leitura permanecem idênticos aos do cliente compartilhado.
 */
@Injectable({
  providedIn: 'root',
})
export class ApiGovernancaService {

  private readonly base = '/cadastro-registro-api/api/v1/governanca';

  constructor(private http: HttpClient) {}

  /** GET preservado: leitura da governança da cooperativa. */
  buscaGovernancasPorCooperativa(cooperativaId: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Governanca[]>>(`${this.base}/buscaPorCooperativa/${cooperativaId}`)
    );
  }

  /**
   * Novo contrato unificado: grava SOMENTE o conselho/órgão informado
   * (mandato + membros), com isolamento por órgão. Retorna o `MandatoTO`
   * salvo com `dataAtualizacao`. Mesmo contrato para Registro e Manutenção —
   * substitui o salvar-da-aba.
   */
  salvarPorConselho(cooperativaId: number, orgaoId: number, mandato: MandatoTO, manutencao = false) {
    return firstValueFrom(
      this.http.post<IServiceResponse<MandatoTO>>(
        `${this.base}/${cooperativaId}/conselho/${orgaoId}?manutencao=${manutencao}`,
        mandato,
        { reportProgress: false }
      )
    );
  }

  /**
   * Inclusão inline de um único membro no conselho ("Incluir e salvar"):
   * adiciona apenas o membro informado ao mandato vigente do órgão,
   * preservando os demais. O corpo é o próprio `MandatoMembro`
   * (pessoa física aninhada + cargo), mesmo formato dos itens de
   * `listaMandatoMembro` do salvar-por-conselho.
   */
  incluirMembro(cooperativaId: number, orgaoId: number, membro: MandatoMembro, manutencao = false) {
    return firstValueFrom(
      this.http.post<IServiceResponse<MandatoTO>>(
        `${this.base}/${cooperativaId}/conselho/${orgaoId}/membro?manutencao=${manutencao}`,
        membro,
        { reportProgress: false }
      )
    );
  }

  /**
   * GET das pendências agregadas da aba. Retorna, por conselho, as pendências
   * necessárias para submeter e a decisão agregada `podeAvancar`. Contrato
   * interno do redesign — pode evoluir.
   */
  buscarPendencias(cooperativaId: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<PendenciasGovernancaTO>>(
        `${this.base}/${cooperativaId}/pendencias`
      )
    );
  }

  buscarTrilhaAcoes(cooperativaId: number, orgaoId: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<AcaoGovernancaTO[]>>(
        `${this.base}/${cooperativaId}/conselho/${orgaoId}/trilha-acoes`
      )
    );
  }

  // Sem consumidor no front: a reativação passou a ser persistida pelo salvarPorConselho.
  reativarMembro(idMandatoMembro: number) {
    return firstValueFrom(
      this.http.put<IServiceResponse<MandatoMembro>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/reativar-membro/${idMandatoMembro}`,
        null
      )
    );
  }

  // Os métodos legados de salvar-da-aba (criarGovernanca / salvarDadosGerais)
  // foram removidos junto com os endpoints no backend.
}
