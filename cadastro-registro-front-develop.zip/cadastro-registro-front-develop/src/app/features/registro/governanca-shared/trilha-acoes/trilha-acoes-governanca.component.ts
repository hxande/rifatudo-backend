import { Component } from '@angular/core';
import { AcaoGovernancaTO } from 'src/app/api/models/AcaoGovernancaTO';
import { ApiGovernancaService } from '../service/api-governanca.service';

/**
 * Dialog com a trilha completa de ações de governança de um conselho
 * (auditoria — FR-037/card 3). Aberto pelo link "Ver trilha completa" da
 * linha "Última ação"; como o link só é renderizado quando `ultimaAcao` veio
 * preenchida (Nacional-only), o gate de exibição acompanha o do backend.
 *
 * Cada linha mostra o resumo (linha 1 da descrição); o botão de detalhe abre
 * o painel com a descrição completa (antes → depois) da ação.
 */
@Component({
  selector: 'app-trilha-acoes-governanca',
  templateUrl: './trilha-acoes-governanca.component.html',
  styleUrls: ['./trilha-acoes-governanca.component.css'],
})
export class TrilhaAcoesGovernancaComponent {

  visivel = false;
  carregando = false;
  nomeOrgao = '';
  acoes: AcaoGovernancaTO[] = [];
  acaoSelecionada: AcaoGovernancaTO | null = null;

  constructor(private apiGovernanca: ApiGovernancaService) {}

  /** Abre o dialog e carrega a trilha do conselho (mais recente primeiro). */
  abrir(cooperativaId: number, orgaoId: number, nomeOrgao: string): void {
    this.nomeOrgao = nomeOrgao;
    this.acoes = [];
    this.acaoSelecionada = null;
    this.visivel = true;
    this.carregando = true;
    this.apiGovernanca.buscarTrilhaAcoes(cooperativaId, orgaoId)
      .then((response) => {
        this.acoes = response.data ?? [];
      })
      .finally(() => {
        this.carregando = false;
      });
  }

  /** Alterna o painel de detalhe da ação clicada. */
  verDetalhe(acao: AcaoGovernancaTO): void {
    this.acaoSelecionada = this.acaoSelecionada === acao ? null : acao;
  }

  /** Linha 1 da descrição — o resumo exibido na tabela. */
  resumo(descricao: string | null): string {
    return descricao?.split('\n')[0] || '—';
  }

  /** Descrição completa (multilinha) da ação selecionada. */
  get detalheExibido(): string {
    return this.acaoSelecionada?.descricao || '—';
  }
}
