import { AcaoGovernancaTO } from 'src/app/api/models/AcaoGovernancaTO';
import { TrilhaAcoesGovernancaComponent } from './trilha-acoes-governanca.component';

/**
 * Trilha completa de ações de governança (FR-037/card 3): abertura do dialog
 * com carga da trilha, resumo = linha 1 da descrição multilinha e painel de
 * detalhe com a descrição completa.
 *
 * Instanciado sem TestBed/DI (padrão do governanca-shared.component.spec):
 * o único serviço injetado é stubado com uma Promise resolvida.
 */
describe('TrilhaAcoesGovernancaComponent', () => {
  const acao = (over: Partial<AcaoGovernancaTO> = {}): AcaoGovernancaTO =>
    ({
      idMandato: 11,
      tipo: 'SALVAR_CONSELHO',
      rotulo: 'Conselho salvo',
      usuario: 'gestor.teste',
      dataHora: '2026-07-14T10:00:00',
      descricao: 'resumo da ação\nAntes: assembleia 01/01/2024\nDepois: assembleia 01/01/2025',
      ...over,
    } as AcaoGovernancaTO);

  function novoComponent(acoes: AcaoGovernancaTO[]): TrilhaAcoesGovernancaComponent {
    const apiStub = {
      buscarTrilhaAcoes: jasmine.createSpy('buscarTrilhaAcoes')
        .and.returnValue(Promise.resolve({ data: acoes })),
    };
    return new TrilhaAcoesGovernancaComponent(apiStub as any);
  }

  it('abrir() carrega a trilha do conselho e exibe o dialog', async () => {
    const component = novoComponent([acao()]);

    component.abrir(501, 1, 'Conselho de Administração');
    expect(component.visivel).toBeTrue();
    expect(component.nomeOrgao).toBe('Conselho de Administração');

    await Promise.resolve(); // resolve a chamada stubada
    await Promise.resolve(); // resolve o finally
    expect(component.acoes.length).toBe(1);
    expect(component.carregando).toBeFalse();
  });

  it('resumo() retorna somente a linha 1 da descrição multilinha', () => {
    const component = novoComponent([]);
    expect(component.resumo('resumo da ação\ndetalhe antes → depois')).toBe('resumo da ação');
    expect(component.resumo('só resumo')).toBe('só resumo');
    expect(component.resumo(null)).toBe('—');
  });

  it('verDetalhe() alterna a seleção da ação', () => {
    const component = novoComponent([]);
    const a = acao();

    component.verDetalhe(a);
    expect(component.acaoSelecionada).toBe(a);

    component.verDetalhe(a);
    expect(component.acaoSelecionada).toBeNull();
  });

  it('detalheExibido degrada para "—" quando a descrição é nula (registros antigos)', () => {
    const component = novoComponent([]);

    component.verDetalhe(acao({ descricao: null }));
    expect(component.detalheExibido).toBe('—');

    component.acaoSelecionada = acao();
    expect(component.detalheExibido).toContain('Antes: assembleia 01/01/2024');
  });
});
