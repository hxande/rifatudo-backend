import { OnInit, Component, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { MenuItem } from 'primeng/api';

@Component({
    selector:'app-passos-processo-registro',
    templateUrl: './passos-processo-registro.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./passos-processo-registro.component.scss']

})
export class PassosProcessoRegistroComponent implements OnInit{

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

    items: MenuItem[];
    indexsteps = 1;

    constructor(private keycloakService: KeycloakService,
                private apiCadastroRegistroService: ApiCadastroRegistroService) { }

    ngOnInit() {

        this.carregaTela();

    }

    carregaItems(){
        this.items = [{
            label: 'Cadastro e envio dos documentos',
            style: {'background-color': '#00426D !important' }
         },
        {
            label: 'Validação dos dados e documentos'
        },
        {
            label: 'Análise de conformidade legal'
        },
        {
            label: 'Visita técnica'
        },
        {
            label: 'Parecer'
        },
        {
            label: 'Emissão do certificado de registro'
        }
        ];

    }
    carregaTela(){
        this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
        .then((coop) => {
            if(coop){
                switch (coop.progressoMacro) {
                    case ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2: {
                        this.indexsteps = 1;
                        break;
                    }
                    case ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3: {
                        this.indexsteps = 2;
                        break;
                    }
                    case ProgressoMacroEnum.VISITA_TECNICA_4: {
                        this.indexsteps = 3;
                        break;
                    }
                    case ProgressoMacroEnum.PARECER_5: {
                        this.indexsteps = 4;
                        break;
                    }
                    case ProgressoMacroEnum.EMISSAO_CERTIFICADO_6: {
                        this.indexsteps = 5;
                        break;
                    }
                    default: {
                        this.indexsteps = 0;
                    }
                }

                this.carregaItems();
                this.changeDetectorRef.markForCheck();
            }
        });
    }

}
