import { Component, OnInit, ViewChild, Output, EventEmitter, Input, ChangeDetectorRef, inject } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { HttpClient, HttpParams } from '@angular/common/http';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { MessageService } from 'primeng/api';
import { NgForm } from '@angular/forms';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ApiManutencaoDocumentoService } from '@documentacao-api/services/api-manutencao-documento.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiManutencaoCadastroRegistroService } from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { GeralService } from '@auth/geral.service';
import { ValidacaoDocumentoManutencao } from '@shared/documentacao/validacao/validacao-documento-manutencao.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { Documento } from '@documentacao-api/models/Documento';
import { DocumentacaoVO } from '@documentacao-api/models/DocumentacaoVO';
import { DocumentoVO } from '@documentacao-api/models/DocumentoVO';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { Repositorio } from '@upload-api/models/Repositorio';
import { Arquivo } from '@upload-api/models/Arquivo';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { PermissaoCooperativa } from 'src/app/features/cooperativa/permissao/permissao.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { FileUploadComponent } from '@gui/file-upload/file-upload/file-upload.component';

type LabelValue = { label: string, value: string };
@Component({
  selector: 'app-manutencao-documentacao',
  templateUrl: './manutencao-documentacao.component.html',
  styleUrls: ['./manutencao-documentacao.component.css']
})
export class ManutencaoDocumentacaoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativaTemp: Cooperativa;

  constructor(private http: HttpClient,
    private apiDocumentoService: ApiManutencaoDocumentoService,
    public keycloakService: KeycloakService,
    private apiCadastroRegistroService: ApiManutencaoCadastroRegistroService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private geralService: GeralService,
    private apiUpload: ApiFileUploadService,
    private messageService: MessageService,
    public validacaoDocumentoManutencao: ValidacaoDocumentoManutencao,
    private apiPj: ApiPessoaJuridicaService,
    public validacaoDados: ValidacaoDados,
    public permissaoCooperativa: PermissaoCooperativa,
    private apiCooperativaService: ApiCooperativaService,
  ) { }

  @Input() cooperativaManutencao: CooperativaManutencao;

  @ViewChild('fileup') fileup: FileUploadComponent;
  @ViewChild('documentosForm') documentosForm: NgForm;
  responsePageDocumentos: IServiceResponse<Documento[]>;
  // documentoAtuais: Documento[];
  documentacaoVO: DocumentacaoVO = null;
  cooperativa: Cooperativa = null;
  mensagensValidacao = Array<{ summary: string; detail: string }>();
  anosReferencia: LabelValue[] = [];
  podeModificarOsCampos = false;
  aprovacoes: CooperativaPendencia[] = [];
  checksAnoAnterior: boolean[] = [];
  anoReferencia;
  anoAtual;
  anoCiclo;
  possuiDocumentoAnterior = false;
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  houveAlteracaoForm = false;
  pendenciasEditadas: CooperativaPendencia[] = [];
  // Tipado como Map em obterUltimasPendenciasChaveManutencao, mas o backend retorna JSON
  // puro (sem reviver para Map) — em tempo de execução é sempre um objeto comum, como já
  // é tratado no template (mapPendencias[chave]).
  mapPendencias: Record<string, boolean> = {};
  nomePessoaJuridica: string;

  ngOnInit(): void {
    this.verificarLiberacaoCampos();
  }

  atualizarMensagensTela() {
      if (this.cooperativaTemp) {
        this.apiPj.buscaUnidadeResponsavel(this.cooperativaTemp.pessoaJuridica.ufSigla)
        .then(pj => {
          this.nomePessoaJuridica = pj.data.nomeFantasia;
          this.changeDetectorRef.markForCheck();
        });

        this.apiCadastroRegistroService.validarDocumentos(this.cooperativaTemp.id).then((res) => {
          this.mensagensValidacao = [];
          if (res && res.data) {
            const dadosValidacao = res.data;
            if (!dadosValidacao.validado) {
              this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
                summary: (msg.message.indexOf('<b>') === -1) ? '' : msg.message.substring((msg.message.indexOf('<b>') + 3), msg.message.indexOf('</b>')),
                detail: (msg.message.indexOf('<b>') === -1) ? msg.message : msg.message.substring((msg.message.indexOf('</b>') + 4))
              }));
            }
          }
        });
      }
  }

  testeD() {
    console.log('chamouuuuu');
    console.log('this.somenteLeitura = ', this.somenteLeitura);
    if (this.somenteLeitura) {
      this.fileup.setDesabilita();
    }
  }

  carregaDocumento() {
        this.apiDocumentoService.getDocumentacao(this.cooperativaTemp.pessoaJuridica.id)
        .then((res) => {
          if (res && res.data != null) {
            this.documentacaoVO = res.data;
            this.mapeaAno();
            this.setaCheckAnoAnterior();
            this.changeDocumentosAno(this.anoReferencia);
            this.changeDetectorRef.markForCheck();
          }
        });
  }

  get somenteLeitura(): boolean {
    return this.cooperativaTemp?.situacaoCooperativa?.nome?.toLowerCase() === 'cancelada';
  }

  /**
   * documentosAno é tipado como Map em DocumentacaoVO, mas o backend retorna JSON puro
   * (sem reviver para Map) — em tempo de execução é sempre um objeto comum.
   */
  private get documentosAnoObj(): Record<string, DocumentoVO[]> {
    return this.documentacaoVO.documentosAno as unknown as Record<string, DocumentoVO[]>;
  }

  mapeaAno() {
    this.anosReferencia = Object.keys(this.documentosAnoObj).map(key => ({
      label: 'Ciclo ' + key + ' (Ano calendário ' + (parseInt(key, 10) - 1) + ')',
      value: key
    }));
    // Se tem um ciclo novo cadastra novo doc, se já fez no ciclo atual n precisa cadastrar outro
    if (this.anosReferencia && this.anosReferencia.length > 1) {
      this.anoReferencia = this.anosReferencia[1] ? this.anosReferencia[1].value : '';
      this.anoAtual = this.anoReferencia - 1;
    } else {
      this.anoReferencia = this.anosReferencia[0] ? this.anosReferencia[0].value : '';
      this.anoAtual = this.anoReferencia;
    }

    this.anoCiclo = this.anoReferencia;
  }

  verficiaSePossuiDocAnterior(idDoc) {
    const documentosAno = this.documentosAnoObj[this.anoAtual];

    if (documentosAno) {
      const documento = documentosAno.find(doc => doc.idDocumento === idDoc);
      return !!documento?.possuiArquivo;
    }

    return false;
  }

  setaCheckAnoAnterior() {
    this.checksAnoAnterior = this.obterDocumentoAno(this.anoReferencia)
      .map(doc => !!(doc.arquivosAnteriores && doc.arquivosAnteriores.length > 0));
  }

  atualizaLiberacaoCampo(pendencia) {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas = [
        ...this.pendenciasEditadas,
        pendencia
      ];
    }
    const chave = pendencia.bloco + '_' + pendencia.identificadorAuxiliar;
    this.mapPendencias = { ...this.mapPendencias, [chave]: false };
    this.houveAlteracaoForm = true;
  }

  private atualizaPendenciaChaveManutencao(coop: Cooperativa) {
    this.apiValidacaoDadosService.obterUltimasPendenciasChaveManutencao(coop.id)
    .then(res => {
      this.mapPendencias = res.data as unknown as Record<string, boolean>;
      this.changeDetectorRef.markForCheck();
    });
  }

  outCarregarArquivos(repositorio: Repositorio, doc: DocumentoVO) {
    const possuiArquivo = !!(repositorio && repositorio.arquivos.length > 0);
    const mesmoAnoExibido = this.anoReferencia === (this.anoAtual).toString();
    const resetarAnterior = !possuiArquivo && mesmoAnoExibido;

    const documentosAno = (this.documentosAnoObj[this.anoAtual] ?? []).map(documento =>
      documento.idDocumento === doc.idDocumento
        ? { ...documento, possuiArquivo, ...(resetarAnterior ? { arquivosAnteriores: [] } : {}) }
        : documento
    );

    this.documentacaoVO = {
      ...this.documentacaoVO,
      documentos: mesmoAnoExibido ? documentosAno : this.documentacaoVO.documentos,
      documentosAno: { ...this.documentosAnoObj, [this.anoAtual]: documentosAno } as unknown as Map<string, DocumentoVO[]>
    };

    if (resetarAnterior) {
      this.checksAnoAnterior = documentosAno.map((documento, i) =>
        documento.idDocumento === doc.idDocumento ? false : this.checksAnoAnterior[i]
      );
    }
  }


  /**
   * Conclusão de upload para um documento específico (SOU-1374).
   * Apenas atualiza o upload do documento quando existir chave de repositório válida,
   * garantindo que uploads vazios não mudem o estado visual dos botões.
   */
  onConcluirUploadDoc(doc: DocumentoVO, chaveRepositorio: string) {
    if (chaveRepositorio) {
      this.atualizaAnexo({ ...doc, upload: chaveRepositorio });
    }

    this.onConcluirUpload(chaveRepositorio);
  }

  onConcluirUpload(chaveRepositorio: string) {
    this.houveMudancaForm();
  }

  manterDocAnoAnterior(e, index) {
    const checked = e.target.checked;
    this.checksAnoAnterior = this.checksAnoAnterior.map((v, i) => i === index ? checked : v);

    const docAtual = this.documentacaoVO.documentos[index];
    let docAtualizado: DocumentoVO;

    if (checked) {
      const documentosAnoAnterior = this.obterDocumentoAno(this.anoAtual);
      const documentoAnterior = documentosAnoAnterior.find(doc => doc.idDocumento === docAtual.idDocumento) ?? null;
      docAtualizado = { ...docAtual, documentoAnterior };
    } else {
      docAtualizado = { ...docAtual, documentoAnterior: null, arquivosAnteriores: [] };
    }

    this.documentacaoVO = {
      ...this.documentacaoVO,
      documentos: this.documentacaoVO.documentos.map((doc, i) => i === index ? docAtualizado : doc)
    };

    if (checked && (!docAtualizado.arquivosAnteriores || docAtualizado.arquivosAnteriores.length === 0)) {
      this.obterArquivosAnteriores(docAtual.idDocumento, index);
    }

    this.houveMudancaForm();
  }


  private atualizarArquivosAnteriores(index: number, arquivos: Arquivo[]) {
    this.documentacaoVO = {
      ...this.documentacaoVO,
      documentos: this.documentacaoVO.documentos.map((doc, i) =>
        i === index ? { ...doc, arquivosAnteriores: arquivos } : doc
      )
    };
  }

  listaArquivosAnoAnterior(uploadAnexoAnterior, index) {
    this.apiUpload.getArquivos(uploadAnexoAnterior).then((repositorio) => {
      this.atualizarArquivosAnteriores(index, repositorio.arquivos);
      this.changeDetectorRef.markForCheck();
    });
  }


  obterDocumentoAno(chaveAno) {
    return this.documentosAnoObj[chaveAno] || [];
  }

  changeDocumentosAno(chaveAno) {
    this.documentacaoVO = {
      ...this.documentacaoVO,
      documentos: this.obterDocumentoAno(chaveAno)
    };
  }

  getLista(): Promise<IServiceResponse<Documento[]>> {
    return this.apiDocumentoService.listaAtivos(true, TipoPessoaEnum.PJ);
  }

  public desativaEventoForm() {
    this.houveAlteracaoForm = false;
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  getAlteracaoForm() {
    return this.houveAlteracaoForm;
  }


  obterArquivosAnteriores(idDoc, index) {
    const options = {
      params: new HttpParams()
        .set('idDoc', idDoc)
        .set('pessoa', this.documentacaoVO.idPessoa.toString())
        .set('ano', (this.anoAtual).toString())
    };

    this.apiDocumentoService.listaArquivosAnteriores(options).then(response => {
      this.atualizarArquivosAnteriores(index, response.data);
      this.changeDetectorRef.markForCheck();
    });
  }


  atualizaAnexo(documento: DocumentoVO) {
    const chaveAno = documento.ano.toString();

    const documentosAno = (this.documentosAnoObj[chaveAno] ?? []).map(docz =>
      docz.idDocumento === documento.idDocumento
        ? { ...docz, upload: documento.upload }
        : docz
    );

    this.documentacaoVO = {
      ...this.documentacaoVO,
      documentos: chaveAno === this.anoReferencia ? documentosAno : this.documentacaoVO.documentos,
      documentosAno: { ...this.documentosAnoObj, [chaveAno]: documentosAno } as unknown as Map<string, DocumentoVO[]>
    };
  }



  download(file: Arquivo) {
    this.apiUpload.getArquivoDownload(file.chaveArquivo).then(data => {

      const thefile = new Blob([data], { type: file.mimeType });

      const url = window.URL.createObjectURL(thefile);

      const link = document.createElement('a');
      link.href = url;
      link.download = file.nome;
      link.dispatchEvent(new MouseEvent('click'));
      this.changeDetectorRef.markForCheck();
    }).catch(err => {
      this.messageService.add({ severity: 'error', detail: err.message, life: 10000 });
      this.changeDetectorRef.markForCheck();
    });

  }

  obterClasseAprovacao(arquivo: Arquivo) {
    return arquivo.dataAprovacao ? 'fa-solid fa-circle-check color-text-green' : 'fa-solid fa-triangle-exclamation color-text-red';
  }
  obterTituloAprovacao(arquivo: Arquivo) {
    return arquivo.dataAprovacao ? 'Validado em ' : 'Documento não validado';
  }

  salvar(abaDestino: number) {
    let pendenciaPreenchimentoTela = false;
    this.aprovacoes.forEach(elem => {
      if (elem.visualizado === true) {
        pendenciaPreenchimentoTela = true;
      }
    });

    if (pendenciaPreenchimentoTela) {
      this.messageService.add({ severity: 'warn', detail: 'Preencha corretamente as orientações para ajuste!', life: 10000 });
      return;
    }

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
    .then(async (coop) => {
      if (coop) {

        if (this.pendenciasEditadas.length > 0) {
          const res = await this.apiValidacaoDadosService.editarAgrupamento(this.pendenciasEditadas);
          this.pendenciasEditadas = res.data;
          this.changeDetectorRef.markForCheck();
        }

        this.geralService.salvarPendenciaManutencao(
          this.aprovacoes,
          [
            () => this.evtSalvarDados.emit(true),
            () => {
              this.apiDocumentoService.salvarDocumentacao(this.documentacaoVO).then(async (res) => {

                // Marcar como Validado
                await this.apiValidacaoDadosService.marcarComoValidadoManutencao(coop.id, 'MANUTENCAO_DOCUMENTOS');

                this.desativaEventoForm();

                this.aprovacoes = this.aprovacoes.map(ap =>
                  ap.houveAlteracao ? { ...ap, houveAlteracao: false } : ap
                );

                this.atualizarMensagensTela();

                window.scroll(0, 0);
                // Atualizando Aba
                this.evtFimSalvarDados.emit(abaDestino);

                this.statusEmPreenchimento(coop)
                this.changeDetectorRef.markForCheck();

                this.changeDetectorRef.markForCheck();

              }).catch(() => {
                this.evtErroSalvar.emit(true);
                this.changeDetectorRef.markForCheck();
              });
            }
          ]
        );
      }
    });

  }

  statusEmPreenchimento(cooperativa: Cooperativa): void {

    if (!this.cooperativa.inPreenchimento && this.cooperativa.status != 'Aprovado') {
        this.apiCooperativaService.atualizarStatusEmPreenchimento(cooperativa)
        .then((response) => {
          this.changeDetectorRef.markForCheck();
        });
    }
  }

  verificarLiberacaoCampos() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
    .then((coop) => {
      if (coop) {
        this.cooperativaTemp = coop;

        this.apiCadastroRegistroService.podePreencherCadastroRegistro(coop.id)
        .then((res) => {
          if (res != null && res.data != null) {
            // TODO sempre modificavel
            this.podeModificarOsCampos = res.data;
          }
          // Carregando Documentos
          this.carregaDocumento();
          this.atualizarMensagensTela();
          this.atualizaPendenciaChaveManutencao(coop);
          this.changeDetectorRef.markForCheck();
        });
      }
    });
  }

  validaAjustesDados(): boolean {
    if (this.cooperativaTemp) {
      return this.validacaoDados.validaAjustesDadosManutencao(this.cooperativaTemp.progressoManutencaoMicro);
    }
    return false;
  }

}
