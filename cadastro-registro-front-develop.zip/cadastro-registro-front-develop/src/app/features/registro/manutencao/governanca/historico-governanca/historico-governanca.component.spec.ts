import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ConfirmationService, Confirmation } from 'primeng/api';

import { HistoricoGovernancaComponent } from './historico-governanca.component';

describe('HistoricoGovernancaComponent', () => {
  let component: HistoricoGovernancaComponent;
  let fixture: ComponentFixture<HistoricoGovernancaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HistoricoGovernancaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoricoGovernancaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

// O modal "Tornar vigente" era o único da família que não usava o
// p-confirmDialog "govConfirm" — abria o confirm global sem botão
// "Cancelar". Instanciação direta (sem TestBed) no padrão do spec do
// governanca-shared: o método só usa os serviços injetados stubáveis.
describe('HistoricoGovernancaComponent — modal "Tornar vigente"', () => {
  function novoComponent(confirmSpy: jasmine.SpyObj<ConfirmationService>, apiSpy: any): HistoricoGovernancaComponent {
    return new HistoricoGovernancaComponent(apiSpy, confirmSpy, {} as any, {} as any);
  }

  const mandatoHistorico = () => ({
    id: 9,
    cooperativa: { id: 7 },
    orgao: { id: 1 },
  } as any);

  it('usa o p-confirmDialog govConfirm (com Cancelar) e não executa nada sem aceite', () => {
    const confirmSpy = jasmine.createSpyObj<ConfirmationService>('ConfirmationService', ['confirm']);
    const apiSpy = jasmine.createSpyObj('ApiManutencaoGovernancaService', ['tornarVigente']);

    const component = novoComponent(confirmSpy, apiSpy);
    component.tornarVigente(mandatoHistorico());

    expect(confirmSpy.confirm).toHaveBeenCalledTimes(1);
    const config: Confirmation = confirmSpy.confirm.calls.mostRecent().args[0];
    expect(config.key)
      .withContext('dialog com botão "Cancelar" explícito')
      .toBe('govConfirm');
    expect(config.message).toContain('Deseja continuar?');
    expect(apiSpy.tornarVigente)
      .withContext('sem aceite, o mandato não é alterado')
      .not.toHaveBeenCalled();
  });

  it('o aceite dispara o tornar-vigente e o fluxo de resync/fechamento', () => {
    const confirmSpy = jasmine.createSpyObj<ConfirmationService>('ConfirmationService', ['confirm']);
    const apiSpy = jasmine.createSpyObj('ApiManutencaoGovernancaService', ['tornarVigente']);
    apiSpy.tornarVigente.and.returnValue(Promise.resolve({}));

    const component = novoComponent(confirmSpy, apiSpy);
    spyOn(component, 'consultaHistorico');
    component.tornarVigente(mandatoHistorico());

    const config: Confirmation = confirmSpy.confirm.calls.mostRecent().args[0];
    config.accept?.();

    expect(apiSpy.tornarVigente).toHaveBeenCalledWith(7, 9);
  });
});
