import { TestBed, inject } from '@angular/core/testing';

import { ApiManutencaoGovernancaService } from './api-manutencao-governanca.service';

describe('ManutencaoGovernancaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiManutencaoGovernancaService]
    });
  });

  it('should be created', inject([ApiManutencaoGovernancaService], (service: ApiManutencaoGovernancaService) => {
    expect(service).toBeTruthy();
  }));
});
