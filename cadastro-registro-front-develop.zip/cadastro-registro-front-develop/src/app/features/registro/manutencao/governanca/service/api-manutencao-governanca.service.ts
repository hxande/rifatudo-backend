import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Governanca } from '@cadastro-registro-api/models/Governanca';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiManutencaoGovernancaService {

  constructor(private http: HttpClient) {}

  tornarUltimoMandatoNaoVigente(idOrgao: number, idCooperativa: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/tornarUltimoNaoVigente/${idCooperativa}/${idOrgao}`
      )
    );
  }

  consultaHistorico(idCooperativa: number, idOrgao: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Governanca[]>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/buscaNaoVigentesPorCooperativaOrgao/${idCooperativa}/${idOrgao}`
      )
    );
  }

  buscaGovernancasVigentesPorCooperativa(cooperativaId: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Governanca[]>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/buscaVigentesPorCooperativa/${cooperativaId}`
      )
    );
  }

  salvar(governanca: Governanca[], cooperativaId: number) {
    return firstValueFrom(
      this.http.post<IServiceResponse<boolean>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/${cooperativaId}`,
        governanca,
        { reportProgress: false }
      )
    );
  }

  excluirMandato(idMandato: number, cooperativaId: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/excluir-mandato/${cooperativaId}/${idMandato}`,
        { reportProgress: false }
      )
    );
  }

  excluirMandatoMembro(idMandatoMembro: number) {
    return firstValueFrom(
      this.http.delete<IServiceResponse<void>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/exluir-membro/${idMandatoMembro}`,
        { reportProgress: false }
      )
    );
  }

  mandatoAprovado(cooperativaId: number, idOrgao: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<boolean>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/mandato-aprovado/${cooperativaId}/${idOrgao}`
      )
    );
  }

  tornarVigente(cooperativaId: number, idMandato: number) {
    return firstValueFrom(
      this.http.put<IServiceResponse<boolean>>(
        `/cadastro-registro-api/api/v1/manutencao-governanca/tornar-vigente/${cooperativaId}/${idMandato}`,
        {}
      )
    );
  }

}
