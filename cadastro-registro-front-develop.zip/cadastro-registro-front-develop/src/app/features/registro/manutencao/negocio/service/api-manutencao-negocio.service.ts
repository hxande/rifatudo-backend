import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Negocio } from '@cadastro-registro-api/models/Negocio';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Faturamento } from '@cadastro-registro-api/models/Faturamento';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { NegocioTO } from 'src/app/api/models/NegocioTO';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiManutencaoNegocioService {
  constructor(private http: HttpClient) {}
  salvarNegocio(negocio: Negocio) {
    return firstValueFrom(
      this.http.put<IServiceResponse<boolean>>(`/cadastro-registro-api/api/v1/manutencao-negocio/${negocio.cooperativa.id}`, negocio, { reportProgress: false })
    );
  }

  salvarHistorico(idCoop: number, faturamentos: Faturamento[]) {
    return firstValueFrom(
      this.http.put<IServiceResponse<Faturamento[]>>(`/cadastro-registro-api/api/v1/faturamento/salvarHistorico/${idCoop}`, faturamentos, { reportProgress: false })
    );
  }

  getNegocio(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<NegocioTO>>(`/cadastro-registro-api/api/v1/manutencao-negocio/buscarNegocio/${idCooperativa}`)
    );
  }

  getFaturamentos(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Faturamento[]>>(`/cadastro-registro-api/api/v1/faturamento/buscarFaturamentosPorCooperativaNoCiclo/${idCooperativa}`)
    );
  }

  getHistoricoFaturamentos(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Faturamento[]>>(`/cadastro-registro-api/api/v1/faturamento/buscaHistoricoFaturamento/${idCooperativa}`)
    );
  }

  validarCnpjFilial(cnpjMatriz: string, cnpjFilial: string) {
    const parametros = {
      params: new HttpParams().set('cnpjMatriz', cnpjMatriz).set('cnpjFilial', cnpjFilial),
      reportProgress: false,
    };

    return firstValueFrom(
      this.http.get<PessoaJuridicaBasicaTO>(`/cadastro-registro-api/api/v1/vinculacaofiliacao/validarCnpj`, parametros)
    );
  }

  exportarRelatorioSegmento(idCooperativa: number): Promise<Blob> {
    return firstValueFrom(
      this.http.get(`/cadastro-registro-api/api/v1/manutencao-negocio/exportarRelatorioSegmento/${idCooperativa}`, {
        reportProgress: false,
        responseType: 'blob',
        headers: new HttpHeaders({ timeout: `${900000}` }),
      })
    );
  }
}
