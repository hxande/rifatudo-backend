import { HttpParams } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, EventEmitter, inject, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiManutencaoNegocioService } from './service/api-manutencao-negocio.service';
import { MessageService, SelectItem, SortEvent } from 'primeng/api';
import { Table, TableLazyLoadEvent } from 'primeng/table';
import { CheckboxChangeEvent } from 'primeng/checkbox';
import { MultiSelectChangeEvent } from 'primeng/multiselect';
import { saveAs } from 'file-saver';
import { Segmento } from '@cadastro-registro-api/models/Segmento';
import { Produtoservico } from '@cadastro-registro-api/models/Produtoservico';
import { PessoaSegmProdServ } from '@cadastro-registro-api/models/PessoaSegmProdServ';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { Cnae } from '@cadastro-registro-api/models/Cnae';
import { OptionDropDown } from '../../registro/negocio/OptionDropdown';
import { PessoaCnae } from '@cadastro-registro-api/models/PessoaCnae';
import { FilialComponentComponent } from '@shared/filial/filial-component.component';
import { Negocio } from '@cadastro-registro-api/models/Negocio';
import { ApiSegmentoService } from '@cadastro-registro-api/services/api-segmento.service';
import { ApiProdutoservicoService } from '@cadastro-registro-api/services/api-produtoservico.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { ApiCnaeService } from '@cadastro-registro-api/services/api-cnae.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import {
  ApiManutencaoCadastroRegistroService,
} from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { GeralService } from '@auth/geral.service';
import { ApiFilialService } from '@cadastro-registro-api/services/api-filial.services';
import { UtilityService } from '@utils/utility/utility.service';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { Faturamento } from '@cadastro-registro-api/models/Faturamento';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { Messages } from '@shared/mensagens/Messages';
import { ApiQuadroSocialFilialService } from '@cadastro-registro-api/services/api-quadro-social-filial.service';
import { QuadroSocialFilial } from '@cadastro-registro-api/models/QuadroSocialFilial';
import { CriterioAssociacaoTO } from '@cadastro-registro/models/CriterioAssociacaoTO';
import { ApiCriterioAssociacaoService } from '@cadastro-registro/services/api-criterio-associacao.service';
import { CriterioAssociacaoCooperativaTO } from '@cadastro-registro/models/CriterioAssociacaoCooperativaTO';
import {
  CriterioAssociacaoCooperativaResponseTO,
} from '@cadastro-registro/models/CriterioAssociacaoCooperativaResponseTO';
import { firstValueFrom } from 'rxjs';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { PermissaoCooperativa } from 'src/app/features/cooperativa/permissao/permissao.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ControlePortifolioTO } from 'src/app/api/models/ControlePortifolioTO';
import { ApiControlePortifolioService } from 'src/app/api/services/api-controle-portifolio.service';
import { PortifolioComponent } from '../../registro/portifolio/portifolio-component';
import { Ramo } from 'src/app/api/models/Ramo';
import { ApiRamoService } from 'src/app/api/services/api-ramo.service';
import { ApiManutencaoService } from 'src/app/api/services/api.manutencao.service';
import { AbaManutencaoSegmentacaoFiliaisTO } from 'src/app/api/models/AbaManutencaoSegmentacaoFiliaisTO';
import { Aba } from 'src/app/api/models/AbaEnum';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
  selector: 'app-manutencao-negocio-component',
  templateUrl: './manutencao-negocio-component.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./manutencao-negocio-component.component.css'],
})
export class ManutencaoNegocioComponentComponent implements OnInit {

  private readonly destroyRef = inject(DestroyRef);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() cooperativaManutencao: CooperativaManutencao;

  optionsDropdownRamo: Ramo[];
  optionsDrobdownSegmento: Segmento[];

  selectedCriterioAssocaicao : CriterioAssociacaoTO[];
  optionsCriterioAssocaicao : CriterioAssociacaoTO[];

  selectedCriterioAssocaicaoCooperativa : CriterioAssociacaoCooperativaTO[];
  selectedCriterioAssocaicaoCooperativaResponse : CriterioAssociacaoCooperativaResponseTO[];

  optionsDrobdownProduto: Produtoservico[];
  listaProdutosServicos: Produtoservico[][];
  listaPessoaSegmProdServ: PessoaSegmProdServ[];
  listaCooperativasFiliacao: PessoaJuridicaBasicaTO[];
  tabelaCooperativas: PessoaJuridicaBasicaTO[];
  listaQuadroSocialFilial: QuadroSocialFilial[];
  listaExcluirQuadroSocialFilial: QuadroSocialFilial[] = [];

  cooperativa: Cooperativa;
  aprovacoes: CooperativaPendencia[] = [];

  optionsDrobdownCnaes: Cnae[];
  optionDropDown: OptionDropDown<Cnae>;
  // listaCnaeSecundarioAux: PessoaCnae[];
  listaProdutosAux: string[];
  campoDescricaoComplementar: boolean;
  @ViewChild('negocioForm') negocioForm: NgForm;
  @ViewChild('filialComponent') filialComponent: FilialComponentComponent;
  @ViewChild('portifolioComponent') portifolioComponent: PortifolioComponent;
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  negocio: Negocio;
  houveAlteracaoForm = false;
  mensagensValidacao = Array<Messages>();
  optionsListaUfs: SelectItem[];
  modalAdicionarFilial = false;
  totalElementos = 0;
  nrLinhas = 10;
  pendenciasEditadas: CooperativaPendencia[] = [];
  mapPendencias: Record<string, boolean> = {};
  cols: { field: string; header: string; width: string }[];
  colsQuadroSocialFilial: { field: string; header: string; width: string }[];
  filtrocnpj = '';
  filtronomeFantasia = '';
  filtroUf: '';
  filtroTelefone = '';
  filtroEmail = '';
  filtroQuadroSocialFilial: number;
  nrLinhasTabela = 10;
  private debouncer;
  private delay = 500;
  @ViewChild('dtFilial') dtFilial: Table;
  cooperativaTemp: Cooperativa;
  nomePessoaJuridica: string;

  ano = new Date().getFullYear() - 1;

  controlePortifolio = new ControlePortifolioTO();

  ramo: Ramo;

  display: boolean = false;
  constructor(
    private segmentoApi: ApiSegmentoService,
    private negocioApi: ApiManutencaoNegocioService,
    private apiProdutoservicoService: ApiProdutoservicoService,
    private apiValidacaoService: ApiValidacaoDadosService,
    private cnaeApi: ApiCnaeService,
    private dadosGeraisService: ApiDadosGeraisService,
    private apiCadastroRegistroService: ApiManutencaoCadastroRegistroService,
    public keycloakService: KeycloakService,
    private geralService: GeralService,
    private messageService: MessageService,
    private filialApi: ApiFilialService,
    private quadroSocialApi: ApiQuadroSocialFilialService,
    private utilityService: UtilityService,
    public validacaoDados: ValidacaoDados,
    private apiPj: ApiPessoaJuridicaService,
    private permissaoCooperativa: PermissaoCooperativa,
    private apiCriterioAssociacaoService: ApiCriterioAssociacaoService,
    private apiCooperativaService: ApiCooperativaService,
    private apiControlePortifolio: ApiControlePortifolioService,
    private ramoApi: ApiRamoService,
    private apiManutencaoSerivce: ApiManutencaoService
  ) {}

  podeModificarOsCampos = false;

  verificarLiberacaoCampos(id: number) {
    this.apiCadastroRegistroService.podePreencherCadastroRegistro(id).then((res) => {
      if (res != null && res.data != null) {
        this.desativaEventoForm();
        this.podeModificarOsCampos = res.data && this.permissaoCooperativa.permissaoAtualizarCadastro();
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  ngOnInit() {
    this.listaProdutosServicos = new Array<Produtoservico[]>();
    this.optionsDrobdownSegmento = new Array<Segmento>();

    this.selectedCriterioAssocaicao = [];
    this.optionsCriterioAssocaicao = [];
    this.selectedCriterioAssocaicaoCooperativa = [];
    this.selectedCriterioAssocaicaoCooperativaResponse = [];
    this.negocio = new Negocio();
    this.negocio.cnaePrimario = new PessoaCnae();
    // this.negocio.cnaeSecundarios = new Array<PessoaCnae>();
    this.negocio.segmentos = new Array<Segmento>();
    this.negocio.faturamentoAtual = new Faturamento();
    this.negocio.produtos = new Array<Produtoservico>();
    // this.listaCnaeSecundarioAux = new Array<PessoaCnae>();
    this.listaProdutosAux = new Array<string>();
    this.listaPessoaSegmProdServ = new Array<PessoaSegmProdServ>();
    this.optionDropDown = new OptionDropDown();
    this.listaExcluirQuadroSocialFilial = new Array<QuadroSocialFilial>();

    this.cols = [
      { field: 'pessoaJuridicaFiliada.cnpj', header: 'CNPJ', width: '170px' },
      { field: 'pessoaJuridicaFiliada.nomeFantasia', header: 'Nome fantasia', width: '280px' },
      { field: 'pessoaJuridicaFiliada.ufSigla', header: 'UF', width: '155px' },
      { field: 'pessoaJuridicaFiliada.telefoneGeral', header: 'Telefone', width: '146px' },
      { field: 'pessoaJuridicaFiliada.emailGeral', header: 'E-mail', width: '120px' },
      { field: 'acoes', header: 'Ações', width: '120px' },
    ];

    this.colsQuadroSocialFilial = [
      { field: 'uf', header: 'UF', width: '60px' },
      { field: 'cooperados', header: 'Quantidade de cooperados', width: '155px' },
      { field: 'empregados', header: 'Quantidade de empregados', width: '155px' },
    ];

    this.carregarTela();
  }

  convertToCriterioAssociacao(lista: CriterioAssociacaoCooperativaResponseTO[]): CriterioAssociacaoTO[] {
    return lista.map(item => {
      return {
        id: item.sqCriterioAssociacao,
        sqRamo: item.ramoId,
        descricao: item.nomeCriterioAssociacao,
        ativo: item.criterioAssociacaoAtivo,
        excluido: item.criterioAssociacaoExcluido
      };
    });
  }

  carregarUfs() {
    this.dadosGeraisService.buscarUfs().then((res) => {
      if (res && res.content != null) {
        this.optionsListaUfs = [];
        res.content.forEach((uf) => {
          this.optionsListaUfs = [
            ...this.optionsListaUfs,
            { label: uf.sigla, value: uf.sigla }
          ];
        });
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  public desativaEventoForm() {
    this.houveAlteracaoForm = false;
  }

  public getAlteracaoForm() {
    let alteracao = false;
    for (const ap of this.aprovacoes) {
      if (ap.houveAlteracao) {
        alteracao = true;
      }
    }
    return this.houveAlteracaoForm || alteracao;
  }

  public getForm() {
    return this.negocioForm;
  }

  salvarNegocio(abaDestino: number) {
    let pendenciaPreenchimentoTela = false;


    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchimentoTela = true;
      }
    });

    if (pendenciaPreenchimentoTela) {
      this.messageService.add({ severity: 'warn', detail: 'Preencha corretamente as orientações para ajuste!', life: 10000 });
      return;
    }

    let pendenciaPreenchumentoTela = false;
    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchumentoTela = true;
      }
    });

    if (pendenciaPreenchumentoTela) {
      this.messageService.add({ severity: 'warn', detail: 'Preencha corretamente as orientações para ajuste!', life: 10000 });
      return;
    }

    if (this.isSegmentoUnico() && this.validaQuantidadeSegmentos()) {
      this.messageService.add({
        severity: 'warn',
        detail: 'O ramo da cooperativa permite a seleção de apenas um segmento!',
        life: 10000,
      });
      return;
    }

    this.houveAlteracaoForm = true;
    this.geralService.salvarPendenciaManutencao(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);

    this.negocio.cooperativa = this.cooperativa;
    //this.negocio.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ;
    this.negocio.listaPessoaSegmProdServ = this.portifolioComponent.listaPessoaSegmProdSevNova;
    this.negocio.filiadas = this.listaCooperativasFiliacao;
    this.negocio.cooperativa.quadrosSociaisFilial = this.listaQuadroSocialFilial;

    if (this.listaExcluirQuadroSocialFilial.length > 0) {
      this.listaExcluirQuadroSocialFilial.forEach(quadro => {
        this.quadroSocialApi.delete(quadro.id);
      });
    }

    if (this.pendenciasEditadas.length > 0) {
      this.apiValidacaoService.editarAgrupamento(this.pendenciasEditadas).then((res) => {
        this.pendenciasEditadas = res.data;
      });
    }

    // Salvar Criterios Associação Cooperativa

    if (this.selectedCriterioAssocaicao && this.selectedCriterioAssocaicao.length > 0) {
      this.selectedCriterioAssocaicaoCooperativa = this.convertListaCriterioAssociao(this.selectedCriterioAssocaicao, this.cooperativa.pessoaJuridica.id);

      this.apiCriterioAssociacaoService.salvarCriterioAssociacaoCooperativa(this.selectedCriterioAssocaicaoCooperativa)
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(response => {
          if (response && response.data) {
            this.selectedCriterioAssocaicaoCooperativa = response.data;
          }
        });
    }


    this.negocio.cooperativa.cooperativaRegistro = null;

    this.apiManutencaoSerivce.segmentacaoFiliais(this.mapNegocioToAbaTOs(this.negocio))
      .then(() => {
        this.houveAlteracaoForm = false;
        this.atualizarMensagensTela();
        this.evtFimSalvarDados.emit(abaDestino);
        this.statusEmPreenchimento(this.negocio.cooperativa)
        for (const ap of this.aprovacoes) {
          if (ap.houveAlteracao) {
            ap.houveAlteracao = false;
          }
        }

        // this.carregarTela();
        window.scroll(0, 0);

      })
      .catch(() => {
        this.evtErroSalvar.emit(true);
      });
  }

  statusEmPreenchimento(cooperativa: Cooperativa): void {
    if (!this.cooperativa.inPreenchimento) {
        this.apiCooperativaService.atualizarStatusEmPreenchimento(cooperativa).then((response) => {
        });
    }
  }

  convertListaCriterioAssociao(selectedCriterioAssociacao: CriterioAssociacaoTO[], valorSqCooperativa: number): CriterioAssociacaoCooperativaTO[] {
    return selectedCriterioAssociacao.map(item => ({
      id: item.id,
      sqCooperativa: valorSqCooperativa,
      sqCriterioAssociacao: item.id
    }));
  }

  carregarTela() {
    this.carregarCooperativa().then(() => {
      this.carregarCriteriosAssociacaoSeNecessario();
      this.carregarControlePortifolio();
    });

    this.carregarUfs();
    this.buscarCnaes();
    this.desativaEventoForm();

  }

  carregarControlePortifolio() {
    this.apiControlePortifolio.obterControlePortifolioUfNacional()
    .pipe(takeUntilDestroyed(this.destroyRef))
    .subscribe(response => {
      this.controlePortifolio = response.data;
      if(this.controlePortifolio && !this.controlePortifolio.informarCampos){
        this.apiControlePortifolio.getControlePortifolioUf(this.cooperativa.pessoaJuridica.ufSigla)
        .pipe(takeUntilDestroyed(this.destroyRef))
        .subscribe(responseUf => {
          if(responseUf && responseUf.data){
            this.controlePortifolio = responseUf.data;
            this.changeDetectorRef.markForCheck();
          }
        });
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  updateSelectedCriterioAssocaicao() {
    this.selectedCriterioAssocaicao = this.selectedCriterioAssocaicao.map(item => {
      const matchingOption = this.optionsCriterioAssocaicao.find(option => option.id === item.id);
      if (matchingOption) {
        return {
          id: item.id, // mantem o ID original
          sqRamo: matchingOption.sqRamo,
          descricao: matchingOption.descricao,
          ativo: matchingOption.ativo,
          excluido: matchingOption.excluido
        };
      } else {
        return item;
      }
    });
  }

  private atualizaPendenciaChaveManutencao(coop: Cooperativa) {
    this.apiValidacaoService.obterUltimasPendenciasChaveManutencao(coop.id).then((res) => {
      this.mapPendencias = res.data as unknown as Record<string, boolean>;
      this.changeDetectorRef.markForCheck();
    });
  }

  atualizarMensagensTela() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.apiCadastroRegistroService.validarNegocio(coop.id).then((res) => {
          if (res && res.data) {
            this.mensagensValidacao = [];

            const dadosValidacao = res.data;

            if (!dadosValidacao.validado) {
              this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
                summary: msg.message.indexOf('<b>') === -1 ? '' : msg.message.substring(msg.message.indexOf('<b>') + 3, msg.message.indexOf('</b>')),
                detail: msg.message.indexOf('<b>') === -1 ? msg.message : msg.message.substring(msg.message.indexOf('</b>') + 4),
              }));
            }
            this.changeDetectorRef.markForCheck();
          }
        });
      }
    });
  }

  async carregarCriteriosAssociacaoSeNecessario(): Promise<void> {

    if(!this.cooperativa){
      await this.carregarCooperativa();
    }

    if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
      const responseRamo = await firstValueFrom(this.apiCriterioAssociacaoService.getCriteriosAssociacaoPorRamoFiltro(this.cooperativa.pessoaJuridica.ramo.id));

      if (responseRamo && responseRamo.data) {
        this.optionsCriterioAssocaicao = responseRamo.data;
      }

      const responseCooperativa = await firstValueFrom(this.apiCriterioAssociacaoService.getCriteriosAssociacaoPorCooperativa(this.cooperativa.pessoaJuridica.id));

      if (responseCooperativa && responseCooperativa.data) {
        this.selectedCriterioAssocaicaoCooperativaResponse = responseCooperativa.data;
      }

      this.selectedCriterioAssocaicao = this.convertToCriterioAssociacao(this.selectedCriterioAssocaicaoCooperativaResponse);
      this.updateSelectedCriterioAssocaicao();
      this.changeDetectorRef.markForCheck();
    }
  }


  atualizarProdutos(produto: Produtoservico, pessoaSegmProdServ: PessoaSegmProdServ, check: CheckboxChangeEvent) {

    this.houveAlteracaoForm = true
    const a = check.checked as Array<unknown>;

    if (check && a.length != 0) {
      if (produto.segmento.id === pessoaSegmProdServ.segmento.id) {
        this.criaPessoaComProdServ(produto);
      }
    } else {
      this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter(item =>
        !(item.segmento.id === produto.segmento.id &&
          item.produtoServico &&
          item.produtoServico.id === produto.id)
      );
    }
  }


  temDescricaoComplementar(produto: Produtoservico) {
    if (this.listaPessoaSegmProdServ) {
      for (const lista of this.listaPessoaSegmProdServ) {
        if (lista.produtoServico) {
          if (lista.produtoServico.id === produto.id) {
            if (lista.produtoServico.descricaoComplementar) {
              return true;
            }
          }
        }
      }
    }
    return false;
  }

  carregarCooperativa(): Promise<void> {
    return this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false)
      .then((coop: Cooperativa) => {
        if (!coop) {
          return;
        }
        this.cooperativaTemp = coop;
        this.verificarLiberacaoCampos(coop.id);

        const promisePj = this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla)
          .then((pj) => {
            this.nomePessoaJuridica = pj.data.nomeFantasia;
            this.changeDetectorRef.markForCheck();
          });

        const promiseDadosGerais = this.dadosGeraisService.getCooperativa(coop.id)
          .then((res) => {
            if (res == null || res.data.id == null) {
              this.desativaEventoForm();
              this.cooperativaNaoEncontrada();
              return;
            }
            this.cooperativa = res.data;
            this.filtroQuadroSocialFilial = this.cooperativa.id;

            // atualiza ramo caso altere na aba Dados Gerais
            if (coop.pessoaJuridica && coop.pessoaJuridica.ramo) {
              this.cooperativa.pessoaJuridica.ramo = coop.pessoaJuridica.ramo;
            }
            this.carregaNegocio(coop);
            this.buscaQuadroSocialFilial();
            this.atualizaPendenciaChaveManutencao(coop);
            this.changeDetectorRef.markForCheck();

            if (this.cooperativaTemp && this.cooperativaTemp.pessoaJuridica && this.cooperativaTemp.pessoaJuridica.ramo) {
              return firstValueFrom(
                this.apiCriterioAssociacaoService.getCriteriosAssociacaoPorRamoFiltro(this.cooperativaTemp.pessoaJuridica.ramo.id)
              ).then(response => {
                if (response && response.data) {
                  this.optionsCriterioAssocaicao = response.data;
                  this.changeDetectorRef.markForCheck();
                }
              });
            }
          });

        return Promise.all([promisePj, promiseDadosGerais]).then(() => {});
      });
  }

  private carregaNegocio(coop: Cooperativa) {
    this.negocioApi.getNegocio(coop.id).then((res) => {
      if (res == null) {
        this.cooperativaNaoEncontrada();
      } else {
        // getNegocio devolve NegocioTO (subconjunto de Negocio); os campos restantes
        // (cooperativa, cnaeSecundarios) são preenchidos depois neste componente.
        this.negocio = res.data as unknown as Negocio;

        if (!this.negocio.cnaePrimario) {
          this.negocio.cnaePrimario = new PessoaCnae();
        }

        if (
          this.negocio.listaPessoaSegmProdServ.length !== 0 ||
          !this.negocio.cnaePrimario ||
          // this.negocio.cnaeSecundarios.length !== 0 ||
          !this.negocio.faturamento
        ) {
          if (this.cooperativa.progressoMicro !== ProgressoMicroEnum.PRE_CADASTRO_0_0) {
            this.atualizarMensagensTela();
          }
        }

        this.listaProdutosAux = new Array<string>();

        if (this.negocio.produtos) {
          this.negocio.produtos.forEach((prod) => {
            this.listaProdutosAux = [...this.listaProdutosAux, '' + prod.id];
          });
        }

        if (this.negocio.listaPessoaSegmProdServ) {
          this.listaPessoaSegmProdServ = this.negocio.listaPessoaSegmProdServ;
        }

        if (this.negocio.filiadas) {
          this.listaCooperativasFiliacao = Object.assign([], this.negocio.filiadas);
          this.buscarFiliaisPorMatriz(this.cooperativa.pessoaJuridica.cnpj, '0');
        }

        this.buscarSegmentos();
        this.buscarRamo();

        if (this.negocio.segmentos && this.cooperativa.pessoaJuridica.ramo) {
          this.negocio.segmentos= this.negocio.segmentos.filter(n=> n.ramo.id === this.cooperativa.pessoaJuridica.ramo.id && n.ativo);
          this.listaPessoaSegmProdServ = this.negocio.listaPessoaSegmProdServ.filter(l => this.negocio.segmentos.some(seg => seg.id === l.segmento.id));
          this.negocio.segmentos.forEach((segmento) => {
            if (!this.listaProdutosServicos[segmento.id + 'string']) {
              this.apiProdutoservicoService.buscaPorRamoSegmento(segmento.id, this.cooperativa.pessoaJuridica.ramo.id).then((ramoSeg) => {
                if (ramoSeg && ramoSeg.data) {
                  this.listaProdutosServicos[segmento.id + 'string'] = ramoSeg.data;
                  this.changeDetectorRef.markForCheck();
                }
              });
            }
          });
        }
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  carregaOptions(pagina: string, nrLinhas: string) {
    const options = {
      params: new HttpParams().set('page', pagina).set('size', nrLinhas),
    };
    return options;
  }

  atualizaLiberacaoCampo(pendencia) {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas = [...this.pendenciasEditadas, pendencia];
    }
    this.mapPendencias = { ...this.mapPendencias, [pendencia.bloco]: false };
      this.houveAlteracaoForm = true;
      this.changeDetectorRef.markForCheck();
    }

  onLazyLoad(event) {
    if (this.negocio.filiadas.length > 0) {
      this.nrLinhas = event.rows;
      if (event.rows !== undefined) {
        this.nrLinhasTabela = event.rows;
      }
      this.tabelaCooperativas = undefined;
      this.get(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then((resp) => {
        this.tabelaCooperativas = resp.data.content;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  customSort(event: SortEvent) {
    event.data.sort((data1, data2) => {
      const value1 = data1[event.field];
      const value2 = data2[event.field];
      let result = null;

      if (value1 == null && value2 != null) {
        result = -1;
      } else if (value1 != null && value2 == null) {
        result = 1;
      } else if (value1 == null && value2 == null) {
        result = 0;
      } else if (typeof value1 === 'string' && typeof value2 === 'string') {
        result = value1.localeCompare(value2);
      } else {
        result = (value1 < value2) ? -1 : (value1 > value2) ? 1 : 0;
      }
      return (event.order * result);
    });
  }

  private buscarFiliaisPorMatriz(cnpj, page) {
    const options = this.carregaOptions(page, this.nrLinhas.toString());
    this.filialApi.filtraFilialPaginadoPelaMatriz(options, cnpj).then((coope) => {
      this.totalElementos = coope.data.totalElements;
      this.tabelaCooperativas = Object.assign([], coope.data.content);
      // Carrega CEP para tabela
      this.tabelaCooperativas.forEach((elemento) => {
        this.listaCooperativasFiliacao.forEach((elementoLista) => {
          if (elemento.cnpj === elementoLista.cnpj) {
            elemento.endereco = elementoLista.endereco;
          }
        });
      });
      this.changeDetectorRef.markForCheck();
    });
  }

  buscarCnaes() {
    this.cnaeApi.lista().then((response) => {
      if (response && response.data) {
        this.desativaEventoForm();
        this.optionsDrobdownCnaes = response.data;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  buscarSegmentos() {
    if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
      this.segmentoApi.buscaPorRamo(this.cooperativa.pessoaJuridica.ramo.id).then((response) => {
        if (response && response.data) {
          this.desativaEventoForm();

          this.optionsDrobdownSegmento = response.data;
          this.changeDetectorRef.markForCheck();
        }
      });
    }

    if (!this.cooperativa.pessoaJuridica.ramo || !this.cooperativa.pessoaJuridica.ramo.id) {
      this.optionsDrobdownSegmento = [];
      this.optionsDrobdownProduto = [];
      this.negocio.segmentos = [];
      this.listaProdutosServicos = [];
      this.listaProdutosAux = [];
    }
  }

  adicionarFiliacao() {
    this.modalAdicionarFilial = true;

    this.filialComponent.inicializaFilial();
    if (!this.negocio.filiadas) {
      this.negocio.filiadas = [];
      this.listaCooperativasFiliacao = [];
    }
  }

  editarFilial(id: number) {
    this.filialApi.get(id).then((resp) => {
      if (resp) {
        this.filialComponent.editarFilial(resp.data);
        this.modalAdicionarFilial = true;
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  AdicionarFilial(pessoaJuridicaTO: PessoaJuridicaBasicaTO) {
    let filialExiste = false;

    this.listaCooperativasFiliacao.forEach((filial) => {
      if (filial.cnpj === pessoaJuridicaTO.cnpj) {
        this.copiarFilialTOParaObjeto(filial, pessoaJuridicaTO);
        filialExiste = true;
      }
    });

    this.tabelaCooperativas.forEach((filial) => {
      if (filial.cnpj === pessoaJuridicaTO.cnpj) {
        this.copiarFilialTOParaObjeto(filial, pessoaJuridicaTO);
        filialExiste = true;
      }
    });

    if (!filialExiste) {
      this.listaCooperativasFiliacao = [...this.listaCooperativasFiliacao, pessoaJuridicaTO];
      this.tabelaCooperativas = [...this.tabelaCooperativas, pessoaJuridicaTO];
    }

    this.tabelaCooperativas.forEach((elemento) => {
      this.listaCooperativasFiliacao.forEach((elementoLista) => {
        if (elemento.cnpj === elementoLista.cnpj) {
          elemento.endereco = elementoLista.endereco;
        }
      });
    });
    this.adicionarQuadroSocialFilialNovaUF(pessoaJuridicaTO.ufSigla);
  }

  private copiarFilialTOParaObjeto(filial, pessoaJuridicaTO) {
    filial.id = pessoaJuridicaTO.id;
    filial.cnpj = pessoaJuridicaTO.cnpj;
    filial.cnpjValidado = true;
    filial.email = pessoaJuridicaTO.email;
    filial.nomeFantasia = pessoaJuridicaTO.nomeFantasia;
    filial.ramo = pessoaJuridicaTO.ramo;
    filial.razaoSocial = pessoaJuridicaTO.razaoSocial;
    filial.telefone = pessoaJuridicaTO.telefone;
    filial.ufSigla = pessoaJuridicaTO.ufSigla;
    filial.tipoPessoa = pessoaJuridicaTO.tipoPessoa;
    filial.endereco = pessoaJuridicaTO.endereco;

    filial.arquivos = pessoaJuridicaTO.arquivos;
  }

  CancelarModalFilial() {
    this.modalAdicionarFilial = false;
  }

  removerFilial(filial: PessoaJuridicaBasicaTO) {
    if(!this.keycloakService.isUsuarioNacional){
      this.messageService.clear();
      this.messageService.add({ severity: 'error', detail: 'Filial não pode ser removida por este Usuário', life: 10000 });
      return;
    }
    this.listaCooperativasFiliacao = this.listaCooperativasFiliacao.filter(coop => coop.id !== filial.id);
    this.tabelaCooperativas = this.tabelaCooperativas.filter(c => c !== filial);
    this.removeQuadroSocialFilialSeUltimaDaUF(filial.ufSigla);
  }

  exportarNegocio() {
    this.negocioApi
      .exportarRelatorioSegmento(this.cooperativaTemp.id)
      .then((response) => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, 'Negocio_Segmentos.xlsx');
      })
      .catch((error) => {
        if (error.status && error.status === 404) {
          this.messageService.add({ severity: 'warn', detail: 'Nenhum registro de negócio encontrado', life: 100000 });
        } else {
          this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
        }
      });
  }

  possuiSegmento(segmento: Segmento) {
    let indice = -1;
    this.listaPessoaSegmProdServ.forEach((pessoaSeg) => {
      if (segmento.id === pessoaSeg.segmento.id) {
        indice = this.listaPessoaSegmProdServ.indexOf(pessoaSeg);
      }
    });
    return indice;
  }

  atualizarListagemProdutos(event: MultiSelectChangeEvent) {
    const segmento = event.itemValue;
    const selecionados = event.value;
    const segContem = selecionados.filter((seg) => seg.id === segmento.id)[0];
    if (segmento) {
      if (!segContem) {
        this.listaProdutosServicos[segmento.id + 'string'] = null;
        this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter(
          pessoaSeg => pessoaSeg.segmento.id !== segmento.id
        );
        if (selecionados && selecionados.length === 0) {
          this.listaPessoaSegmProdServ = [];
        }
      } else {
        // insere
        this.criaPessoaComSeg(segmento);

        if (!this.listaProdutosServicos[segmento.id + 'string']) {
          this.apiProdutoservicoService.buscaPorRamoSegmento(segmento.id, this.cooperativa.pessoaJuridica.ramo.id).then((res) => {
            if (res && res.data) {
              this.listaProdutosServicos[segmento.id + 'string'] = res.data;
              this.changeDetectorRef.markForCheck();
            }
          });
        }
      }
    }
  }

  criaPessoaComProdServ(prod: Produtoservico) {
    const pessoaSegProdServ = new PessoaSegmProdServ();
    pessoaSegProdServ.pessoaJuridica = this.cooperativa.pessoaJuridica;
    pessoaSegProdServ.segmento = prod.segmento;
    pessoaSegProdServ.produtoServico = prod;

    this.listaPessoaSegmProdServ = [...this.listaPessoaSegmProdServ, pessoaSegProdServ];
  }

  criaPessoaComSeg(seg: Segmento) {
    const possuiSeg = this.possuiSegmento(seg);
    if (possuiSeg !== -1) {
      this.listaPessoaSegmProdServ = this.listaPessoaSegmProdServ.filter((_, i) => i !== possuiSeg);
    }
    const pessoaSegProdServ = new PessoaSegmProdServ();
    pessoaSegProdServ.pessoaJuridica = this.cooperativa.pessoaJuridica;
    pessoaSegProdServ.segmento = seg;

    this.listaPessoaSegmProdServ = [...this.listaPessoaSegmProdServ, pessoaSegProdServ];
  }

  cooperativaNaoEncontrada() {
    this.messageService.add({ severity: 'error', detail: 'Cooperativa não encontrada! [SAINDO]', life: 10000 });
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  erroSalvar() {
    this.evtErroSalvar.emit(true);
  }

  somenteNumeros(numero) {
    if (numero !== undefined) {
      return numero.toString().toUpperCase().replace(/[^A-Z0-9]+/g, '');
    }
  }

  carregaOptionsPaginado(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams().set('page', pagina).set('size', nrLinhas).set('sort', `${sortField},${sortOrder}`),
    };
    options.params = this.utilityService.carregaParamsString(this.filtronomeFantasia, options.params, 'nomeFantasia');
    options.params = this.utilityService.carregaParamsString(this.filtrocnpj, options.params, 'cnpj');
    options.params = this.utilityService.carregaParamsString(this.filtroUf, options.params, 'ufSigla');
    options.params = this.utilityService.carregaParamsString(this.filtroTelefone, options.params, 'telefone');
    options.params = this.utilityService.carregaParamsString(this.filtroEmail, options.params, 'email');

    return options;
  }

  get(pagina = 0, sortField, sortOrder = 1): Promise<IServiceResponse<IPage<PessoaJuridicaBasicaTO>>> {
    sortField = sortField || 'pessoaJuridicaFiliada.nomeFantasia';
    let sort: string;
    sort = sortOrder === 1 ? 'asc' : 'desc';
    const options = this.carregaOptionsPaginado(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
    return this.filialApi.filtraFilialPaginadoPelaMatriz(options, this.cooperativa.pessoaJuridica.cnpj);
  }

  onChangeFilter() {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => {
      this.dtFilial.reset();
    }, this.delay);
  }

  loadLazy(event: TableLazyLoadEvent) {
    if (event.rows !== undefined) {
      this.nrLinhasTabela = event.rows;
    }
    this.get(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder).then((resp) => {
      this.tabelaCooperativas = resp.data.content;
      this.changeDetectorRef.markForCheck();
    });
  }

  validaAjustesDados(): boolean {
    if (this.cooperativaTemp) {
      return this.validacaoDados.validaAjustesDadosManutencao(this.cooperativaTemp.progressoManutencaoMicro);
    }
    return false;
  }

  getQtdSegmentos(): number {
    if (this.isSegmentoUnico()) {
      return 1;
    }

    return this.optionsDrobdownSegmento.length;
  }

  isSegmentoUnico(): boolean {
    if (this.ramo != null && this.ramo.segmentoUnico != null && this.ramo.segmentoUnico) {
      return true;
    } else {
      return false;
    }
  }

  carregaOptionsQuadroFilial() {
    const options = {params: new HttpParams()};
    options.params = this.utilityService.carregaParamsId(this.cooperativa, options.params, 'idCooperativa');
    options.params = this.utilityService.carregaParamsString(this.cooperativa.pessoaJuridica.cnpj, options.params, 'cnpjMatriz');
    return options;
  }

  buscaQuadroSocialFilial() {
    const options = this.carregaOptionsQuadroFilial();
    this.quadroSocialApi.getQuadroSocialFiltro(options).then((res) => {
      this.listaQuadroSocialFilial = res.data;
      this.changeDetectorRef.markForCheck();
    });
  }
  removeQuadroSocialFilialSeUltimaDaUF(ufFilial: string) {
    let quadroSocial;
    if (this.listaQuadroSocialFilial.length > 0) {
      if((this.tabelaCooperativas.filter(c => c.ufSigla === ufFilial).length <= 0)) {
        quadroSocial = this.listaQuadroSocialFilial.filter((quadroSocialFilial) => quadroSocialFilial.uf === ufFilial).pop();
        if(quadroSocial.id) {
          this.listaExcluirQuadroSocialFilial = [
            ...this.listaExcluirQuadroSocialFilial,
            quadroSocial
          ] as QuadroSocialFilial[];
        }
        this.listaQuadroSocialFilial = this.listaQuadroSocialFilial.filter((quadroSocialFilial) => quadroSocialFilial.uf !== ufFilial);
      }
    }
  }

  adicionarQuadroSocialFilialNovaUF(ufFilial: string) {
    if((this.listaQuadroSocialFilial.filter(f => f.uf === ufFilial).length <= 0)) {
      const quadroFilial = new QuadroSocialFilial();
        quadroFilial.id = null;
        quadroFilial.uf = ufFilial;

      this.listaQuadroSocialFilial = [
        ...this.listaQuadroSocialFilial,
        quadroFilial
      ];
    }
  }

  buscarRamo(){
    if (this.cooperativa && this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.ramo) {
        this.ramoApi.getRamo(this.cooperativa.pessoaJuridica.ramo.id)
        .then(res => {
          this.ramo = res;
          this.changeDetectorRef.markForCheck();
        });
    }
  }
   mostraModalCnae() {
    this.display = true;
  }

  cancelarCnae(_event: boolean) {
    this.display = false;
  }

  validaQuantidadeSegmentos(): boolean{

    let listaAuxSegmentos = new Array<number>();

    if(this.portifolioComponent.listaPessoaSegmProdSevNova && this.portifolioComponent.listaPessoaSegmProdSevNova.length > 1){
      this.portifolioComponent.listaPessoaSegmProdSevNova.forEach(element => {
        if(!listaAuxSegmentos.includes(element.segmento.id)){
          listaAuxSegmentos = [...listaAuxSegmentos, element.segmento.id];
        }
      });
    }

    return listaAuxSegmentos.length > 1? true : false
  }

  mapNegocioToAbaTOs(negocio: Negocio): AbaManutencaoSegmentacaoFiliaisTO{

    const negocioTO = new AbaManutencaoSegmentacaoFiliaisTO();
    negocioTO.idCooperativa = negocio.cooperativa.id;
    negocioTO.ramo = negocio.ramo;
    negocioTO.segmentos = negocio.segmentos;
    negocioTO.faturamento = negocio.faturamento;
    negocioTO.faturamentoAtual = negocio.faturamentoAtual;
    negocioTO.filiadas = negocio.filiadas;
    negocioTO.listaPessoaSegmProdServ = this.limpaPessoaJuridica(negocio.listaPessoaSegmProdServ);
    negocioTO.produtos = negocio.produtos;
    negocioTO.aba = Aba.ABA_SEGUIMENTOS_FILIAIS;

    return negocioTO;
  }

  limpaPessoaJuridica(listaPessoaSegmProdServ: PessoaSegmProdServ[]): PessoaSegmProdServ[] {
    return listaPessoaSegmProdServ.map((pessoaSegm) => {
      const pessoaJuridica = pessoaSegm.pessoaJuridica;
      const novaPessoaJuridica = new PessoaJuridica();
      novaPessoaJuridica.id = pessoaJuridica.id;
      return { ...pessoaSegm, pessoaJuridica: novaPessoaJuridica };
    });
  }

}
