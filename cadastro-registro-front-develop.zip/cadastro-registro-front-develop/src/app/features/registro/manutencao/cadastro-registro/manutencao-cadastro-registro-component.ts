import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ApiManutencaoCadastroRegistroService } from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { ValidacaoPendenciaVO } from '@cadastro-registro-api/models/validacao-pendencia-vo';
import { PendenciaVO } from '@cadastro-registro-api/models/PendenciaVO';
import { ApicontatoService } from 'src/app/api/services/api-contatos-service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { AppComponent } from 'src/app/app.component';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { ContatoComponent } from '../../registro/contato/contato-component';
import { ManutencaoDadosGeraisComponent } from '../dadosGerais/manutencao-dados-gerais-component';
import { ManutencaoDocumentacaoComponent } from '../documentacao/manutencao-documentacao.component';
import { ManutencaoNegocioComponentComponent } from '../negocio/manutencao-negocio-component.component';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { GovernancaSharedComponent } from '../../governanca-shared/governanca-shared.component';
import { ApiGovernancaService } from '../../governanca-shared/service/api-governanca.service';
import { PermissaoCooperativa } from 'src/app/features/cooperativa/permissao/permissao.service';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { ComponenteComAlteracoesPendentes } from '@shared/guard/alteracoes-pendentes.guard';


@Component({
  selector: 'app-manutencao-cadastro-registro-component',
  templateUrl: './manutencao-cadastro-registro-component.html',
  styleUrls: ['./manutencao-cadastro-registro-component.css']
})
export class ManutencaoCadastroRegistroComponent implements OnInit, ComponenteComAlteracoesPendentes {
  cooperativaManutencao: CooperativaManutencao;

  estadoPreenchimentoGovernanca: 'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null = null;

  /** Resolve a navegação suspensa pelo guard de saída (AlteracoesPendentesGuard). */
  private resolverSaidaPagina: ((podeSair: boolean) => void) | null = null;
  podeModificarLogo = true;
  podeExcluirAtualizacao = false;

  cooperativa: Cooperativa;

  // Dados (Preenchimento)
  submeterValidado = false;

  pendenciasAbas: ValidacaoPendenciaVO;

  contatosValidados: boolean = null;

  get podeSubmeter(): boolean {
    return this.submeterValidado && !this.possuiAbaComObrigatorioPendente();
  }

  // Sobre Pendências
  pendenciasValidas = false;
  podeProgredir = false;

  mostrarSubmeter = false;
  mostrarAjustes = false;
  mostrarConformidade = false;
  anoAtualizacaoDados: number;
  anoReferencia: number;
  exibeMensagemAtualizacao = false;
  bloqueiaSubmeterAjustesValidarDados = false;

  abrirAbaAjuda = false;
  geralValidado = false;
  controleFormContato = false;

  // Declação controle salvar aba
  @ViewChild('dadosGerais') dadosGeraisForm: ManutencaoDadosGeraisComponent;
  @ViewChild('negocioForm') negocioForm: ManutencaoNegocioComponentComponent;
  @ViewChild('governanca') governancaForm: GovernancaSharedComponent;
  @ViewChild('contato') contatoForm: ContatoComponent;
  // @ViewChild('onglets') onglets: TabView;
  @ViewChild('documentos') documentosForm: ManutencaoDocumentacaoComponent;

  dialogoSalvarAba = false;
  situacaoEnum = SituacaoEnum;

  podeModificarOsCampos = false;

  public index = 0;
  public abaOrigem = 0;
  public abaDestino = 0;
  statusCooperativa: string;
  submeterPendencias = false;
  submeterExibir = false;
  nomePessoaJuridica: string;
  anoCicloAtual = new Date().getFullYear();
  constructor(
    private apiCadastroRegistroService: ApiManutencaoCadastroRegistroService,
    private messageService: MessageService,
    public app: AppComponent,
    private router: Router,
    public keycloakService: KeycloakService,
    private confirmationService: ConfirmationService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private apiCooperativaService: ApiCooperativaService,
    public breadCrumbPrimeNGService: BreadcrumbService,
    private route: ActivatedRoute,
    private apiPj: ApiPessoaJuridicaService,
    public permissaoCooperativa: PermissaoCooperativa,
    private apiGovernancaService: ApiGovernancaService,
    private apiContatoService: ApicontatoService
  ) {}

  ngOnInit() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla).then((pj) => {
          this.nomePessoaJuridica = pj.data.nomeFantasia;
        });
        this.cooperativa = coop;
        if (!coop.arquivado) {
          this.carregarTela(coop);
        }
      }
    });
  }
  carregarTela(coopJaCarregada?: Cooperativa) {
    const carregamento = coopJaCarregada
      ? Promise.resolve(coopJaCarregada)
      : this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false);
    carregamento.then((coop) => {
      this.cooperativa = coop;
      this.verificarLiberacaoCampos();
      this.getAnoAtualizacao();
      this.atualizaBreadCrumbPrimeNG();
      this.verificarSeHaAprovacaoCoop();
      this.atualizarCooperativaManutencaoPendencias();
      this.buscarEstadoPreenchimentoGovernanca();
    });
  }

  validadaCancelado(): boolean{
    return this.cooperativa.situacaoCooperativa.id != this.situacaoEnum.CANCELADA;
  }

  atualizaBreadCrumbPrimeNG() {
    const param = new URLSearchParams(window.location.search);
    let paramIdCooperativa = param.get('id_cooperativa');
    if (!paramIdCooperativa) {
      this.route.queryParams.subscribe((params) => {
        paramIdCooperativa = params['id_cooperativa'];
      });
    }
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/' },
      { label: 'Cooperativas Registradas', routerLink: '/cooperativa/listagem' },
      {
        label: 'Cooperativa',
        command: (onclick) => {
          this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: paramIdCooperativa } });
        },
      },
      { label: 'Manutenção Cadastro Registro' },
    ]);
  }

  getAnoAtualizacao() {
    if (this.cooperativa.pessoaJuridica.ramo.id) {
      this.apiCooperativaService.buscaUltimoCadastroPeriodoAtualizacaoPorRamo(this.cooperativa.pessoaJuridica.ramo.id).then((response) => {
        if (response['data']) {
          this.anoAtualizacaoDados = response['data'].ano ? response['data'].ano : new Date().getFullYear();
        } else {
          this.anoAtualizacaoDados = new Date().getFullYear();
        }
        this.anoReferencia = +this.anoAtualizacaoDados - 1;
        this.getUltimaAprovacaoCooperativa();
      });
    }
  }

  getUltimaAprovacaoCooperativa() {
    if (this.cooperativa.id && this.keycloakService.isUsuarioCooperativa) {
      this.exibeMensagemAtualizacao = true;
      this.apiCooperativaService.buscaUltimaAprovacaoCooperativa(this.cooperativa.id).then((response) => {
        if (response.data) {
          if (response.data.ano === this.anoAtualizacaoDados) {
            this.exibeMensagemAtualizacao = false;
          } else {
            this.exibeMensagemAtualizacao = true;
          }
        } else {
          this.exibeMensagemAtualizacao = true;
        }
      });
    } else {
      this.exibeMensagemAtualizacao = false;
    }
  }

  submeterCadastroValidacao() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.apiValidacaoDadosService
          .finalizarAjustesManutencao(coop.id, this.cooperativa.parecer != null ? this.cooperativa.parecer.arquivoConformidade : null)
          .then((res) => {
            this.router.navigate(['/cooperativa/listagem']);
          });
      }
    });
  }

  private cooperativaManutencaoAbasPromise: Promise<CooperativaManutencao> | null = null;

  private atualizarAbaSubmeterPromise: Promise<void> | null = null;

  private buscarCooperativaManutencaoAbas(): Promise<CooperativaManutencao> {
    if (!this.cooperativa) {
      return Promise.resolve(null);
    }
    if (!this.cooperativaManutencaoAbasPromise) {
      this.cooperativaManutencaoAbasPromise = this.apiValidacaoDadosService
        .obterCooperativaManutencaoAbas(this.cooperativa.id, this.anoCicloAtual)
        .then((pendencias) => {
          this.cooperativaManutencao = pendencias;
          return pendencias;
        })
        .finally(() => {
          this.cooperativaManutencaoAbasPromise = null;
        });
    }
    return this.cooperativaManutencaoAbasPromise;
  }

  atualizarCooperativaManutencaoPendencias() {
    if (this.cooperativa) {
      this.buscarCooperativaManutencaoAbas();
    }
  }


  atualizarVerificacaoSubmeterPendencias() {
    if (this.cooperativa) {
      this.apiValidacaoDadosService.obterPendenciasAbasManutencao(this.cooperativa.id).then((validacaoPendencia) => {
        this.aplicarVerificacaoSubmeterPendencias(validacaoPendencia && validacaoPendencia.data != null ? validacaoPendencia.data : null);
      });
    }
  }

  private aplicarVerificacaoSubmeterPendencias(pendencias: ValidacaoPendenciaVO | null) {
    if (pendencias != null) {
      this.podeProgredir = pendencias.podeProgredir;

      if (pendencias.validado && (!this.statusCooperativa || this.statusCooperativa !== 'Aprovada')) {
        // this.classeTopoSubmeter = this.classeFixaIcone + ' fa-solid fa-triangle-exclamation  color-text-red';
        this.submeterPendencias = true;
      } else {
        this.submeterPendencias = false;
      }
    }

    // PREENCHIMENTO
    const emPreenchimento = !this.cooperativa.progressoManutencaoMicro
      || this.cooperativa.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2;
    this.mostrarSubmeter = emPreenchimento;
    this.mostrarAjustes = !emPreenchimento
      && this.cooperativa.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1;
  }

  atualizarAbaSubmeter(mostrarMensagens: boolean = false) {
    if (this.cooperativa && !this.atualizarAbaSubmeterPromise) {
      // Validando aba "DADOS GERAIS"
      this.atualizarAbaSubmeterPromise = this.apiCadastroRegistroService.validarSubmeter(this.cooperativa.id).then((res) => {
        this.submeterValidado = (res && res.data) ? res.data.validado : false;

        this.apiCooperativaService.getStatus(this.cooperativa.id).then((reStatus) => {
          if (reStatus && reStatus.data) {
            this.statusCooperativa = reStatus.data;
          }
          this.submeterExibir = this.submeterValidado && (!this.statusCooperativa || this.statusCooperativa !== 'Aprovada');
        });

        return Promise.all([
          this.buscarCooperativaManutencaoAbas(),
          this.apiValidacaoDadosService.obterPendenciasAbasManutencao(this.cooperativa.id),
          this.buscarEstadoPreenchimentoGovernanca(),
          this.buscarValidacaoContatos()
        ]).then(([, validacaoResp]) => {
          const v: ValidacaoPendenciaVO = (validacaoResp && validacaoResp.data) ? validacaoResp.data : null;
          this.pendenciasAbas = v;

          this.bloqueiaSubmeterAjustesValidarDados = !!v
            && ((v.dadosGerais && v.dadosGerais.validado === false)
              || (v.governanca && v.governanca.validado === false)
              || (v.negocio && v.negocio.validado === false)
              || (v.documentos && v.documentos.validado === false));

          // Caso tenha pendências (podeProgredir, submeterPendencias, mostrar*)
          this.aplicarVerificacaoSubmeterPendencias(v);
        }).catch((e) => {
          console.error('Erro ao atualizar dados do submeter', e);
        });

      }).catch((e) => {
        console.error('Erro ao validar submeter', e);
      }).finally(() => {
        this.atualizarAbaSubmeterPromise = null;
      });
    }
  }

  recarregarStatusAbas(): void {
    this.atualizarCooperativaManutencaoPendencias();
  }

  private buscarEstadoPreenchimentoGovernanca(): Promise<void> {
    if (!this.cooperativa) {
      return Promise.resolve();
    }
    return this.apiGovernancaService.buscarPendencias(this.cooperativa.id)
      .then((res) => {
        this.estadoPreenchimentoGovernanca = res?.data?.estadoPreenchimento ?? null;
      })
      .catch(() => {
        this.estadoPreenchimentoGovernanca = null;
      });
  }

  private possuiAbaComObrigatorioPendente(): boolean {
    return this.estadoPreenchimentoGovernanca === 'OBRIGATORIO_PENDENTE'
      || this.abaNaoPreenchida(this.pendenciasAbas?.dadosGerais)
      || this.abaNaoPreenchida(this.pendenciasAbas?.negocio)
      || this.abaNaoPreenchida(this.pendenciasAbas?.documentos)
      || this.contatosValidados === false;
  }

  private abaNaoPreenchida(pendencia: PendenciaVO): boolean {
    return !!pendencia && pendencia.abaPreenchida === false;
  }

  private buscarValidacaoContatos(): Promise<void> {
    if (!this.cooperativa) {
      return Promise.resolve();
    }
    return this.apiContatoService.validarContatos(this.cooperativa.id)
      .then((res) => {
        this.contatosValidados = res && res.data != null ? res.data : null;
      })
      .catch(() => {
        this.contatosValidados = null;
      });
  }

  submeterCadastro() {
    if (this.podeSubmeter) {
      this.confirmationService.confirm({
        message: 'As informações e documentos inseridos no sistema não poderão mais ser alterados e serão recebidos para análise.',
        key: 'submeterCadastro',
        accept: () => {
          this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
            if (coop) {
              this.apiCadastroRegistroService.submeterCadastro(coop.id).then((res) => {
                if (res != null) {
                  if (res.data) {
                    this.router.navigate(['/cooperativa/listagem']);
                  } else {
                    this.router.navigate(['/registro/manutencaoCadastro']);
                  }
                }
              });
            }
          });
        },
      });
    }
  }

  exibirMensagens(mensagens: IServiceMessage[], titulo: string = null) {
    if (mensagens) {
      this.messageService.clear();
      mensagens.forEach((mens) => {
        this.messageService.add({ severity: 'warn', summary: titulo, detail: mens.message, life: 10000 });
      });
    }
  }

  public change(index: number): void {
    this.atualizarCooperativaManutencaoPendencias();
    // Não permite voltar (a não ser clicando explicitamente na aba)
    if (index >= this.index || index === undefined) {
      this.index = index;
      this.atualizarForms(index);
      this.abaDestino = index;
    }
  }

  fecharDialogo() {
    this.dialogoSalvarAba = false;
  }

  salvandoAba = false;

  salvarAba() {
    if (this.salvandoAba) {
      return;
    }
    this.salvandoAba = true;

    if (this.dadosGeraisForm) {
      if (this.dadosGeraisForm.getAlteracaoForm()) {
        this.dadosGeraisForm.desativaEventoForm();
        this.dadosGeraisForm.salvarDadosGerais(this.abaDestino);
      }
    }

    if (this.governancaForm) {
      if (this.governancaForm.getAlteracaoForm()) {
        this.governancaForm.desativaEventoForm();
        this.governancaForm.salvar(this.abaDestino);
      }
    }

    if (this.negocioForm) {
      if (this.negocioForm.getAlteracaoForm()) {
        this.negocioForm.desativaEventoForm();
        this.negocioForm.salvarNegocio(this.abaDestino);
      }
    }

    if (this.contatoForm) {
      if (this.contatoForm.getAlteracaoForm()) {
        this.contatoForm.desativaEventoForm();
        this.contatoForm.salvar(this.abaDestino);
      }
    }

    if (this.documentosForm) {
      if (this.documentosForm.getAlteracaoForm()) {
        this.documentosForm.desativaEventoForm();
        this.documentosForm.salvar(this.abaDestino);
      }
    }

    this.dialogoSalvarAba = false;
    this.atualizarAbaSubmeter();
    this.resolverSaida(true);

    // Cooldown para impedir duplo-clique disparando as mesmas gravações novamente
    // (as chamadas acima são fire-and-forget, sem uma promise unificada para aguardar).
    setTimeout(() => {
      this.salvandoAba = false;
    }, 1500);
  }

  naoSalvaAba() {
    if (this.dadosGeraisForm) {
      this.dadosGeraisForm.desativaEventoForm();
      this.dadosGeraisForm.carregarTela();
    }

    if (this.governancaForm) {
      this.governancaForm.desativaEventoForm();
      this.governancaForm.carregaTela();
    }

    if (this.negocioForm) {
      this.negocioForm.desativaEventoForm();
      this.negocioForm.carregarTela();
    }

    if (this.contatoForm) {
      this.contatoForm.desativaEventoForm();
      this.contatoForm.carregarTela();
    }

    if (this.documentosForm) {
      this.documentosForm.desativaEventoForm();
      this.documentosForm.carregaDocumento();
    }

    this.dialogoSalvarAba = false;
    this.index = this.abaDestino;
    this.resolverSaida(true);
  }

  mudandoAba(event, idxNovo) {
    if (event) {
      event.stopPropagation();
    }

    if (this.index !== idxNovo) {
      this.abaOrigem = this.index;
      this.index = idxNovo;
      this.abaDestino = idxNovo;

      if (this.podeModificarOsCampos) {
        this.controlaDialogoSalvarAba();
      }

      this.verificarLiberacaoCampos();
      this.atualizarCooperativaManutencaoPendencias();

      if ((idxNovo === 1 && this.governancaForm) || (idxNovo === 2 && this.negocioForm) || (idxNovo === 3 && this.contatoForm)) {
        this.atualizarForms(idxNovo);
      }

      this.atualizarAbaSubmeter();
    }
  }

  atualizarForms(index: number) {
    if (index === 0 && this.dadosGeraisForm) {
      this.dadosGeraisForm.carregarTela();
    }
    if (index === 1 && this.governancaForm) {
      this.governancaForm.carregaTela();
    }
    if (index === 2 && this.negocioForm) {

      this.negocioForm.carregarTela();
    }
    if (index === 3 && this.contatoForm) {
      this.contatoForm.carregarTela();
    }
    if (index === 4 && this.documentosForm) {
      this.documentosForm.carregaDocumento();
    }
    if (index === 5){
      this.atualizarAbaSubmeter();
    }
  }

  cancelaSalvarAba() {
    this.abaDestino = this.abaOrigem;
    this.dialogoSalvarAba = false;
    this.resolverSaida(false);
  }

  erroSalvar(event) {
    this.abaDestino = this.index;
  }

  bloquearAba() {
    this.index = this.abaOrigem;
  }

  /**
   * Guard de saída da página (AlteracoesPendentesGuard): com alterações não
   * salvas — ou conselho de governança em edição/inclusão rápida — abre o mesmo
   * diálogo "Salvar alterações da página antes de sair?" da troca de abas e a
   * navegação fica suspensa até a escolha: Salvar/Não salvar liberam a saída,
   * fechar o diálogo mantém o usuário na página.
   */
  podeSair(): boolean | Promise<boolean> {
    if (!this.podeModificarOsCampos || !this.possuiAlteracoesOuEdicaoAberta()) {
      return true;
    }
    this.dialogoSalvarAba = true;
    return new Promise<boolean>((resolve) => {
      this.resolverSaidaPagina = resolve;
    });
  }

  possuiAlteracoes(): boolean {
    return !!(this.dadosGeraisForm?.getAlteracaoForm()
      || this.documentosForm?.getAlteracaoForm()
      || this.governancaForm?.getAlteracaoForm()
      || this.negocioForm?.getAlteracaoForm()
      || this.contatoForm?.getAlteracaoForm());
  }

  private possuiAlteracoesOuEdicaoAberta(): boolean {
    return this.possuiAlteracoes() || !!this.governancaForm?.algumaEdicaoAtiva();
  }

  private resolverSaida(podeSair: boolean) {
    if (this.resolverSaidaPagina) {
      const resolve = this.resolverSaidaPagina;
      this.resolverSaidaPagina = null;
      resolve(podeSair);
    }
  }

  /** Diálogo fechado sem decisão (X/ESC): permanece na página. */
  aoOcultarDialogoSalvarAba() {
    this.resolverSaida(false);
  }

  /** Fechar/recarregar o navegador com alterações não salvas: aviso nativo. */
  @HostListener('window:beforeunload', ['$event'])
  avisarSaidaNavegador(event: BeforeUnloadEvent) {
    if (this.podeModificarOsCampos && this.possuiAlteracoesOuEdicaoAberta()) {
      event.preventDefault();
      event.returnValue = true;
    }
  }

  controlaDialogoSalvarAba() {
    if (this.dadosGeraisForm) {
      if (this.dadosGeraisForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.documentosForm) {
      if (this.documentosForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.governancaForm) {
      if (this.governancaForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.negocioForm) {
      if (this.negocioForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.contatoForm) {
      if (this.contatoForm.getAlteracaoForm()) {
        this.dialogoSalvarAba = true;
      }
    }

    if (this.dialogoSalvarAba) {
      setTimeout(() => {
        const element: HTMLElement = document.getElementById('botaoVoltar') as HTMLElement;
        element.click();
        this.dialogoSalvarAba = true;
      });
    }
  }

  onSalvarDadosGerais(event) {
    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarNegocio(event) {

    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarGovernancia(event) {

    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarContato(event) {

    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  onSalvarDocumentos(event) {

    this.verificarLiberacaoCampos();
    this.atualizarCooperativaManutencaoPendencias();
  }

  statusEmPreenchimento(cooperativa: Cooperativa): void {
    if (!this.cooperativa.inPreenchimento) {
        this.apiCooperativaService.atualizarStatusEmPreenchimento(cooperativa).then((response) => {
        });
    }
  }

  verificarSeHaAprovacaoCoop() {
    this.apiCooperativaService.buscarUltimaAprovacao(this.cooperativa.pessoaJuridica.id).then((res) => {
      if (res != null && res.data != null && this.keycloakService.isUsuarioNacional) {
        this.podeExcluirAtualizacao = true;
      } else {
        this.podeExcluirAtualizacao = false;
      }
    });
  }

  removerAprovacao() {
    this.apiCooperativaService.excluirAprovacaoCooperativa(this.cooperativa.pessoaJuridica.id).then((response) => {
      this.carregarTela();
      window.location.reload();
    });
  }

  verificarLiberacaoCampos() {
    if (this.cooperativa) {
      this.apiCadastroRegistroService.podePreencherCadastroRegistro(this.cooperativa.id).then((res) => {
        if (res != null && res.data != null) {
          this.podeModificarOsCampos = res.data;
        }
      });
    }
  }


  navegarTutorial() {
    const link = document.createElement('a');
    document.body.appendChild(link);
    link.target = '_blank';
    link.setAttribute('visibility', 'hidden');
    link.href = 'https://www.capacita.coop.br/videos/soucoop-atualizacao-cadastral-na-pratica';
    link.click();
  }
}
