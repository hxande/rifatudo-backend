import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ConfirmationService, MessageService, SelectItem } from 'primeng/api';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import {
  ApiManutencaoCadastroRegistroService
} from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { UtilityService } from '@utils/utility/utility.service';
import { GeralService } from '@auth/geral.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { RedeSocial } from '@cadastro-registro-api/models/RedeSocial';
import { Categoria } from '@cadastro-registro-api/models/Categoria';
import { CooperativaRegistro } from '@cadastro-registro-api/models/CooperativaRegistro';
import { CooperativaBasica } from '@cadastro-registro-api/models/CooperativaBasica';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { DataUtils } from '@shared/utils/DataUtils';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { Pessoa } from '@cadastro-registro-api/models/Pessoa';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { DateService } from '@shared/util/service/date.service';
import { HistoricoQuadroSocialComponent } from '@shared/historico-quadro-social/historico-quadro-social.component';
import { Subject } from 'rxjs';
import {
  QuadroSocialRegistradasComponent
} from '../../../cooperativa/quadro-social-registradas/quadro-social-registradas.component';
import { ApiEnderecoService } from '@cadastro-registro-api/services/api-endereco.service';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { PermissaoCooperativa } from 'src/app/features/cooperativa/permissao/permissao.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { DadosGeraisTO } from 'src/app/api/models/DadosGeraisTO';
import { ApiManutencaoDadosGeraisService } from 'src/app/api/services/api-manutencao-dados-gerais.service';
import { AbaManutencaoDadosGeraisTO } from 'src/app/api/models/AbaManutencaoDadosGeraisTO';
import { EnderecoTO } from 'src/app/api/models/EnderecoTO';
import { EnderecoMapper } from 'src/app/api/mapper/EnderecoMapper';
import { QuadroSocialMapper } from 'src/app/api/mapper/QuadroSocialMapper';
import { ApiManutencaoService } from 'src/app/api/services/api.manutencao.service';
import { PessoaJuridicaTO } from 'src/app/api/models/PessoaJuridicaTO';
import { InformacaoAdicionalTO } from 'src/app/api/models/InformacaoAdicionalTO';
import { Aba } from 'src/app/api/models/AbaEnum';
import { ApiSindicatoService } from 'src/app/api/services/api-sindicato.service';
import { SindicatoTO } from 'src/app/api/models/SindicatoTO';

@Component({
  selector: 'app-manutencao-dados-gerais-component',
  templateUrl: './manutencao-dados-gerais-component.html',
  styleUrls: ['./manutencao-dados-gerais-component.scss'],
})
export class ManutencaoDadosGeraisComponent implements OnInit, OnDestroy {
  cooperativaTemp: Cooperativa;
  atualizaAbaDocumentoFlag = false;
  anoAnterior: number;
  anoAtual: number;
  @Input() cooperativaManutencao: CooperativaManutencao;

  constructor(
    private ramoApi: ApiRamoService,
    private dadosGeraisService: ApiManutencaoDadosGeraisService,
    private apiCadastroRegistroService: ApiManutencaoCadastroRegistroService,
    private apiValidacaoDados: ApiValidacaoDadosService,
    public language: LanguageService,
    public keycloakService: KeycloakService,
    private utilityService: UtilityService,
    private geralService: GeralService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private apiPj: ApiPessoaJuridicaService,
    private apiEnderecoService: ApiEnderecoService,
    public validacaoDados: ValidacaoDados,
    private permissaoCooperativa: PermissaoCooperativa,
    private apiCooperativaService: ApiCooperativaService,
    private apiManutencaoSerivce: ApiManutencaoService,
    private apiSindicato: ApiSindicatoService,
  ) {
    this.anoAtual = new Date().getFullYear();
    this.anoAnterior = this.anoAtual - 1;
  }

  nomePessoaJuridica: string;
  aprovacoes = [];
  cooperativa: Cooperativa = null;
  enderecos: Endereco[] = null;
  enderecosIniciais: Endereco[] = null;
  redesSociais: RedeSocial[] = null;
  indexEnderecoPrincipal: number = null;

  categorias: Categoria[] = [];
  cooperativasVinculadas: number[] = [];
  cooperativasVinculadas2: CooperativaBasica[] = [];
  cooperativasBusca: CooperativaBasica[] = [];

  pendenciasEditadas = [];

  dataAtual = new Date();
  optionsDropdownRamo: Ramo[];
  optionsDropdownSindicato: SindicatoTO[] = [];
  filiadaSindicato: boolean = null;
  sindicatoSelecionado: SindicatoTO = null;
  dateService = new DateService();

  adicionarQuantidadeTotal = false;

  podeModificarOsCampos = false;
  dataUtils = new DataUtils();
  mensagensValidacao = Array<{ summary: string; detail: string }>();
  mapPendencias: Map<string, boolean> = new Map();
  // Declaração controle de aba salvar
  @ViewChild('dadosGeraisForm') dadosGeraisForm: NgForm;
  @ViewChild('historicoQuadroSocial') historicoQuadroSocial: HistoricoQuadroSocialComponent;
  @ViewChild('quadroSocialComponent') quadroSocialRegistradasComponent: QuadroSocialRegistradasComponent;
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtMudarRamo = new EventEmitter<Ramo>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  @Output() evtAtualizaDocumentos = new EventEmitter<boolean>();

  houveAlteracaoForm = false;
  modalVisivel: boolean;
  podeExcluir = false;
  carregarQuadroSocial = new Subject<Cooperativa>();

  rdSingular = false;
  rdCentralFederacao = false;
  rdConfederacao = false;
  modalFiliadas = false;
  modalFiliacaoSuperior = false;
  modalConfederacaoGerenciarFiliadas = false;
  modalCentralFederacao = false;
  abaInicialFiliadas = 0;

  ngOnInit(): void {
    this.carregarTela();
  }

  verificarMudancaRamo(ramo: Ramo) {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false).then((coop) => {
      if (coop) {
        const idRamo = ramo ? ramo.id : null;
        // Validando aba "DADOS GERAIS"
        this.apiCadastroRegistroService.verificarMudancaRamo(coop.id, idRamo).then((res) => {
          if (res && res.data) {
            const ramoComDados = res.data;

            this.confirmationService.confirm({
              message: 'Existem dados de Governaça/Negócio no ramo ' + ramoComDados.nome + ' que serão perdidos, deseja continuar a operação?',
              reject: () => {
                this.cooperativa.pessoaJuridica.ramo = ramoComDados;
              },
            });
          }
        });
      }
    });
  }

  atualizarMensagensTela() {
    if (this.cooperativa) {
      // Validando aba "DADOS GERAIS"
      this.apiCadastroRegistroService.validarDadosGerais(this.cooperativa.id).then((res) => {
        this.mensagensValidacao = [];
        this.desativaEventoForm();
        if (res && res.data) {
          const dadosValidacao = res.data;
          if (!dadosValidacao.validado) {
            if (dadosValidacao.mensagens) {
              this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
                summary: msg.message.indexOf('<b>') === -1 ? '' : msg.message.substring(msg.message.indexOf('<b>') + 3, msg.message.indexOf('</b>')),
                detail: msg.message.indexOf('<b>') === -1 ? msg.message : msg.message.substring(msg.message.indexOf('</b>') + 4),
              }));
            }
          }
        }
      });
    }
  }

  private atualizaPendenciaChaveManutencao(coop: Cooperativa) {
    this.apiValidacaoDados.obterUltimasPendenciasChaveManutencao(coop.id).then((res) => {
      this.mapPendencias = res.data;
    });
  }

  verificarLiberacaoCampos(coop: Cooperativa) {
    if (coop) {
      this.apiCadastroRegistroService.podePreencherCadastroRegistro(coop.id).then((res) => {
        if (res != null && res.data != null) {
          this.podeModificarOsCampos = res.data && this.permissaoCooperativa.permissaoAtualizarCadastro();
        }
      });
    }
  }

  mudaRamo(event) {
    this.verificarMudancaRamo(event.value);
    if (!event.value) {
      this.filiadaSindicato = null;
      this.sindicatoSelecionado = null;
      this.optionsDropdownSindicato = [];
    } else if (this.filiadaSindicato) {
      this.buscarSindicatos();
    }
  }

  carregarFiliacaoSindical() {
    const idSindicato = (this.cooperativa as any).idSindicato;
    this.filiadaSindicato = idSindicato != null ? true : null;
    this.sindicatoSelecionado = null;
    if (idSindicato != null) {
      this.buscarSindicatos(idSindicato);
    }
  }

  aoMudarFiliacaoSindical() {
    this.houveMudancaForm();
    if (this.filiadaSindicato) {
      this.buscarSindicatos();
    } else {
      this.sindicatoSelecionado = null;
    }
  }

  buscarSindicatos(idSindicatoSelecionado?: number) {
    const pessoaJuridica = this.cooperativa ? this.cooperativa.pessoaJuridica : null;
    const uf = pessoaJuridica ? pessoaJuridica.ufSigla : null;
    const idRamo = pessoaJuridica && pessoaJuridica.ramo ? pessoaJuridica.ramo.id : null;
    this.apiSindicato.listaParaFiliacao(uf, idRamo).then((res) => {
      this.optionsDropdownSindicato = res && res.data ? res.data.content : [];
      const idSelecionado = idSindicatoSelecionado != null
        ? idSindicatoSelecionado
        : this.sindicatoSelecionado ? this.sindicatoSelecionado.id : null;
      this.sindicatoSelecionado = idSelecionado != null
        ? this.optionsDropdownSindicato.find((s) => s.id === idSelecionado) || null
        : null;
    });
  }

  public desativaEventoForm() {
    this.houveAlteracaoForm = false;
    this.quadroSocialRegistradasComponent.houveAlteracaoForm = false;
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  public getAlteracaoForm() {
    return this.houveAlteracaoForm || this.quadroSocialRegistradasComponent.houveAlteracaoForm;
  }


  verificarGrauCooperativa(recarregar: boolean) {
    if (this.cooperativa != null && this.cooperativa.categoria != null) {
      if (!(typeof this.cooperativa.categoria.minimoCooperativa === 'number')) {
        this.cooperativa.categoria.minimoCooperativa = 0;
      }

      if(recarregar){
        this.cooperativasVinculadas = [];
        this.cooperativasVinculadas2 = [];
      }
    }

    this.validaExibicaoFiliadas();

  }

  obterEnderecoPrincipal() {
    return this.indexEnderecoPrincipal != null ? this.enderecos[this.indexEnderecoPrincipal] : null;
  }

  atualizaLiberacaoCampo(pendencia) {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas.push(pendencia);
    }
    this.mapPendencias[pendencia.bloco] = false;
    this.houveAlteracaoForm = true;
  }

  verificarCooperativa(cv: CooperativaBasica, i: number) {
    if (!cv || !cv.id) {
      this.cooperativasVinculadas[i] = null;
      this.cooperativasVinculadas2[i] = null;
    }
  }

  removerCooperativaVinculada(i: number) {
    if (
      this.cooperativa != null &&
      this.cooperativa.categoria != null &&
      typeof this.cooperativa.categoria.minimoCooperativa === 'number' &&
      this.cooperativa.categoria.minimoCooperativa > 0
    ) {
      if (this.cooperativasVinculadas.length > this.cooperativa.categoria.minimoCooperativa) {
        this.cooperativasVinculadas.splice(i, 1);
        this.cooperativasVinculadas2.splice(i, 1);
      }
    }

    if (this.cooperativasVinculadas.length <= this.cooperativa.categoria.minimoCooperativa) {
      this.podeExcluir = false;
    }
  }

  adicionarCooperativaVinculada() {
    this.cooperativasVinculadas.push(null);
    this.cooperativasVinculadas2.push(null);

    if (this.cooperativasVinculadas.length > this.cooperativa.categoria.minimoCooperativa) {
      this.podeExcluir = true;
    }
  }

  buscarRamos() {
    this.ramoApi.getRamos().then((response) => {
      if (response && response.data) {
        this.optionsDropdownRamo = response.data;
      }
    });
  }

  carregarTela() {
    this.cooperativasVinculadas = [];
    this.cooperativasVinculadas2 = [];
    this.cooperativa = new Cooperativa();
    this.cooperativa.pessoaJuridica = new PessoaJuridica();
    this.criaEnderecoPrincipalVazio();
    this.enderecos = this.enderecosIniciais;

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado, false).then((coop) => {
      if (coop) {
        this.cooperativaTemp = coop;
        this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla).then((pj) => {
          this.nomePessoaJuridica = pj.data.nomeFantasia;
        });
        this.dadosGeraisService.getCooperativa(coop.id).then((res) => {
          if (res == null || res.data.id == null) {
            this.cooperativaNaoEncontrada();
          } else {
            this.cooperativa = res.data;

            if (this.cooperativa.pessoaJuridica && this.cooperativa.pessoaJuridica.dataConstituicao) {
              this.cooperativa.pessoaJuridica.dataConstituicao = this.dateService.getDate(this.cooperativa.pessoaJuridica.dataConstituicao);
            }

            this.carregarFiliacaoSindical();

            this.carregarQuadroSocial.next(this.cooperativa);

            // ------------ Tratamento de endereços -----------------------
            this.enderecos = this.cooperativa.pessoaJuridica.enderecos;
            if(this.enderecos.length === 0){
              this.enderecos = this.enderecosIniciais;
            }

            this.enderecos = this.enderecos.sort((a, b) => {
              if (a.tipoEndereco?.id === 1) return -1;
              if (b.tipoEndereco?.id === 1) return 1;

              if (a.tipoEndereco?.id === 2) return -1;
              if (b.tipoEndereco?.id === 2) return 1;

              return 0;
            });

            let index = 0;
            this.enderecos.forEach((end) => {
              if (end.idMunicipio) {
                this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {
                  end.municipio = resEnd;

                  // Adicionando UF
                  if (end.municipio != null && end.municipio.id) {
                    end.uf = end.municipio.uf;
                  }
                });
              }

              // Sinalizando quem é o endereço principal
              if (end.tipoEndereco.enderecoPrincipal) {
                this.indexEnderecoPrincipal = index;
              }

              index++;
            });


            this.redesSociais = this.cooperativa.pessoaJuridica.redesSociais;

            // ---------------- Vinculações --------------------------------------
            this.dadosGeraisService.getVinculacoes(coop.id).then((resVinc) => {
              if (resVinc && resVinc.data != null && resVinc.data.length > 0) {
                const dados = resVinc.data.filter((x) => x != null); // Tirar itens nulos da listagem

                this.cooperativasVinculadas2 = dados;
                this.cooperativasVinculadas = new Array<number>(this.cooperativasVinculadas2.length);
              }
              this.verificarGrauCooperativa(false);
            });

            this.atualizaPendenciaChaveManutencao(coop);

            // Atualizando Aba
            if (this.cooperativa.progressoMicro !== ProgressoMicroEnum.PRE_CADASTRO_0_0) {
              this.atualizarMensagensTela();
            }
          }
        });

        // Categorias
        this.dadosGeraisService.getCategorias().then((res) => {
          if (res && res.data != null) {
            this.categorias = res.data;
          }
        });


        this.verificarLiberacaoCampos(coop);
      }
    });

    this.buscarRamos();
  }

  criaEnderecoPrincipalVazio() {
    this.enderecosIniciais = [];
    this.apiEnderecoService.getListaTipoEndereco().subscribe(response => {
      const listaTipoEndereco = response.data.content;
      if(listaTipoEndereco){
        listaTipoEndereco.forEach((value, index) => {
          const endereco = new Endereco();
          endereco.tipoEndereco = value;
          endereco.correspondenciaDiferente = false;
          endereco.enderecoPrincipal = value.enderecoPrincipal;
          this.enderecosIniciais.push(endereco);
          if(value.enderecoPrincipal){
            this.indexEnderecoPrincipal = index;
          }
        })
      }
    });
  }

  ngOnDestroy(): void {}



  formatarNire(nire) {
    this.cooperativa.pessoaJuridica.nire = this.somenteNumeroNire(nire);
  }

  get bloqueiaEdicaoVinculos(): boolean {
    return this.cooperativa?.status?.toLowerCase() === 'aprovada';
  }

  get mensagemBloqueioVinculos(): string {
    return this.bloqueiaEdicaoVinculos
      ? 'A edição ficará disponível após a conclusão da análise pela OE/UE.'
      : '';
  }

  somenteNumeroNire(valor) {
    let saida = null;
    if (valor != null) {
      const valorInteiro = parseInt(String(valor).replace(/\D+/g, ''), 10);
      if (typeof valorInteiro === 'number' && !isNaN(valorInteiro)) {
        saida = valorInteiro;
      }
    }
    return saida;
  }


  varrerListagemVinculacao() {
    if (this.cooperativasVinculadas2 != null) {
      for (let i = 0; i < this.cooperativasVinculadas2.length; i++) {
        if (this.cooperativasVinculadas2[i] != null && !this.cooperativasVinculadas2[i].id) {
          this.cooperativasVinculadas2[i] = null;
        }
      }
    }
  }

  atualizarCooperativa(cv: CooperativaBasica, i: number) {
    this.cooperativasVinculadas2[i] = cv;
  }

  cooperativaNaoEncontrada() {
    this.messageService.add({ severity: 'error', detail: 'Cooperativa não encontrada! [SAINDO]', life: 10000 });
  }

  salvarDadosGerais(abaDestino: number) {
    this.varrerListagemVinculacao();
    this.houveAlteracaoForm = true;

    let pendenciaPreenchimentoTela = false;
    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchimentoTela = true;
      }
    });

    if (pendenciaPreenchimentoTela) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Preencha corretamente as orientações para ajuste!',
        life: 10000,
      });
      return;
    }

    if (this.filiadaSindicato === true && !this.sindicatoSelecionado) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Selecione o sindicato ao qual a cooperativa é filiada.',
        life: 10000,
      });
      return;
    }

    const dadosGerais = new AbaManutencaoDadosGeraisTO();
    dadosGerais.idCooperativa = this.cooperativa.id;
    dadosGerais.aba = Aba.ABA_DADOS_GERAIS;

    const informacaoAdicional = new InformacaoAdicionalTO();
    informacaoAdicional.liquidacao = this.cooperativa.liquidacao;
    informacaoAdicional.regidaPorLei = this.cooperativa.regidaPorLei;
    informacaoAdicional.categoriaId = this.cooperativa.categoria.id;
    informacaoAdicional.idSindicato = this.filiadaSindicato && this.sindicatoSelecionado ? this.sindicatoSelecionado.id : null;
    dadosGerais.informacaoAdicional = informacaoAdicional;

    const pessoaJuridicaTO = new PessoaJuridicaTO();
    if(this.cooperativa.pessoaJuridica !== undefined){
      pessoaJuridicaTO.id = this.cooperativa.pessoaJuridica.id;
      pessoaJuridicaTO.razaoSocial = this.cooperativa.pessoaJuridica.razaoSocial;
      pessoaJuridicaTO.dataConstituicao = this.cooperativa.pessoaJuridica.dataConstituicao;
      pessoaJuridicaTO.emailGeral = this.cooperativa.pessoaJuridica.emailGeral;
      pessoaJuridicaTO.idRamo = this.cooperativa.pessoaJuridica.ramo.id;
      pessoaJuridicaTO.nire = this.cooperativa.pessoaJuridica.nire;
      pessoaJuridicaTO.nomeFantasia = this.cooperativa.pessoaJuridica.nomeFantasia;
      pessoaJuridicaTO.site = this.cooperativa.pessoaJuridica.site;
      pessoaJuridicaTO.lojaVirtual = this.cooperativa.pessoaJuridica.lojaVirtual;
      pessoaJuridicaTO.telefoneGeral = this.cooperativa.pessoaJuridica.telefoneGeral;
      pessoaJuridicaTO.nomeFantasiaReceitaFederal = this.cooperativa.pessoaJuridica.nomeFantasiaReceitaFederal;

      dadosGerais.pessoaJuridica = pessoaJuridicaTO;
    }

    const pessoaId = this.cooperativa?.pessoaJuridica?.id ?? null;
    const enderecos: Endereco[] = this.enderecos ?? [];
    const enderecosTO: EnderecoTO[] = enderecos.map((e) => {
      const clone: Endereco = { ...e };
      const p = new Pessoa();
      p.id = pessoaId;
      clone.pessoa = p;
      clone.idMunicipio = clone.municipio ? clone.municipio.id : null;
      clone.idEstado   = clone.uf ? clone.uf.id : null;
      clone.cep = clone.cep ? this.utilityService.retirarFormatacao(clone.cep) : clone.cep;
      return EnderecoMapper.toTO(clone);
    });

    dadosGerais.enderecos = enderecosTO;
    dadosGerais.cooperativasVinculadas = (this.cooperativasVinculadas2 || []).map(c => c.id);

    const quadrosSociais = this.quadroSocialRegistradasComponent.quadroSociais;
    if (quadrosSociais?.length) {
      const qsAtual = quadrosSociais.find(qs => qs.ano === this.anoAtual);
      if (qsAtual) {
        dadosGerais.quadroSocialManutencao = QuadroSocialMapper.toTO(qsAtual);
      }
    }

    dadosGerais.redesSociais = this.redesSociais.filter(rs => rs.link && rs.tipoRedeSocial);

    if (this.cooperativa.pessoaJuridica?.dataConstituicao) {
      this.cooperativa.pessoaJuridica.dataConstituicao =
        this.dateService.getDate(this.cooperativa.pessoaJuridica.dataConstituicao);
    }

    this.geralService.salvarPendenciaManutencao(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);

    if (this.pendenciasEditadas.length > 0) {
      this.apiValidacaoDados.editarAgrupamento(this.pendenciasEditadas).then((res) => {
        this.pendenciasEditadas = res.data;
      });
    }

    this.limparRegistroEmailCooperativa(this.cooperativa);

    this.apiManutencaoSerivce.dadosGerais(dadosGerais)
      .then(() => {
        this.quadroSocialRegistradasComponent.houveAlteracaoForm = false;
        this.houveAlteracaoForm = false;

        for (const ap of this.aprovacoes) {
          if (ap.houveAlteracao) ap.houveAlteracao = false;
        }

        this.carregarTela();
        window.scroll(0, 0);
        this.evtAtualizaDocumentos.emit(this.atualizaAbaDocumentoFlag);
        this.evtFimSalvarDados.emit(abaDestino);
        this.statusEmPreenchimento(this.cooperativa);
      })
      .catch((e) => {
        // this.evtErroSalvar.emit(true);
      });
  }

  limparRegistroEmailCooperativa(cooperativa: Cooperativa): void {
   if (!cooperativa || !cooperativa.cooperativaRegistro) {
      return null;
    }

    // Cooperativa.cooperativaRegistro está tipado como CooperativaRegistro no modelo (public),
    // mas o backend retorna uma lista (List<CooperativaRegistro> em Cooperativa.java)
    (cooperativa.cooperativaRegistro as unknown as CooperativaRegistro[]).find(
      (registro: CooperativaRegistro) => {
          if (registro?.registroEmail) {
            registro.registroEmail = null;
          }
      });
  }

  statusEmPreenchimento(cooperativa: Cooperativa): void {
    this.cooperativasBusca
    if (!this.cooperativa.inPreenchimento) {
        this.apiCooperativaService.atualizarStatusEmPreenchimento(cooperativa).then((response) => {
        });
    }
  }

  procurarCooperativas(event) {
    const query = this.normalizarBuscaCooperativa(event.query);

    if (this.cooperativa != null && this.cooperativa.categoria != null) {
      this.dadosGeraisService.buscarCooperativas(query, this.cooperativa.categoria.id).then((res) => {
        this.cooperativasBusca = res.data.filter((coop) => coop.id !== this.cooperativa.id);
      });
    }
  }

  private normalizarBuscaCooperativa(valor: string): string {
    if (!valor) {
      return '';
    }

    return valor
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[.\-/\s]/g, '')
      .trim();
  }


  atualizaAbaDocumento() {
    this.atualizaAbaDocumentoFlag = true;
  }

  selectMask(event: Event) {
    setTimeout(() => (event.target as HTMLInputElement).select(), 100);
  }

  collapsedFieldSetEndereco(endereco: Endereco) {
    return false;
  }

  toggleableEndereco(endereco: Endereco) {
    if (endereco) {
      return false;
    }
  }

  limpaEndereco(endereco: Endereco) {
    if (endereco) {
      this.enderecos.forEach((end) => {
        if (endereco.tipoEndereco.id === end.tipoEndereco.id) {
          end.cep = null;
          end.idEstado = null;
          end.idMunicipio = null;
          end.enderecoReferencia = null;
          end.numero = null;
          end.bairro = null;
          end.municipio = null;
          end.uf = null;
          end.complemento = null;
        }
      });
    }
  }

  validaAjustesDados(): boolean {
    if (this.cooperativaTemp) {
      return this.validacaoDados.validaAjustesDadosManutencao(this.cooperativaTemp.progressoManutencaoMicro);
    }
    return false;
  }

  setCorrespondenciaDiferente(enderecoCorrespondenciaDiferente: boolean){
    this.enderecos.forEach(e => e.correspondenciaDiferente = enderecoCorrespondenciaDiferente);
  }

  abrirModalFiliadas(){
    this.modalFiliadas = true;
  }

  abrirModalFiliacaoSuperior(){
    this.modalFiliacaoSuperior = true;
  }

  abrirModalConfederacaoGerenciarFiliadas(){
    this.modalConfederacaoGerenciarFiliadas = true;
  }

  abrirModalCentralFederacao(indexAba: number){
    this.modalCentralFederacao = true;
    this.abaInicialFiliadas = indexAba;
  }

  pegaListaCooperativa(cooperativas){
    this.modalFiliadas = false;
    this.modalFiliacaoSuperior = false;
    this.modalCentralFederacao = false;
    this.modalConfederacaoGerenciarFiliadas = false;
    this.cooperativasVinculadas2 = cooperativas;
  }

  validaExibicaoFiliadas(){
    const categoriaId = this.cooperativa.categoria.id;
    this.rdSingular = categoriaId === 1;
    this.rdCentralFederacao = categoriaId === 2;
    this.rdConfederacao = categoriaId === 3;
  }

  onSelecionarCategoria(cat: Categoria, event: Event): void {

    event.preventDefault();

    if (this.bloqueiaEdicaoVinculos == true) {
      return;
    }

    if (this.cooperativa?.situacaoCooperativa?.nome?.toLowerCase() === 'cancelada') {
      return;
    }

    if (
      this.cooperativa.categoria &&
      this.cooperativa.categoria.id === cat.id
    ) {
      return;
    }

    this.confirmationService.confirm({
      header: 'Alterar grau da cooperativa',
      icon: 'pi pi-exclamation-triangle',

      message:
        'Ao alterar o grau da cooperativa, vínculos de filiação existentes poderão ser removidos ou impactados. ' +
        'Deseja realmente continuar?',

      acceptLabel: 'Sim, continuar',
      rejectLabel: 'Cancelar',

      accept: () => {

        this.cooperativa.categoria = cat;

        this.verificarGrauCooperativa(true);

        this.houveMudancaForm();
      }
    });
  }
}
