import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { AppComponent } from 'src/app/app.component';
import { Button } from 'primeng/button';
import { ConfirmDialog } from 'primeng/confirmdialog';
import { TabViewChangeEvent } from 'primeng/tabview';
import { FileUploadComponent } from '@gui/file-upload/file-upload/file-upload.component';
import { Parecer } from '@cadastro-registro-api/models/Parecer';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { PessoaImagem } from '@cadastro-registro-api/models/PessoaImagem';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { PessoaDocumento } from '@documentacao-api/models/PessoaDocumento';
import { DateService } from '@shared/util/service/date.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { ApiDadosGeraisService as ApiDadosGeraisServiceCadastro } from 'src/app/api/services/api-dados-gerais.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiCooperativaLogoService } from '@cadastro-registro-api/services/api-cooperativa-logo.service';
import { ValidacaoProcessoRegistro } from '@shared/validacao/validacao-processo-registro.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiPessoaDocumentoService } from '@documentacao-api/services/api-pessoa-documento.service';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { VisitaTecnica } from '@cadastro-registro-api/models/VisitaTecnica';
import { ApiVisitaTecnicaService } from '@cadastro-registro-api/services/api-visita-tecnica.service';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { Messages } from '@shared/mensagens/Messages';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { ApontamentoTO } from '@cadastro-registro-api/models/ApontamentoTO';
import { ApiApontamentoService } from '@cadastro-registro-api/services/api-apontamento.service';
import { ArquivoUploadService } from '@gui/file-upload/file-upload/arquivo-service';
import { ChangeDetectorRef } from '@angular/core';
import { CooperativaHistoricoProcessoRegistroTO } from 'src/app/api/models/CooperativaHistoricoProcessoRegistroTO';


@Component({
  selector: 'app-processo-registro-component',
  templateUrl: './processo-registro-component.html',
  styleUrls: ['./processo-registro-component.scss']
})
export class ProcessoRegistroComponent implements OnInit {

  @ViewChild('fileup') fileup: FileUploadComponent;
  @ViewChild('fileupDeliberacao') fileupDeliberacao: FileUploadComponent;
  @ViewChild('fileupRecursoDeliberacao') fileupRecursoDeliberacao: FileUploadComponent;
  @ViewChild('fileupResultadoRecurso') fileupResultadoRecurso: FileUploadComponent;
  @ViewChild('btnAnalisarCadastro') btnAnalisarCadastro: ElementRef;
  @ViewChild('btnConformidadeLegal') btnConformidadeLegal: ElementRef;
  @ViewChild('btnRecursoDeliberacao') btnRecursoDeliberacao: Button;
  @ViewChild('btnEnviarDatas') btnEnviarDatas: Button;
  @ViewChild('vConfirmaRetornoConformidade') vConfirmaRetornoConformidade: ConfirmDialog;
  @ViewChild('vAjusteVisitaTecnica') vAjusteVisitaTecnica: ConfirmDialog;
  items: MenuItem[];
  indexsteps = 1;
  indexaccordion = 0;
  parecer: Parecer = new Parecer();
  objCooperativa: Cooperativa;
  visitaTecnica: VisitaTecnica;
  modalJustificativaDeliberacaoVisivel = false;
  modalApontamentosVisivel = false;
  dialogoVT = false;
  classTab0 = 'display-none';
  classTab1 = 'display-none';
  classTab2 = 'display-none';
  classTab3 = 'display-none';
  classTab4 = 'display-none';
  classMicro_4_1 = 'display-none';
  classMicro_5_1 = 'display-none';
  classMicro_5_2 = 'display-none';
  classMicro_5_3 = 'display-none';
  classMicro_5_3_botoes = 'display-none';
  classMicro_5_4 = 'display-none';
  classMicro_5_1_1 = 'display-none';
  classMicro_5_arquivo = 'display-none';
  classMicro_5_botoes = 'display-none';
  classMicro_6_1 = 'display-none';
  classMicro_6_1_1 = 'display-none';
  classMicro_6_1_2 = 'display-none';
  classMicro_6_2 = 'display-none';
  classMicro_6_2_2 = 'display-none';
  msgCard2_1 = 'display-none';
  msgCard2_2 = 'display-none';
  msgCard2_3 = 'display-none';
  msgCard2_4 = 'display-none';
  msgCard3_1 = 'display-none';
  msgCard3_2 = 'display-none';
  msgCard5_1 = 'display-none';
  msgCard5_2 = 'display-none';
  msgCard6_1 = 'display-none';
  msgCardArquivado = 'display-none';

  btnArquivarProcessoCadastroIniciado = 'display-none';
  btnArquivarProcesso = 'display-none';
  btnDesarquivarProcesso = 'display-none';
  btnArquivarProcessoIndeferido = 'display-none';
  btnDesarquivarProcessoIndeferido = 'display-none';
  btnArquivarProcessoConformidadeLegal = 'display-none';
  btnDesarquivarProcessoConformidadeLegal = 'display-none';
  listaMensagem: Messages[];
  enviarMensagem = true;
  vtEnviada = false;
  vtMarcada = false;
  vtConcluida = false;
  dataSugerida1: Date;
  dataSugerida2: Date;
  dataSugerida3: Date;
  dataUltimoArquivoUpload: Date;
  mostraMensagemVT = false;
  numArquivosRestantes = 0;
  nomePessoaJuridica: string;
  statusProgresso = '';
  flagBtnDeferirPedido = true;
  flagBtnIndeferirPedido = true;
  flagBtnDeferirRecurso = true;
  flagBtnIndeferirRecurso = true;
  eventListenerFileUpload = null;
  eventListenerFileUploadRecursoCooperativa = null;
  eventListenerFileUploadResultadoRecurso = null;
  cooperativaLogo: PessoaImagem = new PessoaImagem();
  podeModificarLogo = true;
  progressoVisita = ProgressoMacroEnum.VISITA_TECNICA_4;
  progressoMacroEnum = ProgressoMacroEnum;
  progressoMicroEnum = ProgressoMicroEnum;
  repositorio: PessoaDocumento[];
  dateService = new DateService;
  txJustificaVisitaNaoRealizada = null;
  modalVisitaNaoRealizada = false;
  modalHistoricoApontamento = false;
  historicoApontamentos: ApontamentoTO[] = [];
  txApontamento: string;
  btnDisabled: boolean = true;
  btnRealizada: boolean;
  flgMarcarRealizada: boolean;
  historico: CooperativaHistoricoProcessoRegistroTO[];

  constructor(
    private messageService: MessageService,
    public app: AppComponent,
    public language: LanguageService,
    public breadCrumbPrimeNGService: BreadcrumbService,
    private router: Router,
    private dadosGeraisService: ApiDadosGeraisService,
    private apiVisitaTecnicaService: ApiVisitaTecnicaService,
    public keycloakService: KeycloakService,
    private confirmationService: ConfirmationService,
    private cooperativaService: ApiCooperativaService,
    private cooperativaLogoService: ApiCooperativaLogoService,
    public validacaoProcessoRegistro: ValidacaoProcessoRegistro,
    public utilityService: UtilityService,
    private pessoaDocumentoApi: ApiPessoaDocumentoService,
    private apontamentoService: ApiApontamentoService,
    private arquivoUploadService: ArquivoUploadService,
    private changeDetectorRef: ChangeDetectorRef,
    private apiDadosGeraisService: ApiDadosGeraisServiceCadastro
  ) {
    this.breadCrumbPrimeNGService.setItems([
      { label: 'Início', routerLink: '/' },
      { label: 'Processo de Registro', routerLink: '/registro/listagem' },
      { label: 'Cooperativa', routerLink: '/registro/processo' },

    ]);

    this.objCooperativa = new Cooperativa();
    this.visitaTecnica = new VisitaTecnica();
    this.objCooperativa.pessoaJuridica = new PessoaJuridica();
  }

  ngOnInit(): void {
    this.listaMensagem = [];
    this.items = [
      { label: 'Cadastro e envio dos documentos' },
      { label: 'Validação dos dados e documentos' },
      { label: 'Análise de conformidade legal' },
      { label: 'Visita técnica' },
      { label: 'Deliberação' },
      { label: 'Emissão do certificado de registro' }
    ];
    this.obterNomePessoaLogada();
    // this.listarHistoricoProcessoRegistro();
    this.arquivoUploadService.getNumArquivosRestantes().subscribe((numArquivos) => {
      this.numArquivosRestantes = numArquivos;

      if (this.numArquivosRestantes === 0) {
        this.flagBtnDeferirPedido = true;
      } else {
        this.flagBtnDeferirPedido = false;
      }
    });

  }

  dialogConfirmaRetornoParaConformidadeLegal() {
    this.confirmationService.confirm({
      message: 'Deseja ajustar a conformidade legal desta cooperativa ?',
      key: 'confirmaRetornoConformidade',
      acceptLabel: 'Sim',
      rejectLabel: 'Não',
      accept: () => {
        this.retornarConformidadeLegal();
      }
    });
  }

  dialogAjustarVisitaTecnica() {
    this.confirmationService.confirm({
      message: 'Deseja ajustar a visita técnica da cooperativa ?',
      key: 'ajusteVisitaTecnica',
      acceptLabel: 'Sim',
      rejectLabel: 'Não',
      accept: () => {
        this.ajustarVisitaTecnica();
      }
    });
  }

  retornarConformidadeLegal() {
    this.cooperativaService.retornarConformidadeLegal(this.objCooperativa).then(response => {
      this.classMicro_5_botoes = 'display-none';
      if (response.data) {
        this.objCooperativa = response.data;
        this.setCooperativa(this.objCooperativa);
        if (this.keycloakService.isUsuarioCooperativa) {
          this.router.navigate(['/registro/processo-cooperativa']);
        }
        if (this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional) {
          this.router.navigate(['/registro/processo'], {
            queryParams: { id_cooperativa: this.objCooperativa.id },
            skipLocationChange: false
          });
        }
      }
    });
  }

  ajustarVisitaTecnica() {
    this.apiVisitaTecnicaService.ajustarVisitaTecnica(this.objCooperativa).then(response => {
      if (response.data) {
        this.apiVisitaTecnicaService.get(response.data.id).then(resVisita => {
          this.vtMarcada = false; // fecha o quadro que informa a data aceita pela cooperativa
          if (this.fileup) {
            this.fileup.desabilita = false; // abre o botão do file upload para exclusão
          }
          this.classMicro_5_botoes = 'display-none';
          this.visitaTecnica.visitaNaoRealizada = false;
          this.marcaComoRealizada(this.visitaTecnica.dataAceitaCooperativa);
          this.classMicro_4_1 = '';
          this.visitaTecnica.dataEnvioParecer = null;
          this.visitaTecnica.visitaNaoRealizada = false;
          this.classMicro_5_arquivo = 'display-none';
          if (resVisita.data.processoAlternativo) {
            if (this.fileup) {
              this.fileup.disabled = false;
            }
            this.objCooperativa.progressoMacro = this.progressoMacroEnum.VISITA_TECNICA_4;
          }
        });
      }
    });
  }

  analisarCadastro() {
    this.router.navigate(['/registro/cadastro'], {
      queryParams: { id_cooperativa: this.objCooperativa.id },
      skipLocationChange: false
    });
  }

  arquivarProcesso() {
    this.confirmationService.confirm({
      message: 'Deseja arquivar o processo?',
      accept: () => {

        this.cooperativaService.arquivarProcesso(this.objCooperativa.id).then(response => {
          this.msgCardArquivado = 'display-block';
          this.setCooperativa(response.data);
          if (this.keycloakService.isUsuarioNacional && this.parecer.arquivoResultadoRecurso) {
            this.salvarResultadoRecursoDeliberacao();
          }

          this.flagBtnIndeferirRecurso = true;
          this.flagBtnDeferirRecurso = true;
          window.scroll(0, 0);
        });
      }
    });
  }

  habilitarOuDesabilitarBtn(button: ElementRef, habilitar: boolean): void {
    let btn: HTMLButtonElement = button.nativeElement;
    habilitar ? btn.removeAttribute('disabled') : btn.setAttribute('disabled', 'true');
  }

  alterarNomeBtn(button: ElementRef, nome: string): void {
    const btn: HTMLButtonElement = button.nativeElement;
    btn.innerText = nome;
  }

  desarquivarProcesso() {
    this.confirmationService.confirm({
      message: 'Deseja desarquivar o processo?',
      accept: () => {
        this.cooperativaService.desarquivarProcesso(this.objCooperativa.id).then(response => {
          this.msgCard2_1 = 'display-none';
          this.classTab1 = 'display-none';
          this.msgCardArquivado = 'display-none';
          this.setCooperativa(response.data);
          this.habilitarOuDesabilitarBtn(this.btnConformidadeLegal, false)
          this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, false)
          this.vtMarcada = false;
        });
      }
    });
  }

  setCooperativa(obj: Cooperativa) {
    this.setDisplayNone();
    this.objCooperativa = obj;
    this.obterHistoricoApontamento();

    this.parecer = this.objCooperativa.parecer ? this.objCooperativa.parecer : new Parecer();
    if (this.parecer) {
      this.carregarArquivos(this.objCooperativa.id);
    }
    this.parecer.cooperativa = new Cooperativa();
    this.parecer.cooperativa.pessoaJuridica = this.objCooperativa.pessoaJuridica;
    this.parecer.cooperativa.id = this.objCooperativa.id;
    this.obtemVisitaTecnica();
    if (this.parecer.dataCadastro) {
      this.msgCard2_4 = 'display-block';
      this.alterarNomeBtn(this.btnAnalisarCadastro, 'Visualizar cadastro')
      this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, true)
    }
    if (this.parecer.dataConformidade) {
      this.msgCard3_2 = 'display-block';
      this.habilitarOuDesabilitarBtn(this.btnConformidadeLegal, true)
      this.alterarNomeBtn(this.btnConformidadeLegal, 'Visualizar cadastro')
    }
    if ((this.parecer.arquivoDeliberacao && (this.parecer.dataDeliberacao || this.parecer.dataIndeferimentoDeliberacao))
      && obj.progressoMicro !== ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1) {
      this.classMicro_5_botoes = 'display-none';
      this.flagBtnDeferirPedido = true;
      this.flagBtnIndeferirPedido = true;

      if (this.parecer.dataDeliberacao) {
        this.msgCard5_1 = 'display-block';
      }
      this.classMicro_5_arquivo = 'display-block';
      if (this.fileupDeliberacao) {
        this.fileupDeliberacao.setDesabilita();
      }
    }
    if ((this.parecer.arquivoRecursoDeliberacao && this.parecer.dataDeliberacaoRecurso)
      && obj.progressoMicro !== ProgressoMicroEnum.REGISTROS_INDEFERIDOS_OCE_5_2) {
      this.msgCard5_2 = 'display-block';
      this.classMicro_5_4 = 'display-block';
      if (this.fileupRecursoDeliberacao) {
        this.fileupRecursoDeliberacao.setDesabilita();
      }
    }
    if ((this.parecer.arquivoResultadoRecurso && this.parecer.loginResultadoRecurso)
      && obj.progressoMicro !== ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3) {
      this.classMicro_5_3_botoes = 'display-block';
      this.flagBtnIndeferirRecurso = true;
      this.flagBtnDeferirRecurso = true;
    }
    if (this.parecer.dataCertificado) {
      this.msgCard6_1 = 'display-block';
      if (this.fileupResultadoRecurso) {
        this.fileupResultadoRecurso.setDesabilita();
      }
    }

    if (obj.arquivado === true) {
      this.msgCardArquivado = 'display-block';
      this.btnDesarquivarProcesso = 'display-block';
      this.flagBtnIndeferirRecurso = true;
      this.flagBtnDeferirRecurso = true;
    }

    switch (obj.progressoMacro) {
      case ProgressoMacroEnum.CADASTRO_INICIADO_1: {
        this.statusProgresso = 'Aguardando envio do cadastro pela Cooperativa.';
        this.indexaccordion = 0;
        this.indexsteps = 0;
        this.btnArquivarProcessoCadastroIniciado = obj.arquivado ? 'display-none' : 'display-block';
        break;
      }
      case ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2: {
        this.statusProgresso = 'Validação dos dados';
        this.classTab1 = 'display-block';
        this.indexaccordion = 1;
        this.indexsteps = 1;
        this.btnArquivarProcesso = obj.arquivado ? 'display-none' : 'display-block';
        this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, true);
        if (obj.arquivado === true) {
          this.alterarNomeBtn(this.btnAnalisarCadastro, 'Visualizar cadastro')
          this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, false)
          this.msgCard2_3 = 'display-none';
          break;
        }

        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1) {
          if (this.keycloakService.isUsuarioCooperativa) {
            this.alterarNomeBtn(this.btnAnalisarCadastro, 'Visualizar cadastro')
            this.msgCard2_2 = 'display-block';
          } else {
            this.alterarNomeBtn(this.btnAnalisarCadastro, 'Analisar cadastro')
          }

          break;
        }

        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2) {
          this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, false)
          this.alterarNomeBtn(this.btnAnalisarCadastro, 'Visualizar cadastro')
          this.msgCard2_3 = 'display-block';
          break;
        }

        this.msgCard2_1 = 'display-block';
        break;
      }
      case ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3: {
        this.statusProgresso = 'Análise de conformidade legal';
        this.classTab2 = 'display-block';
        this.indexaccordion = 2;
        this.indexsteps = 2;
        if (obj.arquivado === true) {
          this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, false)
          this.alterarNomeBtn(this.btnAnalisarCadastro, 'Visualizar cadastro')
          this.btnDesarquivarProcessoConformidadeLegal = 'display-block';
          this.btnArquivarProcessoConformidadeLegal = 'display-none';
          this.msgCard3_1 = 'display-none';

          break;
        }
        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1) {
          this.habilitarOuDesabilitarBtn(this.btnConformidadeLegal, true)
          this.alterarNomeBtn(this.btnConformidadeLegal, 'Analisar conformidade legal')

        }
        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2) {
          this.habilitarOuDesabilitarBtn(this.btnConformidadeLegal, true)
          this.alterarNomeBtn(this.btnConformidadeLegal, 'Visualizar cadastro')
          this.btnArquivarProcessoConformidadeLegal = 'display-block';
          this.msgCard3_1 = 'display-block';
        }
        break;
      }
      case ProgressoMacroEnum.VISITA_TECNICA_4: {
        this.statusProgresso = 'Visita técnica';
        this.btnEnviarDatas.disabled = false;
        this.indexaccordion = 3;
        this.indexsteps = 3;
        this.classMicro_4_1 = 'display-block';
        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_PROPOSTA_DATA_4_1) {
          this.msgCard3_2 = 'display-block';
        }
        break;
      }
      case ProgressoMacroEnum.PARECER_5: {
        this.statusProgresso = 'Deliberação da Organização Estadual';
        this.classTab4 = !this.visitaTecnica.processoAlternativo ? 'display-block' : this.classTab4;
        this.classMicro_5_arquivo = 'display-block';
        this.indexaccordion = 4;
        this.indexsteps = 4;

        if (this.parecer.apontamentos) {
          this.classMicro_6_2_2 = 'display-block';

          if (this.keycloakService.isUsuarioNacional) {
            this.flagBtnDeferirPedido = false;
          }

        }
        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1) {
          this.classMicro_5_1 = 'display-block';
        }
        if (obj.progressoMicro === ProgressoMicroEnum.REGISTROS_INDEFERIDOS_OCE_5_2) {
          this.classMicro_5_2 = 'display-block';
          this.classMicro_5_3 = 'display-block';
          this.classMicro_5_4 = 'display-block';
          this.btnArquivarProcessoIndeferido = 'display-block';
        }

        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3) {
          this.classMicro_5_2 = 'display-block';
          this.classMicro_5_3 = 'display-none';
          if ((this.keycloakService.isUsuarioNacional && this.isInProgressoMicro_5_3)
            && !obj.arquivado) {
            this.classMicro_5_3_botoes = 'display-none';
            this.indexaccordion = 6;
            this.indexsteps = 6;
          }
        }
        if (obj.arquivado) {
          this.btnArquivarProcessoIndeferido = 'display-none';
          this.btnDesarquivarProcessoIndeferido = 'display-block';
          this.classMicro_5_4 = 'display-none';
        }
        break;
      }
      case ProgressoMacroEnum.EMISSAO_CERTIFICADO_6: {
        this.statusProgresso = 'Emissão de certificado';
        this.indexsteps = 5;
        if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_EMISSAO_6_1) {
          this.indexaccordion = 5;
          this.classMicro_6_1 = 'display-block';
        }
        if (obj.progressoMicro === ProgressoMicroEnum.EMISSAO_COM_APONTAMENTOS_6_2) {
          this.indexaccordion = 5;
          this.classMicro_6_2 = 'display-block';
        }
        if (obj.progressoMicro === ProgressoMicroEnum.EMITIDO_6_3) {
          this.indexaccordion = 5;
        }
        break;
      }
      default: {
        if (obj.progressoMacroTexto === '0 - Pré Cadastro') {
          this.classTab0 = 'display-block';
          this.indexaccordion = 0;
          this.indexsteps = 0;
          break;
        } else {

          this.indexaccordion = 5;
          this.indexsteps = 5;
        }
      }
    }
    if (!this.validacaoProcessoRegistro.podeVerAcordeonBotaoAnalisar()) {
      this.habilitarOuDesabilitarBtn(this.btnAnalisarCadastro, false)
    }
    if (!this.validacaoProcessoRegistro.podeVerAcordeonBotaoAjustarConformidadeLegal()) {
      this.habilitarOuDesabilitarBtn(this.btnConformidadeLegal, false)
      this.alterarNomeBtn(this.btnConformidadeLegal, 'Visualizar cadastro')
    }
  }



  obtemVisitaTecnica() {
    this.apiVisitaTecnicaService.get(this.objCooperativa.id).then((res) => {
      this.visitaTecnica = res.data;
      if (!this.visitaTecnica) {
        this.visitaTecnica = new VisitaTecnica();
        this.visitaTecnica.pessoaJuridica = this.objCooperativa.pessoaJuridica;
      } else {
        this.atualizaDatas();
      }
      this.visitaTecnicaExiste();
      this.visitaTecnicaParecerEnviado();
    });
  }

  salvarConformidadeLegal() {
    // TODO: verficar this.objCooperativa.progressoMicro = ProgressoMicroEnum.AGUARDANDO_PROPOSTA_DATA_4_1;
    this.dadosGeraisService.salvar(this.objCooperativa).then((res) => {

    });
  }

  enviaDatasVisitaTecnica() {
    const visitasTecnicas = new Array<Date>();
    visitasTecnicas.push(this.visitaTecnica.dataSugerida1);
    visitasTecnicas.push(this.visitaTecnica.dataSugerida2);
    visitasTecnicas.push(this.visitaTecnica.dataSugerida3);
    if (this.validaDatasVisitaTecnica()) {
      this.apiVisitaTecnicaService.inclui(this.visitaTecnica).then((res) => {
        this.visitaTecnica = res.data;
        this.atualizaDatas();
        this.visitaTecnicaExiste();
        this.vtEnviada = true;
        this.classTab4 = 'display-none';
      });
    }
  }

  validaDatasVisitaTecnica(): boolean {
    // Valida preenchimento obrigatório das datas para visita técnica
    if (!this.visitaTecnica.dataSugerida1 || !this.visitaTecnica.dataSugerida2 || !this.visitaTecnica.dataSugerida3) {
      this.messageService.add({
        severity: 'error',
        detail: 'Preencha corretamente as datas da visita técnica.',
        life: 10000
      });
      return false;
    }
    return true;
  }

  private atualizaDatas() {
    const vt = this.visitaTecnica;
    this.visitaTecnica.dataAceitaCooperativa = vt.dataAceitaCooperativa ? new Date(vt.dataAceitaCooperativa) : null;
    this.visitaTecnica.dataSugerida1 = vt.dataSugerida1 ? new Date(vt.dataSugerida1) : null;
    this.visitaTecnica.dataSugerida2 = vt.dataSugerida2 ? new Date(vt.dataSugerida2) : null;
    this.visitaTecnica.dataSugerida3 = vt.dataSugerida3 ? new Date(vt.dataSugerida3) : null;
  }

  alteraVisitaTecnica() {
    this.visitaTecnicaCancelada();
    this.atualizaDatas();
  }

  visitaTecnicaExiste() {
    if (this.objCooperativa.progressoMacro === ProgressoMacroEnum.VISITA_TECNICA_4 && !this.visitaTecnica.processoAlternativo) {
      this.classTab4 = 'display-block';

      if (this.objCooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ACEITE_DATA_VISITA_4_2) {
        this.vtEnviada = true;
        this.classTab4 = 'display-none';
      }
      if (this.objCooperativa.progressoMicro === ProgressoMicroEnum.VISITA_TECNICA_MARCADA_4_3) {
        this.vtMarcada = true;
        this.classTab4 = 'display-none';
      }
      if (!this.visitaTecnica.dataAceitaCooperativa && this.visitaTecnica.observacoes && !this.visitaTecnica.reconsideraSugestao) {
        this.classTab4 = 'display-block';
        this.vtEnviada = false;
        this.dialogoVT = true;
        this.visitaTecnica.reconsideraSugestao = true;
      }
      this.enviarMensagem = true;
    } else {
      this.classTab4 = 'display-none';
      this.vtConcluida = true;
    }


  }

  fecharDialogoVT() {
    this.dialogoVT = false;
  }

  visitaTecnicaParecerEnviado() {
    if (this.visitaTecnica.dataEnvioParecer) {
      setTimeout(() => {
        if (this.fileup) {
          this.fileup.setDesabilita();
        }
      });
    }
  }

  visitaTecnicaCancelada() {
    this.vtEnviada = false;
    this.classTab4 = 'display-block';
    this.btnEnviarDatas.disabled = false;
  }

  alteraSugestoes() {
    this.visitaTecnicaCancelada();
    this.visitaTecnica.reconsideraSugestao = true;
  }

  marcarRealizada() {
    this.btnRealizada = true;
    this.flgMarcarRealizada = true;
  }

  verMensagens() {
    this.mostraMensagemVT = true;
  }

  renovarDatas() {
    this.dataSugerida1 = null;
    this.dataSugerida2 = null;
    this.dataSugerida3 = null;
  }

  marcaComoRealizada(dataAceitaCooperativa) {
    if (this.validaPodeMarcarComoRealizada(dataAceitaCooperativa)) {
      this.vtConcluida = true;
      this.vtMarcada = false;
      this.visitaTecnica.dataEnvioParecer = null;
      this.visitaTecnica.visitaNaoRealizada = false;
    } else {
      this.messageService.add({
        severity: 'error',
        detail: 'Marcar como realizada, somente a partir da data definida para visita',
        life: 10000
      });
    }
  }

  marcaComoNaoRealizada(dataAceitaCooperativa) {
    if (this.validaPodeMarcarComoRealizada(dataAceitaCooperativa)) {
      this.visitaTecnica.parecerVisitaTecnica = false;
      this.visitaTecnica.observacoes = this.txJustificaVisitaNaoRealizada;
      this.visitaTecnica.anexoParecer = null;
      this.visitaTecnica.visitaNaoRealizada = true;
      this.apiVisitaTecnicaService.naoRealizada(this.visitaTecnica).then((res) => {
        this.visitaTecnica = res.data;
        this.objCooperativa.progressoMacro = ProgressoMacroEnum.PARECER_5;
        this.objCooperativa.progressoMicro = ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1;
        this.classMicro_5_botoes = '';
        this.setCooperativa(this.objCooperativa);
        this.flagBtnDeferirPedido = false;
        this.flagBtnIndeferirPedido = false;
        this.modalVisitaNaoRealizada = false;
      });
    } else {
      this.messageService.add({
        severity: 'error',
        detail: 'Marcar como não realizada, somente a partir da data definida para visita',
        life: 10000
      });
    }

  }

  validaPodeMarcarComoRealizada(dataVisita) {
    // this.utilityService.convertStringToDate(dataAceitaCooperativaStr);
    const hoje = new Date();
    // const dataVisita = new Date(dataAceitaCooperativaStr);
    if ((dataVisita > hoje)) {
      return false;
    }
    return true;
  }

  onConcluirUpload(chaveRepositorio) {
    this.visitaTecnica.anexoParecer = chaveRepositorio;
    if (this.objCooperativa.progressoMacro !== ProgressoMacroEnum.VISITA_TECNICA_4) {
      if (this.fileup) {
        this.fileup.setDesabilita();
      }
    }
  }

  confirmaVisitaTecnica(): Promise<boolean> {
    if (!this.visitaTecnica.anexoParecer || !this.visitaTecnica.dataAceitaCooperativa) {
      this.messageService.add({ severity: 'error', detail: 'Anexe o arquivo e selecione a data da visita.', life: 10000 });
      return Promise.resolve(false);
    }
    return this.apiVisitaTecnicaService.anexaParecer(this.visitaTecnica, this.visitaTecnica.anexoParecer).then((resanexaParecer) => {
      this.visitaTecnica = resanexaParecer.data;
      this.visitaTecnica.visitaNaoRealizada = false;
      return this.apiVisitaTecnicaService.enviaParecer(this.visitaTecnica).then((res) => {
        this.visitaTecnica = res.data;
        this.objCooperativa.progressoMacro = ProgressoMacroEnum.PARECER_5;
        this.objCooperativa.progressoMicro = ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1;
        this.classMicro_5_botoes = '';
        this.setCooperativa(this.objCooperativa);
        this.flagBtnDeferirPedido = false; // habilita btn deferir
        this.flagBtnIndeferirPedido = false; // habilita btn indeferir
        return true;
      });
    }).catch(() => false);
  }

  enviarMarcarComoRealizado(dataAceitaCooperativa: Date) {
    if (!this.validaPodeMarcarComoRealizada(dataAceitaCooperativa)) {
      this.messageService.add({
        severity: 'error',
        detail: 'Marcar como realizada, somente a partir da data definida para visita',
        life: 10000
      });
      return;
    }
    this.visitaTecnica.dataAceitaCooperativa = dataAceitaCooperativa;
    this.visitaTecnica.visitaNaoRealizada = false;
    this.confirmaVisitaTecnica().then((sucesso) => {
      if (!sucesso) {
        return;
      }
      this.vtEnviada = true;
      this.classTab4 = 'display-none';
      this.btnRealizada = false;
      this.flgMarcarRealizada = false;
    });
  }

  cancelaVisitaTecnica() {
    this.renovarDatas();
    this.vtMarcada = false;
    this.vtEnviada = false;
    this.apiVisitaTecnicaService.exclui(this.visitaTecnica.id).then((res) => {
      this.visitaTecnica = new VisitaTecnica();
      this.visitaTecnica.pessoaJuridica = this.objCooperativa.pessoaJuridica;
      this.visitaTecnicaCancelada();
    });
  }

  onConcluiruploadDeliberacao(chaveRepositorio: string) {
    this.parecer.arquivoDeliberacao = chaveRepositorio;
    this.classMicro_5_botoes = 'display-block';

    if (this.objCooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1) {
      this.flagBtnIndeferirPedido = false;
      this.flagBtnDeferirPedido = false;
    }
  }

  onConcluiruploadRecursoDeliberacao(chaveRepositorio: string) {
    this.parecer.arquivoRecursoDeliberacao = chaveRepositorio;
    this.btnRecursoDeliberacao.disabled = false;
  }

  onConcluiruploadResultadoRecurso(chaveRepositorio: string) {
    this.parecer.arquivoResultadoRecurso = chaveRepositorio;
    this.classMicro_5_3_botoes = 'display-block';
    this.flagBtnIndeferirRecurso = false;
    this.flagBtnDeferirRecurso = false;
  }

  onUploadEvents(uploadEvent) {
    this.eventListenerFileUpload = uploadEvent;
    if (this.objCooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_DELIBERACAO_5_1) {
      const arquivos = this.eventListenerFileUpload?.arquivos ?? [];
      if (arquivos.length === 0) {
        this.classMicro_5_botoes = 'display-none';
        this.classMicro_5_1_1 = 'display-none';
        this.flagBtnDeferirPedido = true;
        this.flagBtnIndeferirPedido = true;
      } else {
        this.classMicro_5_botoes = 'display-block';
        this.flagBtnIndeferirPedido = false;
        this.flagBtnDeferirPedido = false;
      }
    }
  }

  onUploadEventsRecursoDeliberacao(uploadEvent) {
    this.eventListenerFileUploadRecursoCooperativa = uploadEvent;
    if (this.objCooperativa.progressoMicro === ProgressoMicroEnum.REGISTROS_INDEFERIDOS_OCE_5_2) {
      if (this.eventListenerFileUploadRecursoCooperativa) {
        if (this.eventListenerFileUploadRecursoCooperativa.arquivos.length === 0) {
          this.btnRecursoDeliberacao.disabled = true;
        } else {
          this.btnRecursoDeliberacao.disabled = false;
        }
      }
    }
  }

  onUploadEventsResultadoRecurso(uploadEvent) {
    this.eventListenerFileUploadResultadoRecurso = uploadEvent;
    if (this.objCooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3) {
      if (this.eventListenerFileUploadResultadoRecurso) {
        if (this.eventListenerFileUploadResultadoRecurso.arquivos.length === 0) {
          this.classMicro_5_3_botoes = 'display-none';
          this.flagBtnIndeferirRecurso = true;
          this.flagBtnDeferirRecurso = true;
        } else {
          this.classMicro_5_3_botoes = 'display-block';
          this.flagBtnIndeferirRecurso = false;
          this.flagBtnDeferirRecurso = false;
        }
      }
    }
  }

  salvarDeliberacao(deferido: boolean) {
    if (this.possuiArquivoDeliberacao) {
      this.classMicro_5_3_botoes = 'display-none';
      this.flagBtnIndeferirPedido = true;
      this.flagBtnDeferirPedido = true;
      this.dadosGeraisService.salvarDeliberacao(this.objCooperativa, deferido).then((resp) => {
        this.setCooperativa(resp.data);
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não é possível submeter sem documento de parecer!' });
    }
  }

  setDisplayNone() {
    this.classTab0 = 'display-none';
    this.classTab1 = 'display-none';
    this.classTab2 = 'display-none';
    this.classTab3 = 'display-none';
    this.classTab4 = 'display-none';
    this.classMicro_4_1 = 'display-none';
    this.classMicro_5_1 = 'display-none';
    this.classMicro_5_2 = 'display-none';
    this.classMicro_5_3 = 'display-none';
    this.classMicro_5_4 = 'display-none';
    this.classMicro_5_1_1 = 'display-none';
    this.classMicro_5_arquivo = 'display-none';
    this.classMicro_6_1 = 'display-none';
    this.classMicro_6_1_1 = 'display-none';
    this.classMicro_6_2 = 'display-none';
    this.classMicro_6_2_2 = 'display-none';
    this.msgCard2_1 = 'display-none';
    this.msgCard2_2 = 'display-none';
    this.msgCard2_3 = 'display-none';
    this.msgCard2_4 = 'display-none';
    this.msgCard3_1 = 'display-none';
    this.msgCard3_2 = 'display-none';
    this.msgCard5_1 = 'display-none';
    this.msgCard5_2 = 'display-none';
    this.msgCard6_1 = 'display-none';
    this.msgCardArquivado = 'display-none';

    this.btnArquivarProcesso = 'display-none';
    this.btnDesarquivarProcesso = 'display-none';
    this.btnArquivarProcessoIndeferido = 'display-none';
    this.btnDesarquivarProcessoIndeferido = 'display-none';
    this.btnArquivarProcessoConformidadeLegal = 'display-none';
    this.btnDesarquivarProcessoConformidadeLegal = 'display-none';
  }

  VisualizarJustificativaDeliberacao() {
    this.modalJustificativaDeliberacaoVisivel = true;
  }

  VisualizarApontamento() {
    this.modalApontamentosVisivel = true;
    this.obterHistoricoApontamento();
  }

  salvarApontamento() {
    this.flagBtnDeferirPedido = true;
    const apontamentoTemp = {
      id: null,
      cooperativa: { id: this.objCooperativa.id },
      loginUsuario: null,
      dataApontamento: null,
      apontamento: this.txApontamento
    };

    this.apontamentoService.save(apontamentoTemp).subscribe({
      next: (response) => {
        if (response?.data) {
          this.setCooperativa(response.data.cooperativa);
          this.flagBtnDeferirPedido = false;

          this.txApontamento = null;
          this.classMicro_6_1_1 = 'display-none';
          this.classMicro_5_botoes = 'display-block';

        }
      },
      error: () => {
        this.flagBtnDeferirPedido = false;
      }
    });
  }

  salvarRecursoDeliberacao() {
    if (this.eventListenerFileUploadRecursoCooperativa && this.eventListenerFileUploadRecursoCooperativa.arquivos.length > 0) {
      this.dadosGeraisService.salvarRecursoDeliberacao(this.objCooperativa).then((resp) => {
        this.setCooperativa(resp.data);
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não é possível solicitar recurso sem o documento!' });
    }
  }

  salvarResultadoRecursoDeliberacao() {
    if (this.parecer.arquivoResultadoRecurso) {
      this.dadosGeraisService.salvarResultadoRecursoDeliberacao(this.objCooperativa).then((resp) => {
        this.setCooperativa(resp.data);
        this.flagBtnIndeferirRecurso = true;
        this.flagBtnDeferirRecurso = true;
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não há arquivo carregado para ser salvo!' });
    }
  }

  obterNomePessoaLogada() {
    this.keycloakService.getPessoaJuridica().then((res) => {
      if (res) {
        let tipoUsuario = '';
        if (this.keycloakService.getTipo()) {
          if (this.keycloakService.isUsuarioEstadual) {
            tipoUsuario = 'Estadual - ';
          } else if (this.keycloakService.isUsuarioNacional) {
            tipoUsuario = 'Nacional - ';
          }
        }
        this.nomePessoaJuridica = tipoUsuario + res.nomePessoaJuridica;
      }
    });
  }

  emitirCertifiado() {
    if (this.objCooperativa.arquivado) {
      this.messageService.add({
        severity: 'error',
        detail: 'Não é possível deferir pedido a cooperativa com status "Arquivada"!',
        life: 10000
      });
    } else {
      if (this.keycloakService.isUsuarioNacional) {
        if (this.parecer.arquivoResultadoRecurso) {

          this.dadosGeraisService.salvarResultadoRecursoDeliberacao(this.objCooperativa).then((resp) => {
            this.setCooperativa(resp.data);

            this.dadosGeraisService.emitirCertifiado(this.objCooperativa).then((resp2) => {
              this.setCooperativa(resp2.data);
              this.router.navigate(['/cooperativa/detalhes'], {
                queryParams: { id_cooperativa: this.objCooperativa.id },
                skipLocationChange: false
              });
            });
            this.flagBtnIndeferirRecurso = true;
            this.flagBtnDeferirRecurso = true;
          });
        } else {
          this.dadosGeraisService.emitirCertifiado(this.objCooperativa).then((resp2) => {
            this.setCooperativa(resp2.data);
            this.router.navigate(['/cooperativa/detalhes'], {
              queryParams: { id_cooperativa: this.objCooperativa.id },
              skipLocationChange: false
            });
          });
          this.flagBtnIndeferirRecurso = true;
          this.flagBtnDeferirRecurso = true;
        }
      }


    }
  }

  get hasApontamentos() {
    if (this.keycloakService.isUsuarioNacional && this.parecer.apontamentos) {
      return true;
    } else {
      return false;
    }
  }

  get possuiArquivoDeliberacao(): boolean {
    return (this.eventListenerFileUpload?.arquivos?.length ?? 0) > 0;
  }

  get isInProgressoMicro_5_3() {
    return this.objCooperativa.progressoMicro === ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3 && !this.objCooperativa.arquivado;
  }

  exibirBtnVerHistorico() {
    if ((this.visitaTecnica.observacoes != null && this.visitaTecnica.observacoes.length > 0)
      || (this.visitaTecnica.observacoesPrevisita != null && this.visitaTecnica.observacoesPrevisita.length > 0)
    ) {
      return true;
    }

    return false;
  }

  exibirComentarioCooperativa() {
    if (this.visitaTecnica.observacoes != null && this.visitaTecnica.observacoes.length > 0) {
      return true;
    }

    return false;
  }

  carregarArquivos(idPessoa) {
    this.pessoaDocumentoApi.getDocumentoByIdPessoa(idPessoa).then(response => {
      this.repositorio = response.data;
      const repositorioSorted = this.repositorio.slice().sort((a, b) => new Date(b?.dataRecebimento).getTime() - new Date(a?.dataRecebimento).getTime());
      this.dataUltimoArquivoUpload = repositorioSorted.pop()?.dataRecebimento;
    });
  }

  getDataConformidade(passoRealizado: boolean, dataValidacao: Date) {
    if (passoRealizado && dataValidacao) {
      return dataValidacao;
    } else if (passoRealizado && !dataValidacao) {
      return this.dataUltimoArquivoUpload;
    }
  }

  VisualizarHistoricoApontamentos(): void {
    this.modalHistoricoApontamento = true;
  }

  fechaModalHistoricoApontamento(): void {
    this.modalHistoricoApontamento = false;
  }

  private obterHistoricoApontamento(): void {
    if (this.objCooperativa?.id) {
      this.apontamentoService.obterApontamentosPorCooperativa(this.objCooperativa.id).subscribe(response => {
        if (response?.data) {
          this.historicoApontamentos = response.data;
          if (this.historicoApontamentos && this.historicoApontamentos.length > 0) {
            this.classMicro_6_1_2 = 'display-block';
          }
        }
      });
    }
  }

  listarHistoricoProcessoRegistro() {
    const param = new URLSearchParams(window.location.search);
    let paramIdCooperativa = param.get('id_cooperativa');
    this.apiDadosGeraisService.listarHistoricoProcessoRegistro(paramIdCooperativa).then((resp) => {
      this.historico = resp;
    });
  }

  onTabChange(event: TabViewChangeEvent) {
    const headerSelecionado = (event.originalEvent.target as HTMLElement).innerText;

    if (headerSelecionado.includes('Histórico do Processo')) {
      this.listarHistoricoProcessoRegistro();
    }
  }
}
