import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { ApiApontamentoService } from '@cadastro-registro-api/services/api-apontamento.service';
import { ApontamentoTO } from '@cadastro-registro-api/models/ApontamentoTO';

@Component({
  selector: 'app-modal-historico-apontamento',
  templateUrl: './historico-apontamento.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./historico-apontamento.component.scss']
})
export class HistoricoApontamentoComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() modalHistoricoApontamento: boolean;
  @Output() fechaModal = new EventEmitter();
  @Input() idCooperativa: number;

  modalApontamentoDetalhe = false;
  apontamentoDetalhe = '';
  apontamentos: ApontamentoTO[] = [];
  cols: { field: string, header: string }[] = [
    { field: 'usuario', header: 'Usuario' },
    { field: 'data', header: 'Data do Apontamento' },
    { field: 'apontamento', header: 'Apontamento' },
  ];

  constructor(private apiApontamentoService: ApiApontamentoService) {
  }

  ngOnInit() {
    if (this.idCooperativa) {
      this.apiApontamentoService.obterApontamentosPorCooperativa(this.idCooperativa)
      .subscribe(response => {
        this.apontamentos = response.data;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  carregaDetalheHistorico(idApontamento: number) {
    const txApontamento = this.apontamentos.find(a => a.id === idApontamento).apontamento;
    this.apontamentoDetalhe = txApontamento ? txApontamento : '';
    this.modalApontamentoDetalhe = (this.apontamentoDetalhe !== '');

  }

  encerraModalHistoricoDetalhe() {
    this.modalApontamentoDetalhe = false;
    this.apontamentoDetalhe = '';
  }

  encerraModalHistorico() {
    this.modalHistoricoApontamento = false;
    this.fechaModal.emit();
  }

}
