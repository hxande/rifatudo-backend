import { OnInit, Component, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';

@Component({
    selector:'app-requerimento-registro-concluido',
    templateUrl: './requerimento-registro-concluido.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./requerimento-registro-concluido.component.scss']

})
export class RequerimentoRegistroConcluidoComponent implements OnInit{

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    nomePessoaJuridica: string;
    usuarioCoop = false;
    usuarioNacEst = false;
    constructor(private keycloakService: KeycloakService) { }

    ngOnInit() {
        this.usuarioCoop = this.keycloakService.isUsuarioCooperativa;
        this.usuarioNacEst = this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional;
        this.keycloakService.getPessoaJuridica().then((res) => {
            if(res){
                this.nomePessoaJuridica = res.nomePessoaJuridica;
                this.changeDetectorRef.markForCheck();
            }
        });

    }

}
