import { OnInit, Component } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { DocumentoTO } from '@documentacao-api/models/DocumentoTO';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';



@Component({
  selector: 'app-requerimento-registro',
  templateUrl: './requerimento-registro.component.html',
  styleUrls: ['./requerimento-registro.component.scss']

})
export class RequerimentoRegistroComponent implements OnInit {

  cooperativa = new Cooperativa();
  pessoaJuridica = new PessoaJuridica();
  documentacao: DocumentoTO[] = [];
  constructor(
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private keycloakService: KeycloakService,
    private apiPj: ApiPessoaJuridicaService
  ) { }
  ngOnInit() {

    this.documentacao = [
      { descricao: 'Requerimento dirigido ao Presidente...', detalhamentoDocumento: '' },
      { descricao: 'Cartão do Cadastro Nacional...', detalhamentoDocumento: '' },
      { descricao: 'Estatuto Social Vigente...', detalhamentoDocumento: '' },
      { descricao: 'Ata da assembleia de constituição...', detalhamentoDocumento: '' },
      { descricao: 'Ata da assembleia que elegeu...', detalhamentoDocumento: '' },
      { descricao: 'Outros documentos eventualmente...', detalhamentoDocumento: '' },
      { descricao: 'Para as pessoas jurídicas...', detalhamentoDocumento: '' },
      { descricao: 'Atas das Assembleias Gerais...', detalhamentoDocumento: '' },
      { descricao: 'As demonstrações financeiras...', detalhamentoDocumento: '' }
    ];

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.cooperativa = coop;
        this.apiPj.buscaUnidadeResponsavel(this.cooperativa.pessoaJuridica.ufSigla).then(pj => {
          this.pessoaJuridica = pj.data;
        });
      }
    });
  }

  notificarOE(){
    if(this.cooperativa){
      this.apiCadastroRegistroService.notificarOE(this.cooperativa.id).subscribe(res => {

      });
    }
  }

}
