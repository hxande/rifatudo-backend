import { ChangeDetectorRef, Component, OnInit, ViewChild, Output, EventEmitter, Input, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { DocumentacaoVO } from '@documentacao-api/models/DocumentacaoVO';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { Municipio } from '@localizacao-api/models/Municipio';
import { Uf } from '@localizacao-api/models/Uf';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';

@Component({
    selector: 'app-documento-filial-component',
    templateUrl: './documento-filial.component.html',
    styleUrls: ['./documento-filial.component.css']
  })
  export class DocumentoFilialComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    filiada: PessoaJuridicaBasicaTO;
    documentacaoVO: DocumentacaoVO = null;

    @Input() filial: PessoaJuridicaBasicaTO;
    @Input() idMatriz: number;
    @Input() podeModificarOsCampos:boolean;
    @ViewChild('documentoFilialForm') documentoFilialForm: NgForm;
    @Output() adicionarFilial = new EventEmitter<PessoaJuridicaBasicaTO>();
    @Output() cancelarDocFilial = new EventEmitter<number>();
    @Output() erroSalvar= new EventEmitter<boolean>();

    ngOnInit(){
        this.carregaTela();
    }

    constructor(private apiDocumentoService: ApiDocumentoService,
        private uploadApi: ApiFileUploadService) { }

    carregaTela(){
        this.inicializaFilial();
    }

    inicializaFilial(){
        this.filiada = new PessoaJuridicaBasicaTO();
        this.filiada.ramo = new Ramo;
        this.filiada.endereco = new Endereco();
        this.filiada.endereco.uf = new Uf();
        this.filiada.endereco.municipio = new Municipio();
        this.documentacaoVO = null;
    }

    anexarDocumento(filial: PessoaJuridicaBasicaTO){

        if(filial.id){
            this.preenchePessoaJuridica(filial);
            this.apiDocumentoService.listaAtivosFilial(true, TipoPessoaEnum.PJ).then(responsePage => {
                    this.apiDocumentoService.getDocumentacaoFilial(filial.id).then((res) => {

                        if (res && res.data != null) {
                          this.documentacaoVO = res.data;
                        }
                        this.changeDetectorRef.markForCheck();
                      });
                    this.changeDetectorRef.markForCheck();
            });
        }
    }

    preenchePessoaJuridica(pessoaJuridica: PessoaJuridicaBasicaTO){
        this.filiada.id = pessoaJuridica.id;
        this.filiada.cnpj = pessoaJuridica.cnpj;
        this.filiada.cnpjValidado = true;
        this.filiada.email = pessoaJuridica.email;
        this.filiada.nomeFantasia = pessoaJuridica.nomeFantasia;
        this.filiada.ramo = pessoaJuridica.ramo;
        this.filiada.razaoSocial = pessoaJuridica.razaoSocial;
        this.filiada.telefone = pessoaJuridica.telefone;
        this.filiada.ufSigla = pessoaJuridica.ufSigla;
        this.filiada.tipoPessoa = pessoaJuridica.tipoPessoa;

        if(pessoaJuridica.endereco){
            this.filiada.endereco = pessoaJuridica.endereco;
        }

      }

      onConcluirUpload(chaveRepositorio: string) {
        const repositorios: string[] = [];
        repositorios.push(chaveRepositorio);

        this.uploadApi.consultaArquivosNaoPaginado(repositorios).then(responseDocumento =>{
            this.filiada.arquivos = responseDocumento.content;
            this.changeDetectorRef.markForCheck();
          });
      }

      salvaDocumentoFilial(){

        if(this.documentacaoVO){
          this.documentacaoVO.idPessoaMatriz = this.idMatriz;
          this.apiDocumentoService.salvarDocumentacao(this.documentacaoVO).then((res) => {
            this.adicionarFilial.emit(this.filiada);
            this.inicializaFilial();
            this.documentoFilialForm.reset();
            this.cancelarDocFilial.emit();
            this.changeDetectorRef.markForCheck();
          }).catch(() => {
                  this.erroSalvar.emit(true);
                  this.changeDetectorRef.markForCheck();
          });
        }


      }

      cancelarDocumentoFilial(){
        this.documentoFilialForm.reset();
        this.inicializaFilial();
        this.cancelarDocFilial.emit();
    }

  }
