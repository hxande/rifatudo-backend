import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { RedeSocial } from '@cadastro-registro-api/models/RedeSocial';
import { TipoRedeSocial } from '@cadastro-registro-api/models/TipoRedeSocial';
import { SelectItem } from 'primeng/api';

@Component({
    selector: 'app-rede-social-component',
    templateUrl: './rede-social.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls:['./rede-social.component.css']
  })
  export class RedeSocialComponent implements OnInit , OnChanges{

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() redesSociais: RedeSocial[] = [];
    @Input() desabilitado = false;

    tiposRedesSociais: SelectItem[] = new TipoRedeSocial().tipoRedesSociais;

    ngOnInit(): void {

    }

    ngOnChanges(changes: SimpleChanges): void {
      if(!changes.desabilitado.currentValue && this.redesSociais.length === 0){
        this.adicionarRedeSocial();
      }
    }

    adicionarRedeSocial(){
        const rs = new RedeSocial()
        this.redesSociais = [
          ...this.redesSociais,
          rs
        ];
    }

    removeRedeSocial(redeSocial: RedeSocial){
      var index = this.redesSociais.indexOf(redeSocial);
      if (index !== -1) {
        this.redesSociais = this.redesSociais.filter((_, i) => i !== index);
      }
    }

  }
