import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { RelatorioGraficoService } from '@relatorio-api/services/relatorio-grafico.service';
import { PowerBICooperativasRegistradasEmbededToken } from '@relatorio-api/models/PowerBICooperativasRegistradasEmbededToken';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-cooperativas-registradas',
  templateUrl: './cooperativas-registradas.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./cooperativas-registradas.component.css']
})
export class CooperativasRegistradasComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  powerBICooperativasRegistradasEmbededToken: PowerBICooperativasRegistradasEmbededToken;
  paineis: PowerBICooperativasRegistradasEmbededToken[];

  constructor(
    public keycloakService: KeycloakService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private relatorioGraficoService: RelatorioGraficoService,
  ) {
    this.powerBICooperativasRegistradasEmbededToken = new PowerBICooperativasRegistradasEmbededToken();
    this.breadCrumbPrimeNGService.setItems([
      {label: 'Relatório/', routerLink: 'inicio'},
      {label: 'Cooperativas Registradas'},
    ]);
  }

  ngOnInit() {
    this.carregaPainelBI();
  }

  private carregaPainelBI() {
    this.relatorioGraficoService.obterPaineisPorServico('SOUCOOP_PAINEL_INICIAL', null)
    .then(response => {
      if (response) {
        this.paineis = response;
      }

      if (this.paineis) {
        this.carregarPainel(this.paineis[0]);
      }

      this.changeDetectorRef.markForCheck();
    });
  }

  private carregarPainel(painel: PowerBICooperativasRegistradasEmbededToken) {
    if (painel) {
      this.relatorioGraficoService.carregarPainel(painel.id, this.paineis.length > 1)
      .then(response => {
        if (response) {
          this.powerBICooperativasRegistradasEmbededToken = response;
        }
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.powerBICooperativasRegistradasEmbededToken = null;
    }
  }

}
