import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RelatorioRoutingModule } from './relatorio-routing.module';
import { CalendarModule } from 'primeng/calendar';
import {CooperativasRegistradasComponent} from './cooperativas-registradas/cooperativas-registradas.component';

// import {NgxPowerBiModule} from 'ngx-powerbi';
import {CardModule} from 'primeng/card';
import { RelatoriosGerenciaisComponent } from './relatorios-gerenciais/relatorios-gerenciais.component';
import { RadioButtonModule } from 'primeng/radiobutton';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { ButtonModule } from 'primeng/button';
import { TabViewModule } from 'primeng/tabview';
import { TableModule } from 'primeng/table';

@NgModule({
  declarations: [
    CooperativasRegistradasComponent,
    RelatoriosGerenciaisComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    RelatorioRoutingModule,
    // NgxPowerBiModule,
    CardModule,
    RadioButtonModule,
    DropdownModule,
    MultiSelectModule,
    ButtonModule,
    TabViewModule,
    TableModule,
    CalendarModule
  ]
})
export class RelatorioModule { }
