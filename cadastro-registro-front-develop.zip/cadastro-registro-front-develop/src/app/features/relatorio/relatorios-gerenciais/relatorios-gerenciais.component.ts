import { HttpParams } from '@angular/common/http';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { ApiPeriodoAtualizacaoService } from '@cadastro-registro-api/services/api-periodo-atualizacao.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { SITUACOES_OPTS } from '@shared/constants/situacoes.constant';
import { MessageService, SelectItem } from 'primeng/api';
import { saveAs } from 'file-saver';
import { ApiCooperativaLeituraService } from '@cadastro-registro-leitura-api/services/api-cooperativa-leitura.service';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiRelatorioService } from 'src/app/api/services/api-relatorio-service';
import { RelatorioAbaColunas } from 'src/app/api/models/RelatorioAbaColunasTO';
import { ApiHistoricoProcessoRegistroService } from 'src/app/api/services/api-historico-processo-registro.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { formatDate } from '@angular/common';
import { Ramo } from 'src/app/api/models/Ramo';
import { firstValueFrom } from 'rxjs';

interface RelatorioOption {
    label: string;
    value?: number;
    relatorio?: string;
    arquivo?: string;
}

@Component({
    selector: 'app-relatorios-gerenciais',
    templateUrl: './relatorios-gerenciais.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./relatorios-gerenciais.component.css']
})
export class RelatoriosGerenciaisComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    listaTipoRelatorio: RelatorioOption[];
    listaSubtipoRelatorio: RelatorioOption[];
    listaCategoria: SelectItem[];
    listaUf: SelectItem[];
    listaRamo: SelectItem[];
    listaAno: SelectItem[];
    listaSituacao = SITUACOES_OPTS;
    listaSolicitacaoOE: SelectItem[];

    colunasPrevias: RelatorioAbaColunas[] = [];

    filtroTipoRelatorio: RelatorioOption;

    filtroSubtipoRelatorio: RelatorioOption;
    filtroSituacao: string[];
    filtroUf: string[];
    filtroRamos: Ramo[];
    filtroRamo: Ramo;
    filtroCategoria: number[];
    filtroCiclo: number;
    filtroCiclos: number[];
    filtroAno: number;
    filtroSolicitacoesOE = [];

    anoReferencia = (new Date().getFullYear() - 1).toString();

    obrigatoriedadeRamo: boolean;

    filtroDataInicio: string;
    filtroDataFim: string;
    filtroStatusProcesso: string[];
    listaStatusProcesso: SelectItem[] = [
        { label: 'Em andamento', value: 'EM_ANDAMENTO' },
        { label: 'Finalizados', value: 'FINALIZADO' }
    ];



    constructor(public breadCrumbPrimeNGService: BreadcrumbService,
        public keycloakService: KeycloakService,
        private ramoApi: ApiRamoService,
        private periodoService: ApiPeriodoAtualizacaoService,
        private dadosGeraisService: ApiManutencaoDadosGeraisService,
        private cooperativaLeituraService: ApiCooperativaLeituraService,
        private relatorioService: ApiRelatorioService,
        private utilityService: UtilityService,
        private historicoProcessoService: ApiHistoricoProcessoRegistroService,
        public language: LanguageService,
     private messageService: MessageService,) {

        this.breadCrumbPrimeNGService.setItems([
            { label: 'Início', routerLink: 'inicio' },
            { label: 'Relatórios', routerLink: '/relatorio/relatorios-gerenciais' }
        ]);
    }

    ngOnInit(): void {
        this.carregarListaTipoRelatorio();
        this.carregarListaSubtipoRelatorio();
        this.carregarListaUf();
        this.carregarListaRamo();
        this.carregarListaAno();
        this.carregarListaCategoria();
        this.carregarListaTipoSolicitacao();
    }
    carregarListaTipoSolicitacao() {
        this.listaSolicitacaoOE = [
            { label: 'Suspensão', value: 'solicitacaoInativacao' },
            { label: 'Regularização', value: 'solicitacaoAtivacao' },
            { label: 'Cancelamento', value: 'solicitacaoCancelamento' },
            { label: 'Não visualizadas', value: 'naoVisualizada' },
        ];
    }
    carregarListaCategoria() {
        this.listaCategoria = [];
        this.dadosGeraisService.getCategorias().then(response => {
            if (response && response.data) {
                this.listaCategoria = response.data
                    .filter(grau => grau.id != 1)
                    .map(grau => ({ label: grau.descricao, value: grau.id }));
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    carregarListaTipoRelatorio() {
        this.listaTipoRelatorio = [
            { label: 'Cadastro', value: 1 },
            { label: 'Governança', value: 2, relatorio: 'GOVERNANCA', arquivo: 'Cooperativas_Registradas_Governanca.xlsx' },
            { label: 'Anuário', value: 4 },
            { label: 'Filiação por Grau', value: 5, relatorio: 'FILIACAO_GRAU', arquivo: 'Cooperativas_Registradas_Filiacao_Grau.xlsx' },
            { label: 'Histórico da situação de registro', value: 6, relatorio: 'HISTORICO_SITUACAO_REGISTRO', arquivo: 'Historico_Situacao_Registro.xlsx' },
            { label: 'Solicitações das Organizações Estaduais', value: 7, relatorio: 'SOLICITACAO', arquivo: 'Solicitações_Suspensão_Cancelamento_regularização.xlsx' }
        ];
        this.filtroTipoRelatorio = this.listaTipoRelatorio[0];
    }

    carregarListaAno() {
        this.listaAno = [];
        const options = {
            params: new HttpParams()
                .set('page', '0')
                .set('size', '10')
                .set('sort', 'ano,desc')
        };
        this.periodoService.buscaTodosAnos(options).then(response => {
            if (response && response.data) {
                this.listaAno = response.data.content.map(ano => ({
                    value: ano,
                    label: 'Ciclo ' + ano + ' (Ano de referência ' + (ano - 1) + ')'
                }));
            }
            this.changeDetectorRef.markForCheck();
        });
    }
    carregarListaRamo() {
        this.listaRamo = [];
        this.ramoApi.getRamos().then(response => {
            if (response && response.data) {
                this.listaRamo = response.data.map(r => ({ label: r.nome, value: r }));
            }
            this.changeDetectorRef.markForCheck();
        });
    }
    carregarListaUf() {
        this.listaUf = [];
        this.dadosGeraisService.buscarUfs().then((res) => {
            if (res && res.content != null) {
                this.listaUf = res.content.map(uf => ({ label: uf.sigla, value: uf.sigla }));

                if (this.keycloakService.isUsuarioEstadual) {
                    this.filtroUf = [this.keycloakService.getUF()];
                }
            }
            this.changeDetectorRef.markForCheck();
        });
    }
    carregarListaSubtipoRelatorio() {
        switch (this.filtroTipoRelatorio.value) {
            case 1:
                this.listaSubtipoRelatorio = [
                    { label: 'Dados Gerais', relatorio: 'DADOS_GERAIS', arquivo: 'Cooperativas_registradas_dadosgerais.xlsx' },
                    { label: 'Segmentos', relatorio: 'NEGOCIO', arquivo: 'Cooperativas_Registradas_Negocio.xlsx' },
                    { label: 'Contatos', relatorio: 'CONTATOS', arquivo: 'Cooperativas_Registradas_Contato.xlsx' },
                    { label: 'Status do Cadastro', relatorio: 'REGISTRADAS', arquivo: 'Cooperativas_registradas.xlsx' },
                    { label: 'Histórico do Processo de Registro', relatorio: 'HISTORICO_PROCESSO_REGISTRO', arquivo: 'Historico_Processo_Registro.xlsx' },
                    { label: 'Filiação Sindical', relatorio: 'FILIACAO_SINDICAL', arquivo: 'Filiacao_Sindical.xlsx' }
                ];
                break;
            case 4:
                this.listaSubtipoRelatorio = [
                    { label: 'Anuário completo', relatorio: 'ANUARIO_DADOS_FINANCEIROS_COMPLEMENTARES', arquivo: 'Anuário_completo.xlsx' },
                    { label: 'Anuário completo vertical', relatorio: 'ANUARIO_VERTICAL', arquivo: 'Anuário_completo_vertical.xlsx' },
                    { label: 'Dados contábeis e tributário', relatorio: 'ANUARIO_DADOS_FINANCEIROS_GERENCIAIS', arquivo: 'Dados_contábeis_e_tributário.xlsx' },
                    { label: 'Intercooperação anuário', relatorio: 'ANUARIO_INTERCOOPERACAO_GERENCIAIS', arquivo: 'Intercooperação_anuário.xlsx' },
                    { label: 'Negócio anuário', relatorio: 'ANUARIO_NEGOCIO_GERENCIAIS', arquivo: 'Negócio_anuário.xlsx' },
                    { label: 'Status do Anuário', relatorio: 'ANUARIO_DADOS_FINANCEIROS_COMPLEMENTARES_SIMPLIFICADO', arquivo: 'Anuario_Ciclo_Corrente_Simplificado.xlsx' },
                    { label: 'Anuário - Série histórica', relatorio: 'ANUARIO_SERIE_HISTORICA', arquivo: 'Anuario_Serie_historica.xlsx' },
                    { label: 'Quadro Social por UF', relatorio: 'DADOS_SOCIAIS_ANUARIO_POR_UF', arquivo: 'Quadro_Social_por_UF.xlsx' }
                ];
                if (this.filtroSubtipoRelatorio) {
                    this.obrigatoriedadeRamo = this.filtroSubtipoRelatorio.relatorio == 'ANUARIO_DADOS_FINANCEIROS_COMPLEMENTARES'
                        || this.filtroSubtipoRelatorio.relatorio == 'ANUARIO_NEGOCIO_GERENCIAIS';
                }
                break;
        }

    }

    visualizarCicloMultiplos(tipo: number, relatorio: string) {
        return tipo == 4 && relatorio == 'ANUARIO_SERIE_HISTORICA';
    }

    visualizarColunasDoRelatorio() {
        this.limparPrevisaDeColunas();
        const exportar = this.filtroTipoRelatorio.relatorio ? this.filtroTipoRelatorio : this.filtroSubtipoRelatorio;
        this.relatorioService.listarColunasRelatorio(exportar.relatorio, this.montarOptionsExportacao())
        .then(response => {
            this.colunasPrevias = response;
            this.changeDetectorRef.markForCheck();
        });
    }

    resetaTipoInformacao() {
        this.filtroRamos = [];
        this.filtroSolicitacoesOE = [];
        this.filtroSubtipoRelatorio = null;
        this.filtroAno = null;
        this.filtroDataInicio = null;
        this.filtroDataFim = null;
        this.filtroStatusProcesso = [];
        this.verificaCiclosPorTipoRelatorio();
        this.limparPrevisaDeColunas();
    }

    limparPrevisaDeColunas() {
        this.colunasPrevias = [];
    }

    verificaCiclosPorTipoRelatorio() {
        switch (this.filtroTipoRelatorio.value) {
            case 4:
                this.listaAno.forEach(ano => {
                    if (ano.value < 2023) {
                        ano.disabled = true;
                    }
                });
                break;
            default:
                this.listaAno.forEach(ano => ano.disabled = false);
                break;
        }
    }

    exportarRelatorio(): void {
        if (this.filtroSubtipoRelatorio?.relatorio === 'HISTORICO_PROCESSO_REGISTRO') {
            this.exportarRelatorioHistoricoProcesso();
            return;
        }
        const exportar = this.filtroTipoRelatorio.relatorio
          ? this.filtroTipoRelatorio
          : this.filtroSubtipoRelatorio;

        this.cooperativaLeituraService
          .buscarRelatorioArrayBuffer(exportar.relatorio, this.montarOptionsExportacao())
          .subscribe({
            next: (response) => this.realizarDownloadRelatorio(exportar.arquivo, response),
            complete: () => {
              this.changeDetectorRef.markForCheck();
            }
          });
      }


    private exportarRelatorioHistoricoProcesso(): void {
        const uf = typeof this.filtroUf === 'string'
            ? this.filtroUf
            : (this.filtroUf && this.filtroUf.length > 0 ? this.filtroUf[0] : this.keycloakService.getUF());

        firstValueFrom(this.historicoProcessoService.gerarRelatorio(
            uf,
            formatDate(this.filtroDataInicio, 'yyyy-MM-dd', 'pt-BR') || null,
            formatDate(this.filtroDataFim, 'yyyy-MM-dd', 'pt-BR') || null,
            this.filtroStatusProcesso && this.filtroStatusProcesso.length > 0 ? this.filtroStatusProcesso : null
        )).then(response => {
            this.realizarDownloadRelatorio('Historico_Processo_Registro_' + uf + '.xlsx', response);
            this.changeDetectorRef.markForCheck();
        });
    }

    private realizarDownloadRelatorio(nomeRelatorio: string, dados): void {
        const blob = new Blob([dados], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(blob, nomeRelatorio);
    }

    private montarOptionsExportacao() {
        const options = {
            params: new HttpParams()
        };
        if (this.filtroTipoRelatorio.value == 4) {
            this.filtroRamos = [this.filtroRamo];
            options.params = this.utilityService.carregaParamsString(this.filtroRamo ? this.filtroRamos.map(r => r.id) : '', options.params, 'ramos');
        } else {
            options.params = this.utilityService.carregaParamsString(this.filtroRamos ? this.filtroRamos.map(r => r.id) : '', options.params, 'ramos');
        }

        options.params = this.utilityService.carregaParamsString(this.filtroUf ? this.filtroUf : '', options.params, 'ufs');
        if (this.filtroSituacao?.length > 0) {
            options.params = this.utilityService.carregaParamsString(this.filtroSituacao, options.params, 'situacaoCooperativa');
        }

        if (this.filtroCategoria?.length > 0) {
            options.params = this.utilityService.carregaParamsString(this.filtroCategoria, options.params, 'graus');
        }

        if (this.filtroSolicitacoesOE?.length > 0) {
            this.filtroSolicitacoesOE.forEach(sol => {
                options.params = this.utilityService.carregaParamsString(true, options.params, sol);
            });
        }

        if ((this.filtroTipoRelatorio.value == 1 && this.filtroSubtipoRelatorio.relatorio == 'REGISTRADAS')
            || (this.filtroTipoRelatorio.value == 4 && this.filtroSubtipoRelatorio.relatorio == 'ANUARIO_DADOS_FINANCEIROS_COMPLEMENTARES_SIMPLIFICADO')) {
            options.params = this.utilityService.carregaParamsString(this.anoReferencia, options.params, 'anoReferencia');
        } if ((this.filtroTipoRelatorio.value == 4 && this.filtroSubtipoRelatorio.relatorio == 'ANUARIO_SERIE_HISTORICA')) {
            options.params = this.utilityService.carregaParamsString(this.filtroCiclos ? this.filtroCiclos : null, options.params, 'anosDeReferencia');
        } else {
            options.params = this.utilityService.carregaParamsString(this.filtroAno ? this.filtroAno : null, options.params, 'anoReferencia');
        }

        return options;
    }
}
