import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { RelatorioGraficoService } from '@relatorio-api/services/relatorio-grafico.service';
import { PowerBICooperativasRegistradasEmbededToken } from '@relatorio-api/models/PowerBICooperativasRegistradasEmbededToken';
import {BreadcrumbService} from "@core/breadcrumb/breadcrumb.service";

@Component({
  selector: 'app-painel-anuario',
  templateUrl: './painel-anuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['../cooperativas-registradas/cooperativas-registradas.component.css']
})
export class PainelAnuarioComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  powerBICooperativasRegistradasEmbededToken: PowerBICooperativasRegistradasEmbededToken;
  paineis: PowerBICooperativasRegistradasEmbededToken[];

  constructor(
    private breadCrumbPrimeNGService: BreadcrumbService,
    public keycloakService: KeycloakService,
    private relatorioGraficoService: RelatorioGraficoService,
  ) {
    this.powerBICooperativasRegistradasEmbededToken = new PowerBICooperativasRegistradasEmbededToken();
  }

  ngOnInit() {
    this.breadCrumbPrimeNGService.setItems([]);
    this.carregaPainelBI();
  }

  private carregaPainelBI() {
    this.relatorioGraficoService.obterPaineisPorServico('SOUCOOP_PAINEL_ANUARIO', null)
    .then(response => {
      if (response) {
        this.paineis = response;
      }

      if (this.paineis) {
        this.carregarPainel(this.paineis[0]);
      }

      this.changeDetectorRef.markForCheck();
    });
  }

  private carregarPainel(painel: PowerBICooperativasRegistradasEmbededToken) {
    if (painel) {
      this.relatorioGraficoService.carregarPainel(painel.id, this.paineis.length > 1)
      .then(response => {
        if (response) {
          this.powerBICooperativasRegistradasEmbededToken = response;
        }
        this.changeDetectorRef.markForCheck();
      });
    } else {
      this.powerBICooperativasRegistradasEmbededToken = null;
    }
  }

}
