import { ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SolicitacaoMudancaEnderecoTO } from '@cadastro-registro-api/models/SolicitacaoMudancaEnderecoTO';
import { SolicitacaoMudancaoEndereco } from '@cadastro-registro-api/models/SolicitacaoMudancaoEndereco';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { ApiMudancaUFService } from '@cadastro-registro-api/services/api-mudanca-uf.service';



@Component({
    selector: 'app-mantem-solicitacao-transferencia',
    templateUrl: './mantem-solicitacao-transferencia.component.html',
    styleUrls: ['./mantem-solicitacao-transferencia.component.css']
})
export class MantemSolicitacaoTransferenciaComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    @Input() solicitacaoMudancaEndereco: SolicitacaoMudancaEnderecoTO;

    @Output() atualizaSolicitacao = new EventEmitter<void>();

    idxEnderecoPrincipal: number;

    modalReprovarMudancaUF = false;

    salvando = false;

    constructor(private apiMudancaService: ApiMudancaUFService,
        private dadosGeraisService: ApiManutencaoDadosGeraisService,
        public kcService: KeycloakService){

    }

    ngOnInit(): void {
        this.carregaMunicipioEUF();
        this.modalReprovarMudancaUF = false;
        this.idxEnderecoPrincipal = this.solicitacaoMudancaEndereco.listaEnderecoHistoricoTO.findIndex(eh => eh.tipoEndereco.enderecoPrincipal);
    }
    carregaMunicipioEUF() {
        this.solicitacaoMudancaEndereco.listaEnderecoHistoricoTO.forEach((end) => {
            if (end.idMunicipio) {
              this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio)
              .then((resEnd) => {
                end.municipio = resEnd;

                // Adicionando UF
                if (end.municipio != null && end.municipio.id) {
                  end.uf = end.municipio.uf;

                }

                this.changeDetectorRef.markForCheck();
              });
            }

            if(end.tipoEndereco.enderecoPrincipal) {

            }
          });

    }

    atualizarSolicitacao(){
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        this.apiMudancaService.atualizaSolicitacaoMudancaEndereco(this.solicitacaoMudancaEndereco)
        .subscribe({
            next: res => {
                this.atualizaSolicitacao.emit();
            },
            complete: () => {
                this.salvando = false;
                this.changeDetectorRef.markForCheck();
            }
        });
    }

    aprovarSolicitacao(){
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        this.apiMudancaService.aprovaSolicitacaoMudancaEndereco(this.solicitacaoMudancaEndereco)
        .subscribe({
            next: res => {
                this.atualizaSolicitacao.emit();
            },
            complete: () => {
                this.salvando = false;
                this.changeDetectorRef.markForCheck();
            }
        });
    }

    reprovarSolicitacao(){
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        const sme = new SolicitacaoMudancaoEndereco();
        sme.justificativaReprovacao = this.solicitacaoMudancaEndereco.justificativaReprovacao;
        this.apiMudancaService.reprovaSolicitacao(this.solicitacaoMudancaEndereco.pessoa.id,sme)
        .then((res) => {
            this.atualizaSolicitacao.emit();
        })
        .finally(() => {
            this.salvando = false;
            this.changeDetectorRef.markForCheck();
        });
    }

    cancelarSolicitacao(){
        if (this.salvando) {
            return;
        }
        this.salvando = true;
        this.apiMudancaService.cancelaSolicitacao(this.solicitacaoMudancaEndereco.pessoa.id,new SolicitacaoMudancaoEndereco())
        .then((res) => {
            this.atualizaSolicitacao.emit();
        })
        .finally(() => {
            this.salvando = false;
            this.changeDetectorRef.markForCheck();
        });
    }

    alteraEnderecoCorrespondencia(event){
        this.solicitacaoMudancaEndereco.listaEnderecoHistoricoTO.forEach(eh => eh.correspondenciaDiferente = event);
    }

}
