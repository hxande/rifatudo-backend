import { AuthGuardService } from '@auth/auth-guard/auth-guard.service';
import { ListagemSolicitacaoTransferenciaComponent } from './listagem-solicitacao-transferencia/listagem-solicitacao-transferencia.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


const routes: Routes = [
    { path: '', component: ListagemSolicitacaoTransferenciaComponent, canActivate: [AuthGuardService] },
  ];
  
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
  })
  export class TransferenciaUfRoutingModule {}
  