import { HttpParams } from '@angular/common/http';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SolicitacaoMudancaEnderecoTO } from '@cadastro-registro-api/models/SolicitacaoMudancaEnderecoTO';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { ApiMudancaUFService } from '@cadastro-registro-api/services/api-mudanca-uf.service';
import { ApiRamoService } from '@cadastro-registro-api/services/api-ramo.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { IPage } from '@utils/interfaces/IPage';
import { UtilityService } from '@utils/utility/utility.service';
import { Table, TableLazyLoadEvent } from 'primeng/table';
import { Ramo } from 'src/app/api/models/Ramo';

@Component({
    selector: 'app-listagem-solicitacao-transferencia',
    templateUrl: './listagem-solicitacao-transferencia.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./listagem-solicitacao-transferencia.component.css']
})
export class ListagemSolicitacaoTransferenciaComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    private debouncer;
    private delay = 500;
    nrLinhasTabela = 10;
    carregando: boolean;

    ufsOpts: { label: string; value: string }[] = [];
    ramosOpts: { label: string; value: Ramo }[] = [];
    situacoesOpts: { label: string; value: string }[] = [];

    filtroRamo: Ramo[] = [];
    filtroSituacao: string[] = [];
    filtroUf: string[];
    filtroCnpj: string;
    filtroNomeFantasia: string;

    idPessoaSelecionada: number;
    solicitacaoMudancaEnderecoSelecionada: SolicitacaoMudancaEnderecoTO;
    modalMudancaUF = false;
    podeAprovar = false;

    solicitacoes: IPage<SolicitacaoMudancaEnderecoTO>;

    @ViewChild('dt') dt: Table;

    constructor(private apiMudancaService: ApiMudancaUFService,
        private apiRamoService: ApiRamoService,
        private apiDadosGeraisService: ApiManutencaoDadosGeraisService,
        private breadCrumbPrimeNGService: BreadcrumbService,
        public kcService: KeycloakService,
        private utilityService: UtilityService,
        public router: Router,
        private apiCooperativaService: ApiCooperativaService) {

        this.breadCrumbPrimeNGService.setItems([
            { label: 'Início', routerLink: '/inicio' },
            { label: 'Transferência de UF', routerLink: '/transferencia-uf/listagem' },
        ]);

    }

    ngOnInit(): void {
        this.buscarUF();
        this.buscarRamos();
        this.buscarSituacoes();
    }
    buscarSituacoes() {
        this.situacoesOpts = [
            { label: 'Aprovada', value: 'APROVADA' },
            { label: 'Reprovada', value: 'REPROVADA' },
            { label: 'Aguardando Parecer', value: 'AGUARDANDO_PARECER' },
            { label: 'Cancelada', value: 'CANCELADA'}
        ]
    }

    buscarRamos() {
        this.apiRamoService.getRamos().then(response => {
            if (response && response.data) {
                this.ramosOpts = response.data.map(r => ({ label: r.nome, value: r }));
                this.changeDetectorRef.markForCheck();
            }
        })
            .catch(e => console.error('error => ', e));
    }

    buscarUF() {
        if (this.ufsOpts.length === 0) {
            this.apiDadosGeraisService.buscarUfs().then((res) => {
                if (res && res.content != null) {
                    this.ufsOpts = res.content.map(uf => ({ label: uf.sigla, value: uf.sigla }));
                    this.changeDetectorRef.markForCheck();
                }
            })
                .catch(e => console.error('error => ', e));
        }
    }

    getSolicitacoes(pagina = 0, sortField, sortOrder = -1) {
        sortField = sortField || 'pj.nomeFantasia';
        let sort: string;
        sort = sortOrder === 1 ? 'desc' : 'asc';
        const options = this.carregaOptions(pagina.toString(), this.nrLinhasTabela.toString(), sortField, sort);
        return this.apiMudancaService.obterSolicitacoes(options);
    }

    carregaSolicitacoes(event: TableLazyLoadEvent) {
        this.carregando = true;

        if (event.rows !== undefined) {
            this.nrLinhasTabela = event.rows;
        }
        this.solicitacoes = undefined;

        this.getSolicitacoes(event.first / event.rows, Array.isArray(event.sortField) ? event.sortField[0] : event.sortField, event.sortOrder)
        .subscribe(response => {
            this.carregando = false;
            this.solicitacoes = response.data;
            this.changeDetectorRef.markForCheck();
        });

    }

    carregaOptions(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
        const options = {
            params: new HttpParams()
                .set('page', pagina)
                .set('size', nrLinhas)
                .set('sort', `${sortField},${sortOrder}`)
        };

        this.carregaFiltroParametros(options);

        return options;

    }

    carregaFiltroParametros(options: { params: HttpParams; }) {
        options.params = this.utilityService.carregaParamsString(this.filtroUf ? this.filtroUf : null, options.params, 'ufs');
        options.params = this.utilityService.carregaParamsString(this.filtroRamo ? this.filtroRamo.map(r => r.id) : null, options.params, 'ramos');
        options.params = this.utilityService.carregaParamsString(this.filtroCnpj, options.params, 'cnpj');
        options.params = this.utilityService.carregaParamsString(this.filtroNomeFantasia, options.params, 'nomeFantasia');
        options.params = this.utilityService.carregaParamsString(this.filtroSituacao ? this.filtroSituacao : null, options.params, 'situacoes');
    }

    onChangeFilter() {
        clearTimeout(this.debouncer);
        this.debouncer = setTimeout(() => {
            this.dt.reset();
        }, this.delay);
    }

    onRowSelect(event) {
        const solicitacao = event.data;
        this.idPessoaSelecionada = solicitacao.pessoa.id;
        if (solicitacao.cancelado || solicitacao.aprovado !== null) {
            this.solicitacaoMudancaEnderecoSelecionada = solicitacao;
            this.modalMudancaUF = true;
        } else {
            this.apiCooperativaService.get(this.idPessoaSelecionada).then((response) => {
                if (response && response.data) {
                    const url = response.data.dataRegistro === null ? '/registro/processo' : '/cooperativa/detalhes';
                    this.router.navigate([url], { queryParams: { id_cooperativa: this.idPessoaSelecionada }, skipLocationChange: false });
                }
                this.changeDetectorRef.markForCheck();
            });
        }

    }
}
