import { ChangeDetectorRef, Component, OnInit, Input, EventEmitter, Output, inject } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ApiCooperativaLogoService } from '@cadastro-registro-api/services/api-cooperativa-logo.service';
import { PessoaImagem } from '@cadastro-registro-api/models/PessoaImagem';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';

@Component({
  selector: 'app-topo-cooperativa',
  templateUrl: './topo-cooperativa.component.html',
  styleUrls: ['./topo-cooperativa.component.css']
})
export class TopoCooperativaComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativaLogo: PessoaImagem;
  cooperativa: Cooperativa;

  @Input() podeModificar: boolean;

  @Output() dadosLogo = new EventEmitter<IServiceResponse<PessoaImagem>>();

  constructor(private cooperativaLogoService: ApiCooperativaLogoService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private keycloakService: KeycloakService
  ) { }

  ngOnInit(){
    this.carregarTela();
  }

  imagemLogo(imagemLogo){
    this.cooperativaLogo = imagemLogo.data;
    this.dadosLogo.emit(imagemLogo);
  }

  carregarTela(){

    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.cooperativa = coop;
      }
      this.changeDetectorRef.markForCheck();
    });

  }



}
