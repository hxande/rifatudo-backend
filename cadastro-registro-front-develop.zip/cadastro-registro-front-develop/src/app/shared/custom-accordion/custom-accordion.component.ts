import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';



@Component({
  selector: 'app-custom-accordion',
  templateUrl: './custom-accordion.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./custom-accordion.component.css'],
  animations: [
    trigger('changeDivSize', [
      state('initial', style({
        opacity: 0,
        height: '0'
      })),
      state('final', style({
        opacity: 100,
        height: '*'
      })),
      transition('initial=>final', animate('500ms')),
      transition('final=>initial', animate('500ms'))
    ]),
  ]
})
export class CustomAccordionComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input()
  contentSubTitle: string;

  @Input()
  contentRightTitle: string;

  @Input()
  title: string;

  @Input()
  opened = false;

  currentState = 'initial';

  initialIcon = 'fas fa-angle-up';

  @Output()
  clickRightTitle = new EventEmitter<void>();

  @Output()
  clickSubTitle = new EventEmitter<void>();

  contentHidden = true;


  changeState() {
    this.currentState = this.currentState === 'initial' ? 'final' : 'initial';
    this.contentHidden = this.opened ? false : true;
    if(this.currentState === 'final') {
      this.contentHidden = false;
    } else {
      setTimeout(() => {
        this.contentHidden = true;
        this.changeDetectorRef.markForCheck();
      }, 550);
    }

  }

  constructor() { }

  ngOnInit() {
    this.currentState = this.opened ? 'final' : 'initial';
    this.contentHidden = this.opened ? false : true;
  }

  onClickRightTitle() {
    this.clickRightTitle.emit();
  }

  onClickSubTitle() {
    this.clickSubTitle.emit();
  }

}


