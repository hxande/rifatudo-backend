import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { FileUploadModule } from 'primeng/fileupload';
import { DialogModule } from 'primeng/dialog';
import { CardModule } from 'primeng/card';
import { CheckboxModule } from 'primeng/checkbox';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DropdownModule } from 'primeng/dropdown';
import { InputMaskModule } from 'primeng/inputmask';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { MessageModule } from 'primeng/message';
import { MessagesModule } from 'primeng/messages';
import { PaginatorModule } from 'primeng/paginator';
import { AccordionModule } from 'primeng/accordion';
import { TooltipModule } from 'primeng/tooltip';
import { ToastModule } from 'primeng/toast';
import { SpinnerModule } from 'primeng/spinner';
import { MultiSelectModule } from 'primeng/multiselect';
import { FieldsetModule } from 'primeng/fieldset';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { RadioButtonModule } from 'primeng/radiobutton';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';
import { ButtonModule } from 'primeng/button';

import { ObservacaoUeComponent } from './observacao-ue/observacao-ue.component';
import { MudancaUfComponentComponent } from './mudanca-uf/mudanca-uf-component.component';
import { TopoCooperativaComponent } from './topo-cooperativa/topo-cooperativa.component';
import { CustomAccordionComponent } from './custom-accordion/custom-accordion.component';

import { RouterModule } from '@angular/router';
import { InformacoesGeraisComponent } from './informacoes-gerais/informacoes-gerais-component';
import { FilialComponentComponent } from './filial/filial-component.component';
import { FileUploadComponentsModule } from '@gui/file-upload/file-upload.module';
import { LogoCooperativaModule } from '@gui/logo-cooperativa/logo-cooperativa.module';
import { AjusteDadosComponent } from './validacaoDados/ajuste-dados-component';
import { ValidacaoDadosHistoricoComponent } from './validacaoDados/validacao-dados-historico/validacao-dados-historico.component';
import { MensagemComponent } from './mensagens/mensagem.component';
import { ListagemHistoricoCooperativaRegistroComponent } from './listagem-historico-cooperativa-registro/listagem-historico-cooperativa-registro.component';
import { ValidacaoDadosComponent } from './validacaoDados/validacao-dados-component';
import { ValidacaoDadosGeraisManutencao } from './dadosGerais/validacao/validacao-dados-gerais-manutencao.service';
import { ValidacaoLogo } from '@gui/logo-cooperativa/validacao/validacao-logo.service';
import { ValidacaoPendenciaVO } from '@cadastro-registro-api/models/validacao-pendencia-vo';
import { PipesCustomizadosModule } from '@gui/pipe/pipes-customizados.module';
import { UsuarioInformacoesComponent } from '@gui/usuario-informacoes/usuario-informacoes.component';

import { TabHeaderIconCheckComponent } from './tab-header-icon-check/tab-header-icon-check.component';
import { HistoricoQuadroSocialComponent } from './historico-quadro-social/historico-quadro-social.component';
import { RegistroEmailComponent } from '../features/cooperativa/registro-email/registro-email.component';
import { InputSwitchModule } from 'primeng/inputswitch';
import { EnderecoUfComponent } from './endereco-uf/endereco-uf.component';
import { CalendarModule } from 'primeng/calendar';
import { SelectButtonModule } from 'primeng/selectbutton';
import { TabMenuModule } from 'primeng/tabmenu';
import { ListboxModule } from 'primeng/listbox';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { SidebarModule } from 'primeng/sidebar';
import { DirectivesCustomizadosModule } from '@gui/directive/directives-customatizados.module';
import { CooperativaManutencaoAbaComponent } from './cooperativa-manutencao/cooperativa-manutencao-aba/cooperativa-manutencao-aba.component';
import { AlertaCadastroAbaComponent } from './alerta-cadastro-aba/alerta-cadastro-aba.component';
import { AverbacaoComponent } from './averbacao/averbacao.component';
import { PortifolioComponent } from '../features/registro/registro/portifolio/portifolio-component';
import { TagModule } from 'primeng/tag';
import { CnaeComponent } from '../features/registro/registro/cnae/cnae-component';
import { UsuarioInformacoes } from '@gerencia-usuario-api/models/UsuarioInformacoes';

@NgModule({
    declarations: [
        CustomAccordionComponent,
        MudancaUfComponentComponent,
        ObservacaoUeComponent,
        TopoCooperativaComponent,
        InformacoesGeraisComponent,
        FilialComponentComponent,
        AjusteDadosComponent,
        ValidacaoDadosHistoricoComponent,
        ValidacaoDadosComponent,
        MensagemComponent,
        ListagemHistoricoCooperativaRegistroComponent,
        TabHeaderIconCheckComponent,
        HistoricoQuadroSocialComponent,
        RegistroEmailComponent,
        EnderecoUfComponent,
        CooperativaManutencaoAbaComponent,
        AlertaCadastroAbaComponent,
        AverbacaoComponent,
        PortifolioComponent,
        CnaeComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        FileUploadModule,
        DialogModule,
        ButtonModule,
        CheckboxModule,
        InputTextModule,
        PaginatorModule,
        TableModule,
        CardModule,
        ScrollPanelModule,
        MessagesModule,
        MessageModule,
        ConfirmDialogModule,
        DropdownModule,
        RadioButtonModule,
        FieldsetModule,
        MultiSelectModule,
        ToastModule,
        AccordionModule,
        InputMaskModule,
        AutoCompleteModule,
        InputTextareaModule,
        TabViewModule,
        SpinnerModule,
        TooltipModule,
        InputSwitchModule,
        TagModule,
        PipesCustomizadosModule,
        UsuarioInformacoesComponent,
        FileUploadComponentsModule,
        UsuarioInformacoesComponent,
        LogoCooperativaModule
    ],
    providers: [
        ValidacaoDadosGeraisManutencao,
        ValidacaoLogo,
        ValidacaoPendenciaVO
    ],
    exports: [
        CommonModule,
        FormsModule,
        RouterModule,
        ReactiveFormsModule,
        FileUploadModule,
        DialogModule,
        ButtonModule,
        CheckboxModule,
        InputTextModule,
        TableModule,
        CardModule,
        ScrollPanelModule,
        MessagesModule,
        MessageModule,
        ConfirmDialogModule,
        DropdownModule,
        RadioButtonModule,
        MultiSelectModule,
        ToastModule,
        AccordionModule,
        InputMaskModule,
        AutoCompleteModule,
        InputTextareaModule,
        TabViewModule,
        SpinnerModule,
        TooltipModule,
        InputSwitchModule,
        CalendarModule,
        SelectButtonModule,
        TabMenuModule,
        ListboxModule,
        CurrencyMaskModule,
        SidebarModule,
        DirectivesCustomizadosModule,


        PipesCustomizadosModule,
        UsuarioInformacoesComponent,
        FileUploadComponentsModule,
        LogoCooperativaModule,

        CustomAccordionComponent,
        MudancaUfComponentComponent,
        ObservacaoUeComponent,
        TopoCooperativaComponent,
        InformacoesGeraisComponent,
        FilialComponentComponent,
        AjusteDadosComponent,
        ValidacaoDadosHistoricoComponent,
        ValidacaoDadosComponent,
        MensagemComponent,
        ListagemHistoricoCooperativaRegistroComponent,
        TabHeaderIconCheckComponent,
        HistoricoQuadroSocialComponent,
        RegistroEmailComponent,
        EnderecoUfComponent,
        CooperativaManutencaoAbaComponent,
        AlertaCadastroAbaComponent,
        AverbacaoComponent,
        PortifolioComponent,
        CnaeComponent
    ]
})
export class SharedModule {}
