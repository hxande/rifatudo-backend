import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaObservacaoUe } from '@cadastro-registro-api/models/CooperativaObservacaoUe';
import { ApiCooperativaObservacaoUeService } from '@cadastro-registro-api/services/api-cooperativa-observacao-ue.service';

@Component({
  selector: 'app-observacao-ue-component',
  templateUrl: './observacao-ue.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./observacao-ue.component.scss']
})
export class ObservacaoUeComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input()
  idCooperativa: number;

  observacaoUe: CooperativaObservacaoUe;
  historicoObservacaoUe: CooperativaObservacaoUe[];
  @Output() fecharEmitter = new EventEmitter<boolean>();

  observacao: string;

  constructor(
    private router: Router, private observacaoUeService: ApiCooperativaObservacaoUeService
  ) { }

  ngOnInit() {
  }

  salvar() {
    this.observacaoUeService.salvar(this.idCooperativa, this.observacao).then(retorno => {
      this.consultar(this.idCooperativa);

      this.changeDetectorRef.markForCheck();
    });
  }

  consultar(idCooperativa: number) {
    // this.cooperativa = cooperativa;
    this.observacaoUeService.getObservacaoAtiva(idCooperativa).then(retorno => {
      this.observacaoUe = retorno.data;
      this.observacao = this.observacaoUe.observacao;
      this.changeDetectorRef.markForCheck();
    }).catch(() => {
      this.observacaoUe = undefined;
      this.observacao = undefined;
      this.changeDetectorRef.markForCheck();
    });
    this.observacaoUeService.getHistorico(idCooperativa).then(retorno => {
      this.historicoObservacaoUe = retorno.data.reverse();
      this.changeDetectorRef.markForCheck();
    }).catch(() => {
      this.historicoObservacaoUe = undefined;
      this.changeDetectorRef.markForCheck();
    });

  }

  removerObservacao() {
    if (this.observacaoUe.id) {
      this.observacaoUeService.excluir(this.idCooperativa, this.observacaoUe.id).then(retorno => {
        this.consultar(this.idCooperativa);
        this.changeDetectorRef.markForCheck();
      }).catch(retorno => {
        // Em caso de falha na remoção.
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  fechar() {
    this.fecharEmitter.emit(true);
  }

}
