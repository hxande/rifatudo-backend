import { Table, TableLazyLoadEvent } from 'primeng/table';
import { Observable } from 'rxjs';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { HttpParams } from '@angular/common/http';
import { IPage } from '@utils/interfaces/IPage';
import { EventEmitter } from '@angular/core';
import { saveAs } from 'file-saver';

type OptionsHandlerCallback = (options: { params: HttpParams }) => void;
type FetchDataCallback<T> = (options: { params: HttpParams }) => Observable<IServiceResponse<IPage<T>>>;
type FetchExportXslCallback = (options: { params: HttpParams }) => Observable<BlobPart>;

export class TablePagedHandler<T> {
  data: T[];
  rows = 10;
  totalRecords = 0;
  table: Table;
  columns: { title: string, name: string, sortable: boolean | { fieldName: string }, filterable: boolean }[];
  filter: Record<string, unknown> = {};

  reportXlsName: string;
  optionsHandler: OptionsHandlerCallback;
  fetchDataCallback: FetchDataCallback<T>;
  fetchExportXlsCallback: FetchExportXslCallback;
  onFetchData: EventEmitter<IServiceResponse<IPage<T>>>;

  private debouncer;
  private delay = 500;

  lazyLoad(event: TableLazyLoadEvent): void {
    if (this.fetchDataCallback) {
      this.rows = event?.rows || 10;

      const page = event?.first / event?.rows || 0;
      const sortFieldRaw = Array.isArray(event?.sortField) ? event.sortField[0] : event?.sortField;
      const sortField = this.getSortFieldName(sortFieldRaw || '');
      const sortOrder = event?.sortOrder || 1;

      this.get(page, sortField, sortOrder).subscribe(response => {
        this.onFetchData?.emit(response);
        this.data = response.data.content;
        this.totalRecords = response.data.totalElements;
      });
    }
  }

  private getSortFieldName(sortField: string): string {
    if (sortField) {
      const sortable = this.columns.filter(column => column.name === sortField)[0].sortable;
      if (typeof sortable === 'object') {
        return sortable.fieldName;
      }
    }
    return '';
  }

  private get(page: number, sortField: string, sortOrder: number): Observable<IServiceResponse<IPage<T>>> {
    const options = this.getPagedOptions(page.toString(), this.rows.toString(), sortField, sortOrder === 1 ? 'asc' : 'desc');
    return this.fetchDataCallback(options);
  }

  getPagedOptions(page: string, size: string, sortField: string, sortOrder: string): { params: HttpParams } {
    let httpParams = new HttpParams()
      .set('page', page)
      .set('size', size);

    if (sortField) {
      httpParams = httpParams.set('sort', `${sortField},${sortOrder}`);
    }

    httpParams = this.getParamsFilter(httpParams);

    const options = { params: httpParams };

    if (this.optionsHandler) {
      this.optionsHandler(options);
    }

    return options;
  }

  getParamsFilter(params: HttpParams ): HttpParams {
    if (this.filter) {
      Object.keys(this.filter).forEach(key => {
        const value = this.filter[key];
        if (typeof this.filter[key] === 'object') {
          params = value ? params.set(key, (value as { value?: unknown })?.value?.toString()) : params;
        } else {
          params = value ? params.set(key, value.toString()) : params;
        }
      });
    }
    return params;
  }

  exportToXls(): void {
    let httpParams = new HttpParams();
    httpParams = this.getParamsFilter(httpParams);
    const options = { params: httpParams };

    this.fetchExportXlsCallback(options).subscribe(reponse => {
      const blob = new Blob([reponse], {type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
      saveAs(blob, this.reportXlsName);
    });
  }

  onChangeFilter(): void {
    clearTimeout(this.debouncer);
    this.debouncer = setTimeout(() => this.table.reset(), this.delay);
  }
}
