export class Transacao {
    id: number;
    idExterno: number;
    dtTransacao: Date;
    usuario: string;
    
}
