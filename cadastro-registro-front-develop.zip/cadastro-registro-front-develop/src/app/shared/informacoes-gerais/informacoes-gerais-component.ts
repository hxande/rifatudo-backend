import {DatePipe} from '@angular/common';
import {Component, EventEmitter, Inject, Input, OnDestroy, OnInit, Output, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {KEYCLOAK_CLIENT_ID, KeyclokClientEnum} from '@auth/auth-guard/constants';
import {Role} from '@auth/auth-guard/Role';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import {SubPerfisEnum} from '@auth/keycloak-service/sub-perfis.enum';
import {ProxyUrl} from '@auth/proxy-url/proxy-url.service';
import {Cooperativa} from '@cadastro-registro-api/models/Cooperativa';
import {PessoaJuridica} from '@cadastro-registro-api/models/PessoaJuridica';
import {ProgressoMacroEnum} from '@cadastro-registro-api/models/ProgressoMacroEnum';
import {ProgressoMicroEnum} from '@cadastro-registro-api/models/ProgressoMicroEnum';
import {SolicitacaoMudancaoEndereco} from '@cadastro-registro-api/models/SolicitacaoMudancaoEndereco';
import {StatusEnum} from '@cadastro-registro-api/models/StatusEnum';
import {ApiAdesaoService} from '@cadastro-registro-api/services/api-adesao.service';
import {ApiCadastroRegistroService} from '@cadastro-registro-api/services/api-cadastro-registro.service';
import {ApiCensoAnuarioService} from '@cadastro-registro-api/services/api-censo-anuario.service';
import {ApiCooperativaObservacaoUeService} from '@cadastro-registro-api/services/api-cooperativa-observacao-ue.service';
import {ApiCooperativaService} from '@cadastro-registro-api/services/api-cooperativa.service';
import {ApiMudancaUFService} from '@cadastro-registro-api/services/api-mudanca-uf.service';
import {ApiPessoaJuridicaService} from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import {BreadcrumbService} from '@core/breadcrumb/breadcrumb.service';
import {Usuario} from '@gerencia-usuario-api/models/Usuario';
import {ApiUsuarioService} from '@gerencia-usuario-api/services/api-usuario.service';
import {ConfirmationService} from 'primeng/api';
import {LanguageService} from '../languages/calendar-primeng/language-calendar';
import {MudancaUfComponentComponent} from '../mudanca-uf/mudanca-uf-component.component';
import {ObservacaoUeComponent} from '../observacao-ue/observacao-ue.component';
import {ValidacaoInformacoesGerais} from '../validacao/validacao-informacoes-gerais.service';
import {ValidacaoDados} from '../validacaoDados/validacao/validacao-dados.service';
import {ApiControleAnuarioService} from '@cadastro-registro-api/services/api-controle-anuario.service';
import {ControleAnuario} from '@cadastro-registro-api/models/ControleAnuario';
import { StringUtil } from '@shared/utils/StringUtil';

@Component({
  selector: 'app-informacoes-gerais-component',
  templateUrl: './informacoes-gerais-component.html',
  styleUrls: ['./informacoes-gerais-component.scss'],
})
export class InformacoesGeraisComponent implements OnInit, OnDestroy {
  @Output() getCooperativa = new EventEmitter<Cooperativa>();
  @Output() travarCampos = new EventEmitter<boolean>();
  @Input() showBotaoVisualizar = false;
  @Input() processoTransferencia = false;
  @Input() exibeAnuario = true;
  usuarios: Usuario[];

  constructor(
    private proxyUrl: ProxyUrl,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    public language: LanguageService,
    private confirmationService: ConfirmationService,
    private router: Router,
    private route: ActivatedRoute,
    public keycloakService: KeycloakService,
    private apiCooperativaService: ApiCooperativaService,
    private apiUsuarioService: ApiUsuarioService,
    private apiMudancaUFService: ApiMudancaUFService,
    public breadCrumbPrimeNGService: BreadcrumbService,
    public validacaoInformacoesGerais: ValidacaoInformacoesGerais,
    public validacaoDados: ValidacaoDados,
    private apiPj: ApiPessoaJuridicaService,
    private apiCooperativaObservacaoService: ApiCooperativaObservacaoUeService,
    private apiAdesaoService: ApiAdesaoService,
    private apiCensoAnuarioService: ApiCensoAnuarioService,
    private apiControleAnuarioService: ApiControleAnuarioService,
    @Inject(KEYCLOAK_CLIENT_ID) private clientId: KeyclokClientEnum
  ) {}

  cooperativa: Cooperativa = null;
  responsaveis: Usuario[];
  modalVisivel: boolean;
  modalMudancaUF = false;
  modalObservacaoUe = false;
  lblgoCadastro: string | null = '';
  podeSolicitarTrocaUF = false;
  podeCancelarSolicitacao = false;
  solicitaoEnvida = false;
  podeAprovar = false;
  dialogControleAnuario = false;
  idCooperativa;
  labelBotaoMudancaUF = 'Solicitar transferência de UF';
  @ViewChild('mudancaUf')
  mudancaUFComponent: MudancaUfComponentComponent;
  strSituacaoPeriodoAtualizacao: string;
  isCancelada = false;
  txClassSituacaoEstado = '';
  txIconStatusRegularidadeCooperativa = '';
  txtExplicacaoPeriodoAtualizacao = '';
  txClassSituacaoCooperativa = '';
  txIconRegularidadeCooperativa = '';
  txtSituacaoCooperativa = '';
  txtPeriodoAtualizacaoAnuario = '';
  statusEnum = StatusEnum;
  isRegistrada = false;
  dtUltimaAprovacao: Date = null;
  mostrarMensagemRealizarAjustes = false;
  nomePessoaJuridica: string;
  anoBase: number;
  anoExercicio: number;
  temPermissaoLeituraObservacaoUe = false;
  temPermissaoGravacaoObservacaoUe = false;
  exibeSituacaoFinanceira = false;
  tamanhoDiv = 'col-12';
  ultimaContribuicaoAno = '---';
  ultimaAtualizacao: Date;
  @ViewChild('mantemObservacoesUe') mantemObservacoesUe: ObservacaoUeComponent;
  tempoDesatualizacao: { anos: number, meses: number };
  descricaoTempoDesatualizacao: string;
  anuarioAtualizado = false;
  controleAnuario: ControleAnuario;
  podePreencherAnuario: string[];
  datePipe = new DatePipe('pt-BR');
  dataInicialLimiteAnuario = new Date('06/13/2022');
  mostrarAnuario = false;
  statusAtualizacaoAnuario = '';
  mostrarDataAprovacaoDadosOE = true;

  ngOnInit(): void {
    this.carregarTela();
  }

  carregarTela() {
    this.modalMudancaUF = false;
    this.buscarControleAnuario();
    this.cooperativa = new Cooperativa();
    this.cooperativa.pessoaJuridica = new PessoaJuridica();
    this.route.queryParams.subscribe((params) => {
      this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          this.cooperativa = coop;
          this.idCooperativa = this.cooperativa.id;
          this.solicitaoEnvida = this.cooperativa.processoTransferencia;
          this.verificaAdesao();

          this.verificaVisualizacaoDataAprovacaoDados();
          /**
           if (this.cooperativa.dataRegistro) {
            this.getArrecadacoes(coop.id);
          }
           */
          this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla).then((pj) => {
            this.nomePessoaJuridica = pj.data.nomeFantasia;
          });
          this.apiUsuarioService.buscaUsuarioCnpj(coop.pessoaJuridica.cnpj).then((res) => {
            this.usuarios = res.data;
          });
          this.apiUsuarioService.buscarResponsaveis(coop.pessoaJuridica.cnpj).then((res) => {
            this.responsaveis = res.data;
          });
          this.cooperativa = coop;
          this.apiCooperativaService.getPeriodoAtualizacao(this.cooperativa.id).then((response) => {
            this.labelGoCadastro(response);
            this.periodoDeAtualizacao(response);
          });
          if (this.validacaoInformacoesGerais.podeVerBotaoSolicitarMudancaEndereco()) {
            this.podeSolicitarMudancaUF(this.cooperativa.id);
            this.podeAprovarMudancaUF(this.cooperativa.id);
            this.podeCancelarMudancaoUF(this.cooperativa.id);
          }
          this.getCooperativa.emit(this.cooperativa);

          if (this.cooperativa.situacaoCooperativa.id === 3) {
            this.isCancelada = true;
          }

          if (this.cooperativa.dataRegistro != null && this.cooperativa.numeroRegistroOCB != null) {
            this.isRegistrada = true;
          } else if (this.cooperativa.situacaoCooperativa != null && this.cooperativa.situacaoCooperativa.id !== 4) {
            this.isRegistrada = true;
          }

          this.apiCooperativaObservacaoService
            .temPermissaoDeLeitura(this.idCooperativa)
            .then((resultado) => (this.temPermissaoLeituraObservacaoUe = resultado.data))
            .catch(() => (this.temPermissaoLeituraObservacaoUe = false));
          this.apiCooperativaObservacaoService
            .temPermissaoDeGravacao(this.idCooperativa)
            .then((resultado) => (this.temPermissaoGravacaoObservacaoUe = resultado.data))
            .catch(() => (this.temPermissaoGravacaoObservacaoUe = false));

          this.carregarStatusAtualizacaoCadastral();
          this.carregarStatusAtualizacaoAnuario();
        }
      });
    });
  }
  verificaVisualizacaoDataAprovacaoDados() {
    this.mostrarDataAprovacaoDadosOE = !(this.keycloakService.isUsuarioCooperativa && this.cooperativa.progressoMacro == 'VALIDACAO_DOCUMENTOS_2');
  }

  carregarStatusAtualizacaoAnuario(): void {
    this.apiCensoAnuarioService.getCheckAnuarioAtualizado(this.cooperativa.id).subscribe(response => {
      this.anuarioAtualizado = response.data;
    });
    this.apiCensoAnuarioService.getStatusAtualizacaoAnuario(this.cooperativa.id).subscribe(response => {
      this.statusAtualizacaoAnuario = response.data;
    });
  }

  private carregarStatusAtualizacaoCadastral() {
    this.strSituacaoPeriodoAtualizacao = this.cooperativa.status;
    if (this.strSituacaoPeriodoAtualizacao === 'Aprovada') {
      this.txClassSituacaoCooperativa = this.txClassSituacaoEstado = 'registro-ativo text-infor';
    } else {
      this.txClassSituacaoCooperativa = this.txClassSituacaoEstado = 'registro-inativo text-infor';
    }
  }

  carregarTelaMudancaUF() {
    this.mudancaUFComponent.carregarTela();
  }

  carregaSolicitacao(solicitacaoCadastrada: boolean) {
    this.solicitaoEnvida = solicitacaoCadastrada;
    this.carregarTela();
  }

  podeSolicitarMudancaUF(idCoop) {
    this.apiMudancaUFService.podeSolicitarMudancaUF(idCoop).then((response) => {
      this.podeSolicitarTrocaUF = response.data;
    });
  }

  podeCancelarMudancaoUF(idCoop) {
    this.apiMudancaUFService.podeCancelar(idCoop).then((response) => {
      this.podeCancelarSolicitacao = response.data;
      this.travarCampos.emit(this.podeCancelarSolicitacao);
    });
  }

  visualizarContribuicoes() {
    this.confirmationService.confirm({
      message: 'O sistema Arrecadação será aberto em uma nova aba. Deseja continuar?',
      accept: () => {
        const urlAtual = this.proxyUrl.getUrlAtual();
        if (urlAtual) {
          const link = document.createElement('a');
          document.body.appendChild(link);
          link.target = '_blank';
          link.setAttribute('visibility', 'hidden');
          if (urlAtual.indexOf(ProxyUrl.HOMOLOGACAO_SUFIXO) !== -1) {
            link.href =
              'https://arrecadacao-hmlg.apps.ocp.somos.coop.br/contribuicao-financeira/' + this.idCooperativa + '?id_cooperativa=' + this.cooperativa.id;
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.PRODUCAO_SUFIXO) !== -1) {
            link.href =
              'https://arrecadacao-prd.apps.ocp.somos.coop.br/contribuicao-financeira/' + this.idCooperativa + '?id_cooperativa=' + this.cooperativa.id;
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.TREINAMENTO_SUFIXO) !== -1) {
            link.href =
              'https://arrecadacao-trt.apps.ocp.somos.coop.br/contribuicao-financeira/' + this.idCooperativa + '?id_cooperativa=' + this.cooperativa.id;
            link.click();
          } else {
            link.href = 'http://localhost/inicio';
            link.click();
          }
        }
      },
    });
  }

  cancelarMudancaUF() {
    this.confirmationService.confirm({
      message: 'Deseja cancelar o processo de mudança de UF?',
      key: 'cancelarMudancaUF',
      accept: () => {
        this.apiMudancaUFService.cancelaSolicitacao(this.cooperativa.id, new SolicitacaoMudancaoEndereco()).then((response) => {
          this.solicitaoEnvida = false;
          this.carregarTela();
          this.carregarTelaMudancaUF();
          this.mudancaUFComponent.resetaFileUpload();
        });
      },
    });
  }

  podeAprovarMudancaUF(idCoop) {
    this.apiMudancaUFService.podeConsultarAprovacao(idCoop).then((response) => {
      this.podeAprovar = response.data;
      this.labelBotaoMudancaUF = this.podeAprovar ? 'Dar parecer mudança de UF' : this.labelBotaoMudancaUF;
      if (!this.podeAprovar && !this.solicitaoEnvida) {
        this.labelBotaoMudancaUF = 'Solicitar transferência de UF';
      } else if (!this.podeAprovar && this.solicitaoEnvida) {
        this.labelBotaoMudancaUF = 'Acompanhar mudança de UF';
      }
    });
  }

  getNomeId(nome){
    const semAcento = StringUtil.retiraAcentuacao(nome)
    return semAcento.toLowerCase().split(' ').join('-')
  }

  labelGoCadastro(response: any) {
    this.lblgoCadastro = this.cooperativa.numeroRegistroOCB ? 'Atualização cadastral' : 'Visualizar cadastro';
    if (this.cooperativa.dataRegistro != null && response?.data) {
      this.mostrarAnuario = response.data.mostrarPeriodoAnuario;
      if (this.keycloakService.isUsuarioCooperativa) {
        if (
          this.cooperativa.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10 &&
          this.cooperativa.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_MANUTENCAO_10_2
        ) {
          this.lblgoCadastro = 'Realizar Ajustes';
          this.mostrarMensagemRealizarAjustes = true;
        } else if (
          !(
            this.cooperativa.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10 &&
            this.cooperativa.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1
          ) &&
          (response['data'].situacao === 'DAP' || response['data'].situacao === 'DP' || response['data'].situacao === 'D')
        ) {
          this.lblgoCadastro = 'Atualizar Cadastro';
        }
      } else {
        if (
          this.cooperativa.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10 &&
          this.cooperativa.progressoManutencaoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1 &&
          this.validacaoDados.validaAjustesDadosManutencao(this.cooperativa.progressoManutencaoMicro)
        ) {
          this.lblgoCadastro = 'Analisar Cadastro';
        }
      }
    }
  }

  abrirMudancaUF() {
    this.modalMudancaUF = true;
  }

  exibirResponsavel() {
    this.modalVisivel = true;
    // this.responsaveis = this.usuarios;
  }

  ngOnDestroy(): void {}

  visualizarCadastro() {
    if (
      this.cooperativa.progressoManutencaoMacro === ProgressoMacroEnum.MANUTENCAO_10 ||
      (!this.cooperativa.progressoManutencaoMacro && !this.cooperativa.progressoMacro)
    ) {
      this.router.navigate(['/registro/manutencaoCadastro'], {
        queryParams: { id_cooperativa: this.cooperativa.id },
        skipLocationChange: false,
      });
    } else {
      this.router.navigate(['/registro/cadastro'], {
        queryParams: { id_cooperativa: this.cooperativa.id },
        skipLocationChange: false,
      });
    }
  }

  goDocumentos() {
    this.router.navigate(['/registro/documentos'], {
      queryParams: { id_cooperativa: this.cooperativa.id },
      skipLocationChange: false,
    });
  }

  get isEstadualOuNacional() {
    return this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional;
  }

  periodoDeAtualizacao(response: any) {
    if (response.data) {
      const retorno = response.data;
      const datePipe = new DatePipe('pt-BR');
      this.txtSituacaoCooperativa =
        'De ' + datePipe.transform(retorno.inicioAttCadastral, 'dd/MM/yyyy', 'BRT') + ' até ' + datePipe.transform(retorno.fimAttCadastral, 'dd/MM/yyyy', 'BRT');
      if (retorno.inicioAttAnuario && retorno.fimAttAnuario) {
        this.txtPeriodoAtualizacaoAnuario =
          'De ' + datePipe.transform(retorno.inicioAttAnuario, 'dd/MM/yyyy', 'BRT') +
          ' até ' + datePipe.transform(retorno.fimAttAnuario, 'dd/MM/yyyy', 'BRT');
      }
      this.dtUltimaAprovacao = retorno.dataAprovacao;
      this.tempoDesatualizacao = retorno.tempoDesatualizacao;
      this.montarDescricaoTempoDesatualizacao();

      // Desatualizada
      if (retorno.situacao === 'DP' || retorno.situacao === 'DAP' || retorno.situacao === 'D') {
        this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa = 'fas fas fa-exclamation-circle';
      }

      // Atualizada
      if (retorno.situacao === 'AP' || retorno.situacao === 'A') {
        if (retorno.situacao === 'AP') {
          this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa = 'fas fas fa-exclamation-circle';
        } else if (retorno.situacao === 'A') {
          this.txIconRegularidadeCooperativa = this.txIconStatusRegularidadeCooperativa = 'fas fas fa-check-circle';
        }
      }
    }
  }

  /**
   * Exibe o modal para edição de Observações da UE.
   */
  exibeModalObservacaoUe() {
    this.modalObservacaoUe = true;
    this.mantemObservacoesUe.consultar(this.cooperativa.id);
  }

  verificaAdesao() {
    this.tamanhoDiv = 'col-12';
    this.apiAdesaoService.getContribuicoes().then((response) => {
      if (response) {
        response.data.forEach((adesao) => {
          if (adesao.ufSigla === this.cooperativa.pessoaJuridica.ufSigla) {
            this.exibeSituacaoFinanceira = adesao.adere;
            if (this.exibeSituacaoFinanceira) {
              this.tamanhoDiv = 'col-6';
            }
          }
        });
      }
    });
  }

  podeVisualizarAnuario(): boolean {
    return (
      this.keycloakService.hasRole(Role.CADASTRO_REGISTRO_USUARIO_ATIVO, this.clientId) &&
      (this.isEstadualOuNacional || this.keycloakService.isUsuarioCooperativa) &&
      this.podeVerMenuAnuarioSubPerfil()
    );
  }

  podeVerMenuAnuarioSubPerfil(): boolean {
    return (
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    );
  }

  visualizarAnuario(): void {
    if (this.keycloakService.isUsuarioCooperativa) {
      if(!this.podeSalvarAnuario()) {
        this.router.navigate(['/cooperativa/anuario-ue']);
      }
    } else {
      this.router.navigate(['/cooperativa/anuario', this.cooperativa.id]);
    }
  }

  private montarDescricaoTempoDesatualizacao(): void {
    if (this.tempoDesatualizacao) {
      this.descricaoTempoDesatualizacao = 'Desatualizada há aproximadamente ';
      if (this.tempoDesatualizacao.anos && this.tempoDesatualizacao.anos > 0) {
        this.descricaoTempoDesatualizacao += this.tempoDesatualizacao.anos.toString();
        if (this.tempoDesatualizacao.anos === 1) {
          this.descricaoTempoDesatualizacao += ' ano';
        } else {
          this.descricaoTempoDesatualizacao += ' anos';
        }
        this.descricaoTempoDesatualizacao += ' e ';
      }

      this.descricaoTempoDesatualizacao += this.tempoDesatualizacao.meses.toString();

      if (this.tempoDesatualizacao.meses === 1) {
        this.descricaoTempoDesatualizacao += ' mês';
      } else {
        this.descricaoTempoDesatualizacao += ' meses';
      }

      this.descricaoTempoDesatualizacao += ', tendo como referência a data';

      if (this.dtUltimaAprovacao) {
        this.descricaoTempoDesatualizacao += ' da última aprovação.';
      } else {
        this.descricaoTempoDesatualizacao += ' de registro.';
      }
    }
  }

  buscarControleAnuario(): void {
    this.apiControleAnuarioService.get('SESCOOP').subscribe(res => {
      this.controleAnuario = res.data;
      this.podePreencherAnuario = res.data.preencherAnuario.split(',');
    });
  }

  podeSalvarAnuario() {
    const dataHoje = new Date();
    const dataFinalLimiteAnuario = new Date('07/08/2022');
    return this.keycloakService.isUsuarioCooperativa &&
      ((dataHoje.getTime() > this.dataInicialLimiteAnuario.getTime()) && (dataHoje.getTime() < dataFinalLimiteAnuario.getTime()));
  }
  fecharDialogControleAnuario() {
    this.dialogControleAnuario = false;
  }

  verificarPopUpAnuario() {
    if (!this.controleAnuario.mostrarpopup) {
      return this.visualizarAnuario();
    } else {
      this.dialogControleAnuario = true;
    }
  }
  verificaPodePreencherAnuario() {
    if (!this.keycloakService.isUsuarioNacional) {
      return !this.podePreencherAnuario.includes(this.keycloakService.getTipo());
    } else {
      return !this.keycloakService.isUsuarioNacional;
    }
  }

}
