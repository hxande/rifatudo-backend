import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoNegocioManutencao {
  constructor(
    private validacaoDados: ValidacaoDados
  ){}


  podeVerHistoricoFaturamento() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }

    return false;
  }

  podeEditarCadastroFiliais() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }

    return false;
  }
}
