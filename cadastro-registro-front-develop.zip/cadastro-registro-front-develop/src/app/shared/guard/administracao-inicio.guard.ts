import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';





@Injectable({
    providedIn: 'root',
})
export class AdministracaoInicioGuard  {

    constructor(private keycloakService: KeycloakService,
        private router: Router){

    }

    canActivate(){
        if(this.keycloakService.isUsuarioNacional){
            return true;
        } else if (this.keycloakService.isUsuarioEstadual) {
            this.router.navigate(['/administracao/inicio-ue']);
        } else {
            this.router.navigate(['/inicio']);
        }
    }
    
}