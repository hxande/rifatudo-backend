import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';

@Injectable({
    providedIn: 'root',
})
export class ProcessoRegistroGuard  {

    constructor(private keycloakService: KeycloakService,
        private router: Router){

}

    canActivate(){
        if(this.keycloakService.isUsuarioCooperativa){
            this.router.navigate(['/inicio']);
        }
        return true;
    }
}
