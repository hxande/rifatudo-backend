import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';

/**
 * Página que pode ter alterações não salvas no momento em que o usuário navega
 * para outra rota. O componente decide (normalmente abrindo o diálogo "Salvar
 * alterações da página antes de sair?") e devolve se a navegação pode seguir.
 */
export interface ComponenteComAlteracoesPendentes {
    podeSair(): boolean | Promise<boolean>;
}

@Injectable({
    providedIn: 'root',
})
export class AlteracoesPendentesGuard implements CanDeactivate<ComponenteComAlteracoesPendentes> {

    canDeactivate(component: ComponenteComAlteracoesPendentes) {
        return component && component.podeSair ? component.podeSair() : true;
    }
}
