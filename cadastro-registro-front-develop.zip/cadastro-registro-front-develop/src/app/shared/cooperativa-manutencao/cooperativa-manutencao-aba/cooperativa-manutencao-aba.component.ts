import { ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit } from '@angular/core';

@Component({
    selector: 'app-cooperativa-manutencao-aba-component',
    templateUrl: './cooperativa-manutencao-aba.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./cooperativa-manutencao-aba.component.scss'],
  })
  export class CooperativaManutencaoAbaComponent implements OnInit, OnDestroy {

    @Input() ajusteSolicitado = false;

    get mensagem(): string {
      return this.ajusteSolicitado
        ? 'Existem ajustes solicitados pela análise nesta aba. Revise os itens apontados e clique em salvar e continuar'
        : 'Favor, preencher os campos e clicar em salvar e continuar';
    }

    constructor() {}
  
    ngOnInit(): void {}
  
    ngOnDestroy(): void {}
  }
  