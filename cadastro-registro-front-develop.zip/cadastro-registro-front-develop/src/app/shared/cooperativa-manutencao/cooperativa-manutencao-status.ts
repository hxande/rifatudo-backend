export enum CooperativaManutencaoStatus {
    ALERTA = "01",
    SALVO_PENDENCIAS = "02",
    SALVO_SUCESSO = "03",
    AJUSTES = "04"
  };

