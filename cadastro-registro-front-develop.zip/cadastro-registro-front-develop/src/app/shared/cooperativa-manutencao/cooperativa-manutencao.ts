export class CooperativaManutencao {
    id: number;
    idCooperativa: number;
    anoCiclo: number;
    abaDocumentos: string;
    abaDadosGerais: string;
    abaGovernanca: string;
    abaSegmentacaoFilial: string;
    abaContatos: string;
    abaSubmeter: string;
    dataAlteracao: Date;
    dataCriacao: Date;
    usuario: string;
    abasComAjusteSolicitado?: string[];
}