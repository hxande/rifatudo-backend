import { Component, OnInit, OnDestroy, Input, ChangeDetectionStrategy } from '@angular/core';
import { Messages } from './Messages';

@Component({
  selector: 'app-mensagem-component',
  templateUrl: './mensagem.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mensagem.component.scss'],
})
export class MensagemComponent implements OnInit, OnDestroy {
  @Input() listaMensagem: Messages[];

  constructor() {}

  ngOnInit(): void {}

  ngOnDestroy(): void {}
}
