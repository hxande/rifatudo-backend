import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SolicitacaoTO } from '@shared/listagem-historico-cooperativa-registro/solicitacaoTO';
import { ComentarioDataTO } from '@shared/listagem-historico-cooperativa-registro/comentarioDataTO';

@Injectable({
  providedIn: 'root'
})
export class SolicitacaoService {

  private apiUrl = '/cadastro-registro-leitura-api/api/v1/motivo-solicitacao';

  constructor(private http: HttpClient) { }

  getSolicitacoes(): Observable<SolicitacaoTO[]> {
    return this.http.get<SolicitacaoTO[]>(this.apiUrl);
  }

  enviarComentario(comentarioData: ComentarioDataTO): Observable<unknown> {
    const url = '/cadastro-registro-api/api/v1/comentarios';
    return this.http.post(url, comentarioData);
  }
}
