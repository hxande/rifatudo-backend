import { ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { saveAs } from 'file-saver';
import { MessageService, SelectItem } from 'primeng/api';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { EnumTipoAcao } from '@cadastro-registro-api/models/EnumTipoAcao';
import { ValidacaoCooperativa } from 'src/app/features/registro/validacao/validacao-cooperativa.service';
import { Situacao } from '@cadastro-registro-api/models/Situacao';
import { SolicitacaoTO } from '@shared/listagem-historico-cooperativa-registro/solicitacaoTO';
import { SolicitacaoService } from '@shared/listagem-historico-cooperativa-registro/solicitacao-service';
import { ComentarioDataTO } from '@shared/listagem-historico-cooperativa-registro/comentarioDataTO';
import { firstValueFrom } from 'rxjs';
import { CooperativaRegistro } from 'src/app/api/models/CooperativaRegistro';
import { HistoricoCooperativaRegistroListagemTO } from 'src/app/api/models/HistoricoCooperativaRegistroListagemTO';

@Component({
  selector: 'app-listagem-historico-cooperativa-registro',
  templateUrl: './listagem-historico-cooperativa-registro.component.html',
  styleUrls: ['./listagem-historico-cooperativa-registro.component.css']
})
export class ListagemHistoricoCooperativaRegistroComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  colsHistorico: { field: string, header: string }[];
  @Input() historicosTO: HistoricoCooperativaRegistroListagemTO[];
  @Input() modalHistoricoSituacaoCoop: boolean;
  @Input() situacaoAtualCoop: Situacao;
  @Output() fechaModal = new EventEmitter();
  @Output() editaIrregularidade = new EventEmitter();
  @Output() onCommentSaved = new EventEmitter<void>();


  historicoSelecionadoId: number;

  displayModal: boolean = false;
  selectedReasons: string[] = [];
  descricao: string;

  selectedHistoricoId: number | null = null;


  solicitacoes: SelectItem[];
  selectedSolicitacoes: SelectItem<SolicitacaoTO>[] = [];


  detalheHistoricoModal: CooperativaRegistro;
  modalHistoricoDetalhe = false;
  novoModalVisible: boolean = false;
  modalRegistroEmail = false;
  justificativaPrincipalHistorico = '';
  situacaoEnum = SituacaoEnum;
  objHistoricoDetalhe = new HistoricoCooperativaRegistroListagemTO();
  enumTipoAcao = EnumTipoAcao;
  isJustificativaUN = false;
  isJustificativaUE = false;
  response: IServiceResponse<IPage<HistoricoCooperativaRegistroListagemTO>>;
  botaoEditar = false;

  constructor(
    private apiCooperativaService: ApiCooperativaService,
    private messageService: MessageService,
    private solicitacaoService: SolicitacaoService,
    public validacaoCooperativa: ValidacaoCooperativa,
  ) {
    this.detalheHistoricoModal = new CooperativaRegistro();
  }

  ngOnInit() {
    this.carregarSolicitacoes();
    this.colsHistorico = [
      { field: 'acao', header: 'Ação' },
      { field: 'dataAlteracao', header: 'Data' },
      { field: 'usuario', header: 'Usuário' },
      { field: 'situacaoCooperativa', header: 'Situação/Regularidade' },
      { field: 'novaSituacao', header: 'Nova' },
      { field: 'motivo', header: 'Motivo' },
      { field: 'detalhesDoHistorico', header: 'Detalhes' },
      { field: 'adicionar', header: 'Adicionar' }
    ];
  }

  getMotivoText(motivoIds: number[]): string {
    if (!motivoIds) {
      return '';
    }
    return motivoIds.map(id =>
      this.solicitacoes.find(s => s.value.id === id)?.label || 'Desconhecido'
    ).join(', ');
  }

  onAddButtonClick(historicoId: number) {
    this.selectedHistoricoId = historicoId;
    this.displayModal = true;
  }

  carregarSolicitacoes() {
    this.solicitacaoService.getSolicitacoes().subscribe(response => {
      this.solicitacoes = response.map(s => ({
        label: s.motivoSolicitacao,
        value: s
      }));
      this.changeDetectorRef.markForCheck();
    }, error => {
      console.error('Erro ao carregar solicitações:', error);
    });
  }



  onConfirm() {

    if (!this.descricao || this.selectedSolicitacoes.length === 0) {
      this.messageService.add({ severity: 'error', detail: 'Observação e motivo são campos obrigatórios.', life: 10000 });
      return;
    }
    const comentarioData: ComentarioDataTO = {
      cooperativaRegistroId: this.selectedHistoricoId,
      observacao: this.descricao,
      motivos: this.selectedSolicitacoes.map((s: SelectItem<SolicitacaoTO>) => s.value.id),
      acao: null,
      dataAlteracao: null,
    };

    this.enviarComentario(comentarioData);
    this.displayModal = false;
  }

  async enviarComentario(comentarioData: ComentarioDataTO) {
    try {
      const response = await firstValueFrom(
        this.solicitacaoService.enviarComentario(comentarioData)
      );
      this.messageService.add({ severity: 'success', detail: 'Comentário salvo com sucesso', life: 2000 });
      this.descricao = null;
      this.selectedSolicitacoes = null;
      this.onCommentSaved.emit();
      this.changeDetectorRef.markForCheck();
    } catch (error) {
      this.messageService.add({ severity: 'error', detail: 'Erro ao salvar comentário.', life: 2000 });
      this.changeDetectorRef.markForCheck();
    }
  }




  carregaDetalheHistorico(historico: HistoricoCooperativaRegistroListagemTO) {

    this.historicoSelecionadoId = historico.cooperativaRegistro.id;

    this.objHistoricoDetalhe = historico;
    this.detalheHistoricoModal = historico.cooperativaRegistro;
    this.isJustificativaUN = false;
    this.isJustificativaUE = false;

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_CANCELA_COOPERATIVA_REGULAR) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaCancelada;
      this.isJustificativaUE = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_CANCELA_COOPERATIVA_IRREGULAR) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaCancelada;
      this.isJustificativaUE = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_APONTA_IRREGULARIDADE) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaIrregular;
      this.isJustificativaUE = true;
      this.botaoEditar = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_APONTA_IRREGULARIDADE) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaIrregular;
      this.isJustificativaUN = true;
      this.botaoEditar = true;
    }

    // Quando UE ou UN regulariza não tem documento nem justificativa
    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_INATIVACAO
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_SUSPENSAO) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaSolicitacaoInativacao;
      this.isJustificativaUE = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ACEITA_SOLICITACAO_INATIVACAO
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_INATIVA_COOPERATIVA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaInativada;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_INATIVACAO
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_SUSPENSAO) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaAtivacao;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_CANCELAMENTO
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_CANCELAMENTO_COOPERATIVA_ATIVA
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_CANCELAMENTO_COOPERATIVA_REGULAR) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaSolicitacaoCancelamento;
      this.isJustificativaUE = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ACEITA_SOLICITACAO_CANCELAMENTO
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_CANCELA_COOPERATIVA
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ACEITA_SOLICITACAO_CANCELAMENTO_ATIVA
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_CANCELA_COOPERATIVA_ATIVA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaCancelada;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_CANCELAMENTO
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_ATIVACAO_COOPERATIVA_CANCELADA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaInativada;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_CANCELAMENTO_ATIVA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaAtivacao;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_CANCELA_COOPERATIVA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaCancelada;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_ATIVACAO ||
      historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_SOLICITA_REGULARIZACAO) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaSolicitacaoAtivacao;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_CANCELA_SOLICITACAO_ATIVACAO) {
      this.justificativaPrincipalHistorico = '';
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ATIVA_COOPERATIVA_INATIVA
      || historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ATIVA_COOPERATIVA_CANCELADA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaAtivacao;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaInativada;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_INATIVA ||
      historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ACEITA_SOLICITACAO_ATIVACAO_COOPERATIVA_CANCELADA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaAtivacao;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_INATIVA_COOPERATIVA_CANCELADA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaInativada;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_ACEITA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_SUSPENSA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaAtivacao;
      this.isJustificativaUN = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UN_RECUSA_SOLICITACAO_REGULARIZACAO_COOPERATIVA_SUSPENSA) {
      this.justificativaPrincipalHistorico = historico.cooperativaRegistro.justificativaInativada;
      this.isJustificativaUN = true;
    }

    if (this.justificativaPrincipalHistorico !== '') {
      this.modalHistoricoDetalhe = true;
    }

    if (historico.cooperativaRegistro.tipoAcao === EnumTipoAcao.UE_NOTIFICA_SUSPENSAO) {
      this.modalRegistroEmail = true;
    }

  }

  encerraModalHistoricoDetalhe() {
    this.detalheHistoricoModal = new CooperativaRegistro();
    this.modalHistoricoDetalhe = false;
    this.justificativaPrincipalHistorico = '';
  }

  encerraModalHistorico() {
    this.modalHistoricoSituacaoCoop = false;
    this.fechaModal.emit({ modalHistoricoSituacaoCoop: false });
  }

  ativarEditarIrregularidade() {
    this.encerraModalHistoricoDetalhe();
    this.encerraModalHistorico();
    // Emite no próximo ciclo para o pai abrir o modal de edição após estes fecharem (evita problema de fechamento)
    setTimeout(() => this.editaIrregularidade.emit(), 0);
  }

  exportarTabela() {
    if (this.historicosTO && this.historicosTO) {

      this.apiCooperativaService.getCooperativaPorCnpjSincronizada(this.historicosTO[0].cnpj).then(c => {
        const idCooperativa = c.data.id;
        this.apiCooperativaService.exportarXlsHistorico(idCooperativa).then(response => {
          const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
          saveAs(blob, 'Cooperativa_Registro_Historico.xlsx');
          this.changeDetectorRef.markForCheck();
        }).catch(error => {
          if (error.status && error.status === 404) {
            this.messageService.add({ severity: 'warn', detail: 'Nenhum registro encontrado', life: 100000 });
          } else {
            this.messageService.add({ severity: 'error', detail: 'Problemas ao gerar relatório', life: 100000 });
          }
          this.changeDetectorRef.markForCheck();
        });
      });
    } else {
      this.messageService.add({ severity: 'warn', detail: 'Não existem registros para serem exportados.', life: 100000 });
    }
  }

  disabledBtnDetalhes(historico: HistoricoCooperativaRegistroListagemTO) {
    let disabled = true;
    if ((historico.cooperativaRegistro.justificativaAtivacao
      || historico.cooperativaRegistro.justificativaCancelada
      || historico.cooperativaRegistro.justificativaInativada
      || historico.cooperativaRegistro.justificativaIrregular
      || historico.cooperativaRegistro.justificativaSolicitacaoAtivacao
      || historico.cooperativaRegistro.justificativaSolicitacaoCancelamento
      || historico.cooperativaRegistro.justificativaSolicitacaoInativacao)
      && historico.cooperativaRegistro.tipoAcao != null
      && (historico.cooperativaRegistro.tipoAcao !== EnumTipoAcao.UE_CANCELA_SOLICITACAO_ATIVACAO
        && historico.cooperativaRegistro.tipoAcao !== EnumTipoAcao.UE_CANCELA_SOLICITACAO_INATIVACAO
        && historico.cooperativaRegistro.tipoAcao !== EnumTipoAcao.UE_CANCELA_SOLICITACAO_CANCELAMEMENTO
        && historico.cooperativaRegistro.tipoAcao !== EnumTipoAcao.UE_COMUNICA_ORGAOS_SUSPENSAO)) {
      disabled = false;
    }
    return disabled;
  }

  capitalize(string: string): string {
    if (string) {
      string = string.toLowerCase();
      return string.charAt(0).toUpperCase() + string.slice(1);
    } else {
      return '';
    }
  }
}
