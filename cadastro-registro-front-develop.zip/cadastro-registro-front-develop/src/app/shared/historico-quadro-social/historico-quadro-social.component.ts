import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { ValidacaoDadosGeraisManutencao } from '@shared/dadosGerais/validacao/validacao-dados-gerais-manutencao.service';
import { MessageService } from 'primeng/api';
import { HttpParams } from '@angular/common/http';
import { UtilityService } from '@utils/utility/utility.service';
import { ParametroQuadroSocial } from '@cadastro-registro-api/models/ParametroQuadroSocial';
import { QuadroSocialParametroQuadro } from '@cadastro-registro-api/models/QuadroSocialParametroQuadro';
import { QuadroSocialService } from '@cadastro-registro-api/services/quadro-social.service';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';

@Component({
  selector: 'app-historico-quadro-social',
  templateUrl: './historico-quadro-social.component.html',
  styleUrls: ['./historico-quadro-social.component.css']
})
export class HistoricoQuadroSocialComponent implements OnInit {
  quadroSociais: QuadroSocial[];
  @Input() idCooperativa: number;
  adicionarQuantidadeTotal = false;
  @Output() evtSalvar = new EventEmitter<void>();
  houveAlteracaoForm = false;
  parametrosQuadroSocial: ParametroQuadroSocial[];
  quadroSocialParametroQuadro: QuadroSocialParametroQuadro[];

  constructor(
    private apiDadosGerais: ApiDadosGeraisService,
    private messageService: MessageService,
    public validacaoDadosGeraisManutencao: ValidacaoDadosGeraisManutencao,
    private quadroSocialService: QuadroSocialService,
    private utilityService: UtilityService,
    private usuario: KeycloakService
  ) {}

  ngOnInit() {
  }

  buscaHistorico() {
    this.apiDadosGerais.buscaHistoricoQuadroSocial(this.idCooperativa).then(resp => {
      this.quadroSociais = resp.data;
      this.atualizaBloqueoCamposQs();
      this.obterParametrosAdicionais();
    });
  }

  // SOU-1046 - Bloquear Alteração para OE e Cooperativa

  public isUsuarioNacional() {
    return !this.usuario.isUsuarioNacional;
  }



  private atualizaBloqueoCamposQs(): void {
    if (this.quadroSociais) {
      this.quadroSociais.forEach(qs => {
        if (qs.id) {
          if (!qs.cooperadosMulheres && !qs.cooperadosHomens && qs.cooperadosPF) {
            qs.apenasTotalPF = true;
          }

          if (!qs.cooperadosMulheres && !qs.cooperadosHomens && !qs.cooperadosPF && !qs.cooperadosPJ && qs.cooperadosTotal) {
            qs.apenasTotalPF = false;
            qs.apenasTotalCooperados = true;
          }

          if (!qs.empregadosHomens && !qs.empregadosMulheres && qs.empregadosTotal) {
            qs.apenasTotalEmpregados = true;
          }
        }
      });
    }
  }

  somenteNumeros(valor) {
    let saida = null;
    if (valor != null) {
      let valorInteiro = parseInt((String(valor)).replace(/\D+/g, ''), 10);
      if ((typeof valorInteiro === 'number') && !isNaN(valorInteiro)) {
        if (valorInteiro > 99999999) {
          valorInteiro = 99999999;
        }
        saida = valorInteiro;

      }
    }
    return saida;
  }

  atualizarTotaisQuadroSocial(quadroSocialAtual: QuadroSocial) {

    if (quadroSocialAtual != null) {
      this.normalizarQuadroSocial(quadroSocialAtual);

      if (!quadroSocialAtual.apenasTotalPF) {
        if ((typeof quadroSocialAtual.cooperadosHomens === 'number') || (typeof quadroSocialAtual.cooperadosMulheres === 'number')) {
          quadroSocialAtual.cooperadosPF = quadroSocialAtual.cooperadosHomens + quadroSocialAtual.cooperadosMulheres;
        } else {
          quadroSocialAtual.cooperadosPF = null;
        }
      }

      // Se preencheu os dois, então calcula o total
      if ((typeof quadroSocialAtual.cooperadosPF === 'number') || (typeof quadroSocialAtual.cooperadosPJ === 'number')) {
        quadroSocialAtual.cooperadosTotal = quadroSocialAtual.cooperadosPF + quadroSocialAtual.cooperadosPJ;
      } else {
        quadroSocialAtual.cooperadosTotal = null;
      }

      if (!this.adicionarQuantidadeTotal) {
        if ((typeof quadroSocialAtual.empregadosHomens === 'number') || (typeof quadroSocialAtual.empregadosMulheres === 'number')) {
          quadroSocialAtual.empregadosTotal = quadroSocialAtual.empregadosHomens + quadroSocialAtual.empregadosMulheres;
        } else {
          quadroSocialAtual.empregadosTotal = null;
        }
      }

    }

  }

  private obterParametrosAdicionais() {
    const options = this.carregaOptionsParametro('0', '999', 'id', 'asc');
    this.quadroSocialService.getParametroQuadroSocialPaginado(options).then(p => {
      if (p && p.content) {
        this.parametrosQuadroSocial = p.content;
        this.obterQuadrosSocialParametroQuadro();
      }
    });
  }

  normalizarQuadroSocial(quadroSocialAtual: QuadroSocial) {
    quadroSocialAtual.cooperadosPF = this.somenteNumeros(quadroSocialAtual.cooperadosPF);
    quadroSocialAtual.cooperadosPJ = this.somenteNumeros(quadroSocialAtual.cooperadosPJ);
    quadroSocialAtual.empregadosHomens = this.somenteNumeros(quadroSocialAtual.empregadosHomens);
    quadroSocialAtual.empregadosMulheres = this.somenteNumeros(quadroSocialAtual.empregadosMulheres);
    quadroSocialAtual.empregadosTotal = this.somenteNumeros(quadroSocialAtual.empregadosTotal);
    quadroSocialAtual.cooperadosHomens = this.somenteNumeros(quadroSocialAtual.cooperadosHomens);
    quadroSocialAtual.cooperadosMulheres = this.somenteNumeros(quadroSocialAtual.cooperadosMulheres);
  }

  salvar() {
    this.houveAlteracaoForm = true;
    for (const quadroSocialAtual of this.quadroSociais) {
      if (!quadroSocialAtual.apenasTotalPF
        && quadroSocialAtual.cooperadosHomens !== null
        && quadroSocialAtual.cooperadosHomens > 0
        && quadroSocialAtual.cooperadosMulheres === null) {

        this.messageService.add({ severity: 'warn', detail: `Preencha todos os campos de quantidade de cooperados do quadro ano referência: ${quadroSocialAtual.ano}`, life: 10000 });
        return;
      }

      if (!quadroSocialAtual.apenasTotalPF
        && quadroSocialAtual.cooperadosMulheres !== null
        && quadroSocialAtual.cooperadosMulheres > 0
        && quadroSocialAtual.cooperadosHomens === null) {

        this.messageService.add({ severity: 'warn', detail: `Preencha todos os campos de quantidade de cooperados do quadro ano referência: ${quadroSocialAtual.ano}`, life: 10000 });
        return;
      }
    }
    this.apiDadosGerais.salvaHistoricoQuadroSocial(this.idCooperativa, this.quadroSociais).then(resp => {
      this.quadroSociais = resp.data;
      this.evtSalvar.emit();
    });
  }

  houveMudancaForm() {
    this.houveAlteracaoForm = true;
  }

  regraTotais(valor, total): number {
    let saida = null;
    if (valor != null) {
      let valorInteiro = parseInt((String(valor)).replace(/\D+/g, ''), 10);
      const valorTotal = parseInt((String(total)).replace(/\D+/g, ''), 10);
      if ((!Number.isNaN(valorInteiro) && !Number.isNaN(valorInteiro)) && (!Number.isNaN(valorTotal) && !Number.isNaN(valorTotal))) {
        if (valorInteiro > valorTotal) {
          valorInteiro = valorTotal;
        }
        saida = valorInteiro;

      }
    }
    return saida;
  }

  private obterQuadrosSocialParametroQuadro(): void {

    const parametroQuadro: QuadroSocialParametroQuadro[] =
      this.quadroSociais.map(q => ({
        idQuadroSocialParametroQuadro: {
          sqQuadroSocial: q.id,
          sqParametroQuadroSocial: null
        },
        quantidade: null
      }));

    this.quadroSociais = this.quadroSociais.map(q => ({
      ...q,
      parametroQuadros: this.parametrosQuadroSocial.map(p => ({
        idQuadroSocialParametroQuadro: {
          sqParametroQuadroSocial: p.id,
          sqQuadroSocial: q.id
        },
        quantidade: null
      }))
    }));

    this.quadroSocialService
      .buscarQuadroParametrosPorQuadrosSociais(parametroQuadro)
      .then(r => {

        if (!r) {
          return;
        }

        // buscarQuadroParametrosPorQuadrosSociais (public) está tipado como IServiceResponse<any>,
        // mas o backend retorna a lista diretamente, sem wrapper.
        this.quadroSocialParametroQuadro = [...(r as unknown as QuadroSocialParametroQuadro[])];

        this.quadroSociais = this.quadroSociais.map(q => ({
          ...q,
          parametroQuadros: q.parametroQuadros.map(pq => {
            const encontrado = this.quadroSocialParametroQuadro.find(qsp =>
              qsp.idQuadroSocialParametroQuadro.sqParametroQuadroSocial ===
                pq.idQuadroSocialParametroQuadro.sqParametroQuadroSocial &&
              qsp.idQuadroSocialParametroQuadro.sqQuadroSocial ===
                pq.idQuadroSocialParametroQuadro.sqQuadroSocial
            );

            return {
              ...pq,
              quantidade: encontrado?.quantidade ?? null
            };
          })
        }));

      });

  }

  private carregaOptionsParametro(pagina: string, nrLinhas: string, sortField: string, sortOrder: string) {
    const options = {
      params: new HttpParams()
        .set('page', pagina)
        .set('size', nrLinhas)
        .set('sort', `${sortField},${sortOrder}`),
      reportProgress: true,
    };

    options.params = this.utilityService.carregaParamsString(true, options.params, 'ativo');

    return options;
  }

  limparCamposCooperadosQuadroSocial(quadroSocialAtual: QuadroSocial): void {
    if (quadroSocialAtual.apenasTotalPF) {
      quadroSocialAtual.cooperadosHomens = null;
      quadroSocialAtual.cooperadosMulheres = null;
    } else {
      quadroSocialAtual.cooperadosPF = null;
    }
  }

  get isNacional() {
    return this.usuario.isUsuarioNacional;
  }

  get isEstadual() {
    return this.usuario.isUsuarioEstadual;
  }

  camposDisponiveis(quadroSocial: QuadroSocial) {
    if (!this.isNacional) {
      return true;
    }
  }


}
