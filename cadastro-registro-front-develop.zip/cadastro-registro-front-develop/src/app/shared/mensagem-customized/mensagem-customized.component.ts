import { ChangeDetectionStrategy, Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-mensagem-customized',
  templateUrl: './mensagem-customized.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mensagem-customized.component.css']
})
export class MensagemCustomizedComponent implements OnInit {

  @Input()
  mensagem = '';
  @Input()
  tipo: string;

  constructor() { }

  ngOnInit() {
  }

}
