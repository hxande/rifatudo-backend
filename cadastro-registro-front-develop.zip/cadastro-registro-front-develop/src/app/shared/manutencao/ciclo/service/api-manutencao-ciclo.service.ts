import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Negocio } from '../../../../entities/Negocio';
import { IServiceResponse } from '../../../../entities/IResponse';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiManutencaoCicloService {
  constructor(private http: HttpClient) { }

  getCicloAtual(idCooperativa: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<number>>(`/cadastro-registro-api/api/v1/periodo-atualizacao/periodo-atualizacao/periodo-atual/response/${idCooperativa}`)
    );
  }
}
