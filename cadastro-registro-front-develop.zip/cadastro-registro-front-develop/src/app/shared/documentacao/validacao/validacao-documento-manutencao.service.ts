import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';


@Injectable({
  providedIn: 'root',
})
export class ValidacaoDocumentoManutencao {
  constructor(
    private validacaoDados: ValidacaoDados
  ){}


  podeVerAbaDocumentoBotaoUpload() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()

    )){
      return true;
    }

    return false;
  }

}
