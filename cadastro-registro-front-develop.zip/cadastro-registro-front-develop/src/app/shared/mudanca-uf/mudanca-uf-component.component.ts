import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, Input, Output, EventEmitter, ViewChild, OnChanges, SimpleChanges, inject } from '@angular/core';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { ApiMudancaUFService } from '@cadastro-registro-api/services/api-mudanca-uf.service';
import { SolicitacaoMudancaoEndereco } from '@cadastro-registro-api/models/SolicitacaoMudancaoEndereco';
import { FileUploadComponent } from '@gui/file-upload/file-upload/file-upload.component';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Router } from '@angular/router';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';

@Component({
  selector: 'app-mudanca-uf-component',
  templateUrl: './mudanca-uf-component.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./mudanca-uf-component.component.css'],
})
export class MudancaUfComponentComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  constructor(
    private dadosGeraisService: ApiManutencaoDadosGeraisService,
    private apiMudancaUF: ApiMudancaUFService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiValidacaoDados: ApiValidacaoDadosService,
    public kcService: KeycloakService,
    private router: Router
  ) { }
  enderecos: Endereco[];
  indexEnderecoPrincipal: number = null;
  @Input()
  cooperativa: number;
  @Output() carregaSolicitacao = new EventEmitter<boolean>();
  @Output() concluirParecer = new EventEmitter<number>();
  mapPendencias: Map<string, boolean> = new Map();

  podeAlterarEndereco = false;
  modalReprovarMudancaUF = false;

  solicitacaoMudanca: SolicitacaoMudancaoEndereco;
  solicitaoEnviada = false;
  @Input() estaAprovado = false;
  reprovar = false;
  @ViewChild('fileup')
  fileup: FileUploadComponent;

  ngOnInit() {
    this.carregarTela();
  }

  carregarTela() {
    // Endereços
    // UFs
    this.apiMudancaUF.buscaSolicitacaoMudancaUF(this.cooperativa).then((res) => {
      this.solicitacaoMudanca = res.data;
      this.setMunicipio();
      this.verificarLiberacaoCampos();
      this.changeDetectorRef.markForCheck();
    });




  }

  setMunicipio() {
    this.dadosGeraisService.getEnderecos(this.cooperativa).then((res) => {
      if (res && res.data != null) {
        const data = res.data;
        this.enderecos = data;
        this.indexEnderecoPrincipal = this.enderecos.findIndex(e => e.tipoEndereco.enderecoPrincipal);
        this.enderecos.forEach((end) => {
          if (end.idMunicipio) {
            this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {
              end.municipio = resEnd;

              // Adicionando UF
              if (end.municipio != null && end.municipio.id) {
                end.uf = end.municipio.uf;
              }
              this.changeDetectorRef.markForCheck();
            });
          }
        });
        this.solicitacaoMudanca.enderecos = this.solicitacaoMudanca.enderecosRequerentes.length > 0 ?
          this.solicitacaoMudanca.enderecosRequerentes
          : this.enderecos;

      }
      this.changeDetectorRef.markForCheck();
    });
  }

  verificarLiberacaoCampos() {
    if (this.cooperativa) {
      this.apiValidacaoDados.obterUltimasPendenciasChaveManutencao(this.cooperativa).then((res) => {
        this.mapPendencias = res.data;
        this.podeAlterarEndereco =
          !this.mapPendencias['MANUTENCAO_DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA'] &&
          this.solicitacaoMudanca.podeEditarEndereco;
        this.changeDetectorRef.markForCheck();
      });
    }
  }


  resetaFileUpload() {
    this.fileup.carregarArquivos();
  }

  aprovaSolicitacao() {
    this.solicitacaoMudanca.enderecosRequerentes = this.solicitacaoMudanca.enderecos;
    this.apiMudancaUF.aprovaSolicitacao(this.cooperativa, this.solicitacaoMudanca).then((response) => {
      this.carregarTela();
      this.concluirParecer.emit(this.cooperativa);
      this.carregaSolicitacao.emit(false);
      this.solicitacaoMudanca = response.data;
      this.changeDetectorRef.markForCheck();
    });
  }

  reprovaSolicitacao() {
    this.apiMudancaUF.reprovaSolicitacao(this.cooperativa, this.solicitacaoMudanca).then((response) => {
      this.modalReprovarMudancaUF = false;
      this.router.navigate(['/transferencia-uf']);
      this.changeDetectorRef.markForCheck();
    });
  }


  criaSolicitacao() {
    this.solicitacaoMudanca.enderecosRequerentes = this.solicitacaoMudanca.enderecos;
    if (this.solicitacaoMudanca.id === null || this.solicitacaoMudanca.id === undefined) {
      this.solicitacaoMudanca.enderecosRequerentes.forEach(e => e.id = null);
    }
    this.apiMudancaUF.criaSolicitacaoMudancaUF(this.cooperativa, this.solicitacaoMudanca).then((response) => {
      this.carregarTela();
      this.carregaSolicitacao.emit(true);
      this.changeDetectorRef.markForCheck();
    });
  }

  setCorrespondenciaDiferente(correspondenciaDiferente: boolean){
    if(correspondenciaDiferente){
      this.enderecos.forEach(e => e.correspondenciaDiferente = correspondenciaDiferente);
    } else{
      this.limpaEnderecoCorrespondencia();
    }
  }

  limpaEnderecoCorrespondencia(){
    this.solicitacaoMudanca.enderecos[1].cep = null;
    this.solicitacaoMudanca.enderecos[1].uf = null;
    this.solicitacaoMudanca.enderecos[1].idEstado = null;
    this.solicitacaoMudanca.enderecos[1].municipio = null;
    this.solicitacaoMudanca.enderecos[1].idMunicipio = null;
    this.solicitacaoMudanca.enderecos[1].enderecoReferencia = null;
    this.solicitacaoMudanca.enderecos[1].numero = null;
    this.solicitacaoMudanca.enderecos[1].complemento = null;
    this.solicitacaoMudanca.enderecos[1].bairro = null;
    this.solicitacaoMudanca.enderecos[1].correspondenciaDiferente = false;
  }
}
