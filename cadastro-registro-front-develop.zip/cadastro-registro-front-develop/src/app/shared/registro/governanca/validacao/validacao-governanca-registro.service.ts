import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable({ providedIn: 'root' })
export class ValidacaoGovernancaRegistro {
    constructor(private validacaoDados: ValidacaoDados) {}

    podeSalvarGovernanca() {
        if (this.validacaoDados.podeVerEditarCooperativa()) {
            return true;
        }

        return false;
    }
}
