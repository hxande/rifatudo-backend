import { KeycloakService } from 'src/app/services/keycloak-service/KeycloakService';
import { Injectable } from '@angular/core';
import { SubPerfisEnum } from 'src/app/services/keycloak-service/SubPerfisEnum';
import { ValidacaoDados } from '../../../validacaoDados/validacao/validacao-dados.service';

@Injectable({
  providedIn: 'root'
})
export class ValidacaoDadosGerais {
  constructor(
    private keycloakService: KeycloakService,
    private validacaoDados: ValidacaoDados
  ){}


  podeAbaDadosGerais() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }
    return false;
  }


}
