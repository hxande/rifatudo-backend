import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';


@Injectable({
  providedIn: 'root',
})
export class ValidacaoCadastroRegistro {
  constructor(
    private keycloakService: KeycloakService
  ){}

  podeVerAbaSubmeterBotaoDeferir() {
    if(
    (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return true;
    }

    return false;
  }

  podeVerAbaSubmeterBotaoIndeferir() {
    if(
    (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return true;
    }

    return false;
  }


  podeVerAbaSubmeterBotaoValidarDados() {
    if(
    (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES)
    )){
      return true;
    }

    return false;
  }

}
