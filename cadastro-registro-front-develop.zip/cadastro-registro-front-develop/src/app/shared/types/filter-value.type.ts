import { FilterOptionValue } from "./filter-option.type";

export type FilterValue = string | number | boolean | FilterOptionValue | null | undefined;
