export type FilterOptionValue = { value: string | number | boolean };
