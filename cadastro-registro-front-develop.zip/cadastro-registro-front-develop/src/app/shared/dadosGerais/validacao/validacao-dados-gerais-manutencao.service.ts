import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable()
export class ValidacaoDadosGeraisManutencao {
  constructor(
    private validacaoDados: ValidacaoDados
  ){

  }

  podeVerAbaBotaoExcluirMandato() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }


    return false;
  }


  podeVerAbaHistoricoQuadroSocial() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }

    return false;
  }


  podeAbaDadosGerais() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }

    return false;
  }

}
