import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabHeaderIconCheckComponent } from './tab-header-icon-check.component';

describe('TabHeaderIconCheckComponent', () => {
  let component: TabHeaderIconCheckComponent;
  let fixture: ComponentFixture<TabHeaderIconCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabHeaderIconCheckComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TabHeaderIconCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
