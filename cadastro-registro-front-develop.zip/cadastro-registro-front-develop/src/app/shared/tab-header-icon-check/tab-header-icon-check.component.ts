import { AfterViewInit, ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-header-icon-check',
  templateUrl: './tab-header-icon-check.component.html',
  styleUrls: ['./tab-header-icon-check.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class TabHeaderIconCheckComponent{

  @Input() tabTitle: string;
  @Input() iconTitle: string;
  @Input() valid: boolean;
  @Input() confirmada = false;
  @Input() podeSubmeterAnuario!: boolean;


}
