import { Component, OnInit, Input, EventEmitter, Output, ViewChild, ElementRef, Inject, ChangeDetectorRef, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { InputMask } from 'primeng/inputmask';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ValidacaoFilial } from './validacao/validacao-averbacao.service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { ApiFilialService } from '@cadastro-registro-api/services/api-filial.services';
import { Municipio } from '@localizacao-api/models/Municipio';
import { Uf } from '@localizacao-api/models/Uf';
import { IPage } from '@utils/interfaces/IPage';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { DocumentacaoVO } from '@documentacao-api/models/DocumentacaoVO';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { MessageService } from 'primeng/api';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiUFService } from '@localizacao-api/services/api-uf.service';
import { ApiCooperativaLeituraService } from '@cadastro-registro-leitura-api/services/api-cooperativa-leitura.service';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { EnderecoConsultaTO } from 'src/app/api/models/EnderecoConsultaTO';

@Component({
    selector: 'app-averbacao',
    templateUrl: './averbacao.component.html',
    styleUrls: ['./averbacao.component.css']
})
export class AverbacaoComponent implements OnInit {

  private changeDetectorRef = inject(ChangeDetectorRef);

    cnpjMatriz: string;
    filiada: PessoaJuridicaBasicaTO;
    listaUfs: Uf[] = [];
    listaMunicipios: Municipio[] = [];
    cooperativa: Cooperativa;
    pessoaJuridica: PessoaJuridica;
    idDocumentoAta: number;
    documentacaoVO: DocumentacaoVO = null;
    houveMudanca = false;
    bloquearPorError = false;
    bloquearBotaoSalvar = false;
    @ViewChild('filialForm') filialForm: NgForm;
    @ViewChild('numeroInput') numeroInput: ElementRef;
    @ViewChild('telefoneInput') telefoneInput: InputMask;
    @ViewChild('cnpjInput') cnpjInput: InputMask;
    @ViewChild('cnpjInputMatriz') cnpjInputMatriz: InputMask;
    @ViewChild('cepInput') cepInput: InputMask;
    @ViewChild('emailInput') emailInput: ElementRef;
    @ViewChild('bairroInput') bairroInput: ElementRef;

    @Input() filial: PessoaJuridicaBasicaTO;
    @Input() podeModificarOsCampos: boolean = false;
    @Output() cancelar = new EventEmitter<number>();
    @Output() adicionarFilial = new EventEmitter<PessoaJuridicaBasicaTO>();
    @Output() erroSalvar = new EventEmitter<boolean>();

    edicaoFilial: boolean = false;

    constructor(private filialApi: ApiFilialService,
        private utilityService: UtilityService,
        private dadosGeraisService: ApiDadosGeraisService,
        private apiDocumentoService: ApiDocumentoService,
        private uploadApi: ApiFileUploadService,
        public validacaoFilial: ValidacaoFilial,
        private messageService: MessageService,
        private keycloakService: KeycloakService,
        private apiUFService: ApiUFService,
        private apiCooperativaLeituraService: ApiCooperativaLeituraService
    ) { }

    ngOnInit() {
        this.carregaTela();
        this.edicaoFilial = false;
    }

    carregaTela() {
        this.inicializaFilial();
    }

    inicializaFilial() {
        this.filiada = new PessoaJuridicaBasicaTO();
        this.cnpjMatriz = "";
        this.filiada.ramo = new Ramo;
        this.filiada.endereco = new Endereco();
        this.filiada.endereco.uf = new Uf();
        this.filiada.endereco.municipio = new Municipio();
        this.filiada.endereco.numero = null;

        if (!this.filiada.id) {
            this.apiDocumentoService.getDocumentacaoNovaFilial().then((res) => {
                if (res && res.data != null) {
                    this.documentacaoVO = res.data;
                }
            });
        }

        if (this.keycloakService.isUsuarioNacional) {
            this.apiUFService.buscarUfs().then((res) => {
                this.listaUfs = (res as unknown as IPage<Uf>).content;
            });
        } else if (this.keycloakService.isUsuarioEstadual) {
            this.apiUFService.buscarUfPelaSigla(this.keycloakService.getUF()).then((res) => {
                this.listaUfs = [res];
                this.dadosGeraisService.buscarMunicipiosByIdUf(res.id).then((res1) => {
                    this.podeModificarOsCampos = true;
                    this.listaMunicipios = res1.content;
                });
            });
        } else {
            this.listaUfs = [];
        }

    }

    carregaPessoaJuridicaMatriz() {
        let cnpj = this.cnpjMatriz;
        if (cnpj != undefined && cnpj.replace(/(\.|\-|\/)*/g, '').trim() != "") {
            cnpj = cnpj.replace(/(\.|\-|\/)*/g, '');
            this.dadosGeraisService.getPessoaJuridicaPorCnpjSincronizada(cnpj).then((res) => {
                if (res) {
                    let httpParams = new HttpParams()
                        .set('cnpj', cnpj)
                        .set('uf', res.ufSigla);
                    const options = { params: httpParams }
                    this.apiCooperativaLeituraService.buscarCooperativasRegistradasListagemUfUsuarioNaoLogado(options).subscribe((res2) => {
                        if (res2.data && res2.data.content && res2.data.content.length >= 1) {
                            this.pessoaJuridica = res;

                            this.bloquearPorError = false;

                            this.carregaDocumento(this.pessoaJuridica);

                        } else {
                            this.messageService.clear();
                            this.messageService.add({ severity: 'error', detail: 'Esse CNPJ não possui registro.', life: 10000 });
                            this.bloquearPorError = true;
                        }
                    });
                }
            }).catch((err) => {
                this.messageService.clear();
                this.messageService.add({ severity: 'error', detail: 'Esse CNPJ não possui registro.', life: 10000 });
                this.bloquearPorError = true;
            });
        }

    }

    carregaDadosEndereco(end) {
        this.filiada.endereco.id = end.id;
        this.filiada.endereco.cep = end.cep;
        this.filiada.endereco.pessoa = end.pessoa;
        this.filiada.endereco.enderecoReferencia = end.enderecoReferencia;
        this.filiada.endereco.complemento = end.complemento;
        this.filiada.endereco.bairro = end.bairro;
        this.filiada.endereco.tipoEndereco = end.tipoEndereco;
        this.filiada.endereco.numero = end.numero;

        if (end.idMunicipio) {
            this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {
                if (resEnd != null && resEnd.id) {
                    this.listaUfs = [resEnd.uf];
                    this.filiada.endereco.uf = resEnd.uf;
                    this.filiada.endereco.idEstado = resEnd.uf.id;
                    this.listaMunicipios = this.buscarMunicipios(this.filiada.endereco.uf, resEnd);
                    this.filiada.endereco.idMunicipio = resEnd.id;
                }
            });
        }

    }

    checagemDadosRFB(cnpjFilial) {
        this.filialApi.enderecoRFB(cnpjFilial).then((res) => {
            if (res) {
                if (Array.isArray(res)) {
                    res.forEach((end) => {

                        if (end.tipoEndereco.enderecoPrincipal) {
                            this.carregaDadosEndereco(end);
                        }
                    });

                    this.podeModificarOsCampos = false;
                }
            } else {
                this.podeModificarOsCampos = true;
            }
        });
    }

    limparCamposEndereco() {
        this.filiada.endereco = new Endereco();
    }

    carregarPessoaJuridica() {
        this.filiada.cnpjValidado = false;
        if (this.filiada.cnpj) {
            let cnpj = this.cnpjMatriz;
            cnpj = cnpj.replace(/(\.|\-|\/)*/g, '').trim();
            let cnpjFilial = this.filiada.cnpj.replace(/(\.|\-|\/)*/g, '').trim();
            this.filialApi.validarCnpjFilialUF(cnpj, cnpjFilial).then((pjRes) => {
                this.filiada.email = "";
                this.filiada.telefone = "";
                if (pjRes) {
                    this.bloquearPorError = false;
                    this.edicaoFilial = true;
                    const pessoaJuridica = pjRes;

                    this.preenchePessoaJuridica(pessoaJuridica);
                    this.limparCamposEndereco();
                    this.checagemDadosRFB(cnpjFilial);

                    this.apiDocumentoService.getDocumentacaoFilial(pessoaJuridica.id).then((res) => {

                        if (res && res.data != null) {
                            this.documentacaoVO = res.data;
                        }
                    });

                } else {
                    this.bloquearPorError = false;
                    this.filiada.cnpjValidado = true;
                    this.messageService.clear();
                    this.limparCamposEndereco();

                    this.checagemDadosRFB(cnpjFilial);

                }
            }).catch((res) => {
                this.bloquearPorError = true;
            });
        }

    }

    selectMask(event: Event) {
        setTimeout(() => (event.target as HTMLInputElement).select(), 100);
    }

    procurarLocalizacao(event, index?) {
        let busca = event.value;
        if (busca) {
            busca = this.utilityService.retirarFormatacao(busca);
            this.dadosGeraisService.buscarEndereco(busca).subscribe((res) => {
                if (res != null && this.filiada.endereco != null) {
                    this.bloquearBotaoSalvar = false;
                    if (this.listaUfs.length == 1 && res.municipio.uf.id != this.listaUfs[0].id) {
                        this.bloquearBotaoSalvar = true;
                        this.messageService.add({ severity: 'error', detail: 'O CEP não corresponde ao estado e à cidade permitidos.', life: 10000 });
                        return;
                    }
                    const endereco = res;
                    this.filiada.endereco.pessoa = endereco.pessoa;
                    this.filiada.endereco.enderecoReferencia = endereco.logradouro;
                    this.filiada.endereco.complemento = endereco.complemento;
                    this.filiada.endereco.bairro = endereco.bairro;
                    this.filiada.endereco.municipio = endereco.municipio;

                    if (endereco.municipio) {
                        this.filiada.endereco.idEstado = endereco.municipio.uf.id;
                        this.filiada.endereco.idMunicipio = endereco.municipio.id;
                        this.filiada.endereco.uf = endereco.municipio.uf;
                        if (this.filiada.endereco.uf) {
                            this.buscarMunicipios(this.filiada.endereco.uf, null);
                        }
                    }
                }
            });
        }
    }

    buscarMunicipios(uf: Uf, resEnd) {
        let saida = null;

        if (uf != null && uf.id) {
            this.dadosGeraisService.buscarMunicipiosByIdUf(uf.id).then((mun) => {
                this.listaMunicipios = mun.content;
                if (resEnd != null) {
                    this.filiada.endereco.municipio = resEnd;
                }
            });
        }
        return saida;
    }


    cancelarFilial() {
        this.filialForm.reset();
        this.inicializaFilial();
        this.limparValidacaoForm();
        this.cancelar.emit();
    }

    onConcluirUpload(chaveRepositorio: string) {
        this.houveMudanca = true;

        const repositorios: string[] = [chaveRepositorio];

        this.uploadApi.consultaArquivosNaoPaginado(repositorios)
        .then(responseDocumento => {
            this.filiada.arquivos = responseDocumento.content;
        });
    }

    salvaFilial() {

        if (!this.filiada.cnpjValidado) {
            this.messageService.add({ severity: 'error', detail: 'CNPJ inválido!', life: 10000 });
            return;
        }

        this.houveMudanca = true;
        this.filiada.nomeFantasia = this.pessoaJuridica.nomeFantasia;
        this.filiada.razaoSocial = this.pessoaJuridica.razaoSocial;
        this.filiada.ufSigla = this.filiada.endereco.uf.sigla;
        this.filiada.endereco.cep = this.utilityService.retirarFormatacao(this.filiada.endereco.cep);
        this.filiada.ramo = this.pessoaJuridica.ramo;
        if (this.filiada.endereco && this.filiada.endereco.municipio) {
            this.filiada.endereco.idEstado = this.filiada.endereco.municipio.uf.id;
            this.filiada.endereco.idMunicipio = this.filiada.endereco.municipio.id;
        }
        this.filiada.documentacaoJson = (this.documentacaoVO && this.documentacaoVO.documentos.length !== 0) ? JSON.stringify(this.documentacaoVO) : null;

        this.filialApi.cadastroFilialAverbacao(this.filiada).then((res) => {
            if (res.data) {
                this.messageService.clear();
                this.filiada = res.data;
                this.filialApi.vinculaFilialAverbacaoMatriz(this.pessoaJuridica.id, this.filiada).then((res) => {
                    this.messageService.clear();
                    this.messageService.add({ severity: 'success', detail: 'Registro Salvo com sucesso !', life: 10000 });
                    this.adicionaFilial();
                });

            }
        }).catch(() => {
            this.erroSalvar.emit(true);
        });


    }

    salvaFilialEdicao() {
        if (!this.filiada.cnpjValidado) {
            this.messageService.add({ severity: 'error', detail: 'CNPJ inválido!', life: 10000 });
            return;
        }

        this.houveMudanca = true;
        this.filiada.nomeFantasia = this.pessoaJuridica.nomeFantasia;
        this.filiada.razaoSocial = this.pessoaJuridica.razaoSocial;
        this.filiada.ufSigla = this.filiada.endereco.uf.sigla;
        this.filiada.endereco.cep = this.utilityService.retirarFormatacao(this.filiada.endereco.cep);
        this.filiada.ramo = this.pessoaJuridica.ramo;
        if (this.filiada.endereco && this.filiada.endereco.municipio) {
            this.filiada.endereco.idEstado = this.filiada.endereco.municipio.uf.id;
            this.filiada.endereco.idMunicipio = this.filiada.endereco.municipio.id;
        }
        this.filiada.documentacaoJson = (this.documentacaoVO && this.documentacaoVO.documentos.length !== 0) ? JSON.stringify(this.documentacaoVO) : null;

        this.filiada.ufSigla = this.filiada.endereco.uf.sigla;

        this.filialApi.updateFilial(this.filiada).then((resp) => {
            if (resp.data) {
                this.filialApi.vinculaFilialAverbacaoMatriz(this.pessoaJuridica.id, this.filiada).then((res) => {
                    this.filiada.id = resp.data.id;
                    if (this.documentacaoVO && this.documentacaoVO.documentos.length !== 0) {
                        this.documentacaoVO.idPessoa = this.filiada.id;
                        if (!this.filiada.arquivos) {
                            this.filiada.arquivos = new Array();
                            const repositorios: string[] = this.documentacaoVO.documentos
                            .map(docVo => docVo.upload);

                            this.uploadApi.consultaArquivosNaoPaginado(repositorios).then(responseDocumento => {
                                this.filiada.arquivos = responseDocumento.content;

                                this.adicionaFilial();
                            });
                        } else {
                            this.adicionaFilial();
                        }
                    } else {
                        this.adicionaFilial();
                    }
                    this.messageService.clear();
                    this.messageService.add({ severity: 'success', detail: 'Registro Salvo com sucesso !', life: 10000 });
                });
            }
        }).catch(() => {
            this.erroSalvar.emit(true);
            this.edicaoFilial = true;
        });

        this.edicaoFilial = false;
    }

    adicionaFilial() {
        this.inicializaFilial();
        this.limparValidacaoForm();
        this.cancelar.emit();
    }

    limparValidacaoForm() {
        this.numeroInput.nativeElement.classList.remove('ng-dirty');
        this.emailInput.nativeElement.classList.remove('ng-dirty');
        this.bairroInput.nativeElement.classList.remove('ng-dirty');
        this.cnpjInput.el.nativeElement.classList.remove('ng-dirty');
        this.cepInput.el.nativeElement.classList.remove('ng-dirty');
        this.telefoneInput.el.nativeElement.classList.remove('ng-dirty');
    }

    preenchePessoaJuridica(pessoaJuridica: PessoaJuridicaBasicaTO) {
        this.filiada.id = pessoaJuridica.id;
        this.filiada.cnpj = pessoaJuridica.cnpj;
        this.filiada.cnpjValidado = true;
        this.filiada.email = pessoaJuridica.email;
        this.filiada.nomeFantasia = pessoaJuridica.nomeFantasia;
        this.filiada.ramo = pessoaJuridica.ramo;
        this.filiada.razaoSocial = pessoaJuridica.razaoSocial;
        this.filiada.telefone = pessoaJuridica.telefone;
        this.filiada.ufSigla = pessoaJuridica.ufSigla;
        this.filiada.tipoPessoa = pessoaJuridica.tipoPessoa;

        if (pessoaJuridica.endereco) {
            this.filiada.endereco = pessoaJuridica.endereco;
            this.filiada.endereco.municipio = pessoaJuridica.endereco.municipio;
            this.filiada.endereco.numero = pessoaJuridica.endereco.numero;
            this.filiada.endereco.bairro = pessoaJuridica.endereco.bairro;
            this.filiada.endereco.complemento = pessoaJuridica.endereco.complemento;
        }

    }

    preencheEndereco(endereco: EnderecoConsultaTO) {
        this.filiada.endereco.cep = endereco.cep;
        this.filiada.endereco.pessoa = endereco.pessoa;
        this.filiada.endereco.enderecoReferencia = endereco.logradouro;
        this.filiada.endereco.complemento = endereco.complemento;
        this.filiada.endereco.bairro = endereco.bairro;
        this.filiada.endereco.municipio = endereco.municipio;

        if (endereco.municipio) {
            this.filiada.endereco.idEstado = endereco.municipio.uf.id;
            this.filiada.endereco.idMunicipio = endereco.municipio.id;
            this.filiada.endereco.uf = endereco.municipio.uf;

        }
    }

    carregaDocumento(filial: PessoaJuridica) {
        this.apiDocumentoService.listaAtivosFilial(true, TipoPessoaEnum.PJ).then(responsePage => {
            if (this.filial) {
                this.apiDocumentoService.getDocumentacao(this.filial.id).then((res) => {
                    if (res && res.data != null) {
                        this.documentacaoVO = res.data;
                    }
                });
            }
        });

    }
}
