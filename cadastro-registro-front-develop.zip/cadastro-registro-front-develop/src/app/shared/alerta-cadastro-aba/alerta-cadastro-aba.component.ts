import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CooperativaManutencaoStatus } from '@shared/cooperativa-manutencao/cooperativa-manutencao-status';

@Component({
  selector: 'app-alerta-cadastro-aba-component',
  templateUrl: './alerta-cadastro-aba.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./alerta-cadastro-aba.component.css'],
})
export class AlertaCadastroAbaComponent {
  @Input() situacaoAba: string;

  @Input() estadoPreenchimento: 'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null = null;

  readonly CooperativaManutencaoStatus = CooperativaManutencaoStatus;

  get possuiApontamento(): boolean {
    return this.situacaoAba === CooperativaManutencaoStatus.ALERTA || this.situacaoAba === CooperativaManutencaoStatus.AJUSTES;
  }
}
