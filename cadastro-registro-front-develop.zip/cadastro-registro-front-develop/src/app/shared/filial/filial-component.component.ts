import { ChangeDetectorRef, Component, OnInit, Input, EventEmitter, Output, ViewChild, ElementRef, Inject, inject } from '@angular/core';
import { NgForm } from '@angular/forms';
import { InputMask } from 'primeng/inputmask';
import { UtilityService } from '@utils/utility/utility.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ValidacaoFilial } from './validacao/validacao-filial.service';
import { Ramo } from '@cadastro-registro-api/models/Ramo';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { PessoaJuridicaBasicaTO } from '@cadastro-registro-api/models/PessoaJuridicaBasicaTO';
import { ApiFilialService } from '@cadastro-registro-api/services/api-filial.services';
import { Municipio } from '@localizacao-api/models/Municipio';
import { Uf } from '@localizacao-api/models/Uf';
import { TipoPessoaEnum } from '@cadastro-registro-api/models/TipoPessoaEnum';
import { DocumentacaoVO } from '@documentacao-api/models/DocumentacaoVO';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { ApiFileUploadService } from '@upload-api/services/file-upload.service';
import { MessageService } from 'primeng/api';
import { ApiManutencaoDadosGeraisService } from 'src/app/api/services/api-manutencao-dados-gerais.service';
import { EnderecoConsultaTO } from 'src/app/api/models/EnderecoConsultaTO';

@Component({
    selector: 'app-filial-component',
    templateUrl: './filial-component.component.html',
    styleUrls: ['./filial-component.component.css']
})
export class FilialComponentComponent implements OnInit {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    filiada: PessoaJuridicaBasicaTO;
    listaMunicipios: Map<number, Municipio[]> = new Map<number, Municipio[]>();
    listaUfs: Uf[] = [];
    cooperativa: Cooperativa;
    idDocumentoAta: number;
    documentacaoVO: DocumentacaoVO = null;
    houveMudanca = false;
    @ViewChild('filialForm') filialForm: NgForm;
    @ViewChild('numeroInput') numeroInput: ElementRef;
    @ViewChild('telefoneInput') telefoneInput: InputMask;
    @ViewChild('cnpjInput') cnpjInput: InputMask;
    @ViewChild('cepInput') cepInput: InputMask;
    @ViewChild('emailInput') emailInput: ElementRef;
    @ViewChild('bairroInput') bairroInput: ElementRef;

    @Input() filial: PessoaJuridicaBasicaTO;
    @Input() cooperativaId: string;
    @Input() podeModificarOsCampos: boolean;
    @Output() cancelar = new EventEmitter<number>();
    @Output() adicionarFilial = new EventEmitter<PessoaJuridicaBasicaTO>();
    @Output() erroSalvar = new EventEmitter<boolean>();

    edicaoFilial: boolean = false;

    constructor(private filialApi: ApiFilialService,
        private utilityService: UtilityService,
        private dadosGeraisService: ApiDadosGeraisService,
        private apiDocumentoService: ApiDocumentoService,
        private uploadApi: ApiFileUploadService,
        public validacaoFilial: ValidacaoFilial,
        private messageService: MessageService,
        private apiManutencaoDadosGeraisService: ApiManutencaoDadosGeraisService,
    ) { }

    ngOnInit() {
        this.carregaTela();
        this.edicaoFilial = false;  
    }

    carregaTela() {
        this.inicializaFilial();


        // UFs
        this.dadosGeraisService.buscarUfs().then((res) => {
            if (res && res.content != null) {
                this.listaUfs = res.content;
            }
            this.changeDetectorRef.markForCheck();
        });

        // cooperativa
        this.dadosGeraisService.getCooperativa(Number(this.cooperativaId)).then((res) => {
            if (res) {
                this.cooperativa = res.data;
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    inicializaFilial() {
        this.filiada = new PessoaJuridicaBasicaTO();
        this.filiada.ramo = new Ramo;
        this.filiada.endereco = new Endereco();
        this.filiada.endereco.uf = new Uf();
        this.filiada.endereco.municipio = new Municipio();
        this.filiada.endereco.numero = null;
        //  this.documentacaoVO = null;

        if (!this.filiada.id) {
            this.apiDocumentoService.getDocumentacaoNovaFilial().then((res) => {
                if (res && res.data != null) {
                    this.documentacaoVO = res.data;
                }
                this.changeDetectorRef.markForCheck();
            });
        }


    }

    editarFilial(filial: PessoaJuridicaBasicaTO) {

        this.edicaoFilial = true;

        if (filial.id) {
            this.preenchePessoaJuridica(filial);

            this.apiDocumentoService.listaAtivosFilial(true, TipoPessoaEnum.PJ).then(responsePage => {
                this.apiDocumentoService.getDocumentacaoFilial(filial.id).then((res) => {

                    if (res && res.data != null) {
                        this.documentacaoVO = res.data;
                    }
                    this.changeDetectorRef.markForCheck();
                });
            });

            this.dadosGeraisService.getEnderecos(filial.id).then((res) => {

                if (res && res.data != null) {
                    const enderecos = res.data;

                    enderecos.forEach((end) => {

                        if (end.tipoEndereco.enderecoPrincipal) {

                            this.filiada.endereco.cep = end.cep;
                            this.filiada.endereco.pessoa = end.pessoa;
                            this.filiada.endereco.enderecoReferencia = end.enderecoReferencia;
                            this.filiada.endereco.complemento = end.complemento;
                            this.filiada.endereco.bairro = end.bairro;
                            this.filiada.endereco.municipio = end.municipio;
                            this.filiada.endereco.tipoEndereco = end.tipoEndereco;
                            this.filiada.endereco.numero = end.numero;

                            if (end.idMunicipio) {
                                this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {

                                    this.filiada.endereco.municipio = resEnd;

                                    // Adicionando UF
                                    if (this.filiada.endereco.municipio != null && this.filiada.endereco.municipio.id) {
                                        this.filiada.endereco.uf = this.filiada.endereco.municipio.uf;
                                        this.filiada.endereco.idEstado = this.filiada.endereco.uf.id;
                                        this.filiada.endereco.idMunicipio = this.filiada.endereco.municipio.id;

                                        this.buscarMunicipios(this.filiada.endereco.uf);
                                    }
                                    this.changeDetectorRef.markForCheck();
                                });
                            }
                        }
                    });
                }
                this.changeDetectorRef.markForCheck();
            });

        }
    }

    carregarPessoaJuridica() {
        this.filiada.cnpjValidado = false;

        if (this.filiada.cnpj) {
            this.filialApi.validarCnpjFilial(this.cooperativa.pessoaJuridica.cnpj, this.filiada.cnpj).then((pjRes) => {
                if (pjRes) {
                    this.edicaoFilial = true;
                    const pessoaJuridica = pjRes;

                    this.preenchePessoaJuridica(pessoaJuridica);
                    this.dadosGeraisService.getEnderecos(pessoaJuridica.id).then((res) => {

                        if (res && res.data != null) {
                            const enderecos = res.data;

                            enderecos.forEach((end) => {

                                if (end.tipoEndereco.enderecoPrincipal) {
                                    this.filiada.endereco.id = end.id;
                                    this.filiada.endereco.cep = end.cep;
                                    this.filiada.endereco.pessoa = end.pessoa;
                                    this.filiada.endereco.enderecoReferencia = end.enderecoReferencia;
                                    this.filiada.endereco.complemento = end.complemento;
                                    this.filiada.endereco.bairro = end.bairro;
                                    this.filiada.endereco.municipio = end.municipio;
                                    this.filiada.endereco.tipoEndereco = end.tipoEndereco;
                                    this.filiada.endereco.numero = end.numero;

                                    if (end.idMunicipio) {
                                        this.dadosGeraisService.buscarMunicipioPorId(end.idMunicipio).then((resEnd) => {
                                            if (resEnd != null && resEnd.id) {
                                                this.filiada.endereco.uf = resEnd.uf;
                                                this.filiada.endereco.idEstado = resEnd.uf.id;
                                                this.filiada.endereco.idMunicipio = resEnd.id;
                                                this.buscarMunicipios(this.filiada.endereco.uf);
                                            }
                                            this.changeDetectorRef.markForCheck();
                                        });
                                    }

                                }
                            });
                        }
                        this.changeDetectorRef.markForCheck();
                    });
                    this.apiDocumentoService.getDocumentacaoFilial(pessoaJuridica.id).then((res) => {

                        if (res && res.data != null) {
                            this.documentacaoVO = res.data;
                        }
                        this.changeDetectorRef.markForCheck();
                    });

                } else {
                  this.filiada.cnpjValidado = true;
                  this.edicaoFilial = false;
                }
            });
        }

    }

    selectMask(event: Event) {
        setTimeout(() => {
            (event.target as HTMLInputElement).select();
            this.changeDetectorRef.markForCheck();
        }, 100);
    }

    procurarLocalizacao(event, index?) {
        let busca = event.value;
        if (busca) {
            busca = this.utilityService.retirarFormatacao(busca);
            this.dadosGeraisService.buscarEndereco(busca).subscribe((res) => {
                if (res != null && this.filiada.endereco != null) {

                    const endereco = res;

                    // this.filiada.endereco.cep = endereco.cep;
                    this.filiada.endereco.pessoa = endereco.pessoa;
                    this.filiada.endereco.enderecoReferencia = endereco.logradouro;
                    this.filiada.endereco.complemento = endereco.complemento;
                    this.filiada.endereco.bairro = endereco.bairro;
                    this.filiada.endereco.municipio = endereco.municipio;

                    if (endereco.municipio) {
                        this.filiada.endereco.idEstado = endereco.municipio.uf.id;
                        this.filiada.endereco.idMunicipio = endereco.municipio.id;
                        this.filiada.endereco.uf = endereco.municipio.uf;
                        if (this.filiada.endereco.uf) {
                            this.buscarMunicipios(this.filiada.endereco.uf);
                        }
                    }
                }
                this.changeDetectorRef.markForCheck();
            });
        }
    }

    buscarMunicipios(uf: Uf) {
        let saida = null;

        if (uf != null && uf.id) {
            //  this.filiada.endereco.municipio = undefined;

            if (this.listaMunicipios[uf.id] == null || this.listaMunicipios[uf.id].length === 0) {
                this.dadosGeraisService.buscarMunicipiosByIdUf(uf.id).then((mun) => {
                    if (mun && mun.content != null) {
                        this.listaMunicipios.set(uf.id, mun.content);
                    }
                    this.changeDetectorRef.markForCheck();
                });
            }

            saida = this.listaMunicipios.get(uf.id);
        }
        return saida;
    }

    obterMunicipiosFiltrados(uf: Uf) {
        let saida = null;
        if (uf != null && uf.id) {
            saida = this.listaMunicipios.get(uf.id);
        }
        return saida;
    }


    cancelarFilial() {
        this.filialForm.reset();
        this.inicializaFilial();
        this.limparValidacaoForm();
        this.cancelar.emit();
        this.edicaoFilial = false;
    }

    onConcluirUpload(chaveRepositorio: string) {
        this.houveMudanca = true;

        const repositorios: string[] = [];
        repositorios.push(chaveRepositorio);

        this.uploadApi.consultaArquivosNaoPaginado(repositorios).then(responseDocumento => {
            this.filiada.arquivos = responseDocumento.content;
            this.changeDetectorRef.markForCheck();
        });
    }

    salvaFilial() {

        if (!this.filiada.cnpjValidado) {
          this.messageService.add({ severity: 'error', detail: 'CNPJ inválido!', life: 10000 });
          return;
        }

        this.houveMudanca = true;
        this.filiada.nomeFantasia = this.cooperativa.pessoaJuridica.nomeFantasia;
        this.filiada.razaoSocial = this.cooperativa.pessoaJuridica.razaoSocial;
        this.filiada.ufSigla = this.filiada.endereco.uf.sigla;
        this.filiada.endereco.cep = this.utilityService.retirarFormatacao(this.filiada.endereco.cep);
        this.filiada.ramo = this.cooperativa.pessoaJuridica.ramo;
        if (this.filiada.endereco && this.filiada.endereco.municipio) {
            this.filiada.endereco.idEstado = this.filiada.endereco.municipio.uf.id;
            this.filiada.endereco.idMunicipio = this.filiada.endereco.municipio.id;
        }
        this.filiada.documentacaoJson = (this.documentacaoVO && this.documentacaoVO.documentos.length !== 0) ? JSON.stringify(this.documentacaoVO) : null;

        this.filialApi.cadastroFilial(this.filiada).then((res) => {
            if (res.data) {
                this.filiada = res.data;
                this.adicionaFilial();
            }
            this.changeDetectorRef.markForCheck();
        }).catch(() => {
            this.erroSalvar.emit(true);
        });
    }

    salvaFilialEdicao() {
        if (!this.filiada.cnpjValidado) {
          this.messageService.add({ severity: 'error', detail: 'CNPJ inválido!', life: 10000 });
          return;
        }

        this.houveMudanca = true;
        this.filiada.nomeFantasia = this.cooperativa.pessoaJuridica.nomeFantasia;
        this.filiada.razaoSocial = this.cooperativa.pessoaJuridica.razaoSocial;
        this.filiada.ufSigla = this.filiada.endereco.uf.sigla;
        this.filiada.endereco.cep = this.utilityService.retirarFormatacao(this.filiada.endereco.cep);
        this.filiada.ramo = this.cooperativa.pessoaJuridica.ramo;
        if (this.filiada.endereco && this.filiada.endereco.municipio) {
            this.filiada.endereco.idEstado = this.filiada.endereco.municipio.uf.id;
            this.filiada.endereco.idMunicipio = this.filiada.endereco.municipio.id;
        }
        this.filiada.documentacaoJson = (this.documentacaoVO && this.documentacaoVO.documentos.length !== 0) ? JSON.stringify(this.documentacaoVO) : null;

        this.filiada.ufSigla = this.filiada.endereco.uf.sigla;

        this.filialApi.updateFilial(this.filiada).then((resp) => {
            if (resp.data) {
                this.filiada.id = resp.data.id;
                if (this.documentacaoVO && this.documentacaoVO.documentos.length !== 0) {
                    this.documentacaoVO.idPessoa = this.filiada.id;
                    if (!this.filiada.arquivos) {
                        this.filiada.arquivos = new Array();
                        const repositorios: string[] = [];
                        for (const docVo of this.documentacaoVO.documentos) {
                            repositorios.push(docVo.upload);
                        }

                        this.uploadApi.consultaArquivosNaoPaginado(repositorios).then(responseDocumento => {
                            this.filiada.arquivos = responseDocumento.content;

                            this.adicionaFilial();
                            this.changeDetectorRef.markForCheck();
                        });
                    } else {
                        this.adicionaFilial();
                        this.changeDetectorRef.markForCheck();
                    }
                } else {
                    this.adicionaFilial();
                }
            }
        }).catch(() => {
            this.erroSalvar.emit(true);
             this.edicaoFilial = true;
        });       
        
        this.edicaoFilial = false;
    }

    adicionaFilial() {
        this.adicionarFilial.emit(this.filiada);
        this.inicializaFilial();
        this.limparValidacaoForm();
        this.cancelar.emit();
    }

    limparValidacaoForm() {
        this.numeroInput.nativeElement.classList.remove('ng-dirty');
        this.emailInput.nativeElement.classList.remove('ng-dirty');
        this.bairroInput.nativeElement.classList.remove('ng-dirty');
        this.cnpjInput.el.nativeElement.classList.remove('ng-dirty');
        this.cepInput.el.nativeElement.classList.remove('ng-dirty');
        this.telefoneInput.el.nativeElement.classList.remove('ng-dirty');
    }

    preenchePessoaJuridica(pessoaJuridica: PessoaJuridicaBasicaTO) {
        this.filiada.id = pessoaJuridica.id;
        this.filiada.cnpj = pessoaJuridica.cnpj;
        this.filiada.cnpjValidado = true;
        this.filiada.email = pessoaJuridica.email;
        this.filiada.nomeFantasia = pessoaJuridica.nomeFantasia;
        this.filiada.ramo = pessoaJuridica.ramo;
        this.filiada.razaoSocial = pessoaJuridica.razaoSocial;
        this.filiada.telefone = pessoaJuridica.telefone;
        this.filiada.ufSigla = pessoaJuridica.ufSigla;
        this.filiada.tipoPessoa = pessoaJuridica.tipoPessoa;

        if (pessoaJuridica.endereco) {
            this.filiada.endereco = pessoaJuridica.endereco;
            this.filiada.endereco.municipio = pessoaJuridica.endereco.municipio;
            this.filiada.endereco.numero = pessoaJuridica.endereco.numero;
            this.filiada.endereco.bairro = pessoaJuridica.endereco.bairro;
            this.filiada.endereco.complemento = pessoaJuridica.endereco.complemento;
        }

    }

    preencheEndereco(endereco: EnderecoConsultaTO) {
        this.filiada.endereco.cep = endereco.cep;
        this.filiada.endereco.pessoa = endereco.pessoa;
        this.filiada.endereco.enderecoReferencia = endereco.logradouro;
        this.filiada.endereco.complemento = endereco.complemento;
        this.filiada.endereco.bairro = endereco.bairro;
        this.filiada.endereco.municipio = endereco.municipio;

        if (endereco.municipio) {
            this.filiada.endereco.idEstado = endereco.municipio.uf.id;
            this.filiada.endereco.idMunicipio = endereco.municipio.id;
            this.filiada.endereco.uf = endereco.municipio.uf;

        }
    }

    carregaDocumento(filial: PessoaJuridicaBasicaTO) {
        this.apiDocumentoService.listaAtivosFilial(true, TipoPessoaEnum.PJ).then(responsePage => {
            if (this.filial) {
                this.apiDocumentoService.getDocumentacao(this.filial.id).then((res) => {

                    if (res && res.data != null) {
                        this.documentacaoVO = res.data;
                    }
                    this.changeDetectorRef.markForCheck();
                });
            }
        });

    }

}
