import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, Input, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { ControlContainer, NgModelGroup } from '@angular/forms';
import { EstruturaIntegracaoParametroTo } from '@cadastro-registro-api/models/estrutura-integracao-parametro-to';
import { UtilityService } from '@utils/utility/utility.service';
import { EnumTipoUnidadeMedida } from '@cadastro-registro-leitura-api/models/EnumTipoUnidadeMedida';
import { StringUtil } from '@shared/utils/StringUtil';


@Component({
  selector: 'app-desempenho-lancamento-externo-params',
  templateUrl: './desempenho-lancamento-externo-params.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./desempenho-lancamento-externo-params.component.css'],
  viewProviders: [ { provide: ControlContainer, useExisting: NgModelGroup } ]
})
export class DesempenhoLancamentoExternoParamsComponent implements OnInit {

  @Input() parametros: EstruturaIntegracaoParametroTo[];
  @Input() preenchimentoObrigatorio: boolean;
  @Input() identificador: string;

  opcoesBoolean: SelectItem[];

  constructor(private utilityService: UtilityService) {
    this.opcoesBoolean = [
      {label: 'Sim', value: '1', icon: 'fa fa-check'},
      {label: 'Não', value: '-1', icon: 'fa fa-times'}
    ];
  }

  ngOnInit(): void {

  }

  isUnidadeMedidaTipoNumerico(param: EstruturaIntegracaoParametroTo) {
    return param && param.tipoUnidade === EnumTipoUnidadeMedida.NUMERO;
  }

  isUnidadeMedidaTipoTexto(param: EstruturaIntegracaoParametroTo) {
    return param && param.tipoUnidade === EnumTipoUnidadeMedida.TEXTO;
  }

  isUnidadeMedidaTipoData(param: EstruturaIntegracaoParametroTo) {
    return param && param.tipoUnidade === EnumTipoUnidadeMedida.DATA;
  }

  isUnidadeMedidaTipoBooleano(param: EstruturaIntegracaoParametroTo) {
    return param && param.tipoUnidade === EnumTipoUnidadeMedida.BOOLEANO;
  }

  podePreencherCampo(param: EstruturaIntegracaoParametroTo) {
    return param.podePreencher && !param.creditoAno;
  }

  maskOptions(param: EstruturaIntegracaoParametroTo) {
    return {
      prefix: '',
      precision: param && param.quantidadeCasasUnidade ? param.quantidadeCasasUnidade : 0,
      thousands: '.',
      decimal: ',',
      allowNegative : param.valoresNegativos,
    };
  }

  tratarData(data) {
    return this.utilityService.isDataValida(data) ? data : null;
  }

  formatarNomeId(nome) {

     nome = StringUtil.retiraAcentuacao(nome)
     nome = nome.replace(/\d/g, '');
     nome = nome.replace(/[^\w\s]/g, ' ');

     nome = nome.toLowerCase().trim();
     const nomes = nome.split(' ');

     return nomes.filter( p => p.length > 2 ).join('-')


}

tratarDataBlur(event: Event): void {
  const input = event.target as HTMLInputElement;
  input.value = this.tratarData(input.value);
}
}
