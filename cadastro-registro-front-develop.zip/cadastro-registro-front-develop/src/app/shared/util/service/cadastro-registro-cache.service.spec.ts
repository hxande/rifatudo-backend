import { TestBed } from '@angular/core/testing';

import { CadastroRegistroCacheService } from './cadastro-registro-cache.service';

describe('CadastroRegistroCacheService', () => {
  let service: CadastroRegistroCacheService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CadastroRegistroCacheService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
