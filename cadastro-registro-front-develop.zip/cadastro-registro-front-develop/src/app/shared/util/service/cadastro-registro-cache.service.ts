import { Injectable } from '@angular/core';
import { CacheSistemaService } from '@utils/cache/cache-sistema.service';


@Injectable({
  providedIn: 'root'
})
export class CadastroRegistroCacheService {

  sistema = 'cadastroregistro';
  initServico = false;
  constructor(private cacheSistema: CacheSistemaService) {

   }

  public getCache(funcionalidade:string, chave:string): unknown{
    return this.cacheSistema.get(this.sistema, funcionalidade, chave)
  }

  public setCache(funcionalidade:string, chave:string, value:unknown): void{
    this.cacheSistema.set(this.sistema, funcionalidade, chave, value)
  }

  public hasCache(funcionalidade:string, chave=''):boolean {
    return this.cacheSistema.has(this.sistema, funcionalidade, chave);
  }

  public deleteCache(funcionalidade:string, chave:string):void{
    this.cacheSistema.remove(this.sistema, funcionalidade, chave);
  }

}
