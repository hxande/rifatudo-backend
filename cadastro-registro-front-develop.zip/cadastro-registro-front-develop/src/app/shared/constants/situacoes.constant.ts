export const SITUACOES_OPTS = [
    { id: 1, label: 'Regular', value: 'REGULAR' },
    { id: 5,label: 'Irregular', value: 'IRREGULAR' },
    { id: 2,label: 'Suspenso', value: 'SUSPENSO' },
    { id: 3,label: 'Cancelada', value: 'CANCELADA' }
];
