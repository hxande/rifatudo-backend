import { TestBed } from '@angular/core/testing';
import { Orgao } from '@cadastro-registro-api/models/Orgao';
import { OrgaoCargo } from '@cadastro-registro-api/models/OrgaoCargo';
import { OrgaoRamo } from '@cadastro-registro-api/models/OrgaoRamo';
import { GovernancaRulesService, SituacaoCooperativa } from './governanca-rules.service';

describe('GovernancaRulesService', () => {
  let service: GovernancaRulesService;

  /** Órgão de teste (id = 1). */
  const orgao = (id = 1): Orgao => ({
    id,
    nome: 'Conselho Fiscal',
    obrigatorio: true,
    ativo: true,
    nomeiaResponsavel: false,
    vinculo: 'ESTATUTÁRIO ELETIVO',
  });

  /**
   * OrgaoRamo com valores distintos por cenário para provar qual ramo é lido:
   * padrão=3, lei≤19=2, lei>19=5, liquidação=1.
   */
  const orgaoRamo = (orgaoId = 1): OrgaoRamo =>
    ({
      id: 10,
      orgao: orgao(orgaoId),
      ramo: null as any,
      ordemExibicao: 1,
      minimoMembro: 3,
      maximoAnos: 4,
      minimoMembrosLei12690: 2,
      maximoAnosLei12690: 8,
      minimoMembrosLiquidacao: 1,
      minimoMembrosLei12690Maior19: 5,
      maximoAnosLei12690Maior19: 9,
      obrigatorio: true,
      obrigatorioLei12690: true,
      obrigatorioLiquidacao: true,
      obrigatorioLei12690Maior19: true,
    } as OrgaoRamo);

  const situacao = (over: Partial<SituacaoCooperativa> = {}): SituacaoCooperativa => ({
    liquidacao: false,
    regidaPorLei: false,
    cooperadosTotal: null,
    ...over,
  });

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GovernancaRulesService);
  });

  it('deve ser criado', () => {
    expect(service).toBeTruthy();
  });

  describe('minimoMembros', () => {
    it('caso padrão: usa minimoMembro do ramo', () => {
      expect(service.minimoMembros([orgaoRamo()], 1, situacao())).toBe(3);
    });

    it('liquidação: usa minimoMembrosLiquidacao (tem precedência sobre lei)', () => {
      const s = situacao({ liquidacao: true, regidaPorLei: true, cooperadosTotal: 50 });
      expect(service.minimoMembros([orgaoRamo()], 1, s)).toBe(1);
    });

    it('Lei 12.690 com <= 19 cooperados: usa minimoMembrosLei12690', () => {
      const s = situacao({ regidaPorLei: true, cooperadosTotal: 19 });
      expect(service.minimoMembros([orgaoRamo()], 1, s)).toBe(2);
    });

    it('Lei 12.690 com > 19 cooperados: usa minimoMembrosLei12690Maior19', () => {
      const s = situacao({ regidaPorLei: true, cooperadosTotal: 20 });
      expect(service.minimoMembros([orgaoRamo()], 1, s)).toBe(5);
    });

    it('Lei 12.690 sem total conhecido (null): conta como 0 e cai na faixa ≤ 19 (paridade com o backend)', () => {
      const s = situacao({ regidaPorLei: true, cooperadosTotal: null });
      expect(service.minimoMembros([orgaoRamo()], 1, s)).toBe(2);
    });

    it('retorna o default (1) quando não há ramo para o órgão', () => {
      expect(service.minimoMembros([orgaoRamo(99)], 1, situacao())).toBe(1);
    });

    it('retorna o default (1) quando orgaoRamos é nulo', () => {
      expect(service.minimoMembros(null, 1, situacao())).toBe(1);
    });
  });

  describe('maximoAnos', () => {
    it('caso padrão: usa maximoAnos do ramo', () => {
      expect(service.maximoAnos([orgaoRamo()], 1, situacao())).toBe(4);
    });

    it('Lei 12.690 com ≤ 19 cooperados: usa maximoAnosLei12690', () => {
      expect(service.maximoAnos([orgaoRamo()], 1, situacao({ regidaPorLei: true, cooperadosTotal: 19 }))).toBe(8);
    });

    it('Lei 12.690 com > 19 cooperados: usa maximoAnosLei12690Maior19 (paridade com o motor)', () => {
      expect(service.maximoAnos([orgaoRamo()], 1, situacao({ regidaPorLei: true, cooperadosTotal: 20 }))).toBe(9);
    });

    it('liquidação: usa maximoAnos padrão mesmo regida por lei (paridade com o motor)', () => {
      const s = situacao({ liquidacao: true, regidaPorLei: true, cooperadosTotal: 50 });
      expect(service.maximoAnos([orgaoRamo()], 1, s)).toBe(4);
    });

    it('default 20 quando não há ramo correspondente', () => {
      expect(service.maximoAnos([orgaoRamo(99)], 1, situacao())).toBe(20);
    });

    it('default 20 quando orgaoRamos é nulo', () => {
      expect(service.maximoAnos(null, 1, situacao())).toBe(20);
    });
  });

  describe('cargos obrigatórios / disponíveis', () => {
    const cargoPresidente = { id: 1, nome: 'Presidente', ativo: true };
    const cargoConselheiro = { id: 2, nome: 'Conselheiro', ativo: true };
    const orgaoCargos: OrgaoCargo[] = [
      { id: 1, orgao: orgao(), cargo: cargoPresidente, obrigatorio: true, diretoriaGdh: false },
      { id: 2, orgao: orgao(), cargo: cargoConselheiro, obrigatorio: false, diretoriaGdh: false },
    ];

    it('cargosObrigatorios retorna apenas os marcados como obrigatórios', () => {
      expect(service.cargosObrigatorios(orgaoCargos)).toEqual([cargoPresidente]);
    });

    it('cargosDisponiveis retorna todos os cargos', () => {
      expect(service.cargosDisponiveis(orgaoCargos)).toEqual([cargoPresidente, cargoConselheiro]);
    });

    it('retorna vazio quando orgaoCargos é nulo', () => {
      expect(service.cargosObrigatorios(null)).toEqual([]);
      expect(service.cargosDisponiveis(null)).toEqual([]);
    });
  });

  describe('podeEditarConselho', () => {
    const base = { isNacional: false, cadastroLiberado: true, mandatoAprovado: false };

    it('habilita quando liberado, não-nacional e não-aprovado', () => {
      expect(service.podeEditarConselho(base)).toBeTrue();
    });

    it('bloqueia usuário nacional', () => {
      expect(service.podeEditarConselho({ ...base, isNacional: true })).toBeFalse();
    });

    it('bloqueia quando cadastro não está liberado', () => {
      expect(service.podeEditarConselho({ ...base, cadastroLiberado: false })).toBeFalse();
    });

    it('bloqueia quando mandato já aprovado', () => {
      expect(service.podeEditarConselho({ ...base, mandatoAprovado: true })).toBeFalse();
    });
  });

  describe('conselhoIsentoDeMinimo', () => {
    it('órgão opcional não possuído é isento de mínimo', () => {
      const opcional = { ...orgao(), obrigatorio: false };
      expect(service.conselhoIsentoDeMinimo(opcional, false)).toBeTrue();
    });

    it('órgão opcional possuído NÃO é isento', () => {
      const opcional = { ...orgao(), obrigatorio: false };
      expect(service.conselhoIsentoDeMinimo(opcional, true)).toBeFalse();
    });

    it('órgão obrigatório nunca é isento', () => {
      expect(service.conselhoIsentoDeMinimo(orgao(), false)).toBeFalse();
    });
  });

  describe('cpfsDuplicadosAtivos', () => {
    it('detecta CPF ativo repetido (ignora formatação)', () => {
      const membros = [
        { cpf: '111.111.111-11', membroAtivo: true },
        { cpf: '11111111111', membroAtivo: true },
        { cpf: '222.222.222-22', membroAtivo: true },
      ];
      expect(service.cpfsDuplicadosAtivos(membros)).toEqual(['11111111111']);
    });

    it('não acusa duplicidade quando uma das posições está inativa', () => {
      const membros = [
        { cpf: '11111111111', membroAtivo: true },
        { cpf: '11111111111', membroAtivo: false },
      ];
      expect(service.cpfsDuplicadosAtivos(membros)).toEqual([]);
    });

    it('ignora membros sem CPF', () => {
      const membros = [
        { cpf: null, membroAtivo: true },
        { cpf: '', membroAtivo: true },
      ];
      expect(service.cpfsDuplicadosAtivos(membros)).toEqual([]);
    });
  });
});
