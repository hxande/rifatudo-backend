import { Injectable } from '@angular/core';
import { Cargo } from '@cadastro-registro-api/models/Cargo';
import { Orgao } from '@cadastro-registro-api/models/Orgao';
import { OrgaoCargo } from '@cadastro-registro-api/models/OrgaoCargo';
import { OrgaoRamo } from '@cadastro-registro-api/models/OrgaoRamo';

/**
 * Situação da cooperativa relevante às regras de governança (porte/lei/liquidação).
 *
 * Tipo leve que captura apenas o que as regras de ramo precisam, sem
 * arrastar o modelo `Cooperativa` inteiro. `cooperadosTotal` vem do quadro social.
 */
export interface SituacaoCooperativa {
  /** Cooperativa em liquidação. */
  liquidacao: boolean;
  /** Cooperativa regida pela Lei 12.690 (cooperativa de trabalho). */
  regidaPorLei: boolean;
  /** Total de cooperados do quadro social (porte). `null` quando desconhecido. */
  cooperadosTotal: number | null;
}

/**
 * Identificação de um membro para a checagem de duplicidade de CPF.
 */
export interface MembroParaValidacao {
  cpf: string | null | undefined;
  membroAtivo: boolean;
}

/**
 * Ponto único de verdade das regras de governança **no frontend**.
 *
 * Espelha o motor de regras do backend (`cadastro-registro-api/.../governanca/rules`)
 * para feedback imediato de UI — NÃO substitui a validação do backend, que
 * permanece autoritativa no salvar-por-conselho. Toda função é **pura** e
 * testável, sem dependência de estado de componente. A lógica reproduz
 * fielmente a que hoje vive espalhada em `GovernancaSharedComponent`
 * (`minimoMembros`, `maximoAnos`, `carregaOrgaoCargo`, `podeModificarCampos`).
 */
@Injectable({
  providedIn: 'root',
})
export class GovernancaRulesService {

  /** Máximo de anos default quando o ramo não define (paridade com o legado). */
  static readonly MAXIMO_ANOS_PADRAO = 20;

  /** Mínimo default de membros quando o ramo não define (paridade com o legado). */
  static readonly MINIMO_MEMBROS_PADRAO = 1;

  /** Limite de porte para a faixa "≤ 19 cooperados" da Lei 12.690. */
  static readonly LIMITE_PORTE_LEI = 19;

  /**
   * Mínimo de membros do órgão considerando liquidação / Lei 12.690 / porte.
   *
   * Espelha `GovernancaSharedComponent.minimoMembros()` (ordem de precedência
   * idêntica): liquidação > Lei 12.690 (≤19 vs >19 por `cooperadosTotal`) >
   * padrão do ramo. O match é por `orgaoId` dentro de `orgaoRamos`; quando não
   * há ramo correspondente, retorna o default (1).
   */
  minimoMembros(
    orgaoRamos: OrgaoRamo[] | null | undefined,
    orgaoId: number,
    situacao: SituacaoCooperativa
  ): number {
    let minimo = GovernancaRulesService.MINIMO_MEMBROS_PADRAO;

    if (!orgaoRamos) {
      return minimo;
    }

    for (const o of orgaoRamos) {
      let minimoMembros: number;

      if (situacao.liquidacao) {
        minimoMembros = o.minimoMembrosLiquidacao;
      } else if (situacao.regidaPorLei) {
        if (this.porteAte19(situacao)) {
          minimoMembros = o.minimoMembrosLei12690;
        } else {
          minimoMembros = o.minimoMembrosLei12690Maior19;
        }
      } else {
        minimoMembros = o.minimoMembro;
      }

      if (o.orgao.id === orgaoId && typeof minimoMembros === 'number') {
        minimo = minimoMembros;
      }
    }

    return minimo;
  }

  /**
   * Máximo de anos de duração do mandato do órgão, considerando liquidação /
   * Lei 12.690 / porte — MESMA matriz do motor (`OrgaoRamoResolver` /
   * `verificarLei12690` do backend): liquidação → `maximoAnos`; Lei 12.690 →
   * `maximoAnosLei12690` (≤19) ou `maximoAnosLei12690Maior19` (>19); padrão →
   * `maximoAnos`. Default 20 quando o ramo não define. (A versão anterior —
   * como o legado do god-component — ignorava a faixa >19 e a liquidação.)
   */
  maximoAnos(
    orgaoRamos: OrgaoRamo[] | null | undefined,
    orgaoId: number,
    situacao: SituacaoCooperativa
  ): number {
    if (!orgaoRamos) {
      return GovernancaRulesService.MAXIMO_ANOS_PADRAO;
    }

    for (const o of orgaoRamos) {
      let maximoAnos: number;
      if (situacao.liquidacao) {
        maximoAnos = o.maximoAnos;
      } else if (situacao.regidaPorLei) {
        maximoAnos = this.porteAte19(situacao) ? o.maximoAnosLei12690 : o.maximoAnosLei12690Maior19;
      } else {
        maximoAnos = o.maximoAnos;
      }
      if (o.orgao.id === orgaoId && typeof maximoAnos === 'number') {
        return maximoAnos;
      }
    }

    return GovernancaRulesService.MAXIMO_ANOS_PADRAO;
  }

  /**
   * Faixa de porte da Lei 12.690: total desconhecido conta como 0 (faixa ≤ 19),
   * como o backend (`getTotalCooperados` retorna 0 na ausência de quadro social).
   */
  private porteAte19(situacao: SituacaoCooperativa): boolean {
    return (situacao.cooperadosTotal ?? 0) <= GovernancaRulesService.LIMITE_PORTE_LEI;
  }

  /**
   * Cargos obrigatórios do órgão, na ordem de exibição definida pelo ramo.
   *
   * Espelha a intenção de `carregaOrgaoCargo`: extrai os cargos marcados como
   * `obrigatorio` em `OrgaoCargo`, que devem permanecer atribuídos aos membros
   * mesmo após inclusão/remoção/reordenação.
   */
  cargosObrigatorios(orgaoCargos: OrgaoCargo[] | null | undefined): Cargo[] {
    if (!orgaoCargos) {
      return [];
    }
    return orgaoCargos.filter((oc) => oc.obrigatorio).map((oc) => oc.cargo);
  }

  /**
   * Todos os cargos do órgão (obrigatórios e opcionais), para o dropdown de cargo.
   * Espelha a montagem da lista de opções em `carregaOrgaoCargo`.
   */
  cargosDisponiveis(orgaoCargos: OrgaoCargo[] | null | undefined): Cargo[] {
    if (!orgaoCargos) {
      return [];
    }
    return orgaoCargos.map((oc) => oc.cargo);
  }

  /**
   * Habilitação de edição dos campos de um conselho (espelha
   * `podeModificarCampos`). Versão **pura**: recebe os fatores explicitamente em
   * vez de ler estado de componente.
   *
   * Retorna `true` quando os campos PODEM ser editados. Bloqueia para usuário
   * nacional, quando o cadastro não está liberado, ou quando o mandato já está
   * aprovado.
   */
  podeEditarConselho(opcoes: {
    isNacional: boolean;
    cadastroLiberado: boolean;
    mandatoAprovado: boolean;
  }): boolean {
    if (opcoes.isNacional) {
      return false;
    }
    if (!opcoes.cadastroLiberado) {
      return false;
    }
    if (opcoes.mandatoAprovado) {
      return false;
    }
    return true;
  }

  /**
   * Indica se o órgão é opcional e, portanto, só exige membros/mínimo quando a
   * cooperativa declara possuí-lo (`coopPossui = true`).
   * Retorna `true` quando o conselho NÃO deve exigir mínimo de membros.
   */
  conselhoIsentoDeMinimo(orgao: Orgao, coopPossui: boolean): boolean {
    return orgao.obrigatorio === false && coopPossui === false;
  }

  /**
   * Detecta CPFs que ocupam mais de uma posição **ativa** no mesmo mandato.
   * Retorna a lista de CPFs (sem formatação) em conflito; vazio = ok.
   * A comparação ignora membros sem CPF (linhas ainda não preenchidas).
   */
  cpfsDuplicadosAtivos(membros: MembroParaValidacao[] | null | undefined): string[] {
    if (!membros) {
      return [];
    }
    const contagem = new Map<string, number>();
    for (const m of membros) {
      if (!m.membroAtivo || !m.cpf) {
        continue;
      }
      const cpf = m.cpf.replace(/\D/g, '');
      if (!cpf) {
        continue;
      }
      contagem.set(cpf, (contagem.get(cpf) ?? 0) + 1);
    }
    return Array.from(contagem.entries())
      .filter(([, qtd]) => qtd > 1)
      .map(([cpf]) => cpf);
  }
}
