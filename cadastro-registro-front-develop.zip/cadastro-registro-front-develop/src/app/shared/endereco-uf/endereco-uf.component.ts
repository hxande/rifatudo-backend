import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { Endereco } from '@cadastro-registro-api/models/Endereco';
import { ApiManutencaoDadosGeraisService } from '@cadastro-registro-api/services/api-manutencao-dados-gerais.service';
import { Uf } from '@localizacao-api/models/Uf';
import { UtilityService } from '@utils/utility/utility.service';
import { MessageService } from 'primeng/api';

@Component({
    selector: 'app-endereco-uf',
    templateUrl: './endereco-uf.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush,
    styleUrls: ['./endereco-uf.component.css']
})
export class EnderecoUfComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

    listaMunicipios: { label: string; value: number; selected: boolean }[] | undefined = [];
    listaUfs: Uf[] = [];

    @Input() visivel: boolean;

    @Input() edita: boolean;

    @Input() endereco: Endereco;

    @Output() onCorrespondenciaDiferente = new EventEmitter<boolean>();

    constructor(
        public kcService: KeycloakService,
        private dadosGeraisService: ApiManutencaoDadosGeraisService,
        private utilityService: UtilityService,
        private messageService: MessageService
    ) {

    }

    ngOnInit(): void {
        this.buscarUfs();
        this.buscarMunicipios(this.endereco.idEstado);
    }


    buscarUfs() {
        this.dadosGeraisService.buscarUfs().then((res) => {
            if (res && res.content != null) {
                this.listaUfs = res.content;
            }
            this.changeDetectorRef.markForCheck();
        });
    }

    selectMask(event: Event) {
        setTimeout(() => {
          (event.target as HTMLInputElement).select()
          this.changeDetectorRef.markForCheck();
        }, 100);
      }

    limpaCep(endereco: Endereco) {
        endereco.cep = '';
    }

    procurarLocalizacao(event) {
        let busca = event?.value;
        if (busca) {
            busca = this.utilityService.retirarFormatacao(busca);
            this.dadosGeraisService.buscarEndereco(busca).then((res) => {
                this.endereco.idEstado = res.municipio.uf.id;
                this.endereco.idMunicipio = res.municipio.id;
                this.endereco.bairro = res.bairro;
                this.endereco.enderecoReferencia = res.logradouro;
                this.buscarMunicipios(this.endereco.idEstado);
                this.changeDetectorRef.markForCheck();
            });
        }
    }

    buscarMunicipios(idEstado: number) {
      if(!idEstado){
          this.listaMunicipios = [];
          return;
      }
      this.listaMunicipios = undefined;
      this.dadosGeraisService.buscarMunicipiosByIdUf(idEstado).then((mun) => {
          if (mun != null && mun.content != null) {
              this.listaMunicipios = [];
              if(this.endereco != null && this.endereco.idMunicipio != null){
                  this.listaMunicipios = mun.content.map(m => ({label: m.nome, value: m.id, selected: m.id === this.endereco.idMunicipio}));
                  const municipioSelecionado = mun.content.find(m => m.id === this.endereco.idMunicipio);
                  if (municipioSelecionado) {
                      this.endereco.municipio = municipioSelecionado;
                      this.endereco.uf = municipioSelecionado.uf;
                  }
              } else {
                  this.messageService.add({ severity: 'warn', detail: 'Preencha o CEP antes dos demais campos.', life: 100000 });
              }
          }
          this.changeDetectorRef.markForCheck();
      });
  }


    setCorrespondenciaDiferente(){
        this.onCorrespondenciaDiferente.emit(this.endereco.correspondenciaDiferente);
    }

}
