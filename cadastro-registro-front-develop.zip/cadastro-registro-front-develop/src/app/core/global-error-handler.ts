import { HttpErrorResponse } from '@angular/common/http';
import { ErrorHandler, Injectable, Injector, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';

const CHUNK_ERROR_RELOAD_KEY = 'globalErrorHandler.chunkLoadReload';
const CHUNK_ERROR_RETRY_LIMIT = 1;
const CHUNK_ERROR_PATTERN =
  /Loading chunk [\w-]+ failed|ChunkLoadError|Failed to fetch dynamically imported module|error loading dynamically imported module|Importing a module script failed/i;

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  private chunkRetryCount = 0;

  constructor(private injector: Injector) {}

  handleError(error: unknown): void {
    console.error(error);

    if (error instanceof HttpErrorResponse) {
      // Erros de requisição HTTP já são tratados (toast) pelo MessageHttpInterceptor.
      return;
    }

    if (this.isChunkLoadError(error)) {
      this.handleChunkLoadError();
      return;
    }
  }

  private isChunkLoadError(error: unknown): boolean {
    return CHUNK_ERROR_PATTERN.test(this.extractMessage(error));
  }

  private extractMessage(error: unknown): string {
    if (error instanceof Error) {
      return error.message ?? '';
    }
    return typeof error === 'string' ? error : '';
  }

  private handleChunkLoadError(): void {
    const zone = this.injector.get(NgZone);

    if (this.chunkRetryCount < CHUNK_ERROR_RETRY_LIMIT) {
      this.chunkRetryCount++;
      // Reenviar o usuário para a mesma rota faz o Angular retentar o import()
      // do chunk. Resolve a maioria das falhas transitórias de rede sem
      // recarregar a página.
      const router = this.injector.get(Router);
      const currentUrl = router.url;
      zone.run(() => router.navigateByUrl(currentUrl));
      return;
    }

    if (sessionStorage.getItem(CHUNK_ERROR_RELOAD_KEY)) {
      // Já recarregou uma vez nesta sessão e o erro persiste: evita loop de reload.
      this.showGenericErrorToast();
      return;
    }
    sessionStorage.setItem(CHUNK_ERROR_RELOAD_KEY, '1');

    // A retentativa falhou: o chunk provavelmente não existe mais (nova versão
    // publicada). O mapa de hashes dos chunks só é atualizado recarregando o
    // bundle principal, então o reload aqui é inevitável - mas acontece
    // automaticamente, sem exigir nenhuma ação do usuário.
    const messageService = this.injector.get(MessageService);
    zone.run(() => {
      messageService.add({
        severity: 'info',
        detail: 'Uma nova versão do sistema foi publicada. Atualizando automaticamente...',
        life: 3000,
      });
    });
    setTimeout(() => window.location.reload(), 1500);
  }

  private showGenericErrorToast(): void {
    const zone = this.injector.get(NgZone);
    const messageService = this.injector.get(MessageService);
    zone.run(() => {
      messageService.add({
        severity: 'error',
        detail: 'Ocorreu um erro inesperado. Tente novamente.',
        life: 8000,
      });
    });
  }
}
