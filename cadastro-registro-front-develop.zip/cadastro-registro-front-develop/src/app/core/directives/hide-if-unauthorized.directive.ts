import { Directive, ElementRef, Input, OnInit, OnChanges } from '@angular/core';

@Directive({
  selector: '[appHideIfUnauthorized]'
})
export class HideIfUnauthorizedDirective implements OnChanges, OnInit {

  // eslint-disable-next-line
  @Input('appHideIfUnauthorized') role: string;

  /*
  Exemplo:
  <button appHideIfUnauthorized='CONSULTAR_LOGON' ..."></button>
  */
  constructor(private el: ElementRef
    // private keycloakService: KeycloakService
  ) { }

  ngOnInit(): void {
    this.updateElement();
  }

  ngOnChanges(): void {
    this.updateElement();
  }

  private updateElement() {
   /* if (!this.keycloakService.hasRole(this.role)) {
      this.el.nativeElement.style.display = 'none';
    } else {
      this.el.nativeElement.style.display = '';
    }*/
  }
}
