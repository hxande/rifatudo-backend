import { UsuarioInformacoesComponent } from '@gui/usuario-informacoes/usuario-informacoes.component';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ToastModule } from 'primeng/toast';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { MenubarModule } from 'primeng/menubar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { BreadcrumbModule } from 'primeng/breadcrumb';
import { DialogModule } from 'primeng/dialog';
import { CardModule } from 'primeng/card';
import { ForbiddenComponent } from './forbidden/forbidden.component';
import { ConfirmacaoEmailComponent } from './confirmacao-email/confirmacao-email.component';
import { UsuarioComponent } from './usuario/usuario.component';
import { AppTopBarComponent } from './layout/topbar/app.topbar.component';
import { AppMenuComponent, AppSubMenuComponent } from './layout/menu/app.menu.component';
import { AppBreadcrumbComponent } from './layout/topbar/app.breadcrumb.component';
import { SelecionarEntidadeComponent } from './selecionar-entidade/selecionar-entidade.component';
import { BarraTopoModule } from '@gui/barra-topo/barra-topo.module';
import { RodapeModule } from '@gui/rodape/rodape.module';
import { PipesCustomizadosModule } from '@gui/pipe/pipes-customizados.module';
import { ModalSelecionarEntidadeModule } from '@gui/modal-selecionar-entidade/modal-selecionar-entidade.module';
import { ProgressBarModule } from 'primeng/progressbar';
import { LogoSistemaComponent } from '@gui/logo/logo-sistema.component';


@NgModule({
  declarations: [
    AppTopBarComponent,
    AppMenuComponent,
    AppSubMenuComponent,
    AppBreadcrumbComponent,
    ForbiddenComponent,
    ConfirmacaoEmailComponent,
    UsuarioComponent,
    SelecionarEntidadeComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    BrowserAnimationsModule,
    BarraTopoModule,
    LogoSistemaComponent,
    RodapeModule,
    BreadcrumbModule,
    MenubarModule,
    ScrollPanelModule,
    ConfirmDialogModule,
    ToastModule,
    CardModule,
    ProgressBarModule,
    DialogModule,
    PipesCustomizadosModule,
    UsuarioInformacoesComponent,
    ModalSelecionarEntidadeModule
  ],
  providers: [
  ],
  exports: [
    CommonModule,
    BrowserAnimationsModule,
    BarraTopoModule,
    LogoSistemaComponent,
    RodapeModule,
    BreadcrumbModule,
    MenubarModule,
    ScrollPanelModule,
    ConfirmDialogModule,
    PipesCustomizadosModule,

    CardModule,
    DialogModule,
    ToastModule,
    UsuarioInformacoesComponent,

    AppTopBarComponent,
    AppMenuComponent,
    AppSubMenuComponent,
    AppBreadcrumbComponent,
    ForbiddenComponent,
    ConfirmacaoEmailComponent,
    UsuarioComponent,
    SelecionarEntidadeComponent
  ],
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() parentModule?: CoreModule) {
    if (parentModule) {
      throw new Error('CoreModule is already loaded. Import it in the AppModule only');
    }
  }
}
