import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { firstValueFrom } from 'rxjs';


@Injectable({
    providedIn: 'root'
  })
  export class ApiConfirmacaoEmailService {

    constructor(private http: HttpClient) { }

      enviaEmail(options: { params: HttpParams }) {
        return firstValueFrom(
          this.http.get<IServiceResponse<void>>(`/gerencia-usuario/public/api/v1/ativacao/envia-email`, options)
        );
      }
  }


