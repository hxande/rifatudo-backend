import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { ApiConfirmacaoEmailService } from './api-confirmacao-email-service/api-confirmacao-email-service';
import { HttpParams } from '@angular/common/http';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ApiDocumentoService } from '@documentacao-api/services/api-documento.service';
import { DocumentoTO } from '@documentacao-api/models/DocumentoTO';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-confirmacao-email',
  templateUrl: './confirmacao-email.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./confirmacao-email.component.css']
})
export class ConfirmacaoEmailComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativa = new Cooperativa();
  pessoaJuridica = new PessoaJuridica();
  documentacao: DocumentoTO[] = null;
  sistema = 'cadastro-registro';
  constructor(
    private apiConfirmacaoEmail: ApiConfirmacaoEmailService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private keycloakService: KeycloakService,
    private apiPj: ApiPessoaJuridicaService,
    private apiDocumentoService: ApiDocumentoService,
    private messageService: MessageService,
  ){ }

  ngOnInit() {
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      if (coop) {
        this.cooperativa = coop;

        this.apiPj.buscaUnidadeResponsavel(this.cooperativa.pessoaJuridica.ufSigla).then(pj =>{
          this.pessoaJuridica = pj.data;
          this.changeDetectorRef.markForCheck();
        });

        this.apiDocumentoService.getDocumentoTO(this.cooperativa.pessoaJuridica.id).then((res) => {
          if (res && res.data != null) {
            this.documentacao = res.data;
          }
          this.changeDetectorRef.markForCheck();
        });
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  enviaEmail() {
    const options = {
      params: new HttpParams()
        .set('sistema', this.sistema)
    };

    this.apiConfirmacaoEmail.enviaEmail(options).then(response=> {
      this.messageService.add({ severity: 'success', detail: 'E-mail enviado!', life: 10000 });
      this.changeDetectorRef.markForCheck();
    });
  }

}
