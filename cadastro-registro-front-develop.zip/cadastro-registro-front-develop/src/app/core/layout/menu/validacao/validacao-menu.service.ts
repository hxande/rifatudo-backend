import {Injectable} from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoMenu {

  constructor(
    private keycloakService: KeycloakService,
  ) {
  }

  podeVerMenuProcessosTransferenciaSubPerfil() {
    return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    );
  }

  podeVerMenuAdministracao() {
    return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    );
  }

  podeVerMenuUsuario() {
    return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES)
    );
  }

  podeVerMenuRelatorio() {
    return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES)
    );
  }

  podeVerContribuicaoFinanceira() {
    // TODO ver lógica de subperfis
    return true;
  }
}
