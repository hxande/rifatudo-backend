import {animate, state, style, transition, trigger} from '@angular/animations';
import { HttpParams } from '@angular/common/http';
import {AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, Inject, Input, OnInit, ViewChild} from '@angular/core';
import {KEYCLOAK_CLIENT_ID, KeyclokClientEnum} from '@auth/auth-guard/constants';
import {Role} from '@auth/auth-guard/Role';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import {ProxyUrl} from '@auth/proxy-url/proxy-url.service';
import {Cooperativa} from '@cadastro-registro-api/models/Cooperativa';
import {PessoaJuridica} from '@cadastro-registro-api/models/PessoaJuridica';
import {Situacao} from '@cadastro-registro-api/models/Situacao';
import {ApiAdesaoService} from '@cadastro-registro-api/services/api-adesao.service';
import {ApiCadastroRegistroService} from '@cadastro-registro-api/services/api-cadastro-registro.service';
import {ApiCooperativaService} from '@cadastro-registro-api/services/api-cooperativa.service';
import {ApiPendenciaRegistroService} from '@gerencia-usuario-api/services/api-pendencia-registro.service';
import {CacheService} from '@utils/cache/cache.service';
import {ConfirmationService, MenuItem} from 'primeng/api';
import {ScrollPanel} from 'primeng/scrollpanel';
import {AppComponent} from 'src/app/app.component';
import {ValidacaoMenu} from './validacao/validacao-menu.service';
import {ApiLeituraCensoAnuarioService} from '@cadastro-registro-leitura-api/services/api-censo-anuario.service';

export interface AppMenuItem extends MenuItem {
  role?: Role;
  items?: AppMenuItem[];
}

@Component({
  selector: 'app-menu',
  templateUrl: './app.menu.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppMenuComponent implements OnInit, AfterViewInit {

  private changeDetectorRef = inject(ChangeDetectorRef);

  static appMenuInstance: AppMenuComponent;

  model: AppMenuItem[];
  estadualInAdesao = false;
  cooperativa: Cooperativa = new Cooperativa();
  temPendencia = false;
  temAtualizacaoNaoVisualizada = 0;
  temAtualizacaoNaoVisualizadaRegistrada = 0;
  temAtualizacaoAguadandoValidacao = 0;
  tipoUsuario;
  entidadeUsuario;

  @ViewChild('scrollPanel') layoutMenuScrollerViewChild: ScrollPanel;

  constructor(
    public app: AppComponent,
    private cacheService: CacheService,
    private keycloakService: KeycloakService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiCooperativaService: ApiCooperativaService,
    private confirmationService: ConfirmationService,
    private proxyUrl: ProxyUrl,
    private pendenciaRegistroService: ApiPendenciaRegistroService,
    public validacaoMenu: ValidacaoMenu,
    private apiAdesaoService: ApiAdesaoService,
    private apiLeituraCensoAnuarioService: ApiLeituraCensoAnuarioService,
    @Inject(KEYCLOAK_CLIENT_ID) private clientId: KeyclokClientEnum
  ) {
    this.cooperativa = new Cooperativa();
    this.cooperativa.pessoaJuridica = new PessoaJuridica();
    this.cooperativa.situacaoCooperativa = new Situacao();
  }

  ngOnInit() {
    AppMenuComponent.appMenuInstance = this;
    this.loadEstadualInAdesao();
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
      this.verificaPendenciaNoGerenciaUsuario(this.keycloakService.usuarioLogado).then((pendencia) => {
        this.temPendencia = pendencia.data > 0;
        if (coop) {
          this.cooperativa = coop;
          this.updateMenu();
        } else {
          this.updateMenu();
        }
        this.changeDetectorRef.markForCheck();
      });
    });

    this.entidadeUsuario = this.keycloakService.getEntidade();
    this.tipoUsuario = this.keycloakService.getTipo();

    AppMenuComponent.appMenuInstance.carregarNotificacaoTela();

    setInterval(() => {
      AppMenuComponent.appMenuInstance.carregarNotificacaoTela();
      this.changeDetectorRef.markForCheck();
    }, 300000);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.layoutMenuScrollerViewChild.moveBar();
    }, 100);
  }

  public irParaContribuicaoCooperativista() {
    this.confirmationService.confirm({
      message: 'O sistema Arrecadação será aberto em uma nova aba. Deseja continuar?',
      accept: () => {
        const urlAtual = this.proxyUrl.getUrlAtual();
        if (urlAtual) {
          const link = document.createElement('a');
          document.body.appendChild(link);
          link.target = '_blank';
          link.setAttribute('visibility', 'hidden');
          if (urlAtual.indexOf(ProxyUrl.HOMOLOGACAO_SUFIXO) !== -1) {
            link.href = 'https://arrecadacao-hmlg.apps.ocp.somos.coop.br/inicio';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.PRODUCAO_SUFIXO) !== -1) {
            link.href = 'https://arrecadacao-prd.apps.ocp.somos.coop.br/inicio';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.TREINAMENTO_SUFIXO) !== -1) {
            link.href = 'https://arrecadacao-trt.apps.ocp.somos.coop.br/inicio';
            link.click();
          } else {
            link.href = 'http://localhost/inicio';
            link.click();
          }
        }
      },
    });
  }

  public irParaGerenciaUsuario() {
    this.confirmationService.confirm({
      message: 'O sistema de Gestão de Usuários será aberto em uma nova aba. Deseja continuar?',
      accept: () => {
        const urlAtual = this.proxyUrl.getUrlAtual();
        if (urlAtual) {
          const link = document.createElement('a');
          document.body.appendChild(link);
          link.target = '_blank';
          link.setAttribute('visibility', 'hidden');
          if (urlAtual.indexOf(ProxyUrl.HOMOLOGACAO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-hmlg.apps.ocp.somos.coop.br/inicio/mantem-usuario-adm?client_id=cadastro-registro';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.PRODUCAO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-prd.apps.ocp.somos.coop.br/inicio/mantem-usuario-adm?client_id=cadastro-registro';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.TREINAMENTO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-trt.apps.ocp.somos.coop.br/inicio/mantem-usuario-adm?client_id=cadastro-registro';
            link.click();
          } else {
            link.href = 'http://localhost/inicio/mantem-usuario-adm?client_id=cadastro-registro';
            link.click();
          }
        }
      },
    });
  }

  updateMenu() {
    const txtMenuCadastro = this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional ? 'Cooperativas Registradas' : 'Cadastro';
    this.cacheService.set('notificacao_registrada', this.temAtualizacaoNaoVisualizadaRegistrada);
    this.cacheService.set('notificacao', this.temAtualizacaoNaoVisualizada);

    this.model = [
      {
        label: this.trocaLabelInicio(),
        visible: true,
        title: this.trocaLabelInicio(),
        icon: 'fa fa-th-large',
        routerLink: ['/'],
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
      },
      {
        label: txtMenuCadastro,
        title: txtMenuCadastro,
        icon: 'fa fa-file-alt',
        visible: this.keycloakService.getTipo() === 'C' ? this.cooperativa.situacaoCooperativa.id === 4 : true,
        routerLink: this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional ? ['/cooperativa/listagem'] : ['/registro/cadastro'],
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
        badge: this.temAtualizacaoNaoVisualizadaRegistrada > 0 ? '!' : '',
      },
      {
        label: 'Processo de Registro',
        visible: this.keycloakService.getTipo() === 'C' ? this.cooperativa.situacaoCooperativa.id !== 1 && this.cooperativa.dataRegistro == null : true,
        title: 'Processo de Registro',
        icon: 'fa fa fa-tasks',
        routerLink: ['/registro/listagem'],
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
        badge: this.temAtualizacaoNaoVisualizada > 0 ? '!' : '',
      },
      {
        label: 'Documentos',
        title: 'Documentos',
        icon: 'fa fa-inbox',
        routerLink: ['/registro/documentos'],
        visible: this.keycloakService.getTipo() === 'C',
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
      },
      {
        label: 'Sistema de Arrecadação',
        visible:
          this.keycloakService.getTipo() === 'N' ||
          (this.keycloakService.getTipo() === 'E' && this.validacaoMenu.podeVerContribuicaoFinanceira() && this.estadualInAdesao),
        title: 'Sistema de Arrecadação',
        command: (onclick) => {
          this.irParaContribuicaoCooperativista();
        },
        icon: 'fas fa-hand-holding-usd',
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
        badge: this.temAtualizacaoAguadandoValidacao > 0 ? '!' : '',
      },
      {
        label: 'Relatórios',
        visible: this.keycloakService.isUsuarioNacional || this.keycloakService.isUsuarioEstadual,
        title: 'Relatórios',
        icon: 'fa-regular fa-file-excel',
        routerLink: ['/relatorio/relatorios-gerenciais'],
      },
      {
        label: 'Processos de transferência de UF',
        title: 'Processos de transferência de UF',
        icon: 'fa fa-handshake',
        visible:
          (this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional) && this.validacaoMenu.podeVerMenuProcessosTransferenciaSubPerfil(),
        routerLink: ['/transferencia-uf'],
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
      },
      {
        label: 'Usuários',
        visible: this.validacaoMenu.podeVerMenuUsuario(),
        title: 'Usuários',
        command: (onclick) => {
          this.irParaGerenciaUsuario();
        },
        icon: 'fas fa-user',
        routerLinkActiveOptions: { exact: true },
        role: Role.CADASTRO_REGISTRO_USUARIO_ATIVO,
        badge: this.temPendencia ? '!' : '',
      },
      // {
      //   label: 'Exportação de dados',
      //   visible: this.keycloakService.isUsuarioNacional || this.keycloakService.isUsuarioEstadual,
      //   title: 'Exportação de dados',
      //   icon: 'fa fa-file-export',
      //   routerLink: ['/exportacao-dados'],
      // },
      {
        label: 'Administração',
        visible: this.validacaoMenu.podeVerMenuAdministracao(),
        title: 'Administração',
        icon: 'fa fa-cog',
        routerLink: this.rotaAdministracao(),
        role: Role.CADASTRO_REGISTRO_ESTADUAL,
      }
    ];

    this.model = this.model.filter((menu) => (menu.role ? this.keycloakService.hasRole(menu.role, this.clientId) : true)).filter((menu) => menu.visible);
  }

  loadEstadualInAdesao() {
    this.apiAdesaoService.getContribuicoes().then((response) => {
      if (response) {
        const adesaoUE = response.data.filter((result) => {
          return result.ufSigla === this.keycloakService.getUF();
        });
        this.estadualInAdesao = adesaoUE[0].adere;
      }
    });
  }

  trocaLabelInicio() {
    if (this.keycloakService.isUsuarioCooperativa) {
      return this.cooperativa.progressoMacro != null ? 'Registro' : 'Cadastro';
    }
    return 'Painel de Informações';
  }

  rotaAdministracao() {
    if (this.keycloakService.isUsuarioNacional) {
      return ['/administracao/inicio'];
    } else if (this.keycloakService.isUsuarioEstadual) {
      return ['/administracao/inicio-ue'];
    }

    return ['/inicio'];
  }

  verificaPendenciaNoGerenciaUsuario(usuarioLogado) {
    const options = {
      params: new HttpParams()
        .set('sistema', 'cadastro-registro')
        .set('tipo', this.tipoUsuario)
        .set('parametro', this.tipoUsuario === 'E' ? this.tipoUsuario : this.entidadeUsuario),
    };

    return this.pendenciaRegistroService.getNumeroUsuariosPendentes(options);
  }

  carregarNotificacaoTela() {
    if (AppMenuComponent.appMenuInstance.keycloakService.isUsuarioEstadual || AppMenuComponent.appMenuInstance.keycloakService.isUsuarioNacional) {
      AppMenuComponent.appMenuInstance.apiCadastroRegistroService.numeroDePendencias().then((resp) => {
        AppMenuComponent.appMenuInstance.temAtualizacaoAguadandoValidacao = resp;
        AppMenuComponent.appMenuInstance.updateMenu();
        AppMenuComponent.appMenuInstance.changeDetectorRef.markForCheck();
      });
      AppMenuComponent.appMenuInstance.apiCooperativaService.verificaAtualizacaoNaoVisualizada().then((naoVisualizada) => {
        AppMenuComponent.appMenuInstance.temAtualizacaoNaoVisualizada = naoVisualizada;
        AppMenuComponent.appMenuInstance.updateMenu();
        AppMenuComponent.appMenuInstance.changeDetectorRef.markForCheck();
      });

      AppMenuComponent.appMenuInstance.apiCooperativaService.verificaAtualizacaoNaoVisualizadaRegistrada().then((naoVisualizadaRegistrada) => {
        AppMenuComponent.appMenuInstance.temAtualizacaoNaoVisualizadaRegistrada = naoVisualizadaRegistrada;
        AppMenuComponent.appMenuInstance.updateMenu();
        AppMenuComponent.appMenuInstance.changeDetectorRef.markForCheck();
      });
    }
  }
}

@Component({
  /* eslint-disable @angular-eslint/component-selector */
  selector: '[app-submenu]',
  /* eslint-enable @angular-eslint/component-selector */
  templateUrl: 'appsubmenu.component.html',
  animations: [
    trigger('children', [
      state(
        'visible',
        style({
          height: '*',
        })
      ),
      state(
        'hidden',
        style({
          height: '0px',
        })
      ),
      transition('visible => hidden', animate('600ms cubic-bezier(0.86, 0, 0.07, 1)')),
      transition('hidden => visible', animate('600ms cubic-bezier(0.86, 0, 0.07, 1)')),
    ]),
  ],
})
export class AppSubMenuComponent {
  @Input() item: AppMenuItem | AppMenuItem[];
  @Input() root: boolean;

  activeIndex: number;

  hover: boolean;

  constructor(public app: AppComponent, public appMenu: AppMenuComponent) {}

  get childItems(): AppMenuItem[] {
    return this.root ? (this.item as AppMenuItem[]) : (this.item as AppMenuItem).items;
  }

  itemClick(event: Event, item: MenuItem, index: number) {
    // avoid processing disabled items
    if (item.disabled) {
      event.preventDefault();
      return true;
    }

    // activate current item and deactivate active sibling if any
    if (item.routerLink || item.items || item.command || item.url) {
      this.activeIndex = this.activeIndex === index ? -1 : index;
    }

    // execute command
    if (item.command) {
      item.command({ originalEvent: event, item });
    }

    // prevent hash change
    if (item.items || (!item.url && !item.routerLink)) {
      setTimeout(() => {
        this.appMenu.layoutMenuScrollerViewChild.moveBar();
      }, 450);
      event.preventDefault();
    }
  }

  isActive(index: number): boolean {
    return this.activeIndex === index;
  }
}
