import { MenuItem } from 'primeng/api';
import { Subscription } from 'rxjs';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, inject } from '@angular/core';
import { AppComponent } from 'src/app/app.component';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
    selector: 'app-breadcrumb',
    templateUrl: './app.breadcrumb.component.html',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppBreadcrumbComponent implements OnDestroy {

    private readonly changeDetectorRef = inject(ChangeDetectorRef);

    private subscription: Subscription;

    items: MenuItem[];

    constructor(public breadcrumbService: BreadcrumbService,
                public app: AppComponent,
            private keycloakService: KeycloakService
            ) {
        this.subscription = breadcrumbService.itemsHandler.subscribe(response => {
            this.items = response;
            this.changeDetectorRef.markForCheck();
        });
    }

    ngOnDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }

    getUser() {
      //  return this.keycloakService.usuarioLogado;
    }

    account(): void {
      // window.open('https://keycloak-hmlg.ocb.org.br/auth/realms/OCB/account', '_blank');
    }

    logout(): void {
       this.keycloakService.logout();
    }



}
