import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ProxyUrl } from '@auth/proxy-url/proxy-url.service';
import { ApiUsuarioService } from '@gerencia-usuario-api/services/api-usuario.service';
import { ConfirmationService } from 'primeng/api';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-topbar',
  templateUrl: './app.topbar.component.html',
  styleUrls: ['./app.topbar.component.scss']
})
export class AppTopBarComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  username: string;
  sistema: string;
  idUsuario: string;
  alteracaoPerfil: boolean;
  imagemLogoAmbiente: string;

  ngOnInit() {
    this.carregarTela();
  }

  carregarTela() {
    if (this.keycloakService.getToken()) {
      this.username = this.keycloakService.usuarioLogado.username;

      const urlAtual = this.proxyUrl.getUrlAtual();
      if (urlAtual) {
        if (urlAtual.indexOf(ProxyUrl.HOMOLOGACAO_SUFIXO) !== -1) {
          this.imagemLogoAmbiente = `../../../assets/images/SouCoopHomologacao.png`;
        } else if (urlAtual.indexOf(ProxyUrl.PRODUCAO_SUFIXO) !== -1) {
          this.imagemLogoAmbiente = `../../../assets/images/sejacoop.png`;
        } else if (urlAtual.indexOf(ProxyUrl.TREINAMENTO_SUFIXO) !== -1) {
          this.imagemLogoAmbiente = `../../../assets/images/SouCoopTreinamento.png`;
        } else {
          this.imagemLogoAmbiente = `../../../assets/images/sejacoop.png`;
        }
      }
      this.sistema = 'cadastro-registro';
      this.buscaUsuarioId();
    }
  }

  constructor(public app: AppComponent,
    public keycloakService: KeycloakService,
    private confirmationService: ConfirmationService,
    private apiUsuarioService: ApiUsuarioService,
    private router: Router,
    private proxyUrl: ProxyUrl) { }

  logout(): void {
    this.keycloakService.logout();
  }

  buscaUsuarioId() {
    this.apiUsuarioService.buscaUsuario(this.keycloakService.usuarioLogado.username).then(resp => {
      this.idUsuario = resp.data[0].id.toString();
      this.exibirAlteracaoPerfil();
      this.changeDetectorRef.markForCheck();
    });
  }

  account(): void {
    this.irParaGerenciaUsuario();
  }

  alterarPerfil() {
    this.router.navigateByUrl('/selecionar-entidade?alterar=true');
  }

  exibirAlteracaoPerfil() {
    this.apiUsuarioService.buscaEntidadesComPermissao(this.idUsuario, this.sistema).then(resp => {
      this.alteracaoPerfil = resp.data.length > 1;
      this.changeDetectorRef.markForCheck();
    });
  }

  irParaGerenciaUsuario() {
    this.confirmationService.confirm({
      message: 'O sistema de Gestão de Usuários será aberto em uma nova aba. Deseja continuar?',
      accept: () => {
        const urlAtual = this.proxyUrl.getUrlAtual();

        if (urlAtual) {
          const link = document.createElement('a');
          document.body.appendChild(link);
          link.target = '_blank';
          link.setAttribute('visibility', 'hidden');
          if (urlAtual.indexOf(ProxyUrl.HOMOLOGACAO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-hmlg.apps.ocp.somos.coop.br/inicio/mantemusuario';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.PRODUCAO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-prd.apps.ocp.somos.coop.br/inicio/mantemusuario';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.TREINAMENTO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-trt.apps.ocp.somos.coop.br/inicio/mantemusuario';
            link.click();
          } else {
            link.href = 'http://localhost:4401/inicio/mantemusuario';
            link.click();
          }
        }
      }
    });

  }
}
