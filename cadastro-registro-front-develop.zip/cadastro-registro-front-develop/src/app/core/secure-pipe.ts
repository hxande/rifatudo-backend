import {
  ChangeDetectorRef, OnDestroy, Pipe,
  PipeTransform
} from '@angular/core';

import { BehaviorSubject, Observable, Subscription } from 'rxjs';

import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { MessageHttpInterceptor } from './message-http-interceptor';

// Using similarity from AsyncPipe to avoid having to pipe |secure|async in HTML.
@Pipe({
    name: 'secure',
    pure: false
})
export class SecurePipe implements PipeTransform, OnDestroy {
    private _latestValue: SafeUrl = null;
    private _latestReturnedValue: SafeUrl = null;
    private _subscription: Subscription = null;
    private _obj: Observable<SafeUrl> = null;

    private previousUrl: string;
    private _result: BehaviorSubject<SafeUrl> = new BehaviorSubject(null);
    private result: Observable<SafeUrl> = this._result.asObservable();
    private _internalSubscription: Subscription = null;

    constructor(
        private _ref: ChangeDetectorRef,
        private urlHelperService: MessageHttpInterceptor,
        private sanitizer: DomSanitizer
    ) { }

    ngOnDestroy(): void {
        if (this._subscription) {
            this._dispose();
        }
    }

    transform(url: string): SafeUrl {
        const obj = this.internalTransform(url);
        return this.asyncTrasnform(obj);
    }

    private internalTransform(url: string): Observable<SafeUrl> {
        if (!url) {
            return this.result;
        }

        if (this.previousUrl !== url) {
            this.previousUrl = url;
            url = url + '?src-tag-image-request=true';
            this._internalSubscription = this.urlHelperService.get(url).subscribe(m => {
                const sanitized = this.sanitizer.bypassSecurityTrustUrl(m);
                this._result.next(sanitized);
            });
        }

        return this.result;
    }

    private asyncTrasnform(obj: Observable<SafeUrl>): SafeUrl {
        if (!this._obj) {
            if (obj) {
                this._subscribe(obj);
            }
            this._latestReturnedValue = this._latestValue;
            return this._latestValue;
        }
        if (obj !== this._obj) {
            this._dispose();
            return this.asyncTrasnform(obj);
        }
        if (this._latestValue === this._latestReturnedValue) {
            return this._latestReturnedValue;
        }
        this._latestReturnedValue = this._latestValue;
        return this._latestValue;
    }

    private _subscribe(obj: Observable<SafeUrl>) {
        const _this = this;
        this._obj = obj;

        this._subscription = obj.subscribe({
            next (value) {
                return _this._updateLatestValue(obj, value);
            }, error: (e: unknown) => { throw e; }
        });
    }

    private _dispose() {
        this._subscription.unsubscribe();
        this._internalSubscription.unsubscribe();
        this._internalSubscription = null;
        this._latestValue = null;
        this._latestReturnedValue = null;
        this._subscription = null;
        this._obj = null;
    }

    private _updateLatestValue(async: Observable<SafeUrl>, value: SafeUrl) {
        if (async === this._obj) {
            this._latestValue = value;
            this._ref.markForCheck();
        }
    }
}
