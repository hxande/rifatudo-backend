import {ChangeDetectorRef, Component, OnInit, inject} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import {ApiUsuarioService} from '@gerencia-usuario-api/services/api-usuario.service';

@Component({
  selector: 'app-selecionar-entidade',
  templateUrl: './selecionar-entidade.component.html',
  styleUrls: ['./selecionar-entidade.component.css'],
})
export class SelecionarEntidadeComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  idUsuario: string;
  sistema: string;
  exibirModal: boolean;
  exibirBotaoVoltar: boolean;
  exibirBotaoSair: boolean;

  constructor(
    private apiUsuarioService: ApiUsuarioService,
    private keycloakService: KeycloakService,
    private activeRoute: ActivatedRoute,
    private router: Router
  ) {
  }

  ngOnInit() {
    const possuiEntidade = this.keycloakService.possuiEntidade(this.keycloakService.usuarioLogado.userKeycloak.attributes.ENTIDADE_SISTEMA[0]); 
    const alterar = this.activeRoute.snapshot.queryParamMap.get('alterar');
    this.exibirBotoes(possuiEntidade, alterar);

    this.apiUsuarioService.buscaUsuario(this.keycloakService.usuarioLogado.username).then((resp) => {
      if(resp.data.length){
        this.idUsuario = resp.data[0].id.toString();
      }

      this.sistema = 'cadastro-registro';
      this.exibirModal = true;
      this.changeDetectorRef.markForCheck();
    });
  }


  exibirBotoes(possuiEntidade, alterar) {
    if (possuiEntidade) {
      this.exibirBotaoVoltar = true;
      if (!alterar) {
        this.router.navigate(['/inicio']);
      }
    } else {
      this.exibirBotaoSair = true;
    }
  }

  onUpdate(event) {
    this.router.navigate(['inicio']).then(() => {
      window.location.reload();
      this.changeDetectorRef.markForCheck();
    });
  }

  voltarEvent(event) {
    if (event.value) {
      this.router.navigate(['/inicio']);
    }
  }

  logoutEvent(event) {
    if (event.value) {
      sessionStorage.clear();
      this.keycloakService.logout();
    }
  }
}
