import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProxyUrl } from '@auth/proxy-url/proxy-url.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {

  constructor(
    private proxyUrl: ProxyUrl,
    private router: Router,
    private confirmationService: ConfirmationService, ) { }

  ngOnInit() {
    this.irParaGerenciaUsuario();
  }

  public irParaGerenciaUsuario() {
    this.confirmationService.confirm({
      message: 'O sistema de Gestão de Usuários será aberto em uma nova aba. Deseja continuar?',
      accept: () => {
        const urlAtual = this.proxyUrl.getUrlAtual();

        if (urlAtual) {
          const link = document.createElement('a');
          document.body.appendChild(link);
          link.target = '_blank';
          link.setAttribute('visibility', 'hidden');
          if (urlAtual.indexOf(ProxyUrl.HOMOLOGACAO_SUFIXO) !== -1) {
            link.href = 'https://gerencia-usuario-hmlg.apps.ocp.somos.coop.br/mantem-usuario-adm/?client_id=cadastra-registro';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.PRODUCAO_SUFIXO) !== -1) {
            link.href = 'http://gerencia-usuario-prd.apps.ocp.somos.coop.br/mantem-usuario-adm/?client_id=cadastra-registro';
            link.click();
          } else if (urlAtual.indexOf(ProxyUrl.TREINAMENTO_SUFIXO) !== -1) {
            link.href = 'http://gerencia-usuario-trt.apps.ocp.somos.coop.br/mantem-usuario-adm/?client_id=cadastra-registro';
            link.click();
          }
        }
      }
    });

    this.router.navigate(['/inicio']);
  }

}
