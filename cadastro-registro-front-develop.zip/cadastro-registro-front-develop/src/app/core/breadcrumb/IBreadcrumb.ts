export interface IBreadCrumb {
    label: string;
    router?: string;
    isLast: boolean;
}
