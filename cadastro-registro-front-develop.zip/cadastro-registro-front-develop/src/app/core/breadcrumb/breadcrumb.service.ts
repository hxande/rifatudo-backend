import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';
import { EventEmitter } from '@angular/core';
import { IBreadCrumb } from './IBreadcrumb';

@Injectable()
export class BreadcrumbService {
  breadcrumb: EventEmitter<IBreadCrumb[]> = new EventEmitter<IBreadCrumb[]>();
  private itemsSource = new Subject<MenuItem[]>();
  itemsHandler = this.itemsSource.asObservable();

  constructor(private router: Router) {}

  setItems(items: MenuItem[]) {
    this.itemsSource.next(items);
  }

  updateBreadcrumb(value: IBreadCrumb[]) {
    this.breadcrumb.emit(value);
  }

  goTO(item: MenuItem[]) {
    this.router.navigate(item);
  }
}
