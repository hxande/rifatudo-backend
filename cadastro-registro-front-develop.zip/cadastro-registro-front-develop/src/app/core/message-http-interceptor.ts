import { HttpClient, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HTTPStatus } from '@auth/http/http-status.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ProxyUrl } from '@auth/proxy-url/proxy-url.service';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { MessageService } from 'primeng/api';
import { Observable, Subscriber, throwError } from 'rxjs';
import { catchError, finalize, map } from 'rxjs/operators';

@Injectable()
export class MessageHttpInterceptor implements HttpInterceptor {
  private requisicoes = 0;
  private tempoMaximoDeCarregamento = 15000; // 15 segundos
  private timeout: ReturnType<typeof setTimeout>;

  constructor(
    private status: HTTPStatus,
    private messageService: MessageService,
    private proxyUrl: ProxyUrl,
    private http: HttpClient,
    private keycloakService: KeycloakService
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (req.url.indexOf('?src-tag-image-request=true') === -1) {
      req = req.clone({ url: this.proxyUrl.obterUrl(req.url) });
    }

    // obtém timeout da requisição, se for configurado. Senão, usa valor padrão
    const timeoutValue = req.headers.get('timeout') || this.tempoMaximoDeCarregamento;
    const timeoutValueNumeric = parseInt(timeoutValue as string, 10);

    // this.status.setHttpStatus(true);
    if (!req.reportProgress) {
      this.requisicoes++;
      if (this.requisicoes === 1 && !req.headers.has('background')) {
        this.status.setHttpStatus(true);

        // Evitar do loading ficar eternamente na tela
        this.timeout = setTimeout(() => {
          this.status.setHttpStatus(false);
          this.requisicoes = 0;
        }, timeoutValueNumeric);
      }
    }

    return next.handle(req).pipe(
      map((event) => {
        if (event instanceof HttpResponse && event.body && event.body.messages) {
          this.messageService.addAll(
            event.body.messages.map((msg: IServiceMessage) => ({
              severity: event.status === 202 ? 'warn' : msg.type.toLowerCase(),
              sumary: msg.message.substring(msg.message.indexOf('<b>') + 2, msg.message.indexOf('</b>')),
              detail: msg.message,
            }))
          );
        }
        return event;
      }),
      catchError((error) => {
        if (error.error && error.error instanceof ArrayBuffer) {
          const decoder = new TextDecoder('utf-8');
          error.error = JSON.parse(decoder.decode(error.error));
        }

        if (error.status >= 500 && error.status <= 599 && error.error && error.error.message) {
          this.messageService.addAll(
            error.error.messages.map((msg: IServiceMessage) => ({
              severity: msg.type.toLowerCase(),
              detail: 'Erro ao processar serviço remoto. Tente novamente mais tarde.',
            }))
          );
        } else if (error.error && error.error.messages) {
          this.messageService.addAll(error.error.messages.map((msg: IServiceMessage) => ({ severity: msg.type.toLowerCase(), detail: msg.message })));
        } else {
          // Serviço OFFLINE
          if (error.status === 503) {
            this.messageService.add({ severity: 'error', detail: 'Serviço indisponível: ' + error.url, life: 7000 });
          } else {
            this.messageService.add({ severity: 'error', detail: error.message, life: 7000 });
          }
        }
        return throwError(error);
      }),
      finalize(() => {
        if (!req.reportProgress) {
          clearTimeout(this.timeout);
          this.requisicoes--;

          if (this.requisicoes <= 0) {
            setTimeout(() => {
              if (this.requisicoes <= 0) {
                this.status.setHttpStatus(false);
                this.requisicoes = 0;
              }
            }, 1000);
          }
        }
      })
    );
  }

  get(url: string): Observable<string> {
    return new Observable((observer: Subscriber<string>) => {
      let objectUrl: string = null;

      this.http
        .get(url, {
          headers: this.getHeaders(),
          responseType: 'blob',
        })
        .subscribe((m) => {
          objectUrl = URL.createObjectURL(m);
          observer.next(objectUrl);
        });

      return () => {
        if (objectUrl) {
          URL.revokeObjectURL(objectUrl);
          objectUrl = null;
        }
      };
    });
  }

  getHeaders(): HttpHeaders {
    const headers = new HttpHeaders();
    headers.set('Authorization', 'Bearer ' + this.keycloakService.getToken());
    return headers;
  }
}
