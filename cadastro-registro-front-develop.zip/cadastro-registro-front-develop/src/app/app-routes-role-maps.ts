import { Role } from '@auth/auth-guard/Role';
import { RoleRouteMap } from '@auth/auth-guard/auth-guard.service';

export const appRoutesRoleMaps: RoleRouteMap[] = [
  {
    routes: [
      'administracao/novo-documento',
      'administracao/novo-criterio-associacao',
      'administracao/listagem-criterio-associacao',
      'administracao/validacao-em-lote',
      'administracao/editar-criterio-associacao/:id',
      'administracao/listagem-ramo',
      'administracao/novo-ramo',
      'administracao/editar-ramo/:id',
      'administracao/listagem-orgao-regulador',
      'administracao/novo-orgao-regulador',
      'administracao/editar-orgao-regulador/:id',
      'administracao/listagem-sindicato-cooperativa',
      'administracao/listagem-segmento',
      'administracao/novo-segmento',
      'administracao/editar-segmento/:id',
      'administracao/listagem-produto-servico',
      'administracao/novo-produto-servico',
      'administracao/editar-produto-servico/:id',
      'administracao/listagem-unidade-estadual',
      'administracao/listagem-tipoEndereco',
      'administracao/novo-tipo',
      'administracao/editar-tipo/:id',
      'administracao/listagem-cargo',
      'administracao/novo-cargo',
      'administracao/editar-cargo/:id',
      'administracao/listagem-sistema-vinculacao',
      'administracao/novo-sistema-vinculacao',
      'administracao/editar-sistema-vinculacao/:id',
      'administracao/listagem-orgao',
      'administracao/novo-orgao',
      'administracao/editar-orgao/:id',
      'relatorio/cooperativas-registradas',
      'administracao/listagem-regional',
      'administracao/novo-regional',
      'administracao/editar-regional/:id',
      'administracao/listagem-solicitacao',
      'administracao/nova-solicitacao',
      'administracao/editar-solicitacao/:id',
      'administracao/certificado-unidade-estadual',
      'administracao/novo-complemento-anuario',
      'administracao/listagem-complemento-anuario',
      'administracao/complemento-anuario/:id',
      'administracao/controle-disparo-email',
      'administracao/controle-anuario'
    ],
    roles: [Role.CADASTRO_REGISTRO_NACIONAL],
    types: ['N']
  },
  {
    routes: [
      'cooperativa/anuario/:id'
    ],
    roles: [Role.CADASTRO_REGISTRO_NACIONAL, Role.CADASTRO_REGISTRO_ESTADUAL],
    types: ['N', 'E']
  },
  {
    routes: [
      'administracao/complemento-anuario-ue'
    ],
    roles: [Role.CADASTRO_REGISTRO_ESTADUAL],
    types: ['E']
  }
];
