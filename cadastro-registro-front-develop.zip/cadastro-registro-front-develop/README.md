# Soucoop (Frontend)
Frontend do sistema de cadastro e registro de cooperativas

## Serviços de backend utilizados
* [api-cadastro-registro](http://git.somoscooperativismo.coop.br/administradores/api-cadastro-registro)
* [documentacao-api](http://git.somoscooperativismo.coop.br/administradores/documentacao-api)
* [gerencia-usuario](http://git.somoscooperativismo.coop.br/administradores/gerencia-usuario)
* [localizacao](http://git.somoscooperativismo.coop.br/administradores/LOCALIZACAO)
* [portal-acesso-api](http://git.somoscooperativismo.coop.br/administradores/relatorio-api)
* [relatorio-api](http://git.somoscooperativismo.coop.br/administradores/relatorio-api)
* [file-upload](http://git.somoscooperativismo.coop.br/administradores/file-upload)
* [pessoa-api](http://git.somoscooperativismo.coop.br/administradores/pessoa-api)
* [cadastro-registro-leitura-api](http://git.somoscooperativismo.coop.br/administradores/cadastro-registro-leitura-api)


## Setup e Execução em ambiente de desenvolvimento
1. Inicie os serviços acima através de alguma IDE Java (Eclipse, IntelliJ)

2. Após clonar o projeto com o git, no diretório do projeto, inicilize o projeto git vinculado public-includes:
```
 git submodule init
 git submodule update
```
Uma pasta `src/public` será criada e o projeto public-includes será inicializado dentro dela.

_Obs.: É possivel que os comandos `git submodules...` retornem algum erro se executados no terminal dentro da IDE. Se for o caso, executar num terminal externo._

3. Instale as dependências do projeto:
 `npm ci`

4. Inicie o projeto:
 `npm start`

## Utilizando serviços _hmlg_ ou _trt_ em ambiente de desenvolvimento

É possível rodar o frontend localmente em desenvolvimento sem ter que rodar os serviços de backend localmente.
Esse cenário é particularmente útil para reproduzir situações nas bases de dados _hmlg_ ou _trt_ sem ter que apontar todos os serviços de backend para os bancos correspondentes.
Para isso basta editar a variável `backendEnv` do arquivo `environment.ts` inserindo o ambiente desejado:

```
export const environment = {
  production: false,
  keycloakConfigFilePath: '/assets/keycloak/keycloak-dev.json',
  backendEnv: 'hmlg'  // (dev|hmlg|trt)
};
```

## Baixar alterações do git que envolvam o submodulo compartilhado (public-includes)

Quando o submódulo public-includes foi atualizado por outro desenvolvedor é necessário atualizar ele também localmente através de um dos meios a seguir:

1. `git pull --recurse-submodules`: Baixa alterações no projeto principal e no public-includes

**OU**

2. `git submodule update`: Após executar um pull normal

## Fazendo alterações que envolvam o submodulo compartilhado (public-includes)
O submodulo public-includes (src/public) contém serviços compartilhados entre os frontends de vários projetos, como autenticação, apis de acesso aos serviços do backend, dentre outros. Cada commit do git no projeto pai está vinculado à um commit específico do modulo public-includes, por isso é necessário manter a referência adequada.

_Obs.: A versão em uso do public-includes não é uma lib angular, por isso não deve ser utilizada como pacote npm, mas simplesmente como um submodulo do git._

Para fazer alterações no public-includes, demandadas por uma alteração no projeto pai, é recomendável criar também uma branch correspondente no public-includes, por exemplo:
1. Criar a branch no projeto pai (Ex.: cadastro-registro-front):
 `git checkout -b feature/SOUC-X`
2. Após, criar a branch no public-includes:
 ```
 cd src/public
 git checkout -b feature/SOUC-X
```
3. Ao finalizar a alterações fazer o merge na ordem inversa, ou seja, executando primeito o merge para a develop na public e depois no projeto pai. Isso é necessário para que o projeto pai receba uma referência atualizada do submodulo já com o merge feito e essa referência faça parte do commit do projeto pai.

## Cuidados ao alterar a public-includes
A public-includes contém código reutilizado por vários projetos, por isso é necessário manter a compatibilidade entre eles, para que uma alteração não quebre outro projeto. Algumas diretrizes recomendadas ao alterar a public-includes:
* **Modulos de acesso as apis de backend**: 
    * Utilizar um NgModule para cada serviço de backend, de maneira que seja possivel importar nos projetos dependentes somente os serviços desejados
    * As models devem refletir exatamente os campos e tipos das entities dos serviços de backend. Mesmo que uma aplicação específica não utilize um campo, todos os campos devem estar declarados para fins de compatibilidade.
    * Os services devem **somente** buscar, enviar e retornar dados. Nenhuma lógica de alguma aplicação específica deve ser implementada dentro desses services.
* **Módulos com componentes de interface**
    * Não misturar compoenentes PrimeNG e Material no mesmo NGModule: Como alguns projetos utilizam PrimeNG e outros Material como base de componentes gráficos, não é possivel, em geral, criar componentes gráficos totalmente reutilizáveis. Nesse caso os componentes devem estar isolados para que ao importar um módulo gráfico em algum projeto não seja necessário utilizar dependências desnecessárias.

