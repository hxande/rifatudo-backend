java -jar target\localizacao-api-0.0.1-SNAPSHOT.jar ^
	--spring.profiles.active=production ^
	--spring.cloud.config.name=localizacao-service ^
	--spring.cloud.config.discovery.service-id=config ^
	--spring.cloud.config.discovery.enabled=true ^
	--eureka.client.serviceUrl.defaultZone=http://prius.ocb.org.br:8082/eureka/