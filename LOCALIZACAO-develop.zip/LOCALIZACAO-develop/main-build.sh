#!/bin/bash
#rm -f *.conf Dockerfile 2>/dev/null
#wget -q http://git.somoscooperativismo.coop.br/nilton.araruna/teste_release/blob/develop/ARQUITETURA/cicd/ci-cd.sh
#chmod +x ./ci-cd.sh && ./ci-cd.sh
SIGLA=$(echo $PROJECT | cut -d '-' -f 1 | tr '[:lower:]' '[:upper:]')
AMBIENTE=$(echo $CI_BUILD_REF_NAME | tr '[:lower:]' '[:upper:]')
wget -q http://git.somoscooperativismo.coop.br/nilton.araruna/teste_release/blob/develop/ARQUITETURA/cicd/environments.sh
chmod +x environments.sh && ./environments.sh $SIGLA $AMBIENTE
mkdir -p compilados
mvn clean install package
mv target/* compilados/
wget -q http://git.somoscooperativismo.coop.br/nilton.araruna/teste_release/blob/develop/Dockerfile
mv openshift/ compilados/ target/
#wget -q http://git.somoscooperativismo.coop.br/nilton.araruna/teste_release/blob/develop/ARQUITETURA/cicd/config-map.sh
#chmod +x config-map.sh && ./config-map.sh
