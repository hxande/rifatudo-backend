package br.coop.somoscooperativismo.localizacao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.JacksonJsonHttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;
import tools.jackson.core.exc.StreamReadException;
import tools.jackson.databind.DatabindException;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.util.Map;

import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

@ContextConfiguration
public class BaseTestRestController {

	protected MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType());

	@Autowired
	protected WebApplicationContext webApplicationContext;

	protected MockMvc mockMvc;

	protected final JacksonJsonHttpMessageConverter jsonHttpMessageConverter =
			new JacksonJsonHttpMessageConverter(JsonMapper.builder().build());

	protected String json(Object o) throws IOException {
		var mockHttpOutputMessage = new MockHttpOutputMessage();
		jsonHttpMessageConverter.write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);
		return mockHttpOutputMessage.getBodyAsString();
	}

	public void setup() throws Exception {
		mockMvc = webAppContextSetup(webApplicationContext).build();
	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new JsonMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	@SuppressWarnings("unchecked")
	protected Map<String, Object> convertJsonStringToObject(String json)
			throws IOException, StreamReadException, DatabindException {
		ObjectMapper mapper = new JsonMapper();
		return mapper.readValue(json, Map.class);
	}
}
