package br.coop.somoscooperativismo.localizacao.api.v1.paises;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class PaisTest {

	@Test
	public void testPaisGettersAndSetters() {
		Pais pais = new Pais();

		pais.setId(1);
		pais.setBrasil(true);
		pais.setNome("Brasil");
		pais.setSituacao(true);

		assertThat(pais.getId()).isEqualTo(1);
		assertThat(pais.getNome()).isEqualTo("Brasil");
		assertThat(pais.getSituacao()).isEqualTo(true);
	}
}