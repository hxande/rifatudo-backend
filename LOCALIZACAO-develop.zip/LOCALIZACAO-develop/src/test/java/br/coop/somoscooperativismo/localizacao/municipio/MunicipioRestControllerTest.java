package br.coop.somoscooperativismo.localizacao.municipio;

import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioService;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.Regional;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.RegionalRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.RegionalService;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;
import br.coop.somoscooperativismo.localizacao.BaseTestRestController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class MunicipioRestControllerTest extends BaseTestRestController{
	
	Municipio municipio;
	Pais pais;
	Regiao regiao;
	Regional regional;
	UF uf;
	
	Pageable pageable;
	Page<Municipio> page;
	
	List<Municipio> listaMunicipio;
	
	@MockitoBean
	MunicipioRepository municipioRepository;
	
	@MockitoBean
	RegionalRepository regionalRepository;

	@BeforeEach
	public void setup() throws Exception {
		super.setup();
		
		pais = ClasseConstrutora.buildPais();
		regiao = ClasseConstrutora.buildRegiao();
		uf = ClasseConstrutora.buildUf();
		regional = ClasseConstrutora.buildRegional();
		municipio = ClasseConstrutora.buildMunicipio();
		
		listaMunicipio = Arrays.asList(new Municipio[] {municipio});
		
		pageable = PageRequest.of(0, 1);		
		page = new PageImpl<>(listaMunicipio);
		
		when(municipioRepository.findAll()).thenReturn(listaMunicipio);
		when(municipioRepository.findById(any(Integer.class))).thenReturn(Optional.of(municipio));
		when(municipioRepository.buscarPorNomeLikeQuery(any(String.class))).thenReturn(listaMunicipio);
		when(municipioRepository.buscarPorCepLikeQuery(any(String.class))).thenReturn(listaMunicipio);
		when(municipioRepository.save(any(Municipio.class))).thenReturn(municipio);
		when(municipioRepository.buscarPorIdUf(any(Integer.class), any(Pageable.class))).thenReturn(new PageImpl<>(listaMunicipio));
		when(municipioRepository.buscarPorIdRegional(any(Integer.class))).thenReturn(listaMunicipio);
		when(municipioRepository.buscarPorCodIbge(any(Integer.class))).thenReturn(listaMunicipio);
		when(municipioRepository.buscarPorCodSerpro(any(Integer.class))).thenReturn(listaMunicipio);
		when(municipioRepository.buscarPorNomeRegionalLikeQuery(any(String.class))).thenReturn(listaMunicipio);
		when(municipioRepository.buscarPorIdPais(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(municipioRepository.buscarPorNomeUfLikeQuery(any(String.class), any(Pageable.class))).thenReturn(page);
		when(municipioRepository.buscarPorSiglaUfLikeQuery(any(String.class), any(Pageable.class))).thenReturn(page);
		when(regionalRepository.findById(any(Integer.class))).thenReturn(Optional.of(regional));
	}
	
	@Test
	public void lista() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void buscar() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/" + regiao.getId()))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
				
		when(municipioRepository.findById(any(Integer.class))).thenReturn(Optional.ofNullable(null));
		//Inexistente
		result = mockMvc.perform(get("/public/api/v1/municipios/7000"))
				.andDo(print())
				.andExpect(status().is4xxClientError())
				.andReturn();
				assertThat(result.getResponse().getStatus()).isEqualTo(400);
	}
	
	@Test
	public void buscaPorNome() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/buscarPorNome/?nome=São"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void buscaPorCep() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/buscarPorCep/" + municipio.getCepMunicipio()))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
		when(municipioRepository.buscarPorCepLikeQuery(any(String.class))).thenReturn(new ArrayList<>());
		 result = mockMvc.perform(get("/public/api/v1/municipios/buscarPorCep/70001235")).andExpect(status().is4xxClientError())
					.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(400);
	}
	@Test
	public void buscarPorIdUf() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/buscarPorIdUf?idUf=1"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
		when(municipioRepository.buscarPorIdUf(any(Integer.class), any(Pageable.class))).thenReturn(new PageImpl<>(new ArrayList<>()));
		result = mockMvc.perform(get("/public/api/v1/municipios/buscarPorIdUf?idUf=7000")).andExpect(status().is4xxClientError())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(400);

	}
	
	@Test
	public void alteraRegional() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/alteraRegional/1/2"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);

		when(regionalRepository.findById(any(Integer.class))).thenReturn(Optional.ofNullable(null));
		result = mockMvc.perform(get("/public/api/v1/municipios/alteraRegional/1/7000"))
				.andExpect(status().is4xxClientError())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(404);
		
		when(municipioRepository.findById(any(Integer.class))).thenReturn(Optional.ofNullable(null));
		result = mockMvc.perform(get("/public/api/v1/municipios/alteraRegional/1/7000"))
				.andExpect(status().is4xxClientError())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(404);

	}
	
	@Test
	public void removeRegional() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/removeRegional/1"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
		when(municipioRepository.findById(any(Integer.class))).thenReturn(Optional.ofNullable(null));
		result = mockMvc.perform(get("/public/api/v1/municipios/removeRegional/7000")).andExpect(status().is4xxClientError())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(400);
	}
	
	@Test
	public void buscarPorIdRegional() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/municipios/buscarPorIdRegional/1"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
	}
}
