package br.coop.somoscooperativismo.localizacao.municipio;

import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class MunicipioServiceTest {

    @Autowired
    MunicipioService municipioService;

    @MockitoBean
    MunicipioRepository municipioRepository;

    Municipio municipio;

    @BeforeEach
    public void setup() {
        municipio = ClasseConstrutora.buildMunicipio();

        when(municipioRepository.findById(any(Integer.class))).thenReturn(Optional.of(municipio));
        when(municipioRepository.save(any(Municipio.class))).thenReturn(municipio);
    }

    @Test
    public void updateMunicipio() throws Exception {
        Municipio teste = municipioService.updateMunicipio(municipio);
        assertThat(teste).isEqualTo(municipio);
    }
}
