package br.coop.somoscooperativismo.localizacao.regional;

import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.Regional;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.RegionalRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.RegionalTO;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;
import br.coop.somoscooperativismo.localizacao.BaseTestRestController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class RegionalRestControllerTest extends BaseTestRestController{

	@MockitoBean
	RegionalRepository regionalRepository;

	@MockitoBean
	MunicipioRepository municipioRepository;

	UF uf;
	Pais pais;
	Regiao regiao;
	Regional regional;
	RegionalTO regionalTO;
	Municipio municipio;
	List<Regional> listaRegional;
	List<Municipio> municipios;

	@BeforeEach
	public void setup() throws Exception {
		super.setup();
		
		pais = ClasseConstrutora.buildPais();
		regiao = ClasseConstrutora.buildRegiao();
		uf = ClasseConstrutora.buildUf();
		municipio = ClasseConstrutora.buildMunicipio();
		
		municipios = Arrays.asList(new Municipio[] {municipio});
		
		regional = new Regional();
		regional.setId(1);
		regional.setNome("OESTE");
		regional.setUf(uf);
		
		regionalTO = new RegionalTO();
		regionalTO.setMunicipios(municipios);
		regionalTO.setRegional(regional);
		listaRegional = Arrays.asList(new Regional[] {regional});
		
		when(regionalRepository.findById(any(Integer.class))).thenReturn(Optional.of(regional));
		when(regionalRepository.findAll()).thenReturn(listaRegional);
		when(regionalRepository.buscarPorNomeLikeQuery(any(String.class))).thenReturn(listaRegional);
		when(regionalRepository.buscarPorIdUf(any(Integer.class))).thenReturn(listaRegional);
		when(regionalRepository.save(any(Regional.class))).thenReturn(regional);
		when(regionalRepository.filtra(any(String.class), any(String.class), any(Pageable.class))).thenReturn(new PageImpl<>(listaRegional));
		when(municipioRepository.findById(any(Integer.class))).thenReturn(Optional.of(municipio));
		doNothing().when(regionalRepository).deleteById(any(Integer.class));
	}
	
	@Test
	public void buscar() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/regionais/" + regiao.getId())).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
		when(regionalRepository.findById(any(Integer.class))).thenReturn(Optional.ofNullable(null));
		//Inexistente
		result = mockMvc.perform(get("/public/api/v1/regionais/99"))
				.andExpect(status().is4xxClientError())
				.andReturn();
				assertThat(result.getResponse().getStatus()).isEqualTo(404);
	}
	
	@Test
	public void listaCooperativaRegistro() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/regionais")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void buscaPorNome() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/regionais/buscaPorNome?nome=teste")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void buscaPorIdUf() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/regionais/buscaPorIdUf?idUf=1")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

	@Test
	public void filtro() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/regionais/filtro")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void buscaRegionaisNaoPaginado() throws Exception{
		MvcResult result = mockMvc.perform(get("/public/api/v1/regionais/buscaRegionaisNaoPaginado")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

}
