package br.coop.somoscooperativismo.localizacao.endereco;

import br.coop.somoscooperativismo.localizacao.BaseTestRestController;
import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.distritos.Distrito;
import br.coop.somoscooperativismo.localizacao.api.v1.distritos.DistritoRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.enderecos.Endereco;
import br.coop.somoscooperativismo.localizacao.api.v1.enderecos.EnderecoRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.Regional;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class EnderecoRestControllerTest extends BaseTestRestController {

	@MockitoBean
	EnderecoRepository enderecoRepository;
	
	@MockitoBean
	MunicipioRepository municipioRepository;

	@MockitoBean
	DistritoRepository distritoRepository;

	Endereco endereco;
	Municipio municipio;
	UF uf;
	Regiao regiao;
	Regional regional;
	Pais pais;
	Distrito distrito;
	
	List<Endereco> enderecos;
	List<Endereco> enderecosVazio;
	List<Municipio> municipios;
	
	
	@BeforeEach
	public void setup() throws Exception {
		super.setup();
		
		pais = ClasseConstrutora.buildPais();
		regiao = ClasseConstrutora.buildRegiao();
		uf = ClasseConstrutora.buildUf();
		regional = ClasseConstrutora.buildRegional();
		municipio = ClasseConstrutora.buildMunicipio();
		endereco = ClasseConstrutora.buildEndereco();
		distrito = ClasseConstrutora.buildDistrito();

		enderecos = Arrays.asList(new Endereco[] {endereco});
		enderecosVazio = new ArrayList<>();
		municipios = Arrays.asList(new Municipio[] {municipio});
		
		when(enderecoRepository.buscarPorCep(any(String.class))).thenReturn(enderecos);
		when(municipioRepository.buscarPorCepLikeQuery(any(String.class))).thenReturn(municipios);
		when(distritoRepository.buscarPorCep(any(String.class))).thenReturn(List.of(distrito));
	}

	@Test
	public void deverRecuperarEnderecoComSucesso() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/enderecos/buscarPorCep/" + endereco.getCep()))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

	@Test
	public void deverRecuperarListaVazia() throws Exception {
		when(enderecoRepository.buscarPorCep(any(String.class))).thenReturn(enderecosVazio);

		MvcResult result = mockMvc.perform(get("/public/api/v1/enderecos/buscarPorCep/12312312"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

	@Test
	public void deveRetornarCepInvalido() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/enderecos/buscarPorCep/15"))
				.andExpect(status().is2xxSuccessful())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

	@Test
	public void deveRetornarEnderecoVazio() throws Exception {
		when(municipioRepository.buscarPorCepLikeQuery(any(String.class))).thenReturn(null);

		MvcResult result = mockMvc.perform(get("/public/api/v1/enderecos/buscarPorCep/12312312"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
}
