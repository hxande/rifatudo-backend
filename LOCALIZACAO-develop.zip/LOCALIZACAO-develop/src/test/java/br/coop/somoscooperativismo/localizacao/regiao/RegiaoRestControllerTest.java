package br.coop.somoscooperativismo.localizacao.regiao;

import br.coop.somoscooperativismo.localizacao.BaseTestRestController;
import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.RegiaoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class RegiaoRestControllerTest extends BaseTestRestController{

	@MockitoBean
	RegiaoRepository regiaoRepository;

	Pais pais;
	Regiao regiao;
	
	List<Regiao> listaRegiao;
	Pageable pageable;
	Page<Regiao> page;

	@BeforeEach
	public void setup() throws Exception {
		super.setup();
		
		pais = ClasseConstrutora.buildPais();
		regiao = ClasseConstrutora.buildRegiao();
		
		listaRegiao = Arrays.asList(new Regiao[] {regiao});
		
		pageable = PageRequest.of(0, 1);
		page = new PageImpl<>(listaRegiao);
		
		when(regiaoRepository.findById(any(Integer.class))).thenReturn(Optional.of(regiao));
		when(regiaoRepository.findAll(any(Pageable.class))).thenReturn(new PageImpl<>(listaRegiao));
		when(regiaoRepository.save(any(Regiao.class))).thenReturn(regiao);
		when(regiaoRepository.buscaRegioesNaoPaginado()).thenReturn(listaRegiao);
		when(regiaoRepository.buscarPorNomeLikeQuery(any(String.class), any(Pageable.class))).thenReturn(page);
		when(regiaoRepository.buscarPorIdPais(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(regiaoRepository.buscarPorSituacao(any(Boolean.class), any(Pageable.class))).thenReturn(page);
		when(regiaoRepository.buscaRegioesNaoPaginado()).thenReturn(listaRegiao);
	}
	
	@Test
	public void deveBuscarComSucesso() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/regioes/" + regiao.getId()))
				.andExpect(status().isOk())
				.andReturn();

		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

	@Test
	public void deveGerarExcecaoAoBuscar() throws Exception {
		when(regiaoRepository.findById(any(Integer.class))).thenReturn(Optional.empty());

		MvcResult result = mockMvc.perform(get("/public/api/v1/regioes/99"))
				.andExpect(status().is4xxClientError())
				.andReturn();

		assertThat(result.getResponse().getStatus()).isEqualTo(404);
	}
	
	@Test
	public void listRegioesPaginado() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/regioes")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
	}
	
	@Test
	public void listaRegioesNaoPaginado() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/regioes/buscaRegioesNaoPaginado/")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
}
