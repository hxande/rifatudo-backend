package br.coop.somoscooperativismo.localizacao;

import br.coop.somoscooperativismo.localizacao.api.v1.distritos.Distrito;
import br.coop.somoscooperativismo.localizacao.api.v1.enderecos.Endereco;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.Regional;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;

public class ClasseConstrutora {

    public static Pais buildPais() {
        Pais pais = new Pais();
        pais.setBrasil(true);
        pais.setId(1);
        pais.setNome("BRASIL");
        pais.setSituacao(true);

        return pais;
    }

    public static Regiao buildRegiao() {
        Regiao regiao = new Regiao();
        regiao.setId(1);
        regiao.setNome("NORTE");
        regiao.setPais(buildPais());
        regiao.setSituacao(true);

        return regiao;
    }

    public static UF buildUf() {
        UF uf = new UF();
        uf.setCodigoCorreios(123);
        uf.setCodigoIbge(123);
        uf.setCodigoSerpro(132);
        uf.setId(1);
        uf.setNome("SAO PAULO");
        uf.setPais(buildPais());
        uf.setRegiao(buildRegiao());
        uf.setSigla("SP");
        uf.setSituacao(true);

        return uf;
    }

    public static Regional buildRegional() {
        Regional regional = new Regional();
        regional.setId(1);
        regional.setNome("OESTE");
        regional.setUf(buildUf());

        return regional;
    }

    public static Municipio buildMunicipio() {
        Municipio municipio = new Municipio();
        municipio.setCepMunicipio("72155802");
        municipio.setCodigoIbgeMunicipio(123);
        municipio.setCodigoSerproMunicipio(123);
        municipio.setId(1);
        municipio.setLatitude(0.0);
        municipio.setLongitude(0.0);
        municipio.setNome("Municipio");
        municipio.setNomeComUf("Municipio DF");
        municipio.setPais(buildPais());
        municipio.setRegional(buildRegional());
        municipio.setUf(buildUf());

        return municipio;
    }

    public static Endereco buildEndereco() {
        Endereco endereco = new Endereco();
        endereco.setId(1);
        endereco.setCep("72155060");
        endereco.setComplemento("Apartamento");
        endereco.setBairro("Centro");
        endereco.setLogradouro("Av. dos Testes, 333B");
        endereco.setMunicipio(buildMunicipio());

        return endereco;
    }

    public static Distrito buildDistrito() {
        Distrito distrito = new Distrito();
        distrito.setId(1);
        distrito.setCep("72200000");
        distrito.setNomeDistrito("Nome do distrito");
        distrito.setMunicipio(buildMunicipio());
        distrito.setUfs(buildUf());

        return distrito;
    }
}
