package br.coop.somoscooperativismo.localizacao.regiao;

import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.RegiaoRepository;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.RegiaoService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class RegiaoServiceTest {

    @Autowired
    RegiaoService regiaoService;

    @MockitoBean
    RegiaoRepository regiaoRepository;

    Pais pais;
    Regiao regiao;
    List<Regiao> listaRegiao;
    Pageable pageable;
    Page<Regiao> page;

    @BeforeEach
    public void setup() throws Exception {
        pais = ClasseConstrutora.buildPais();
        regiao = ClasseConstrutora.buildRegiao();

        listaRegiao = Arrays.asList(new Regiao[] {regiao});
        pageable = PageRequest.of(0, 1);
        page = new PageImpl<>(listaRegiao);

        when(regiaoRepository.findById(any(Integer.class))).thenReturn(Optional.of(regiao));
        when(regiaoRepository.findAll(any(Pageable.class))).thenReturn(new PageImpl<>(listaRegiao));
        when(regiaoRepository.save(any(Regiao.class))).thenReturn(regiao);
        when(regiaoRepository.buscaRegioesNaoPaginado()).thenReturn(listaRegiao);
        when(regiaoRepository.buscarPorNomeLikeQuery(any(String.class), any(Pageable.class))).thenReturn(page);
        when(regiaoRepository.buscarPorIdPais(any(Integer.class), any(Pageable.class))).thenReturn(page);
        when(regiaoRepository.buscarPorSituacao(any(Boolean.class), any(Pageable.class))).thenReturn(page);
        when(regiaoRepository.buscaRegioesNaoPaginado()).thenReturn(listaRegiao);
    }

    @Test
    public void getRegiaoByName() {
        Page<Regiao> teste = regiaoService.buscarPorNome(regiao.getNome(), pageable);
        assertThat(teste).isEqualTo(page);
    }

    @Test
    public void getRegiaoBySituacao() {
        Page<Regiao> teste = regiaoService.buscarPorSituacao(regiao.getSituacao(), pageable);
        assertThat(teste).isEqualTo(page);
    }

    @Test
    public void getRegiaoNaoPaginado() {
        List<Regiao> teste = regiaoService.buscaRegioesNaoPaginado();
        assertThat(teste).isEqualTo(listaRegiao);
    }
}
