package br.coop.somoscooperativismo.localizacao.uf;

import br.coop.somoscooperativismo.localizacao.BaseTestRestController;
import br.coop.somoscooperativismo.localizacao.ClasseConstrutora;
import br.coop.somoscooperativismo.localizacao.LocalizacaoApplication;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UfRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MvcResult;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = LocalizacaoApplication.class)
@WebAppConfiguration
public class UfRestControllerTest extends BaseTestRestController {

	@MockitoBean
	UfRepository ufRepository;

	Pais pais;
	Regiao regiao;
	UF uf;
	
	List<UF> listaUf;
	
	Pageable pageable;
	Page<UF> page;


	@BeforeEach
	public void setup() throws Exception {
		super.setup();
		
		pais = ClasseConstrutora.buildPais();
		regiao = ClasseConstrutora.buildRegiao();
		uf = ClasseConstrutora.buildUf();
		
		listaUf = Arrays.asList(new UF[] {uf});
		
		pageable = PageRequest.of(0, 1);		
		page = new PageImpl<>(listaUf);
		
		when(ufRepository.findAll()).thenReturn(listaUf);
		when(ufRepository.findById(any(Integer.class))).thenReturn(Optional.of(uf));
		when(ufRepository.save(any(UF.class))).thenReturn(uf);
		when(ufRepository.buscarPorSiglaQuery(any(String.class))).thenReturn(listaUf);
		when(ufRepository.buscaUFsPeloRegiaoId(any(Integer.class))).thenReturn(listaUf);
		when(ufRepository.buscarUfsNaoPaginado()).thenReturn(listaUf);
		when(ufRepository.buscarPorIdRegiao(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(ufRepository.buscarPorCodigoCorreios(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(ufRepository.buscarPorCodigoSerpro(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(ufRepository.buscarPorCodigoIbge(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(ufRepository.buscarPorIdPais(any(Integer.class), any(Pageable.class))).thenReturn(page);
		when(ufRepository.buscarPorSituacao(any(Boolean.class), any(Pageable.class))).thenReturn(page);
		when(ufRepository.buscarPorSiglasQuery(any())).thenReturn(listaUf);
		
		doNothing().when(ufRepository).deleteById(any(Integer.class));
	}
	
	@Test
	public void listarUf() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void listarUfNaoPaginado() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs/nao-paginado")).andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void listarUfById() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs/" + uf.getId()))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);

		//Inexistente
		when(ufRepository.findById(any(Integer.class))).thenReturn(Optional.ofNullable(null));
		result = mockMvc.perform(get("/public/api/v1/ufs/99"))
				.andExpect(status().is4xxClientError())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(404);
	}
	
	@Test
	public void listarUfBySigla() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs/buscaSigla/?sigla=DF"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
		
		when(ufRepository.buscarPorSiglaQuery(any(String.class))).thenReturn(null);
		//Inexistente
		result = mockMvc.perform(get("/public/api/v1/ufs/buscaSigla/?sigla=inexistente"))
				.andExpect(status().is4xxClientError())
				.andReturn();
				assertThat(result.getResponse().getStatus()).isEqualTo(404);
	}
	
	@Test
	public void listarUfByRegiao() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs/buscaUFPorRegiao/1"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}
	
	@Test
	public void listarTodasUfs() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs/buscarUfsNaoPaginado/"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);
	}

	@Test
	public void listarUfsBySiglas() throws Exception {
		MvcResult result = mockMvc.perform(get("/public/api/v1/ufs/buscaSiglas/?siglas=PR,AC"))
				.andExpect(status().isOk())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(200);

		when(ufRepository.buscarPorSiglasQuery(any())).thenReturn(null);

		//Uf não encontrada
		result = mockMvc.perform(get("/public/api/v1/ufs/buscaSiglas/?siglas="))
				.andExpect(status().is4xxClientError())
				.andReturn();
		assertThat(result.getResponse().getStatus()).isEqualTo(400);
	}
}
