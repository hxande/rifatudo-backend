package br.coop.somoscooperativismo.localizacao.api.v1.ufs;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface UfRepository extends JpaRepository<UF, Integer> {

	@Query("select uf from UF uf where uf.sigla like :sigla")
	public List<UF> buscarPorSiglaQuery(@Param("sigla") String sigla);
	
	@Query("select uf from UF uf where uf.pais.id = :idPais")
	public Page<UF> buscarPorIdPais (@Param("idPais") Integer idPais, Pageable pageable);
	
	@Query("select uf from UF uf where uf.regiao.id = :idRegiao")
	public Page<UF> buscarPorIdRegiao (@Param("idRegiao") Integer idRegiao, Pageable pageable);
	
	@Query("select uf from UF uf where uf.situacao = :situacao")
	public Page<UF> buscarPorSituacao (@Param("situacao") Boolean situacao, Pageable pageable);
	
	@Query("select uf from UF uf where uf.codigoIbge = :codigoIbge")
	public Page<UF> buscarPorCodigoIbge (@Param("codigoIbge") Integer codigoIbge, Pageable pageable);
	
	@Query("select uf from UF uf where uf.codigoSerpro = :codigoSerpro")
	public Page<UF> buscarPorCodigoSerpro (@Param("codigoSerpro") Integer codigoSerpro, Pageable pageable);
	
	@Query("select uf from UF uf where uf.codigoCorreios = :codigoCorreios")
	public Page<UF> buscarPorCodigoCorreios (@Param("codigoCorreios") Integer codigoCorreios, Pageable pageable);
	
	@Query("select uf from UF uf where uf.regiao.id = :id")
	public List<UF> buscaUFsPeloRegiaoId(@Param("id") Integer idRegiao);
	
	@Query("select uf from UF uf")
	public List<UF> buscarUfsNaoPaginado();

	Optional<UF> findByCodigoIbge(Integer codigo);

	@Query("SELECT new br.coop.somoscooperativismo.localizacao.api.v1.ufs.EstadoMunicipioDTO(uf.nome, mu.nome) " +
			"FROM UF uf " +
			"JOIN Municipio mu ON mu.uf.id = uf.id " +
			"JOIN Pais pa ON pa.id = uf.pais.id " +
			"WHERE pa.brasil = true " +
			"AND (:sigla is null or LOWER(uf.nome) like %:sigla%) " +
			"AND (:nome is null or LOWER(mu.nome) like %:nome%) " +
			"ORDER BY uf.nome, mu.nome")
	Page<EstadoMunicipioDTO> findAllEstadosMunicipios(@Param("sigla") String sigla, @Param("nome") String nome, Pageable pageable);

	@Query("select uf from UF uf where uf.sigla in (:siglas)")
	List<UF> buscarPorSiglasQuery(@Param("siglas") List<String> siglas);
}

