package br.coop.somoscooperativismo.localizacao.api.v1.ufs;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.type.YesNoConverter;
import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;

import java.util.List;

@Entity
@Table(name = "Estado", schema = "dbo")
public class UF {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_ESTADO")
	private Integer id;
	
	@Column(name = "TX_SIGLA_ESTADO", nullable = false)
	@Size(max = 2, min = 2, message = "deve ter 2 caracteres")
	@NotBlank
	private String sigla;
	
	@Column(name = "TX_ESTADO", nullable = false)
	@Size(max = 50, message = "deve ter no máximo 50 caracteres")
	@NotBlank
	private String nome;
	
	@Column(name = "CD_UF_IBGE")
	private Integer codigoIbge;
	
	@Column(name = "CD_UF_SERPRO")
	private Integer codigoSerpro;
	
	@Column(name = "CD_UF_ECT")
	private Integer codigoCorreios;
	
	@ManyToOne
	@JoinColumn(name = "SQ_PAIS")
	@Fetch(FetchMode.JOIN)
	private Pais pais;
	
	@ManyToOne
	@JoinColumn(name = "SQ_REGIAO_PAIS")
	@Fetch(FetchMode.JOIN)
	private Regiao regiao;
	
	@Column(name = "IN_ATIVO", nullable = false, columnDefinition = "varchar(1)")
	@Convert(converter = YesNoConverter.class)
	private Boolean situacao;

//	@OneToMany(mappedBy = "uf")
//	private Municipio municipio;
	
	
	public UF() {
		
	}
	
	public UF(Integer id, String sigla, String nome, Pais pais, Regiao regiao, Boolean situacao) {
		this.id = id;
		this.sigla = sigla;
		this.nome = nome;
		this.pais = pais;
		this.regiao = regiao;
		this.situacao = situacao;
	}
	
	public UF(Integer id, String sigla, String nome, Pais pais, Regiao regiao, Integer codigoIbge, Integer codigoSerpro, Integer codigoCorreios, Boolean situacao) {
		this.id = id;
		this.sigla = sigla;
		this.nome = nome;
		this.pais = pais;
		this.regiao = regiao;
		this.codigoIbge = codigoIbge;
		this.codigoSerpro = codigoSerpro;
		this.codigoCorreios = codigoCorreios;
		this.situacao = situacao;
	}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	
	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	public Pais getPais() {
		return pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}
	

	public Regiao getRegiao() {
		return regiao;
	}

	public void setRegiao(Regiao regiao) {
		this.regiao = regiao;
	}
	

	public Integer getCodigoIbge() {
		return codigoIbge;
	}

	public void setCodigoIbge(Integer codigoIbge) {
		this.codigoIbge = codigoIbge;
	}
	

	public Integer getCodigoSerpro() {
		return codigoSerpro;
	}

	public void setCodigoSerpro(Integer codigoSerpro) {
		this.codigoSerpro = codigoSerpro;
	}
	

	public Integer getCodigoCorreios() {
		return codigoCorreios;
	}

	public void setCodigoCorreios(Integer codigoCorreios) {
		this.codigoCorreios = codigoCorreios;
	}
	

	public Boolean getSituacao() {
		return situacao;
	}

	public void setSituacao(Boolean situacao) {
		this.situacao = situacao;
	}
	
}
