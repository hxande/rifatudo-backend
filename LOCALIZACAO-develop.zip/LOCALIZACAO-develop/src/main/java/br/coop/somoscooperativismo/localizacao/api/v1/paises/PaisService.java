package br.coop.somoscooperativismo.localizacao.api.v1.paises;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class PaisService {

    private final PaisRepository paisRepository;

    public Page<Pais> fetchAll(Pageable pageable) {
        return paisRepository.findAll(pageable);
    }

}
