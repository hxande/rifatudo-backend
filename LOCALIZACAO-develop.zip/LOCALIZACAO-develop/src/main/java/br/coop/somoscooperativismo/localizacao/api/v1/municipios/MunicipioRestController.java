package br.coop.somoscooperativismo.localizacao.api.v1.municipios;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/public/api/v1/municipios")
@Tag(name = "Municipios")
public class MunicipioRestController {

	@Autowired
	private MunicipioService municipioService;

	@GetMapping
	@Operation(summary = "Lista com os Municípios")
	public Page<Municipio> listarMunicipiosPaginado(Pageable pageable) {
		return municipioService.getAll(pageable);
	}

	@Operation(summary = "Detalha um Município pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public Municipio buscarPorId(@PathVariable Integer id) {
		return municipioService.buscarPorId(id);
	}

	@Operation(summary = "Detalha Municípios pelo nome", description = "Um nome existente deve ser informado")
	@GetMapping("/buscarPorNome/")
	public List<Municipio> buscarPorNome(@RequestParam String nome) {
		return municipioService.buscarPorNome(nome);
	}

	@Operation(summary = "Detalha Municípios pelo CEP", description = "Um CEP existente e válido deve ser informado")
	@GetMapping("/buscarPorCep/{cep}")
	public Municipio buscarPorCep(@PathVariable String cep) {
		return municipioService.buscarPorCep(cep);
	}

	@Operation(summary = "Detalha Todos os Municípios", description = "Não precisa informar um ID.")
	@GetMapping("/buscarTodosMunicipios")
	public Page<Municipio> buscarTodosMunicipios(Pageable pageable) {
		return municipioService.buscarTodosMunicipios(pageable);
	}

	@Operation(summary = "Detalha Municípios pelo ID da UF", description = "Um ID existente e válido deve ser informado")
	@GetMapping("/buscarPorIdUf")
	public Page<Municipio> buscarPorIdUf(@RequestParam Integer idUf, Pageable pageable) {
		return municipioService.buscarPorIdUf(idUf, pageable);
	}

	@Operation(summary = "Detalha Municípios pelas UFS passadas", description = "Uma Sigla existente e válida deve ser informada")
	@GetMapping("/buscarMunicipiosPorUfs/{sigla}")
	public Page<Municipio> buscarMunicipiosPorUfs(
			@PathVariable(required = true) List<String> sigla, 
			@PageableDefault(size = 5999) Pageable pageable) {
		return municipioService.buscarMunicipiosPorUfs(sigla, pageable);
	}
	
	@Operation(summary = "Altera regional de Município", description = "Um ID existente e válido deve ser informado")
	@GetMapping("/alteraRegional/{id}/{idRegional}")
	public ResponseEntity<ServiceResponse<Municipio>> alteraRegional(@PathVariable Integer id, @PathVariable Integer idRegional) {
		return new ResponseEntity<>(new ServiceResponse<>(municipioService.alteraRegional(id, idRegional)), HttpStatus.OK);
	}
	
	@Operation(summary = "Remove regional de Município", description = "Um ID existente e válido deve ser informado")
	@GetMapping("/removeRegional/{id}")
	public ResponseEntity<ServiceResponse<Municipio>> removeRegional(@PathVariable Integer id) {
		return new ResponseEntity<>(new ServiceResponse<>(municipioService.removeRegional(id)), HttpStatus.OK);
	}
	
	@Operation(summary = "Detalha Municípios pelo ID da Regional", description = "Um ID existente e válido deve ser informado")
	@GetMapping("/buscarPorIdRegional/{idRegional}")
	public List<Municipio> buscarPorIdRegional(@PathVariable Integer idRegional) {
		return municipioService.buscarPorIdRegional(idRegional);
	}
	
	@Operation(summary= "Retorna lista de municipios", description = "UF deve ser informada")
	@GetMapping("/buscarTOPorUF/{uf}")
	public List<MunicipioTO> buscarPorUF(@PathVariable String uf) {
		 return municipioService.buscarPorUF(uf);
	}

	@Operation(summary = "Detalha Municípios pelo código do Municípios do Serpro", description = "Um Código do Municípios do Serpro existente e válido deve ser informado")
	@GetMapping("/buscarPorCodigoSerpro/{codSerproMuni}")
	public Municipio buscarPorCep(@PathVariable Integer codSerproMuni) {
		return municipioService.buscarPorCodMuniSerpro(codSerproMuni);
	}

}
