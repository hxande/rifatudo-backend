package br.coop.somoscooperativismo.localizacao.api.v1.enderecos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EnderecoRepository extends JpaRepository<Endereco, Integer> {

	@Query("select e from Endereco e where e.cep = :cep")
	List<Endereco> buscarPorCep(@Param("cep") String cep);
	
	@Query("select e from Endereco e where e.cep = :cep")
	Endereco validaCEP(@Param("cep") String cep);

}
