package br.coop.somoscooperativismo.localizacao.api.v1.municipios;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.NativeQuery;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MunicipioRepository extends JpaRepository<Municipio, Integer> {
	
	@Query("select mun from Municipio mun where mun.nome like %:nome%")
	List<Municipio> buscarPorNomeLikeQuery (@Param("nome") String nome);
	
	@Query("select mun from Municipio mun where mun.cepMunicipio like :cepMunicipio%")
	List<Municipio> buscarPorCepLikeQuery (@Param("cepMunicipio") String cepMunicipio);
	
	@Query("select mun from Municipio mun where mun.codigoIbgeMunicipio = :codigoIbgeMunicipio")
	List<Municipio> buscarPorCodIbge (@Param("codigoIbgeMunicipio") Integer codigoIbgeMunicipio);
	
	@Query("select mun from Municipio mun where mun.codigoSerproMunicipio = :codigoSerproMunicipio")
	List<Municipio> buscarPorCodSerpro (@Param("codigoSerproMunicipio") Integer codigoSerproMunicipio);

	@Query("select mun from Municipio mun where mun.pais.id = :idPais")
	Page<Municipio> buscarPorIdPais (@Param("idPais") Integer idPais, Pageable pageable);
	
	@Query("select mun from Municipio mun")
	Page<Municipio> buscarTodosMunicipios (Pageable pageable);
	
	@Query("select mun from Municipio mun where mun.uf.id = :idUf")
	Page<Municipio> buscarPorIdUf (@Param("idUf") Integer idUf, Pageable pageable);
	
	@Query("select mun from Municipio mun where mun.uf.sigla IN (:sigla)")
	Page<Municipio> buscarMunicipiosPorUfs (@Param("sigla") List<String> sigla, Pageable pageable);
	
	@Query("select mun from Municipio mun where mun.uf.nome like %:nomeUf%")
	Page<Municipio> buscarPorNomeUfLikeQuery (@Param("nomeUf") String nomeUf, Pageable pageable);
	
	@Query("select mun from Municipio mun where mun.uf.sigla like %:siglaUf%")
	Page<Municipio> buscarPorSiglaUfLikeQuery (@Param("siglaUf") String siglaUf, Pageable pageable);
	
	@Query("select mun from Municipio mun where mun.regional.id = :idRegional")
	List<Municipio> buscarPorIdRegional (@Param("idRegional") Integer idRegional);
	
	@Query("select mun from Municipio mun where mun.regional.nome like %:nomeRegional%")
	List<Municipio> buscarPorNomeRegionalLikeQuery (@Param("nomeRegional") String nomeRegional);
	
	@NativeQuery("  SELECT M.SQ_MUNICIPIO, M.TX_NOME_MUNICIPIO  " + 
			"  FROM Municipio M" + 
			"  INNER JOIN Estado E ON E.SQ_ESTADO = M.SQ_ESTADO" + 
			"  WHERE E.TX_SIGLA_ESTADO LIKE :uf")
	List<Object[]> buscarPorUF(@Param("uf") String uf);

	Municipio findByCodigoSerproMunicipio(Integer codigoSerproMunicipio);
}
