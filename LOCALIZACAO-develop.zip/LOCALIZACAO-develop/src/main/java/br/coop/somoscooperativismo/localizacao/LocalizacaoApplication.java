package br.coop.somoscooperativismo.localizacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication(scanBasePackages={"br.coop.somoscooperativismo"})
@ConfigurationPropertiesScan
public class LocalizacaoApplication {
	public static void main(String[] args) {
		SpringApplication.run(LocalizacaoApplication.class, args);
	}
}
