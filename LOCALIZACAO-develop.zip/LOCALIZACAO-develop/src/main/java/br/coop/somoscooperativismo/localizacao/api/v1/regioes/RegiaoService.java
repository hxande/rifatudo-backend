package br.coop.somoscooperativismo.localizacao.api.v1.regioes;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Service
public class RegiaoService {
	
	@Autowired
	private RegiaoRepository regiaoRepository;
	
	@Autowired
	private MessagesService messages;
	
	public static final String REGIAONAOENCONTRADA = "regiao.naoEncontrada";
	public static final String PARAMENTROSUTILIZADOS = "global.parametrosUtilizados";
	
	public Page<Regiao> getAllRegioes(Pageable pageable){
		return regiaoRepository.findAll(pageable);
	}
	
	public Regiao buscarPorId(Integer id) {
		Optional<Regiao> opRegiao = regiaoRepository.findById(id);
		if (opRegiao.isPresent()) {
			return opRegiao.get();
		} else {
			throw new RegraNegocioException(messages.get( REGIAONAOENCONTRADA ) + id, HttpStatus.NOT_FOUND);
		}
	}
	
	public Page<Regiao> buscarPorNome(String nome, Pageable pageable) {
		return regiaoRepository.buscarPorNomeLikeQuery(nome, pageable);
	}
	
	public Page<Regiao> buscarPorSituacao(Boolean situacao, Pageable pageable) {
		return regiaoRepository.buscarPorSituacao(situacao, pageable);
	}
	
	public List<Regiao> buscaRegioesNaoPaginado(){
		return regiaoRepository.buscaRegioesNaoPaginado();
	}
	
}
