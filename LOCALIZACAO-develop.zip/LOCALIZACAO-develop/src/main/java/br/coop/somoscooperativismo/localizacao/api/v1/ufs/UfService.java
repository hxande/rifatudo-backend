package br.coop.somoscooperativismo.localizacao.api.v1.ufs;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Service
public class UfService {
	
	@Autowired
	private UfRepository ufRepository;
	
	@Autowired
	private MessagesService messages;
	
	public static final String UFNAOENCONTRADA = "uf.naoEncontrada";
	public static final String PARAMETROSUTILIZADOS = "global.parametrosUtilizados";
	
	public Page<UF> getAllUfs(Pageable pageable){
		return ufRepository.findAll(pageable);
	}

	public List<UF> getAllUfs(){
		return ufRepository.findAll(Sort.by(Sort.Direction.ASC, "sigla"));
	}
	
	public UF buscarPorId(Integer id) {
		Optional<UF> opUf = ufRepository.findById(id);
		if (opUf.isPresent()) {
			return opUf.get();
		} else {
			throw new RegraNegocioException(messages.get( UFNAOENCONTRADA ) + id, HttpStatus.NOT_FOUND);
		}
	}
	
	public UF buscarPorSigla(String sigla) {
		List<UF> ufs = ufRepository.buscarPorSiglaQuery(sigla != null ? sigla.toUpperCase() : null);
		
		if(ufs != null && !ufs.isEmpty()) {
			return ufs.get(0);
		} else {
			throw new RegraNegocioException(messages.get(UFNAOENCONTRADA) + messages.get(PARAMETROSUTILIZADOS) + sigla, HttpStatus.NOT_FOUND);
		}
	}
	
	public List<UF> buscarPorIdRegiaoNaoPaginado(Integer idRegiao){
		return ufRepository.buscaUFsPeloRegiaoId(idRegiao);
	}
	
	public List<UF> buscarUfsNaoPaginado(){
		return ufRepository.buscarUfsNaoPaginado();
	}

    public UF buscarUfIbge(Integer codigoIbge){
    	Optional<UF> optionalUF = ufRepository.findByCodigoIbge(codigoIbge);
    	if(optionalUF.isPresent()) {
    		return optionalUF.get();
		}
			
    	throw new RegraNegocioException("Nenhuma UF encontrada para esse código do IBGE", HttpStatus.NOT_FOUND);
			
    }

	public Page<EstadoMunicipioDTO> getAll(String sigla, String nome, Pageable pageable) {
		if (sigla.equals("null")) {
			sigla = "";
		}

		if (nome.equals("null")) {
			nome = "";
		}

		Page<EstadoMunicipioDTO> municipios = ufRepository.findAllEstadosMunicipios(sigla, nome, pageable);

		if (!municipios.isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException("Nenhum município encontrado.");
		}
	}

	public List<UF> buscarPorSiglas(List<String> siglas) {
		List<UF> ufs = ufRepository.buscarPorSiglasQuery(siglas);
		if (ufs != null && !ufs.isEmpty()) {
			return ufs;
		} else {
			throw new RegraNegocioException("Nenhuma UF encontrada.");
		}
	}
}
