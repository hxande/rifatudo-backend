package br.coop.somoscooperativismo.localizacao.api.v1.municipios;


public class MunicipioTO {
	Integer id;
	String nome;
	
	
	
	public MunicipioTO(Integer id, String nome) {
		super();
		this.id = id;
		this.nome = nome;
	}
	
	public MunicipioTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}
	public String getNome() {
		return nome;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
}
