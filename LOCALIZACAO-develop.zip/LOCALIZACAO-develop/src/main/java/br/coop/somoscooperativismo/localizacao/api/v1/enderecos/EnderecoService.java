package br.coop.somoscooperativismo.localizacao.api.v1.enderecos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.localizacao.api.v1.distritos.Distrito;
import br.coop.somoscooperativismo.localizacao.api.v1.distritos.DistritoService;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.municipios.MunicipioRepository;
import br.coop.somoscooperativismo.ocbcommonsapi.util.ValidacaoCampos;

@Service
public class EnderecoService {
	
	@Autowired
	private EnderecoRepository enderecoRepository;
	
	@Autowired
	private DistritoService distritoService;

	@Autowired
	private MunicipioRepository municipioRepository;

	public static final String MUNICIPIO_CEP_INVALIDO = "municipio.cepInvalido";
	public static final String ENDERECO_CEP_INVALIDO = "endereco.enderecoNaoEncontrado";

	public Endereco buscarPorCep(String cep) {

		Endereco endereco = new Endereco();
				
		if(cep != null && !"null".equals(cep)) {
			List<Endereco> enderecos = enderecoRepository.buscarPorCep(cep);			
			if (!enderecos.isEmpty()) {
				endereco = enderecos.get(0);
			}
			
			if(endereco.getId() == null) {
				Distrito dist = distritoService.buscarPorCep(cep);
				if(dist != null) {
					endereco = new Endereco();
					endereco.setMunicipio(dist.getMunicipio());
					endereco.setBairro(dist.getNomeDistrito());
				} else {
					String prefixoCep = cep.substring(0, cep.length() - 3);
					
					List<Municipio> municipios = municipioRepository.buscarPorCepLikeQuery(prefixoCep);
					
					if(ValidacaoCampos.validaCampoPreenchido(municipios) && !municipios.isEmpty()) {
						endereco = new Endereco();
						endereco.setMunicipio(municipios.get(0));
					}
				}
			}				
			
		}
		return endereco;
	}
	
	public Endereco validaCep(String cep) {
		Endereco endereco = enderecoRepository.validaCEP(cep);
		return endereco;
	}

}
