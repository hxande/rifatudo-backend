package br.coop.somoscooperativismo.localizacao.api.v1.regionais;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;

@Entity
@Table(name = "Regiao_Unidade_Estadual", schema = "dbo")
public class Regional {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_REGIAO_UNIDADE_ESTADUAL")
	private Integer id;
	
	@Column(name = "TX_NOME_REGIAO_UNIDADE_ESTADUAL", nullable = false)
	@Size(max = 255, message = "deve ter no máximo 255 caracteres")
	@NotBlank
	private String nome;
	
	@ManyToOne
	@JoinColumn(name = "SQ_ESTADO")
	@Fetch(FetchMode.JOIN)
	private UF uf;
	
	
	public Regional() {
		
	}
	
	public Regional(Integer id, String nome, UF uf) {
		this.id = id;
		this.nome = nome;
		this.uf = uf;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
		
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	

	public UF getUf() {
		return uf;
	}

	public void setUf(UF uf) {
		this.uf = uf;
	}
}
