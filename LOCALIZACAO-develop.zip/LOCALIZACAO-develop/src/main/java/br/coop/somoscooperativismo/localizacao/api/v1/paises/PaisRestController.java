package br.coop.somoscooperativismo.localizacao.api.v1.paises;

import br.coop.somoscooperativismo.localizacao.api.v1.regioes.Regiao;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/public/api/v1/paises")
@Tag(name = "Países")
public class PaisRestController {

	private final PaisService paisService;

	@GetMapping
	@Operation(summary = "Lista países")
	public Page<Pais> paisesPaginado(Pageable pageable) {
		return paisService.fetchAll(pageable);
	}

}
