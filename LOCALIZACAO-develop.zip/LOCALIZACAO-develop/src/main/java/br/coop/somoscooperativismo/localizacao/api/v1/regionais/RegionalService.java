package br.coop.somoscooperativismo.localizacao.api.v1.regionais;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RegionalService {

    private final RegionalRepository regionalRepository;

    private final MessagesService messages;

    public static final String REGIONALNAOENCONTRADA = "regional.naoEncontrada";


    public RegionalService(RegionalRepository regionalRepository, MessagesService messages) {
        this.regionalRepository = regionalRepository;
        this.messages = messages;
    }


    public Page<Regional> getAll(Pageable pageable) {
        return regionalRepository.findAll(pageable);
    }


    public Regional buscarPorId(Integer id) {
        Optional<Regional> opRegional = regionalRepository.findById(id);

        if (opRegional.isPresent()) {
            return opRegional.get();
        } else {
            throw new RegraNegocioException(messages.get(REGIONALNAOENCONTRADA) + id, HttpStatus.NOT_FOUND);
        }
    }


    public List<Regional> buscarPorNome(String nome) {
        return regionalRepository.buscarPorNomeLikeQuery(nome);
    }


    public List<Regional> buscarPorIdUf(Integer idUf) {
        return regionalRepository.buscarPorIdUf(idUf);
    }


    public List<Regional> buscarPorSiglaUf(String siglaUf) {
        return regionalRepository.buscarPorSiglaUfLikeQuery(siglaUf);
    }

    public List<Regional> buscarPorListaSiglasUf(List<String> siglasUf) {
        return regionalRepository.buscarPorListaSiglasUf(siglasUf);
    }

    public List<Regional> buscaRegionais() {
        return regionalRepository.findAll();
    }

    public Page<Regional> filtra(String nome, String uf, Pageable pageable) {
        return regionalRepository.filtra(nome, uf, pageable);
    }
}
