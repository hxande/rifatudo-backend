package br.coop.somoscooperativismo.localizacao.api.v1.paises;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.type.YesNoConverter;

@Entity
@Table(name = "Pais", schema = "dbo")
public class Pais {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_PAIS")
	private Integer id;
	
	@Column(name = "TX_PAIS")
	@Size(max = 50, message = "deve ter no máximo 50 caracteres")
	@NotBlank
	private String nome;
	
	@Column(name = "IN_BRASIL", nullable = false, columnDefinition = "varchar(1)")
	@Convert(converter = YesNoConverter.class)
	private Boolean brasil;
	
	@Column(name = "IN_ATIVO", nullable = false, columnDefinition = "varchar(1)")
	@Convert(converter = YesNoConverter.class)
	private Boolean situacao;
	
	
	public Pais() {
		
	}
	
	public Pais(Integer id, String nome) {
		this.id = id;
		this.nome = nome;
		this.brasil = false;
		this.situacao = true;
	}
	
	public Pais(Integer id, String nome, Boolean brasil, Boolean situacao) {
		this.id = id;
		this.nome = nome;
		this.brasil = brasil;
		this.situacao = situacao;
	}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	public Boolean isBrasil() {
		return brasil;
	}

	public void setBrasil(Boolean brasil) {
		this.brasil = brasil;
	}

	
	public Boolean getSituacao() {
		return situacao;
	}

	public void setSituacao(Boolean situacao) {
		this.situacao = situacao;
	}
	
}
