package br.coop.somoscooperativismo.localizacao.api.v1.regionais;

import java.util.List;

import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;

public class RegionalTO {
	Regional regional;
	List<Municipio> municipios;
	
	public Regional getRegional() {
		return regional;
	}
	public List<Municipio> getMunicipios() {
		return municipios;
	}
	public void setRegional(Regional regional) {
		this.regional = regional;
	}
	public void setMunicipios(List<Municipio> municipios) {
		this.municipios = municipios;
	}
}
