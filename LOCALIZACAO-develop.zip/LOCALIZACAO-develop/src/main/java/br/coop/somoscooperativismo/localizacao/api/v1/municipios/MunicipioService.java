package br.coop.somoscooperativismo.localizacao.api.v1.municipios;

import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.Regional;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.RegionalService;
import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MunicipioService {
	
	@Autowired
	private MunicipioRepository municipioRepository;
	
	@Autowired
	private RegionalService regionalService;
	
	@Autowired
	private MessagesService messages;
	
	public static final String MUNICIPIO_CEP_INVALIDO 	= "municipio.cepInvalido";
	public static final String MUNICIPIONAOENCONTRADO 	= "municipio.naoEncontrado";
	public static final String PARAMETROSUTILIZADOS 	= "global.parametrosUtilizados";
	public static final String REGIONAL_NAO_ENCONTRADO = "regional.naoEncontrada";
	
	
	public Municipio createMunicipio(Municipio municipio) {
		Optional<Municipio> opMunicipio = Optional.ofNullable(municipio);
		
		if(opMunicipio.isEmpty()) {
			throw new RegraNegocioException(messages.get("municipio.nulo"));
		}
		if(opMunicipio.get().getNome().isEmpty()) {
			throw new RegraNegocioException(messages.get("municipio.nomeNaoVazio"));
		}
		
		Optional<Pais> opPais = Optional.ofNullable(municipio.getPais());
		if(opPais.isEmpty() || opPais.get().getId() == null) {
			throw new RegraNegocioException(messages.get("municipio.paisNaoVazio"));
		}
		
		return municipioRepository.save(municipio);
	}
	
	public void deleteMunicipio(Integer id) {
		try {
			municipioRepository.deleteById(id);
		} catch (EmptyResultDataAccessException e) {
			 throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + id);
		}
	}
	
	public Page<Municipio> getAll(Pageable pageable){
		return municipioRepository.findAll(pageable);
	}
	
	public Municipio buscarPorId(Integer id) {
		Optional<Municipio> opMunicipio = municipioRepository.findById(id);
		if (opMunicipio.isPresent()) {
			return opMunicipio.get();
		} else {
			throw new RegraNegocioException(messages.get( MUNICIPIONAOENCONTRADO ) + id);
		}
	}
	
	public List<Municipio> buscarPorNome(String nome) {
		return municipioRepository.buscarPorNomeLikeQuery(nome);
	}
	
	public Municipio buscarPorCep(@Valid String cepMunicipio) {
		
		
		if(cepMunicipio.length() != 8) {
			throw new RegraNegocioException(messages.get(MUNICIPIO_CEP_INVALIDO));
		}
		
		String prefixoCep = cepMunicipio.substring(0, cepMunicipio.length() - 3);
		
		List<Municipio> municipios = municipioRepository.buscarPorCepLikeQuery(prefixoCep);
		
		if(!municipios.isEmpty()) {
			return municipios.get(0);
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + cepMunicipio);
		}
	}
	
	public List<Municipio> buscarPorCodIbge(Integer codigoIbgeMunicipio) {
		List<Municipio> municipios = municipioRepository.buscarPorCodIbge(codigoIbgeMunicipio);
		
		if(!municipios.isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + codigoIbgeMunicipio);
		}
	}
	
	public List<Municipio> buscarPorCodSerpro(Integer codigoSerproMunicipio) {
		List<Municipio> municipios = municipioRepository.buscarPorCodSerpro(codigoSerproMunicipio);
		
		if(!municipios.isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + codigoSerproMunicipio);
		}
	}
	
	
	public Page<Municipio> buscarPorIdPais(Integer idPais, Pageable pageable) {
		Page<Municipio> municipios = municipioRepository.buscarPorIdPais(idPais, pageable);
		
		if (!municipios.getContent().isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + idPais);
		}
	}
	
	
	public Page<Municipio> buscarTodosMunicipios(Pageable pageable) {
		Page<Municipio> municipios = municipioRepository.buscarTodosMunicipios(pageable);
		
		if (!municipios.getContent().isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS));
		}
	}
	
	
	public Page<Municipio> buscarPorIdUf(Integer idUf, Pageable pageable) {
		Page<Municipio> municipios = municipioRepository.buscarPorIdUf(idUf, pageable);
		
		if (!municipios.getContent().isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + idUf);
		}
	}
	
	
	public Page<Municipio> buscarMunicipiosPorUfs(List<String> ufs, Pageable pageable) {
		Page<Municipio> municipios = municipioRepository.buscarMunicipiosPorUfs(ufs, pageable);
		
		if(!municipios.getContent().isEmpty()) {
	    	return municipios;
        }else {
        	throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + ufs);
        }
	}
	
	
	public Page<Municipio> buscarPorNomeUf(String nomeUf, Pageable pageable) {
		Page<Municipio> municipios = municipioRepository.buscarPorNomeUfLikeQuery(nomeUf, pageable);
		
		if (!municipios.getContent().isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + nomeUf);
		}
	}
	
	public Page<Municipio> buscarPorSiglaUf(String siglaUf, Pageable pageable) {
		Page<Municipio> municipios = municipioRepository.buscarPorSiglaUfLikeQuery(siglaUf, pageable);
		
		if (!municipios.getContent().isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + siglaUf);
		}
	}
	
	public List<Municipio> buscarPorIdRegional(Integer idRegional) {
		return municipioRepository.buscarPorIdRegional(idRegional);
	}
	
	public List<Municipio> buscarPorNomeRegional(String nomeRegional) {
		List<Municipio> municipios = municipioRepository.buscarPorNomeRegionalLikeQuery(nomeRegional);
		
		if(!municipios.isEmpty()) {
			return municipios;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + nomeRegional);
		}
	}
	
	
	public Municipio updateMunicipio(Municipio municipio) {
		Optional<Municipio> existingMunicipio = municipioRepository.findById(municipio.getId());
		if (existingMunicipio.isPresent()) {
			return municipioRepository.save(municipio);
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + municipio.getId());
		}
	 }

	public Municipio alteraRegional(@Valid Integer id, @Valid Integer idRegional) {
		Optional<Municipio> m = municipioRepository.findById(id);
		Regional r = regionalService.buscarPorId(idRegional);
		
		if(m.isEmpty()) {
			throw new RegraNegocioException(MUNICIPIONAOENCONTRADO);
		}
		if(r == null) {
			throw new RegraNegocioException(REGIONAL_NAO_ENCONTRADO);
		}
		Municipio municipio = m.get();
		municipio.setRegional(r);
		return municipioRepository.save(municipio);
	}

	public Municipio removeRegional(Integer id) {
		Optional<Municipio> m = municipioRepository.findById(id);
		if(m.isEmpty()) {
			throw new RegraNegocioException(MUNICIPIONAOENCONTRADO);
		}
		Municipio municipio = m.get();
		municipio.setRegional(null);
		return municipioRepository.save(municipio);
	}
	
	public List<MunicipioTO> buscarPorUF(String uf) {
		List<Object[]> resultList = municipioRepository.buscarPorUF(uf);
		List<MunicipioTO> lista = new ArrayList<>();
		resultList.forEach(obj -> {
			lista.add(new MunicipioTO((Integer) obj[0], (String) obj[1]));
		});
		return lista;
	}

	public Municipio buscarPorCodMuniSerpro(Integer codigoSerproMunicipio) {
		Municipio municipio = municipioRepository.findByCodigoSerproMunicipio(codigoSerproMunicipio);
		if(municipio != null) {
			return municipio;
		} else {
			throw new RegraNegocioException(messages.get(MUNICIPIONAOENCONTRADO) + messages.get(PARAMETROSUTILIZADOS) + codigoSerproMunicipio);
		}
	}

}
