package br.coop.somoscooperativismo.localizacao.api.v1.distritos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DistritoRepository extends JpaRepository<Distrito, Integer> {

	@Query("select d from Distrito d where d.cep = :cep")
	List<Distrito> buscarPorCep(@Param("cep") String cep);

}
