package br.coop.somoscooperativismo.localizacao.api.v1.regionais;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RegionalRepository extends JpaRepository<Regional, Integer> {
	@Query("select regional from Regional regional where regional.uf.id = :idUf")
	List<Regional> buscarPorIdUf(@Param("idUf") Integer idUf);
	
	@Query("select regional from Regional regional where regional.uf.nome like %:nomeUf%")
	List<Regional> buscarPorNomeUfLikeQuery(@Param("nomeUf") String nomeUf);
	
	@Query("select regional from Regional regional where regional.uf.sigla like %:siglaUf%")
	List<Regional> buscarPorSiglaUfLikeQuery(@Param("siglaUf") String siglaUf);

	@Query("select regional from Regional regional where regional.uf.sigla IN (:siglasUf)")
	List<Regional> buscarPorListaSiglasUf(@Param("siglasUf") List<String> siglasUf);
	
	@Query("select regional from Regional regional where regional.nome like %:nome%")
	List<Regional> buscarPorNomeLikeQuery(@Param("nome") String nome);

	@Query("select tb from Regional tb where tb.nome like %:nome% and tb.uf.sigla like %:uf% ")
	Page<Regional> filtra(String nome, String uf, Pageable pageable);
}
