package br.coop.somoscooperativismo.localizacao.api.v1.regioes;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RegiaoRepository extends JpaRepository<Regiao, Integer> {
	
	@Query("select r from Regiao r where r.nome like %:nome%")
	public Page<Regiao> buscarPorNomeLikeQuery (@Param("nome") String nome, Pageable pageable);
	
	@Query("select r from Regiao r where r.situacao = :situacao")
	public Page<Regiao> buscarPorSituacao (@Param("situacao") Boolean situacao, Pageable pageable);
	
	@Query("select r from Regiao r where r.pais.id = :idPais")
	public Page<Regiao> buscarPorIdPais (@Param("idPais") Integer idPais, Pageable pageable);
	
	@Query("select r from Regiao r")
	public List<Regiao>buscaRegioesNaoPaginado();
}
