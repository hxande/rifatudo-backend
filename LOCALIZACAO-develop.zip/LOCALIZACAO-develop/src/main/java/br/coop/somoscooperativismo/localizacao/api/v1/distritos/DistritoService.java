package br.coop.somoscooperativismo.localizacao.api.v1.distritos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@Service
public class DistritoService {
	
	@Autowired
	private DistritoRepository distritoRepository;

	@Autowired
	private MessagesService messages;

	public static final String MUNICIPIO_CEP_INVALIDO = "municipio.cepInvalido";

	
	public Distrito buscarPorCep(String cep) {
		Distrito distrito = null;
		
		if (cep == null || cep.length() != 8) {
			throw new RegraNegocioException(messages.get(MUNICIPIO_CEP_INVALIDO), HttpStatus.NOT_FOUND);
		}

		List<Distrito> distritos = distritoRepository.buscarPorCep(cep);

		if (!distritos.isEmpty()) {
			distrito = distritos.get(0);
		}
		return distrito;
	}
	
}
