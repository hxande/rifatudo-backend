package br.coop.somoscooperativismo.localizacao.api.v1.distritos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;

@Entity
@Table(name = "Distrito", schema = "dbo")
public class Distrito {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_DISTRITO")
	private Integer id;
	
	@ManyToOne
	@JoinColumn(name = "SQ_ESTADO")
	@Fetch(FetchMode.JOIN)
	private UF uf;
	
	@ManyToOne
	@JoinColumn(name = "SQ_MUNICIPIO")
	@Fetch(FetchMode.JOIN)
	private Municipio municipio;
	
	@Column(name = "TX_CEP")
	@Size(max = 10, message = "deve ter no máximo 10 caracteres")
	private String cep;

	@Column(name = "TX_NOME_DISTRITO")
	@Size(max = 72, message = "deve ter no máximo 72 caracteres")
	private String nomeDistrito;
	
	
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	
	public UF getUfs() {
		return uf;
	}
	
	public void setUfs(UF ufs) {
		this.uf = ufs;
	}
	
	
	public Municipio getMunicipio() {
		return municipio;
	}
	
	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}
	
	
	public String getCep() {
		return cep;
	}
	
	public void setCep(String cep) {
		this.cep = cep;
	}
	
	
	public String getNomeDistrito() {
		return nomeDistrito;
	}
	
	public void setNomeDistrito(String nomeDistrito) {
		this.nomeDistrito = nomeDistrito;
	}
	
}
