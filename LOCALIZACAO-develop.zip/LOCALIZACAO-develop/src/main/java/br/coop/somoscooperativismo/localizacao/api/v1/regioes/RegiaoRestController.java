package br.coop.somoscooperativismo.localizacao.api.v1.regioes;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;

@RestController
@RequestMapping("/public/api/v1/regioes")
@Tag(name = "Regioes")
public class RegiaoRestController {

	public static final String REGIAO_CRIADA = "regiao.create";
	public static final String NAO_CORRESPONDE = "regiao.naoCorresponde";
	public static final String REGIAO_ATUALIZADA = "regiao.update";
	public static final String REGIAO_EXCLUIDA = "regiao.delete";

	@Autowired
	private RegiaoService regiaoService;
	
	@Autowired
	MessagesService messages;

	@GetMapping
	@Operation(summary = "Lista com as regiões")
	public Page<Regiao> listRegioesPaginado(Pageable pageable) {
		return regiaoService.getAllRegioes(pageable);
	}

	@Operation(summary = "Detalha uma região pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public Regiao buscarRegiaoPorId(@PathVariable Integer id) {
		return regiaoService.buscarPorId(id);
	}
	
	@Operation(summary = "Detalha uma região", description = "Um ID válido deve ser informado")
	@GetMapping("/buscaRegioesNaoPaginado/")
	public List<Regiao> buscaRegioesNaoPaginado() {
		return regiaoService.buscaRegioesNaoPaginado();
	}
	
	
}
