package br.coop.somoscooperativismo.localizacao.api.v1.ufs;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public/api/v1/ufs")
@Tag(name = "Ufs")
public class UfRestController {

	@Autowired
	private UfService ufService;

	@GetMapping
	@Operation(summary = "Lista com as UFs")
	public Page<UF> listUfsPaginado(Pageable pageable) {
		return ufService.getAllUfs(pageable);
	}

	@GetMapping("/nao-paginado")
	@CrossOrigin("*")
	@Operation(summary = "Lista com as UFs")
	public List<UF> listUfsNaoPaginado() {
		return ufService.getAllUfs();
	}

	@Operation(summary = "Detalha uma UF pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public UF buscarUfPorId(@PathVariable Integer id) {
		return ufService.buscarPorId(id);
	}
	
	@Operation(summary = "Detalha UFs pela sigla", description = "Uma sigla existente deve ser informada")
	@GetMapping("/buscaSigla/")
	public UF buscarUfPorSigla(@RequestParam String sigla) {
		return ufService.buscarPorSigla(sigla);
	}
	
	@Operation(summary = "Lista de UFs pela região", description = "Um ID válido deve ser informado")
	@GetMapping("/buscaUFPorRegiao/{id}")
	public List<UF> buscaUFPorRegiao(@PathVariable Integer id){
		return ufService.buscarPorIdRegiaoNaoPaginado(id);
	}
	
	@Operation(summary = "Lista de UFs pela região", description = "")
	@GetMapping("/buscarUfsNaoPaginado/")
	public List<UF> buscaUFPorRegiao(){
		return ufService.buscarUfsNaoPaginado();
	}

    @Operation(summary = "Lista de UFs pela região", description = "")
    @GetMapping("/buscarUfsIbge/{id}")
    public UF buscaUFPorIdIbge(@PathVariable Integer id){
        return ufService.buscarUfIbge(id);
    }

	@GetMapping("buscaUfsPaginado/{uf}/{municipio}")
	@Operation(summary = "Lista com os Estados e Municípios")
	public Page<EstadoMunicipioDTO> listarEstadosPaginado(
			@PathVariable String uf,
			@PathVariable String municipio,
			Pageable pageable) {
		return ufService.getAll(uf, municipio, pageable);
	}

	@Operation(summary = "Detalha UFs pelas siglas", description = "Uma sigla existente deve ser informada")
	@GetMapping("/buscaSiglas/")
	public List<UF> buscarUfsPorSiglas(@RequestParam List<String> siglas) {
		return ufService.buscarPorSiglas(siglas);
	}
}