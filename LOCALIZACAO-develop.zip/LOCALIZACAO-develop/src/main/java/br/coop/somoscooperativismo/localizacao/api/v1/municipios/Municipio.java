package br.coop.somoscooperativismo.localizacao.api.v1.municipios;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;
import br.coop.somoscooperativismo.localizacao.api.v1.regionais.Regional;
import br.coop.somoscooperativismo.localizacao.api.v1.ufs.UF;

@Entity
@Table(name = "Municipio", schema = "dbo")
public class Municipio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_MUNICIPIO")
	private Integer id;
	
	@Column(name = "TX_NOME_MUNICIPIO", nullable = false)
	@Size(max = 255, message = "deve ter no máximo 255 caracteres")
	@NotBlank
	private String nome;
	
	@Column(name = "TX_CEP_MUNICIPIO")
	@Size(max = 8, message = "deve ter no máximo 8 caracteres")
	private String cepMunicipio;
	
	@Column(name = "CD_MUNICIPIO_IBGE")
	private Integer codigoIbgeMunicipio;
	
	@Column(name = "CD_MUNICIPIO_SERPRO")
	private Integer codigoSerproMunicipio;
	
	@Column(name = "NU_LATITUDE", columnDefinition = "numeric(10,4)")
	private Double latitude;
	
	@Column(name = "NU_LONGITUDE", columnDefinition = "numeric(10,4)")
	private Double longitude;
	
	@ManyToOne
	@JoinColumn(name = "SQ_PAIS")
	@Fetch(FetchMode.JOIN)
	private Pais pais;
	
	@ManyToOne
	@JoinColumn(name = "SQ_ESTADO")
	@Fetch(FetchMode.JOIN)
	private UF uf;
	
	@ManyToOne
	@JoinColumn(name = "SQ_REGIAO_UNIDADE_ESTADUAL")
	@Fetch(FetchMode.JOIN)
	private Regional regional;

	@Transient
	private String nomeComUf;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCepMunicipio() {
		return cepMunicipio;
	}

	public void setCepMunicipio(String cepMunicipio) {
		this.cepMunicipio = cepMunicipio;
	}


	public Integer getCodigoIbgeMunicipio() {
		return codigoIbgeMunicipio;
	}

	public void setCodigoIbgeMunicipio(Integer codigoIbgeMunicipio) {
		this.codigoIbgeMunicipio = codigoIbgeMunicipio;
	}


	public Integer getCodigoSerproMunicipio() {
		return codigoSerproMunicipio;
	}

	public void setCodigoSerproMunicipio(Integer codigoSerproMunicipio) {
		this.codigoSerproMunicipio = codigoSerproMunicipio;
	}


	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}


	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}


	public Pais getPais() {
		return pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}


	public UF getUf() {
		return uf;
	}

	public void setUf(UF uf) {
		this.uf = uf;
	}


	public Regional getRegional() {
		return regional;
	}

	public void setRegional(Regional regional) {
		this.regional = regional;
	}
	
	public String getNomeComUf() {
		return this.nome != null ? ("%s - %s".formatted(this.nome, this.uf != null ? this.uf.getSigla() : "")) : null;
	}


	public void setNomeComUf(String nomeComUf) {
		this.nomeComUf = nomeComUf;
	}
	
}
