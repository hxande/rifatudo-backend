package br.coop.somoscooperativismo.localizacao.api.v1.enderecos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import br.coop.somoscooperativismo.localizacao.api.v1.municipios.Municipio;

@Entity
@Table(name = "Endereco", schema = "dbo")
public class Endereco {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_ENDERECO")
	private Integer id;

	@Column(name = "TX_BAIRRO", nullable = false)
	@Size(max = 71, message = "deve ter no máximo 71 caracteres")
	@NotBlank
	private String bairro;

	@Column(name = "SQ_BAIRRO")
	private Integer idBairro;

	@Column(name = "TX_CEP")
	@Size(max = 10, message = "deve ter no máximo 10 caracteres")
	private String cep;

	@Column(name = "TX_LOGRADOURO")
	@Size(max = 72, message = "deve ter no máximo 72 caracteres")
	private String logradouro;

	@Column(name = "TX_COMPLEMENTO")
	@Size(max = 88, message = "deve ter no máximo 88 caracteres")
	private String complemento;

	@ManyToOne
	@JoinColumn(name = "SQ_MUNICIPIO")
	@Fetch(FetchMode.JOIN)
	private Municipio municipio;

	public Integer getId() {
		return id;
	}

	public Integer getIdBairro() {
		return idBairro;
	}

	public String getCep() {
		return cep;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public String getComplemento() {
		return complemento;
	}

	public Municipio getMunicipio() {
		return municipio;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setIdBairro(Integer idBairro) {
		this.idBairro = idBairro;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
}
