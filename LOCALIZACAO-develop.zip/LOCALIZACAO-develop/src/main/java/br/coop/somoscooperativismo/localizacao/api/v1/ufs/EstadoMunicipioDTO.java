package br.coop.somoscooperativismo.localizacao.api.v1.ufs;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EstadoMunicipioDTO {
    private String siglaEstado;
    private String nomeMunicipio;
}
