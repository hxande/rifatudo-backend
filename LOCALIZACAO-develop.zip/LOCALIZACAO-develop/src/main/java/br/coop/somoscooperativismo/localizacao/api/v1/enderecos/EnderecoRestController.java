package br.coop.somoscooperativismo.localizacao.api.v1.enderecos;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public/api/v1/enderecos")
@Tag(name = "Endereços")
public class EnderecoRestController {

	@Autowired
	private EnderecoService enderecoService;

	@Operation(summary = "Detalha Municípios pelo CEP", description = "Um CEP existente e válido deve ser informado")
	@GetMapping("/buscarPorCep/{cep}")
	public Endereco buscarPorCep(@PathVariable String cep) {
		return enderecoService.buscarPorCep(cep);
	}
	
	@Operation(summary = "Detalha Municípios pelo CEP", description = "Um CEP deve ser informado")
	@GetMapping("/validaCEP/{cep}")
	public Endereco validaCep(@PathVariable String cep) {
		return enderecoService.validaCep(cep);
	}

}
