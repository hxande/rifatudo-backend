package br.coop.somoscooperativismo.localizacao.api.v1.regioes;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.type.YesNoConverter;
import com.fasterxml.jackson.annotation.JsonBackReference;

import br.coop.somoscooperativismo.localizacao.api.v1.paises.Pais;

@Entity
@Table(name = "Regiao", schema = "dbo")
public class Regiao {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "SQ_REGIAO_PAIS")
	private Integer id;
	
	@Column(name = "TX_REGIAO_PAIS")
	@Size(max = 20, message = "deve ter no máximo 20 caracteres")
	@NotBlank
	private String nome;
	
	@ManyToOne
	@JoinColumn(name = "SQ_PAIS")
	@Fetch(FetchMode.JOIN)
	@JsonBackReference
	private Pais pais;
	
	@Column(name = "IN_ATIVO", nullable = false, columnDefinition = "varchar(1)")
	@Convert(converter = YesNoConverter.class)
	private Boolean situacao;
	
	
	public Regiao() {
		
	}
	
	public Regiao(Integer id, String nome, Pais pais, Boolean situacao) {
		this.id = id;
		this.nome = nome;
		this.pais = pais;
		this.situacao = situacao;
	}

	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	public Pais getPais() {
		return pais;
	}

	public void setPais(Pais pais) {
		this.pais = pais;
	}
	

	public Boolean getSituacao() {
		return situacao;
	}

	public void setSituacao(Boolean situacao) {
		this.situacao = situacao;
	}
}
