package br.coop.somoscooperativismo.localizacao.api.v1.regionais;

import br.coop.somoscooperativismo.ocbcommonsapi.response.ServiceResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/public/api/v1/regionais")
@Tag(name = "Regionais")
public class RegionalRestController {

	private final RegionalService regionalService;

	public RegionalRestController(RegionalService regionalService) {
		this.regionalService = regionalService;
	}

	@GetMapping
	@Operation(summary = "Lista com as Regionais")
	public Page<Regional> listarRegionais(Pageable pageable) {
		return regionalService.getAll(pageable);
	}
	
	@Operation(summary = "Detalha uma Regional pelo ID", description = "Um ID válido deve ser informado")
	@GetMapping("/{id}")
	public Regional buscarRegionalPorId(@PathVariable Integer id) {
		return regionalService.buscarPorId(id);
	}

	@Operation(summary = "Detalha Regionais pelo nome", description = "Um nome existente deve ser informado")
	@GetMapping("/buscaPorNome")
	public ServiceResponse<List<Regional>> buscarRegionalPorNome(@RequestParam String nome) {
		return new ServiceResponse<>(regionalService.buscarPorNome(nome));
	}

	@Operation(summary = "Detalha Regionais pelo ID da UF", description = "Um ID válido deve ser informado")
	@GetMapping("/buscaPorIdUf")
	public List<Regional> buscarRegionaisPorIdUf(@RequestParam Integer idUf) {
		return regionalService.buscarPorIdUf(idUf);
	}

	@Operation(summary = "Detalha Regionais pela sigla da UF", description = "Uma sigla válida deve ser informada")
	@GetMapping("/buscarPorSiglaUf")
	public List<Regional> buscarPorSiglaUf(@RequestParam String siglaUf) {
		return regionalService.buscarPorSiglaUf(siglaUf);
	}

	@Operation(summary = "Detalha Regionais pela sigla da UF", description = "Uma lista siglas válidas separadas por vírgula")
	@GetMapping("/buscarPorListaSiglasUf")
	public List<Regional> buscarPorSiglaUf(@RequestParam List<String> siglasUf) {
		return regionalService.buscarPorListaSiglasUf(siglasUf);
	}

	@GetMapping("/filtro")
	@Operation(summary = "Lista as com filtro")
	public ServiceResponse<Page<Regional>> listaFiltradoPaginado(
			@RequestParam(required = false) String nome,
			@RequestParam(required = false) String uf, Pageable pageable) {
		return new ServiceResponse<>(regionalService.filtra(nome != null ? nome : "", uf != null ? uf : "", pageable));
	}

	@Operation(summary = "Lista com todas as Regionais")
	@GetMapping("/buscaRegionaisNaoPaginado")
	public List<Regional> buscaRegionais() {
		return regionalService.buscaRegionais();
	}
}
