package br.coop.somoscooperativismo.localizacao.api.v1.paises;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface PaisRepository extends JpaRepository<Pais, Integer> {
	
	@Query("select p from Pais p where p.nome like %:nome%")
	public Page<Pais> buscarPorNomeLikeQuery (@Param("nome") String nome, Pageable pageable);
	
	@Query("select p from Pais p where p.situacao = :situacao")
	public Page<Pais> buscarPorSituacao (@Param("situacao") Boolean situacao, Pageable pageable);
	
	@Query("select p from Pais p where p.brasil = :brasil")
	public Page<Pais> buscarPorParametroBrasil (@Param("brasil") Boolean brasil, Pageable pageable);
}
