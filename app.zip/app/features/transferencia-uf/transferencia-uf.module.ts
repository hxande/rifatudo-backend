
import { ListagemSolicitacaoTransferenciaComponent } from './listagem-solicitacao-transferencia/listagem-solicitacao-transferencia.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TransferenciaUfRoutingModule } from './transferencia-uf-routing.module';
import { SharedModule } from '@shared/shared.module';
import { MantemSolicitacaoTransferenciaComponent } from './mantem-solicitacao-transferencia/mantem-solicitacao-transferencia.component';


@NgModule({
    declarations: [
      ListagemSolicitacaoTransferenciaComponent,
      MantemSolicitacaoTransferenciaComponent
    ],
    imports: [
        CommonModule,
        SharedModule,
        TransferenciaUfRoutingModule,
      
    ]
  })
  export class TransferenciaUfModule { }