import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CooperativasRegistradasComponent} from './cooperativas-registradas/cooperativas-registradas.component';
import {AuthGuardService} from '@auth/auth-guard/auth-guard.service';
import { RelatoriosGerenciaisComponent } from './relatorios-gerenciais/relatorios-gerenciais.component';

const routes: Routes = [
   {
       path: 'cooperativas-registradas',
       component: CooperativasRegistradasComponent,
       canActivate: [AuthGuardService],
   },
   {
    path: 'relatorios-gerenciais',
    component: RelatoriosGerenciaisComponent,
    canActivate: [AuthGuardService],
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RelatorioRoutingModule { }
