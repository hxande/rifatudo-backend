import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { CooperativasRegistradasComponent } from './cooperativas-registradas.component';

describe('CooperativasRegistradasComponent', () => {
  let component: CooperativasRegistradasComponent;
  let fixture: ComponentFixture<CooperativasRegistradasComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CooperativasRegistradasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CooperativasRegistradasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
