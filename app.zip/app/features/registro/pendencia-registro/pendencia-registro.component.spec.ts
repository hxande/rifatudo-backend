import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendenciaRegistroComponent } from './pendencia-registro.component';

describe('PendenciaRegistroComponent', () => {
  let component: PendenciaRegistroComponent;
  let fixture: ComponentFixture<PendenciaRegistroComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ PendenciaRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendenciaRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
