import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoCooperativa {
  constructor(
    private keycloakService: KeycloakService,
  ){}

    podeVerBotoesSituacaoCooperativa() {
      if(
        (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_RESP_SITUACAO) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
        )){
          return true;
        }

        return false;
    }

    podeVerBotaoCertificadoRegistro(){
      if(
        (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
        )){
          return true;
        }
        return false;
    }


    podeVerBotaoCertificadoRegularidade(){
      if(
        (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
        )){
          return true;
        }
        return false;
    }

    podeVerBotaoExportarHistorico() {
      if(
      (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
      )){
        return true;
      }
      return false;
    }

    podeVerBotoesExportarDadosTabela() {
      return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_VIS) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_VIS)
      );

    }

    podeVerBotaoNovaCooperativa() {
      if(
      (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
      )){
        return true;
      }
      return false;
    }

    podeVerBotaoAnalisarDados() {
      if(
      (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS)  ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
      )){
        return true;
      }



      return false;
    }

    podeVerAbaArquivadosBotaoExportarTabela() {
      if(
      (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
      )){
        return true;
      }
      return false;
    }

    podeVerCardInicioRelatorio() {
      if(
        (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
        )){
          return true;
        }
        return false;

    }



}
