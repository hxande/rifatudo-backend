import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem, MessageService } from 'primeng/api';
import { AppComponent } from 'src/app/app.component';
import { Accordion } from 'primeng/accordion';
import { Button } from 'primeng/button';
import { FileUploadComponent } from '@gui/file-upload/file-upload/file-upload.component';
import { VisitaTecnica } from '@cadastro-registro-api/models/VisitaTecnica';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { Parecer } from '@cadastro-registro-api/models/Parecer';
import { ApiVisitaTecnicaService } from '@cadastro-registro-api/services/api-visita-tecnica.service';
import { PessoaJuridica } from '@cadastro-registro-api/models/PessoaJuridica';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { ProgressoMacroEnum } from '@cadastro-registro-api/models/ProgressoMacroEnum';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-processo-registro-cooperativa-component',
  templateUrl: './processo-registro-cooperativa-component.html',
  styles:['.p-steps .p-steps-item.p-highlight .p-steps-number{ background-color: red !important}','.escolha-data{padding-top: 100px;}',
  '.content-btn-enviar-datas{ width: 250px; margin-top: 20px}']
})
export class ProcessoRegistroCooperativaComponent implements OnInit, OnDestroy {
  items: MenuItem[];

  indexsteps = 1;
  indexaccordion = 0;
  @ViewChild('accordionTabs') accordionTabs: Accordion;
  classTab0 = 'display-none';
  classTab1 = 'display-none';
  classTab2 = 'display-none';
  classTab3 = 'display-none';
  classTab4 = 'display-none';
  classTab4_1 = 'display-none';
  classTab5 = 'display-none';
  classMicro_4_2 = 'display-none';
  classMicro_5_2 = 'display-none';
  classMicro_5_3 = 'display-none';
  msgCard2_1 = 'display-none';
  msgCard2_2 = 'display-none';
  msgCard2_3 = 'display-none';
  msgCard3_1 = 'display-none';
  msgCard3_2 = 'display-none';
  msgCard4_1 = 'display-none';
  msgCard4_2 = 'display-none';
  msgCard2_Arquivado = 'display-none';
  msgCard3_Arquivado = 'display-none';
  msgCard5_Arquivado = 'display-none';
  divuploadConformidadeLegal = 'display-none';

  @ViewChild('fileup') fileup: FileUploadComponent;
  @ViewChild('btnAnalisarCadastro') btnAnalisarCadastro: Button;
  modalJustificativaDeliberacaoVisivel = false;
  @ViewChild('fileupRecursoDeliberacao') fileupRecursoDeliberacao: FileUploadComponent;
  visitaTecnica: VisitaTecnica;
  vtDataEnviada = false;
  mostraMensagemCoop = false;
  mostraMensagemUE = false;
  objCooperativa: Cooperativa = new Cooperativa();
  parecer: Parecer = new Parecer();
  envioReconsideracao = false;
  isRequired = false;
  observacaoHistorico = '';
  txtMensagemDataEnviadaCooperativa = null;
  constructor(
    private messageService: MessageService,
    public app: AppComponent,
    private apiVisitaTecnicaService: ApiVisitaTecnicaService,
    public breadCrumbPrimeNGService: BreadcrumbService,
    private router: Router
  ) {
    this.objCooperativa = new Cooperativa();
    this.objCooperativa.pessoaJuridica = new PessoaJuridica();
  }

  ngOnInit(): void {
    this.visitaTecnica = new VisitaTecnica();

    this.items = [
      {
        label: 'Cadastro e envio dos documentos',
        id:'1'
      },
      {
        label: 'Validação dos dados e documentos',
        id:'2'
      },
      {
        label: 'Análise de conformidade legal',
        id:'3'
      },
      {
        label: 'Visita técnica',
        id:'4'
      },
      {
        label: 'Deliberação',
        id:'5'
      },
      {
        label: 'Emissão do certificado de registro',
        id:'6'
      },
    ];
  }

  ngOnDestroy(): void {}

  setRequired(option: boolean) {
    this.isRequired = option;
  }

  setCooperativa(obj: Cooperativa) {
    this.objCooperativa = obj;
    this.parecer = this.objCooperativa.parecer ? this.objCooperativa.parecer : new Parecer();
    this.parecer.cooperativa = new Cooperativa();
    this.parecer.cooperativa.pessoaJuridica = this.objCooperativa.pessoaJuridica;
    this.parecer.cooperativa.id = this.objCooperativa.id;

    if (!this.objCooperativa.arquivado) {
      if (this.objCooperativa.situacaoCooperativa.id !== SituacaoEnum.NAOREGISTRADA && this.objCooperativa.numeroRegistroOCB) {
        this.router.navigate(['/inicio']);
      }

      switch (obj.progressoMacro) {
        case ProgressoMacroEnum.CADASTRO_INICIADO_1:
          this.classTab0 = 'display-block';
          this.accordionTabs.tabs[0].disabled = false;
          this.indexaccordion = 0;
          this.indexsteps = 0;
          break;
        case ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2: {
          this.classTab1 = 'display-block';
          this.accordionTabs.tabs[1].disabled = false;
          this.indexaccordion = 1;
          this.indexsteps = 1;
          this.btnAnalisarCadastro.disabled = false;
          this.btnAnalisarCadastro.label = 'Realizar cadastro';
          if (obj.arquivado === true) {
            this.btnAnalisarCadastro.disabled = true;
            this.msgCard2_Arquivado = 'display-block';
            this.msgCard2_1 = 'display-none';
            this.msgCard2_2 = 'display-none';
            this.msgCard2_3 = 'display-none';
            break;
          }
          if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1) {
            this.btnAnalisarCadastro.disabled = false;
            this.btnAnalisarCadastro.label = 'Visualizar cadastro';
            this.msgCard2_2 = 'display-block';
            break;
          }
          if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2) {
            this.btnAnalisarCadastro.disabled = false;
            this.btnAnalisarCadastro.label = 'Realizar ajustes';
            this.msgCard2_3 = 'display-block';
            break;
          }
          this.msgCard2_1 = 'display-block';
          break;
        }
        case ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3: {
          this.classTab2 = 'display-block';
          this.indexaccordion = 2;
          this.indexsteps = 2;
          this.accordionTabs.tabs[2].disabled = false;
          if (obj.arquivado === true) {
            this.msgCard3_Arquivado = 'display-block';
            break;
          }
          if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1) {
            this.msgCard3_1 = 'display-block';
          }
          if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2) {
            this.msgCard3_2 = 'display-block';
          }
          break;
        }
        case ProgressoMacroEnum.VISITA_TECNICA_4: {
          this.obtemVisitaTecnica();
          this.classTab3 = 'display-block';
          this.accordionTabs.tabs[3].disabled = false;
          this.indexaccordion = 3;
          this.indexsteps = 3;
          if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_PROPOSTA_DATA_4_1) {
            this.msgCard4_1 = 'display-block';
          }
          if ((obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_ACEITE_DATA_VISITA_4_2 && !this.vtDataEnviada) || this.visitaTecnica.reconsideraSugestao) {
            this.classMicro_4_2 = 'display-block';
          }
          break;
        }
        case ProgressoMacroEnum.PARECER_5:
        case ProgressoMacroEnum.EMISSAO_CERTIFICADO_6: {
          this.indexsteps = 4;
          this.indexaccordion = 4;
          this.classTab4 = 'display-block';
          this.accordionTabs.tabs[4].disabled = false;
          this.fileupRecursoDeliberacao.setDesabilita();
          if (obj.arquivado === true) {
            this.msgCard5_Arquivado = 'display-block';
            break;
          }
          if (obj.progressoMicro === ProgressoMicroEnum.REGISTROS_INDEFERIDOS_OCE_5_2) {
            this.classMicro_5_2 = 'display-block';
          }
          if (obj.progressoMicro === ProgressoMicroEnum.AGUARDANDO_LIBERACAO_5_3) {
            this.accordionTabs.tabs[4].disabled = true;
            this.accordionTabs.tabs[5].disabled = false;
            this.indexaccordion = 5;
            this.classMicro_5_3 = 'display-block';
            this.classTab4 = 'display-none';
            this.classTab4_1 = 'display-block';
          }
          break;
        }

        default: {
          if (obj.progressoMacroTexto === '0 - Pré Cadastro') {
            this.classTab0 = 'display-block';
            this.accordionTabs.tabs[0].disabled = false;
            this.indexaccordion = 0;
            this.indexsteps = 0;
            break;
          } else {
            this.indexsteps = 6;
          }
        }
      }
      this.items.map(i => Number(i.id) < this.indexsteps + 1 ? i.styleClass = "check" : '')
      this.items.map(i => Number(i.id) > this.indexsteps + 1 ? i.styleClass = "no-check display-flex" : '')
    }
  }

  VisualizarJustificativaDeliberacao() {
    this.modalJustificativaDeliberacaoVisivel = true;
  }

  obtemVisitaTecnica() {
    this.apiVisitaTecnicaService.get(this.objCooperativa.id).then((res) => {
      this.visitaTecnica = res.data;
      const dt1 = new Date(this.visitaTecnica.dataSugerida1);
      dt1.setMinutes(1);
      const dt2 = new Date(this.visitaTecnica.dataSugerida2);
      dt2.setMinutes(2);
      const dt3 = new Date(this.visitaTecnica.dataSugerida3);
      dt1.setMinutes(3);
      this.visitaTecnica.dataSugerida1 = dt1;
      this.visitaTecnica.dataSugerida2 = dt2;
      this.visitaTecnica.dataSugerida3 = dt3;
      this.verificaDataEnviada();
    });
  }

  private verificaDataEnviada() {
    if (this.visitaTecnica !== null) {
      this.vtDataEnviada = !this.visitaTecnica.reconsideraSugestao ? true : false;
      if (this.vtDataEnviada) {
        this.classMicro_4_2 = 'display-none';
        this.msgCard4_1 = 'display-none';
        if (!this.visitaTecnica.dataAceitaCooperativa) {
          this.vtDataEnviada = false;
          this.msgCard4_1 = 'display-block';
        }
      }

      if (!this.visitaTecnica.dataAceitaCooperativa && this.visitaTecnica.dataSugerida1 != null && !this.visitaTecnica.observacoes) {
        this.classMicro_4_2 = 'display-block';
        this.msgCard4_1 = 'display-none';
      }
      if (this.envioReconsideracao) {
        this.envioReconsideracao = false;
        this.classMicro_4_2 = 'display-none';
        this.msgCard4_1 = 'display-block';
      }
      this.observacaoHistorico = this.visitaTecnica.observacoes;
      this.visitaTecnica.observacoes = '';
    } else {
      this.vtDataEnviada = false;
    }
  }

  verMensageCoopVT() {
    this.mostraMensagemCoop = true;
  }
  verMensagemUE() {
    this.mostraMensagemUE = true;
  }

  enviaDatasVisitaTecnica() {
    if (!this.envioDataVazia()) {
      this.envioReconsideracao = this.visitaTecnica.dataAceitaCooperativa === null && this.visitaTecnica.reconsideraSugestao ? true : false;
      if (this.envioReconsideracao) {
        this.visitaTecnica.reconsideraSugestao = false;
      }

      this.apiVisitaTecnicaService.enviaDatas(this.visitaTecnica).then((res) => {
        this.visitaTecnica = res.data;
        this.verificaDataEnviada();
      });
    }
  }

  envioDataVazia() {
    if (this.visitaTecnica.dataAceitaCooperativa === null && this.isRequired === false) {
      this.messageService.add({ severity: 'error', detail: 'Você precisa selecionar alguma data para a vistoria técnica!', life: 10000 });
      return true;
    }
    return false;
  }

  exibiMensagensObservacoes() {
    this.txtMensagemDataEnviadaCooperativa = new Date();
    if (this.visitaTecnica.observacoesPrevisita !== null && this.visitaTecnica.observacoesPrevisita.length > 0) {
      return true;
    }
    return false;
  }
}
