import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, inject, Input, OnInit, Output, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { NgForm, UntypedFormGroup } from '@angular/forms';
import { AjusteDadosComponent } from '@shared/validacaoDados/ajuste-dados-component';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { DateService } from '@shared/util/service/date.service';
import { Mandato } from '@cadastro-registro-api/models/Mandato';
import { Governanca } from '@cadastro-registro-api/models/Governanca';
import { Cargo } from '@cadastro-registro-api/models/Cargo';
import { OrgaoRamo } from '@cadastro-registro-api/models/OrgaoRamo';
import { OrgaoCargo } from '@cadastro-registro-api/models/OrgaoCargo';
import { ConfirmationService, MessageService, SelectItem } from 'primeng/api';
import { MandatoMembro } from '@cadastro-registro-api/models/MandatoMembro';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { ValidacaoPrimeiroRegistro } from '@cadastro-registro-api/models/ValidacaoPrimeiroRegistro';
import { ProgressoMicroEnum } from '@cadastro-registro-api/models/ProgressoMicroEnum';

interface EscolaridadeTO {
  id: number;
  ativo: boolean;
  descricaoEscolaridade: string;
}
import { HistoricoGovernancaComponent } from '../manutencao/governanca/historico-governanca/historico-governanca.component';
import { TrilhaAcoesGovernancaComponent } from './trilha-acoes/trilha-acoes-governanca.component';
import { Dialog } from 'primeng/dialog';
import { QuadroSocial } from '@cadastro-registro-api/models/QuadroSocial';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiManutencaoCadastroRegistroService } from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { ApiManutencaoGovernancaService } from '../manutencao/governanca/service/api-manutencao-governanca.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { ApiOrgaoCargoService } from '@cadastro-registro-api/services/api-orgao-cargo.service';
import { ApiOrgaoRamoService } from '@cadastro-registro-api/services/api-orgao-ramo.service';
import { ApiPessoaFisicaService } from '@cadastro-registro-api/services/api-pessoa-fisica.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { UtilityService } from '@utils/utility/utility.service';
import { GeralService } from '@auth/geral.service';
import { ValidacaoGovernancaManutencao } from '@shared/governanca/validacao/validacao-governanca-manutencao.service';
import { ApiPessoaJuridicaService } from '@cadastro-registro-api/services/api-pessoa-juridica.service';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';
import { ApiDadosGeraisService } from '@utils/api-dados-gerais.service';
import { Genero } from '@gerencia-usuario-api/models/Genero';
import { IServiceMessage } from '@utils/interfaces/IServiceMessage';
import { Orgao } from '@cadastro-registro-api/models/Orgao';
import { PessoaFisica } from '@cadastro-registro-api/models/PessoaFisica';
import { ApiGovernancaService } from './service/api-governanca.service';
import { ApiControleAbasRegistroService } from '@cadastro-registro-api/services/api-controle-abas-registro.service';
import { ControleAbasRegistroEnum } from '@cadastro-registro-api/models/ControleAbasRegistroEnum';
import { CooperativaManutencao } from '@shared/cooperativa-manutencao/cooperativa-manutencao';
import { PermissaoCooperativa } from '../../cooperativa/permissao/permissao.service';
import { StringUtil } from '@shared/utils/StringUtil';
import { MandatoTO } from 'src/app/api/models/MandatoTO';
import { PendenciasGovernancaTO } from 'src/app/api/models/PendenciasGovernancaTO';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { Aprovacao } from '@cadastro-registro-api/models/Aprovacao';
import { DatePipe } from '@angular/common';
import { GovernancaRulesService, SituacaoCooperativa } from '@shared/governanca/validacao/governanca-rules.service';

@Component({
  selector: 'app-governanca-shared',
  templateUrl: './governanca-shared.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./governanca-shared.component.css'],
})
export class GovernancaSharedComponent implements OnInit {
  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() cooperativaManutencao: CooperativaManutencao;
  @Input() exibirErros = true;
  @Input() isManutencao = false;
  @Output() evtSalvarDados = new EventEmitter<boolean>();
  @Output() evtFimSalvarDados = new EventEmitter<number>();
  @Output() evtErroSalvar = new EventEmitter<boolean>();
  @Output() evtEstadoPreenchimento = new EventEmitter<'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null>();
  @Output() evtAbaSincronizada = new EventEmitter<void>();
  @ViewChild('governancaForm') governancaForm: NgForm;
  @ViewChild('ajusteDados') ajusteDadosForm: AjusteDadosComponent;
  @ViewChildren(AjusteDadosComponent) ajusteDadosComponentes: QueryList<AjusteDadosComponent>;
  @ViewChild('manutencaoGovernancaForm') manutencaoGovernancaForm: NgForm;
  @ViewChild('historicoGovernanca') historicoGovernanca: HistoricoGovernancaComponent;
  @ViewChild('dialog') dialog: Dialog;
  @ViewChild('trilhaAcoes') trilhaAcoes: TrilhaAcoesGovernancaComponent;

  mensagensValidacao = Array<{ summary: string; detail: string }>();
  cols: { field: string; header: string }[];
  cooperativa: Cooperativa = null;
  nomePessoaJuridica: string;
  dateService = new DateService();
  datePipe = new DatePipe('pt-BR');
  governancaArray: Governanca[] = [];
  optionsCargo: Cargo[][] = [];
  orgaoRamos: OrgaoRamo[];
  orgaoCargos: OrgaoCargo[];
  optionsEscolaridade: EscolaridadeTO[] = [];
  listGenero: SelectItem[];
  orgaoOpcional: boolean[] = [];
  membrosGovExcluidos: MandatoMembro[];
  public form: UntypedFormGroup;
  podeModificarOsCampos = false;
  pendenciasEditadas: CooperativaPendencia[] = [];
  aprovacoes: CooperativaPendencia[] = [];
  houveAlteracaoForm = false;
  salvando = false;
  mapPendencias: Record<string, boolean> = {};
  dataAtual = new Date();
  cooperativaTemp: Cooperativa;
  nomeOrgao: string;
  membrosAprovados: number[] = [];
  modalVisivel: boolean;
  podeAdicionarNovoMandato: boolean[] = [];
  mapTemVigente = new Map<number, boolean>();
  quadroSocial: QuadroSocial;
  listaMandatosMembrosInativos: Mandato[] = [];
  modalValidarEncerrarMandatoVisivel: boolean;
  alertaMandatoExpiradoExibido = false;
  aprovacao: Aprovacao = null;
  statusGovernancaGlobal: { alertClass: string; icon: string; message: string } = null;
  labelModalEncerrarMandato: string;
  /** Pendências agregadas por conselho + flag pode-avançar. */
  pendenciasGovernanca: PendenciasGovernancaTO | null = null;
  /** Trava por órgão enquanto o salvar-por-conselho está em curso. */
  salvandoConselhoOrgaoId: number | null = null;
  /**
   * Dirty-flag POR conselho: salvar um conselho não pode desarmar o guard
   * "Salve os conselhos alterados" dos demais.
   */
  orgaosAlterados = new Set<number>();

  // ---- Desmarque da Diretoria Contratada (RN-DC-02, feature 003) ----
  /** Conselho DC aguardando a data de fim do contrato no modal. */
  dcDesmarqueGovernanca: Governanca | null = null;
  dcDesmarqueVisivel = false;
  dcDataFimContrato: Date | null = null;
  /** Piso do calendário: maior início de contrato entre os membros ativos. */
  dcDataFimMinima: Date | null = null;
  private dcDesmarqueConfirmado = false;
  /** Data de fim capturada por órgão — enviada como dataFimContrato no TO. */
  private dataFimContratoPorOrgao: { [orgaoId: number]: Date } = {};

  // ---- Redesign (accordion por conselho, decisão de produto 2026-07-06) ----
  /** Cartões expandidos por órgão (accordion). */
  expandidoPorOrgao: { [orgaoId: number]: boolean } = {};
  /** Órgão em edição — apenas UM conselho por vez. */
  editandoOrgaoId: number | null = null;
  /** Rascunho do conselho em edição; "Cancelar" descarta sem tocar o modelo. */
  draftGovernanca: Governanca | null = null;
  /** Inclusão rápida ("Incluir e salvar") em andamento por órgão. */
  inclusaoRapidaOrgaoId: number | null = null;
  membroInclusaoRapida: MandatoMembro | null = null;
  salvandoInclusaoRapida = false;
  /** Houve exclusão imediata (API) durante a edição — cancelar exige resync. */
  private houveExclusaoNaEdicao = false;
  /** Busca por nome/CPF/cargo por conselho (filtro de exibição, não muta a lista). */
  buscaPorOrgao: { [orgaoId: number]: string } = {};

  private rotuloSubstituto = new Map<MandatoMembro, string>();

  private idsInativosAoEditar = new Set<number>();

  private substitutoRecemInserido: MandatoMembro | null = null;

  /** Paleta de destaque dos cartões (protótipo: navy/verde; DC azul) — cores nas classes gov-accent-N do CSS. */
  private static readonly TOTAL_ACCENTS = 4;

  constructor(
    public language: LanguageService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiManutencaoCadastrosRegistro: ApiManutencaoCadastroRegistroService,
    private apiManutencaoGovernanca: ApiManutencaoGovernancaService,
    private apiValidacaoService: ApiValidacaoDadosService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private orgaoCargoApi: ApiOrgaoCargoService,
    private governancaApi: ApiGovernancaService,
    private orgaoRamoApi: ApiOrgaoRamoService,
    private pessoaApi: ApiPessoaFisicaService,
    public keycloakService: KeycloakService,
    private utility: UtilityService,
    private geralService: GeralService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    public validacaoGovernancaManutencao: ValidacaoGovernancaManutencao,
    private apiPj: ApiPessoaJuridicaService,
    public validacaoDados: ValidacaoDados,
    private dadosGerais: ApiDadosGeraisService,
    private apiControleAbas: ApiControleAbasRegistroService,
    private permissaoCooperativa: PermissaoCooperativa,
    private apiCooperativaService: ApiCooperativaService,
    private rules: GovernancaRulesService
  ) {}

  ngOnInit(): void {
    this.carregaTela();
    if (this.ajusteDadosForm) {
      this.ajusteDadosForm.carregarAprovacao();
    }

    this.cols = [
      { field: 'cpf', header: 'CPF' },
      { field: 'nome', header: 'Nome completo' },
      { field: 'genero', header: 'Sexo' },
      { field: 'cargo', header: 'Cargo' },
      { field: 'responsavelLegal', header: 'Representante legal' },
    ];
  }

  carregarMenssagens(mensagens: IServiceResponse<ValidacaoPrimeiroRegistro>) {
    this.mensagensValidacao = [];
    if (mensagens && mensagens.data) {
      const dadosValidacao = mensagens.data;
      if (!dadosValidacao.validado) {
        this.mensagensValidacao = dadosValidacao.mensagens.map((msg: IServiceMessage) => ({
          summary: msg.message.indexOf('<b>') === -1 ? '' : msg.message.substring(msg.message.indexOf('<b>') + 3, msg.message.indexOf('</b>')),
          detail: msg.message.indexOf('<b>') === -1 ? msg.message : msg.message.substring(msg.message.indexOf('</b>') + 4),
        }));
      }
    }
  }

  atualizarMensagensTela() {
    if (this.cooperativa) {
      if (this.isManutencao) {
        this.apiManutencaoCadastrosRegistro.getValidacaoGovernanca(this.cooperativa.id).subscribe((res) => {
          this.carregarMenssagens(res);
          this.changeDetectorRef.markForCheck();
          this.evtAbaSincronizada.emit();
        });
      } else {
        this.apiCadastroRegistroService.validarGovernanca(this.cooperativa.id).then((res) => {
          this.carregarMenssagens(res);
          this.changeDetectorRef.markForCheck();
          this.evtAbaSincronizada.emit();
        });
      }
    }
  }

  get abaComAjusteSolicitado(): boolean {
    return !!this.cooperativaManutencao?.abasComAjusteSolicitado?.includes('ABA_GOVERNANCA');
  }

  verificarLiberacaoCampos(id?: number) {
    if (this.isManutencao) {
      this.apiManutencaoCadastrosRegistro.podePreencherCadastroRegistro(id).then((res) => {
        if (res != null && res.data != null) {
          this.podeModificarOsCampos = res.data && this.permissaoCooperativa.permissaoAtualizarCadastro();
          if (!this.isManutencao) {
            this.desativaEventoForm();
          }
          this.changeDetectorRef.markForCheck();
        }
      });
    } else {
      this.apiCadastroRegistroService.podePreencherCadastroRegistroBasico(this.cooperativa.id).then((res) => {
        if (res != null && res.data != null) {
          this.podeModificarOsCampos = res.data;
          this.desativaEventoForm();
          this.changeDetectorRef.markForCheck();
        }
      });
    }
  }

  public carregaTela() {
    this.rotuloSubstituto.clear();
    this.editandoOrgaoId = null;
    this.draftGovernanca = null;
    this.houveExclusaoNaEdicao = false;
    this.inclusaoRapidaOrgaoId = null;
    this.membroInclusaoRapida = null;

    this.membrosGovExcluidos = [];
    this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then(async (coop) => {
      if (coop) {
        this.cooperativaTemp = coop;
        if (coop.id) {
          this.apiPj.buscaUnidadeResponsavel(coop.pessoaJuridica.ufSigla).then((pj) => {
            this.nomePessoaJuridica = pj.data.nomeFantasia;
            this.changeDetectorRef.markForCheck();
          });
          await Promise.all([
            this.dadosGerais.buscarQuadroSocialAtual(this.cooperativaTemp.id).then((resQuadroSocial) => {
              if (resQuadroSocial.data) {
                this.quadroSocial = resQuadroSocial.data;
              }
            }),
            this.orgaoRamoApi.getPorRamo(coop.pessoaJuridica.ramo.id).then((response) => {
              this.orgaoRamos = response.data;
            }),
            this.carregarEscolaridade(),
          ]);
          this.changeDetectorRef.markForCheck();
          this.cooperativa = coop;
          this.atualizarMensagensTela();

          const servAprovacao = await this.apiCooperativaService.buscarUltimaAprovacao(coop.id);
          if (servAprovacao && servAprovacao.data) {
            this.aprovacao = servAprovacao.data;
            this.changeDetectorRef.markForCheck();
            if (this.aprovacao && this.aprovacao.dataAtualizacao) {
              this.aprovacao.dataAtualizacao = this.aprovacao.dataAtualizacao;
            }
          }

          if (coop.pessoaJuridica.ramo) {
            this.apiManutencaoGovernanca.buscaGovernancasVigentesPorCooperativa(coop.id).then((res) => {
              this.governancaArray = res.data;
              this.governancaArray.forEach((governanca, index) => {
                this.mapTemVigente.set(governanca.mandato.orgao.id, governanca.mandato.id !== null);
                // Data de Assembleia
                if (governanca.mandato.dataAssembleia) {
                  governanca.mandato.dataAssembleia = this.dateService.getDate(governanca.mandato.dataAssembleia);
                }

                // Data de inicio e fim de mandato
                let contagemAprovados = 0;
                for (const membro of governanca.mandato.listaMandatoMembro) {
                  if (membro.fimMandato) {
                    membro.fimMandato = this.dateService.getDate(membro.fimMandato);
                  }
                  if (membro.aprovacao) {
                    contagemAprovados++;
                  }
                  membro.inicioMandato = this.dateService.getDate(membro.inicioMandato);
                  membro.pessoaFisica.dataNascimento = this.dateService.getDate(membro.pessoaFisica.dataNascimento);
                  membro.pessoaFisica.escolaridadeTemp = this.optionsEscolaridade.find(
                    (escolaridade) => escolaridade.id === membro.pessoaFisica.idEscolaridade
                  );
                }
                this.membrosAprovados[index] = contagemAprovados;
                this.podeAdicionarNovoMandato[index] = governanca.mandato.vigente;

                // Separa lista de membros ativos e inativos
                governanca.mandato.listaMandatoMembro = this.getMembrosAtivos(governanca.mandato);

                if (governanca.mandato.orgao.obrigatorio === false) {
                  this.orgaoOpcional[governanca.mandato.orgao.id] = !governanca.mandato.orgao.obrigatorio && governanca.mandato.coopPossui;
                  if (governanca.mandato.orgao.vinculo === 'ESTATUTÁRIO ELETIVO') {
                    if (governanca.mandato.listaMandatoMembro[0] && governanca.mandato.listaMandatoMembro[0].id) {
                      this.orgaoOpcional[governanca.mandato.orgao.id] = true;
                    } else {
                      governanca.mandato.vigente = false;
                    }
                  }
                }

                if (governanca.mandato.orgao.vinculo === 'CONTRATAÇÃO' && (governanca.mandato.listaMandatoMembro ?? []).some((membro) => !!membro.id)) {
                  this.orgaoOpcional[governanca.mandato.orgao.id] = true;
                }

                this.minimoMembros(governanca.mandato);
              });

              this.inicializarExpansaoConselhos();

              this.processarStatusGlobal();

              this.atualizaPendenciaChaveManutencao(coop);
              this.carregaOrgaoCargo();
              this.carregarPendencias();
              if (!this.alertaMandatoExpiradoExibido) {
                this.alertaMandatoExpiradoExibido = this.validarEncerrarMandatoConselhoAdministracaoEFiscal(null);
              }
              this.changeDetectorRef.markForCheck();
            });
          }
          if (this.isManutencao) {
            this.atualizaPendenciaChave(coop);
          }
        }

        if (!this.governancaArray || this.governancaArray.length === 0) {
          this.processarStatusGlobal();
        }
        if (!this.governancaArray && this.isManutencao) {
          this.atualizarMensagensTela();
        }

        this.listGenero = [];
        const key = Object.keys(Genero);
        const value = Object.values(Genero);
        for (let i = 0; i < key.length; i++) {
          const x = key[i];
          const y = value[i];
          this.listGenero = [...this.listGenero, { label: y, value: x }];
        }
        this.verificarLiberacaoCampos(coop.id);
        this.changeDetectorRef.markForCheck();
      }
    });
  }

  private atualizaPendenciaChave(coop: Cooperativa) {
    this.apiValidacaoDadosService.obterUltimasPendenciasChave(coop.id).then((res) => {
      this.mapPendencias = res.data as unknown as Record<string, boolean>;
      this.changeDetectorRef.markForCheck();
    });
  }

  /**
   * Edição no formulário: não atualiza o hint (hint só após carregaTela / Salvar e
   * continuar). Quando a edição vem de um conselho específico, registra o órgão no
   * dirty-flag por conselho (P1 nº 7).
   */
  houveMudancaForm(g?: Governanca) {
    this.houveAlteracaoForm = true;
    const orgaoId = g?.mandato?.orgao?.id;
    if (orgaoId != null) {
      this.orgaosAlterados.add(orgaoId);
    }
  }

  houveMudancaFormOrgaoOpcional(g: Governanca) {
    if (g && g.mandato) {
      g.mandato.dataAtualizacao = new Date();
    }
    this.houveMudancaForm(g);
  }

  processarStatusGlobal() {
    if (!this.aprovacao || !this.aprovacao?.dataAtualizacao) {
      // "Aguardando ajustes" e "Aguardando análise" são estados distintos do CICLO
      // da atualização cadastral e não da aprovação do mandato — tratá-los com a
      // mesma frase fazia a aba acusar "aguardando aprovação" com os conselhos já
      // aprovados, enquanto o que segurava o ciclo era outra aba.
      if (this.cooperativa?.status === 'Aguardando análise') {
        this.statusGovernancaGlobal = {
          alertClass: 'warn',
          icon: 'pi pi-clock',
          message: 'Atualização cadastral em análise pela Organização Estadual.',
        };
      } else if (this.cooperativa?.status === 'Aguardando ajustes') {
        this.statusGovernancaGlobal = {
          alertClass: 'warn',
          icon: 'pi pi-exclamation-triangle',
          message: 'Atualização cadastral aguardando ajustes da cooperativa.',
        };
      } else {
        this.statusGovernancaGlobal = null;
      }
      return;
    } else if (this.cooperativa?.situacaoCooperativa?.id !== 4 && this.cooperativa?.dataRegistro) {
      let dataAprovacao = this.aprovacao?.dataAtualizacao;
      let dataUltimaAlteracaoGeral: Date = null;
      let houveAlteracaoPosAprovacao: boolean = false;

      if (this.governancaArray) {
        this.governancaArray.forEach((g) => {
          if (g.mandato && g.mandato.dataAtualizacao) {
            const dataAlteracao = g.mandato.dataAtualizacao;
            if (dataAlteracao) {
              if (!dataUltimaAlteracaoGeral || dataAlteracao > dataUltimaAlteracaoGeral) {
                dataUltimaAlteracaoGeral = dataAlteracao;
              }
            }
          }
        });
      }
      houveAlteracaoPosAprovacao = dataAprovacao && dataUltimaAlteracaoGeral && dataUltimaAlteracaoGeral > dataAprovacao;
      if (this.cooperativa) {
        if (houveAlteracaoPosAprovacao) {
          this.statusGovernancaGlobal = {
            alertClass: 'warn',
            icon: 'pi pi-exclamation-triangle',
            message: `Cadastro do mandato alterado em: ${this.datePipe.transform(dataUltimaAlteracaoGeral, 'dd/MM/yyyy HH:mm')}. Aguarda aprovação.`,
          };
        }
      }
      if (!dataAprovacao) {
        this.statusGovernancaGlobal = {
          alertClass: 'warn',
          icon: 'pi pi-exclamation-triangle',
          message: 'Cadastro do mandato aguarda aprovação.',
        };
      } else if (!dataUltimaAlteracaoGeral || dataUltimaAlteracaoGeral <= dataAprovacao) {
        this.statusGovernancaGlobal = {
          alertClass: 'success',
          icon: 'pi pi-check-circle',
          message: `Cadastro do mandato aprovado em: ${this.datePipe.transform(dataAprovacao, 'dd/MM/yyyy HH:mm')}.`,
        };
      } else {
        this.statusGovernancaGlobal = {
          alertClass: 'warn',
          icon: 'pi pi-exclamation-triangle',
          message: `Cadastro do mandato alterado em: ${this.datePipe.transform(dataUltimaAlteracaoGeral, 'dd/MM/yyyy HH:mm')}. Aguarda aprovação.`,
        };
      }
    }
  }

  formatarNomeId(nome) {
    nome = StringUtil.limparTexto(nome);
    switch (nome) {
      case 'Conselho de AdministracaoDiretoria':
        return 'adm';
      case 'Conselho Fiscal':
        return 'fis';
      case 'Diretoria Contratada':
        return 'dir';
      default:
        return nome;
    }
  }

  buscaCpf(membro: MandatoMembro) {
    const membroExcluido = this.membrosGovExcluidos.find((m) => m.pessoaFisica.cpf === this.utility.retirarFormatacao(membro.pessoaFisica.cpf));

    if (membro.pessoaFisica.cpf && this.utility.retirarFormatacao(membro.pessoaFisica.cpf).length === 11) {
      this.pessoaApi.buscaPorCpf(this.utility.retirarFormatacao(membro.pessoaFisica.cpf)).then((response) => {
        if (response.data !== null && response.data.cpf === this.utility.retirarFormatacao(membro.pessoaFisica.cpf)) {
          membro.pessoaFisica = response.data;

          if (response?.data?.dataNascimento) {
            membro.pessoaFisica.dataNascimento = new Date(response.data.dataNascimento);
          }

          if (membroExcluido) {
            membro.id = membroExcluido.id;
          }
        } else {
          membro.pessoaFisica.id = null;
        }
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  /** Matriz do ramo via GovernancaRulesService (ponto único no front). */
  maximoAnos(orgao: Orgao) {
    return this.rules.maximoAnos(this.orgaoRamos, orgao.id, this.situacaoAtual());
  }

  /** Situação da cooperativa para as regras de ramo (porte/lei/liquidação). */
  private situacaoAtual(): SituacaoCooperativa {
    return {
      liquidacao: !!this.cooperativaTemp?.liquidacao,
      regidaPorLei: !!this.cooperativaTemp?.regidaPorLei,
      cooperadosTotal: this.quadroSocial?.cooperadosTotal ?? null,
    };
  }

  atualizaLiberacaoCampo(pendencia) {
    if (!this.pendenciasEditadas.includes(pendencia)) {
      this.pendenciasEditadas = [...this.pendenciasEditadas, pendencia];
    }
    const chave = pendencia.bloco + '_' + pendencia.identificadorAuxiliar;
    this.mapPendencias = { ...this.mapPendencias, [chave]: false };
    this.houveAlteracaoForm = true;

    // Se for governança, encontrar o mandato correspondente e atualizar data de alteração
    if (pendencia.bloco === 'MANUTENCAO_GOVERNANCA' || pendencia.bloco === 'GOVERNANCA') {
      const governanca = this.governancaArray.find((g) => g.mandato.orgao.id === pendencia.identificadorAuxiliar);
      if (governanca?.mandato) {
        governanca.mandato.dataAtualizacao = new Date();
        this.orgaosAlterados.add(governanca.mandato.orgao.id);
      }
    }

    this.changeDetectorRef.markForCheck();
  }

  carregaOrgaoCargo() {
    for (let i = 0; i < this.governancaArray.length; i++) {
      this.orgaoCargoApi.getPorOrgao(this.governancaArray[i].mandato.orgao.id).then((response2) => {
        this.orgaoCargos = response2.data;
        const cargos = new Array<Cargo>();
        const membros = this.governancaArray[i]?.mandato?.listaMandatoMembro ?? [];
        for (let j = 0, k = 0; j < this.orgaoCargos.length; j++) {
          cargos.push(this.orgaoCargos[j].cargo);
          const membro = membros[k];
          if (this.orgaoCargos[j].obrigatorio && membro && membro.representanteLegal === null) {
            membro.cargo = this.orgaoCargos[j].cargo;
            k++;
          }
        }
        this.optionsCargo[i] = cargos;
        this.changeDetectorRef.markForCheck();
      });
    }
  }

  getAlteracaoForm() {
    // Edição em rascunho ou inclusão rápida ABERTAS contam como alteração
    // pendente para TODOS os guards dos containers (diálogo de troca de aba,
    // CanDeactivate e beforeunload) — antes a inclusão rápida preenchida era
    // perdida silenciosamente na troca de aba. Salvar/cancelar a inclusão
    // rápida fecha o painel (inclusaoRapidaOrgaoId=null) e desarma o guard.
    if (this.algumaEdicaoAtiva()) {
      return true;
    }
    if (!this.isManutencao) {
      let alteracao = false;
      for (const ap of this.aprovacoes) {
        if (ap.houveAlteracao) {
          alteracao = true;
        }
      }
      return this.houveAlteracaoForm || alteracao;
    }
    return this.houveAlteracaoForm;
  }

  getOptionsDropDownCargo(i: number) {
    return this.optionsCargo[i];
  }

  fecharDialogModalEncerrarMandato() {
    this.modalValidarEncerrarMandatoVisivel = false;
  }

  /**
   * Alerta de vigência expirada (assembleia + duração < hoje) dos conselhos
   * de Administração e Fiscal. O alerta lista TODOS os conselhos expirados em
   * um único modal — o laço antigo retornava no primeiro "Fiscal" encontrado
   * e o Cons. de Administração nunca era citado.
   */
  validarEncerrarMandatoConselhoAdministracaoEFiscal(abaDestino): boolean {
    const conselhosExpirados: string[] = [];
    for (const governanca of this.governancaArray ?? []) {
      const mandato = governanca.mandato;
      if (mandato && mandato.dataAssembleia && mandato.anosDuracao && mandato.orgao) {
        const conselhoAlvo = mandato.orgao.nome.indexOf('Fiscal') !== -1 || mandato.orgao.nome.indexOf('Administração') !== -1;
        const fimVigencia = this.dateService.getDate(mandato.dataAssembleia);
        fimVigencia.setFullYear(fimVigencia.getFullYear() + mandato.anosDuracao);
        if (conselhoAlvo && new Date() >= fimVigencia) {
          conselhosExpirados.push(mandato.orgao.nome);
        }
      }
    }

    if (conselhosExpirados.length === 0) {
      return false;
    }
    this.labelModalEncerrarMandato = conselhosExpirados.join(' e ') + ': ';
    this.modalValidarEncerrarMandatoVisivel = true;
    this.showPopupEncerramentoMandatoVisivel(abaDestino, conselhosExpirados.length > 1);
    return true;
  }

  get somenteLeitura(): boolean {
    return this.cooperativa?.situacaoCooperativa?.nome?.toLowerCase() === 'cancelada';
  }

  get abaEditavel(): boolean {
    return this.podeModificarOsCampos && !this.somenteLeitura;
  }

  get processoJaSubmetido(): boolean {
    const progresso = this.cooperativa?.progressoMicro;
    return (
      progresso === ProgressoMicroEnum.AGUARDANDO_ANALISE_2_1 ||
      progresso === ProgressoMicroEnum.AGUARDANDO_ANALISE_CONFORMIDADE_3_1 ||
      progresso === ProgressoMicroEnum.AGUARDANDO_AJUSTE_2_2 ||
      progresso === ProgressoMicroEnum.AGUARDANDO_AJUSTE_CONFORMIDADE_3_2
    );
  }

  showPopupEncerramentoMandatoVisivel(abaDestino, plural = false) {
    const complemento = plural
      ? `O tempo dos mandatos atuais expirou.
      É necessário encerrá-los e cadastrar novos.`
      : `O tempo do mandato atual expirou.
      É necessário encerrá-lo e cadastrar um novo.`;
    this.confirmationService.confirm({
      header: 'O tempo do mandato atual expirou!',
      message: `${this.labelModalEncerrarMandato} ${complemento}`,
      icon: 'pi pi-exclamation-triangle',
      rejectVisible: false,
      acceptLabel: 'Ciente',
      accept: () => {
        if (abaDestino !== null) {
          this.salvarConfirmacao(abaDestino);
        }
      },
      key: 'dialog1',
    });
  }

  salvar(abaDestino: number): void {
    if (!this.isManutencao) {
      abaDestino = 3;
    }

    let pendenciaPreenchimentoTela = false;
    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchimentoTela = true;
      }
    });

    if (pendenciaPreenchimentoTela) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Preencha corretamente as orientações para ajuste!',
        life: 10000,
      });
      return;
    }

    this.houveAlteracaoForm = true;

    if (!this.validarEncerrarMandatoConselhoAdministracaoEFiscal(abaDestino)) {
      this.salvarConfirmacao(abaDestino);
    }
  }

  salvarConfirmacao(abaDestino) {
    if (this.salvando) {
      return;
    }
    this.salvando = true;
    if (this.isManutencao) {
      this.geralService.salvarPendenciaManutencao(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);
    } else {
      this.geralService.salvarPendencia(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);
    }

    if (this.pendenciasEditadas.length > 0) {
      this.apiValidacaoService.editarAgrupamento(this.pendenciasEditadas).then((res) => {
        this.pendenciasEditadas = res.data;
      });
    }

    const aba = {
      id: null,
      cooperativa: { id: Number(this.cooperativa.id) },
      dataEnvio: null,
      aba: ControleAbasRegistroEnum.GOVERNANCA,
      enviada: true,
    };

    this.apiControleAbas.save(aba).subscribe();

    this.salvarTodosConselhos()
      .then(() => {
        if (this.isManutencao) {
          window.scroll(0, 0);
          this.evtFimSalvarDados.emit(abaDestino);
          this.desativaEventoForm();
        } else {
          this.evtSalvarDados.emit(true);
          this.verificarLiberacaoCampos();
          this.atualizarMensagensTela();

          if (this.governancaArray) {
            this.governancaArray = [];
          }

          this.houveAlteracaoForm = false;

          for (const ap of this.aprovacoes) {
            if (ap.houveAlteracao) {
              ap.houveAlteracao = false;
            }
          }

          this.membrosGovExcluidos = [];
          this.carregaTela();
          window.scroll(0, 0);

          this.evtFimSalvarDados.emit(abaDestino);

          this.desativaEventoForm();
        }
        this.carregarPendencias();
        this.changeDetectorRef.markForCheck();
      })
      .catch(() => {
        this.evtErroSalvar.emit(true);
      })
      .finally(() => {
        this.salvando = false;
        this.changeDetectorRef.markForCheck();
      });
  }

  /**
   * Grava os conselhos ALTERADOS da aba, em sequência, pelo salvar-por-conselho
   * — único caminho de gravação. Usado pelo diálogo "salvar aba?" dos
   * containers de Registro/Manutenção.
   *
   * Conselhos SEM alteração real não são POSTados — o save-página em rajada
   * gerava 400 inócuo (conselho vazio) e no-ops, e a rejeição impedia o
   * resync do chamador (UI defasada até reload manual). Entram no save:
   * conselhos com dirty-flag (orgaosAlterados), o rascunho de edição aberto
   * e a inclusão rápida VÁLIDA.
   *
   * Falha em um conselho não aborta os demais: os que falharam são nomeados ao
   * usuário, a tela é ressincronizada se algo chegou a ser gravado e a promise
   * é rejeitada ao final.
   */
  private async salvarTodosConselhos(): Promise<void> {
    const conselhosComFalha: string[] = [];
    let houveGravacao = false;
    try {
      for (const g of this.governancaArray ?? []) {
        // Conselho em edição: grava o RASCUNHO (mesma regra do botão "Salvar"
        // do card) — senão o "Salvar" do diálogo de sair descartaria a edição.
        const emEdicaoComRascunho = this.emEdicao(g) && !!this.draftGovernanca;
        if (!emEdicaoComRascunho && !this.orgaosAlterados.has(g.mandato.orgao.id)) {
          continue; // sem alteração real neste conselho — não POSTa
        }
        try {
          const origem = emEdicaoComRascunho ? this.draftGovernanca : g;
          const preparada = this.prepararGovernancaParaSalvar(origem);
          const mandatoTO = this.toMandatoTO(preparada.mandato);
          const res = await this.governancaApi.salvarPorConselho(this.cooperativa.id, g.mandato.orgao.id, mandatoTO, this.isManutencao);
          houveGravacao = true;
          if (emEdicaoComRascunho) {
            g.mandato = this.draftGovernanca.mandato;
            this.editandoOrgaoId = null;
            this.draftGovernanca = null;
            this.houveExclusaoNaEdicao = false;
          }
          this.aplicarRetornoSalvarConselho(g, res?.data as MandatoTO);
          // Mesma regra do salvarConselho: desarma o dirty-flag SÓ deste
          // conselho; o guard global segue armado para os que falharem.
          this.orgaosAlterados.delete(g.mandato.orgao.id);
          this.houveAlteracaoForm = this.orgaosAlterados.size > 0;
        } catch {
          conselhosComFalha.push(g.mandato.orgao.nome);
        }
      }
      // Painel de inclusão rápida aberto com membro COMPLETO também é
      // gravado pelo "Salvar" do diálogo de saída (mesmo caminho do botão
      // "Incluir e salvar") — depois dos conselhos, para o salvar-por-conselho
      // não competir com o membro recém-incluído. Painel incompleto é
      // descartado: o diálogo já avisou que alterações não salvas se perdem.
      if (this.inclusaoRapidaOrgaoId !== null && this.membroInclusaoRapida) {
        const gInclusao = (this.governancaArray ?? []).find((x) => x.mandato.orgao.id === this.inclusaoRapidaOrgaoId);
        if (gInclusao && this.membroInclusaoRapidaValido()) {
          try {
            await this.incluirMembroInclusaoRapida(gInclusao);
            houveGravacao = true;
          } catch {
            conselhosComFalha.push(gInclusao.mandato.orgao.nome);
          }
        }
        this.cancelarInclusaoRapida();
      }
    } finally {
      this.carregarPendencias();
    }
    if (conselhosComFalha.length > 0) {
      // No caminho de erro o chamador NÃO recarrega a tela (cai no catch).
      // Se algo chegou a ser gravado, ressincroniza aqui — senão um membro
      // incluído no banco ficava fora da lista até reload manual. Exceção:
      // rascunho de edição cujo save falhou permanece aberto para correção
      // (carregaTela o descartaria silenciosamente).
      if (houveGravacao && !this.draftGovernanca) {
        this.carregaTela();
      }
      const complemento = houveGravacao ? ' Os demais conselhos foram salvos.' : '';
      this.messageService.add({
        severity: 'error',
        detail: `Não foi possível salvar: ${conselhosComFalha.join(', ')}.${complemento}`,
        life: 10000,
      });
      throw new Error(`Falha ao salvar os conselhos: ${conselhosComFalha.join(', ')}`);
    }
  }

  /**
   * Sincroniza o modelo de tela com o mandato retornado pelo salvar-por-conselho:
   * sem atualizar `mandato.id` e os ids dos membros, o próximo "Salvar"
   * reenviaria id=null e o backend criaria um SEGUNDO mandato vigente do
   * órgão. Os membros são casados por CPF (sem máscara).
   */
  private aplicarRetornoSalvarConselho(g: Governanca, salvo: MandatoTO | null | undefined): void {
    if (!salvo) {
      return;
    }
    g.mandato.id = salvo.id ?? g.mandato.id;
    g.mandato.dataAtualizacao = (salvo as MandatoTO & { dataAtualizacao?: Date }).dataAtualizacao ?? new Date();
    const membrosSalvos = salvo.listaMandatoMembro ?? [];
    (g.mandato.listaMandatoMembro ?? []).forEach((membro) => {
      if (membro.id || !membro.pessoaFisica?.cpf) {
        return;
      }
      const cpf = this.utility.retirarFormatacao(membro.pessoaFisica.cpf);
      const correspondente = membrosSalvos.find((ms) => ms.pessoaFisica?.cpf && this.utility.retirarFormatacao(ms.pessoaFisica.cpf) === cpf);
      if (correspondente) {
        membro.id = correspondente.id;
        if (correspondente.pessoaFisica?.id) {
          membro.pessoaFisica.id = correspondente.pessoaFisica.id;
        }
      }
    });
  }
  /** Carrega as pendências agregadas por conselho + flag pode-avançar. */
  private carregarPendencias(): Promise<void> {
    if (!this.cooperativa) {
      return Promise.resolve();
    }
    return this.governancaApi
      .buscarPendencias(this.cooperativa.id)
      .then((res) => {
        this.pendenciasGovernanca = res?.data ?? null;
        this.evtEstadoPreenchimento.emit(this.pendenciasGovernanca?.estadoPreenchimento ?? null);
        this.changeDetectorRef.markForCheck();
      })
      .catch(() => {
        this.pendenciasGovernanca = null;
        this.evtEstadoPreenchimento.emit(null);
        this.changeDetectorRef.markForCheck();
      });
  }

  /** Pendências do conselho (casadas por órgão) — necessárias para submeter. */
  pendenciasDoOrgao(orgaoId: number): string[] {
    return this.pendenciasGovernanca?.conselhos?.find((c) => c.idOrgao === orgaoId)?.pendencias ?? [];
  }

  /** Pendências da aba não associadas a um conselho — também bloqueiam o Avançar. */
  get pendenciasGerais(): string[] {
    return this.pendenciasGovernanca?.pendenciasGerais ?? [];
  }

  private static textoPlano(html: string): string {
    return (html ?? '')
      .replace(/<[^>]*>/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  get mensagensValidacaoSemPendencias(): { summary: string; detail: string }[] {
    const textosPendencias = new Set<string>();
    (this.pendenciasGovernanca?.conselhos ?? []).forEach((conselho) =>
      (conselho.pendencias ?? []).forEach((p) => textosPendencias.add(GovernancaSharedComponent.textoPlano(p)))
    );
    this.pendenciasGerais.forEach((p) => textosPendencias.add(GovernancaSharedComponent.textoPlano(p)));
    return this.mensagensValidacao.filter((msg) => !textosPendencias.has(GovernancaSharedComponent.textoPlano(`${msg.summary}${msg.detail}`)));
  }

  /**
   * Com mandato vigente e aprovado, os botões
   * de excluir membro/mandato ficam desabilitados para cooperativa e unidade
   * estadual — a exclusão é restrita ao Nacional. Diretoria Contratada (vínculo
   * CONTRATAÇÃO) é exceção; antes da aprovação apagar segue livre.
   */
  exclusaoBloqueadaFr032(mandato: Mandato, membro?: MandatoMembro): boolean {
    if (this.isNacional) {
      return false;
    }
    if (mandato?.orgao?.vinculo === 'CONTRATAÇÃO') {
      return false;
    }
    const aprovado = !!(mandato?.aprovacao || membro?.aprovacao);
    return !!mandato?.vigente && aprovado;
  }

  /**
   * Botão "Remover" do membro (vínculo estatutário). Na atualização cadastral,
   * mandato vigente já basta para bloquear cooperativa/UE — o caminho é o
   * desligamento (espelha validarExclusaoMembroAprovado no backend). No registro
   * o bloqueio segue valendo só a partir da aprovação. O Nacional mantém a
   * exclusão (apenas exige membro persistido).
   */
  apagarMembroDesabilitado(mandato: Mandato, membro: MandatoMembro): boolean {
    if (!membro?.id) {
      return true;
    }
    if (this.isNacional) {
      return false;
    }
    if (this.isManutencao && !!mandato?.vigente && mandato?.orgao?.vinculo !== 'CONTRATAÇÃO') {
      return true;
    }
    return this.podeModificarMembros(mandato, membro) || this.exclusaoBloqueadaFr032(mandato, membro);
  }

  /**
   * Salva SOMENTE este conselho/órgão via salvar-por-conselho.
   * Reaproveita a preparação de mandato do salvar-da-aba (datas, órgão opcional,
   * merge de inativos), mas grava apenas o mandato deste órgão — os demais
   * conselhos permanecem inalterados (isolamento garantido pelo backend).
   */
  salvarConselho(g: Governanca, aoConcluir?: () => void, aoFalhar?: () => void): void {
    let pendenciaPreenchimentoTela = false;
    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchimentoTela = true;
      }
    });
    if (pendenciaPreenchimentoTela) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Preencha corretamente as orientações para ajuste!',
        life: 10000,
      });
      if (aoFalhar) {
        aoFalhar();
      }
      return;
    }

    const orgaoId = g.mandato.orgao.id;
    // Em edição, grava o RASCUNHO; fora dela, o próprio modelo.
    const origem = this.emEdicao(g) && this.draftGovernanca ? this.draftGovernanca : g;
    const governancaPreparada = this.prepararGovernancaParaSalvar(origem);
    const mandatoTO = this.toMandatoTO(governancaPreparada.mandato);

    this.salvandoConselhoOrgaoId = orgaoId;
    this.governancaApi
      .salvarPorConselho(this.cooperativa.id, orgaoId, mandatoTO, this.isManutencao)
      .then((res) => {
        this.salvandoConselhoOrgaoId = null;
        if (this.emEdicao(g) && this.draftGovernanca) {
          g.mandato = this.draftGovernanca.mandato;
          this.editandoOrgaoId = null;
          this.draftGovernanca = null;
          this.houveExclusaoNaEdicao = false;
          this.rotuloSubstituto.clear();
          this.idsInativosAoEditar.clear();
        }
        this.aplicarRetornoSalvarConselho(g, res?.data as MandatoTO);
        // Data de fim do desmarque da DC é de uso único — consumida neste save.
        delete this.dataFimContratoPorOrgao[orgaoId];
        // P1 nº 7: desarma o dirty-flag SÓ deste conselho; o guard global permanece
        // armado enquanto houver outro conselho com edição não salva.
        this.orgaosAlterados.delete(orgaoId);
        this.houveAlteracaoForm = this.orgaosAlterados.size > 0;
        this.atualizarMensagensTela();
        this.carregarPendencias().then(() => {
          const nomeOrgao = g.mandato.orgao.nome;
          if (this.pendenciasDoOrgao(orgaoId).length > 0) {
            this.messageService.add({
              severity: 'warn',
              detail: `Registro salvo com pendências. Conselho "${nomeOrgao}" gravado — há pendências a resolver.`,
            });
          } else {
            this.messageService.add({
              severity: 'success',
              detail: `Conselho "${nomeOrgao}" salvo com sucesso.`,
            });
          }
        });
        this.processarStatusGlobal();
        this.evtSalvarDados.emit(true);
        if (aoConcluir) {
          aoConcluir();
        }
        this.changeDetectorRef.markForCheck();
      })
      .catch((err) => {
        this.salvandoConselhoOrgaoId = null;
        if (!err?.error?.messages?.length) {
          this.messageService.add({
            severity: 'error',
            detail: `Não foi possível salvar o conselho "${g.mandato.orgao.nome}".`,
          });
        }
        this.evtErroSalvar.emit(true);
        if (aoFalhar) {
          aoFalhar();
        }
        this.changeDetectorRef.markForCheck();
      });
  }

  /** Prepara um único mandato para gravação (espelha a lógica por item do salvar-da-aba). */
  private prepararGovernancaParaSalvar(g: Governanca): Governanca {
    g.mandato.coopPossui = !(!g.mandato.orgao.obrigatorio && !this.orgaoOpcional[g.mandato.orgao.id]);

    g.mandato.dataAssembleia = this.dateService.getDate(g.mandato.dataAssembleia);

    g.mandato.listaMandatoMembro.forEach((membro) => {
      membro.inicioMandato = this.dateService.getDate(membro.inicioMandato);
      membro.fimMandato = this.dateService.getDate(membro.fimMandato);
      if (membro.pessoaFisica.escolaridadeTemp) {
        membro.pessoaFisica.idEscolaridade = membro.pessoaFisica.escolaridadeTemp.id;
        membro.pessoaFisica.escolaridadeTemp = null;
      }
    });

    if (!g.mandato.mostrarInativos) {
      const governancaTemp: Governanca = JSON.parse(JSON.stringify(g));
      const governancaMembrosInativos = this.inativosGuardadosDe(g.mandato);
      governancaMembrosInativos?.listaMandatoMembro.forEach((membro) => {
        if (!governancaTemp.mandato.listaMandatoMembro.some((atual) => this.mesmoMembro(atual, membro))) {
          governancaTemp.mandato.listaMandatoMembro.push(membro);
        }
      });
      governancaTemp.mandato.listaMandatoMembro = governancaTemp.mandato.listaMandatoMembro.filter((membro) => membro.pessoaFisica.cpf);
      governancaTemp.mandato.dataAssembleia = this.dateService.getDate(governancaTemp.mandato.dataAssembleia);
      this.definirMembrosMandatoParaEnvio(governancaTemp.mandato);
      return governancaTemp;
    }

    // Achado P1 nº 10: com "mostrar inativos" ligado o payload ia CRU — sem o
    // filtro de linhas sem CPF (que o legado SEMPRE aplicava) nem o recálculo de
    // membrosMandato — e o motor bloqueava com NOME/CARGO obrigatório "do nada".
    // Mesmo tratamento do ramo acima (a lista já contém os inativos exibidos).
    const governancaComInativos: Governanca = JSON.parse(JSON.stringify(g));
    governancaComInativos.mandato.listaMandatoMembro = governancaComInativos.mandato.listaMandatoMembro.filter((membro) => membro.pessoaFisica.cpf);
    governancaComInativos.mandato.dataAssembleia = this.dateService.getDate(governancaComInativos.mandato.dataAssembleia);
    this.definirMembrosMandatoParaEnvio(governancaComInativos.mandato);
    return governancaComInativos;
  }

  /**
   * `membrosMandato` é a quantidade eleita em assembleia — derivada da lista
   * enquanto o mandato NÃO está aprovado (criação e edição durante o
   * cadastro/manutenção em andamento). Após a aprovação (FR-031) o valor do
   * servidor é reenviado sem recalcular: o save comum não pode sobrescrever
   * essa referência (um save sem alteração podia mudar 2→3 porque o backend
   * copia o campo). Opera sempre sobre o CLONE de envio — a tela não é mutada.
   */
  private definirMembrosMandatoParaEnvio(mandato: Mandato): void {
    if (!mandato.id) {
      mandato.membrosMandato = mandato.listaMandatoMembro.length;
      return;
    }
    if (!mandato.aprovacao) {
      mandato.membrosMandato = mandato.listaMandatoMembro.filter((membro) => membro.membroAtivo).length;
    }
  }

  /** Mapeia o Mandato (modelo de tela) para o MandatoTO do contrato salvar-por-conselho. */
  private toMandatoTO(mandato: Mandato): MandatoTO {
    const to = new MandatoTO();
    to.id = mandato.id;
    to.dataAssembleia = mandato.dataAssembleia;
    to.orgao = mandato.orgao;
    to.fimMandato = mandato.fimMandato;
    to.anosDuracao = mandato.anosDuracao;
    to.membrosMandato = mandato.membrosMandato;
    to.vigente = mandato.vigente;
    to.aprovacao = mandato.aprovacao;
    to.coopPossui = mandato.coopPossui;
    to.dataAssembleiaStr = mandato.dataAssembleiaStr;
    to.listaMandatoMembro = mandato.listaMandatoMembro;
    to.tamListaMembrosAtivos = mandato.tamListaMembrosAtivos;
    to.tamMinLista = mandato.tamMinLista;
    to.mostrarInativos = mandato.mostrarInativos;
    // RN-DC-02: data de fim do contrato do desmarque da DC (capturada no modal);
    // o backend desativa os membros ativos com esta data.
    to.dataFimContrato = this.dataFimContratoPorOrgao[mandato.orgao.id] ?? null;
    return to;
  }

  /**
   * Avança a aba: o antigo "salvar tudo" vira submissão agregada.
   * A persistência agora é por conselho (salvarConselho); aqui só validamos que
   * não há pendências nem edição não salva, e então avançamos.
   */
  avancar(abaDestino: number): void {
    if (!this.isManutencao) {
      abaDestino = 3;
    }

    let pendenciaPreenchimentoTela = false;
    this.aprovacoes.forEach((elem) => {
      if (elem.visualizado === true) {
        pendenciaPreenchimentoTela = true;
      }
    });
    if (pendenciaPreenchimentoTela) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Preencha corretamente as orientações para ajuste!',
        life: 10000,
      });
      return;
    }

    if (this.houveAlteracaoForm) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Salve os conselhos alterados antes de avançar.',
      });
      return;
    }

    if (!this.pendenciasGovernanca || !this.pendenciasGovernanca.podeAvancar) {
      this.messageService.add({
        severity: 'warn',
        detail: 'Existem pendências em um ou mais conselhos. Resolva-as antes de avançar.',
      });
      return;
    }

    if (this.isManutencao) {
      this.geralService.salvarPendenciaManutencao(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);
    } else {
      this.geralService.salvarPendencia(this.aprovacoes, [() => this.evtSalvarDados.emit(true)]);
    }

    if (this.pendenciasEditadas.length > 0) {
      this.apiValidacaoService.editarAgrupamento(this.pendenciasEditadas).then((res) => {
        this.pendenciasEditadas = res.data;
      });
    }

    const aba = {
      id: null,
      cooperativa: { id: Number(this.cooperativa.id) },
      dataEnvio: null,
      aba: ControleAbasRegistroEnum.GOVERNANCA,
      enviada: true,
    };
    this.apiControleAbas.save(aba).subscribe();

    this.avisarOrgaosSemParecerDaAnalise();

    window.scroll(0, 0);
    this.evtFimSalvarDados.emit(abaDestino);
    this.desativaEventoForm();
  }

  /**
   * Avançar de aba não grava nada (a gravação é por conselho), então o aviso
   * aqui não pode falar em "registro salvo". Segue o gate de fase das demais
   * abas e nomeia os órgãos cujo parecer da análise ainda não foi marcado.
   */
  private avisarOrgaosSemParecerDaAnalise(): void {
    if (this.isManutencao || !this.ajusteDadosComponentes?.first) {
      return;
    }
    if (this.ajusteDadosComponentes.first.pendenciaAtual?.cooperativa?.progressoMicro !== 'AGUARDANDO_ANALISE_2_1') {
      return;
    }
    const orgaosSemParecer = this.ajusteDadosComponentes
      .filter((componente) => componente.validacaoSemMarcacao())
      .map((componente) => componente.titulo)
      .filter((nome) => !!nome);
    if (!orgaosSemParecer.length) {
      return;
    }
    this.messageService.add({
      severity: 'warn',
      life: 10000,
      detail: `Marque "Aprovar dados" ou "Solicitar ajustes" em: ${orgaosSemParecer.join(', ')}.`,
    });
  }

  carregarMandatoMembros(governancaArray: Governanca[]) {
    for (let index = 0; index < governancaArray.length; index++) {
      const governanca = governancaArray[index];
      governanca.mandato.listaMandatoMembro = governanca.mandato.listaMandatoMembro.filter((membro) => membro.pessoaFisica.cpf);
    }
  }

  adicionarMembro(g: Governanca) {
    if (!this.podeAdicionarMembro(g)) {
      this.messageService.add({
        severity: 'warn',
        detail: `Mandato aprovado: desligue um membro do ${g.mandato.orgao.nome} para incluir o substituto.`,
      });
      return;
    }
    const membro = this.criaMandatoMembro();
    g.mandato.listaMandatoMembro = [...g.mandato.listaMandatoMembro, membro];
    this.sincronizarQtdeMembrosEleitos(g.mandato);
    this.focarMembro(g, membro);
    this.changeDetectorRef.markForCheck();
  }

  private sincronizarQtdeMembrosEleitos(m: Mandato) {
    if (!!m.id && !!m.aprovacao) {
      return;
    }
    const ativos = this.getListaMembrosAtivos(m).length;
    if (ativos > (m.tamListaMembrosAtivos ?? 0)) {
      m.tamListaMembrosAtivos = ativos;
    }
  }

  private criaMandatoMembro() {
    const mandatoMembro = new MandatoMembro();
    mandatoMembro.pessoaFisica = new PessoaFisica();
    mandatoMembro.membroAtivo = true;
    mandatoMembro.cargo = new Cargo();
    mandatoMembro.representanteLegal = false;
    mandatoMembro.aprovacao = null;
    mandatoMembro.isNew = true;
    return mandatoMembro;
  }

  excluirMembro(membro: MandatoMembro, g: Governanca) {
    g.mandato.listaMandatoMembro = g.mandato.listaMandatoMembro.filter((m) => m !== membro);
    this.excluirMandatoMembro(membro);
    this.changeDetectorRef.markForCheck();
  }

  /**
   * Remover membro de mandato aprovado não reduz o nº de membros eleitos (o
   * backend deixa de re-sincronizar membrosMandato após a aprovação): a linha
   * do removido dá lugar a uma linha de substituto, que precisa ser preenchida
   * e salva para o conselho voltar a fechar com a quantidade declarada.
   */
  apagarMembro(membro: MandatoMembro, m: Mandato) {
    const indice = m.listaMandatoMembro.indexOf(membro);
    const exigeSubstituto =
      !!membro.id && !!membro.membroAtivo && !!m.aprovacao && m.orgao?.vinculo !== 'CONTRATAÇÃO';
    m.listaMandatoMembro = m.listaMandatoMembro.filter((mm) => mm !== membro);
    this.membrosGovExcluidos = [...this.membrosGovExcluidos, membro];
    if (exigeSubstituto) {
      m.listaMandatoMembro = this.inserirSubstitutoDoRemovido(m, membro, indice);
    } else {
      m.tamListaMembrosAtivos = m.listaMandatoMembro.length;
    }
    this.excluirMandatoMembro(membro);
    this.avisarOrgaoOpcionalSemMembros(m);
    this.changeDetectorRef.markForCheck();
  }

  private inserirSubstitutoDoRemovido(m: Mandato, removido: MandatoMembro, indice: number): MandatoMembro[] {
    const substituto = this.criaMandatoMembro();
    this.rotuloSubstituto.set(substituto, removido.pessoaFisica?.nome?.trim() || 'membro removido');
    this.substitutoRecemInserido = substituto;
    if (indice < 0) {
      return [...m.listaMandatoMembro, substituto];
    }
    return [...m.listaMandatoMembro.slice(0, indice), substituto, ...m.listaMandatoMembro.slice(indice)];
  }

  private avisarOrgaoOpcionalSemMembros(mandato: Mandato): void {
    if (mandato?.orgao?.obrigatorio !== false || !this.orgaoOpcional[mandato.orgao.id]) {
      return;
    }
    if (this.membrosAtivosReais(mandato).length > 0) {
      return;
    }
    this.messageService.add({
      severity: 'info',
      life: 10000,
      detail:
        `"${mandato.orgao.nome}" é um órgão opcional e ficou sem membros. ` +
        `Desmarque "Cooperativa possui ${mandato.orgao.nome}" para remover os demais dados do órgão e avançar.`,
    });
  }

  excluirMandatoMembro(membro: MandatoMembro) {
    if (membro.id) {
      this.apiManutencaoGovernanca.excluirMandatoMembro(membro.id);
      // Exclusão efetivada na API durante uma edição em rascunho: "Cancelar"
      // precisará ressincronizar a tela com o backend.
      this.registrarExclusaoNaEdicao();
    }
  }

  alterarQtdeMembros(m: Mandato) {
    const minimo = this.minimoMembros(m);
    if (m.tamListaMembrosAtivos < minimo) {
      m.tamListaMembrosAtivos = minimo;
      this.messageService.add({
        severity: 'warn',
        detail: `O ramo exige no mínimo ${minimo} membro(s) no ${m.orgao.nome}.`,
      });
    }

    if (m.listaMandatoMembro.length > m.tamListaMembrosAtivos) {
      const removidos = this.selecionaMembrosParaRemover(m, m.listaMandatoMembro.length - m.tamListaMembrosAtivos);
      m.listaMandatoMembro = m.listaMandatoMembro.filter((membro) => !removidos.includes(membro));
      this.membrosGovExcluidos = [...this.membrosGovExcluidos, ...removidos.filter((membro) => !!membro.id)];
    }

    const membrosAtivos = m.listaMandatoMembro.filter((membro) => membro.membroAtivo);

    if (!m.mostrarInativos) {
      m.listaMandatoMembro = membrosAtivos;
    }

    if (m.mostrarInativos) {
      this.toggleMembrosInativos(m);
    }

    this.defineQtdeMinMembros(m);
  }

  private qtdeFixaPorAprovacao(m: Mandato): boolean {
    if (this.isNacional || m?.orgao?.vinculo === 'CONTRATAÇÃO') {
      return false;
    }
    return !!m?.id && !!m?.aprovacao;
  }

  private selecionaMembrosParaRemover(m: Mandato, quantidade: number): MandatoMembro[] {
    const vazios = m.listaMandatoMembro.filter((membro) => !membro.pessoaFisica?.cpf);
    const preenchidos = m.listaMandatoMembro.filter((membro) => !!membro.pessoaFisica?.cpf);
    return [...vazios.reverse(), ...preenchidos.reverse()].slice(0, quantidade);
  }

  private defineQtdeMinMembros(m: Mandato) {
    const membrosAtivos = m.listaMandatoMembro.filter((membro) => membro.membroAtivo);

    if (this.qtdeFixaPorAprovacao(m)) {
      m.tamListaMembrosAtivos = m.membrosMandato ?? membrosAtivos.length;
      return membrosAtivos;
    }

    if (!m.tamListaMembrosAtivos || m.tamListaMembrosAtivos === 0 || m.tamListaMembrosAtivos < this.minimoMembros(m)) {
      m.tamListaMembrosAtivos = this.minimoMembros(m);
    }

    if (membrosAtivos.length < m.tamListaMembrosAtivos) {
      for (let i = 0; i < m.tamListaMembrosAtivos - membrosAtivos.length; i++) {
        if (m.orgao.vinculo !== 'CONTRATAÇÃO') {
          m.listaMandatoMembro = [...m.listaMandatoMembro, this.criaMandatoMembro()];
        }
      }
    }

    m.tamListaMembrosAtivos = m.listaMandatoMembro.filter((membro) => membro.membroAtivo).length;

    return m.listaMandatoMembro.filter((mandato) => mandato.membroAtivo);
  }

  limitarDuracaoMandato(m: Mandato) {
    const maximo = this.maximoAnos(m.orgao);
    if (m.anosDuracao != null && m.anosDuracao > maximo) {
      m.anosDuracao = maximo;
      this.messageService.add({
        severity: 'warn',
        detail: `A duração do mandato do ${m.orgao.nome} não pode passar de ${maximo} ano(s).`,
      });
    }
    if (m.anosDuracao != null && m.anosDuracao < 1) {
      m.anosDuracao = 1;
    }
  }

  /** Matriz do ramo via GovernancaRulesService (ponto único no front). */
  minimoMembros(m: Mandato) {
    const minimo = this.rules.minimoMembros(this.orgaoRamos, m.orgao.id, this.situacaoAtual());
    m.tamMinLista = minimo;
    return minimo;
  }

  carregarEscolaridade(): Promise<void> {
    return this.apiManutencaoCadastrosRegistro.listarEscolaridade().then((response) => {
      // listarEscolaridade (public) está tipado como IServiceResponse<any>; o backend
      // (EscolaridadeRestController) retorna List<EscolaridadeTO>.
      this.optionsEscolaridade = response.data as EscolaridadeTO[];
      this.changeDetectorRef.markForCheck();
    });
  }

  validaAjustesDados(): boolean {
    if (this.cooperativaTemp) {
      if (this.isManutencao) {
        return this.validacaoDados.validaAjustesDadosManutencao(this.cooperativaTemp.progressoManutencaoMicro);
      } else {
        return this.validacaoDados.validaAjustesDados(this.cooperativaTemp.progressoMacro);
      }
    }
    return false;
  }

  get isNacional() {
    return this.keycloakService.isUsuarioNacional;
  }

  /**
   * No fluxo de REGISTRO a fase bloqueada (podePreencher=false) vale
   * TAMBÉM para o Nacional — o backend rejeita qualquer save com 400 "Aguarde
   * o andamento do processo", então liberar a edição só faria o usuário montar
   * um rascunho fadado a se perder. Na MANUTENÇÃO o bypass do Nacional é
   * comportamento legado (SOUC-514) e permanece intacto.
   */
  private nacionalBloqueadoPelaFase(): boolean {
    return !this.isManutencao && !this.podeModificarOsCampos;
  }

  podeModificarMembros(mandato: Mandato, membro?: MandatoMembro) {
    if (this.somenteLeitura) {
      return true;
    }

    if (this.isNacional) {
      return this.nacionalBloqueadoPelaFase();
    }

    if (this.isManutencao) {
      return (
        (!this.podeModificarOsCampos ||
          !!this.mapPendencias['MANUTENCAO_GOVERNANCA_' + mandato.orgao.id] ||
          membro?.aprovacao ||
          this.membroDeMandatoAprovado(mandato, membro)) &&
        !membro?.isNew
      );
    } else {
      return (
        !this.podeModificarOsCampos ||
        !!this.mapPendencias['GOVERNANCA_' + mandato.orgao.id] ||
        (this.membroDeMandatoAprovado(mandato, membro) && !membro?.isNew)
      );
    }
  }

  private membroDeMandatoAprovado(mandato: Mandato, membro?: MandatoMembro): boolean {
    if (mandato?.orgao?.vinculo === 'CONTRATAÇÃO') {
      return false;
    }
    return !!mandato?.aprovacao && !!membro?.id;
  }

  /**
   * Conselho travado porque a análise aprovou o agrupamento deste órgão. A saída
   * é reabrir o agrupamento em "Editar dados do agrupamento", que cancela aquela
   * aprovação e devolve a edição — sem isso o botão fica cinza sem explicação.
   */
  conselhoTravadoPorAgrupamentoAprovado(g: Governanca): boolean {
    if (this.somenteLeitura || !this.podeModificarOsCampos) {
      return false;
    }
    const chave = (this.isManutencao ? 'MANUTENCAO_GOVERNANCA_' : 'GOVERNANCA_') + g.mandato.orgao.id;
    return !!this.mapPendencias[chave];
  }

  private bloqueioBaseConselho(mandato: Mandato): boolean {
    if (this.isNacional) {
      return this.nacionalBloqueadoPelaFase();
    }
    const chave = (this.isManutencao ? 'MANUTENCAO_GOVERNANCA_' : 'GOVERNANCA_') + mandato.orgao.id;
    return !!(this.somenteLeitura || !this.podeModificarOsCampos || this.mapPendencias[chave]);
  }

  private isAtualizacaoCadastralAprovada(): boolean {
    return this.cooperativa?.status?.toLowerCase() === 'aprovada';
  }

  podeExcluirMembroMandato(mandato: Mandato, membro: MandatoMembro): boolean {
    if (this.somenteLeitura) {
      return true;
    }

    if (this.isNacional) {
      return false;
    }

    return this.podeModificarMembros(mandato, membro) || !membro?.id || !!membro?.aprovacao || this.isAtualizacaoCadastralAprovada();
  }

  podeModificarCampos(mandato: Mandato) {
    if (this.isNacional) {
      return this.nacionalBloqueadoPelaFase();
    }

    const aprovacaoBloqueia = mandato?.orgao?.vinculo !== 'CONTRATAÇÃO' && !!mandato.aprovacao;
    return !!(
      !this.podeModificarOsCampos ||
      aprovacaoBloqueia ||
      (this.isManutencao ? this.mapPendencias['MANUTENCAO_GOVERNANCA_' + mandato.orgao.id] : this.mapPendencias['GOVERNANCA_' + mandato.orgao.id])
    );
  }

  podeModificarDiretoriaContratada(mandato: Mandato, membro?: MandatoMembro) {
    if (this.isNacional) {
      return this.nacionalBloqueadoPelaFase();
    }

    if (this.isManutencao) {
      return !this.podeModificarOsCampos || membro.membroAtivo || this.mapPendencias['MANUTENCAO_GOVERNANCA_' + mandato.orgao.id];
    } else {
      return !this.podeModificarOsCampos || this.mapPendencias['GOVERNANCA_' + mandato.orgao.id];
    }
  }

  atualizaPendenciaChaveManutencao(coop: Cooperativa) {
    this.apiValidacaoService.obterUltimasPendenciasChaveManutencao(coop.id).then((res) => {
      this.mapPendencias = res.data as unknown as Record<string, boolean>;
      this.changeDetectorRef.markForCheck();
    });
  }

  adicionarMandatoVigente(g: Governanca, c: Cooperativa) {
    if (g.mandato.aprovacao || this.podeModificarOsCampos) {
      // Confirmação com "Cancelar" explícito (dialog govConfirm do componente).
      this.confirmationService.confirm({
        key: 'govConfirm',
        message:
          'Esta ação vai adicionar um novo mandato no ' +
          g.mandato.orgao.nome +
          " da cooperativa e deixará o mandato atual como 'não vigente' e não será possível editá-lo. Deseja continuar?",
        accept: () => {
          this.tornarUltimoMandatoNaoVigente(g.mandato.orgao.id, c.id);
        },
      });
    } else {
      this.messageService.add({
        severity: 'warn',
        detail: 'Nao é possível adicionar um novo mandato.',
      });
    }
  }

  tornarUltimoMandatoNaoVigente(idOrgao: number, idCooperativa: number) {
    this.apiManutencaoGovernanca.tornarUltimoMandatoNaoVigente(idOrgao, idCooperativa).then(() => {
      this.carregaTela();
      this.changeDetectorRef.markForCheck();
    });
  }

  historicoMandatos(g: Governanca, c: Cooperativa) {
    if (c && g.mandato.orgao) {
      this.historicoGovernanca.consultaHistorico(c.id, g.mandato.orgao.id);
      this.historicoGovernanca.existeVigente = this.mapTemVigente.get(g.mandato.orgao.id);
      this.modalVisivel = true;
      this.nomeOrgao = g.mandato.orgao.nome;
    }
  }

  resumoAcao(descricao: string | null | undefined): string {
    return descricao?.split('\n')[0] ?? '';
  }

  abrirTrilha(g: Governanca) {
    if (this.cooperativa && g?.mandato?.orgao) {
      this.trilhaAcoes.abrir(this.cooperativa.id, g.mandato.orgao.id, g.mandato.orgao.nome);
    }
  }

  fecharDialogEditarHistorico() {
    this.modalVisivel = false;
  }

  public desativaEventoForm() {
    this.houveAlteracaoForm = false;
    this.orgaosAlterados.clear();
  }

  dialogExcluirMandato(g: Governanca, c: Cooperativa) {
    // Confirmação destrutiva com "Cancelar" explícito.
    this.confirmationService.confirm({
      key: 'govConfirm',
      message: 'Esta ação vai excluir o mandato permanentemente. Deseja continuar?',
      accept: () => {
        this.excluirMandato(c.id, g);
      },
    });
  }

  dialogApagarMandatoMembro(membro: MandatoMembro, g: Governanca) {
    // "Cancelar" explícito; linha ainda não salva não é exclusão "permanente".
    this.confirmationService.confirm({
      key: 'govConfirm',
      message: membro?.id
        ? 'Esta ação vai excluir o membro do mandato permanentemente. Deseja continuar?'
        : 'Esta ação vai remover a linha do membro ainda não salvo. Deseja continuar?',
      accept: () => {
        this.apagarMembro(membro, g.mandato);
      },
    });
  }

  excluirMandato(idCoop, governanca: Governanca) {
    if (!governanca.mandato.id) {
      this.carregaTela();
    } else {
      this.apiManutencaoGovernanca.excluirMandato(governanca.mandato.id, idCoop).then(() => this.carregaTela());
    }
  }

  podeAlterarMembroAtivo(mandato: Mandato, membro: MandatoMembro) {
    if (membro?.isNew) {
      return true; // desabilitado
    }

    if (!this.isNacional && !this.isManutencao) {
      return !this.podeModificarOsCampos || this.mapPendencias['GOVERNANCA_' + mandato.orgao.id] || (mandato.aprovacao && !membro.membroAtivo);
    } else {
      return false;
    }
  }

  private inativosGuardadosDe(mandato: Mandato): Mandato | undefined {
    return this.listaMandatosMembrosInativos.find((guardado) => guardado.orgao?.id === mandato?.orgao?.id);
  }

  getMembrosAtivos(m: Mandato) {
    const listaMandatoMembro = m?.listaMandatoMembro || [];
    const listaMembrosInativos = listaMandatoMembro.filter((mandatoMembro) => !mandatoMembro.membroAtivo);
    const indiceMandatoInativo = this.listaMandatosMembrosInativos.findIndex((guardado) => guardado.orgao?.id === m?.orgao?.id);

    if (indiceMandatoInativo >= 0) {
      this.listaMandatosMembrosInativos[indiceMandatoInativo].listaMandatoMembro = [...listaMembrosInativos];
    } else {
      this.listaMandatosMembrosInativos = [...this.listaMandatosMembrosInativos, { ...m, listaMandatoMembro: [...listaMembrosInativos] }];
    }

    return this.defineQtdeMinMembros(m);
  }

  toggleMembrosInativos(m: Mandato) {
    if (!m) {
      return;
    }
    if (!m.listaMandatoMembro) {
      m.listaMandatoMembro = [];
    }

    if (!m.mostrarInativos) {
      m.listaMandatoMembro = m.listaMandatoMembro.filter((membro) => membro.membroAtivo);
      this.changeDetectorRef.markForCheck();
      return;
    }

    const guardados = this.inativosGuardadosDe(m)?.listaMandatoMembro ?? [];
    guardados.forEach((membro) => {
      if (!membro.membroAtivo && !m.listaMandatoMembro.some((atual) => this.mesmoMembro(atual, membro))) {
        m.listaMandatoMembro = [...m.listaMandatoMembro, membro];
      }
    });
    this.changeDetectorRef.markForCheck();
  }

  private mesmoMembro(a: MandatoMembro, b: MandatoMembro): boolean {
    if (a === b) {
      return true;
    }
    if (a?.id && b?.id) {
      return a.id === b.id;
    }
    const cpfA = this.utility.retirarFormatacao(a?.pessoaFisica?.cpf ?? '');
    const cpfB = this.utility.retirarFormatacao(b?.pessoaFisica?.cpf ?? '');
    return !!cpfA && cpfA === cpfB;
  }

  checkListaMembroInativo(m: Mandato, membro: MandatoMembro) {
    // "Nº de membros eleitos" antes deste toggle (alvo de ativos)
    const alvoMembrosAtivos = m.tamListaMembrosAtivos;

    if (!membro.membroAtivo) {
      this.listaMandatosMembrosInativos = this.listaMandatosMembrosInativos.map((mandatoMembroInativo) => {
        if (m?.orgao?.id === mandatoMembroInativo.orgao?.id && !mandatoMembroInativo.listaMandatoMembro.includes(membro)) {
          return { ...mandatoMembroInativo, listaMandatoMembro: [...mandatoMembroInativo.listaMandatoMembro, membro] };
        }
        return mandatoMembroInativo;
      });

      // Só adiciona linha nova se ainda não atingiu o nº de membros eleitos
      const ativos = this.getListaMembrosAtivos(m).length;
      if (membro.pessoaFisica.cpf && ativos < alvoMembrosAtivos) {
        m.listaMandatoMembro = this.inserirSubstituto(m, membro);
      }
    } else if (membro.membroAtivo) {
      this.listaMandatosMembrosInativos = this.listaMandatosMembrosInativos.map((mandatoMembroInativo) => {
        if (m?.orgao?.id === mandatoMembroInativo.orgao?.id) {
          return {
            ...mandatoMembroInativo,
            listaMandatoMembro: mandatoMembroInativo.listaMandatoMembro.filter((membroInativo) => membroInativo.id !== membro.id),
          };
        }
        return mandatoMembroInativo;
      });

      // Remove linhas vazias excedentes para não passar do nº de membros eleitos
      let ativos = this.getListaMembrosAtivos(m).length;
      while (ativos > alvoMembrosAtivos) {
        const indiceVazio = m.listaMandatoMembro.findIndex((mm) => mm.membroAtivo && !mm.pessoaFisica.cpf && mm !== membro);
        if (indiceVazio === -1) {
          break; // não há mais linha vazia para remover
        }
        this.rotuloSubstituto.delete(m.listaMandatoMembro[indiceVazio]);
        m.listaMandatoMembro = m.listaMandatoMembro.filter((_, i) => i !== indiceVazio);
        ativos--;
      }
    }

    m.tamListaMembrosAtivos = this.getListaMembrosAtivos(m).length;
  }

  private inserirSubstituto(m: Mandato, desligado: MandatoMembro): MandatoMembro[] {
    const substituto = this.criaMandatoMembro();
    const indice = m.listaMandatoMembro.indexOf(desligado);
    this.rotuloSubstituto.set(substituto, desligado.pessoaFisica?.nome?.trim() || 'membro desligado');
    this.substitutoRecemInserido = substituto;
    if (indice < 0) {
      return [...m.listaMandatoMembro, substituto];
    }
    return [...m.listaMandatoMembro.slice(0, indice + 1), substituto, ...m.listaMandatoMembro.slice(indice + 1)];
  }

  rotuloDeSubstituto(membro: MandatoMembro): string | null {
    return this.rotuloSubstituto.get(membro) ?? null;
  }

  private focarMembro(g: Governanca, membro: MandatoMembro): void {
    this.buscaPorOrgao[g.mandato.orgao.id] = '';
    setTimeout(() => {
      const indice = this.membrosVisiveis(g).indexOf(membro);
      if (indice < 0) {
        return;
      }
      const campo = document.getElementById(`inp-${this.formatarNomeId(g.mandato.orgao.nome)}-cpf-membro-${indice}`);
      if (!campo) {
        return;
      }
      campo.scrollIntoView({ block: 'center', behavior: 'smooth' });
      campo.focus();
    });
  }

  private coletarIdsInativosPersistidos(g: Governanca): Set<number> {
    const ids = new Set<number>();
    const inativos = [
      ...(g.mandato.listaMandatoMembro ?? []),
      ...(this.inativosGuardadosDe(g.mandato)?.listaMandatoMembro ?? []),
    ];
    inativos.filter((membro) => !!membro.id && !membro.membroAtivo).forEach((membro) => ids.add(membro.id));
    return ids;
  }

  private mensagemSituacaoMembro(membro: MandatoMembro, novoStatus: boolean, nome: string): string {
    if (!novoStatus) {
      return `Confirma o desligamento de <b>${nome}</b>?`;
    }
    if (!!membro.id && this.idsInativosAoEditar.has(membro.id)) {
      return `Confirma a reativação de <b>${nome}</b>? A data de desligamento será removida e a alteração será efetivada ao salvar o conselho.`;
    }
    return `Desfazer o desligamento de <b>${nome}</b>? O registro ainda não foi salvo.`;
  }

  aoAlternarSituacaoMembro(g: Governanca, mandato: Mandato, membro: MandatoMembro): void {
    const novoStatus = !!membro.membroAtivo;
    const nome = membro.pessoaFisica?.nome || 'este membro';
    this.confirmationService.confirm({
      key: 'govConfirm',
      header: 'Confirmação',
      message: this.mensagemSituacaoMembro(membro, novoStatus, nome),
      accept: () => {
        this.houveMudancaForm(g);
        this.substitutoRecemInserido = null;
        this.checkListaMembroInativo(mandato, membro);
        if (membro.membroAtivo) {
          membro.fimMandato = null;
        }
        if (this.substitutoRecemInserido) {
          this.focarMembro(g, this.substitutoRecemInserido);
          this.substitutoRecemInserido = null;
        }
        this.changeDetectorRef.markForCheck();
      },
      reject: () => {
        membro.membroAtivo = !novoStatus;
        this.changeDetectorRef.markForCheck();
      },
    });
  }

  getListaMembrosAtivos(mandato: Mandato): MandatoMembro[] {
    return mandato.listaMandatoMembro.filter((membro) => membro.membroAtivo);
  }

  private membrosAtivosReais(mandato: Mandato): MandatoMembro[] {
    return this.getListaMembrosAtivos(mandato).filter((membro) => this.membroReal(membro));
  }

  private membrosAtivosPersistidos(g: Governanca): MandatoMembro[] {
    return this.getListaMembrosAtivos(this.governancaExibida(g).mandato).filter((membro) => !!membro.id);
  }

  /**
   * Guarda do desmarque de órgão opcional, religada ao (change) do checkbox
   * (RN-PAR-08 + RN-DC-02): órgão estatutário com mandato vigente que ainda tem
   * MEMBRO ATIVO não desmarca (orienta encerrar primeiro e reverte); Diretoria
   * Contratada com membros ativos abre o modal da data de fim do contrato (os
   * membros são DESATIVADOS — nada é excluído). Sem membro ativo, os dois
   * vínculos seguem o mesmo caminho de desmarque. O backend aplica as mesmas
   * regras (fonte da verdade).
   */
  aoAlternarOrgaoOpcional(g: Governanca): void {
    const orgaoId = g.mandato.orgao.id;
    if (this.orgaoOpcional[orgaoId] !== false) {
      delete this.dataFimContratoPorOrgao[orgaoId];
      this.houveMudancaFormOrgaoOpcional(g);
      this.abrirEdicaoParaRegistrarMembros(g);
      return;
    }

    const ativos = this.membrosAtivosPersistidos(g);

    if (!this.isContratacao(g)) {
      if (g.mandato.vigente && ativos.length > 0) {
        this.orgaoOpcional[orgaoId] = true; // reverte o desmarque
        this.confirmationService.confirm({
          header: 'Existe mandato ainda vigente!',
          message: 'Encerre o mandato vigente antes de desmarcar esse campo.',
          icon: 'pi pi-exclamation-triangle',
          rejectVisible: false,
          acceptLabel: 'Fechar',
          accept: () => {},
          key: 'dialog2',
        });
        return;
      }
      this.concluirDesmarqueOrgaoOpcional(g);
      return;
    }

    // Diretoria Contratada: nada é excluído — membros ativos são desativados.
    if (g.mandato.id && ativos.length > 0) {
      this.dcDesmarqueGovernanca = g;
      this.dcDataFimContrato = null;
      this.dcDesmarqueConfirmado = false;
      const inicios = ativos.map((m) => this.dateService.getDate(m.inicioMandato)).filter((d) => !!d) as Date[];
      this.dcDataFimMinima = inicios.length ? new Date(Math.max(...inicios.map((d) => d.getTime()))) : null;
      this.dcDesmarqueVisivel = true;
      return;
    }
    this.concluirDesmarqueOrgaoOpcional(g);
  }

  private concluirDesmarqueOrgaoOpcional(g: Governanca): void {
    const orgaoId = g.mandato.orgao.id;
    if (!g.mandato.id) {
      if (this.emEdicao(g)) {
        this.cancelarEdicao();
        return;
      }
      this.orgaosAlterados.delete(orgaoId);
      this.houveAlteracaoForm = this.orgaosAlterados.size > 0;
      return;
    }
    this.confirmationService.confirm({
      key: 'govConfirm',
      message: `Confirma que a cooperativa não possui "${g.mandato.orgao.nome}"? O mandato será encerrado e os dados do órgão removidos — os registros de membros são preservados no histórico.`,
      accept: () => {
        this.descartarEdicao();
        this.houveMudancaFormOrgaoOpcional(g);
        this.salvarConselho(
          g,
          () => this.carregaTela(),
          () => this.reverterDesmarqueOrgaoOpcional(orgaoId, true)
        );
      },
      reject: () => {
        this.reverterDesmarqueOrgaoOpcional(orgaoId);
      },
    });
  }

  /**
   * Desistência ou falha do desmarque: remarca o órgão e descarta a data de fim
   * de contrato capturada no modal — ela é de uso único e, se sobrevivesse,
   * seria reenviada no próximo save do conselho, desativando os membros ativos.
   * O dirty-flag só é desarmado quando foi o próprio desmarque que o armou.
   */
  private reverterDesmarqueOrgaoOpcional(orgaoId: number, limparDirty = false): void {
    this.orgaoOpcional[orgaoId] = true;
    delete this.dataFimContratoPorOrgao[orgaoId];
    if (limparDirty) {
      this.orgaosAlterados.delete(orgaoId);
      this.houveAlteracaoForm = this.orgaosAlterados.size > 0;
    }
  }

  private abrirEdicaoParaRegistrarMembros(g: Governanca): void {
    if (!this.isContratacao(g) || this.emEdicao(g) || this.edicaoIndisponivel(g)) {
      return;
    }
    this.entrarEdicao(g);
    if (!this.draftGovernanca) {
      return;
    }
    const mandato = this.draftGovernanca.mandato;
    const faltam = this.minimoMembros(mandato) - this.getListaMembrosAtivos(mandato).length;
    for (let i = 0; i < faltam; i++) {
      this.adicionarMembro(this.draftGovernanca);
    }
  }

  /** Confirma o desmarque da DC: valida a data e dispara o save do conselho. */
  confirmarDesmarqueDc(): void {
    const g = this.dcDesmarqueGovernanca;
    const data = this.dateService.getDate(this.dcDataFimContrato);
    if (!g || !data) {
      this.messageService.add({ severity: 'warn', detail: 'Informe a data de fim do contrato.' });
      return;
    }
    if (this.dcDataFimMinima && data.getTime() < this.dcDataFimMinima.getTime()) {
      this.messageService.add({
        severity: 'warn',
        detail: 'O fim do contrato não pode ser anterior ao início do contrato dos membros ativos.',
      });
      return;
    }
    if (data.getTime() > new Date().getTime()) {
      this.messageService.add({ severity: 'warn', detail: 'O fim do contrato não pode ser superior à data atual.' });
      return;
    }
    const orgaoId = g.mandato.orgao.id;
    this.dataFimContratoPorOrgao[orgaoId] = data;
    this.dcDesmarqueConfirmado = true;
    this.dcDesmarqueVisivel = false;
    this.descartarEdicao();
    this.houveMudancaFormOrgaoOpcional(g);
    this.salvarConselho(
      g,
      () => this.carregaTela(),
      () => this.reverterDesmarqueOrgaoOpcional(orgaoId, true)
    );
  }

  /** Fechar o modal sem confirmar reverte o desmarque do checkbox. */
  aoFecharModalDesmarqueDc(): void {
    if (!this.dcDesmarqueConfirmado && this.dcDesmarqueGovernanca) {
      this.reverterDesmarqueOrgaoOpcional(this.dcDesmarqueGovernanca.mandato.orgao.id);
    }
    this.dcDesmarqueGovernanca = null;
    this.dcDataFimContrato = null;
    this.dcDataFimMinima = null;
  }

  // ------------------------------------------------------------------
  // Redesign do protótipo (2026-07-06): accordion por conselho, edição em
  // rascunho (um conselho por vez — FR-024), inclusão rápida (FR-025) e
  // rodapé de submissão agregada (FR-026/FR-030).
  // ------------------------------------------------------------------

  /** Cor de destaque do cartão (protótipo: navy/verde; Diretoria Contratada azul). */
  accentDoConselho(g: Governanca, index: number): string {
    if (this.isContratacao(g)) {
      return 'gov-accent-dc';
    }
    return `gov-accent-${index % GovernancaSharedComponent.TOTAL_ACCENTS}`;
  }

  isContratacao(g: Governanca): boolean {
    return g?.mandato?.orgao?.vinculo === 'CONTRATAÇÃO';
  }

  orientacaoLegal(g: Governanca): string | null {
    if (g?.mandato?.orgao?.vinculo !== 'ESTATUTÁRIO ELETIVO') {
      return null;
    }
    const nome = (g.mandato.orgao.nome || '').toLowerCase();
    if (nome.indexOf('fiscal') >= 0) {
      return (
        'Orientação legal (Lei nº 5.764/71, art. 56): o Conselho Fiscal é composto por ' +
        '3 membros efetivos e 3 suplentes, eleitos anualmente pela Assembleia Geral, ' +
        'permitida a reeleição de apenas 1/3 (um terço) dos seus componentes.'
      );
    }
    if (nome.indexOf('administra') >= 0) {
      return (
        'Orientação legal (Lei nº 5.764/71, art. 47): o mandato dos membros do Conselho de ' +
        'Administração não pode exceder 4 (quatro) anos, sendo obrigatória a renovação de, ' +
        'no mínimo, 1/3 (um terço) dos seus componentes a cada eleição.'
      );
    }
    return 'Orientação legal: observe as regras de composição, renovação e reeleição previstas ' + 'na Lei nº 5.764/71 e no estatuto social da cooperativa.';
  }

  trackPorOrgao(_indice: number, g: Governanca): number {
    return g?.mandato?.orgao?.id;
  }

  emEdicao(g: Governanca): boolean {
    return this.editandoOrgaoId !== null && this.editandoOrgaoId === g?.mandato?.orgao?.id;
  }

  /** Alguma ação exclusiva em andamento (edição ou inclusão rápida). */
  algumaEdicaoAtiva(): boolean {
    return this.editandoOrgaoId !== null || this.inclusaoRapidaOrgaoId !== null;
  }

  /** Este cartão fica esmaecido enquanto OUTRO conselho está em edição. */
  outroConselhoOcupado(g: Governanca): boolean {
    return this.algumaEdicaoAtiva() && !this.emEdicao(g) && this.inclusaoRapidaOrgaoId !== g.mandato.orgao.id;
  }

  estaExpandido(g: Governanca): boolean {
    return this.emEdicao(g) || !!this.expandidoPorOrgao[g.mandato.orgao.id];
  }

  /**
   * Estado inicial do accordion (protótipo): conselhos COM membros persistidos
   * abrem já expandidos; se nenhum tiver (registro novo), abre o primeiro.
   * Recargas (salvar/cancelar/tornar vigente) preservam o que o usuário
   * abriu/fechou — só define o default de órgãos ainda sem estado.
   */
  inicializarExpansaoConselhos(): void {
    if (!this.governancaArray?.length) {
      return;
    }
    const primeiroAcesso = Object.keys(this.expandidoPorOrgao).length === 0;
    const emAnalise = this.validaAjustesDados();
    this.governancaArray.forEach((g) => {
      const orgaoId = g.mandato.orgao.id;
      if (this.expandidoPorOrgao[orgaoId] === undefined) {
        this.expandidoPorOrgao[orgaoId] = emAnalise || this.temMembroPersistido(g);
      }
    });
    const nenhumAberto = !this.governancaArray.some((g) => this.expandidoPorOrgao[g.mandato.orgao.id]);
    if (primeiroAcesso && nenhumAberto) {
      this.expandidoPorOrgao[this.governancaArray[0].mandato.orgao.id] = true;
    }
  }

  private temMembroPersistido(g: Governanca): boolean {
    return (g.mandato.listaMandatoMembro ?? []).some((membro) => !!membro.id);
  }

  alternarExpansao(g: Governanca): void {
    if (this.emEdicao(g)) {
      return; // em edição o cartão fica travado aberto
    }
    this.expandidoPorOrgao[g.mandato.orgao.id] = !this.expandidoPorOrgao[g.mandato.orgao.id];
  }

  /** Fonte de exibição do corpo: o rascunho quando em edição, senão o modelo. */
  governancaExibida(g: Governanca): Governanca {
    return this.emEdicao(g) && this.draftGovernanca ? this.draftGovernanca : g;
  }

  /** Entra em edição clonando o conselho para um rascunho (FR-024). */
  entrarEdicao(g: Governanca): void {
    if (this.algumaEdicaoAtiva()) {
      this.messageService.add({ severity: 'warn', detail: 'Conclua a edição do outro conselho primeiro.' });
      return;
    }
    this.idsInativosAoEditar = this.coletarIdsInativosPersistidos(g);
    this.draftGovernanca = this.clonarGovernanca(g);
    if (this.exigeMinimoDeMembros(this.draftGovernanca)) {
      this.defineQtdeMinMembros(this.draftGovernanca.mandato);
    }
    this.editandoOrgaoId = g.mandato.orgao.id;
    this.expandidoPorOrgao[g.mandato.orgao.id] = true;
    this.houveExclusaoNaEdicao = false;
  }

  /**
   * Cancela a edição descartando o rascunho e ressincroniza a tela com o
   * backend — cobre tanto exclusões imediatas de membro efetivadas na API
   * durante a edição quanto qualquer estado derivado (lista de inativos)
   * tocado pelo rascunho.
   */
  cancelarEdicao(): void {
    this.descartarEdicao();
    this.carregaTela();
  }

  /** Descarta o rascunho e o dirty-flag do conselho em edição, sem recarregar. */
  private descartarEdicao(): void {
    this.rotuloSubstituto.clear();
    this.idsInativosAoEditar.clear();
    const orgaoId = this.editandoOrgaoId;
    this.editandoOrgaoId = null;
    this.draftGovernanca = null;
    this.houveExclusaoNaEdicao = false;
    if (orgaoId != null) {
      this.orgaosAlterados.delete(orgaoId);
      this.houveAlteracaoForm = this.orgaosAlterados.size > 0;
    }
  }

  private exigeMinimoDeMembros(g: Governanca): boolean {
    const mandato = g?.mandato;
    if (!mandato || mandato.orgao?.vinculo === 'CONTRATAÇÃO' || this.qtdeMembrosBloqueada(g)) {
      return false;
    }
    return mandato.orgao?.obrigatorio !== false || !!this.orgaoOpcional[mandato.orgao.id];
  }

  /** Botão "Editar conselho": indisponível durante outra edição ou sem permissão. */
  edicaoIndisponivel(g: Governanca): boolean {
    return this.algumaEdicaoAtiva() || this.bloqueioBaseConselho(g.mandato);
  }

  salvarBloqueado(g: Governanca): boolean {
    return this.bloqueioBaseConselho(g.mandato) || this.salvandoConselhoOrgaoId === g.mandato.orgao.id;
  }

  podeAdicionarMembro(g: Governanca): boolean {
    const mandato = this.governancaExibida(g).mandato;
    if (this.bloqueioBaseConselho(mandato)) {
      return false;
    }
    if (!this.qtdeMembrosBloqueada(g)) {
      return true;
    }
    return this.getListaMembrosAtivos(mandato).length < this.numeroMembrosEleitosExibido(g);
  }

  edicaoRestritaPorAprovacao(g: Governanca): boolean {
    if (this.isNacional || g?.mandato?.orgao?.vinculo === 'CONTRATAÇÃO') {
      return false;
    }
    return !!g?.mandato?.aprovacao;
  }

  /**
   * Duração do mandato (anos) e nº de membros eleitos ficam somente-leitura
   * para Coop/UE somente após a APROVAÇÃO do mandato (FR-031/Card 1;
   * FR-001/FR-002 da feature 003). Cadastro em andamento — mandato salvo mas
   * nunca analisado — permanece editável.
   */
  assembleiaBloqueada(g: Governanca): boolean {
    if (this.isNacional) {
      return false;
    }
    const mandato = this.governancaExibida(g).mandato;
    if (mandato?.orgao?.vinculo === 'CONTRATAÇÃO') {
      return false;
    }
    return !!mandato.id && !!mandato.aprovacao;
  }

  duracaoMandatoBloqueada(g: Governanca): boolean {
    // RN-BLQ-02 revisada (feature 003): o Nacional edita a duração mesmo em
    // mandato aprovado — o bloqueio vale só para Coop/UE.
    if (this.isNacional) {
      return false;
    }
    const mandato = this.governancaExibida(g).mandato;
    return !!mandato.id && !!mandato.aprovacao && mandato.anosDuracao != null;
  }

  cpfBloqueado(mandato: Mandato, membro: MandatoMembro): boolean {
    if (mandato?.orgao?.vinculo === 'CONTRATAÇÃO') {
      return false;
    }
    return !!membro?.id && !!mandato?.aprovacao;
  }

  qtdeMembrosBloqueada(g: Governanca): boolean {
    // RN-BLQ-02 revisada (feature 003): idem para o nº de membros eleitos.
    if (this.isNacional) {
      return false;
    }
    const mandato = this.governancaExibida(g).mandato;
    return !!mandato.id && !!mandato.aprovacao && !!mandato.tamListaMembrosAtivos;
  }

  /** Clona o conselho para edição em rascunho, reidratando datas do JSON. */
  private clonarGovernanca(g: Governanca): Governanca {
    const clone: Governanca = JSON.parse(JSON.stringify(g));
    clone.mandato.dataAssembleia = this.dateService.getDate(clone.mandato.dataAssembleia);
    (clone.mandato.listaMandatoMembro ?? []).forEach((membro) => {
      membro.inicioMandato = this.dateService.getDate(membro.inicioMandato);
      membro.fimMandato = this.dateService.getDate(membro.fimMandato);
      if (membro.pessoaFisica) {
        membro.pessoaFisica.dataNascimento = this.dateService.getDate(membro.pessoaFisica.dataNascimento);
        // Religa a escolaridade à instância das opções (p-dropdown casa por referência/dataKey).
        if (membro.pessoaFisica.escolaridadeTemp) {
          membro.pessoaFisica.escolaridadeTemp =
            this.optionsEscolaridade.find((e) => e.id === membro.pessoaFisica.escolaridadeTemp.id) ?? membro.pessoaFisica.escolaridadeTemp;
        }
      }
    });
    return clone;
  }

  /** Exclusão imediata de membro durante a edição — marca a necessidade de resync no cancelar. */
  registrarExclusaoNaEdicao(): void {
    if (this.editandoOrgaoId !== null) {
      this.houveExclusaoNaEdicao = true;
    }
  }

  // ---- Inclusão rápida ("Incluir e salvar", FR-025) ----

  inclusaoRapidaAberta(g: Governanca): boolean {
    return this.inclusaoRapidaOrgaoId !== null && this.inclusaoRapidaOrgaoId === g.mandato.orgao.id;
  }

  /** Disponível apenas com conselho já salvo (o backend exige o mandato vigente). */
  podeIncluirRapido(g: Governanca): boolean {
    return !!g.mandato.id && !this.algumaEdicaoAtiva() && !this.bloqueioBaseConselho(g.mandato) && this.podeAdicionarMembro(g);
  }

  abrirInclusaoRapida(g: Governanca): void {
    if (this.algumaEdicaoAtiva()) {
      this.messageService.add({ severity: 'warn', detail: 'Conclua a ação em andamento primeiro.' });
      return;
    }
    this.membroInclusaoRapida = this.criaMandatoMembro();
    this.inclusaoRapidaOrgaoId = g.mandato.orgao.id;
    this.expandidoPorOrgao[g.mandato.orgao.id] = true;
  }

  cancelarInclusaoRapida(): void {
    this.inclusaoRapidaOrgaoId = null;
    this.membroInclusaoRapida = null;
  }

  membroInclusaoRapidaValido(): boolean {
    const m = this.membroInclusaoRapida;
    if (!m) {
      return false;
    }
    const cpf = this.utility.retirarFormatacao(m.pessoaFisica?.cpf ?? '');
    return cpf.length === 11 && !!m.pessoaFisica?.nome?.trim() && !!m.pessoaFisica?.genero && !!m.cargo?.id && !!m.inicioMandato;
  }

  /**
   * Normaliza o membro do painel e envia ao incluir-membro (FR-025). Caminho
   * único usado pelo botão "Incluir e salvar" e pelo "Salvar" do diálogo de
   * saída (A1 — salvarTodosConselhos).
   */
  private incluirMembroInclusaoRapida(g: Governanca): Promise<unknown> {
    const membro = this.membroInclusaoRapida;
    membro.pessoaFisica.cpf = this.utility.retirarFormatacao(membro.pessoaFisica.cpf);
    if (membro.pessoaFisica.escolaridadeTemp) {
      membro.pessoaFisica.idEscolaridade = membro.pessoaFisica.escolaridadeTemp.id;
      membro.pessoaFisica.escolaridadeTemp = null;
    }
    membro.inicioMandato = this.dateService.getDate(membro.inicioMandato);
    membro.fimMandato = this.dateService.getDate(membro.fimMandato);
    return this.governancaApi.incluirMembro(this.cooperativa.id, g.mandato.orgao.id, membro, this.isManutencao);
  }

  salvarInclusaoRapida(g: Governanca): void {
    if (!this.membroInclusaoRapida || !this.membroInclusaoRapidaValido()) {
      this.messageService.add({ severity: 'warn', detail: 'Preencha os campos obrigatórios do novo membro.' });
      return;
    }

    this.salvandoInclusaoRapida = true;
    this.incluirMembroInclusaoRapida(g)
      .then(() => {
        this.salvandoInclusaoRapida = false;
        this.cancelarInclusaoRapida();
        this.messageService.add({
          severity: 'success',
          detail: `Membro incluído e salvo no ${g.mandato.orgao.nome}.`,
        });
        this.carregaTela();
        this.carregarPendencias();
        this.changeDetectorRef.markForCheck();
      })
      .catch((err) => {
        this.salvandoInclusaoRapida = false;
        if (!err?.error?.messages?.length) {
          this.messageService.add({
            severity: 'error',
            detail: `Não foi possível incluir o membro no ${g.mandato.orgao.nome}.`,
          });
        }
        this.changeDetectorRef.markForCheck();
      });
  }

  // ---- Leitura (tabela compacta), busca e resumo dos cartões ----

  /** Normalização da busca (A6): minúsculas e sem acentos ("joao" encontra "João"). */
  private normalizarBusca(texto: string): string {
    return (texto ?? '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase();
  }

  /** Membros exibidos: lista atual (ativos ± inativos) filtrada pela busca. */
  membrosVisiveis(g: Governanca): MandatoMembro[] {
    const lista = this.governancaExibida(g).mandato.listaMandatoMembro ?? [];
    const consulta = this.normalizarBusca((this.buscaPorOrgao[g.mandato.orgao.id] ?? '').trim());
    if (!consulta) {
      return lista;
    }
    const digitos = consulta.replace(/\D/g, '');
    return lista.filter(
      (membro) =>
        this.normalizarBusca(membro.pessoaFisica?.nome ?? '').includes(consulta) ||
        (!!digitos && this.utility.retirarFormatacao(membro.pessoaFisica?.cpf ?? '').includes(digitos)) ||
        this.normalizarBusca(membro.cargo?.nome ?? '').includes(consulta)
    );
  }

  /**
   * Membro "real" para os CONTADORES (A15): persistido (id) ou com CPF
   * preenchido. Linhas-placeholder do backend e drafts vazios ("Revisar")
   * ficam de fora da contagem — a exibição da tabela e o payload enviado
   * não mudam.
   */
  private membroReal(membro: MandatoMembro): boolean {
    return !!membro?.id || !!membro?.pessoaFisica?.cpf;
  }

  /** Campos essenciais faltando (linha placeholder ou incompleta) — chip "Revisar". */
  membroIncompleto(membro: MandatoMembro): boolean {
    return !membro.pessoaFisica?.cpf || !membro.pessoaFisica?.nome || !membro.cargo?.id;
  }

  situacaoMembro(membro: MandatoMembro): 'Ativo' | 'Inativo' | 'Revisar' {
    if (!membro.membroAtivo) {
      return 'Inativo';
    }
    return this.membroIncompleto(membro) ? 'Revisar' : 'Ativo';
  }

  contadorMembros(g: Governanca): string {
    // A15: conta apenas membros REAIS — placeholders do backend e linhas draft
    // vazias apareciam como "ativos" contradizendo a própria pendência do motor.
    const mandato = this.governancaExibida(g).mandato;
    const reais = (mandato.listaMandatoMembro ?? []).filter((m) => this.membroReal(m));
    const ativos = reais.filter((m) => m.membroAtivo).length;
    const inativosGuardados = (this.inativosGuardadosDe(mandato)?.listaMandatoMembro ?? []).filter((m) =>
      this.membroReal(m)
    ).length;
    const inativosNaLista = reais.filter((m) => !m.membroAtivo).length;
    const inativos = Math.max(inativosGuardados, inativosNaLista);
    return `${ativos} membros ativos` + (inativos ? ` · ${inativos} inativo(s)` : '');
  }

  /**
   * Valor EXIBIDO no "Nº de membros eleitos". Com o campo bloqueado (mandato
   * aprovado — FR-031/hint "não editável") mostra o VALOR PERSISTIDO
   * `membrosMandato`, alinhado à regra do payload (definirMembrosMandatoParaEnvio):
   * a quantidade eleita em assembleia não acompanha a lista de membros (N1/QA R5:
   * com membrosMandato=2 no banco e 3 membros na lista, o campo exibia 3,
   * contradizendo o hint "não editável"). Sem valor persistido (mandato antigo),
   * cai na contagem de membros reais ativos (A15 — imune a placeholders/drafts).
   * Com o campo editável (criação do mandato), reflete o modelo normalmente.
   * Exibição apenas — o payload não muda.
   */
  numeroMembrosEleitosExibido(g: Governanca): number {
    const mandato = this.governancaExibida(g).mandato;
    if (this.qtdeMembrosBloqueada(g)) {
      const ativosReais = (mandato.listaMandatoMembro ?? []).filter((m) => m.membroAtivo && this.membroReal(m)).length;
      if (mandato.membrosMandato != null) {
        return Math.max(mandato.membrosMandato, ativosReais);
      }
      return ativosReais;
    }
    return mandato.tamListaMembrosAtivos;
  }

  metaConselho(g: Governanca): string {
    const mandato = this.governancaExibida(g).mandato;
    if (this.isContratacao(g)) {
      return mandato.id ? 'Conselho próprio — salvo separadamente' : 'Ainda não cadastrada';
    }
    const assembleia = mandato.dataAssembleia ? this.datePipe.transform(this.dateService.getDate(mandato.dataAssembleia), 'dd/MM/yyyy') : '—';
    return `Mandato ${mandato.anosDuracao ?? '—'} ano(s) · Assembleia ${assembleia}`;
  }

  chipConselhoOk(g: Governanca): boolean {
    return this.pendenciasDoOrgao(g.mandato.orgao.id).length === 0;
  }

  estadoConselho(g: Governanca): 'COMPLETO' | 'SO_OBRIGATORIOS' | 'OBRIGATORIO_PENDENTE' | null {
    return this.pendenciasGovernanca?.conselhos?.find((c) => c.idOrgao === g.mandato.orgao.id)?.estadoPreenchimento ?? null;
  }

  orgaoNaoPossuido(g: Governanca): boolean {
    return g.mandato.orgao.obrigatorio === false && !this.orgaoOpcional[g.mandato.orgao.id];
  }

  conselhoNaoSalvo(g: Governanca): boolean {
    return this.orgaosAlterados.has(g.mandato.orgao.id);
  }

  chipConselhoClasse(g: Governanca): string {
    if (this.conselhoNaoSalvo(g)) {
      return 'gov-chip--warn';
    }
    if (this.orgaoNaoPossuido(g)) {
      return 'gov-chip--off';
    }
    switch (this.estadoConselho(g)) {
      case 'OBRIGATORIO_PENDENTE':
        return 'gov-chip--pendente';
      case 'SO_OBRIGATORIOS':
        return 'gov-chip--ok';
      case 'COMPLETO':
        return 'gov-chip--ok';
      default:
        return this.chipConselhoOk(g) ? 'gov-chip--ok' : 'gov-chip--warn';
    }
  }

  chipConselhoTexto(g: Governanca): string {
    if (this.conselhoNaoSalvo(g)) {
      return 'Não salvo';
    }
    if (this.orgaoNaoPossuido(g)) {
      return 'Não possui';
    }
    const pendencias = this.pendenciasDoOrgao(g.mandato.orgao.id).length;
    if (pendencias > 0) {
      return `${pendencias} pendência(s)`;
    }
    return this.estadoConselho(g) === 'SO_OBRIGATORIOS' ? 'Informações facultativas não preenchidas' : '✓ Completo';
  }

  rodapeConselho(g: Governanca): string {
    const total = (this.governancaExibida(g).mandato.listaMandatoMembro ?? []).length;
    const exibidos = this.membrosVisiveis(g).length;
    return `${exibidos} de ${total} linha(s) exibida(s)`;
  }

  // ---- Rodapé da aba (submissão agregada — FR-026/FR-030/INV-12) ----

  get totalPendenciasAba(): number {
    const porConselho = this.pendenciasGovernanca?.conselhos?.reduce((total, c) => total + (c.pendencias?.length ?? 0), 0) ?? 0;
    return porConselho + this.pendenciasGerais.length;
  }

  get resumoRodape(): { ok: boolean; titulo: string; subtitulo: string } {
    if (this.algumaEdicaoAtiva()) {
      return {
        ok: false,
        titulo: 'Conselho em edição',
        subtitulo: 'Salve ou cancele o conselho em edição para avançar.',
      };
    }
    if (this.houveAlteracaoForm) {
      return {
        ok: false,
        titulo: 'Alterações não salvas',
        subtitulo: 'Salve os conselhos alterados antes de avançar.',
      };
    }
    if (this.pendenciasGovernanca?.podeAvancar) {
      const facultativos = this.pendenciasGovernanca?.estadoPreenchimento === 'SO_OBRIGATORIOS';
      return {
        ok: true,
        titulo: 'Tudo certo para submeter',
        subtitulo: facultativos
          ? 'Há informações facultativas não preenchidas (data de nascimento e escolaridade dos membros) — elas não impedem o envio.'
          : 'Cada conselho já foi salvo separadamente. Avançar não reenvia a aba.',
      };
    }
    return {
      ok: false,
      titulo: `${this.totalPendenciasAba || 'Há'} pendência(s) em aberto`,
      subtitulo: 'Resolva as pendências dos conselhos para liberar o envio.',
    };
  }

  podeConcluir(): boolean {
    return this.podeModificarOsCampos && !!this.pendenciasGovernanca?.podeAvancar && !this.algumaEdicaoAtiva() && !this.houveAlteracaoForm;
  }

  /** compareWith dos selects/dropdowns que casam objetos clonados por id. */
  compararPorId(a: { id?: number } | null, b: { id?: number } | null): boolean {
    return a?.id === b?.id;
  }

  /** CPF formatado para exibição na tabela compacta (000.000.000-00). */
  formatarCpf(cpf: string | null | undefined): string {
    const digitos = (cpf ?? '').replace(/\D/g, '');
    if (digitos.length !== 11) {
      return cpf || '—';
    }
    return `${digitos.slice(0, 3)}.${digitos.slice(3, 6)}.${digitos.slice(6, 9)}-${digitos.slice(9)}`;
  }
}
