import { Component, OnInit, Output, EventEmitter, Input, ViewChild, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { Cargo } from '@cadastro-registro-api/models/Cargo';
import { Governanca } from '@cadastro-registro-api/models/Governanca';
import { Mandato } from '@cadastro-registro-api/models/Mandato';
import { Genero } from '@gerencia-usuario-api/models/Genero';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';
import { DataUtils } from '@shared/utils/DataUtils';
import { SelectItem, ConfirmationService } from 'primeng/api';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { ApiManutencaoGovernancaService } from '../service/api-manutencao-governanca.service';
import { PermissaoCooperativa } from 'src/app/features/cooperativa/permissao/permissao.service';
import { TrilhaAcoesGovernancaComponent} from '../../../governanca-shared/trilha-acoes/trilha-acoes-governanca.component';

@Component({
  selector: 'app-historico-governanca',
  templateUrl: './historico-governanca.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: [
    './historico-governanca.component.css',
    '../../../governanca-shared/governanca-shared.component.css',
  ],
})
export class HistoricoGovernancaComponent implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  @Input() optionsCargo: Cargo[][] = [];
  @Input() existeVigente: boolean;
  @Output() fecharDialogVisualizarHistorico = new EventEmitter<string>();
  @Output() evtTornarVigente = new EventEmitter<string>();
  @ViewChild('trilhaAcoes') trilhaAcoes: TrilhaAcoesGovernancaComponent;
  cols: { field: string, header: string }[];
  colsContratacao: { field: string, header: string }[];
  listGenero: SelectItem[];
  governancaArray: Governanca[] = [];
  dataUtils = new DataUtils();
  podeModificarOsCampos = false;
  /** Cartões expandidos por mandato — períodos COM membros abrem já expandidos. */
  expandidoPorMandato: { [idMandato: number]: boolean } = {};

  constructor(
    private apiManutencaoGovernanca: ApiManutencaoGovernancaService,
    private confirmationService: ConfirmationService,
    public language: LanguageService,
    private permissaoCooperativa: PermissaoCooperativa
  ) { }

  ngOnInit() {
      this.podeModificarOsCampos = this.permissaoCooperativa.permissaoAtualizarCadastro();
      this.cols = [
        { field: 'cpf', header: 'CPF' },
        { field: 'nome', header: 'Nome' },
        { field: 'genero', header: 'Sexo' },
        { field: 'cargo', header: 'Cargo' },
        { field: 'inicioMandato', header: 'Data de início' },
        { field: 'membroAtivo', header: 'Status' },
        { field: 'fimMandato', header: 'Desligamento' },
        { field: 'responsavelLegal', header: 'Representante legal' }
    ];
    this.colsContratacao = [
      { field: 'cpf', header: 'CPF' },
      { field: 'nome', header: 'Nome' },
      { field: 'genero', header: 'Sexo' },
      { field: 'cargo', header: 'Cargo' },
      { field: 'inicioMandato', header: 'Data de início' },
      { field: 'membroAtivo', header: 'Status' },
      { field: 'fimMandato', header: 'Data de término' },
      { field: 'responsavelLegal', header: 'Representante legal' }
    ];
  }

  fecharVisualizar() {
    this.fecharDialogVisualizarHistorico.emit();
  }

  consultaHistorico(idCooperativa: number, idOrgao: number){
    this.getHistorico(idCooperativa, idOrgao)
    .then(responsePage => {
      this.governancaArray = responsePage.data;
      this.expandidoPorMandato = {};
      for(const governanca of this.governancaArray){
        governanca.mandato.dataAssembleia = new Date(governanca.mandato.dataAssembleia);
        governanca.mandato.dataAssembleia.setHours( governanca.mandato.dataAssembleia.getHours() + 24 );
        if(governanca.mandato.fimMandato) {
          governanca.mandato.fimMandato = new Date(governanca.mandato.fimMandato);
          governanca.mandato.fimMandato.setHours( governanca.mandato.fimMandato.getHours() + 24 );
        }
        for(const membro of governanca.mandato.listaMandatoMembro){
          membro.inicioMandato = new Date(membro.inicioMandato);
          membro.inicioMandato = this.dataUtils.carregaDataUTC(membro.inicioMandato);
          if(membro.fimMandato) {
            membro.fimMandato = new Date(membro.fimMandato);
            membro.fimMandato = this.dataUtils.carregaDataUTC(membro.fimMandato);
          }
        }
        // Períodos com membros abrem já expandidos (pedido 2026-07-06).
        this.expandidoPorMandato[governanca.mandato.id] =
          (governanca.mandato.listaMandatoMembro?.length ?? 0) > 0;
      }
      this.carregaOptionsGenero();
      this.changeDetectorRef.markForCheck();
      return this.governancaArray;
    });
  }

  estaExpandido(g: Governanca): boolean {
    return !!this.expandidoPorMandato[g.mandato.id];
  }

  alternarExpansao(g: Governanca): void {
    this.expandidoPorMandato[g.mandato.id] = !this.expandidoPorMandato[g.mandato.id];
  }

  contadorMembros(g: Governanca): string {
    const lista = g.mandato.listaMandatoMembro ?? [];
    const ativos = lista.filter((m) => m.membroAtivo).length;
    const desligados = lista.length - ativos;
    if (!lista.length) {
      return 'Sem membros registrados';
    }
    return `${ativos} membro(s) ativo(s)` + (desligados ? ` · ${desligados} desligado(s)` : '');
  }

  periodoTexto(g: Governanca): string {
    const partes: string[] = [];
    if (g.mandato.anosDuracao) {
      partes.push(`Mandato ${g.mandato.anosDuracao} ano(s)`);
    }
    return partes.join(' · ');
  }

  /** Linha 1 (resumo) da descrição multilinha da última ação da trilha. */
  resumoAcao(descricao: string | null | undefined): string {
    return descricao?.split('\n')[0] ?? '';
  }

  /** Abre o dialog da trilha completa de ações do conselho (Nacional-only). */
  abrirTrilha(g: Governanca) {
    if (g?.mandato?.cooperativa && g?.mandato?.orgao) {
      this.trilhaAcoes.abrir(g.mandato.cooperativa.id, g.mandato.orgao.id, g.mandato.orgao.nome);
    }
  }

  generoLabel(genero: string | null | undefined): string {
    return this.listGenero?.find((item) => item.value === genero)?.label ?? (genero || '—');
  }

  nomeCargo(membro: { cargo?: { nome?: string } | null }): string {
    return membro?.cargo?.nome || '—';
  }

  /** CPF formatado para exibição (000.000.000-00). */
  formatarCpf(cpf: string | null | undefined): string {
    const digitos = (cpf ?? '').replace(/\D/g, '');
    if (digitos.length !== 11) {
      return cpf || '—';
    }
    return `${digitos.slice(0, 3)}.${digitos.slice(3, 6)}.${digitos.slice(6, 9)}-${digitos.slice(9)}`;
  }

  getOptionsDropDownCargo(i: number) {
    return this.optionsCargo[i];
  }

  tornarVigente(mandato: Mandato)  {
    // Confirmação no p-confirmDialog "govConfirm" (declarado no
    // governanca-shared, que hospeda este componente), com botão "Cancelar"
    // explícito. O ConfirmationService é o singleton do app, então a chave
    // alcança o dialog do componente pai.
    this.confirmationService.confirm({
      key: 'govConfirm',
      message: 'Esta ação vai tornar este mandato vigente novamente. Deseja continuar?',
      accept: () => {
        this.apiManutencaoGovernanca.tornarVigente(mandato.cooperativa.id, mandato.id)
        .then(() => {
          this.consultaHistorico(mandato.cooperativa.id, mandato.orgao.id);
          this.evtTornarVigente.emit();
          this.fecharVisualizar();
          this.changeDetectorRef.markForCheck();
        });
      }
    });

  }

  carregaOptionsGenero(){
    const key = Object.keys(Genero);
    const value = Object.values(Genero);
    this.listGenero = key.map((x, i) => ({ label: value[i], value: x }));
  }
  getHistorico(idCooperativa: number, idOrgao: number): Promise<IServiceResponse<Governanca[]>> {
    return this.apiManutencaoGovernanca.consultaHistorico(idCooperativa, idOrgao);
  }
}
