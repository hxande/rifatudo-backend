import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemProcessoRegistroComponent } from './listagem-processo-registro.component';

describe('ListagemProcessoRegistroComponent', () => {
  let component: ListagemProcessoRegistroComponent;
  let fixture: ComponentFixture<ListagemProcessoRegistroComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemProcessoRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemProcessoRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
