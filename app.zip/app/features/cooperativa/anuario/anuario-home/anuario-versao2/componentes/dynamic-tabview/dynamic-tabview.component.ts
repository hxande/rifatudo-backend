import { AfterViewChecked, ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FieldChangedEvent, flattenFields, TabDataInterface, TabInterface } from '../../types/tabs.interface';
import { AbstractControl, FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { PortifolioComponent } from 'src/app/features/registro/registro/portifolio/portifolio-component';
import { AjudaDinamicaComponent } from '../../../abas-ajuda/ajuda-dinamica/ajuda-dinamica.component';
import { TabViewChangeEvent } from 'primeng/tabview';
const TAB_PORTFOLIO = 'tab-portfolio';
const TAB_COMPLEMENTAR = 'tab-dados-complementares';
const TAB_DADOS_COMPLEMENTARES = 'tab-dados-complementares';
const PENDENCIA_FORM = 'pendencia-form';
@Component({
  selector: 'app-dynamic-tabview',
  templateUrl: './dynamic-tabview.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./dynamic-tabview.component.css'],
})
export class DynamicTabviewComponent implements OnInit, AfterViewChecked {
  @ViewChild(AjudaDinamicaComponent) ajudaComponent: AjudaDinamicaComponent;
  @Input() tabs: TabInterface[];
  @Input() formGroup: FormGroup;
  @Input() cooperativa: Cooperativa;

  @Output() ajudaSidebarDadosSociaisChange = new EventEmitter<boolean>();
  private _mostrarBotaoAjuda: boolean = false;
  @Input() set mostrarBotaoAjuda(value: boolean) {
    this._mostrarBotaoAjuda = value;
  }
  @Input() arrayHelper = [];
  get mostrarBotaoAjuda() {
    return this._mostrarBotaoAjuda;
  }

  private _ajudaSidebarDadosSociais: boolean = false;
  @Input() set ajudaSidebarDadosSociais(value: boolean) {
    this._ajudaSidebarDadosSociais = value;
  }
  get ajudaSidebarDadosSociais() {
    return this._ajudaSidebarDadosSociais;
  }
  @ViewChild('portifolioComponent') portifolioComponent: PortifolioComponent;

  @Input() ajudaSidebarVisivel = false;
  @Input() estruturas: unknown[];
  @Input() grupoAberto = 0;
  @Input() estruturaAberta = 0;

  @Output() listaMudou = new EventEmitter<number>();
  @Output() fieldChanged = new EventEmitter<FieldChangedEvent>();
  @Output() tabChange = new EventEmitter<{ from: number; to: number }>();
  @Output() activeIndexChange = new EventEmitter<number>();
  @Output() tabClick = new EventEmitter<{ from: number; to: number }>();
  @Output() portfolioAlterado = new EventEmitter<boolean>();
  @Output() linkClicado = new EventEmitter<boolean>();

  @Input() activeIndex = 0;

  abaStatusMap: { [key: string]: boolean } = {};
  totalSegmentosPortfolio: number = 0;
  segmentosCompletosPortfolio: number = 0;
  listaSegmentoSelecionado: unknown[] = [];
  alterouPorfilio: boolean = false;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.listaSegmentoSelecionado.length;
    this.tabs.forEach((tab) => {
      const controlName = tab.id;
      if (!this.formGroup.controls[controlName]) {
        this.formGroup.addControl(controlName, this.fb.group({}));
      }
    });
  }

  iniciaPortifolio() {
    this.portifolioComponent.init();
  }

  ngAfterViewChecked(): void {
    const tabAtiva = this.tabs[this.activeIndex];
    if (this.isPortfolioTab(tabAtiva) && this.portifolioComponent) {
      // A aba de portfólio reaproveita o slot content.data para guardar a lista de
      // PessoaSegmProdServ (não o formato padrão TabDataInterface[] das demais abas).
      tabAtiva.content.data = this.portifolioComponent.listaPessoaSegmProdSevNova as unknown as TabDataInterface[];
    }
  }
  private hasValor(c: AbstractControl): boolean {
    const v = c.value;
    if (v === null || v === undefined) return false;
    if (typeof v === 'string') return v.trim().length > 0;
    if (Array.isArray(v)) return v.length > 0;
    return true;
  }

  isPortfolioTab(tab: TabInterface): boolean {
    return tab?.id === TAB_PORTFOLIO;
  }

  isComplementaryTab(tab: TabInterface): boolean {
    return tab?.id === TAB_COMPLEMENTAR;
  }

  isStandardTab(tab: TabInterface): boolean {
    return !this.isPortfolioTab(tab) && !this.isComplementaryTab(tab);
  }

  shouldShowProgress(tab: TabInterface): boolean {
    // if (this.isPortfolioTab(tab)) {
    //   return !!this.totalSegmentosPortfolio;
    // }
    return !this.isComplementaryTab(tab);
  }

  getProgressTotal(tab: TabInterface): number {
    if (this.isPortfolioTab(tab)) {
      return 1;
    }
    return tab?.content?.data?.length || 0;
  }

  getProgressValid(tab: TabInterface, index: number): number {
    if (this.isPortfolioTab(tab)) {
      return this.totalSegmentosPortfolio > 0 ? 1 : 0;
    }
    return this.activeIndex === index ? this.getValidAccordionCountForActiveTab() : 0;
  }

  handleTabClick(toIndex: number, event: MouseEvent, tab?: TabInterface) {
    event.preventDefault();
    event.stopPropagation();
    if (this.isPortfolioTab(tab)) {
      this.calcularProgressoPortfolio();
    }

    this.tabClick.emit({ from: this.activeIndex, to: toIndex });
  }

  getMudancaPortfolio(event: unknown): void {
    const tab = this.tabs[this.activeIndex];
    if (this.isPortfolioTab(tab)) {
      this.calcularProgressoPortfolio();
      this.portfolioAlterado.emit(true);
      this.alterouPorfilio = true;
    }

    this.listaMudou.emit(this.totalSegmentosPortfolio);
  }

  onPortifolioListSizeChange(): void {
    this.calcularProgressoPortfolio();
  }

  calcularProgressoPortfolio(): void {
    const statusSegmentosMap = this.verificarStatusSegmentosPortfolio();
    this.totalSegmentosPortfolio = this.portifolioComponent.listaProdutoServico.size;
    this.segmentosCompletosPortfolio = Array.from(statusSegmentosMap.values()).filter(Boolean).length;

    const tab = this.tabs[this.activeIndex];

    if (this.isPortfolioTab(tab)) {
      // tab.temPendencia = this.totalSegmentosPortfolio > 0 && this.totalSegmentosPortfolio !== this.segmentosCompletosPortfolio;
    }
  }

  verificarStatusSegmentosPortfolio(): Map<string, boolean> {
    const statusSegmentos = new Map<string, boolean>();
    this.portifolioComponent.listaProdutoServico.forEach((valores, segmentoKey) => {
      const isCompleto = this.portifolioComponent.listaProdutoServicoSelecionado.some((itemSelecionado) => {
        return itemSelecionado.segmento && itemSelecionado.segmento.id === segmentoKey.id;
      });
      statusSegmentos.set(segmentoKey.nome, isCompleto);
    });

    return statusSegmentos;
  }

  onFieldChanged(event: FieldChangedEvent) {
    this.tabs.forEach((tab) => {
      if (this.isStandardTab(tab)) {
        // tab.temPendencia = !this.isTabComplete(tab);
      }
    });
    this.fieldChanged.emit(event);
  }

  popularMapaStatusAbas(dados: unknown[]) {
    this.abaStatusMap = {};
    dados.forEach((item) => {
      // this.abaStatusMap[item.abaNome.toLowerCase()] = !item.temPendencia;
    });
  }

  getTabStatus(tab: TabInterface): boolean {
    const safeName = tab.id;
    let dynamicStatus: boolean;

    if (this.isStandardTab(tab)) {
      dynamicStatus = this.isTabComplete(tab) || !tab.temPendencia;
    } else if (this.isPortfolioTab(tab)) {
      dynamicStatus = (this.totalSegmentosPortfolio > 0 && this.totalSegmentosPortfolio === this.segmentosCompletosPortfolio) || !tab.temPendencia;
    } else if (this.isComplementaryTab(tab)) {
      dynamicStatus = !tab.temPendencia;
    }

    const initialStatus = this.abaStatusMap[safeName];

    if (tab.temPendencia && !this.isTabComplete(tab)) {
      dynamicStatus = false;
    }

    return typeof dynamicStatus === 'boolean' ? dynamicStatus : (initialStatus ?? false);
  }
  getTabTooltip(status: string): string {
    switch (status) {
      case 'completo':
        return 'Completo';
      case 'incompleto-vazio':
        return 'Itens não preenchidos';
      case 'incompleto-invalid':
        return 'Incompleto';
      default:
        break;
    }
    return status === 'completo' ? 'Completo' : 'Incompleto';
  }
  getTabStatusPendencia(tab: TabInterface): 'completo' | 'incompleto-invalid' | 'incompleto-vazio' {
    let dynamicStatus: boolean;
    return this.getSituacaoPendencia(tab.situacao);
  }

  getTabFormGroup(id: string): FormGroup {
    return this.formGroup.get(id) as FormGroup;
  }

  setSituacaoPendenciaTab(tab: TabInterface, status: string) {
    switch (status) {
      case 'completo':
        tab.situacao = 1;
        break;
      case 'incompleto-invalid':
        tab.situacao = -1;
        break;
      case 'incompleto-vazio':
        tab.situacao = 0;
        break;
      default:
        break;
    }
  }

  getSituacaoPendencia(situacao: number): 'completo' | 'incompleto-invalid' | 'incompleto-vazio' {
    switch (situacao) {
      case 1:
        return 'completo';
      case -1:
        return 'incompleto-invalid';
      case 0:
        return 'incompleto-vazio';
      default:
        return 'incompleto-invalid';
    }
  }
  onTabChange(event: TabViewChangeEvent) {
    this.activeIndexChange.emit(event.index);
  }

  getFormGroup() {}

  getTabProgressValidCount(tab: TabInterface, tabIndex: number): number {
    if (tab.id === 'tab-portfolio') {
      return this.segmentosCompletosPortfolio;
    }

    if (this.activeIndex === tabIndex) {
      return this.getValidAccordionCountForActiveTab();
    }

    return 0;
  }

  private allPropsHaveValue(obj: Record<string, unknown>): boolean {
    const values = Object.values(obj ?? {});
    return values.length > 0 && values.every((v) => v !== null && v !== undefined && v !== '');
  }

  private isAccordionControlComplete(ctrl: AbstractControl | null): boolean {
    if (!ctrl) return false;

    if (ctrl instanceof FormArray) {
      if (ctrl.length === 0) return false;

      return ctrl.controls.every((rowCtrl) => {
        if (!(rowCtrl instanceof FormGroup)) {
          const v = rowCtrl.value;
          return rowCtrl.disabled || (v !== null && v !== undefined && v !== '');
        }

        const obj = rowCtrl.value ?? {};
        const values = Object.values(obj) as unknown[];

        const todosComValor = this.allPropsHaveValue(rowCtrl.value);
        return rowCtrl.disabled || todosComValor;
      });
    }
  }

  getValidAccordionCount(tab: TabInterface): number {
    const tabGroup = this.getTabFormGroup(tab.id);
    if (!tabGroup) return 0;

    return Object.keys(tabGroup.controls).reduce((count, key) => {
      const control = tabGroup.get(key);
      return this.isAccordionControlComplete(control) ? count + 1 : count;
    }, 0);
  }

private hasPendenciaByPanel(tab: TabInterface, panelId: string): boolean | null {
  const panel = tab.content.data?.find(p => p.id === panelId);
  if (!panel) return null;

  const pendFields = flattenFields(panel.fields).filter(f => f?.id === PENDENCIA_FORM);
  if (pendFields.length === 0) return null;
  return pendFields.some(f => f.value !== null && f.value !== undefined && f.value !== '');
}

 getValidAccordionCountForActiveTab(): number {
  if (this.activeIndex < 0 || this.activeIndex >= this.tabs.length) return 0;

  const activeTab = this.tabs[this.activeIndex];
  const tabGroup = this.getTabFormGroup(activeTab.id);
  if (!tabGroup) return 0;

  return (activeTab.content.data ?? []).reduce((count, panel) => {
    const panelId = panel.id;

    const pendencia = this.hasPendenciaByPanel(activeTab, panelId);
    if (pendencia !== null) {
      return pendencia ? count : count + 1;
    }

    const control = tabGroup.get(panelId);
    return this.isAccordionControlCompleteByForm(control) ? count + 1 : count;
  }, 0);
}
private isAccordionControlCompleteByForm(ctrl: AbstractControl | null): boolean {
  if (!ctrl) return false;

  if (ctrl.disabled) return true;

  if (ctrl instanceof FormArray) {
    if (ctrl.length === 0) return false;
    return ctrl.controls.every(c => {
      if (!(c instanceof FormGroup)) {
        return c.disabled || this.hasValor(c);
      }
      return Object.values((c as FormGroup).controls).every(
        field => field.disabled || this.hasValor(field)
      );
    });
  }

  return this.hasValor(ctrl);
}

  isTabComplete(tab: TabInterface): boolean {
    const tabGroup = this.getTabFormGroup(tab.id);
    if (!tabGroup) return false;

    const keys = Object.keys(tabGroup.controls);
    if (keys.length === 0) return false;
    return keys.every((key) => this.isAccordionControlComplete(tabGroup.get(key)));
  }
  getComplementoTexto(tab: TabInterface): string {
    const primeiroCampo = flattenFields(tab?.content?.data?.[0]?.fields)[0];
    return primeiroCampo?.label || '';
  }

  getComplementoUrl(tab: TabInterface): string {
    const primeiroCampo = flattenFields(tab?.content?.data?.[0]?.fields)[0];
    return (primeiroCampo?.value as string) || '';
  }

  getTabByIndex(index: number): TabInterface {
    return this.tabs[index];
  }

  salvarStatusAba(tab: TabInterface, event: boolean) {
    tab.tabPreenchida = event;
    tab.situacao = 1;
    tab.temPendencia = false;
    this.linkClicado.emit(true);
  }

  onSidebarHide() {
    if (this.ajudaComponent) {
      this.ajudaComponent.fecharTodos();
    }
  }
}
