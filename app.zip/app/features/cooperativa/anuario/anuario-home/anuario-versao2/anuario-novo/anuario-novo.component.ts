import { ChangeDetectionStrategy, ChangeDetectorRef, Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { firstValueFrom, map, Observable, switchMap, tap } from 'rxjs';
import { ApiCooperativaService } from '@cadastro-registro-api/services/api-cooperativa.service';
import { CensoAnuario } from '@cadastro-registro-api/models/CensoAnuario';
import { BreadcrumbService } from '@core/breadcrumb/breadcrumb.service';
import { SituacaoEnum } from '@cadastro-registro-api/models/SituacaoEnum';
import { ControleAnuarioUFTO } from 'src/app/api/models/ControleAnurioUFTO';
import { CooperativaAnuarioAbaTO } from 'src/app/api/models/CooperativaAnuarioAbaTO';
import { ApiCooperativaAnuarioAbasService } from 'src/app/api/services/api-cooperativa-anuario-abas.service';
import { AnuarioDynamic } from '../types/anuario-dynamic';
import { AnuarioQuadroSocialService } from 'src/app/api/services/api-anuario-quadro-social.service';
import { TipoAba } from '../types/tipo-aba';
import { ConfirmationService, MenuItem, MessageService } from 'primeng/api';
import { ApiCensoAnuarioService } from '@cadastro-registro-api/services/api-censo-anuario.service';
import { FieldChangedEvent, flattenFields, TabDataInterface, TabField, TabInterface } from '../types/tabs.interface';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
const TAB_PORTFOLIO = 'tab-portfolio';

@Component({
  selector: 'app-anuario-novo',
  templateUrl: './anuario-novo.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./anuario-novo.component.css'],
})
export class AnuarioNovoComponent extends AnuarioDynamic implements OnInit {

  private readonly changeDetectorRef = inject(ChangeDetectorRef);

  cooperativa!: Cooperativa;
  ano = new Date().getFullYear() - 1;
  salvarAbaDialog = false;
  mostrarBotaoAjuda = false;
  ajudaSidebarDadosSociais = false;
  private hasChanges = false;
  pendingIndex: number | null = null;
  censoAnuario!: CensoAnuario;
  anuarioAtualizado = false;
  arrayHelper: { title: string; subtitle: string }[] = [];
  constructor(
    private fb: FormBuilder,
    private apiAnuarioQuadroSocialService: AnuarioQuadroSocialService,
    private cooperativaService: ApiCooperativaService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiCooperativaAnuarioAbasService: ApiCooperativaAnuarioAbasService,
    public keycloakService: KeycloakService,
    private breadCrumbPrimeNGService: BreadcrumbService,
    private route: ActivatedRoute,
    private router: Router,
    messageService: MessageService,
    private confirmationService: ConfirmationService,
    private apiCensoAnuarioService: ApiCensoAnuarioService,
  ) {
    super(fb, messageService);
  }
  ngOnInit(): void {
    this.init();
  }

  async init() {
    await this.getDadosCooperativa();
    await this.carregarCooperativaAnuarioAbas();
    await this.buildBreadCrumb(this.cooperativa.id, false);
    await this.carregarDadosAbaAtiva(this.getIndiceTabAtiva());
    await this.carregarCensoAnuario();
  }

  async getDadosCooperativa() {
    const resposta = this.route.params.pipe(
      switchMap((params) => {
        if (params['id']) {
          return this.cooperativaService.get(params['id'])
          .then((response) => {
            this.changeDetectorRef.markForCheck();
            return { data: response.data, idExists: true };
          });
        } else {
          return this.apiCadastroRegistroService
            .getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado)
            .then((cooperativa) => {
              this.changeDetectorRef.markForCheck();
              return { data: cooperativa, idExists: false };
            });
        }
      }),
      map(({ data, idExists }) => data)
    );

    this.cooperativa = await firstValueFrom(resposta);
  }

  async carregarCooperativaAnuarioAbas() {
    this.tabs = (await firstValueFrom(this.apiCooperativaAnuarioAbasService.obterCooperativaAnuarioAbasV2(this.cooperativa.id, this.ano))).data;
  }

  protected async carregarDadosAbaAtiva(indexAbaAtiva: Number): Promise<void> {
    switch (indexAbaAtiva) {
      case TipoAba.DADOS_SOCIAIS.index: {
        const dados = await firstValueFrom(this.apiAnuarioQuadroSocialService.obterQuadroSocialAnuarioV2(this.cooperativa.id, this.ano));
        this.arrayHelper = [];
        this.mostrarBotaoAjuda = true;
        this.ajudaSidebarDadosSociais = false;
        await this.criarFormularioAba(dados);
        break;
      }

      case TipoAba.PORTFOLIO.index: {
        this.mostrarBotaoAjuda = false;
        this.arrayHelper = [];
        this.ajudaSidebarDadosSociais = false;
        break;
      }

      case TipoAba.CONTABIL_TRIBUTARIO.index: {
        const dados = (await firstValueFrom(this.apiCooperativaAnuarioAbasService.obterDadosContabilTributarioV2(this.cooperativa.id, this.ano))).data;
        this.arrayHelper = [];
        this.arrayHelper = this.extrairSubtitles(dados);
        this.mostrarBotaoAjuda = false;
        this.ajudaSidebarDadosSociais = false;
        await this.criarFormularioAba(dados);
        break;
      }

      case TipoAba.NEGOCIO.index: {
        const dados = (await firstValueFrom(this.apiCooperativaAnuarioAbasService.obterDadosNegociosV2(this.cooperativa.id, this.ano))).data;
        this.arrayHelper = [];
        this.arrayHelper = this.extrairSubtitles(dados);
        this.mostrarBotaoAjuda = false;
        this.ajudaSidebarDadosSociais = false;
        await this.criarFormularioAba(dados);
        break;
      }

      case TipoAba.DADOS_COMPLEMENTARES.index: {
        const dados = (await firstValueFrom(this.apiCooperativaAnuarioAbasService.obterDadosComplementaresV2(this.cooperativa.id, this.ano))).data;
        this.arrayHelper = [];
        this.arrayHelper = this.extrairSubtitles(dados);
        this.mostrarBotaoAjuda = false;
        this.ajudaSidebarDadosSociais = false;
        await this.criarFormularioAba(dados);
        break;
      }

      default: {
        this.arrayHelper = [];
        this.mostrarBotaoAjuda = false;
        this.ajudaSidebarDadosSociais = false;
        break;
      }
    }
    this.changeDetectorRef.markForCheck();
  }

  private extrairSubtitles(dados: TabDataInterface[]): { title: string; subtitle: string }[] {
    return (dados ?? []).reduce((acc: { title: string; subtitle: string }[], grupo: TabDataInterface) =>
      acc.concat(
        flattenFields(grupo?.fields)
          .filter((field) => field?.subTitle && field?.label)
          .map((field) => ({
            title: field.label ?? '',
            subtitle: field.subTitle ?? ''
          }))
      ), []
    );
  }

  protected onSubmit(waitForComplete: boolean = false): Observable<IServiceResponse<void>> | void {
    let observable: Observable<IServiceResponse<void>>;
    switch (this.activeIndex) {
      case TipoAba.DADOS_SOCIAIS.index:
        observable = this.salvarDadosSocial(waitForComplete);
        break;
      case TipoAba.PORTFOLIO.index:
        observable = this.salvarPortifolio(waitForComplete);
        break;
      case TipoAba.CONTABIL_TRIBUTARIO.index:
        observable = this.salvarContabilTributario(waitForComplete);
        break;
      case TipoAba.NEGOCIO.index:
        observable = this.salvarNegocio(waitForComplete);
        break;
      case TipoAba.DADOS_COMPLEMENTARES.index:
        observable = this.salvarDadosComplementares(waitForComplete);
        break;
      default:
        return;
    }
    this.hasChanges = false;
    if (waitForComplete) {
      return observable;
    } else {
      observable.subscribe();
      return;
    }
  }


  salvarDadosSocial(isSubmit: boolean = false): Observable<IServiceResponse<void>> {
    this.atualizarStatusAba();
    const payload = this.gerarPayload();
    return this.apiAnuarioQuadroSocialService.salvarQuadroSocialAnuarioV2(this.cooperativa.id, this.ano, payload, isSubmit).pipe(tap(() => {}));
  }

  salvarPortifolio(isSubmit: boolean = false): Observable<IServiceResponse<void>> {
    const tab = this.tabs[this.activeIndex];
    const payload = tab.content?.data ?? [];
    payload.length == 0 ? this.setSituacaoPendenciaTab(tab, 'incompleto-invalid') : this.setSituacaoPendenciaTab(tab, 'completo');
    const payloadSituacao = {
      fields: payload,
      situacao: tab.situacao,
    };
    return this.apiAnuarioQuadroSocialService.salvarPortifolioAnuarioV2(this.cooperativa.id, this.ano, payloadSituacao, isSubmit).pipe(tap(() => {}));
  }

  salvarContabilTributario(isSubmit: boolean = false): Observable<IServiceResponse<void>> {
    this.atualizarStatusAba();
    const payload = this.gerarPayload();
    return this.apiAnuarioQuadroSocialService.salvarTributarioAnuarioV2(this.cooperativa.id, this.ano, payload, isSubmit).pipe(tap(() => {}));
  }

  salvarNegocio(isSubmit: boolean = false): Observable<IServiceResponse<void>> {
    this.atualizarStatusAba();
    const payload = this.gerarPayload();
    return this.apiAnuarioQuadroSocialService.salvarNegocioAnuarioV2(this.cooperativa.id, this.ano, payload, isSubmit).pipe(tap(() => {}));
  }


    salvarDadosComplementares(isSubmit: boolean = false): Observable<IServiceResponse<void>> {
    const payload = this.gerarPayload();
    payload.situacao = 1;
    return this.apiAnuarioQuadroSocialService.salvarDadosComplementaresAnuarioV2(this.cooperativa.id, this.ano, payload, isSubmit).pipe(tap(() => {}));
  }

  validadaCancelado(): boolean {
    return true;
  }



  salvarContinuar() {
    this.onSubmit();
    const posicao = this.tabs.indexOf(this.tabs[this.activeIndex + 1]);
    if (posicao !== -1) this.irParaAba(this.activeIndex + 1);
  }

  public podeExibirBotaoSubmeterAnuario(): boolean {
    return this.form.invalid || !this.isTodasAbasCompletas();
  }

  submeterAnuario(): void {
    if (this.form.invalid || !this.isTodasAbasCompletas()) {
      this.messageService?.add({
        severity: 'warn',
        detail: 'Os campos de preenchimento obrigatório não foram parametrizados. Favor entrar em contato com a Unidade Nacional do Sistema OCB.',
        life: 3000,
      });
      return;
    }

    const salvarObs = this.onSubmit(true) as Observable<IServiceResponse<void>>;
    salvarObs.subscribe({
      next: () => {
        const headerMessage = 'Confirmação da submissão do anuário';
        const message =
          'A veracidade dos dados aqui inseridos são de inteira responsabilidade de quem está preenchendo. O Sistema OCB assegura que nenhuma informação individual será divulgada no Anuário do Cooperativismo Brasileiro.';

        if (this.censoAnuario.id) {
          this.confirmationService.confirm({
            header: headerMessage,
            message: message,
            accept: () => {
              this.apiCensoAnuarioService.update(this.censoAnuario).subscribe((response) => {
                this.censoAnuario.id = response.data.id;
                if (response != null) {
                  if (response.data) {
                    this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: this.cooperativa.id } });
                  } else {
                    this.router.navigate(['/registro/manutencaoCadastro']);
                  }
                }
                this.changeDetectorRef.markForCheck();
              });
            },
          });
        } else {
          this.censoAnuario.ano = this.ano;
          this.censoAnuario.cooperativaId = this.cooperativa.id;
          this.confirmationService.confirm({
            header: headerMessage,
            message: message,
            accept: () => {
              this.apiCensoAnuarioService.create(this.censoAnuario).subscribe((response) => {
                this.censoAnuario.id = response.data.id;
                if (response != null) {
                  if (response.data) {
                    this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: this.cooperativa.id } });
                  } else {
                    this.router.navigate(['/registro/manutencaoCadastro']);
                  }
                }
                this.changeDetectorRef.markForCheck();
              });
            },
          });
        }
      },
    });
  }

  private carregarCensoAnuario(): void {
    this.apiCensoAnuarioService.getByAnoAndCooperativaId(this.ano, this.cooperativa.id)
    .subscribe((response) => {
      if (response.data) {
        this.censoAnuario = response.data;
      } else {
        this.censoAnuario = new CensoAnuario();
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  onFieldAlterado(event: FieldChangedEvent) {

    const fieldId = event.fieldId;
    const value = event.value;
    const formGroup = event.formGroup;
    switch (fieldId) {
      case 'cooperadosHomensUF':
      case 'cooperadosMulheresUF':
        this.sumFields(formGroup, 'cooperadosHomensUF', 'cooperadosMulheresUF', 'cooperadosPFUF');
        break;
      case 'cooperadosPFUF':
        this.sumFields(formGroup, 'cooperadosPFUF', 'cooperadosPJUF', 'cooperadosTotalUF');
        break;
      case 'cooperadosPJUF':
        this.sumFields(formGroup, 'cooperadosPFUF', 'cooperadosPJUF', 'cooperadosTotalUF');
        break;
      case 'empregadosHomensUF':
      case 'empregadosMulheresUF':
        this.sumFields(formGroup, 'empregadosHomensUF', 'empregadosMulheresUF', 'empregadosTotalUF');
        break;
      case 'realizaExportacao':
        const tabNegocio = this.tabs.find((tab) => tab.id === 'tab-negocio');
        const accordionNegocioExportacao = tabNegocio?.content?.data?.find((accordion) => accordion.id === 'negocioExportacao');
        (accordionNegocioExportacao?.fields?.[0] as TabField[] | undefined)?.map((field) => {
          if(value == '0' && field.id !== 'realizaExportacao'){
            field.visible = false;
            this.clearValueField(field);
            this.removeControl(formGroup, field.id);
          }else if(value == '1' && field.id !== 'realizaExportacao'){
            field.visible = true;
            const controlCreate = this.createControlsFromFields([field]);
            if(controlCreate.length > 0){
              this.addControl(formGroup,controlCreate[0].name, controlCreate[0].control);
            }
          }
          return field;
        });
        break;
    }
    this.hasChanges = true;
    this.changeDetectorRef.markForCheck();
  }

  portfolioAlterado(event: boolean) {
    this.hasChanges = true;
    this.changeDetectorRef.markForCheck();
  }

  async onTabChange(ev: { from: number; to: number }) {
    const to = ev.to;
    if (this.hasChanges) {
      this.pendingIndex = to;
      this.salvarAbaDialog = true;
    } else {
      await this.irParaAba(to);
    }

    this.changeDetectorRef.markForCheck();
  }

  private async irParaAba(index: number) {
    const posicao = this.tabs.indexOf(this.tabs[index]);
    if (posicao !== -1) this.activeIndex = index;
    await this.carregarDadosAbaAtiva(index);
  }

  cancelarSalvarAba() {
    this.salvarAbaDialog = false;
    this.pendingIndex = null;
    this.changeDetectorRef.markForCheck();
  }

  async naoSalvarAba() {
    const tab = this.tabs[this.activeIndex];
    const group = this.form.get(tab.id) as FormGroup | null;
    group?.markAsPristine();
    group?.markAsUntouched();
    this.hasChanges = false;

    const idx = this.pendingIndex;
    this.salvarAbaDialog = false;
    this.pendingIndex = null;

    if (idx != null) {
      let index = this.activeIndex;

      if (this.isPortfolioTab(tab)) await this.carregarCooperativaAnuarioAbas();
      else await this.carregarDadosAbaAtiva(index);
      this.irParaAba(idx);
    }
  }

  isPortfolioTab(tab: TabInterface): boolean {
    return tab?.id === TAB_PORTFOLIO;
  }

  async salvarAba() {
    this.onSubmit(); // salva
    this.hasChanges = false;

    const idx = this.pendingIndex;
    this.salvarAbaDialog = false;
    this.pendingIndex = null;

    if (idx != null) {
      await this.irParaAba(idx);
    }
  }

  private buildBreadCrumb(cooperativaId: number, showListagemRoute: boolean): void {
    const items = [
      { label: 'Início', routerLink: '/' },
      showListagemRoute ? { label: 'Cooperativas Registradas', routerLink: '/cooperativa/listagem' } : null,
      {
        label: 'Cooperativa',
        command: () => {
          this.router.navigate(['/cooperativa/detalhes'], { queryParams: { id_cooperativa: cooperativaId } });
        },
      },
      { label: 'Anuário do Cooperativismo', routerLink: '' },
    ].filter((item) => item !== null) as MenuItem[]; // Remove o item nulo se showListagemRoute for false

    this.breadCrumbPrimeNGService.setItems(items);
  }
}
