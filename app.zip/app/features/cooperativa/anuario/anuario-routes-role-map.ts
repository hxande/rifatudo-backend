export const anuarioRoutesRoleMaps = [
  {
    routes: [
      'cooperativa/anuario/:id'
    ],
    roles: ['CADASTRO_REGISTRO_NACIONAL', 'CADASTRO_REGISTRO_ESTADUAL'],
    types: ['N', 'E']
  }
];
