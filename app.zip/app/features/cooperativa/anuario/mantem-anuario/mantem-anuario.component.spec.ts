import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemAnuarioComponent } from './mantem-anuario.component';

describe('MantemAnuarioComponent', () => {
  let component: MantemAnuarioComponent;
  let fixture: ComponentFixture<MantemAnuarioComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemAnuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemAnuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
