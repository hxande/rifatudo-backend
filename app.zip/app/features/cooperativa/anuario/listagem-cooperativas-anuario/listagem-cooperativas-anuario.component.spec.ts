import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemCooperativasAnuarioComponent } from './listagem-cooperativas-anuario.component';

describe('ListagemCooperativasAnuarioComponent', () => {
  let component: ListagemCooperativasAnuarioComponent;
  let fixture: ComponentFixture<ListagemCooperativasAnuarioComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemCooperativasAnuarioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemCooperativasAnuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
