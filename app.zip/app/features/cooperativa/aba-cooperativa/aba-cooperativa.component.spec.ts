import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { AbaCooperativaComponent } from './aba-cooperativa.component';

describe('AbaCooperativaComponent', () => {
  let component: AbaCooperativaComponent;
  let fixture: ComponentFixture<AbaCooperativaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ AbaCooperativaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AbaCooperativaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
