import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatorioAnuarioComponent } from './relatorio-anuario.component';

describe('RelatorioAnuarioComponent', () => {
  let component: RelatorioAnuarioComponent;
  let fixture: ComponentFixture<RelatorioAnuarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RelatorioAnuarioComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RelatorioAnuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
