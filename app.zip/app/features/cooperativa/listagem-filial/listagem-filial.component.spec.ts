import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemFilialComponent } from './listagem-filial.component';

describe('ListagemFilialComponent', () => {
  let component: ListagemFilialComponent;
  let fixture: ComponentFixture<ListagemFilialComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemFilialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemFilialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
