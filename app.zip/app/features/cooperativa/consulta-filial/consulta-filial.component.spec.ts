import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultaFilialComponent } from './consulta-filial.component';

describe('ConsultaFilialComponent', () => {
  let component: ConsultaFilialComponent;
  let fixture: ComponentFixture<ConsultaFilialComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultaFilialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultaFilialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
