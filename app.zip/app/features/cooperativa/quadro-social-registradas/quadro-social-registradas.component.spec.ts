import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuadroSocialRegistradasComponent } from './quadro-social-registradas.component';

describe('QuadroSocialRegistradasComponent', () => {
  let component: QuadroSocialRegistradasComponent;
  let fixture: ComponentFixture<QuadroSocialRegistradasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuadroSocialRegistradasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuadroSocialRegistradasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
