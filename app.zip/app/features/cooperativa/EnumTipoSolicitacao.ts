export enum EnumTipoSolicitacao {
  INATIVACAO = 1,
  IRREGULARIZAR = 2,
  REGULARIZAR = 3,
  OUTROS = 4,
  SOLICITACAO_DE_INATIVACAO= 5,
}
