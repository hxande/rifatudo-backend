import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemCooperaitvaComponent } from './listagem-cooperaitva.component';

describe('ListagemCooperaitvaComponent', () => {
  let component: ListagemCooperaitvaComponent;
  let fixture: ComponentFixture<ListagemCooperaitvaComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemCooperaitvaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemCooperaitvaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
