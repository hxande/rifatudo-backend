import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from '@auth/auth-guard/auth-guard.service';
import { ExportacaoDadosComponent } from './exportacao-dados.component';

const routes: Routes = [
  { path: '', component: ExportacaoDadosComponent, canActivate:  [AuthGuardService]}
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class ExportacaoDadosRoutingModule { }