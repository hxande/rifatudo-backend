import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManterSolicitacaoComponent } from './mantem-solicitacao.component';

describe('ManterSolicitacaoComponent', () => {
  let component: ManterSolicitacaoComponent;
  let fixture: ComponentFixture<ManterSolicitacaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ManterSolicitacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManterSolicitacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
