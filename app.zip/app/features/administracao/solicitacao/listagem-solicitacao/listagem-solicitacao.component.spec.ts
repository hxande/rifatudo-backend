import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemSolicitacaoComponent } from './listagem-solicitacao.component';

describe('ListagemSolicitacaoComponent', () => {
  let component: ListagemSolicitacaoComponent;
  let fixture: ComponentFixture<ListagemSolicitacaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemSolicitacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemSolicitacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
