import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemUnidadeEstadualComponent } from './listagem-unidade-estadual.component';

describe('ListagemUnidadeEstadualComponent', () => {
  let component: ListagemUnidadeEstadualComponent;
  let fixture: ComponentFixture<ListagemUnidadeEstadualComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemUnidadeEstadualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemUnidadeEstadualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
