import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemUnidadeEstadualComponent } from './mantem-unidade-estadual.component';

describe('MantemUnidadeEstadualComponent', () => {
  let component: MantemUnidadeEstadualComponent;
  let fixture: ComponentFixture<MantemUnidadeEstadualComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemUnidadeEstadualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemUnidadeEstadualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
