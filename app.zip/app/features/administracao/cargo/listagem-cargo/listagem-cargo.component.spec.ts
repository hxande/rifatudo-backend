import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemCargoComponent } from './listagem-cargo.component';

describe('ListagemCargoComponent', () => {
  let component: ListagemCargoComponent;
  let fixture: ComponentFixture<ListagemCargoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemCargoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemCargoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
