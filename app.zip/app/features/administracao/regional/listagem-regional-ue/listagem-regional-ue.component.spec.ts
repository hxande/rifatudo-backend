import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListagemRegionalComponent } from '../listagem-regional/listagem-regional.component';


describe('ListagemRegionalComponent', () => {
  let component: ListagemRegionalComponent;
  let fixture: ComponentFixture<ListagemRegionalComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemRegionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemRegionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
