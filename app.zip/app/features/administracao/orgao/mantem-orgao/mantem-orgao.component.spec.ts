import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemOrgaoComponent } from './mantem-orgao.component';

describe('MantemOrgaoComponent', () => {
  let component: MantemOrgaoComponent;
  let fixture: ComponentFixture<MantemOrgaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemOrgaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemOrgaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
