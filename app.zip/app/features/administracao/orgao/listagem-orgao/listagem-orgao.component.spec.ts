import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemOrgaoComponent } from './listagem-orgao.component';

describe('ListagemOrgaoComponent', () => {
  let component: ListagemOrgaoComponent;
  let fixture: ComponentFixture<ListagemOrgaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemOrgaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemOrgaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
