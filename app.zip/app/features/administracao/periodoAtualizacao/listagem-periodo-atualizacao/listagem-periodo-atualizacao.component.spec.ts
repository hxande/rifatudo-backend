import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ListagemPeriodoAtualizacaoComponent } from './listagem-periodo-atualizacao.component';


describe('ListagemPeriodoAtualizacaoComponent', () => {
  let component: ListagemPeriodoAtualizacaoComponent;
  let fixture: ComponentFixture<ListagemPeriodoAtualizacaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemPeriodoAtualizacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemPeriodoAtualizacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
