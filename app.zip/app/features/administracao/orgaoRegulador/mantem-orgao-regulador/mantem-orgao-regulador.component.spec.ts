import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemOrgaoReguladorComponent } from './mantem-orgao-regulador.component';

describe('MantemOrgaoReguladorComponent', () => {
  let component: MantemOrgaoReguladorComponent;
  let fixture: ComponentFixture<MantemOrgaoReguladorComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemOrgaoReguladorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemOrgaoReguladorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
