import {ComponentFixture, TestBed} from '@angular/core/testing';

import {ManterParametroQuadroSocialComponent} from './manter-parametro-quadro-social.component';

describe('ManterParametroQuadroSocialComponent', () => {
  let component: ManterParametroQuadroSocialComponent;
  let fixture: ComponentFixture<ManterParametroQuadroSocialComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ManterParametroQuadroSocialComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManterParametroQuadroSocialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
