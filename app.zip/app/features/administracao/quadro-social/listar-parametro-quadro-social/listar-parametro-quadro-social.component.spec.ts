import {ComponentFixture, TestBed} from '@angular/core/testing';

import {ListarParametroQuadroSocialComponent} from './listar-parametro-quadro-social.component';

describe('ListarParametroQuadroSocialComponent', () => {
  let component: ListarParametroQuadroSocialComponent;
  let fixture: ComponentFixture<ListarParametroQuadroSocialComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListarParametroQuadroSocialComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListarParametroQuadroSocialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
