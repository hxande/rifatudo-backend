export const complementoAnuarioRoutesRoleMaps = [
  {
    routes: [
      'administracao/novo-complemento-anuario',
      'administracao/listagem-complemento-anuario',
      'administracao/complemento-anuario/:id'
    ],
    roles: ['CADASTRO_REGISTRO_NACIONAL'],
    types: ['N']
  },
  {
    routes: [
      'administracao/complemento-anuario-ue'
    ],
    roles: ['CADASTRO_REGISTRO_ESTADUAL'],
    types: ['E']
  }
];
