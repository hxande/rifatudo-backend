import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplementoAnuarioRamoUrlComponent } from './complemento-anuario-ramo-url.component';

describe('ComplementoAnuarioRamoUrlComponent', () => {
  let component: ComplementoAnuarioRamoUrlComponent;
  let fixture: ComponentFixture<ComplementoAnuarioRamoUrlComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ComplementoAnuarioRamoUrlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ComplementoAnuarioRamoUrlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
