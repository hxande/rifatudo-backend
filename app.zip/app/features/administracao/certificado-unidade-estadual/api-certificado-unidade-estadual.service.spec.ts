import { TestBed, inject } from '@angular/core/testing';

import { ApiCertificadoUnidadeEstadualService } from './api-certificado-unidade-estadual.service';

describe('ApiCertificadoUnidadeEstadualService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiCertificadoUnidadeEstadualService]
    });
  });

  it('should be created', inject([ApiCertificadoUnidadeEstadualService], (service: ApiCertificadoUnidadeEstadualService) => {
    expect(service).toBeTruthy();
  }));
});
