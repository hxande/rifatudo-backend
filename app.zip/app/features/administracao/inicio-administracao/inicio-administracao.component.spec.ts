import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { InicioAdministracaoComponent } from './inicio-administracao.component';

describe('InicioAdministracaoComponent', () => {
  let component: InicioAdministracaoComponent;
  let fixture: ComponentFixture<InicioAdministracaoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ InicioAdministracaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InicioAdministracaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
