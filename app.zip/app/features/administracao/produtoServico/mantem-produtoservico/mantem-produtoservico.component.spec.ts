import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { MantemProdutoservicoComponent } from './mantem-produtoservico.component';

describe('MantemProdutoservicoComponent', () => {
  let component: MantemProdutoservicoComponent;
  let fixture: ComponentFixture<MantemProdutoservicoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MantemProdutoservicoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MantemProdutoservicoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
