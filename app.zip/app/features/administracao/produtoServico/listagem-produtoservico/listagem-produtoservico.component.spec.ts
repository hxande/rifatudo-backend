import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemProdutoservicoComponent } from './listagem-produtoservico.component';

describe('ListagemProdutoservicoComponent', () => {
  let component: ListagemProdutoservicoComponent;
  let fixture: ComponentFixture<ListagemProdutoservicoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemProdutoservicoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemProdutoservicoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
