import { Directive, Input, ElementRef, OnInit, OnChanges } from '@angular/core';

@Directive({
  selector: '[appDisableIfUnauthorized]'
})
export class DisableIfUnauthorizedDirective implements OnInit, OnChanges {

  // eslint-disable-next-line
  @Input('appDisableIfUnauthorized') role: string;


  constructor(private el: ElementRef
   // private keycloakService: KeycloakService
  ) { }

  ngOnInit() {
    this.updateElement();
  }

  ngOnChanges(): void {
    this.updateElement();
  }

  private updateElement() {
  /*  if (!this.keycloakService.hasRole(this.role)) {
      this.el.nativeElement.disabled = true;
    } else {
      this.el.nativeElement.disabled = false;
    }*/
  }
}
