import { Transacao } from './Transacao';

export class Boleto {
    id: number;
    transacao: Transacao;
    pdfBoleto: string;
    valor: number;
    numeroBoleto: number;
    desconto: number;
    multa: number;
    juros: number;
    dtVencimento: Date;
    dtRegistro: Date;
    dtPagamento: Date;
    idPessoa: number;
    cpfCnpj: string;
    nossoNumero: string;
    nomePessoa: string;
    email: string;
    endereco: string;
    cep: string;
    uf: string;
    cidade: string;
    linhaDigitavel: string;
    chaveArquivo: string;
}
