import { TestBed, inject } from '@angular/core/testing';

import { ApiBoletoService } from './api-boleto.service';

describe('ApiBoletoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiBoletoService]
    });
  });

  it('should be created', inject([ApiBoletoService], (service: ApiBoletoService) => {
    expect(service).toBeTruthy();
  }));
});
