import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Boleto } from '../../entidades/Boleto';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiBoletoService {

  constructor(private http: HttpClient) { }

  getBoleto(id: number) {
    return firstValueFrom(
      this.http.get<IServiceResponse<Boleto>>(`/boleto-api/api/v1/boleto/${id}`)
    );
  }

  saveBoleto(boleto: Boleto) {
    return firstValueFrom(
      this.http.post<IServiceResponse<Boleto>>(`/boleto-api/api/v1/boleto`, boleto)
    );
  }

}
