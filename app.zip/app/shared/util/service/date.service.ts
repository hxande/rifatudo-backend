import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DateService {

  constructor() { }

  getDate(element) {
    if(element) {
      const data = new Date(element);
      data.setHours(data.getHours()+(data.getTimezoneOffset()/60));
      return data;
  }
  return null;
  }
}
