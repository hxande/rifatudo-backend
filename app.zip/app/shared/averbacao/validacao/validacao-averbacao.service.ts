import { Injectable } from '@angular/core';
import { ValidacaoDados } from '../../validacaoDados/validacao/validacao-dados.service';

@Injectable({
    providedIn: 'root',
})
export class ValidacaoFilial {
    constructor(private validacaoDados: ValidacaoDados) {}

    podeEditarCadastroFiliais() {
        if (this.validacaoDados.podeVerEditarCooperativa()) {
            return true;
        }
        return false;
    }
}
