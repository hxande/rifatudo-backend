import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoProcessoRegistro{
  constructor(
    private keycloakService: KeycloakService
  ){}

  podeVerAcordeonBotaoAnalisar() {
    if(
    (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return true;
    }
    return false;
  }

  podeVerBotaoArquivarProcesso() {
    if(
    (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)

    )){
      return true;
    }

    return false;
  }

  podeVerFormVisitaTecnica() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }

    return true;
  }

  podeVerAcordeonBotaoAjustarConformidadeLegal() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }

    return true;
  }

  podeDesarquivarProcesso() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }

    return true;
  }

  podeDeferirIndeferirPedido() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_RESP_SITUACAO) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }
    return true;
  }

  podeEmitirCertificado() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }

    return true;
  }


  podeEmitirApontamentos() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }
    return true;
  }

  podeVerBotaoContinuarCadastro() {
    if(
    !(this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    )){
      return false;
    }
    return true;
  }

  podeFazerVisitaTecnica() {
    if(
      (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS)
      )){
        return true;
      }
      return false;
  }

}
