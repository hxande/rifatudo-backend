import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { SubPerfisEnum } from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
  providedIn: 'root'
})
export class ValidacaoInformacoesGerais {
  constructor(
    private keycloakService: KeycloakService
  ){}

  podeVerBotaoSolicitarMudancaEndereco() {
    if((this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
    this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES)
    )){
      return true;
    }
    return false;
  }

}
