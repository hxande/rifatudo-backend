import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoGovernancaManutencao {
  constructor(
    private validacaoDados: ValidacaoDados
  ){}

  podeVerAbaBotaoExcluirMandato() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }

    return false;
  }

}
