import { ChangeDetectionStrategy, Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';

@Component({
  selector: 'app-validacao-dados-historico',
  templateUrl: './validacao-dados-historico.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./validacao-dados-historico.component.css']
})
export class ValidacaoDadosHistoricoComponent implements OnInit {


  @Output() fecharDialogVisualizarHistorico = new EventEmitter<CooperativaPendencia[]>();
  @Input() pendenciasPassadas: CooperativaPendencia[];

  constructor(

  ) { }

  ngOnInit() {

  }


  fecharVisualizar(event: CooperativaPendencia[]) {
    this.fecharDialogVisualizarHistorico.emit(event);
  }

}
