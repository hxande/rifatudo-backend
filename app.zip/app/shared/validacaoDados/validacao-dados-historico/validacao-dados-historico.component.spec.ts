import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { ValidacaoDadosHistoricoComponent } from './validacao-dados-historico.component';

describe('ValidacaoDadosHistoricoComponent', () => {
  let component: ValidacaoDadosHistoricoComponent;
  let fixture: ComponentFixture<ValidacaoDadosHistoricoComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidacaoDadosHistoricoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidacaoDadosHistoricoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
