import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { Cooperativa } from '@cadastro-registro-api/models/Cooperativa';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiManutencaoCadastroRegistroService } from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { LanguageService } from '@shared/languages/calendar-primeng/language-calendar';

@Component({
  selector: 'app-ajuste-dados-component',
  templateUrl: './ajuste-dados-component.html',
  styleUrls: ['./validacao-dados-component.scss'],
})
export class AjusteDadosComponent implements OnInit {
  @Input() chave: string;
  @Input() titulo: string;
  @Input() aprovacoes: CooperativaPendencia[];
  @Input() id: number;
  @Input() coopId: number;

  pendenciaAtual: CooperativaPendencia;
  ultimaPendencia: CooperativaPendencia;
  pendenciasPassadas: CooperativaPendencia[];
  liberarValidacao = false;
  mensagemComponente = '';
  private chavePendencias = new Set();
  carregarPendencia = false;
  size: number;
  modalVisivelHistorico = false;

  constructor(
    public language: LanguageService,
    private keycloakService: KeycloakService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiManutencaoCadastroRegistroService: ApiManutencaoCadastroRegistroService,
    private changeDetectorRef: ChangeDetectorRef
  ) { }

  ngOnInit(): void {
    this.carregarAprovacao();
    this.pendenciaAtual.houveAlteracao = false;
  }

  carregarAprovacao() {
    this.pendenciaAtual = new CooperativaPendencia();

    this.chavePendencias
      .add('DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA')
      .add('DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA')
      .add('DADOS_GERAIS_CONTATOS_DA_COOPERATIVA')
      .add('DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA')
      .add('GOVERNANCA')
      .add('MANUTENCAO_GOVERNANCA')
      .add('NEGOCIO')
      .add('NEGOCIO_FILIADAS')
      .add('DOCUMENTOS')
      .add('MANUTENCAO_DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA')
      .add('MANUTENCAO_DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA')
      .add('MANUTENCAO_DADOS_GERAIS_CONTATOS_DA_COOPERATIVA')
      .add('MANUTENCAO_DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA')
      .add('MANUTENCAO_NEGOCIO')
      .add('MANUTENCAO_NEGOCIO_FILIADAS')
      .add('MANUTENCAO_DOCUMENTOS')
      .add('ARRECADACAO_BALANCO');

    if (this.chave && this.chavePendencias.has(this.chave)) {
      this.carregarComponente();
    } else {
      this.mensagemComponente = `Chave inválida para o componente: ${this.chave}`;
    }
  }

  salvarPendencia(pendencia: CooperativaPendencia) {
    if (this.isBlocoDadosGerais(pendencia.bloco)) {
      pendencia.identificadorAuxiliar = this.getBlocoDadosGerais(pendencia.bloco);
    } else {
      pendencia.identificadorAuxiliar = this.id;
    }
    pendencia.houveAlteracao = true;
    this.addPendenciaAprovacoes(pendencia);
  }

  addPendenciaAprovacoes(pendencia: CooperativaPendencia) {
    pendencia.pendencias = !this.pendenciaAtual.pendencias || this.pendenciaAtual.pendencias === '' ? null : this.pendenciaAtual.pendencias;
    pendencia.blocoAdequado = this.pendenciaAtual.blocoAdequado;
    pendencia.visualizado = false;
    if (this.pendenciaAtual.blocoAdequado === false && (this.pendenciaAtual.pendencias === null || this.pendenciaAtual.pendencias === '')) {
      pendencia.visualizado = true;
    }
    if (this.pendenciaAtual.blocoAdequado === true) {
      pendencia.visualizado = false;
    }

    if (this.verificaPendenciaAjusteExistente()) {
      this.atualizaPendenciaAjustesExistente(pendencia);
    } else {
      if (!this.aprovacoes.includes(pendencia)) {
        this.aprovacoes.push(pendencia);
      }
    }
  }

  getBlocoDadosGerais(bloco: string) {
    const arr = [
      { identificadorAuxiliar: null, bloco: 'DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA' },
      { identificadorAuxiliar: null, bloco: 'DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA' },
      { identificadorAuxiliar: null, bloco: 'DADOS_GERAIS_CONTATOS_DA_COOPERATIVA' },
      { identificadorAuxiliar: null, bloco: 'DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA' },
    ];

    let identificadorAuxiliarDadosGerais: number = null;
    arr.forEach((elem) => {
      if (elem.bloco.trim() === bloco.trim()) {
        identificadorAuxiliarDadosGerais = elem.identificadorAuxiliar;
      }
    });

    return identificadorAuxiliarDadosGerais;
  }

  isBlocoDadosGerais(bloco: string) {
    if (
      bloco === 'DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA' ||
      bloco === 'DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA' ||
      bloco === 'DADOS_GERAIS_CONTATOS_DA_COOPERATIVA' ||
      bloco === 'DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA'
    ) {
      return true;
    }
    return false;
  }

  /**
   * @description Quando o usuários seleciona Aprovar dados ou Solicitar Ajuste, é removido o anterior da lista de aprovações
   * @param identificadorAuxiliar
   */
  verificaPendenciaAjusteExistente() {
    let pendenciaExiste = false;
    this.aprovacoes.forEach((param) => {
      if (param.bloco === this.pendenciaAtual.bloco && param.identificadorAuxiliar === this.pendenciaAtual.identificadorAuxiliar) {
        pendenciaExiste = true;
      }
    });
    return pendenciaExiste;
  }

  atualizaPendenciaAjustesExistente(pendencia) {
    for (let i = 0; i < this.aprovacoes.length; i++) {
      if (this.aprovacoes[i].bloco === this.pendenciaAtual.bloco && this.aprovacoes[i].identificadorAuxiliar === this.pendenciaAtual.identificadorAuxiliar) {
        this.aprovacoes.splice(i, 1);
      }
    }
    if (!this.aprovacoes.includes(pendencia)) {
      this.aprovacoes.push(pendencia);
    }
  }

  carregarComponente() {
    if (this.chave.indexOf('MANUTENCAO_') === 0) {
      this.apiManutencaoCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          this.pendenciaAtual = new CooperativaPendencia();
          this.pendenciaAtual.cooperativa = coop;
          this.pendenciaAtual.bloco = this.chave;

          this.apiManutencaoCadastroRegistroService.podePreencherCadastroValidacao(coop.id).then((res) => {
            // Para unidade Estadual e Nacional
            if (res && res.data != null) {
              this.liberarValidacao = res.data;
              if (this.liberarValidacao) {
                this.carregarPendencia = true;
                this.apiValidacaoDadosService.obterUltimaPendenciaManutencao(this.chave, coop.id, this.id).then((uPend) => {
                  if (uPend != null && uPend.data != null) {
                    if (uPend.data.id != null) {
                      // Se trazer uma pendência, então preenche
                      this.pendenciaAtual = uPend.data; // Para UE e UN
                      this.ultimaPendencia = this.pendenciaAtual; // Para Cooperativa
                      if (this.aprovacoes && !this.aprovacoes.includes(this.pendenciaAtual) && this.ultimaPendencia.blocoAdequado) {
                        this.aprovacoes.push(this.ultimaPendencia);
                      }
                    }
                    this.apiValidacaoDadosService.obterPendenciasManutencao(this.chave, coop.id, this.id).then((pend) => {
                      if (pend != null && pend.data != null) {
                        this.pendenciasPassadas = pend.data.filter((pendencia) => this.pendenciaAtual == null || pendencia.id !== this.pendenciaAtual.id);
                        this.size = this.pendenciasPassadas.length - 1;
                      }
                      this.changeDetectorRef.markForCheck();
                    });
                  } else {
                    this.carregarPendencia = false;
                  }
                  this.changeDetectorRef.markForCheck();
                });
              }
              this.changeDetectorRef.markForCheck();
            }
          });
        }
      });
    } else if (this.chave.indexOf('ARRECADACAO_') === 0) {
      // TODO Implementr lógica, código temporário
      this.liberarValidacao = true; // TODO Lógica
      this.carregarPendencia = true;

      if (this.coopId) {
        this.pendenciaAtual = new CooperativaPendencia();
        this.pendenciaAtual.cooperativa = new Cooperativa();
        this.pendenciaAtual.cooperativa.id = this.coopId;
        this.pendenciaAtual.bloco = this.chave;

        // Para unidade Estadual e Nacional
        this.liberarValidacao = this.keycloakService.isUsuarioEstadual || this.keycloakService.isUsuarioNacional;
        if (this.liberarValidacao) {
          this.apiValidacaoDadosService.obterUltimaPendenciaArrecadacao(this.chave, this.coopId, this.id).then((uPend) => {
            // Obs: Se a pendência vier NULL, não carrega o campo para preenchimento
            if (uPend != null && uPend.data != null) {
              if (uPend.data.id != null) {
                // Se trazer uma pendência, então preenche
                this.pendenciaAtual = uPend.data; // Para UE e UN
                this.ultimaPendencia = this.pendenciaAtual; // Para Cooperativa
                // this.ultimaPendencia.blocoAdequado = this.ultimaPendencia.editadoDepoisDeAprovado ? null : this.ultimaPendencia.blocoAdequado;
                if (this.aprovacoes && !this.aprovacoes.includes(this.pendenciaAtual) && this.ultimaPendencia.blocoAdequado) {
                  this.aprovacoes.push(this.ultimaPendencia);
                }
              }
            }
          });
          this.apiValidacaoDadosService.obterPendencias(this.chave, this.coopId, this.id).then((pend) => {
            if (pend != null && pend.data != null) {
              this.pendenciasPassadas = pend.data.filter((pendencia) => this.pendenciaAtual == null || pendencia.id !== this.pendenciaAtual.id);
              this.size = this.pendenciasPassadas.length - 1;
            }
          });
        }
      }
    } else {
      this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          this.pendenciaAtual = new CooperativaPendencia();
          this.pendenciaAtual.cooperativa = coop;
          this.pendenciaAtual.bloco = this.chave;

          this.apiCadastroRegistroService.podePreencherCadastroValidacao(coop.id).then((res) => {
            // Para unidade Estadual e Nacional
            if (res && res.data != null) {
              this.liberarValidacao = res.data;
              if (this.liberarValidacao) {
                this.carregarPendencia = true;
                this.apiValidacaoDadosService.obterUltimaPendencia(this.chave, coop.id, this.id).then((uPend) => {
                  if (uPend != null && uPend.data != null) {
                    if (uPend.data.id != null) {
                      // Se trazer uma pendência, então preenche
                      this.pendenciaAtual = uPend.data; // Para UE e UN
                      this.ultimaPendencia = this.pendenciaAtual; // Para Cooperativa
                      // this.ultimaPendencia.blocoAdequado = this.ultimaPendencia.editadoDepoisDeAprovado ? null : this.ultimaPendencia.blocoAdequado;
                      if (this.aprovacoes && !this.aprovacoes.includes(this.pendenciaAtual) && this.ultimaPendencia.blocoAdequado) {
                        this.aprovacoes.push(this.ultimaPendencia);
                      }
                    }

                    this.apiValidacaoDadosService.obterPendencias(this.chave, coop.id, this.id).then((pend) => {
                      if (pend != null && pend.data != null) {
                        this.pendenciasPassadas = pend.data.filter((pendencia) => this.pendenciaAtual == null || pendencia.id !== this.pendenciaAtual.id);
                        this.size = this.pendenciasPassadas.length - 1;
                      }
                      this.changeDetectorRef.markForCheck();
                    });
                  } else {
                    this.carregarPendencia = false;
                  }
                  this.changeDetectorRef.markForCheck();
                });
              }
              this.changeDetectorRef.markForCheck();
            }
          });
        }
      });
    }
  }

  validacaoSemMarcacao(): boolean {
    return this.liberarValidacao && (!this.pendenciaAtual || this.pendenciaAtual.blocoAdequado == null);
  }

  abrirDialogoHistorico() {
    this.modalVisivelHistorico = true;
  }

  fecharDialogVisualizarHistorico(event: CooperativaPendencia[]) {
    this.modalVisivelHistorico = false;
  }
}
