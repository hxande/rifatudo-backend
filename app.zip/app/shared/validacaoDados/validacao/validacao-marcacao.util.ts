import { QueryList } from '@angular/core';
import { MessageService } from 'primeng/api';
import { AjusteDadosComponent } from '../ajuste-dados-component';

export class ValidacaoMarcacaoUtil {

  static readonly MENSAGEM_SALVO_COM_PENDENCIAS = 'Registro salvo com pendências';

  static existeValidacaoSemMarcacao(componentes: QueryList<AjusteDadosComponent>): boolean {
    if (!componentes) {
      return false;
    }
    return componentes.some((componente) => componente.validacaoSemMarcacao());
  }

  static notificarSalvoComPendencias(messageService: MessageService, componentes: QueryList<AjusteDadosComponent>): boolean {
    if (componentes.first == undefined || componentes.first.pendenciaAtual.cooperativa.progressoMicro !== 'AGUARDANDO_ANALISE_2_1') {
      return false;
    }

    if (!ValidacaoMarcacaoUtil.existeValidacaoSemMarcacao(componentes)) {
      return false;
    }
    messageService.clear();
    ValidacaoMarcacaoUtil.adicionarAvisoSalvoComPendencias(messageService, componentes);
    return true;
  }

  static adicionarAvisoSalvoComPendencias(messageService: MessageService, componentes: QueryList<AjusteDadosComponent>): boolean {
    if (!ValidacaoMarcacaoUtil.existeValidacaoSemMarcacao(componentes)) {
      return false;
    }
    messageService.add({
      severity: 'warn',
      detail: ValidacaoMarcacaoUtil.MENSAGEM_SALVO_COM_PENDENCIAS,
      life: 10000,
    });
    return true;
  }
}
