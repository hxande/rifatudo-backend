import {Injectable} from '@angular/core';
import {ProgressoMacroEnum} from '@cadastro-registro-api/models/ProgressoMacroEnum';
import {ProgressoMicroEnum} from '@cadastro-registro-api/models/ProgressoMicroEnum';
import {KeycloakService} from '@auth/keycloak-service/keycloak.service';
import {SubPerfisEnum} from '@auth/keycloak-service/sub-perfis.enum';

@Injectable({
  providedIn: 'root',
})
export class ValidacaoDados {

  constructor(
    private keycloakService: KeycloakService,
  ) {
  }

  podeVerEditarDadosAgrupamento() {
    return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES)
    );
  }

  podeVerEditarCooperativa() {
    return (this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_RESP_SITUACAO) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.CO_ANA) ||
      this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN)
    );

  }

  validaAjustesDadosManutencao(progressoMacro: string) {
    if (progressoMacro === ProgressoMicroEnum.AGUARDANDO_ANALISE_MANUTENCAO_10_1) {
      return this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN);

    }

    return false;
  }

  validaAjustesDados(progressoMacro: string) {
    if (progressoMacro === ProgressoMacroEnum.VALIDACAO_DOCUMENTOS_2) {
      return this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_DADOS) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN);

    } else if (progressoMacro === ProgressoMacroEnum.ANALISE_CONFORMIDADE_LEGAL_3) {
      return this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_GES) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UE_ANA_LEGALIDADE) ||
        this.keycloakService.isVerificaPossuiSubPerfil(SubPerfisEnum.UN_AN);

    }

    return false;
  }

}
