import { ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { LanguageService } from '../languages/calendar-primeng/language-calendar';
import { ValidacaoDados } from './validacao/validacao-dados.service';
import { CooperativaPendencia } from '@cadastro-registro-api/models/CooperativaPendencia';
import { ApiValidacaoDadosService } from '@cadastro-registro-api/services/api-validacao-dados.service';
import { ApiCadastroRegistroService } from '@cadastro-registro-api/services/api-cadastro-registro.service';
import { ApiManutencaoCadastroRegistroService } from '@cadastro-registro-api/services/api-manutencao-cadastro-registro.service';
import { ApiTaxaRegistroService } from 'src/app/api/services/api-taxa-registro.service';
import { TaxaRegistro } from 'src/app/api/models/TaxaRegistro';

@Component({
  selector: 'app-validacao-dados-component',
  templateUrl: './validacao-dados-component.html',
  styleUrls: ['./validacao-dados-component.scss'],
})
export class ValidacaoDadosComponent implements OnInit, OnDestroy {
  @Input() chave: string;
  @Input() titulo: string;
  @Input() id: number;
  @Input() coopId: number;
  @Input() tooltipMessage: string;
  @Input() anoReferencia: number;
  @Input() obrigatorio: boolean = false;
  @Output() aoEditarAgrupamento = new EventEmitter<CooperativaPendencia>();

  ultimaPendencia: CooperativaPendencia;
  liberarValidacao = false;
  fluxoRegistro = false;
  mensagemComponente = '';
  private chavePendencias = new Set();
  carregarPendencia = false;
  dialogEditarAgrupamento = false;
  anoAtual: number;
  taxaRegistro: TaxaRegistro = null;
  taxaRegistroPagamentoConfirmado = false;

  constructor(
    private confirmationService: ConfirmationService,
    public language: LanguageService,
    private keycloakService: KeycloakService,
    private apiValidacaoDadosService: ApiValidacaoDadosService,
    private apiCadastroRegistroService: ApiCadastroRegistroService,
    private apiManutencaoCadastroRegistroService: ApiManutencaoCadastroRegistroService,
    public validacaoDados: ValidacaoDados,
    private apiTaxaRegistroService: ApiTaxaRegistroService,
    private changeDetectorRef: ChangeDetectorRef
  ) {
    this.anoAtual = new Date().getFullYear();
  }

  ngOnInit(): void {
    this.chavePendencias
      .add('DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA')
      .add('DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA')
      .add('DADOS_GERAIS_CONTATOS_DA_COOPERATIVA')
      .add('DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA')
      .add('GOVERNANCA')
      .add('NEGOCIO')
      .add('NEGOCIO_FILIADAS')
      .add('DOCUMENTOS')
      .add('MANUTENCAO_DADOS_GERAIS_IDENTIFICACAO_DA_COOPERATIVA')
      .add('MANUTENCAO_DADOS_GERAIS_ENDERECOS_DA_COOPERATIVA')
      .add('MANUTENCAO_DADOS_GERAIS_CONTATOS_DA_COOPERATIVA')
      .add('MANUTENCAO_DADOS_GERAIS_DADOS_SOCIAIS_DA_COOPERATIVA')
      .add('MANUTENCAO_GOVERNANCA')
      .add('MANUTENCAO_NEGOCIO')
      .add('MANUTENCAO_NEGOCIO_FILIADAS')
      .add('MANUTENCAO_DOCUMENTOS')
      .add('ARRECADACAO_BALANCO');

    if (this.chave && this.chavePendencias.has(this.chave)) {
      this.carregarComponente();
    } else {
      this.mensagemComponente = `Chave inválida para o componente: ${this.chave}`;
    }

    if (!this.anoReferencia) {
      this.anoReferencia = this.anoAtual;
    }
  }

  carregarComponente() {
    this.fluxoRegistro = this.chave.indexOf('MANUTENCAO_') !== 0 && this.chave.indexOf('ARRECADACAO_') !== 0;
    if (this.chave.indexOf('MANUTENCAO_') === 0) {
      this.apiManutencaoCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          this.carregarTaxaRegistro(coop.id);
          this.apiManutencaoCadastroRegistroService.podePreencherCadastroValidacao(coop.id).then((res) => {
            // Para unidade Estadual e Nacional
            if (res && res.data != null) {
              this.liberarValidacao = res.data;
              if (!this.liberarValidacao) {
                // Para a Cooperativa
                this.apiValidacaoDadosService.obterUltimaPendenciaManutencao(this.chave, coop.id, this.id).then((uPend) => {
                  if (uPend != null && uPend.data != null) {
                    this.ultimaPendencia = uPend.data;
                  }

                  this.carregarPendencia = true;
                  this.changeDetectorRef.markForCheck();
                });
              }
            }
          });
        }
      });
    } else if (this.chave.indexOf('ARRECADACAO_') === 0) {
      if (this.coopId) {
        this.carregarTaxaRegistro(this.coopId);
        // Para unidade Estadual e Nacional
        this.liberarValidacao = false; // TODO Pegar do servidor
        if (!this.liberarValidacao) {
          // Para a Cooperativa
          this.apiValidacaoDadosService.obterUltimaPendenciaArrecadacao(this.chave, this.coopId, this.id).then((uPend) => {
            if (uPend != null && uPend.data != null) {
              this.ultimaPendencia = uPend.data;
            }

            this.carregarPendencia = true;
            this.changeDetectorRef.markForCheck();
          });
        }
      }
    } else {
      this.apiCadastroRegistroService.getCooperativaCadastroRegistro(this.keycloakService.usuarioLogado).then((coop) => {
        if (coop) {
          this.carregarTaxaRegistro(coop.id);
          this.apiCadastroRegistroService.podePreencherCadastroValidacao(coop.id).then((res) => {
            // Para unidade Estadual e Nacional
            if (res && res.data != null) {
              this.liberarValidacao = res.data;
              if (!this.liberarValidacao) {
                // Para a Cooperativa
                this.apiValidacaoDadosService.obterUltimaPendencia(this.chave, coop.id, this.id).then((uPend) => {
                  if (uPend != null && uPend.data != null) {
                    this.ultimaPendencia = uPend.data;
                  }

                  this.carregarPendencia = true;
                  this.changeDetectorRef.markForCheck();
                });
              }
            }
          });
        }
      });
    }
  }

  ngOnDestroy(): void {}

  editarAgrupamento() {
    this.ultimaPendencia.editadoDepoisDeAprovado = true;
    this.aoEditarAgrupamento.emit(this.ultimaPendencia);
    /*this.apiValidacaoDadosService.editarAgrupamento(this.ultimaPendencia).then(res => {
        const pendencia = res.data;
        this.ultimaPendencia = pendencia;
        this.aoEditarAgrupamento.emit(this.ultimaPendencia);
    });*/
  }

  toogleDlgEditarAgrupamento() {
    this.dialogEditarAgrupamento = this.dialogEditarAgrupamento ? false : true;
  }

  confirmaEdicaoAgrupamento() {
    this.editarAgrupamento();
    this.dialogEditarAgrupamento = false;
  }

  carregarTaxaRegistro(idCooperativa: number) {
    this.apiTaxaRegistroService
      .getTaxaRegistro(idCooperativa)
      .then((res) => {
        if (res && res.data) {
          this.taxaRegistro = res.data;
          this.taxaRegistroPagamentoConfirmado = this.taxaRegistro.status === 'PAGAMENTO_REALIZADO';
          if (this.taxaRegistroPagamentoConfirmado) {
            this.carregarPendencia = true;
          }
        }
        this.changeDetectorRef.markForCheck();
      })
      .catch(() => {
        this.taxaRegistro = null;
        this.taxaRegistroPagamentoConfirmado = false;
        this.changeDetectorRef.markForCheck();
      });
  }
}
