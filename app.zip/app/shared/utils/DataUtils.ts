export class DataUtils {

  static mesesNomes = [
    { nome: 'Janeiro', indice: 1 },
    { nome: 'Fevereiro', indice: 2 },
    { nome: 'Março', indice: 3 },
    { nome: 'Abril', indice: 4 },
    { nome: 'Maio', indice: 5 },
    { nome: 'Junho', indice: 6 },
    { nome: 'Julho', indice: 7 },
    { nome: 'Agosto', indice: 8 },
    { nome: 'Setembro', indice: 9 },
    { nome: 'Outubro', indice: 10 },
    { nome: 'Novembro', indice: 11 },
    { nome: 'Dezembro', indice: 12 }
  ];

  static nomeDoMes(mes) {
    switch (mes) {
      case 1:
        return 'Janeiro';
      case 2:
        return 'Fevereiro';
      case 3:
        return 'Março';
      case 4:
        return 'Abril';
      case 5:
        return 'Maio';
      case 6:
        return 'Junho';
      case 7:
        return 'Julho';
      case 8:
        return 'Agosto';
      case 9:
        return 'Setembro';
      case 10:
        return 'Outubro';
      case 11:
        return 'Novembro';
      case 12:
        return 'Dezembro';
    }
    return null;
  }


  carregaDataUTC(dt: Date) {
    if (dt && dt.getTimezoneOffset() > 0) {
      dt.setUTCHours(dt.getUTCHours() + (dt.getTimezoneOffset() / 60));
    }
    return dt;
  }
}
