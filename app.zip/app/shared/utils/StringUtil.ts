export  class StringUtil {
  static letrasSubstituicao = {
    'ã': 'a',
    'õ': 'o',
    'á': 'a',
    'é': 'e',
    'í': 'i',
    'ó': 'o',
    'ú': 'u',
    'ç': 'c',
    'ê': 'e'
};

static retiraAcentuacao(palavra){
    return palavra.replace(/[ãõáóçõíéúê]/g, function(match) {
      return StringUtil.letrasSubstituicao[match];
  });
 }

static retiraCaracteres(palavra){
  return palavra.replace(/[^\w\s;]/gi, '');
}

static limparTexto(texto){
 const semAcento = StringUtil.retiraAcentuacao(texto)
 return StringUtil.retiraCaracteres(semAcento)

}

}
