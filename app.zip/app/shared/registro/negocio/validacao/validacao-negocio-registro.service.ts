import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable({
    providedIn: 'root',
  })
  export class ValidacaoNegocioRegistro{
    constructor(
      private validacoDados: ValidacaoDados
    ){}

    podeSalvarNegocio() {
        if(
        this.validacoDados.podeVerEditarCooperativa()
        ){
          return true;
        }

        return false;
    }

    podeEditarCadastroFiliais() {
        if(
        this.validacoDados.podeVerEditarCooperativa()
        ){
          return true;
        }

        return false;
    }
}
