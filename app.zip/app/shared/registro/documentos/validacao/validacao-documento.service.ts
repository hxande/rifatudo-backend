import { Injectable } from '@angular/core';
import { KeycloakService } from '@auth/keycloak-service/keycloak.service';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable({
  providedIn: 'root'
})
export class ValidacaoDocumento {
  constructor(
    private keycloack: KeycloakService,
    private validacaoDados: ValidacaoDados
  ){}

  podeVerBotaoNovoDocumento() {
    return (this.validacaoDados.podeVerEditarCooperativa()
    );


  }

  podeVerBotaoExcluirDocumento() {
    return (this.validacaoDados.podeVerEditarCooperativa()
    );

  }

  podeAbaDocumentoUploadArquivo() {
    return (this.validacaoDados.podeVerEditarCooperativa()
    );

  }
}
