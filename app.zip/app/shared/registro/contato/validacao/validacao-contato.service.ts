import { Injectable } from '@angular/core';
import { ValidacaoDados } from '@shared/validacaoDados/validacao/validacao-dados.service';

@Injectable({
  providedIn: 'root'
})
export class ValidacaoContato {
  constructor(
    private validacaoDados: ValidacaoDados
  ){}

  podeVerBotaoSalvarContinuar() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }
    return false;
  }

  podeAlterarContato() {
    if(
    (this.validacaoDados.podeVerEditarCooperativa()
    )){
      return true;
    }

    return false;
  }
}
