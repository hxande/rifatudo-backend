import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DesempenhoLancamentoExternoParamsComponent } from './desempenho-lancamento-externo-params.component';

describe('DesempenhoLancamentoExternoParamsComponent', () => {
  let component: DesempenhoLancamentoExternoParamsComponent;
  let fixture: ComponentFixture<DesempenhoLancamentoExternoParamsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DesempenhoLancamentoExternoParamsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DesempenhoLancamentoExternoParamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
