export interface ComentarioDataTO {
  cooperativaRegistroId: number;
  motivos: number[];
  observacao: string;
  acao: string;
  dataAlteracao: Date | string;
  usuarioAlteracao? : string;

}
