import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListagemHistoricoCooperativaRegistroComponent } from './listagem-historico-cooperativa-registro.component';

describe('ListagemHistoricoCooperativaRegistroComponent', () => {
  let component: ListagemHistoricoCooperativaRegistroComponent;
  let fixture: ComponentFixture<ListagemHistoricoCooperativaRegistroComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ListagemHistoricoCooperativaRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListagemHistoricoCooperativaRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
