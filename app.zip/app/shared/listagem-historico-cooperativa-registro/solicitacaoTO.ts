export interface SolicitacaoTO {
  id: number;
  motivoSolicitacao: string;
  statusSolicitacao: boolean;
  descricaoTipoSolicitacao: string;
  necessitaComplemento: boolean;
  necessitaDocumento: boolean;
}
