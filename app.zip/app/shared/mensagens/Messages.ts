export class Messages {
    summary?: string;
    detail?: string;
}
