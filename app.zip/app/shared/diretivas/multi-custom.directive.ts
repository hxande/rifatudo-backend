import { AfterViewInit, Directive, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appAriaLabelInputCustom]'
})
export class AriaLabelInputCustomDirective implements AfterViewInit{

  @Input() ariaLabel: string


  constructor(private el: ElementRef) {
  }
  ngAfterViewInit(): void {


    let input = this.el.nativeElement.querySelector('.p-hidden-accessible input');
    input.setAttribute('aria-label', this?.ariaLabel);
    if( input.getAttribute('role') === 'listbox')
        input.setAttribute('role', 'textbox');
  }
}
