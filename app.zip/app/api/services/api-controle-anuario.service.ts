import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {IServiceResponse} from '@utils/interfaces/IServiceResponse';
import { ControleAnuarioTO } from '../models/ControleAnuarioTO';


@Injectable({
  providedIn: 'root',
})
export class ApiControleAnuarioService {

  private url = '/cadastro-registro-api/api/v1/controle-anuario';

  constructor(private http: HttpClient) { }

  get(chaveAnuario: string): Observable<IServiceResponse<ControleAnuarioTO>> {
    const urlGet = `${this.url}/${chaveAnuario}`;
    return this.http.get<IServiceResponse<ControleAnuarioTO>>(urlGet);
  }

  update(controleAnuario: ControleAnuarioTO): Observable<IServiceResponse<ControleAnuarioTO>> {
    const urlUpdate = `${this.url}`;
    return this.http.put<IServiceResponse<ControleAnuarioTO>>(urlUpdate, controleAnuario);
  }
}
