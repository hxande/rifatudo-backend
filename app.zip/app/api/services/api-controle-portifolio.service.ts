import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { ControlePortifolioTO } from '../models/ControlePortifolioTO';

@Injectable({
    providedIn: 'root'
})
export class ApiControlePortifolioService {


    private readonly URL_API = '/cadastro-registro-api/api/v1/controle-portifolio';

    constructor(private http: HttpClient) { }

    obterControlePortifolioUfNacional(): Observable<IServiceResponse<ControlePortifolioTO>> {
        return this.http.get<IServiceResponse<ControlePortifolioTO>>(`${this.URL_API}/obter-controle-nacional`);
    }

    habilitaControlePortifolioNacional(habilita: boolean): Observable<IServiceResponse<ControlePortifolioTO>>{
        return this.http.put<IServiceResponse<ControlePortifolioTO>>(`${this.URL_API}/habilita-controle-nacional`,habilita);
    }

    getControlePortifolioUf(uf: string): Observable<IServiceResponse<ControlePortifolioTO>> {
        return this.http.get<IServiceResponse<ControlePortifolioTO>>(`${this.URL_API}/${uf}`);
    }
    salvarControlePortifolioUf(controleAnuario: ControlePortifolioTO): Observable<IServiceResponse<ControlePortifolioTO>> {
        return this.http.post<IServiceResponse<ControlePortifolioTO>>(`${this.URL_API}`, controleAnuario);
    }
    
}