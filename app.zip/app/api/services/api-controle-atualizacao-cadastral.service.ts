import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { ControleAtualizacaoCadastralTO } from '../models/ControleAtualizacaoCadastralTO';

@Injectable({
    providedIn: 'root'
})
export class ApiControleAtualizacaoCadastralService {
    private readonly URL_API = '/cadastro-registro-api/api/v1/controle-atualizacao-cadastral';

    constructor(private http: HttpClient){}


    obterControleAtualizacaoCadastral(uf: string) : Observable<IServiceResponse<ControleAtualizacaoCadastralTO>> {
        return this.http.get<IServiceResponse<ControleAtualizacaoCadastralTO>>(`${this.URL_API}/${uf}`);
    }

    obterControleAtualizacaoCadastralNacional(): Observable<IServiceResponse<ControleAtualizacaoCadastralTO>>{
        return this.http.get<IServiceResponse<ControleAtualizacaoCadastralTO>>(`${this.URL_API}/obter-controle-nacional`);    }

    getControleAtualizacaoCadastral(uf: string) : Observable<IServiceResponse<ControleAtualizacaoCadastralTO>> {
        return this.http.get<IServiceResponse<ControleAtualizacaoCadastralTO>>(`${this.URL_API}/obter-por-uf/${uf}`);
    }

    salvarControleAtualizacaoCadastral(controleAtualizacaoCadastral: ControleAtualizacaoCadastralTO) : Observable<IServiceResponse<ControleAtualizacaoCadastralTO>> {
        return this.http.post<IServiceResponse<ControleAtualizacaoCadastralTO>>(`${this.URL_API}`,controleAtualizacaoCadastral);
    }

    desabilitarControleAtualizacaoCadastral(ativaDesativa: boolean) : Observable<IServiceResponse<void>>{
        return this.http.post<IServiceResponse<void>>(`${this.URL_API}/atualizar-controle-atualizacao-cadastral`,ativaDesativa);
    }
}