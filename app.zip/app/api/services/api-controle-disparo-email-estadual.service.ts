import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ControleDisparoEmailEstadualTO } from '../models/ControleDisparoEmailEstadualTO';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { IPage } from '@utils/interfaces/IPage';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class ControleDisparoEmailEstadualService {
    private readonly URL_API = '/cadastro-registro-api/api/v1/disparo-email-estadual';
    constructor(private http: HttpClient){}

    obterControleDisparoEmailEstadual(options: { params: HttpParams }) : Observable<IServiceResponse<IPage<ControleDisparoEmailEstadualTO>>> {
        return this.http.get<IServiceResponse<IPage<ControleDisparoEmailEstadualTO>>>(`${this.URL_API}/listar`,options);
    }

    atualizatControleDisparoEmailEstadual(disparoEmailEstadual: ControleDisparoEmailEstadualTO){
        return this.http.put<IServiceResponse<ControleDisparoEmailEstadualTO>>(`${this.URL_API}/alterar`,disparoEmailEstadual);
    }
}