import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { QuadroSocialUFTO } from '../models/QuadroSocialUFTO';

@Injectable({
    providedIn: 'root'
})
export class QuadroSocialUfService {
    
    private readonly URL_API = '/cadastro-registro-api/api/v1/quadro-social-uf';

    constructor(private http: HttpClient){}

    getDadosFilialNaUf(cooperativaId: number): Observable<IServiceResponse<QuadroSocialUFTO[]>>{
        return this.http.get<IServiceResponse<QuadroSocialUFTO[]>>(`${this.URL_API}/${cooperativaId}`);
    }
}