import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ControleAnuarioUFTO } from "../models/ControleAnurioUFTO";
import { Observable } from "rxjs";
import { IServiceResponse } from "@utils/interfaces/IServiceResponse";

@Injectable({
    providedIn: 'root'
})
export class ApiControleAnuarioUfService {

    private readonly URL_API = '/cadastro-registro-api/api/v1/controle-anuario-uf';

    constructor(private http: HttpClient){}

    obterControleAnuarioUf(uf: string) : Observable<IServiceResponse<ControleAnuarioUFTO>> {
      return this.http.get<IServiceResponse<ControleAnuarioUFTO>>(`${this.URL_API}/${uf}`);
    }

    obterControleAnuarioUflNacional() : Observable<IServiceResponse<ControleAnuarioUFTO>>  {
        return this.http.get<IServiceResponse<ControleAnuarioUFTO>>(`${this.URL_API}/obter-controle-nacional`);    
    }

    getControleAnuarioUf(uf: string) : Observable<IServiceResponse<ControleAnuarioUFTO>> {
        return this.http.get<IServiceResponse<ControleAnuarioUFTO>>(`${this.URL_API}/obter-por-uf/${uf}`);
    }
    salvarControleAnuarioUf(controleAnuario: ControleAnuarioUFTO) : Observable<IServiceResponse<ControleAnuarioUFTO>> {
        return this.http.post<IServiceResponse<ControleAnuarioUFTO>>(`${this.URL_API}`,controleAnuario);
    }
    desabilitarControleAnuarioUf(ativaDesativa: boolean) : Observable<IServiceResponse<void>>{
        return this.http.post<IServiceResponse<void>>(`${this.URL_API}/atualizar-controle-anuario-uf`,ativaDesativa);
    }


}