import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable, firstValueFrom } from 'rxjs';
import { Contato } from '../models/Contato';
import { ContatoTO } from '../models/ContatoTO';

@Injectable({
  providedIn: 'root',
})
export class ApicontatoService {
  constructor(private http: HttpClient) {}

  salvaLista(contatos: ContatoTO[], idPessoa: number): Promise<IServiceResponse<void>> {
  return firstValueFrom(
    this.http.post<IServiceResponse<void>>(
      `/cadastro-registro-api/api/v1/contato/${idPessoa}`,
      contatos
    )
  );
}


  listaAreaPessoa(idArea: number, idPessoa: number): Promise<IServiceResponse<Contato[]>> {
    return firstValueFrom(this.http.get<IServiceResponse<Contato[]>>(`/cadastro-registro-api/api/v1/contato/pessoa/${idArea}/${idPessoa}`));
  }

  getListAreaContatoPorPessoa( idPessoa: number): Observable<IServiceResponse<Contato[]>> {
    return this.http.get<IServiceResponse<Contato[]>>(`/cadastro-registro-api/api/v1/contato/pessoa/${idPessoa}`);
  }
}
