import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class ApiRelatorioPendencia {

    private readonly URL_API = '/cadastro-registro-api/api/v1/manutencao-cadastro-registro';
    constructor(private http: HttpClient) { }


    gerarRelatorio(idsCooperativas: number[]): Observable<Blob> {
      return this.http.post(`${this.URL_API}/relatorioValidacaoErros`, idsCooperativas, {
        reportProgress: false,
        responseType: 'blob'
      });
    }
    
    
}