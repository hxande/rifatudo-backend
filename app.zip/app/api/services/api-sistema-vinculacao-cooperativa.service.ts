import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IPage } from '@utils/interfaces/IPage';
import { IServiceResponse } from '@utils/interfaces/IServiceResponse';
import { Observable } from 'rxjs';
import { SistemaVinculacaoCooperativaTO } from '../models/SistemaVinculacaoCooperativaTO';
import { SistemaVinculacaoTO } from '../models/SistemaVinculacaoTO';

@Injectable({
    providedIn: 'root',
})
export class ApiSistemaVinculacaoCooperativaService {
    private readonly URL_API = '/cadastro-registro-api/api/v1/sistema-vinculacao-cooperativa';
    constructor(private http: HttpClient) { }

    obterListSistemaVinculacaoCooperativa(options: { params: HttpParams }): Observable<IServiceResponse<IPage<SistemaVinculacaoCooperativaTO>>> {
        return this.http.get<IServiceResponse<IPage<SistemaVinculacaoCooperativaTO>>>(`${this.URL_API}/listar-por-sistema`, options);
    }

    salvarSistemaVinculacaoCooperativa(sistemaVinculacaoCooperativaTO: SistemaVinculacaoTO) : Observable<IServiceResponse<SistemaVinculacaoTO>> {
        return this.http.post<IServiceResponse<SistemaVinculacaoTO>>(this.URL_API,sistemaVinculacaoCooperativaTO);
    }

    getPorCooperativa(idCooperativa: number) : Observable<IServiceResponse<SistemaVinculacaoCooperativaTO[]>>{
        return this.http.get<IServiceResponse<SistemaVinculacaoCooperativaTO[]>>(`${this.URL_API}/cooperativa/${idCooperativa}`);
    }
}