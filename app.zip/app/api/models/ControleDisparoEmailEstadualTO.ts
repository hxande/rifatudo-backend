
export class ControleDisparoEmailEstadualTO {

    id: number;
    idDisparoEmail: number;
    processoDescricao: string;
    emailDescricao: string;
    emailTexto: string;
    ativo: boolean;
    uf: string;
}
