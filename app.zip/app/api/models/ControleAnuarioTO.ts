export class ControleAnuarioTO {

    chaveAnuario: string;
    preencherAnuario: string;
    mostrarpopup: boolean;
    destacarAnuario: boolean;
    textoPop: string;
    visualizarAnuario: string;
    habilitarPreenchimento: boolean;
}
