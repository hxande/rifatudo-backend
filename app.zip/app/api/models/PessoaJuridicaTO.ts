export class PessoaJuridicaTO {
    id: number;
    razaoSocial: string;
    nomeFantasia: string;
    nomeFantasiaReceitaFederal: string;
    nire: string;
    dataConstituicao: Date;
    idRamo: number;
    telefoneGeral: string;
    emailGeral: string;
    site: string;
}


