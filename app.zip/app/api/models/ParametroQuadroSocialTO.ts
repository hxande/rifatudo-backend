export class ParametroQuadroSocialTO {
    id: number;
    ativo: boolean;
    obrigatorio: boolean;
    descricaoParametro: string;
  
  }