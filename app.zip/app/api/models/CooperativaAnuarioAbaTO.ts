export class CooperativaAnuarioAbaTO {
    id: number;
    abaNome: string;
    abaPreenchida: boolean;
    anoCiclo: number;
    idCooperativa: number;
}