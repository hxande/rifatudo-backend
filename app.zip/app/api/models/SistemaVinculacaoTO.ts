import { SistemaVinculacaoCooperativaTO } from "./SistemaVinculacaoCooperativaTO";

export class SistemaVinculacaoTO {
    id: number;

	sigla: string;

	descricao: string;

	detalhamento: string;

	ativo: boolean;
	
	visivelCadastro: boolean;
	
	listaSistemaVinculacaoCooperativa: SistemaVinculacaoCooperativaTO[];

}