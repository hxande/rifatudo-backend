export class AtividadeCooperativaParticipacaoTO {
    anoAtividade: number;
    tipoAtividade: string;
    cnpj: string;
    nomeFantasia: string;
    anoRegistro: number;
    sqRamo: number;
    ramo: string;
    categoria: string;
    situacao: string;
    situacaoSK: string;
    participa: boolean;
}