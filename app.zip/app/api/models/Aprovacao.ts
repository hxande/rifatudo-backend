import { Cooperativa } from "@cadastro-registro-api/models/Cooperativa";


export class Aprovacao {
    id: number;
    ano: number;
    dataAtualizacao: Date;
    cooperativa: Cooperativa;
}
