export class QuadroSocialCooperadosDadosAdicionaisTO {
    idQuadroSocial: number;
    idParametroQuadroSocialCooperado: number;
    nomeParametroQuadroSocialCooperado: string;
    quantidade: number;
    obrigatorio: boolean;
}