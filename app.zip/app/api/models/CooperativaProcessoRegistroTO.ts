export class CooperativaProcessoRegistroTO {
    id: number;
    uf: string;
    cnpj: string;
    razaoSocial: string;
    nomeFantasia: string;
    fase: string;
    ramo: string;
    dataAberturaProcesso: Date;
    dataPrazoRegistro: Date;
    dataAtualizacao: Date;
    dataUltimaAnaliseUE: Date;
    atualizacaoNaoVisualizada: boolean;
}