export class ControleAnuarioUFTO {
    id: number;
    chaveAnuario: string;
    mostrarpopup: boolean;
    destacarAnuario: boolean;
    textoPop: string;
    cooperativaPodePreencher: boolean;
    cooperativaPodeVisualizar: boolean;
    uf: string;
    habilitarPreenchimentoAnuario: boolean;
    visualizarPeriodoAtualizacao: boolean;
}