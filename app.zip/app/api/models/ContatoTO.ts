import { AreaContato } from "./AreaContato";

export class ContatoTO {
  id: number;
  idPessoa: number;
  idAreaContato: number;
  nomeResponsavel: string;
  telefone: string;
  celular: string;
  email: string;
  site: string;
  cargo: string;
}
