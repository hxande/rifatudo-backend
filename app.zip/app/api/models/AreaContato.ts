import { Contato } from './Contato';

export class AreaContato {
    id: number;
    nome: string;
    ativo: boolean;
    excluido: boolean;
    contatos: Contato[];
    posicaoTela: number;
    utilizaCargo: boolean;
    obrigatorio: boolean;
    uf: string;
}
