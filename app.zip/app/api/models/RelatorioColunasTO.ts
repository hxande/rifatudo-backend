export class RelatorioColuna {
    descricao: string;
    largura: number;
    tipo: string;
}
