
import { PessoaFisica } from '@cadastro-registro-api/models/PessoaFisica';
import { Aprovacao } from './Aprovacao';
import { Cargo } from '@cadastro-registro-api/models/Cargo';

export class MandatoMembro {
    id: number;
    cargo: Cargo;
    pessoaFisica: PessoaFisica;
    representanteLegal: boolean;
    membroAtivo: boolean;
    inicioMandato: Date;
    fimMandato: Date;
    aprovacao: Aprovacao;
    inicioMandatoStr: string;
    isNew: boolean;
}
