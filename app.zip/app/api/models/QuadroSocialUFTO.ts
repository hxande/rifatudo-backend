export class QuadroSocialUFTO {
    id: number;
    uf: string;
    idQuadroSocial: number;
    cooperadosPFUF: number;
    cooperadosPJUF: number;
    cooperadosTotalUF: number;
    empregadosHomensUF: number;
    empregadosMulheresUF: number;
    empregadosTotalUF: number;
    cooperadosHomensUF: number;
    cooperadosMulheresUF: number;
    cooperadosAtivosUF: number;

}
