export class CooperativaHistoriCiclos {
    anoReferenciaDados: number;
    estatutoSocialVigenteDaCooperativa: string;
	demonstracoesFinanceirasExercicioFindo: string;
	ataAssembleiaGeralOrdinariaAnual: string;
	ataAssembleiaGeralAtualDiretoria: string;
	ataAssembleiaGeralEspecial: string;
	conselhoAdministracao: string;
	conselhoFiscal: string;
}
