export class TipoAtividadeTO {
    id: number;
    nome: string;
}