package br.coop.somoscooperativismo.registro.api.v1.anuario.filtros;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AnuarioFiltroTO {

	private Integer ano;

	private String nomeFantasia;

	private String cnpj;

	private String ramo;

	private String uf;

	private String situacaoCooperativa;
	
	private Integer idSituacaoCooperativa;

	private String anuario;
}
