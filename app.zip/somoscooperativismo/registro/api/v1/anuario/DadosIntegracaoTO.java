package br.coop.somoscooperativismo.registro.api.v1.anuario;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DadosIntegracaoTO {

    private String group;

    private Integer idCooperativa;
    private Integer ano;

    private String socialFinanceiro;
    private String contabilTributarioFiscal;
    private String negocio;
    private String intercooperacao;

    private String negociosSetorias;
    private String negociosIntercooperacao;
    private String negociosExportacao;
    private String negociosVendasOnline;

    private Integer situacao;
}
