package br.coop.somoscooperativismo.registro.api.v1.anuario;

import org.springframework.data.repository.CrudRepository;

public interface AnuarioTORepository extends CrudRepository<AnuarioTO, Integer> {

}
