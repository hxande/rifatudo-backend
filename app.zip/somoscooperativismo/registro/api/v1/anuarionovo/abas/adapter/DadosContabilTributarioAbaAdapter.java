package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import br.coop.somoscooperativismo.registro.api.v1.anuario.DadosIntegracaoTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioFieldsTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeQuadroEnum;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util.ConversorParametroIntegracaoService;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.util.MapeadorFieldService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.CensoAnuarioService;
import br.coop.somoscooperativismo.registro.api.v1.censoanuario.DadosSociaisFinanceirosTO;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesService;
import br.coop.somoscooperativismo.registro.api.v1.fates.CooperativaFatesTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class DadosContabilTributarioAbaAdapter {

    private final MapeadorFieldService mapeadorFieldService;
    private final CensoAnuarioService censoAnuarioService;
    private final ConversorParametroIntegracaoService conversorParametroIntegracaoService;
    private final CooperativaFatesService cooperativaFatesService;

    public boolean execute(Integer idCooperativa, Integer ano, RequestAnuarioTO request, boolean isSubmit) {
        CooperativaFatesTO cooperativaFatesTO = new CooperativaFatesTO();

        for (RequestAnuarioFieldsTO grupo : request.getFields()) {
            if (grupo.getName().equals(NomeQuadroEnum.DESTINACAO_FATES.toString())) {
                this.processarFates(grupo, cooperativaFatesTO);
            }
        }

        this.cooperativaFatesService.salvarOuAtualizar(ano, idCooperativa, cooperativaFatesTO);

        return this.processarDadosIntegracao(idCooperativa, ano, request, isSubmit);
    }

    private void processarFates(RequestAnuarioFieldsTO grupo, CooperativaFatesTO cooperativaFatesTO) {
        List<DadosDinamicosTO> dadosDinamicos = mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), CooperativaFatesTO.class);

        dadosDinamicos.forEach(dado -> {
            for (Map.Entry<String, FieldTO> entry : dado.getCamposOriginais().entrySet()) {

                String chave = entry.getKey();
                FieldTO campo = entry.getValue();

                if ("valorFates".equals(chave) && campo.getValue() != null) {
                    cooperativaFatesTO.setValorFates(new BigDecimal(campo.getValue()));
                }

                if ("finalidadesFates".equals(chave) && campo.getValue() != null) {
                    List<Integer> finalidades = Optional.ofNullable(campo.getValue())
                            .map(v -> v.replace("[", "").replace("]", "").trim())
                            .filter(v -> !v.isEmpty())
                            .map(v -> Arrays.stream(v.split(",")))
                            .orElseGet(Stream::empty)
                            .map(String::trim)
                            .filter(s -> !s.isEmpty())
                            .map(Integer::valueOf)
                            .toList();

                    cooperativaFatesTO.setFinalidadesFates(finalidades);
                }
            }
        });
    }

    private boolean processarDadosIntegracao(Integer idCooperativa, Integer ano, RequestAnuarioTO request, boolean isSubmit) {
        List<DadosDinamicosTO> dadosDinamicos = new ArrayList<>();

        for (RequestAnuarioFieldsTO grupo : request.getFields()) {
            if (!grupo.getName().equals(NomeQuadroEnum.DESTINACAO_FATES.toString())) {
                dadosDinamicos.addAll(mapeadorFieldService.mapFieldsToHybrid(grupo.getFields(), DadosSociaisFinanceirosTO.class));
            }
        }

        DadosIntegracaoTO dadosIntegracaoTO = new DadosIntegracaoTO();
        dadosIntegracaoTO.setIdCooperativa(idCooperativa);
        dadosIntegracaoTO.setAno(ano);
        dadosIntegracaoTO.setContabilTributarioFiscal(conversorParametroIntegracaoService.converterDadosDinamicos(dadosDinamicos));
        dadosIntegracaoTO.setSituacao(request.getSituacao());

        return this.censoAnuarioService.salvarIntegracao(dadosIntegracaoTO, isSubmit);
    }
}
