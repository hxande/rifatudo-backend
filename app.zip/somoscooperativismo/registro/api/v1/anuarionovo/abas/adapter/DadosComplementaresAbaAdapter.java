package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.RequestAnuarioTO;
import br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.enums.NomeAbaEnum;
import br.coop.somoscooperativismo.registro.api.v1.cooperativaanuarioabas.CooperativaAnuarioAbasService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DadosComplementaresAbaAdapter {

    private final CooperativaAnuarioAbasService cooperativaAnuarioAbasService;

    public boolean execute(Integer idCooperativa, Integer ano, RequestAnuarioTO request) {
        this.cooperativaAnuarioAbasService.salvarAba(idCooperativa, ano, NomeAbaEnum.DADOS_COMPLEMENTARES.getChaveAba(), request.getSituacao());
        return true;
    }

}
