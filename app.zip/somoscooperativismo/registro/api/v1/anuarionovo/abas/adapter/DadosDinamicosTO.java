package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import lombok.Getter;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
public class DadosDinamicosTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    // Dados mapeados para entidade (quando houver)
    private Object entidadeMapeada;

    // Dados dinâmicos para integração
    private List<DadoIntegracaoTO> dadosIntegracao = new ArrayList<>();

    // Lista original dos campos para referência
    private Map<String, FieldTO> camposOriginais = new HashMap<>();

    public void addCampo(FieldTO campo) {
        if (campo.getName() != null) {
            dadosIntegracao.add(new DadoIntegracaoTO(0, campo.getName(), campo.getIdParametro(), campo.getIdParametroAuxiliar(), campo.getValue(), campo.getParametroIntegracao()));
            camposOriginais.put(campo.getName(), campo);
        }
    }

    public String getParametroIntegracao(String id) {
        FieldTO campo = camposOriginais.get(id);
        return campo != null ? campo.getParametroIntegracao() : null;
    }
}
