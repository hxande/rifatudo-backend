package br.coop.somoscooperativismo.registro.api.v1.anuarionovo.abas.adapter;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.io.Serial;
import java.io.Serializable;

@Getter
@Setter
public class DadoIntegracaoTO implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    private Integer id;
    private String name;
    private Integer idParametro;
    private Integer idParametroAuxiliar;
    private String value;
    private String parametroIntegracao;

    public DadoIntegracaoTO(Integer id, String name, Integer idParametro, Integer idParametroAuxiliar, String value, String parametroIntegracao) {
        this.id = id;
        this.name = name;
        this.idParametro = idParametro;
        this.idParametroAuxiliar = idParametroAuxiliar;
        this.value = value;
        this.parametroIntegracao = parametroIntegracao;
    }

}
