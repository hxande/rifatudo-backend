package br.coop.somoscooperativismo.api.v1.relatorio;

import java.io.Serializable;
import java.math.BigInteger;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class RelatorioCooperativasRegistradasTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String uf;
	private BigInteger qtCooperativasTotal;
	private BigInteger qtCooperadosTotal;
	private BigInteger qtEmpregadosTotal;
	private BigInteger qtCooperativasAtivasTotal;
	private BigInteger qtCooperativasRegularesTotal;
	private BigInteger qtCooperativasInativasTotal;
	private String situacao;
	private String status;
	private BigInteger ramoId;
	private String logo;
	
	
	private transient JRBeanCollectionDataSource listaCooperativasRamo;

	public BigInteger getRamoId() {
		return ramoId;
	}
	public void setRamoId(BigInteger ramoId) {
		this.ramoId = ramoId;
	}
	
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public BigInteger getQtCooperativasTotal() {
		return qtCooperativasTotal;
	}
	public void setQtCooperativasTotal(BigInteger qtCooperativasTotal) {
		this.qtCooperativasTotal = qtCooperativasTotal;
	}
	public BigInteger getQtCooperadosTotal() {
		return qtCooperadosTotal;
	}
	public void setQtCooperadosTotal(BigInteger qtCooperadosTotal) {
		this.qtCooperadosTotal = qtCooperadosTotal;
	}
	public BigInteger getQtEmpregadosTotal() {
		return qtEmpregadosTotal;
	}
	public void setQtEmpregadosTotal(BigInteger qtEmpregadosTotal) {
		this.qtEmpregadosTotal = qtEmpregadosTotal;
	}
	public BigInteger getQtCooperativasAtivasTotal() {
		return qtCooperativasAtivasTotal;
	}
	public void setQtCooperativasAtivasTotal(BigInteger qtCooperativasAtivasTotal) {
		this.qtCooperativasAtivasTotal = qtCooperativasAtivasTotal;
	}
	public BigInteger getQtCooperativasRegularesTotal() {
		return qtCooperativasRegularesTotal;
	}
	public void setQtCooperativasRegularesTotal(BigInteger qtCooperativasRegularesTotal) {
		this.qtCooperativasRegularesTotal = qtCooperativasRegularesTotal;
	}
	public BigInteger getQtCooperativasInativasTotal() {
		return qtCooperativasInativasTotal;
	}
	public void setQtCooperativasInativasTotal(BigInteger qtCooperativasInativasTotal) {
		this.qtCooperativasInativasTotal = qtCooperativasInativasTotal;
	}
	public String getSituacao() {
		return situacao;
	}
	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}
	public JRBeanCollectionDataSource getListaCooperativasRamo() {
		return listaCooperativasRamo;
	}
	public void setListaCooperativasRamo(JRBeanCollectionDataSource listaCooperativasRamo) {
		this.listaCooperativasRamo = listaCooperativasRamo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
			
}
