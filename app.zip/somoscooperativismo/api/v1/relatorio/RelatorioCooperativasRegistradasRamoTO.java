package br.coop.somoscooperativismo.api.v1.relatorio;

import java.io.Serializable;
import java.math.BigInteger;

public class RelatorioCooperativasRegistradasRamoTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String uf;
	private String status;
	private String situacao;
	private BigInteger ano;
	private BigInteger qtCooperados;
	private BigInteger qtEmpregados;
	private BigInteger ramoId;
	private String ramo;
	private BigInteger qtCooperativasAtivas;
	private BigInteger qtCooperativasRegulares;
	
	public RelatorioCooperativasRegistradasRamoTO() {}
	
	public RelatorioCooperativasRegistradasRamoTO(String uf, String situacao, String status,
	                                              BigInteger qtCooperatdos, BigInteger qtEmpregados, BigInteger ramoId, String ramo) {
		super();
		this.uf = uf;
		this.situacao = situacao;
		this.status = status;
		this.qtCooperados = qtCooperatdos;
		this.qtEmpregados = qtEmpregados;
		this.ramoId = ramoId;
		this.ramo = ramo;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSituacao() {
		return situacao;
	}

	public void setSituacao(String situacao) {
		this.situacao = situacao;
	}

	public BigInteger getAno() {
		return ano;
	}

	public void setAno(BigInteger ano) {
		this.ano = ano;
	}

	public BigInteger getRamoId() {
		return ramoId;
	}

	public void setRamoId(BigInteger ramoId) {
		this.ramoId = ramoId;
	}

	public String getRamo() {
		return ramo;
	}

	public void setRamo(String ramo) {
		this.ramo = ramo;
	}

	public BigInteger getQtCooperativasAtivas() {
		return qtCooperativasAtivas;
	}

	public void setQtCooperativasAtivas(BigInteger qtCooperativasAtivas) {
		this.qtCooperativasAtivas = qtCooperativasAtivas;
	}

	public BigInteger getQtCooperativasRegulares() {
		return qtCooperativasRegulares;
	}

	public void setQtCooperativasRegulares(BigInteger qtCooperativasRegulares) {
		this.qtCooperativasRegulares = qtCooperativasRegulares;
	}

	public BigInteger getQtCooperados() {
		return qtCooperados;
	}

	public void setQtCooperados(BigInteger qtCooperatdos) {
		this.qtCooperados = qtCooperatdos;
	}

	public BigInteger getQtEmpregados() {
		return qtEmpregados;
	}

	public void setQtEmpregados(BigInteger qtEmpregados) {
		this.qtEmpregados = qtEmpregados;
	}
}
