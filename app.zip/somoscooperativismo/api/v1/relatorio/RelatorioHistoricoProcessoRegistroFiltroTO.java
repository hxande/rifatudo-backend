package br.coop.somoscooperativismo.api.v1.relatorio;


import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class RelatorioHistoricoProcessoRegistroFiltroTO {

    private String uf;
    private Date dataInicio;
    private Date dataFim;
    private List<String> status;
}
