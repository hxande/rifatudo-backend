package br.coop.somoscooperativismo.api.v1.relatorio;

import br.coop.somoscooperativismo.ocbcommonsapi.exceptions.RegraNegocioException;
import br.coop.somoscooperativismo.ocbcommonsapi.relatorio.util.RelatorioTO;
import br.coop.somoscooperativismo.ocbcommonsapi.services.MessagesService;
import br.coop.somoscooperativismo.registro.api.v1.situacaocooperativa.NovaSituacaoCooperativaEnum;
import br.coop.somoscooperativismo.registro.api.v1.util.GeradorPlanilhaUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
@RequiredArgsConstructor
public class RelatorioHistoricoProcessoRegistroService {

    private static final String ERRO_PLANILHA = "cooperativa.erroPlanilha";

    private final RelatorioClient relatorioClient;
    private final MessagesService messages;
    private final EntityManager entityManager;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy").withZone(ZoneId.systemDefault());

    private static final List<String> STATUS_CONCLUIDO = List.of(
            "Deferiu o pedido", "Indeferiu o pedido", "Arquivou processo",
            "Emitiu certificado", "Indeferiu recurso", "Deferiu recurso"
    );

    @Transactional(readOnly = true)
    public byte[] gerarRelatorio(RelatorioHistoricoProcessoRegistroFiltroTO filtro) {

        List<Object[]> resultados = buscarDados(filtro);

        if (resultados.isEmpty()) {
            throw new RegraNegocioException("Nenhum dado encontrado para os filtros informados.", HttpStatus.NO_CONTENT);
        }

        Map<String, List<Object[]>> processoMap = new LinkedHashMap<>();

        for (Object[] row : resultados) {
            String numeroRegistro = Optional.ofNullable((String) row[9]).orElse("SEM_REGISTRO_" + row[0]);
            processoMap.computeIfAbsent(numeroRegistro, k -> new ArrayList<>()).add(row);
        }

        RelatorioTO relatorio = GeradorPlanilhaUtil.obterRelatorioPadrao();
        relatorio.setNome("Historico_Processo_Registro");

        gerarAbaProcessos(relatorio, processoMap);

        try {
            return relatorioClient.gerarRelatorio(relatorio);
        } catch (Exception e) {
            throw new RegraNegocioException(messages.get(ERRO_PLANILHA), e);
        }

    }

    private List<Object[]> buscarDados(RelatorioHistoricoProcessoRegistroFiltroTO filtro) {

        StringBuilder jpql = new StringBuilder();

        jpql.append("SELECT h.cooperativa.id, ");
        jpql.append("h.cooperativa.dataAberturaProcesso, "); // NOVO
        jpql.append("h.dataAtualizacao, h.acao, h.fase, h.usuario, ");
        jpql.append("h.cooperativa.pessoaJuridica.ufSigla, ");
        jpql.append("h.cooperativa.progressoMacro, ");
        jpql.append("h.cooperativa.pessoaJuridica.cnpj, ");
        jpql.append("h.cooperativa.numeroRegistroOCB, ");
        jpql.append("h.cooperativa.situacaoCooperativa.id ");
        jpql.append("FROM CooperativaHistoricoProcessoRegistro h ");
        jpql.append("WHERE h.cooperativa.pessoaJuridica.ufSigla = :uf ");

        if (Objects.nonNull(filtro.getDataInicio())) {
            jpql.append("AND h.dataAtualizacao >= :dataInicio ");
        }
        if (Objects.nonNull(filtro.getDataFim())) {
            jpql.append("AND h.dataAtualizacao < :dataFim ");
        }

        jpql.append("ORDER BY h.cooperativa.id, h.dataAtualizacao ASC");

        TypedQuery<Object[]> query = entityManager.createQuery(jpql.toString(), Object[].class);
        query.setParameter("uf", filtro.getUf());

        if (Objects.nonNull(filtro.getDataInicio())) {
            query.setParameter("dataInicio", filtro.getDataInicio());
        }

        if (Objects.nonNull(filtro.getDataFim())) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(filtro.getDataFim());
            cal.add(Calendar.DAY_OF_MONTH, 1);
            query.setParameter("dataFim", cal.getTime());
        }

        return query.getResultList();
    }

    private void gerarAbaProcessos(RelatorioTO relatorio, Map<String, List<Object[]>> processoMap) {

        List<String> cabecalho = List.of(
                "numero_registro_ocb",
                "cnpj",
                "estado_uf",
                "data_inicio_processo",
                "data_fim_processo",
                "status_final",
                "duracao_total (dias)"
        );

        List<List<String>> linhas = new ArrayList<>();

        for (Map.Entry<String, List<Object[]>> entry : processoMap.entrySet()) {

            String numeroRegistro = entry.getKey();
            List<Object[]> eventos = entry.getValue();

            eventos.sort(Comparator.comparing(e -> (Date) e[2]));

            Date dataInicio = (Date) eventos.get(0)[1];
            Date dataFim = null;
            String statusFinal = "";

            String uf = (String) eventos.get(0)[6];
            String cnpj = (String) eventos.get(0)[8];

            Object[] ultimoEvento = eventos.get(eventos.size() - 1);
            Date dataUltimoEvento = (Date) ultimoEvento[2];
            String ultimaAcao = (String) ultimoEvento[3];
            Object situacaoCooperativaId = ultimoEvento[10];

            boolean finalizado =
                    (Objects.nonNull(situacaoCooperativaId) &&
                            !NovaSituacaoCooperativaEnum.NAO_REGISTRADA.getCodigo().equals(situacaoCooperativaId))
                            || STATUS_CONCLUIDO.contains(ultimaAcao);

            if (finalizado) {
                dataFim = dataUltimoEvento;
                statusFinal = Objects.nonNull(ultimaAcao) ? ultimaAcao : "Finalizado";
            }

            String duracao = "";
            if (Objects.nonNull(dataFim) && Objects.nonNull(dataInicio)) {
                long diffMs = dataFim.getTime() - dataInicio.getTime();
                duracao = String.valueOf(TimeUnit.MILLISECONDS.toDays(diffMs));
            }

            linhas.add(List.of(
                    numeroRegistro,
                    Objects.nonNull(cnpj) ? cnpj : "",
                    Objects.nonNull(uf) ? uf : "",
                    formatDate(dataInicio),
                    Objects.nonNull(dataFim) ? formatDate(dataFim) : "",
                    statusFinal,
                    duracao
            ));
        }

        GeradorPlanilhaUtil.adicionarPlanilha("01_Processos", relatorio, cabecalho, linhas, List.of(25, 25, 10, 25, 25, 30, 20));
    }

    private String formatDate(Date date) {
        return Objects.nonNull(date) ? DATE_FORMATTER.format(date.toInstant()) : "";
    }

}